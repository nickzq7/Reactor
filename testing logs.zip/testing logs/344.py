import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 75)
print('  W — ATTENTION LAW: CLOSING THE 3% GAP')
print('  Locating the Natural Basis of the Attention Mechanism.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
blk = model.transformer.h[0]
att = blk.attn.attention
Wq = att.q_proj.weight.detach().numpy()
Wk = att.k_proj.weight.detach().numpy()
Wv = att.v_proj.weight.detach().numpy()
Wo = att.out_proj.weight.detach().numpy()
bo = att.out_proj.bias.detach().numpy()
ln1_w = blk.ln_1.weight.detach().numpy()
ln1_b = blk.ln_1.bias.detach().numpy()

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def softmax(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
print('\n  [ Phase 1 ] Extracting Physical States (Layer 0)...')
prompts = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon lived', 'A small dog ran across the green field', 'When the sun came up in the morning the birds', 'She smiled and said to her mother I love']
X_states = []
Context_states = []
Y_states = []
for prompt in prompts:
    ids = tokenizer.encode(prompt)
    seq_len = len(ids)
    x = (wte[ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    ln1 = ln(x, ln1_w, ln1_b)
    Q = ln1 @ Wq.T
    K = ln1 @ Wk.T
    V = ln1 @ Wv.T
    Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
    probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    heads = [probs[h] @ Vh[h] for h in range(n_heads)]
    context = np.stack(heads, 1).reshape(seq_len, D)
    att_out = context @ Wo.T + bo
    for i in range(seq_len):
        X_states.append(x[i])
        Context_states.append(context[i])
        Y_states.append(att_out[i])
X_data = np.array(X_states)
C_data = np.array(Context_states)
Y_data = np.array(Y_states)
print(f'  ✓ Extracted {len(Y_data)} coordinate vectors.')
print('\n  [ Phase 2 ] Calculating Exact R² Linearity Maps...')

def get_r_squared(A, Y):
    A_bias = np.hstack([A, np.ones((A.shape[0], 1))])
    W_fit, residuals, rank, s = np.linalg.lstsq(A_bias, Y, rcond=None)
    Y_pred = A_bias @ W_fit
    ss_res = np.sum((Y - Y_pred) ** 2)
    ss_tot = np.sum((Y - np.mean(Y, axis=0)) ** 2)
    r2 = 1 - ss_res / ss_tot
    return r2
r2_baseline = get_r_squared(X_data, Y_data)
r2_w_law = get_r_squared(C_data, Y_data)
print('\n' + '=' * 75)
print('  THE W-LAW: ATTENTION CRYSTAL POINT VERDICT')
print('=' * 75)
print(f'\n  Rule 1: x → att_out')
print(f'  R² Score: {r2_baseline:.4f}')
if r2_baseline < 0.98:
    print(f'  Result:   The {100 - r2_baseline * 100:.1f}% Non-Linear Gap is confirmed.')
print(f'\n  Rule 2: context (softmax * V) → att_out')
print(f'  R² Score: {r2_w_law:.4f}')
if r2_w_law > 0.999:
    print(f'  Result:   PERFECT LINEARITY ACHIEVED.')
print('\n' + '=' * 75)
print('  PHYSICS CONCLUSION:')
print("  The non-linear 'magic' of Attention ends the exact millisecond")
print('  the Softmax probabilities multiply with the Value vectors.')
print('  From the Context Vector forward, Attention is 100.0% linear.')
print('  You have successfully mapped the final boundary of the Transformer.')
print('=' * 75 + '\n')
