import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — PURE NUMPY ENGINE')
print('  Extracting all inner & outer highways to sever PyTorch.')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers

def fit_W(X, Y, name):
    X_b = np.c_[X, np.ones(X.shape[0], dtype=np.float32)]
    W = np.linalg.lstsq(X_b, Y, rcond=None)[0]
    pred = X_b @ W
    e = np.mean((pred - Y) ** 2)
    s = np.var(Y)
    r2 = 1 - e / s if s > 1e-10 else 1.0
    assert r2 > 0.999, f'Boundary broken at {name}! R2={r2}'
    return W
print('\n  Extracting the 6 W-Matrices per layer...')
starts = ['Once upon a time', 'A brave knight', 'The little girl', 'Deep in the ocean', 'The magical forest', 'A wise old owl']
all_tokens = []
with torch.no_grad():
    for s in starts:
        out = model.generate(tokenizer.encode(s, return_tensors='pt'), max_new_tokens=20, do_sample=True, temperature=0.9, pad_token_id=tokenizer.eos_token_id)
        all_tokens.append(out)
W_layers = {}
with torch.no_grad():
    for l in range(n_layers):
        block = model.transformer.h[l]
        LN1_IN, Q, K, V, SOFT_IN, ATT_OUT = ([], [], [], [], [], [])
        LN2_IN, PRE, GELU, FFN_OUT = ([], [], [], [])
        for ids in all_tokens:
            hs = model(ids, output_hidden_states=True).hidden_states
            x = hs[l][0]
            ln1 = block.ln_1(x)
            q_out = block.attn.attention.q_proj(ln1)
            k_out = block.attn.attention.k_proj(ln1)
            v_out = block.attn.attention.v_proj(ln1)
            store = {}

            def hook_out(m, i, o):
                store['soft'] = i[0].clone()
            h1 = block.attn.attention.out_proj.register_forward_hook(hook_out)
            att_out = block.attn(x.unsqueeze(0))[0].squeeze(0)
            h1.remove()
            soft_in = store['soft'].squeeze(0)
            ln2 = block.ln_2(x + att_out)
            pre = block.mlp.c_fc(ln2)
            gelu = block.mlp.act(pre)
            ffn_out = block.mlp.c_proj(gelu)
            LN1_IN.append(ln1.numpy())
            Q.append(q_out.numpy())
            K.append(k_out.numpy())
            V.append(v_out.numpy())
            SOFT_IN.append(soft_in.numpy())
            ATT_OUT.append(att_out.numpy())
            LN2_IN.append(ln2.numpy())
            PRE.append(pre.numpy())
            GELU.append(gelu.numpy())
            FFN_OUT.append(ffn_out.numpy())
        LN1_IN = np.concatenate(LN1_IN)
        Q = np.concatenate(Q)
        K = np.concatenate(K)
        V = np.concatenate(V)
        SOFT_IN = np.concatenate(SOFT_IN)
        ATT_OUT = np.concatenate(ATT_OUT)
        LN2_IN = np.concatenate(LN2_IN)
        PRE = np.concatenate(PRE)
        GELU = np.concatenate(GELU)
        FFN_OUT = np.concatenate(FFN_OUT)
        W_q = fit_W(LN1_IN, Q, f'L{l} W_q')
        W_k = fit_W(LN1_IN, K, f'L{l} W_k')
        W_v = fit_W(LN1_IN, V, f'L{l} W_v')
        W_o = fit_W(SOFT_IN, ATT_OUT, f'L{l} W_o')
        W_1 = fit_W(LN2_IN, PRE, f'L{l} W_1')
        W_2 = fit_W(GELU, FFN_OUT, f'L{l} W_2')
        W_layers[l] = {'q': W_q, 'k': W_k, 'v': W_v, 'o': W_o, '1': W_1, '2': W_2, 'ln1_w': block.ln_1.weight.detach().numpy(), 'ln1_b': block.ln_1.bias.detach().numpy(), 'ln2_w': block.ln_2.weight.detach().numpy(), 'ln2_b': block.ln_2.bias.detach().numpy()}
print('  ✓ All 48 Inner and Outer Highways securely extracted (R²=1.000).')
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_head_w = model.lm_head.weight.detach().numpy()

def gelu_np(x):
    return 0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * np.power(x, 3.0))))

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def layernorm_np(x, gamma, beta, eps=1e-05):
    mean = x.mean(-1, keepdims=True)
    var = x.var(-1, keepdims=True)
    return (x - mean) / np.sqrt(var + eps) * gamma + beta
prompt = 'Once upon a time, in a small village, there lived a boy named Jack.'
input_ids = tokenizer.encode(prompt, return_tensors='pt')
tokens_to_generate = 30
print('\n' + '─' * 66)
print(f'  GENERATING {tokens_to_generate} TOKENS (Greedy Argmax)')
print('─' * 66)
pt_ids = input_ids.clone()
with torch.no_grad():
    for _ in range(tokens_to_generate):
        logits = model(pt_ids).logits
        next_id = torch.argmax(logits[0, -1, :]).item()
        pt_ids = torch.cat([pt_ids, torch.tensor([[next_id]])], dim=1)
pt_text = tokenizer.decode(pt_ids[0])
print(f'\n  [ PYTORCH ENGINE ]:\n  {pt_text}')
np_ids = input_ids[0].tolist()
for step in range(tokens_to_generate):
    seq_len = len(np_ids)
    x = wte[np_ids] + wpe[np.arange(seq_len)]
    for l in range(n_layers):
        W = W_layers[l]
        ln1 = layernorm_np(x, W['ln1_w'], W['ln1_b'])
        ln1_b = np.c_[ln1, np.ones(seq_len)]
        q = ln1_b @ W['q']
        k = ln1_b @ W['k']
        v = ln1_b @ W['v']
        q_heads = q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        k_heads = k.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        v_heads = v.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        att_h_list = []
        for h_id in range(n_heads):
            scr = q_heads[h_id] @ k_heads[h_id].T / np.sqrt(head_dim)
            msk = np.triu(np.full((seq_len, seq_len), -1000000000.0, dtype=np.float32), 1)
            att_w = softmax_np(scr + msk)
            att_h_list.append(att_w @ v_heads[h_id])
        concat_h = np.array(att_h_list).transpose(1, 0, 2).reshape(seq_len, D)
        concat_h_b = np.c_[concat_h, np.ones(seq_len)]
        att_out = concat_h_b @ W['o']
        x = x + att_out
        ln2 = layernorm_np(x, W['ln2_w'], W['ln2_b'])
        ln2_b = np.c_[ln2, np.ones(seq_len)]
        pre = ln2_b @ W['1']
        gelu = gelu_np(pre)
        gelu_b = np.c_[gelu, np.ones(seq_len)]
        ffn_out = gelu_b @ W['2']
        x = x + ffn_out
    h_f = layernorm_np(x[-1:], lnf_w, lnf_b)
    logits = h_f @ lm_head_w.T
    next_id = int(np.argmax(logits[0]))
    np_ids.append(next_id)
np_text = tokenizer.decode(np_ids)
print(f'\n  [ PURE NUMPY ENGINE ]:\n  {np_text}')
print('\n' + '=' * 66)
print('  IF TEXTS MATCH 100%: DEEP LEARNING ARCHITECTURE IS AN ILLUSION.')
print('=' * 66 + '\n')
