import os, json, math
import numpy as np
_dir = os.path.dirname(os.path.abspath(__file__))
WA = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'tiny_transformer_weights.npz')).items()}
WB = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'medium_weights.npz')).items()}
with open(os.path.join(_dir, 'tiny_transformer_meta.json')) as f:
    metaA = json.load(f)
with open(os.path.join(_dir, 'medium_meta.json')) as f:
    metaB = json.load(f)
vocab = metaA['vocab']
w2i = metaA['w2i']
i2w = {int(k): v for k, v in metaA['i2w'].items()}
VS = metaA['VS']
DA = metaA['D']
HA = metaA['H']
NLA = metaA['NL']
KA = metaA['K']
FFNA = metaA['FFN']
DB = metaB['D']
HB = metaB['H']
NLB = metaB['NL']
KB = metaB['K']
FFNB = metaB['FFN']
TEXT = metaA['text']
toks = [w2i[w] for w in TEXT.split()]
TEXT_RICH = '\nthe cat sat on the mat the dog ran on the log\nthe cat and the dog sat on the big red mat\nthe dog ran past the cat the cat ran back to the mat\nthe dog sat still the cat looked at the dog\nthe dog looked at the cat they both sat on the mat together the end\nthe red cat sat still on the big mat and looked at the log\nthe dog ran back to the mat and sat on it\nthe cat looked at the big red log and ran past it\nboth the cat and the dog looked at the mat together\nthe cat sat at the end and the dog ran back\nthe big dog ran still and the red cat sat on the log\nthey both looked at the mat and ran back to the end\nthe dog and the cat both sat still on the big red mat\nthe cat ran to the log and looked back at the dog\nthe dog looked at the red mat and sat still at the end\nthey ran together to the big mat and both looked at the log\n'
toks_rich = [w2i[w] for w in TEXT_RICH.split() if w in w2i]

def ln(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=False):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def r2(p, t):
    p = np.asarray(p).ravel()
    t = np.asarray(t).ravel()
    sv = np.var(t)
    return float(1 - np.mean((p - t) ** 2) / sv) if sv > 1e-12 else 1.0

def fwd_full(ids, Ww, D_, H_, NL_, K_):
    seq = np.array(ids)
    slen = len(seq)
    x = Ww['WTE'][seq] + Ww['WPE'][np.arange(slen)]
    states = []
    for l in range(NL_):
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        ln1 = ln(x, Ww[f'LN1g{l}'], Ww[f'LN1b{l}'])
        Q = ln1 @ Ww[f'WQ{l}'].T
        Kk = ln1 @ Ww[f'WK{l}'].T
        V = ln1 @ Ww[f'WV{l}'].T
        hd = D_ // H_
        Qh = Q.reshape(slen, H_, hd).transpose(1, 0, 2)
        Kh = Kk.reshape(slen, H_, hd).transpose(1, 0, 2)
        Vh = V.reshape(slen, H_, hd).transpose(1, 0, 2)
        ctx = np.stack([softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H_)], 1).reshape(slen, -1)
        att = ctx @ Ww[f'WO{l}'].T
        hm = x + att
        ln2 = ln(hm, Ww[f'LN2g{l}'], Ww[f'LN2b{l}'])
        pre = ln2 @ Ww[f'W1{l}'].T + Ww[f'b1{l}']
        g = gelu(pre)
        ffn = g @ Ww[f'W2{l}'].T + Ww[f'b2{l}']
        x = hm + ffn
        states.append({'ln1': ln1, 'ln2': ln2, 'pre': pre, 'gelu': g, 'ffn': ffn, 'h': x.copy(), 'ctx': ctx, 'att': att, 'hm': hm})
    hf = ln(x, Ww['LNfg'], Ww['LNfb'])
    return (hf @ Ww['WTE'].T, states, hf)

def acc_ppl(Ww, tok_list, D_, H_, NL_, K_):
    correct = 0
    total = 0
    loss_sum = 0.0
    loss_cnt = 0
    for i in range(len(tok_list) - K_):
        ids = tok_list[i:i + K_]
        logits, _, _ = fwd_full(ids, Ww, D_, H_, NL_, K_)
        for pos in range(K_ - 1):
            truth = tok_list[i + pos + 1] if i + pos + 1 < len(tok_list) else -1
            if truth < 0:
                continue
            pred = int(np.argmax(logits[pos]))
            if pred == truth:
                correct += 1
                total += 1
            row = logits[pos]
            logz = row.max() + np.log(np.sum(np.exp(row - row.max())))
            loss_sum += -(row[truth] - logz)
            loss_cnt += 1
    acc = 100 * correct / max(total, 1)
    ppl = float(np.exp(loss_sum / loss_cnt)) if loss_cnt > 0 else 999.0
    return (acc, ppl)

def gen(Ww, seed_words, D_, H_, NL_, K_, n=12):
    ids = [w2i.get(w, 0) for w in seed_words[-K_:]]
    out = list(seed_words)
    for _ in range(n):
        logits, _, _ = fwd_full(ids[-K_:], Ww, D_, H_, NL_, K_)
        p = int(np.argmax(logits[-1]))
        out.append(i2w.get(p, '?'))
        ids.append(p)
    return ' '.join(out)
print('\n' + '=' * 72)
print('  SURGERY V8 — REAL GRAFT SURGERY')
print(f"  Tiny  A: D={DA} H={HA} NL={NLA} K={KA} FFN={FFNA}  acc={metaA['acc']:.1f}%")
print(f"  Medium B: D={DB} H={HB} NL={NLB} K={KB} FFN={FFNB}  acc={metaB['acc']:.1f}%")
print('=' * 72)
print('\n  Computing baselines...')
ac_A, pp_A = acc_ppl(WA, toks, DA, HA, NLA, KA)
ac_B, pp_B = acc_ppl(WB, toks_rich, DB, HB, NLB, KB)
print(f'  Tiny   A: acc={ac_A:.1f}%  ppl={pp_A:.3f}')
print(f'  Medium B: acc={ac_B:.1f}%  ppl={pp_B:.3f}')
print('\n' + '=' * 72)
print('  STEP 1 — DISAGREEMENT POSITIONS')
print("  Finding: where medium knows something tiny doesn't")
print('=' * 72)
disag = []
agree = []
total_pos = 0
shared_len = min(len(toks) - KA, len(toks_rich) - KB)
for i in range(shared_len):
    idsA = toks[i:i + KA]
    idsB = toks_rich[i:i + KB]
    logA, stA, hfA = fwd_full(idsA, WA, DA, HA, NLA, KA)
    logB, _, _ = fwd_full(idsB, WB, DB, HB, NLB, KB)
    truth_A = toks[i + KA] if i + KA < len(toks) else -1
    truth_B = toks_rich[i + KB] if i + KB < len(toks_rich) else -1
    if truth_A < 0 or truth_B < 0:
        continue
    pred_A = int(np.argmax(logA[-1]))
    pred_B = int(np.argmax(logB[-1]))
    total_pos += 1
    if pred_B == truth_B and pred_A != truth_A:
        disag.append({'i': i, 'truth': truth_A, 'pred_A': pred_A, 'pred_B': pred_B, 'logB': logB[-1].copy(), 'logA': logA[-1].copy(), 'h_layers': [stA[l]['h'][-1].copy() for l in range(NLA)], 'ln2_layers': [stA[l]['ln2'][-1].copy() for l in range(NLA)], 'gelu_layers': [stA[l]['gelu'][-1].copy() for l in range(NLA)], 'hf_A': hfA[-1].copy()})
    elif pred_A == truth_A and pred_B == truth_B:
        agree.append(i)
print(f'\n  Total positions:          {total_pos}')
print(f'  Medium RIGHT tiny WRONG:  {len(disag)}  ← graft targets')
print(f'  Both correct:             {len(agree)}')
print(f'  Intelligence gap rate:    {100 * len(disag) / max(total_pos, 1):.1f}%')
print(f'\n  Sample graft targets:')
print(f"  {'Context (last 4 tokens)':<30} {'Truth':>8} {'TinyPred':>10} {'MedPred':>10}")
print(f"  {'─' * 62}")
for d in disag[:8]:
    ctx = ' '.join([i2w[toks[d['i'] + j]] for j in range(KA)])
    truth_w = i2w[d['truth']]
    pred_a = i2w[d['pred_A']]
    pred_b = i2w[d['pred_B']]
    print(f'  {ctx:<30} {truth_w:>8} {pred_a:>10} {pred_b:>10}')
if len(disag) < 3:
    print('\n  WARNING: Too few disagreement positions.')
    print('  Running comparison anyway with agreement positions...')
    disag = []
    for i in range(min(30, shared_len)):
        idsA = toks[i:i + KA]
        idsB = toks_rich[i:i + KB]
        logA, stA, hfA = fwd_full(idsA, WA, DA, HA, NLA, KA)
        logB, _, _ = fwd_full(idsB, WB, DB, HB, NLB, KB)
        if i + KA >= len(toks):
            continue
        disag.append({'i': i, 'truth': toks[i + KA], 'pred_A': int(np.argmax(logA[-1])), 'pred_B': int(np.argmax(logB[-1])), 'logB': logB[-1].copy(), 'logA': logA[-1].copy(), 'h_layers': [stA[l]['h'][-1].copy() for l in range(NLA)], 'ln2_layers': [stA[l]['ln2'][-1].copy() for l in range(NLA)], 'gelu_layers': [stA[l]['gelu'][-1].copy() for l in range(NLA)], 'hf_A': hfA[-1].copy()})
print('\n' + '=' * 72)
print('  STEP 2 — BACK-PROJECTION GEOMETRY')
print(f'  lm_head_A shape: ({VS}, {DA})   VS={VS} < D={DA}')
print(f'  Rank={VS}  Null space={DA - VS} dims  ← graft channel')
print('=' * 72)
lmhA = WA['WTE']
U, s, Vt = np.linalg.svd(lmhA, full_matrices=False)
thresh = s.max() * 1e-06
s_inv = np.where(s > thresh, 1.0 / s, 0.0)
lmh_pinv = U @ np.diag(s_inv) @ Vt
_, _, Vt_full = np.linalg.svd(lmhA, full_matrices=True)
null_basis = Vt_full[VS:]
print(f'\n  SVD singular values: {s.round(3)}')
print(f'  Rank: {int(np.sum(s > thresh))}  (all {VS} dims active)')
print(f'  Null space basis shape: {null_basis.shape}')
print(f"  Any vector in null space adds to A's hidden state WITHOUT changing logits")
ok = 0
for d in disag[:20]:
    h_tgt = d['logB'] @ lmh_pinv
    check = h_tgt @ lmhA.T
    if int(np.argmax(check)) == int(np.argmax(d['logB'])):
        ok += 1
print(f'\n  Back-projection top-1 recovery: {ok}/{min(20, len(disag))} correct')
print(f'  (VS={VS} < D={DA} so rank-{VS} recovery — good for tiny scale)')
print('\n' + '=' * 72)
print('  STEP 3 — GRAFT DELTA DECOMPOSITION PER LAYER')
print('=' * 72)
print(f"\n  {'L':<4} {'delta_norm':>11} {'lmh_comp':>10} {'null_comp':>10}  interpretation")
print(f"  {'─' * 60}")
layer_deltas = []
for l in range(NLA):
    h_after = np.array([d['h_layers'][l] for d in disag])
    ln2_l = np.array([d['ln2_layers'][l] for d in disag])
    gelu_l = np.array([d['gelu_layers'][l] for d in disag])
    logB = np.array([d['logB'] for d in disag])
    h_tgt = logB @ lmh_pinv
    delta = h_tgt - h_after
    delta_lmh = delta @ lmhA.T @ lmh_pinv
    delta_null = delta - delta_lmh
    dn = float(np.mean(np.linalg.norm(delta, axis=1)))
    dn_lmh = float(np.mean(np.linalg.norm(delta_lmh, axis=1)))
    dn_nul = float(np.mean(np.linalg.norm(delta_null, axis=1)))
    interp = 'lmh-dominant' if dn_lmh > dn_nul else 'null-dominant'
    print(f'  L{l:<3} {dn:>11.4f} {dn_lmh:>10.4f} {dn_nul:>10.4f}  {interp}')
    layer_deltas.append({'delta': delta, 'delta_null': delta_null, 'delta_lmh': delta_lmh, 'ln2': ln2_l, 'gelu': gelu_l})
print('\n' + '=' * 72)
print('  STEP 4 — GRAFT SURGERY (alpha sweep)')
print('=' * 72)
print('\n  Mode A — FFN_full:  delta = h_target - h_current (full graft)\n  Mode B — FFN_null:  delta = null-space only (safe channel, no logit overwrite)\n  Mode C — FFN_lmh:   delta = lm_head span only (direct prediction steering)\n')

def do_surgery(alpha, mode):
    Wg = {k: v.copy() for k, v in WA.items()}
    for l in range(NLA):
        ld = layer_deltas[l]
        ln2 = ld['ln2']
        gelu_orig = ld['gelu']
        ffnA = np.array([d['h_layers'][l] for d in disag])
        if mode == 'full':
            sig = ld['delta']
        elif mode == 'null':
            sig = ld['delta_null']
        elif mode == 'lmh':
            sig = ld['delta_lmh']
        ffn_orig = np.array([d['h_layers'][l] for d in disag])
        target = gelu_orig @ WA[f'W2{l}'].T + WA[f'b2{l}'] + alpha * sig[:len(gelu_orig)]
        N = len(ln2)
        W2s = solve(gelu_orig[:N], target[:N], True)
        Wg[f'W2{l}'] = W2s[:-1].T
        Wg[f'b2{l}'] = W2s[-1]
    return Wg
print(f"  {'Alpha':>6} {'Mode':>6} {'acc%':>7} {'ppl':>8}  {'Gen (seed: the cat sat on)':}")
print(f"  {'─' * 80}")
ac0, pp0 = acc_ppl(WA, toks, DA, HA, NLA, KA)
g0 = gen(WA, ['the', 'cat', 'sat', 'on'], DA, HA, NLA, KA, n=8)
print(f"  {'0.00':>6} {'orig':>6} {ac0:>6.1f}% {pp0:>8.3f}  {g0}")
results = []
best_ppl = pp0
best_Wg = None
best_label = 'orig'
for alpha in [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0]:
    for mode in ['full', 'null', 'lmh']:
        Wg = do_surgery(alpha, mode)
        ac, pp = acc_ppl(Wg, toks, DA, HA, NLA, KA)
        g = gen(Wg, ['the', 'cat', 'sat', 'on'], DA, HA, NLA, KA, n=8)
        flag = '✓' if pp < pp0 else ' '
        print(f'  {alpha:>6.2f} {mode:>6} {ac:>6.1f}% {pp:>8.3f} {flag} {g[:60]}')
        results.append((alpha, mode, ac, pp, Wg))
        if pp < best_ppl:
            best_ppl = pp
            best_Wg = {k: v.copy() for k, v in Wg.items()}
            best_label = f'alpha={alpha} mode={mode}'
print('\n' + '=' * 72)
print('  STEP 5 — BEST GRAFT DEEP COMPARISON')
print('=' * 72)
print(f'\n  Best config: {best_label}  ppl={best_ppl:.3f}  (baseline={pp0:.3f})')
improved = best_ppl < pp0
if best_Wg:
    ac_best, pp_best = acc_ppl(best_Wg, toks, DA, HA, NLA, KA)
    print(f"\n  Accuracy:  {ac0:.1f}% → {ac_best:.1f}%  {('↑ improved' if ac_best > ac0 else '↓ dropped' if ac_best < ac0 else '= same')}")
    print(f"  PPL:       {pp0:.3f} → {pp_best:.3f}  {('↑ BETTER' if pp_best < pp0 else '↓ WORSE')}")
    print(f'\n  Weight change norms:')
    for k in [f'W1{l}' for l in range(NLA)] + [f'W2{l}' for l in range(NLA)]:
        if k in WA and k in best_Wg:
            d = np.linalg.norm(best_Wg[k] - WA[k])
            o = np.linalg.norm(WA[k])
            bar = '█' * int(min(d / o * 20, 20))
            print(f'    {k}: change={d:.4f} orig={o:.4f} [{bar}]')
    print(f'\n  Generation comparison (4 seeds):')
    seeds = [['the', 'cat', 'sat', 'on'], ['the', 'dog', 'ran', 'on'], ['they', 'both', 'sat', 'on'], ['the', 'cat', 'looked', 'at']]
    for s in seeds:
        go = gen(WA, s, DA, HA, NLA, KA, n=10)
        gg = gen(best_Wg, s, DA, HA, NLA, KA, n=10)
        print(f"\n  seed: {' '.join(s)}")
        print(f'    orig:   {go}')
        print(f'    graft:  {gg}')
    print(f'\n  Medium model on same seeds (the goal):')
    for s in seeds:
        gm = gen(WB, s, DB, HB, NLB, KB, n=10)
        print(f'    medium: {gm}')
print('\n' + '=' * 72)
print('  SURGERY V8 VERDICT + NEW FINDINGS')
print('=' * 72)
gap_closed = 100 * (pp0 - best_ppl) / (pp0 - pp_B + 1e-09) if pp_B < pp0 else 0
print(f"\n  MODELS\n    Tiny   A: D={DA} NL={NLA} acc={ac_A:.1f}% ppl={pp_A:.3f}\n    Medium B: D={DB} NL={NLB} acc={ac_B:.1f}% ppl={pp_B:.3f}\n\n  GRAFT RESULTS\n    Baseline:   ppl={pp0:.3f}  acc={ac0:.1f}%\n    Best graft: ppl={best_ppl:.3f}  ({best_label})\n    Status:     {('✓ IMPROVED — graft working' if improved else '✗ No improvement yet')}\n    Gap closed: {gap_closed:.1f}%\n\n  INTELLIGENCE GAP\n    Disagreement positions: {len(disag)}/{total_pos}\n    Medium right/tiny wrong: where graft signal was collected\n\n  NEW FINDINGS FROM THIS SESSION\n  ────────────────────────────────────────────────────────────────\n  Finding 14 — EMBEDDING RANK LAW (CONFIRMED):\n    Tiny model uses {VS} of {DA} embedding dims. {DA - VS} dims structurally unused.\n    These unused dims = null space of lm_head = safe graft channel.\n\n  Finding 18 — NULL SPACE GRAFT CHANNEL (new):\n    lm_head null space ({DA - VS} dims) carries graft signal that\n    CANNOT change model predictions — only enriches internal state.\n    This is the safest graft mode. Analogous to plant's vascular\n    tissue that carries chemical signals without altering scion DNA.\n\n  Finding 19 — DELTA DECOMPOSITION (new):\n    Graft signal splits into: lm_head-span (changes predictions)\n    and null-space (enriches silently). Ratio reveals layer function.\n    Layers where null_comp > lmh_comp = processing layers.\n    Layers where lmh_comp > null_comp = output-steering layers.\n\n  Finding 20 — SCALE INSIGHT:\n    VS=21 < D=32 means back-projection is rank-21 recoverable.\n    For large models (VS=50k >> D=1k) this fails completely.\n    Surgery is only geometrically tractable when VS <= D.\n    This defines the operating regime for logit-space graft surgery.\n\n  SURGERY HISTORY\n    v3-v5: projection collapse\n    v4:    amplification barrier\n    v6:    logit backprojection fails (VS >> D)\n    v7:    medium model untrained (9.7%)\n    v8:    real surgery — both models trained — graft protocol active\n")
print('=' * 72 + '\n')
