import numpy as np
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')

def r2(p, t):
    e = np.mean((p - t) ** 2)
    s = np.var(t)
    return float(1 - e / s) if s > 0 else 0.0

def fit_W(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    return np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0].astype(np.float32)
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at']
print(f'\nGenerating {len(seeds) * 6} training texts...')
train_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(6):
            torch.manual_seed(i * 60 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=0.8 + j * 0.04, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(train_texts)} texts.')
store = {l: {'gate': [], 'out': []} for l in range(n_layers)}
hooks = []
for li in range(n_layers):
    b = model.transformer.h[li]

    def make(l):

        def hg(m, inp, out):
            x = inp[0].detach().float()
            for t in range(x.shape[1]):
                store[l]['gate'].append(x[0, t].numpy())

        def ho(m, inp, out):
            x = out.detach().float()
            for t in range(x.shape[1]):
                store[l]['out'].append(x[0, t].numpy())
        return (hg, ho)
    hg, ho = make(li)
    hooks += [b.mlp.c_proj.register_forward_hook(hg), b.mlp.c_proj.register_forward_hook(ho)]
print(f'Running {len(train_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(train_texts):
        if i % 40 == 0:
            print(f'  {i}/{len(train_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
print(f'\nFitting W_ffn for all {n_layers} layers...')
W_ffn = {}
for li in range(n_layers):
    G = np.array(store[li]['gate'], dtype=np.float32)
    F = np.array(store[li]['out'], dtype=np.float32)
    W_ffn[li] = fit_W(G, F)
    if li in [0, 3, 7]:
        n = len(G)
        s = int(n * 0.8)
        Xb = np.c_[G, np.ones(n)]
        rv = r2(Xb[s:] @ W_ffn[li], F[s:])
        print(f'  Layer {li}: R²={rv:.4f}  N={n}  shapes G={G.shape} F={F.shape}')
print('W_ffn ready.')

class WffnPatch(nn.Module):

    def __init__(self, orig, W_mat):
        super().__init__()
        self.orig = orig
        self.W = torch.tensor(W_mat, dtype=torch.float32)
        self.active = False

    def forward(self, x):
        if not self.active:
            return self.orig(x)
        B, L, fd = x.shape
        xf = x.float().reshape(B * L, fd)
        xb = torch.cat([xf, torch.ones(B * L, 1)], dim=1)
        return (xb @ self.W).reshape(B, L, -1).to(x.dtype)
patches = []
for li in range(n_layers):
    p = WffnPatch(model.transformer.h[li].mlp.c_proj, W_ffn[li])
    model.transformer.h[li].mlp.c_proj = p
    patches.append(p)

def generate(prompt, max_new=100, mode='normal'):
    for p in patches:
        p.active = mode == 'w'
    inp = tokenizer.encode(prompt, return_tensors='pt')
    toks = []
    current = inp.clone()
    with torch.no_grad():
        for _ in range(max_new):
            out = model(current)
            tok = int(torch.argmax(out.logits[0, -1, :]).item())
            toks.append(tok)
            current = torch.cat([current, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return toks
prompts = ['Once upon a time there was a little girl who loved to', 'The little boy found a magic', 'She looked at the stars and', 'The dog ran into the forest and']
print(f"\n{'=' * 70}")
print(f'  W-NATIVE DSA — ATTENTION NORMAL + W-LAW FFN')
print(f"{'=' * 70}")
for prompt in prompts:
    nt = generate(prompt, max_new=100, mode='normal')
    wt = generate(prompt, max_new=100, mode='w')
    n = min(len(nt), len(wt))
    matches = [1 if nt[i] == wt[i] else 0 for i in range(n)]
    acc = sum(matches) / n
    normal_text = tokenizer.decode(nt, skip_special_tokens=True)
    w_text = tokenizer.decode(wt, skip_special_tokens=True)
    print(f'\n  PROMPT:  {prompt}')
    print(f'  NORMAL:  {normal_text[:150]}')
    print(f'  W-DSA:   {w_text[:150]}')
    print(f'  Match:   {acc:.1%}  ({sum(matches)}/{n})')
print(f"\n{'=' * 70}\n")
