import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
cfg = model.config
D = cfg.hidden_size
n_heads = cfg.num_attention_heads
head_dim = D // n_heads
n_layers = cfg.num_layers
act_fn = cfg.activation_function
att_layers = getattr(cfg, 'attention_layers', ['global'] * n_layers)
print(f'  D={D} heads={n_heads} head_dim={head_dim} layers={n_layers}')
print(f'  att_layers={att_layers}\n')
prompt = 'Once upon a time, in a small village, there lived a boy named Jack.'
input_ids = tokenizer.encode(prompt, return_tensors='pt')
seq_len = input_ids.shape[1]
print(f'  Prompt tokens: {seq_len}\n')
PT = {l: {} for l in range(n_layers)}
PT['final'] = {}
hooks = []
for l in range(n_layers):
    block = model.transformer.h[l]
    d = PT[l]

    def mh(li, blk, di):

        def h_ln1(m, i, o):
            di['ln1'] = o.detach().squeeze(0)

        def h_ln2(m, i, o):
            di['ln2'] = o.detach().squeeze(0)

        def h_q(m, i, o):
            di['Q'] = o.detach().squeeze(0)

        def h_k(m, i, o):
            di['K'] = o.detach().squeeze(0)

        def h_v(m, i, o):
            di['V'] = o.detach().squeeze(0)

        def h_oproj(m, i, o):
            di['concat'] = i[0].detach().squeeze(0)
            di['att_out'] = o.detach().squeeze(0)

        def h_cfc(m, i, o):
            di['pre'] = o.detach().squeeze(0)

        def h_act(m, i, o):
            di['gelu'] = o.detach().squeeze(0)

        def h_cproj(m, i, o):
            di['ffn_out'] = o.detach().squeeze(0)

        def h_blk(m, i, o):
            di['x_in'] = i[0].detach().squeeze(0)
            di['x_out'] = o[0].detach().squeeze(0)
        hooks.append(blk.ln_1.register_forward_hook(h_ln1))
        hooks.append(blk.ln_2.register_forward_hook(h_ln2))
        hooks.append(blk.attn.attention.q_proj.register_forward_hook(h_q))
        hooks.append(blk.attn.attention.k_proj.register_forward_hook(h_k))
        hooks.append(blk.attn.attention.v_proj.register_forward_hook(h_v))
        hooks.append(blk.attn.attention.out_proj.register_forward_hook(h_oproj))
        hooks.append(blk.mlp.c_fc.register_forward_hook(h_cfc))
        hooks.append(blk.mlp.act.register_forward_hook(h_act))
        hooks.append(blk.mlp.c_proj.register_forward_hook(h_cproj))
        hooks.append(blk.register_forward_hook(h_blk))
    mh(l, block, d)

def h_lnf(m, i, o):
    PT['final']['lnf'] = o.detach().squeeze(0)
hooks.append(model.transformer.ln_f.register_forward_hook(h_lnf))
with torch.no_grad():
    out = model(input_ids)
    pt_logits = out.logits[0, -1, :].numpy()
    pt_next = int(np.argmax(pt_logits))
for h in hooks:
    h.remove()

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu_new(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def cmp(name, np_v, pt_v, l=None):
    a = np.array(np_v, np.float32).flatten()
    b = np.array(pt_v, np.float32).flatten()
    e = float(np.max(np.abs(a - b)))
    s = '✓' if e < 1e-05 else '~' if e < 0.005 else '✗ DIVERGE'
    tag = f'L{l} ' if l is not None else '   '
    print(f'  {tag}{name:<28} max_err={e:.3e}  {s}')
    return e
print('=' * 62)
print('  COMPARING PYTORCH vs NUMPY STEP BY STEP')
print('=' * 62)
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()
ids = input_ids[0].tolist()
x = (wte[ids] + wpe[np.arange(seq_len)]).astype(np.float32)
cmp('embedding (x_in L0)', x, PT[0]['x_in'].numpy())
for l in range(n_layers):
    blk = model.transformer.h[l]
    att = blk.attn.attention
    mlp = blk.mlp
    atyp = att_layers[l] if l < len(att_layers) else 'global'
    print(f'\n  ─── Layer {l} ({atyp}) ───')
    ln1 = ln_np(x, blk.ln_1.weight.detach().numpy(), blk.ln_1.bias.detach().numpy())
    cmp('ln1', ln1, PT[l]['ln1'].numpy(), l)
    Wq = att.q_proj.weight.detach().numpy()
    Wk = att.k_proj.weight.detach().numpy()
    Wv = att.v_proj.weight.detach().numpy()
    Q = ln1 @ Wq.T
    cmp('Q', Q, PT[l]['Q'].numpy(), l)
    K = ln1 @ Wk.T
    cmp('K', K, PT[l]['K'].numpy(), l)
    V = ln1 @ Wv.T
    cmp('V', V, PT[l]['V'].numpy(), l)
    Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    scale = np.float32(1.0 / math.sqrt(head_dim))
    outs = []
    for h in range(n_heads):
        sc = Qh[h] @ Kh[h].T * scale
        msk = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
        outs.append(softmax(sc + msk) @ Vh[h])
    c1 = np.stack(outs, 1).reshape(seq_len, D)
    outs2 = []
    for h in range(n_heads):
        sc = Qh[h] @ Kh[h].T
        causal = np.tril(np.ones((seq_len, seq_len), bool))
        sc2 = np.where(causal, sc, np.float32(np.finfo(np.float32).min))
        sc2 = sc2 / np.float32(head_dim ** 0.5)
        outs2.append(softmax(sc2) @ Vh[h])
    c2 = np.stack(outs2, 1).reshape(seq_len, D)
    pt_c = PT[l]['concat'].numpy()
    e1 = cmp('concat (std scale)', c1, pt_c, l)
    e2 = cmp('concat (gptneo scale)', c2, pt_c, l)
    best = c1 if e1 <= e2 else c2
    Wo = att.out_proj.weight.detach().numpy()
    bo = att.out_proj.bias.detach().numpy()
    att_out = best @ Wo.T + bo
    cmp('att_out', att_out, PT[l]['att_out'].numpy(), l)
    x = x + att_out
    cmp('x after att residual', x, PT[l]['ln2'].numpy() * 0 + x, l)
    ln2 = ln_np(x, blk.ln_2.weight.detach().numpy(), blk.ln_2.bias.detach().numpy())
    cmp('ln2', ln2, PT[l]['ln2'].numpy(), l)
    W1 = mlp.c_fc.weight.detach().numpy()
    b1 = mlp.c_fc.bias.detach().numpy()
    W2 = mlp.c_proj.weight.detach().numpy()
    b2 = mlp.c_proj.bias.detach().numpy()
    pre = ln2 @ W1.T + b1
    cmp('pre_gelu', pre, PT[l]['pre'].numpy(), l)
    g = gelu_new(pre)
    cmp('post_gelu', g, PT[l]['gelu'].numpy(), l)
    ffn_out = g @ W2.T + b2
    cmp('ffn_out', ffn_out, PT[l]['ffn_out'].numpy(), l)
    x = x + ffn_out
    cmp('x_out (full block)', x, PT[l]['x_out'].numpy(), l)
print(f'\n  ─── Final ───')
lnf = ln_np(x, lnf_w, lnf_b)
cmp('lnf (last token)', lnf[-1], PT['final']['lnf'][-1].numpy())
logits = lnf[-1:] @ lm_w.T
cmp('logits', logits[0], pt_logits)
np_next = int(np.argmax(logits[0]))
print(f"\n{'=' * 62}")
print(f'  PT next: {repr(tokenizer.decode([pt_next]))} (id={pt_next})')
print(f'  NP next: {repr(tokenizer.decode([np_next]))} (id={np_next})')
print(f"  MATCH:   {('✓ YES — W PRINCIPLE PROVEN' if pt_next == np_next else '✗ NO — see first ✗ above')}")
print(f"{'=' * 62}\n")
