import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL FROM SCRATCH v2 — GREEDY LAYER-WISE')
print('  Direct text targets. No error propagation.')
print('  Each layer: one matrix inversion toward text.')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\nand flowers and all the small creatures that lived among the leaves\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with his\niron glove at last he reached the edge of the forest and called out\nthe child answered from behind a large tree where she had been hiding\nthe knight lifted her onto his horse and wrapped his cloak around her\nto keep her warm they rode back to the village as the first stars\nappeared in the sky and the people came out to greet them with lights\nand warm bread and kind words the knight stayed the night and left in\nthe morning before anyone else was awake leaving only his footprints\nin the soft mud as a sign that he had been there and done what he came\nto do the little cloud named wisp floated over the green valley and\nwatched the people work in their fields below wisp was smaller than\nall the other clouds and sometimes felt that being small was not useful\nbut one very hot day when the sun was beating down on the fields wisp\ndrifted slowly in front of the sun and made a small cool shadow on the\nearth below a farmer looked up and smiled and wiped his forehead and\nwent back to work wisp felt very happy to have helped even in a small\nway and from that day on wisp always tried to find a place where a\nlittle bit of shade might make someone or something feel better the\nold miller named otto had run his windmill for forty years every\nmorning he climbed the wooden stairs to check the stones and oil the\ngears and watch the sails turn in the wind the flour from his mill\nwas the finest in the region and bakers came from many villages to\nbuy it one summer the wind died and for three weeks the sails stood\nstill otto swept the floors and mended the fences and waited on the\ntwenty second day a small cool wind brushed his cheek and by noon\nthe mill was running at full speed and the sound of the stones filled\nthe valley otto laughed out loud which was something he almost never\ndid and he ground twice as much flour that week to make up for the\ntime that had been lost without any extra charge to the bakers because\nhe said the wind was not anyone fault and everyone had done their best\n'.strip()
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VS = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Text: {len(TEXT)} chars  Vocab: {VS}  Tokens: {len(tokens)}')
D = 64
FFN_D = 128
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 3
SEQ_LEN = 24
print(f'  D={D}  FFN_D={FFN_D}  Heads={N_HEADS}  Layers={N_LAYERS}')

def ln(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve_ridge(X, Y, lam=0.001):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    return np.linalg.solve(A, Xb.T @ Y)

def init():
    w = {}
    w['wte'] = np.random.randn(VS, D).astype(np.float64) * 0.1
    w['wpe'] = np.random.randn(SEQ_LEN + 1, D).astype(np.float64) * 0.05
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1_g{s}'] = np.ones(D, dtype=np.float64)
        w[f'ln1_b{s}'] = np.zeros(D, dtype=np.float64)
        w[f'ln2_g{s}'] = np.ones(D, dtype=np.float64)
        w[f'ln2_b{s}'] = np.zeros(D, dtype=np.float64)
        w[f'Wq{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'Wk{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'Wv{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'Wo{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'bo{s}'] = np.zeros(D, dtype=np.float64)
        w[f'W1{s}'] = np.random.randn(FFN_D, D).astype(np.float64) * 0.02
        w[f'b1{s}'] = np.zeros(FFN_D, dtype=np.float64)
        w[f'W2{s}'] = np.random.randn(D, FFN_D).astype(np.float64) * 0.02
        w[f'b2{s}'] = np.zeros(D, dtype=np.float64)
    w['lnf_g'] = np.ones(D, dtype=np.float64)
    w['lnf_b'] = np.zeros(D, dtype=np.float64)
    return w

def forward_layer(x, li, w):
    T = len(x)
    s = str(li)
    ln1_out = np.array([ln(x[i], w[f'ln1_g{s}'], w[f'ln1_b{s}']) for i in range(T)])
    Q = ln1_out @ w[f'Wq{s}'].T
    K = ln1_out @ w[f'Wk{s}'].T
    V = ln1_out @ w[f'Wv{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    context = np.stack([probs[h] @ Vh[h] for h in range(N_HEADS)], 1).reshape(T, D)
    att_out = context @ w[f'Wo{s}'].T + w[f'bo{s}']
    x_att = x + att_out
    x_new = x_att.copy()
    for t in range(T):
        ln2t = ln(x_att[t], w[f'ln2_g{s}'], w[f'ln2_b{s}'])
        pre = ln2t @ w[f'W1{s}'].T + w[f'b1{s}']
        x_new[t] = x_att[t] + gelu(pre) @ w[f'W2{s}'].T + w[f'b2{s}']
    return (x_new, context, x_att)

def forward_all(ids, w):
    T = len(ids)
    x = (w['wte'][ids] + w['wpe'][:T]).copy()
    for li in range(N_LAYERS):
        x, _, _ = forward_layer(x, li, w)
    x_f = np.array([ln(x[t], w['lnf_g'], w['lnf_b']) for t in range(T)])
    return (x_f @ w['wte'].T, x)

def perplexity(w, n=400):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        logits, _ = forward_all(ids, w)
        lg = logits[-1] - logits[-1].max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[tgt]
        tok += 1
    return math.exp(nll / tok) if tok > 0 else float('inf')
w = init()
ppl0 = perplexity(w)
print(f'\n  Random perplexity: {ppl0:.2f}  (vocab={VS})')
print(f"\n{'=' * 70}")
print(f'  GREEDY LAYER-WISE W-KERNEL TRAINING')
print(f'  Target for ALL layers = wte[next_char]')
print(f'  Direct text signal. No error propagation.')
print(f"{'=' * 70}\n")
ROUNDS = 25
BATCH = 500
print(f"  {'Round':<7} {'Perplexity':>12} {'Change':>8} {'Best':>8}")
print(f"  {'─' * 42}")
best_ppl = ppl0
best_w = {k: v.copy() for k, v in w.items()}
ppl_hist = [ppl0]
t_start = time.time()
for rnd in range(ROUNDS):
    idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
    layer_inputs = {li: [] for li in range(N_LAYERS)}
    layer_contexts = {li: [] for li in range(N_LAYERS)}
    layer_x_att = {li: [] for li in range(N_LAYERS)}
    text_targets = []
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        target = w['wte'][nxt].copy()
        text_targets.append(target)
        T = SEQ_LEN
        x = (w['wte'][ids] + w['wpe'][:T]).copy()
        for li in range(N_LAYERS):
            layer_inputs[li].append(x[-1].copy())
            x_out, ctx, x_a = forward_layer(x, li, w)
            layer_contexts[li].append(ctx[-1].copy())
            layer_x_att[li].append(x_a[-1].copy())
            x = x_out
    text_targets = np.array(text_targets, dtype=np.float64)
    for li in range(N_LAYERS):
        s = str(li)
        X_in = np.array(layer_inputs[li], dtype=np.float64)
        X_ctx = np.array(layer_contexts[li], dtype=np.float64)
        X_att = np.array(layer_x_att[li], dtype=np.float64)
        Y_att = text_targets - X_in
        Wo_new = solve_ridge(X_ctx, Y_att, lam=0.001)
        w[f'Wo{s}'] = Wo_new[:-1].T
        w[f'bo{s}'] = Wo_new[-1]
        Y_ffn = text_targets - X_att
        gelu_outs = []
        for i in range(len(idxs)):
            ids = tokens[idxs[i]:idxs[i] + SEQ_LEN]
            x_in_i = (w['wte'][ids] + w['wpe'][:SEQ_LEN]).copy()
            for ll in range(li):
                x_in_i, _, _ = forward_layer(x_in_i, ll, w)
            ln2_i = ln(X_att[i], w[f'ln2_g{s}'], w[f'ln2_b{s}'])
            pre_i = ln2_i @ w[f'W1{s}'].T + w[f'b1{s}']
            gelu_outs.append(gelu(pre_i))
        X_gelu = np.array(gelu_outs, dtype=np.float64)
        W2_new = solve_ridge(X_gelu, Y_ffn, lam=0.001)
        w[f'W2{s}'] = W2_new[:-1].T
        w[f'b2{s}'] = W2_new[-1]
        ln2s = []
        for i in range(len(idxs)):
            ln2_i = ln(X_att[i], w[f'ln2_g{s}'], w[f'ln2_b{s}'])
            ln2s.append(ln2_i)
        X_ln2 = np.array(ln2s, dtype=np.float64)
        W2_cur = w[f'W2{s}']
        Y_pre = Y_ffn @ W2_cur
        W1_new = solve_ridge(X_ln2, Y_pre, lam=0.001)
        w[f'W1{s}'] = W1_new[:-1].T
        w[f'b1{s}'] = W1_new[-1]
    wte_targets = np.zeros((VS, D), dtype=np.float64)
    wte_counts = np.zeros(VS, dtype=np.float64)
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        _, h_last = forward_all(ids, w)
        wte_targets[nxt] += h_last[-1]
        wte_counts[nxt] += 1
    for c in range(VS):
        if wte_counts[c] > 0:
            w['wte'][c] = 0.8 * w['wte'][c] + 0.2 * (wte_targets[c] / wte_counts[c])
    ppl = perplexity(w)
    ppl_hist.append(ppl)
    delta = ppl - ppl_hist[-2] if len(ppl_hist) > 1 else 0
    arrow = '↓' if delta < 0 else '→'
    best_mark = ''
    if ppl < best_ppl:
        best_ppl = ppl
        best_w = {k: v.copy() for k, v in w.items()}
        best_mark = '★'
    print(f'  {rnd + 1:<7} {ppl:>12.2f} {delta:>+8.2f} {best_ppl:>7.2f}  {arrow}{best_mark}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  FINAL EVALUATION')
print(f"{'=' * 70}\n")
ppl_final = perplexity(w, n=600)
print(f'  Random init    : {ppl0:.2f}')
print(f'  Best W-Kernel  : {best_ppl:.2f}')
print(f'  Final eval     : {ppl_final:.2f}')
print(f'  Vocab ceiling  : {VS:.0f}')
print(f'  Reduction      : {(1 - best_ppl / ppl0) * 100:.1f}%')
print(f'\n  GENERATION TEST:\n')
for gp in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    ids_g = [vocab[c] for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(100):
        logits, _ = forward_all(gen[-SEQ_LEN:], w)
        nxt = int(np.argmax(logits[-1]))
        gen.append(nxt)
    out = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  INPUT: '{gp}'")
    print(f'  GEN  : {out[len(gp):][:80]}')
    print()
print(f"{'=' * 70}")
print(f'  VERDICT')
print(f"{'=' * 70}\n")
if best_ppl < VS * 0.4:
    v = f'✓ STRONG LEARNING    — ppl={best_ppl:.1f} << vocab={VS}'
    conclusion = 'W-Kernel trains from scratch. Coordinate descent converges.'
elif best_ppl < VS * 0.7:
    v = f'✓ LEARNING           — ppl={best_ppl:.1f} < vocab={VS}'
    conclusion = 'W-Kernel learns from text. More rounds or data will improve.'
elif best_ppl < VS:
    v = f'~ PARTIAL            — ppl={best_ppl:.1f} < vocab={VS}'
    conclusion = 'Below random ceiling. Real signal from text. Architecture too small.'
else:
    v = f'! NOT YET            — ppl={best_ppl:.1f} > vocab={VS}'
    conclusion = 'Coordinate descent unstable. Need better target formulation.'
print(f'  {v}')
print(f'  {conclusion}\n')
print(f"  TRAINING METHOD SUMMARY:\n    No gradient descent. No backprop. No learning rate.\n    Each round: 3 matrix inversions per layer.\n    Rounds completed: {ROUNDS}\n    Total time: {time.time() - t_start:.0f}s\n    \n  MANISH PRINCIPLE:\n    Each layer = linear in its natural coordinates.\n    Greedy solve toward text targets = local prediction.\n    Same as how a baby learns: local, direct, no global error.\n    \n  PPLEXITY TRAJECTORY:\n    {' → '.join((f'{p:.0f}' for p in ppl_hist[::max(1, len(ppl_hist) // 10)]))}\n")
print('=' * 70 + '\n')
