import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

def diagnose(model_name, family):
    print(f"\n{'=' * 60}")
    print(f'  DIAGNOSING: {model_name} ({family})')
    print(f"{'=' * 60}")
    tok = AutoTokenizer.from_pretrained(model_name)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(model_name)
    model.eval()
    ids = tok.encode('Once upon a time', return_tensors='pt')
    L = ids.shape[1]
    print(f'  seq_len={L}  model type={type(model).__name__}')
    with torch.no_grad():
        full_out = model(ids, output_hidden_states=True)
    full_logits = full_out.logits[0, -1, :]
    hidden = full_out.hidden_states
    print(f'  hidden_states count: {len(hidden)}')
    print(f'  hidden[0] shape: {hidden[0].shape}')
    if family == 'llama':
        layer = model.model.layers[0]
        h_in = hidden[0].clone()
        print(f'\n  Trying different call signatures for Llama layer[0]:')
        try:
            with torch.no_grad():
                out = layer(h_in)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h):                    → {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h):                    → ERROR: {e}')
        try:
            pos = torch.arange(L).unsqueeze(0)
            with torch.no_grad():
                out = layer(h_in, position_ids=pos)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h, position_ids):      → {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h, position_ids):      → ERROR: {e}')
        try:
            cache_pos = torch.arange(L)
            with torch.no_grad():
                out = layer(h_in, cache_position=cache_pos)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h, cache_position):    → {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h, cache_position):    → ERROR: {e}')
        try:
            pos = torch.arange(L).unsqueeze(0)
            cache_pos = torch.arange(L)
            with torch.no_grad():
                out = layer(h_in, position_ids=pos, cache_position=cache_pos)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h, pos_ids, cache_pos):→ {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h, pos_ids, cache_pos):→ ERROR: {e}')
        import inspect
        sig = inspect.signature(layer.forward)
        print(f'\n  Layer forward signature: {sig}')
    elif family == 'gpt-neox':
        layer = model.gpt_neox.layers[0]
        h_in = hidden[0].clone()
        print(f'\n  Trying different call signatures for GPT-NeoX layer[0]:')
        try:
            with torch.no_grad():
                out = layer(h_in)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h):                 → {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h):                 → ERROR: {e}')
        try:
            mask = torch.ones(1, 1, L, L)
            with torch.no_grad():
                out = layer(h_in, attention_mask=mask)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h, attn_mask 4D):   → {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h, attn_mask 4D):   → ERROR: {e}')
        try:
            causal = torch.triu(torch.full((L, L), float('-inf')), diagonal=1)
            causal = causal.unsqueeze(0).unsqueeze(0)
            with torch.no_grad():
                out = layer(h_in, attention_mask=causal)
            h_out = out[0] if isinstance(out, tuple) else out
            err = float((h_out - hidden[1]).abs().max()) if h_out is not None else float('inf')
            print(f'  layer(h, causal_mask 4D): → {type(out)} err={err:.6f}')
        except Exception as e:
            print(f'  layer(h, causal_mask 4D): → ERROR: {e}')
        import inspect
        sig = inspect.signature(layer.forward)
        print(f'\n  Layer forward signature: {sig}')
    del model
diagnose('HuggingFaceTB/SmolLM-135M', 'llama')
diagnose('EleutherAI/pythia-160m', 'gpt-neox')
