import os, time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
_dir = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def banner(text, width=68):
    print(f"\n{'=' * width}")
    print(f'  {text}')
    print(f"{'=' * width}")

def sep(text=''):
    print(f"  ── {text} {'─' * (60 - len(text))}")
banner(f'INTELLIGENCE TRANSFER: 33M → 1M   device={device}')
sep('Downloading models')
tokenizer = AutoTokenizer.from_pretrained('roneneldan/TinyStories-33M')
tokenizer.pad_token = tokenizer.eos_token
print('  Loading TinyStories-33M (teacher)...')
model_33m = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-33M', use_safetensors=True).to(device).eval()
print('  Loading TinyStories-1M  (student)...')
model_1m = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M', use_safetensors=True).to(device)
D_big = model_33m.config.hidden_size
D_small = model_1m.config.hidden_size
VS = model_33m.config.vocab_size
p_33m = sum((p.numel() for p in model_33m.parameters()))
p_1m = sum((p.numel() for p in model_1m.parameters()))
print(f'\n  Teacher 33M : D={D_big}   params={p_33m:>12,}')
print(f'  Student  1M : D={D_small}    params={p_1m:>12,}')
print(f'  Compression : {p_33m / p_1m:.1f}x fewer params in student')
print(f'  Vocab size  : {VS:,}')
EASY_PROMPTS = ['Once upon a time, there was a little girl named Lily.', 'Tom was a small boy who loved to play with his dog.', 'A little bear lived in a cozy cave in the forest.', 'The children ran to the playground and', 'It was raining outside so Anna decided to']
HARD_PROMPTS = ['The ice cream fell on the ground. Tim started to cry because', 'Sara was kind to everyone. That is why all the children in the village', 'The bridge was broken. This meant that the children could not', 'First the boy found a key. Then he found a locked box. He used the key to open the box and inside he found', 'The old woman had three sons. The first son was brave. The second son was clever. The third son was', 'The magician performed an extraordinary trick that left everyone', 'The ancient castle was surrounded by a deep moat and tall', 'The scientists discovered a mysterious creature that was completely', 'Even though she was scared, the little girl took a deep breath and', 'The old man had not seen his friend for many years. When they finally met again, he felt', 'Everyone thought the small mouse was weak. But one day the mouse', 'The dragon was supposed to be terrifying. But when he opened his mouth, he', 'Once there was a kingdom where it never rained. The crops died. The animals were thirsty. The king called his wisest advisor and asked him to find a solution. The advisor thought for a long time and then said:']
ALL_PROMPTS = EASY_PROMPTS + HARD_PROMPTS

def generate(model, prompt, max_new=100):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.3, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def quality(prompt, output):
    gen = output[len(prompt):]
    words = gen.split()
    uniq = len(set((w.lower() for w in words)))
    n = max(len(words), 1)
    score = round(uniq / n * 0.4 + min(n, 100) / 100 * 0.4 + output.rstrip().endswith(('.', '!', '?')) * 0.2, 3)
    return score

def run_all(model, label):
    banner(label)
    easy_total = 0
    hard_total = 0
    results = []
    for i, prompt in enumerate(ALL_PROMPTS):
        tag = 'EASY' if i < len(EASY_PROMPTS) else 'HARD'
        out = generate(model, prompt)
        q = quality(prompt, out)
        gen = out[len(prompt):].strip().replace('\n', ' ')
        bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
        if tag == 'EASY':
            easy_total += q
        else:
            hard_total += q
        results.append((prompt, out, q, tag))
        print(f'  [{tag}][{i + 1:>2}] {bar} Q={q:.2f}')
        print(f'   P: {prompt[:70]}')
        print(f'   → {gen[:110]}\n')
    easy_avg = easy_total / len(EASY_PROMPTS)
    hard_avg = hard_total / len(HARD_PROMPTS)
    print(f'  Easy prompts avg : {easy_avg:.3f}')
    print(f'  Hard prompts avg : {hard_avg:.3f}')
    print(f'  Overall avg      : {(easy_total + hard_total) / len(ALL_PROMPTS):.3f}')
    return (results, easy_avg, hard_avg)

def v16_transfer(wte_big, wte_small, k=3):
    P = np.linalg.lstsq(wte_big, wte_small, rcond=None)[0]
    wte_proj = wte_big @ P
    wte_blend = 0.5 * wte_small + 0.5 * wte_proj
    agree_d = np.sum(wte_small * wte_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    wte_child = wte_blend.copy()
    wte_child[:, flip_dims] *= -1
    return (wte_child, flip_dims, agree_d)

def analyze_compression_problems(wte_big, wte_small):
    banner('WHY DIRECT COMPRESSION FAILS — ANALYSIS')
    P = np.linalg.lstsq(wte_big, wte_small, rcond=None)[0]
    wte_proj = wte_big @ P
    ss_res = np.sum((wte_small - wte_proj) ** 2)
    ss_tot = np.sum((wte_small - wte_small.mean(0)) ** 2)
    r2 = 1 - ss_res / ss_tot
    print(f'\n  1. PROJECTION QUALITY (how much 33M→1M projection fits 1M space)')
    print(f'     R² = {r2:.4f}   (1.0 = perfect, 0.0 = nothing preserved)')
    print(f"     → {('Good alignment' if r2 > 0.7 else 'Poor alignment — big information loss')}")

    def eff_rank(W, threshold=0.99):
        _, S, _ = np.linalg.svd(W, full_matrices=False)
        cumvar = np.cumsum(S) / np.sum(S)
        return int(np.searchsorted(cumvar, threshold)) + 1
    rank_big = eff_rank(wte_big)
    rank_small = eff_rank(wte_small)
    print(f'\n  2. EFFECTIVE RANK (minimum dimensions needed to hold 99% of info)')
    print(f'     33M WTE effective rank : {rank_big}')
    print(f'     1M  WTE effective rank : {rank_small}')
    print(f'     1M has D={D_small} dimensions but needs {rank_small} for its own info')
    if rank_big > D_small:
        loss_pct = round((1 - D_small / rank_big) * 100, 1)
        print(f'     → 33M needs {rank_big} dims. 1M only has {D_small}.')
        print(f'     → {loss_pct}% of 33M intelligence CANNOT fit in 1M space.')
    else:
        print(f'     → 1M has enough dimensions to hold 33M intelligence.')
    dot_products = np.sum(wte_big[:1000] @ P * wte_small[:1000], axis=1)
    align_pct = np.mean(dot_products > 0) * 100
    print(f'\n  3. TOKEN ALIGNMENT (are same words pointing same direction?)')
    print(f'     {align_pct:.1f}% of top-1000 tokens align direction after projection')
    print(f"     → {('Good' if align_pct > 60 else 'Poor')} token geometry preservation")
    print(f'\n  4. WHAT GETS LOST IN DIRECT COMPRESSION')
    print(f'     D=768 → D=64 = {768 // 64}x dimension reduction')
    print(f'     Each dimension in 1M must represent {768 // 64} dimensions of 33M')
    print(f'     Fine-grained word relationships collapse into coarse buckets')
    print(f'     Synonyms, antonyms, rare words lose their distinct positions')
    print(f'     → 1M can learn COMMON patterns but loses rare/complex intelligence')

class StoryDataset(Dataset):

    def __init__(self, texts, tok, maxlen=128):
        self.data = []
        for t in texts:
            enc = tok(t, truncation=True, max_length=maxlen, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
results_33m, easy_33m, hard_33m = run_all(model_33m, 'TEACHER — TinyStories-33M')
results_before, easy_bef, hard_bef = run_all(model_1m, 'STUDENT BEFORE — TinyStories-1M (original)')
WTE_33m = model_33m.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
WTE_1m = model_1m.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
analyze_compression_problems(WTE_33m, WTE_1m)
banner('APPLYING V16 TRANSFER  (33M → 1M)')
print(f'  33M WTE : {WTE_33m.shape}   D={D_big}')
print(f'  1M  WTE : {WTE_1m.shape}    D={D_small}\n')
WTE_child, flip_dims, agree_d = v16_transfer(WTE_33m, WTE_1m, k=3)
print(f'  Agreement range : {agree_d.min():.2f} → {agree_d.max():.2f}')
print(f'  Flipped dims    : {flip_dims.tolist()}')
with torch.no_grad():
    model_1m.transformer.wte.weight.copy_(torch.tensor(WTE_child, dtype=torch.float32).to(device))
print('\n  ✓ 33M WTE geometry injected into 1M student.')
model_33m.cpu()
torch.cuda.empty_cache()
print('  ✓ 33M moved to CPU. GPU freed.')
banner('FINE-TUNING 1M  (8 epochs, WTE frozen)')
print('  WTE frozen. Attention + FFN adapt to 33M geometry.\n')
model_1m.transformer.wte.weight.requires_grad_(False)
print('  Loading training data...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
texts = []
for item in ds:
    texts.append(item['text'])
    if len(texts) >= 3000:
        break
print(f'  Loaded {len(texts)} stories.\n')
dataset = StoryDataset(texts, tokenizer, maxlen=128)
loader = DataLoader(dataset, batch_size=8, shuffle=True)
opt = torch.optim.AdamW([p for p in model_1m.parameters() if p.requires_grad], lr=5e-05)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=8, eta_min=1e-06)
WATCH_EASY = 'Once upon a time, there was a little bear who'
WATCH_HARD = 'Everyone thought the small mouse was weak. But one day the mouse'
print(f'  Easy watch: "{WATCH_EASY}"')
print(f'  Hard watch: "{WATCH_HARD}"\n')
print(f"  {'Ep':>3}  {'Loss':>8}  {'EasyQ':>6}  {'HardQ':>6}  Output (hard prompt)")
print(f"  {'─' * 70}")
epoch_log = []
for epoch in range(1, 9):
    model_1m.train()
    total = 0
    steps = 0
    for batch in loader:
        batch = batch.to(device)
        out = model_1m(batch, labels=batch)
        opt.zero_grad()
        out.loss.backward()
        nn.utils.clip_grad_norm_(model_1m.parameters(), 1.0)
        opt.step()
        total += out.loss.item()
        steps += 1
    sched.step()
    avg_loss = total / steps
    easy_out = generate(model_1m, WATCH_EASY, max_new=40)
    hard_out = generate(model_1m, WATCH_HARD, max_new=60)
    eq = quality(WATCH_EASY, easy_out)
    hq = quality(WATCH_HARD, hard_out)
    hard_gen = hard_out[len(WATCH_HARD):].strip().replace('\n', ' ')
    bar = '█' * int(hq * 10) + '░' * (10 - int(hq * 10))
    print(f'  {epoch:>3}  {avg_loss:>8.4f}  {eq:>6.2f}  {hq:>6.2f}  {bar}')
    print(f'       Hard → {hard_gen[:85]}\n')
    epoch_log.append((epoch, avg_loss, eq, hq))
print('  ✓ Fine-tuning complete.')
results_after, easy_aft, hard_aft = run_all(model_1m, 'STUDENT AFTER — TinyStories-1M (V16 + fine-tuned)')
banner('FINAL COMPARISON')
print(f"\n  {'Model':>30}  {'Easy':>6}  {'Hard':>6}  {'Gap to Teacher':>14}")
print(f"  {'─' * 62}")
print(f"  {'Teacher  33M':>30}  {easy_33m:>6.3f}  {hard_33m:>6.3f}  {'(reference)':>14}")
print(f"  {'1M BEFORE':>30}  {easy_bef:>6.3f}  {hard_bef:>6.3f}  {easy_bef - easy_33m:>+7.3f} / {hard_bef - hard_33m:>+6.3f}")
print(f"  {'1M AFTER  (V16)':>30}  {easy_aft:>6.3f}  {hard_aft:>6.3f}  {easy_aft - easy_33m:>+7.3f} / {hard_aft - hard_33m:>+6.3f}")
print(f'\n  Transfer gain  →  Easy: {easy_aft - easy_bef:>+.3f}   Hard: {hard_aft - hard_bef:>+.3f}')
print(f'  Compression    →  {p_33m:,} → {p_1m:,} params  ({p_33m / p_1m:.1f}x smaller)')
print(f'\n  Learning curve:')
print(f"  {'Ep':>3}  {'Loss':>8}  {'EasyQ':>6}  {'HardQ':>6}  Progress (hard)")
print(f"  {'─' * 55}")
for ep, loss, eq, hq in epoch_log:
    print(f"  {ep:>3}  {loss:>8.4f}  {eq:>6.2f}  {hq:>6.2f}  {'█' * int(hq * 20)}")
print(f'\n  HARD PROMPT COMPARISON (where intelligence shows):')
print(f"  {'─' * 68}")
for i, prompt in enumerate(HARD_PROMPTS):
    idx = len(EASY_PROMPTS) + i
    t = results_33m[idx][1][len(prompt):].strip().replace('\n', ' ')[:90]
    bef = results_before[idx][1][len(prompt):].strip().replace('\n', ' ')[:90]
    aft = results_after[idx][1][len(prompt):].strip().replace('\n', ' ')[:90]
    q_t = results_33m[idx][2]
    q_bef = results_before[idx][2]
    q_aft = results_after[idx][2]
    print(f'\n  [{i + 1}] {prompt[:70]}')
    print(f'  33M   (Q={q_t:.2f}): {t}')
    print(f'  Before(Q={q_bef:.2f}): {bef}')
    print(f'  After (Q={q_aft:.2f}): {aft}')
save_path = os.path.join(_dir, 'tinystories_1m_v16_from_33m')
model_1m.save_pretrained(save_path)
tokenizer.save_pretrained(save_path)
print(f'\n\n  ✓ Saved to: {save_path}')
banner('DONE')
