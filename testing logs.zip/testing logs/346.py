import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 75)
print('  W — THE KERNEL COLLAPSE')
print('  Folding 8 Neural Layers into 1 Exact Matrix.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
print('\n  [ Phase 1 ] Extracting Physical Timelines (h_0 and h_final)...')
prompts = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon lived', 'A small dog ran across the green field', 'When the sun came up in the morning the birds', 'She smiled and said to her mother I love', 'The brave knight took his shiny sword and', 'A little boy found a magic wand inside', 'High up in the clouds there was a', 'The cat jumped over the fence and saw', 'A wise old owl sat in the tree']
H_0_raw = []
Context_raw = []
H_final = []
final_states = []

def hook_final(m, i, o):
    final_states.append(o[0].detach().cpu().numpy())
h = model.transformer.h[-1].register_forward_hook(hook_final)
all_ids = []
with torch.no_grad():
    for s in prompts:
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(hash(s) % 10000 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            seq_ids = out[0].cpu().numpy()
            model(torch.from_numpy(seq_ids).unsqueeze(0))
            y_states = final_states.pop()[0]
            seq_len = len(seq_ids)
            x_states = (wte[seq_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
            running_sum = np.zeros(D, dtype=np.float32)
            for i in range(seq_len):
                x_i = x_states[i]
                running_sum += x_i
                ctx_i = running_sum / (i + 1)
                H_0_raw.append(x_i)
                Context_raw.append(ctx_i)
                H_final.append(y_states[i])
h.remove()
H_0_raw = np.array(H_0_raw)
Context_raw = np.array(Context_raw)
H_final = np.array(H_final)
print(f'  ✓ Extracted {len(H_final)} timeline vectors.')
print('\n  [ Phase 2 ] Lifting h_0 into the W-Law Super-Space...')
Phi_X = np.hstack([H_0_raw, H_0_raw ** 2, Context_raw, Context_raw ** 2, H_0_raw * Context_raw])
Phi_X = np.hstack([Phi_X, np.ones((Phi_X.shape[0], 1))])
print(f'  ✓ Super-Space dimensions: {Phi_X.shape[1]} (from {D})')
if len(H_final) <= Phi_X.shape[1]:
    print('  [!] WARNING: Underdetermined system. Generate more data.')
print('\n  [ Phase 3 ] Inverting the Matrix to Build W_kernel...')
start_train = time.time()
W_kernel, residuals, rank, s = np.linalg.lstsq(Phi_X, H_final, rcond=None)
train_time = time.time() - start_train
print(f'  ✓ W_kernel built successfully in {train_time:.4f} seconds.')
print('\n  [ Phase 4 ] Testing the Collapse (R² Physics)')
Y_pred = Phi_X @ W_kernel
ss_res = np.sum((H_final - Y_pred) ** 2)
ss_tot = np.sum((H_final - np.mean(H_final, axis=0)) ** 2)
r2_score = 1 - ss_res / ss_tot
print('\n' + '=' * 75)
print('  THE W-KERNEL VERDICT')
print('=' * 75)
print(f'  W_kernel Shape    : {W_kernel.shape}')
print(f'  Training Time     : {train_time:.4f}s (0 Epochs, 0 Gradients)')
print(f'  R² Collapse Score : {r2_score:.4f}')
print('\n  WHAT THIS MEANS:')
if r2_score > 0.9:
    print('  MASSIVE SUCCESS. You have collapsed 8 layers into a single matrix.')
    print('  The network is almost entirely a linear geometric projection.')
    print('  Depth is officially an illusion.')
elif r2_score > 0.6:
    print('  PARTIAL COLLAPSE. The geometry holds, but the Context proxy')
    print('  (mean of past tokens) is too simple to fully capture the Softmax map.')
    print('  We need the exact Attention probability map to hit 1.000.')
else:
    print('  THE POLYNOMIAL LIMIT. The mathematical expansion of 8 layers')
    print('  creates too much high-degree complexity (x^256) for a degree-2')
    print('  Super-Space to catch. The physics exist, but require a deeper Taylor expansion.')
print('=' * 75 + '\n')
