import subprocess, sys

def ensure(p):
    try:
        __import__(p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
ensure('accelerate')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — ROPE NATURAL SPACE TEST')
print('  Apply RoPE rotation. Recover per_head law.')
print('=' * 62)
MODEL_NAME = 'EleutherAI/pythia-160m'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_hidden_layers
rope_base = getattr(model.config, 'rotary_emb_base', 10000)
print(f'  D={D}  Heads={n_heads}  Head_dim={head_dim}  Layers={n_layers}')
print(f'  RoPE base={rope_base}')
rotary_ndims = getattr(model.gpt_neox.layers[0].attention, 'rotary_ndims', head_dim)
print(f'  Rotary dims per head={rotary_ndims}')

def apply_rope(x, seq_offset=0, base=10000):
    rd = rotary_ndims
    half = rd // 2
    CTX_ = x.shape[0]
    theta = 1.0 / base ** (np.arange(half, dtype=np.float32) * 2 / rd)
    pos = np.arange(seq_offset, seq_offset + CTX_, dtype=np.float32)
    freqs = np.outer(pos, theta)
    cos_t = np.cos(freqs)
    sin_t = np.sin(freqs)
    x_out = x.copy()
    x1 = x[:, :half]
    x2 = x[:, half:rd]
    x_out[:, :half] = x1 * cos_t - x2 * sin_t
    x_out[:, half:rd] = x1 * sin_t + x2 * cos_t
    return x_out

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2_np(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2_tok(X, Y):
    n = len(X)
    s = int(n * 0.8)
    Xf = X.astype(np.float32)
    Yf = Y.astype(np.float32)
    Xb = np.c_[Xf, np.ones(n, dtype=np.float32)]
    W = np.linalg.lstsq(Xb[:s], Yf[:s], rcond=None)[0]
    return r2_np(Xb[s:] @ W, Yf[s:])
CTX = 8
starts = ['Once upon a time', 'The scientist looked', 'In a distant future', 'The old library held', 'A young programmer', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed slowly', 'A dog sat quietly', 'She found the key', 'The storm was coming']
print(f'\n  Generating texts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.8, 1.0]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=25, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} texts.')
test_layers = [0, 2, 5, 8, 11]
print(f'\n  Testing layers: {test_layers}')
print(f"\n  {'Layer':<7} {'ph_noRoPE':<13} {'ph_RoPE':<13} {'ffn':<10} {'gap_closed?'}")
print('  ' + '─' * 60)
for layer_idx in test_layers:
    block = model.gpt_neox.layers[layer_idx]
    hd = head_dim
    qkv_w_raw = block.attention.query_key_value.weight.detach().float().numpy()
    qkv_b_raw = block.attention.query_key_value.bias
    Wq_h = [qkv_w_raw[h * 3 * hd:h * 3 * hd + hd, :] for h in range(n_heads)]
    Wk_h = [qkv_w_raw[h * 3 * hd + hd:h * 3 * hd + 2 * hd, :] for h in range(n_heads)]
    Wv_h = [qkv_w_raw[h * 3 * hd + 2 * hd:h * 3 * hd + 3 * hd, :] for h in range(n_heads)]
    if qkv_b_raw is not None:
        b_np = qkv_b_raw.detach().float().numpy()
        bq_h = [b_np[h * 3 * hd:h * 3 * hd + hd] for h in range(n_heads)]
        bk_h = [b_np[h * 3 * hd + hd:h * 3 * hd + 2 * hd] for h in range(n_heads)]
        bv_h = [b_np[h * 3 * hd + 2 * hd:h * 3 * hd + 3 * hd] for h in range(n_heads)]
    else:
        bq_h = bk_h = bv_h = [0] * n_heads
    captured = {}

    def hook_att(mod, inp, out):
        captured['att'] = out[0].detach().float()

    def hook_act(mod, inp, out):
        captured['act'] = out.detach().float()

    def hook_ffn(mod, inp, out):
        captured['ffn'] = out.detach().float()
    hk1 = block.attention.dense.register_forward_hook(hook_att)
    hk2 = block.mlp.act.register_forward_hook(hook_act)
    hk3 = block.mlp.dense_4h_to_h.register_forward_hook(hook_ffn)
    PH_raw = []
    PH_rot = []
    ATT = []
    FA = []
    FO = []
    with torch.no_grad():
        for text in all_texts:
            toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
            L = toks['input_ids'].shape[1]
            if L < CTX:
                continue
            out_m = model(**toks, output_hidden_states=True)
            hs = out_m.hidden_states
            att_full = captured['att'][0].detach().numpy()
            act_full = captured['act'][0].detach().numpy()
            ffn_full = captured['ffn'][0].detach().numpy()
            ln1_full = block.input_layernorm(hs[layer_idx][0]).detach().float().numpy()
            Qf = [ln1_full @ Wq_h[h].T + bq_h[h] for h in range(n_heads)]
            Kf = [ln1_full @ Wk_h[h].T + bk_h[h] for h in range(n_heads)]
            Vf = [ln1_full @ Wv_h[h].T + bv_h[h] for h in range(n_heads)]
            for start in range(L - CTX + 1):
                att_w = att_full[start:start + CTX]
                ph_raw = []
                ph_rot = []
                for h in range(n_heads):
                    Qh = Qf[h][start:start + CTX]
                    Kh = Kf[h][start:start + CTX]
                    Vh = Vf[h][start:start + CTX]
                    scr = Qh @ Kh.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    ah = softmax_np(scr + msk)
                    ph_raw.append(ah @ Vh)
                    Qh_r = apply_rope(Qh, seq_offset=start)
                    Kh_r = apply_rope(Kh, seq_offset=start)
                    scr_r = Qh_r @ Kh_r.T / np.sqrt(head_dim)
                    ah_r = softmax_np(scr_r + msk)
                    ph_rot.append(ah_r @ Vh)
                concat_raw = np.concatenate(ph_raw, axis=1)
                concat_rot = np.concatenate(ph_rot, axis=1)
                for t in range(CTX):
                    PH_raw.append(concat_raw[t])
                    PH_rot.append(concat_rot[t])
                    ATT.append(att_w[t])
                    FA.append(act_full[start + t])
                    FO.append(ffn_full[start + t])
    hk1.remove()
    hk2.remove()
    hk3.remove()
    PH_RAW = np.array(PH_raw, dtype=np.float32)
    PH_ROT = np.array(PH_rot, dtype=np.float32)
    ATT_A = np.array(ATT, dtype=np.float32)
    FA_A = np.array(FA, dtype=np.float32)
    FO_A = np.array(FO, dtype=np.float32)
    r_raw = fit_r2_tok(PH_RAW, ATT_A)
    r_rot = fit_r2_tok(PH_ROT, ATT_A)
    r_ffn = fit_r2_tok(FA_A, FO_A)
    closed = r_rot > 0.99
    mark = '✓ LAW HOLDS' if closed else '↑ IMPROVING' if r_rot > r_raw else '✗ STILL WRONG'

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {layer_idx:<7} {f(r_raw):<13} {f(r_rot):<13} {f(r_ffn):<10} {mark}')
print('\n' + '=' * 62)
print('  WHAT IS REVEALED')
print('=' * 62)
print(f"\n  IF ph_RoPE recovers to 0.99+:\n    RoPE = natural space for position-aware attention.\n    Same law as TinyStories. Different basis.\n    Universal principle confirmed:\n      Find the natural space (basis).\n      W is linear there.\n    RoPE models: natural space = rotated per-head.\n    Standard: natural space = unrotated per-head.\n    Same law. Architecture defines the basis.\n\n  IF ph_RoPE still negative:\n    RoPE alone not sufficient.\n    Something else in Pythia attention changes basis.\n    Could be: attention bias, ALiBi slopes,\n    or different head grouping.\n    New hidden law to find.\n\n  IF ffn drops at layers 8-15:\n    Middle-layer anomaly is real.\n    Not RoPE (FFN has no RoPE).\n    Could be: different activation scale at mid-depth,\n    or gradient flow artifact from training.\n    New hidden law candidate.\n\n  UNIVERSAL FORMULA HYPOTHESIS:\n    Every architecture has:\n      Attention natural space = per-head in architecture's basis.\n      FFN natural space = gated activation.\n      W linear in those spaces.\n    Basis changes. Law does not.\n    Testing more models confirms or refines.\n")
print('=' * 62 + '\n')
