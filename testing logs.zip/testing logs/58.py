import numpy as np
import torch
import torch.nn as nn
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def generate_patterns(n=2000):
    data = []
    for i in range(1, n):
        data.append(([i / 100], [(i + 1) / 100], 'additive'))
    for i in range(1, n):
        data.append(([i / 100], [i * 2 / 100], 'multiply2'))
    for i in range(1, 50):
        data.append(([i / 100], [i ** 2 / 100], 'square'))
    a, b = (1, 1)
    for _ in range(n):
        data.append(([a / 100], [(a + b) / 100], 'fibonacci'))
        a, b = (b, a + b)
        if a > 1000000.0:
            a, b = (1, 1)
    for i in range(1, n):
        data.append(([i / 100], [i % 7 / 10], 'mod7'))
    for i in range(1, 20):
        data.append(([i / 100], [2 ** i / 100], 'pow2'))
    for i in range(1, 50):
        data.append(([i / 100], [i * (i + 1) / 2 / 100], 'triangular'))
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
    for i in range(len(primes) - 1):
        data.append(([primes[i] / 100], [(primes[i + 1] - primes[i]) / 10], 'prime_gap'))
    np.random.shuffle(data)
    X = torch.tensor([d[0] for d in data], dtype=torch.float32)
    Y = torch.tensor([d[1] for d in data], dtype=torch.float32)
    return (X, Y)
X, Y = generate_patterns()
print(f'Patterns: {len(X)}')
split = int(len(X) * 0.8)
X_train, Y_train = (X[:split].to(device), Y[:split].to(device))
X_test, Y_test = (X[split:].to(device), Y[split:].to(device))

class FlatModel(nn.Module):

    def __init__(self, dim=256):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(1, dim), nn.ReLU(), nn.Linear(dim, dim), nn.ReLU(), nn.Linear(dim, 1))

    def forward(self, x):
        return self.net(x)

class StructuredModel(nn.Module):

    def __init__(self, dim=16):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(1, dim), nn.ReLU(), nn.Linear(dim, dim), nn.ReLU(), nn.Linear(dim, 1))
        self._structured_init()

    def _structured_init(self):
        dim = 16
        W = torch.zeros(dim, 1)
        b = torch.zeros(dim)
        relationships = [(1.0, 0.0), (2.0, 0.0), (3.0, 0.0), (0.5, 0.0), (1.0, 1.0), (1.0, -1.0), (1.0, 0.5), (4.0, 0.0), (1.0, 2.0), (2.0, 1.0), (0.1, 0.0), (10.0, 0.0), (1.0, -0.5), (3.0, 1.0), (0.5, 0.5), (2.0, -1.0)]
        for i, (w, b_val) in enumerate(relationships):
            W[i, 0] = w
            b[i] = b_val
        with torch.no_grad():
            self.net[0].weight.copy_(W)
            self.net[0].bias.copy_(b)

    def forward(self, x):
        return self.net(x)

def count_params(model):
    return sum((p.numel() for p in model.parameters()))

def train_model(model, label, epochs=200, lr=0.001):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    best_loss = 9999
    best_state = None
    for ep in range(1, epochs + 1):
        model.train()
        pred = model(X_train)
        loss = loss_fn(pred, Y_train)
        opt.zero_grad()
        loss.backward()
        opt.step()
        model.eval()
        with torch.no_grad():
            test_loss = loss_fn(model(X_test), Y_test).item()
        if test_loss < best_loss:
            best_loss = test_loss
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        if ep % 20 == 0:
            bar = '█' * int(max(0, 1 - best_loss) * 20)
            print(f'  {label}  ep{ep:>3}  test_loss={best_loss:.6f}  {bar}')
    model.load_state_dict(best_state)
    return best_loss
print(f"\n{'=' * 60}")
print(f'  MODEL A: 256-dim FLAT  (random init)')
print(f"{'=' * 60}")
model_A = FlatModel(dim=256).to(device)
print(f'  Params: {count_params(model_A):,}')
loss_A = train_model(model_A, 'FLAT-256', epochs=200)
print(f"\n{'=' * 60}")
print(f'  MODEL B: 16-dim STRUCTURED  (relationship init)')
print(f"{'=' * 60}")
model_B = StructuredModel(dim=16).to(device)
print(f'  Params: {count_params(model_B):,}')
loss_B = train_model(model_B, 'STRUCT-16', epochs=200)
print(f"\n{'=' * 60}")
print(f'  PATTERN ACCURACY TEST')
print(f"{'=' * 60}")
tests = [(5, 10, 'double:    5 → 10'), (3, 9, 'square:    3 → 9'), (8, 13, 'fibonacci: 8 → 13'), (10, 11, 'additive:  10 → 11'), (7, 1, 'mod7:      7 → 0'), (4, 16, 'square:    4 → 16'), (6, 12, 'double:    6 → 12'), (5, 25, 'square:    5 → 25')]
print(f"  {'Pattern':<25}  {'Target':>8}  {'Flat-256':>10}  {'Struct-16':>10}  Winner")
print(f"  {'─' * 65}")
wins_A = wins_B = 0
for inp, target, label in tests:
    x = torch.tensor([[inp / 100]], dtype=torch.float32).to(device)
    t = target / 100
    with torch.no_grad():
        pA = model_A(x).item()
        pB = model_B(x).item()
    errA = abs(pA - t)
    errB = abs(pB - t)
    winner = 'STRUCT-16 ✓' if errB < errA else 'FLAT-256'
    if errB < errA:
        wins_B += 1
    else:
        wins_A += 1
    print(f'  {label:<25}  {t:>8.4f}  {pA:>10.4f}  {pB:>10.4f}  {winner}')
print(f"\n{'=' * 60}")
print(f'  FINAL RESULT')
print(f"{'=' * 60}")
print(f'  Model A  FLAT-256    params={count_params(model_A):,}   loss={loss_A:.6f}')
print(f'  Model B  STRUCT-16   params={count_params(model_B):,}    loss={loss_B:.6f}')
print(f'')
print(f'  Pattern wins — FLAT-256  : {wins_A}')
print(f'  Pattern wins — STRUCT-16 : {wins_B}')
print(f'')
if loss_B < loss_A:
    print(f'  ✓ STRUCTURE BEATS SIZE')
    print(f'  16-dim structured < 256-dim flat')
    print(f'  Subconscious hypothesis SUPPORTED')
else:
    gap = loss_B - loss_A
    print(f'  Flat-256 wins by {gap:.6f}')
    print(f'  Structure needs refinement')
print(f"{'=' * 60}")
