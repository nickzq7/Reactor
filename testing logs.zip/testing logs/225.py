import numpy as np
import math
print('\n' + '=' * 70)
print('  W — UNIVERSAL NATURAL SPACE: BEYOND TRANSFORMERS')
print('  ReLU, tanh, sigmoid, ELU — what is their natural space?')
print('=' * 70)

def relu(x):
    return np.maximum(0, x)

def tanh(x):
    return np.tanh(x.astype(np.float64))

def sigmoid(x):
    return 1 / (1 + np.exp(-x.astype(np.float64)))

def silu(x):
    return x * sigmoid(x)

def gelu(x):
    x = x.astype(np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def elu(x, alpha=1.0):
    x = x.astype(np.float64)
    return np.where(x > 0, x, alpha * (np.exp(x) - 1))

def leaky_relu(x, alpha=0.01):
    return np.where(x > 0, x, alpha * x).astype(np.float64)

def swish(x):
    return x * sigmoid(x)

def mish(x):
    x = x.astype(np.float64)
    return x * np.tanh(np.log(1 + np.exp(x)))

def r2_poly(x_flat, y_flat, degree):
    x = x_flat.astype(np.float64).reshape(-1, 1)
    y = y_flat.astype(np.float64).reshape(-1)
    basis = np.hstack([x ** k for k in range(1, degree + 1)])
    Ab = np.hstack([basis, np.ones((len(x), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, y, rcond=None)
    yp = Ab @ W
    ss_res = np.sum((y - yp) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    if ss_tot < 1e-15:
        return 1.0
    return float(1 - ss_res / ss_tot)

def find_natural_degree(name, fn, x_samples, max_deg=8, threshold=0.9999):
    y_samples = fn(x_samples)
    results = []
    nat_deg = None
    for deg in range(1, max_deg + 1):
        score = r2_poly(x_samples, y_samples, deg)
        results.append((deg, score))
        if score >= threshold and nat_deg is None:
            nat_deg = deg
    return (results, nat_deg, y_samples)

def fmt(v):
    if v > 0.9999:
        return f'{v:.6f} ✓'
    if v > 0.999:
        return f'{v:.6f} ~'
    if v > 0.99:
        return f'{v:.6f} !'
    return f'{v:.6f} ✗'
N = 50000
np.random.seed(42)
x_standard = np.random.normal(0, 1, N).astype(np.float64)
x_wide = np.random.normal(0, 3, N).astype(np.float64)
x_realistic = np.random.normal(0, 0.5, N).astype(np.float64)
print(f'\n  N={N} samples per test. Three distributions:')
print(f'  standard:  N(0,1)')
print(f'  wide:      N(0,3)')
print(f'  realistic: N(0,0.5)  — typical FFN pre-activation scale\n')
print(f"{'=' * 70}")
print(f'  POLYNOMIAL NATURAL SPACE — MINIMUM DEGREE FOR R²≥0.9999')
print(f"{'=' * 70}\n")
activations = [('ReLU', relu, 'max(0,x)'), ('LeakyReLU', leaky_relu, 'x if x>0 else 0.01x'), ('ELU', elu, 'x if x>0 else e^x-1'), ('Sigmoid', sigmoid, '1/(1+e^-x)'), ('Tanh', tanh, 'tanh(x)'), ('GeLU', gelu, 'x·Φ(x)  [proven deg-2]'), ('SiLU/Swish', silu, 'x·σ(x)  [proven deg-2]'), ('Mish', mish, 'x·tanh(softplus(x))')]
print(f"  {'Activation':<14} {'Formula':<28} {'Deg1':>8} {'Deg2':>8} {'Deg3':>8} {'Deg4':>8} {'Natural':>8}")
print(f"  {'─' * 78}")
all_results = {}
for name, fn, formula in activations:
    row_d = []
    nat_deg = None
    for dist_name, x in [('realistic', x_realistic)]:
        try:
            results, nd, _ = find_natural_degree(name, fn, x, max_deg=8)
            row_d = results
            nat_deg = nd
        except Exception as e:
            row_d = [(d, 0.0) for d in range(1, 5)]
            nat_deg = None
    scores = {d: s for d, s in row_d}
    nd_str = f'deg-{nat_deg}' if nat_deg else '>8'
    print(f'  {name:<14} {formula:<28} {fmt(scores.get(1, 0)):>14} {fmt(scores.get(2, 0)):>14} {fmt(scores.get(3, 0)):>14} {fmt(scores.get(4, 0)):>14} {nd_str:>8}')
    all_results[name] = (nat_deg, scores)
print(f"\n{'=' * 70}")
print(f'  ALGEBRAIC ANALYSIS — WHY EACH DEGREE')
print(f"{'=' * 70}\n")
print('\n  ReLU = max(0,x):\n    Positive region: f(x) = x   = linear (degree 1)\n    Negative region: f(x) = 0   = linear (degree 1)\n    Piecewise linear → degree 1 in each region.\n    GLOBALLY: degree 1 (already linear, no transform needed).\n    BUT: the boundary at x=0 = the only nonlinear point.\n    In sign(x) coordinates: ReLU = linear everywhere.\n    Natural space = (x, sign(x)) or equivalently just x in each region.\n\n  ELU/LeakyReLU = piecewise:\n    Same as ReLU: piecewise linear.\n    Degree 1 in each region.\n    Natural space = piecewise linear = already linear.\n\n  Sigmoid = 1/(1+e^-x):\n    σ(x) = e^x / (1+e^x)\n    In exponential space: e = exp(x)\n    σ = e/(1+e) = linear in e, divided by (1+e).\n    NOT a simple linear in exp space.\n    BUT: σ(x) = 1 - σ(-x) = antisymmetric.\n    Polynomial: σ(x) ≈ 0.5 + 0.25x - x³/48 + ...\n    Degree 3 in standard polynomial? Or degree 2?\n    Data will tell.\n\n  Tanh = 2σ(2x) - 1:\n    Same structure as sigmoid, scaled.\n    tanh(x) = (e^x - e^-x)/(e^x + e^-x)\n    In hyperbolic coordinates: already linear.\n    Polynomial: tanh(x) ≈ x - x³/3 + ...\n    Odd function: only odd powers. Degree 1, 3, 5...\n    Degree 3 needed? Data will tell.\n\n  GeLU = x·Φ(x):\n    Φ(x) = CDF ≈ a + bx (smooth, monotone)\n    GeLU ≈ ax + bx²  → degree 2.\n    PROVEN by data. ✓\n\n  SiLU = x·σ(x):\n    σ(x) ≈ a + bx (sigmoid is smooth, monotone)\n    SiLU ≈ ax + bx²  → degree 2.\n    PROVEN by data. ✓\n\n  Mish = x·tanh(softplus(x)):\n    More complex gating. tanh·softplus may need degree 3.\n    Data will tell.\n')
print(f"{'=' * 70}")
print(f'  DISTRIBUTION SENSITIVITY TEST')
print(f'  Does natural degree change with input scale?')
print(f"{'=' * 70}\n")
print(f"  {'Activation':<14} {'N(0,0.5)':>12} {'N(0,1)':>12} {'N(0,3)':>12} {'N(0,10)':>12}")
print(f"  {'─' * 56}")
x_narrow = np.random.normal(0, 0.2, N)
x_very_wide = np.random.normal(0, 10, N)
for name, fn, _ in activations[:6]:
    row = []
    for x in [x_realistic, x_standard, x_wide, x_very_wide]:
        try:
            _, nd, _ = find_natural_degree(name, fn, x, max_deg=8)
            row.append(f'deg-{nd}' if nd else '>8')
        except:
            row.append('err')
    print(f'  {name:<14} {row[0]:>12} {row[1]:>12} {row[2]:>12} {row[3]:>12}')
print(f"\n{'=' * 70}")
print(f'  COMPOSITION TEST')
print(f'  If GeLU = degree-2, what is GeLU(GeLU(x))?')
print(f'  If natural spaces compose: degree 2×2 = degree 4?')
print(f"{'=' * 70}\n")
x = x_realistic
for name1, fn1 in [('GeLU', gelu), ('SiLU', silu), ('tanh', tanh)]:
    composed = lambda x: fn1(fn1(x))
    results, nd, _ = find_natural_degree(f'{name1}({name1}(x))', composed, x, max_deg=8)
    scores = {d: s for d, s in results}
    print(f"  {name1}({name1}(x)):  d1={fmt(scores[1])}  d2={fmt(scores[2])}  d4={fmt(scores[4])}  natural=deg-{(nd if nd else '>8')}")
print(f"\n{'=' * 70}")
print(f'  W PRINCIPLE — UNIVERSAL CLASSIFICATION')
print(f"{'=' * 70}\n")
print(f'\n  CLASS 1 — Already linear (degree 1):\n    ReLU, LeakyReLU, ELU (in each linear region)\n    Natural space = x itself.\n    These are piecewise linear. No transform needed.\n    \n  CLASS 2 — Parabolic natural space (degree 2):\n    GeLU = x·Φ(x)    → (x, x²)\n    SiLU = x·σ(x)    → (x, x²)\n    Swish = x·σ(βx)  → (x, x²)\n    All gating functions f(x) = x·g(x) where g is smooth:\n    g(x) ≈ a + bx → f = ax + bx²\n    Universal: any smooth gate → degree-2 natural space.\n    \n  CLASS 3 — Higher polynomial space:\n    tanh, sigmoid: odd/even symmetry → needs odd/even degrees\n    tanh: only odd powers → degree 3 minimum?\n    sigmoid: asymptotes → degree 3?\n    Data answers this.\n    \n  CLASS ? — Softmax:\n    Not polynomial. Exponential family.\n    Natural space = exp(s) → NOT polynomial.\n    Different class entirely.\n    \n  W PRINCIPLE TAXONOMY:\n    f(x) = x·g(x):      natural space = (x, x²)    [degree 2]\n    f(x) = piecewise:   natural space = x           [degree 1]\n    f(x) = exp family:  natural space = exp coords  [exponential]\n    f(x) = odd fn:      natural space = (x, x³, x⁵) [odd polynomial]\n    \n  Everything linear in its natural space.\n  The space determines the degree.\n  The structure of the function = the structure of its natural space.\n  Nothing is nonlinear. Only coordinates differ.\n')
print('=' * 70 + '\n')
