import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — ARITHMETIC CHECK')
print('  att + ffn MUST = delta. Find where it breaks.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
CTX = 16

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0
sentence = 'Once upon a time there was a little girl named Lily who loved to play'
tokens = tokenizer(sentence, return_tensors='pt')
print(f"\n  Sentence: '{sentence}'")
print(f"  Tokens: {tokens['input_ids'].shape[1]}")
print('\n' + '─' * 62)
print('  EXACT ARITHMETIC VERIFICATION')
print('  For each layer: does att + ffn = delta exactly?')
print('─' * 62)
print()
with torch.no_grad():
    out = model(**tokens, output_hidden_states=True)
    hs = out.hidden_states
    print(f"  {'Layer':<6} {'att+ffn=delta?':<16} {'max_err':<12} {'att_norm':<12} {'ffn_norm':<12} {'delta_norm'}")
    print('  ' + '─' * 70)
    for layer_idx in range(n_layers):
        block = model.transformer.h[layer_idx]
        x_t = hs[layer_idx][0]
        y_t = hs[layer_idx + 1][0]
        delta = (y_t - x_t).numpy()
        ln1_out = block.ln_1(x_t)
        att_out = block.attn(ln1_out.unsqueeze(0))[0].squeeze(0).numpy()
        x2 = x_t + torch.tensor(att_out, dtype=torch.float32)
        ln2_out = block.ln_2(x2)
        pre = block.mlp.c_fc(ln2_out).numpy()
        act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
        ffn_out = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).numpy()
        delta_recon = att_out + ffn_out
        error = np.abs(delta - delta_recon).max()
        att_norm = np.linalg.norm(att_out)
        ffn_norm = np.linalg.norm(ffn_out)
        delta_norm = np.linalg.norm(delta)
        exact = '✓ EXACT' if error < 0.0001 else f'✗ ERR={error:.4f}'
        print(f'  {layer_idx:<6} {exact:<16} {error:<12.6f} {att_norm:<12.3f} {ffn_norm:<12.3f} {delta_norm:.3f}')
print('\n' + '─' * 62)
print('  BLOCK FORWARD VS MANUAL EXTRACTION')
print('  Do they give same att and ffn?')
print('─' * 62)
print()
with torch.no_grad():
    out = model(**tokens, output_hidden_states=True)
    hs = out.hidden_states
    for layer_idx in [0, 1, 6, 7]:
        block = model.transformer.h[layer_idx]
        x_t = hs[layer_idx][0]
        ln1 = block.ln_1(x_t)
        att = block.attn(ln1.unsqueeze(0))[0].squeeze(0).numpy()
        x2 = x_t.numpy() + att
        ln2 = block.ln_2(torch.tensor(x2, dtype=torch.float32)).numpy()
        pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
        act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
        ffn = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).numpy()
        delta_true = (hs[layer_idx + 1][0] - x_t).numpy()
        delta_ours = att + ffn
        error_max = np.abs(delta_true - delta_ours).max()
        error_mean = np.abs(delta_true - delta_ours).mean()
        att_n = np.linalg.norm(att)
        ffn_n = np.linalg.norm(ffn)
        dt_n = np.linalg.norm(delta_true)
        print(f'  Layer {layer_idx}:')
        print(f'    max error  = {error_max:.8f}')
        print(f'    mean error = {error_mean:.8f}')
        print(f'    |att|={att_n:.3f}  |ffn|={ffn_n:.3f}  |delta|={dt_n:.3f}')
        match = '✓ MATCHES' if error_max < 0.0001 else '✗ MISMATCH'
        print(f'    Result: {match}')
        print()
print('\n' + '─' * 62)
print('  DIAGNOSIS: where does mismatch occur?')
print('─' * 62)
print()
with torch.no_grad():
    out = model(**tokens, output_hidden_states=True)
    hs = out.hidden_states
    for layer_idx in [6, 7]:
        print(f'  Layer {layer_idx} step-by-step:')
        block = model.transformer.h[layer_idx]
        x_t = hs[layer_idx][0]
        delta_t = (hs[layer_idx + 1][0] - x_t).numpy()
        ln1 = block.ln_1(x_t)
        print(f'    ln1(x): mean={ln1.mean():.4f} std={ln1.std():.4f}')
        att = block.attn(ln1.unsqueeze(0))[0].squeeze(0)
        print(f'    att:    mean={att.mean():.4f} std={att.std():.4f} norm={att.norm():.3f}')
        x2 = x_t + att
        print(f'    x+att:  mean={x2.mean():.4f} std={x2.std():.4f}')
        ln2 = block.ln_2(x2)
        print(f'    ln2:    mean={ln2.mean():.4f} std={ln2.std():.4f}')
        pre = block.mlp.c_fc(ln2)
        act = block.mlp.act(pre)
        ffn = block.mlp.c_proj(act)
        print(f'    ffn:    mean={ffn.mean():.4f} std={ffn.std():.4f} norm={ffn.norm():.3f}')
        delta_recon = (att + ffn).numpy()
        err = np.abs(delta_t - delta_recon).max()
        print(f'    delta_true norm={np.linalg.norm(delta_t):.3f}')
        print(f'    att+ffn   norm={np.linalg.norm(delta_recon):.3f}')
        print(f'    max error = {err:.8f}')
        print(f"    {('✓ EXACT' if err < 0.0001 else '✗ MISMATCH — cause found')}")
        print()
print('=' * 62)
print('  CONCLUSION')
print('=' * 62)
print('\n  If all layers show EXACT match:\n    Previous R²=0.72 was underdetermined.\n    Not enough samples for layer 7.\n    Arithmetic is correct. Sampling was wrong.\n\n  If layers 6-7 show MISMATCH:\n    Our extraction code has a bug at depth.\n    Likely cause: dtype conversion or\n    residual connection computed differently.\n    Fix the extraction. Then retest laws.\n\n  Clean measurement is the foundation.\n  All law-finding depends on it.\n  W cannot find the natural space\n  if the measurement of the space is wrong.\n')
print('=' * 62 + '\n')
