import numpy as np
import json
import math
print('\n' + '=' * 70)
print('  W-HASH STEP 3b — KERNEL v2 + W-HASH')
print('  Fix: LN uses exact params. W matrices via lstsq.')
print('=' * 70)
W_npz = np.load('tiny_transformer_weights.npz')
with open('tiny_transformer_meta.json') as f:
    meta = json.load(f)
w2i = meta['w2i']
i2w = {int(k): v for k, v in meta['i2w'].items()}
VS, D, H = (meta['VS'], meta['D'], meta['H'])
NL, K, FFN = (meta['NL'], meta['K'], meta['FFN'])
TEXT = meta['text']
hd = D // H
print(f'\n  VS={VS} D={D} H={H} NL={NL} K={K} FFN={FFN}')
WTE = W_npz['WTE'].astype(np.float64)
WPE = W_npz['WPE'].astype(np.float64)
LNfg = W_npz['LNfg'].astype(np.float64)
LNfb = W_npz['LNfb'].astype(np.float64)
TL = []
for l in range(NL):
    TL.append({k: W_npz[f'{k}{l}'].astype(np.float64) for k in ['WQ', 'WK', 'WV', 'WO', 'W1', 'b1', 'W2', 'b2', 'LN1g', 'LN1b', 'LN2g', 'LN2b']})

def ln(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=True):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    W, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)
    return W

def r2(p, t):
    ss = np.mean((p.ravel() - t.ravel()) ** 2)
    sv = np.var(t.ravel())
    return float(1 - ss / sv) if sv > 1e-12 else 1.0
words = TEXT.split()
toks = [w2i[w] for w in words]
M = len(toks) - K
X_ids = np.array([toks[i:i + K] for i in range(M)])
y_ids = np.array([toks[i + 1:i + K + 1] for i in range(M)])
print('\n  Collecting transformer activations (exact h_in storage)...')
store = {l: {k: [] for k in ['h_in', 'ln1_out', 'Q', 'K', 'V', 'ctx', 'att_out', 'h_mid', 'ln2_out', 'pre_gelu', 'pre_gelu_ns', 'gelu_out', 'ffn_out']} for l in range(NL)}
s_lnf_in = []
s_lnf_out = []
s_lmh_out = []

def forward_collect(seq):
    slen = len(seq)
    x = WTE[seq] + WPE[np.arange(slen)]
    for l in range(NL):
        lw = TL[l]
        store[l]['h_in'].append(x.copy())
        ln1 = ln(x, lw['LN1g'], lw['LN1b'])
        store[l]['ln1_out'].append(ln1)
        Q = ln1 @ lw['WQ'].T
        K_ = ln1 @ lw['WK'].T
        V = ln1 @ lw['WV'].T
        store[l]['Q'].append(Q)
        store[l]['K'].append(K_)
        store[l]['V'].append(V)
        Q_h = Q.reshape(slen, H, hd).transpose(1, 0, 2)
        K_h = K_.reshape(slen, H, hd).transpose(1, 0, 2)
        V_h = V.reshape(slen, H, hd).transpose(1, 0, 2)
        sc = 1 / math.sqrt(hd)
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            p = softmax(Q_h[h] @ K_h[h].T * sc + mk)
            heads.append(p @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(slen, D)
        att = ctx @ lw['WO'].T
        store[l]['ctx'].append(ctx)
        store[l]['att_out'].append(att)
        hm = x + att
        store[l]['h_mid'].append(hm)
        ln2 = ln(hm, lw['LN2g'], lw['LN2b'])
        store[l]['ln2_out'].append(ln2)
        pre = ln2 @ lw['W1'].T + lw['b1']
        pns = np.c_[pre, pre ** 2]
        gout = gelu(pre)
        fout = gout @ lw['W2'].T + lw['b2']
        store[l]['pre_gelu'].append(pre)
        store[l]['pre_gelu_ns'].append(pns)
        store[l]['gelu_out'].append(gout)
        store[l]['ffn_out'].append(fout)
        x = hm + fout
    s_lnf_in.append(x.copy())
    lf = ln(x, LNfg, LNfb)
    s_lnf_out.append(lf)
    lg = lf @ WTE.T
    s_lmh_out.append(lg)
    return lg
correct_t = 0
for i in range(M):
    lg = forward_collect(X_ids[i].tolist())
    correct_t += int((np.argmax(lg, -1) == y_ids[i]).sum())
acc_t = 100 * correct_t / (M * K)
print(f'  Transformer accuracy: {acc_t:.1f}%')
cat = lambda l: np.concatenate(l, axis=0)
for l in range(NL):
    for k in store[l]:
        store[l][k] = cat(store[l][k])
lnf_in = cat(s_lnf_in)
lnf_out = cat(s_lnf_out)
lmh_out = cat(s_lmh_out)
N = len(store[0]['h_in'])
print(f'  Samples: {N}')
print('\n' + '=' * 70)
print('  KERNEL TRAINING — O(1) Laws Only')
print('  LN: exact params  |  W matrices: lstsq')
print('=' * 70)
KL = []
for l in range(NL):
    s = store[l]
    lw = TL[l]
    print(f'\n  Layer {l}:')
    W_q = solve(s['ln1_out'], s['Q'], bias=False)
    W_k = solve(s['ln1_out'], s['K'], bias=False)
    W_v = solve(s['ln1_out'], s['V'], bias=False)
    rq = r2(s['ln1_out'] @ W_q, s['Q'])
    rk = r2(s['ln1_out'] @ W_k, s['K'])
    rv = r2(s['ln1_out'] @ W_v, s['V'])
    print(f'    WQ R²={rq:.6f}  WK R²={rk:.6f}  WV R²={rv:.6f}')
    W_o = solve(s['ctx'], s['att_out'], bias=False)
    ro = r2(s['ctx'] @ W_o, s['att_out'])
    print(f'    WO R²={ro:.6f}')
    W1 = solve(s['ln2_out'], s['pre_gelu'], bias=True)
    r1 = r2(np.c_[s['ln2_out'], np.ones(N)] @ W1, s['pre_gelu'])
    print(f'    W1 R²={r1:.6f}')
    W_g = solve(s['pre_gelu_ns'], s['gelu_out'], bias=False)
    rg = r2(s['pre_gelu_ns'] @ W_g, s['gelu_out'])
    print(f'    W_gelu R²={rg:.6f}  (natural space x,x²)')
    W2 = solve(s['gelu_out'], s['ffn_out'], bias=True)
    r2w = r2(np.c_[s['gelu_out'], np.ones(N)] @ W2, s['ffn_out'])
    print(f'    W2 R²={r2w:.6f}')
    KL.append({'W_q': W_q, 'W_k': W_k, 'W_v': W_v, 'W_o': W_o, 'W1': W1, 'W_g': W_g, 'W2': W2, 'LN1g': lw['LN1g'], 'LN1b': lw['LN1b'], 'LN2g': lw['LN2g'], 'LN2b': lw['LN2b']})
W_lmh = solve(lnf_out, lmh_out, bias=False)
rl = r2(lnf_out @ W_lmh, lmh_out)
print(f'\n  W_lmh R²={rl:.6f}')
K_global = {'W_lmh': W_lmh, 'LNfg': LNfg, 'LNfb': LNfb}

def kernel_forward(seq):
    slen = len(seq)
    x = WTE[seq] + WPE[np.arange(slen)]
    for l in range(NL):
        kw = KL[l]
        ln1 = ln(x, kw['LN1g'], kw['LN1b'])
        Q = ln1 @ kw['W_q']
        K_ = ln1 @ kw['W_k']
        V = ln1 @ kw['W_v']
        Q_h = Q.reshape(slen, H, hd).transpose(1, 0, 2)
        K_h = K_.reshape(slen, H, hd).transpose(1, 0, 2)
        V_h = V.reshape(slen, H, hd).transpose(1, 0, 2)
        sc = 1 / math.sqrt(hd)
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            p = softmax(Q_h[h] @ K_h[h].T * sc + mk)
            heads.append(p @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(slen, D)
        att = ctx @ kw['W_o']
        hm = x + att
        ln2 = ln(hm, kw['LN2g'], kw['LN2b'])
        pre = np.c_[ln2, np.ones(slen)] @ kw['W1']
        gout = gelu(pre)
        fout = np.c_[gout, np.ones(slen)] @ kw['W2']
        x = hm + fout
    lf = ln(x, K_global['LNfg'], K_global['LNfb'])
    return lf @ K_global['W_lmh']
correct_k = 0
for i in range(M):
    lg = kernel_forward(X_ids[i].tolist())
    correct_k += int((np.argmax(lg, -1) == y_ids[i]).sum())
acc_k = 100 * correct_k / (M * K)
print(f'\n  Transformer accuracy: {acc_t:.1f}%')
print(f'  Kernel accuracy:      {acc_k:.1f}%')
print(f'  Accuracy gap:         {acc_t - acc_k:.1f}%')
print('\n' + '=' * 70)
print('  W-HASH — GEOMETRIC FINGERPRINT')
print('  Transformer W matrices vs Kernel W matrices')
print('=' * 70)

def svd_hash(M2):
    M2 = np.array(M2, dtype=np.float64)
    if M2.ndim != 2:
        return None
    try:
        _, S, _ = np.linalg.svd(M2, full_matrices=False)
    except:
        return None
    s_n = S / (S[0] + 1e-12)
    return {'S': S, 'frob': float(np.linalg.norm(M2, 'fro')), 'nuclear': float(np.sum(S)), 'spectral': float(S[0]), 'eff_rank': float(np.exp(-np.sum(s_n * np.log(s_n + 1e-12)))), 'cond': float(S[0] / (S[-1] + 1e-12))}

def gap(hT, hK):
    n = min(len(hT['S']), len(hK['S']))
    sv_g = float(np.mean(np.abs(hT['S'][:n] - hK['S'][:n])))
    sv_r = sv_g / (float(np.mean(hT['S'][:n])) + 1e-12) * 100
    return {'sv_pct': sv_r, 'frob_T': hT['frob'], 'frob_K': hK['frob'], 'rank_T': hT['eff_rank'], 'rank_K': hK['eff_rank'], 'spec_T': hT['spectral'], 'spec_K': hK['spectral'], 'frob_diff': abs(hT['frob'] - hK['frob'])}
print(f"\n  {'L':<3}{'Matrix':<8}{'Frob_T':>8}{'Frob_K':>8}{'SV_gap%':>9}{'Rank_T':>9}{'Rank_K':>9}  Diagnosis")
print(f"  {'─' * 75}")
all_gaps = []
per_layer_gap = {l: [] for l in range(NL)}
for l in range(NL):
    lw = TL[l]
    kw = KL[l]
    pairs = [('WQ', lw['WQ'].T, kw['W_q']), ('WK', lw['WK'].T, kw['W_k']), ('WV', lw['WV'].T, kw['W_v']), ('WO', lw['WO'].T, kw['W_o']), ('W1', lw['W1'].T, kw['W1'][:-1]), ('W2', lw['W2'].T, kw['W2'][:-1])]
    for name, Wt, Wk in pairs:
        ht = svd_hash(Wt)
        hk = svd_hash(Wk)
        if not ht or not hk:
            continue
        g = gap(ht, hk)
        sv = g['sv_pct']
        all_gaps.append(sv)
        per_layer_gap[l].append(sv)
        if sv < 0.1:
            tag = '✓ EXACT'
        elif sv < 1.0:
            tag = '✓ NEAR EXACT'
        elif sv < 5.0:
            tag = '~ CLOSE'
        elif sv < 15.0:
            tag = '△ GAP'
        else:
            tag = '✗ DIVERGED'
        print(f"  L{l} {name:<8}{g['frob_T']:>8.3f}{g['frob_K']:>8.3f}{sv:>8.2f}%{g['rank_T']:>9.1f}{g['rank_K']:>9.1f}  {tag}")
print(f"  {'─' * 75}")
print(f'  Mean SV gap: {np.mean(all_gaps):.2f}%   Max: {np.max(all_gaps):.2f}%')
print(f'\n  LAYER GEOMETRIC DISTANCE')
print(f"  {'─' * 55}")
for l in range(NL):
    lw = TL[l]
    kw = KL[l]
    dq = np.linalg.norm(lw['WQ'].T - kw['W_q'], 'fro')
    dk = np.linalg.norm(lw['WK'].T - kw['W_k'], 'fro')
    dv = np.linalg.norm(lw['WV'].T - kw['W_v'], 'fro')
    do = np.linalg.norm(lw['WO'].T - kw['W_o'], 'fro')
    d1 = np.linalg.norm(lw['W1'].T - kw['W1'][:-1], 'fro')
    d2 = np.linalg.norm(lw['W2'].T - kw['W2'][:-1], 'fro')
    dt = dq + dk + dv + do + d1 + d2
    fn = sum((np.linalg.norm(lw[k], 'fro') for k in ['WQ', 'WK', 'WV', 'WO', 'W1', 'W2']))
    pct = 100 * dt / (fn + 1e-12)
    bar = '█' * int(pct / 2) + '░' * (30 - min(30, int(pct / 2)))
    print(f'  L{l}: |{bar}| {pct:.2f}% total gap')
    print(f'       WQ={dq:.4f} WK={dk:.4f} WV={dv:.4f} WO={do:.4f} W1={d1:.4f} W2={d2:.4f}')
print(f'\n  SINGULAR VALUE SPECTRUM — TOP 8')
print(f"  {'─' * 65}")
for l in range(NL):
    lw = TL[l]
    kw = KL[l]
    for nm, Wt, Wk in [('WQ', lw['WQ'].T, kw['W_q']), ('W1', lw['W1'].T, kw['W1'][:-1])]:
        _, St, _ = np.linalg.svd(Wt, full_matrices=False)
        _, Sk, _ = np.linalg.svd(Wk, full_matrices=False)
        n = min(8, len(St), len(Sk))
        g = St[:n] - Sk[:n]
        print(f'\n  L{l} {nm}:')
        print(f"    Transformer: {' '.join((f'{v:.4f}' for v in St[:n]))}")
        print(f"    Kernel:      {' '.join((f'{v:.4f}' for v in Sk[:n]))}")
        print(f"    Gap:         {' '.join((f'{v:+.4f}' for v in g))}")
        max_g = float(np.max(np.abs(g)))
        print(f"    Max gap: {max_g:.4f}  → {('✓ aligned' if max_g < 0.1 else '△ needs more data' if max_g < 1.0 else '✗ significant')}")
print('\n' + '=' * 70)
print('  FINAL VERDICT')
print('=' * 70)
print(f'\n  Transformer: {acc_t:.1f}%')
print(f'  Kernel:      {acc_k:.1f}%')
print(f'  Gap:         {acc_t - acc_k:.1f}%')
print(f'  Mean SV gap: {np.mean(all_gaps):.2f}%')
print(f'  Max SV gap:  {np.max(all_gaps):.2f}%')
acc_gap = acc_t - acc_k
if acc_gap < 2:
    diag_msg = '✓ Kernel = Transformer. Ready for 70B.'
elif acc_gap < 10:
    diag_msg = '~ Small gap. W matrices aligned. Need more diverse training data.'
elif acc_gap < 30:
    diag_msg = '△ Moderate gap. Check highest SV_gap% matrix above. That layer needs more data.'
else:
    diag_msg = '✗ Large gap. Root cause: kernel sees limited activation space.\n  Transformer backprop visited every possible token combination.\n  Kernel lstsq only sees what we fed it.\n  Fix: feed ALL possible token sequences to collection pass.\n  On 70B: this is not a problem — model already has full distribution.'
compress_msg = '✓ SV spectrum aligned. Safe to compress.' if np.mean(all_gaps) < 5 else '△ SV gap present. Understand gap before compressing.'
print(f'\n  DIAGNOSIS:\n  {diag_msg}\n\n  JPEG COMPRESSION READINESS:\n  {compress_msg}\n  \n  For 70B: feed real text corpus during collection pass.\n  Kernel will see full distribution → SV gap → 0.\n  Then SVD compress W matrices → JPEG quality slider.\n')
print('=' * 70 + '\n')
