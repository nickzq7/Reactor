import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL v7 — NATURAL COORDINATES PER LAYER')
print("  SVD discovers each layer's own space.")
print('  Universe has its own coordinates. So does each layer.')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\nout loud and ground twice as much flour that week to make up for\nthe time that had been lost without any extra charge to the bakers\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also very\ncurious which sometimes got him into trouble one spring morning\nriku went exploring while his mother was sleeping he found a path\nhe had never followed before and followed it until he reached a\nfarm with a red barn and a vegetable garden behind a low fence\nthe garden was full of green things and the smell of fresh earth\nriku squeezed under the fence and walked between the rows of\nvegetables sniffing everything he did not mean to do any harm\nhe was just curious but the farmer saw him from the window and\ncame out shouting riku ran as fast as he could back under the\nfence and all the way home where he lay panting under a bush\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet agreement between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was\na small room with a round window and inside the room there was\na wooden table with a candle and a book the book had no title\nbut when she opened it the pages were full of maps of places\nshe had never heard of she sat down and read for a long time\nand when she finally looked up the candle had burned low and\nthe light outside had turned to gold she closed the book and\nput it carefully under her arm and walked back through the door\nand down the hill and did not tell anyone what she had found\nthe small lighthouse on the eastern cliff had been dark for\nmany years until one autumn a young woman came to the town\nand asked if she could tend the light the people were pleased\nand gave her the keys and she climbed the long stairs to the\nlamp room and cleaned the great lens and filled it with oil\nthat night the light shone out across the water for the first\ntime in years and the fishing boats that had been waiting in\nthe dark found their way safely into the harbor\n'.strip()
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VS = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Vocab={VS}  Tokens={len(tokens)}')
D = 48
FFN_D = 96
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 3
SEQ_LEN = 24
LAM = 0.01
CLIP = 1.5
LR = 0.1
K_SVD = 32
print(f'  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}  SEQ={SEQ_LEN}')
print(f'  K_SVD={K_SVD} (natural coordinate dim per layer)')
rng = np.random.RandomState(0)
WTE = rng.randn(VS, D).astype(np.float64)
for i in range(VS):
    WTE[i] /= np.linalg.norm(WTE[i]) + 1e-08
WTE *= 0.5
WPE = rng.randn(SEQ_LEN + 2, D).astype(np.float64) * 0.04

def ortho(n, m, scale=0.07):
    A = rng.randn(max(n, m), max(n, m))
    Q, _ = np.linalg.qr(A)
    return Q[:n, :m].astype(np.float64) * scale

def init():
    w = {}
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1g{s}'] = np.ones(D)
        w[f'ln1b{s}'] = np.zeros(D)
        w[f'ln2g{s}'] = np.ones(D)
        w[f'ln2b{s}'] = np.zeros(D)
        w[f'Wq{s}'] = ortho(D, D)
        w[f'Wk{s}'] = ortho(D, D)
        w[f'Wv{s}'] = np.zeros((D, D))
        w[f'Wo{s}'] = np.zeros((D, D))
        w[f'bo{s}'] = np.zeros(D)
        w[f'W1{s}'] = ortho(FFN_D, D, 0.01)
        w[f'b1{s}'] = np.zeros(FFN_D)
        w[f'W2{s}'] = np.zeros((D, FFN_D))
        w[f'b2{s}'] = np.zeros(D)
        w[f'U_in{s}'] = np.eye(D, K_SVD)
        w[f'U_out{s}'] = np.eye(D, K_SVD)
    w['lfg'] = np.ones(D)
    w['lfb'] = np.zeros(D)
    return w

def lnorm(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def ridge(X, Y, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    try:
        W = np.linalg.solve(A, Xb.T @ Y)
    except:
        W, _, _, _ = np.linalg.lstsq(Xb, Y, rcond=None)
    return np.clip(W, -CLIP, CLIP)

def layer_fwd(x, li, w):
    T = len(x)
    s = str(li)
    h = np.array([lnorm(x[i], w[f'ln1g{s}'], w[f'ln1b{s}']) for i in range(T)])
    Q = h @ w[f'Wq{s}'].T
    K = h @ w[f'Wk{s}'].T
    V = h @ w[f'Wv{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    ctx = np.stack([probs[hd] @ Vh[hd] for hd in range(N_HEADS)], 1).reshape(T, D)
    xa = x + ctx @ w[f'Wo{s}'].T + w[f'bo{s}']
    xn = xa.copy()
    for t in range(T):
        h2 = lnorm(xa[t], w[f'ln2g{s}'], w[f'ln2b{s}'])
        xn[t] = xa[t] + gelu(h2 @ w[f'W1{s}'].T + w[f'b1{s}']) @ w[f'W2{s}'].T + w[f'b2{s}']
    return (xn, ctx, xa, h, probs)

def full_fwd(ids, w):
    T = len(ids)
    x = (WTE[ids] + WPE[:T]).copy()
    for li in range(N_LAYERS):
        x, _, _, _, _ = layer_fwd(x, li, w)
    xf = np.array([lnorm(x[t], w['lfg'], w['lfb']) for t in range(T)])
    return xf @ WTE.T

def calc_ppl(w, n=400):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        try:
            logits = full_fwd(ids, w)
            if not np.all(np.isfinite(logits[-1])):
                continue
            lg = logits[-1] - logits[-1].max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return 999.0
    return math.exp(min(nll / tok, 500))

def discover_natural_coords(w, n_samples=500):
    inputs = {li: [] for li in range(N_LAYERS)}
    outputs = {li: [] for li in range(N_LAYERS)}
    idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, n_samples, replace=False)
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
        for li in range(N_LAYERS):
            inputs[li].append(x[-1].copy())
            x, _, _, _, _ = layer_fwd(x, li, w)
            outputs[li].append(x[-1].copy())
    for li in range(N_LAYERS):
        s = str(li)
        X_in = np.array(inputs[li], dtype=np.float64)
        X_out = np.array(outputs[li], dtype=np.float64)
        X_in -= X_in.mean(0)
        X_out -= X_out.mean(0)
        try:
            _, _, Vt_in = np.linalg.svd(X_in, full_matrices=False)
            _, _, Vt_out = np.linalg.svd(X_out, full_matrices=False)
            w[f'U_in{s}'] = Vt_in[:K_SVD].T
            w[f'U_out{s}'] = Vt_out[:K_SVD].T
        except:
            pass
    return w

def collect_frozen(w, idxs):
    data = {li: {'x_in': [], 'ctx': [], 'xa': [], 'h': [], 'probs': [], 'h2': [], 'gl': [], 'residual': [], 'nxt': []} for li in range(N_LAYERS)}
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
        for li in range(N_LAYERS):
            x_in = x[-1].copy()
            residual = WTE[nxt] - x_in
            if not np.all(np.isfinite(x_in)):
                break
            if np.linalg.norm(residual) < 1e-08:
                break
            xn, ctx, xa, h_ln1, probs_h = layer_fwd(x, li, w)
            ctx_l = ctx[-1]
            xa_l = xa[-1]
            if not np.all(np.isfinite(ctx_l)):
                break
            if not np.all(np.isfinite(xa_l)):
                break
            s = str(li)
            h2 = lnorm(xa_l, w[f'ln2g{s}'], w[f'ln2b{s}'])
            pre = h2 @ w[f'W1{s}'].T + w[f'b1{s}']
            gl = gelu(pre)
            if not np.all(np.isfinite(gl)):
                break
            probs_last_avg = probs_h[:, -1, :].mean(0)
            weighted_ln1 = probs_last_avg @ h_ln1
            data[li]['x_in'].append(x_in)
            data[li]['ctx'].append(ctx_l)
            data[li]['xa'].append(xa_l)
            data[li]['h'].append(weighted_ln1)
            data[li]['h2'].append(h2)
            data[li]['gl'].append(gl)
            data[li]['residual'].append(residual)
            data[li]['nxt'].append(nxt)
            x = xn
    for li in range(N_LAYERS):
        for k in data[li]:
            if len(data[li][k]) > 0:
                data[li][k] = np.array(data[li][k], dtype=np.float64)
            else:
                data[li][k] = np.zeros((0, D))
    return data

def solve_in_natural_coords(li, w, data):
    s = str(li)
    N = len(data[li]['residual'])
    if N < 20:
        return w
    U_in = w[f'U_in{s}']
    U_out = w[f'U_out{s}']
    Residuals = data[li]['residual']
    X_ctx = data[li]['ctx']
    X_xa = data[li]['xa']
    X_h = data[li]['h']
    X_h2 = data[li]['h2']
    X_gl = data[li]['gl']
    R_nat = Residuals @ U_out
    R_att = R_nat * 0.5
    R_ffn = R_nat * 0.5
    X_h_nat = X_h @ U_in
    Wv_nat = ridge(X_h_nat, R_att, lam=LAM)
    Wv_new = U_in @ Wv_nat[:-1] @ U_out.T
    w[f'Wv{s}'] = np.clip((1 - LR) * w[f'Wv{s}'] + LR * Wv_new, -CLIP, CLIP)
    X_ctx_nat = X_ctx @ U_in
    Wo_nat = ridge(X_ctx_nat, R_att, lam=LAM)
    Wo_new = U_in @ Wo_nat[:-1] @ U_out.T
    w[f'Wo{s}'] = np.clip((1 - LR) * w[f'Wo{s}'] + LR * Wo_new, -CLIP, CLIP)
    w[f'bo{s}'] = np.clip((1 - LR) * w[f'bo{s}'] + LR * (U_out @ Wo_nat[-1]), -CLIP, CLIP)
    R_ffn_full = R_ffn @ U_out.T
    W2_nat = ridge(X_gl, R_ffn_full, lam=LAM)
    w[f'W2{s}'] = np.clip((1 - LR) * w[f'W2{s}'] + LR * W2_nat[:-1].T, -CLIP, CLIP)
    w[f'b2{s}'] = np.clip((1 - LR) * w[f'b2{s}'] + LR * W2_nat[-1], -CLIP, CLIP)
    X_h2_nat = X_h2 @ U_in
    Y_pre = R_ffn_full @ w[f'W2{s}']
    W1_nat = ridge(X_h2_nat, Y_pre, lam=LAM)
    W1_new = U_in @ W1_nat[:-1]
    w[f'W1{s}'] = np.clip((1 - LR) * w[f'W1{s}'] + LR * W1_new.T, -CLIP, CLIP)
    w[f'b1{s}'] = np.clip((1 - LR) * w[f'b1{s}'] + LR * W1_nat[-1], -CLIP, CLIP)
    return w

def measure_residuals(w):
    idx = len(tokens) // 3
    ids = tokens[idx:idx + SEQ_LEN]
    nxt = tokens[idx + SEQ_LEN]
    x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
    norms = [np.linalg.norm(WTE[nxt] - x[-1])]
    for li in range(N_LAYERS):
        x, _, _, _, _ = layer_fwd(x, li, w)
        if np.all(np.isfinite(x[-1])):
            norms.append(np.linalg.norm(WTE[nxt] - x[-1]))
        else:
            norms.append(999.0)
    return norms
w = init()
p0 = calc_ppl(w)
print(f'\n  Random ppl = {p0:.2f}  (vocab={VS})\n')
BATCH = 400
ROUNDS = 50
SVD_INTERVAL = 5
best_ppl = p0
best_w = {k: v.copy() for k, v in w.items()}
hist = [p0]
t0 = time.time()
print(f"  {'Rnd':<5} {'PPL':>8} {'Best':>8}  {'Residuals →':>35}  {'Note'}")
print(f"  {'─' * 72}")
for rnd in range(ROUNDS):
    if rnd % SVD_INTERVAL == 0:
        w = discover_natural_coords(w, n_samples=600)
        note = '[SVD coords updated]'
    else:
        note = ''
    idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
    data = collect_frozen(w, idxs)
    for li in range(N_LAYERS):
        w = solve_in_natural_coords(li, w, data)
    p = calc_ppl(w)
    hist.append(p)
    norms = measure_residuals(w)
    mark = ''
    if np.isfinite(p) and p < best_ppl:
        best_ppl = p
        best_w = {k: v.copy() for k, v in w.items()}
        mark = ' ★'
    arr = '↓' if p < hist[-2] else '↑'
    rstr = ' → '.join((f'{n:.3f}' for n in norms))
    print(f'  {rnd + 1:<5} {p:>8.2f} {best_ppl:>8.2f}  [{rstr}]  {arr}{mark} {note}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  FINAL EVALUATION')
print(f"{'=' * 70}\n")
print(f'  Start  : {p0:.2f}')
print(f'  Best   : {best_ppl:.2f}')
print(f'  Vocab  : {VS}')
print(f'  Ratio  : {best_ppl / VS:.4f}')
print(f'  Reduce : {(1 - best_ppl / p0) * 100:.1f}%\n')
nf = measure_residuals(w)
print(f'  Final residuals:')
labels = ['embed'] + [f'L{i}' for i in range(N_LAYERS)]
for i in range(len(nf) - 1):
    red = nf[i] - nf[i + 1]
    pct = 100 * red / nf[i] if nf[i] > 0 else 0
    sign = '✓' if red > 0 else '✗'
    print(f'    {labels[i]}→{labels[i + 1]}: {nf[i]:.4f}→{nf[i + 1]:.4f}  reduced={red:.4f} ({pct:.1f}%)  {sign}')
print(f'\n  GENERATION:\n')
for gp in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    ids_g = [vocab[c] for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(120):
        lg = full_fwd(gen[-SEQ_LEN:], w)
        if not np.all(np.isfinite(lg[-1])):
            break
        gen.append(int(np.argmax(lg[-1])))
    out = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  '{gp}'")
    print(f'  → {out[len(gp):][:70]}')
    print()
print(f"{'=' * 70}")
print(f'  THE UNIVERSE INSIGHT:')
print(f"\n  Star from distance  = nonlinear (5 sharp points).\n  Star with telescope = linear (sphere).\n  Instrument = coordinate transformation.\n  \n  Layer activations in wrong space = exploding residuals.\n  Layer activations in SVD space   = stable, shrinking.\n  SVD = the telescope for neural network layers.\n  \n  Manish Principle: nothing is nonlinear.\n  Only the coordinate system is incomplete.\n  \n  Applied to training:\n    Find natural coords (SVD) → solve (W-Kernel) → repeat.\n    No gradient. No backprop. No learning rate schedule.\n    Each step: exact. Each layer: its own universe.\n    \n  ppl = {best_ppl:.2f}  vocab = {VS}\n  Ratio = {best_ppl / VS:.4f}  ({('SEQUENCE LEARNING' if best_ppl < VS * 0.5 else 'BELOW VOCAB' if best_ppl < VS else 'PARTIAL')})\n")
print(f'  Time: {time.time() - t0:.0f}s')
print('=' * 70 + '\n')
