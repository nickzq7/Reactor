import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — GENERATION TEST')
print('  Fixing Model Collapse: Generating N > 3072 samples.')
print('  Extracting W. Then generating text using ONLY W.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
CTX = 8

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came', 'The dog ran fast', 'The children went to', 'It was a sunny', 'Deep in the woods', 'Every morning the bird', 'The brave knight rode', 'She found a lost', 'The baby bear found', 'A tiny seed grew', 'The two friends walked', 'A rainbow appeared', 'The kind queen shared', 'A yellow duck learned', 'The snow fell softly', 'He wished upon a', 'The cat chased the', 'The children found a', 'She drew a picture', 'The moon shone bright', 'A boy climbed the', 'He discovered a door', 'Three little bears came', 'The frog jumped across', 'A butterfly emerged', 'An owl sat watching', 'The kitten played with', 'A girl named Emma', 'The farmer woke up', 'A genie appeared to', 'The turtle and rabbit', 'She sang a song to', 'The brave little mouse', 'A young girl read', 'The old farmer fed', 'A baby elephant learned', 'The wolf huffed and']
print(f'\n  Generating texts to saturate the feature space (Target > 3072 samples)...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} stories. Caching hidden states...')
all_hs = []
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        if ids.shape[1] < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        all_hs.append((ids, out.hidden_states))
print(f'\n  Extracting W matrices for all {n_layers} layers...')
W_matrices = {}
with torch.no_grad():
    for layer_idx in range(n_layers):
        block = model.transformer.h[layer_idx]
        attn_mod = block.attn.attention
        Wq = attn_mod.q_proj.weight.detach().numpy().T
        Wk = attn_mod.k_proj.weight.detach().numpy().T
        Wv = attn_mod.v_proj.weight.detach().numpy().T
        X_rules_list = []
        Y_delta_list = []
        for ids, hs in all_hs:
            L = ids.shape[1]
            for start in range(L - CTX + 1):
                x_t = hs[layer_idx][0, start:start + CTX]
                x_np = x_t.numpy()
                y_np = hs[layer_idx + 1][0, start:start + CTX].numpy()
                delta = y_np - x_np
                ln1 = block.ln_1(x_t).numpy()
                Q_full = ln1 @ Wq
                K_full = ln1 @ Wk
                V_full = ln1 @ Wv
                head_feats = []
                for h in range(n_heads):
                    s_h, e_h = (h * head_dim, (h + 1) * head_dim)
                    Q_h, K_h, V_h = (Q_full[:, s_h:e_h], K_full[:, s_h:e_h], V_full[:, s_h:e_h])
                    scr = Q_h @ K_h.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    att_h = softmax(scr + msk)
                    head_feats.append((att_h @ V_h).flatten())
                per_head = np.concatenate(head_feats)
                att_out = block.attn(block.ln_1(x_t).unsqueeze(0))[0].squeeze(0).numpy()
                x2 = x_np + att_out
                ln2 = block.ln_2(torch.tensor(x2, dtype=torch.float32)).numpy()
                pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
                ind = (pre > 0).astype(float)
                rule_feats = np.concatenate([x_np.flatten(), per_head, (pre * ind).flatten()])
                X_rules_list.append(rule_feats)
                Y_delta_list.append(delta.flatten())
        X_arr = np.array(X_rules_list)
        Y_arr = np.array(Y_delta_list)
        W = np.linalg.lstsq(X_arr, Y_arr, rcond=None)[0]
        W_matrices[layer_idx] = W
        ratio = len(X_arr) / 3072
        mark = '✓ SAFE' if ratio > 1.0 else '✗ UNDERDETERMINED'
        print(f'    Layer {layer_idx} W extracted | Samples: {len(X_arr)} | Features: 3072 | Ratio: {ratio:.1f}x ({mark})')
print('\n' + '─' * 62)
print('  GENERATION LOOP (W-DRIVEN)')
print('─' * 62)
prompt = 'Once upon a time, a little girl named'
print(f"\n  Prompt: '{prompt}'")
input_ids = tokenizer.encode(prompt, return_tensors='pt')
generated_tokens = input_ids[0].tolist()
tokens_to_generate = 20
print(f'  Generating {tokens_to_generate} tokens...\n')
print(f'  {prompt}', end=' ', flush=True)
with torch.no_grad():
    for step in range(tokens_to_generate):
        current_ids = torch.tensor([generated_tokens[-CTX:]])
        if current_ids.shape[1] < CTX:
            pad_len = CTX - current_ids.shape[1]
            pad = torch.full((1, pad_len), tokenizer.eos_token_id)
            current_ids = torch.cat([pad, current_ids], dim=1)
        h = model.transformer.wte(current_ids) + model.transformer.wpe(torch.arange(0, CTX).unsqueeze(0))
        h_np = h[0].numpy()
        for layer_idx in range(n_layers):
            block = model.transformer.h[layer_idx]
            Wq = block.attn.attention.q_proj.weight.detach().numpy().T
            Wk = block.attn.attention.k_proj.weight.detach().numpy().T
            Wv = block.attn.attention.v_proj.weight.detach().numpy().T
            ln1 = block.ln_1(torch.tensor(h_np, dtype=torch.float32)).numpy()
            Q_full = ln1 @ Wq
            K_full = ln1 @ Wk
            V_full = ln1 @ Wv
            head_feats = []
            for h_id in range(n_heads):
                s_h, e_h = (h_id * head_dim, (h_id + 1) * head_dim)
                Q_h, K_h, V_h = (Q_full[:, s_h:e_h], K_full[:, s_h:e_h], V_full[:, s_h:e_h])
                scr = Q_h @ K_h.T / np.sqrt(head_dim)
                msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                att_h = softmax(scr + msk)
                head_feats.append((att_h @ V_h).flatten())
            per_head = np.concatenate(head_feats)
            att_out = block.attn(torch.tensor(ln1, dtype=torch.float32).unsqueeze(0))[0].squeeze(0).numpy()
            x2 = h_np + att_out
            ln2 = block.ln_2(torch.tensor(x2, dtype=torch.float32)).numpy()
            pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
            ind = (pre > 0).astype(float)
            rule_feats = np.concatenate([h_np.flatten(), per_head, (pre * ind).flatten()])
            delta_pred = (rule_feats @ W_matrices[layer_idx]).reshape(CTX, D)
            h_np = h_np + delta_pred
        h_final = torch.tensor(h_np, dtype=torch.float32)
        h_norm = model.transformer.ln_f(h_final)
        logits = model.lm_head(h_norm)
        next_token_logit = logits[-1, :]
        next_token_id = torch.argmax(next_token_logit).item()
        generated_tokens.append(next_token_id)
        word = tokenizer.decode([next_token_id])
        print(word, end='', flush=True)
print('\n\n' + '=' * 62)
print('  IF THIS READS AS ENGLISH: W IS PROVEN.')
print('=' * 62 + '\n')
