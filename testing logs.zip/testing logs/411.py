import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'HuggingFaceTB/SmolLM-135M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_layers = len(model.model.layers)
print(f'D={D}  Layers={n_layers}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2(X, Y, split=0.8):
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X.astype(np.float32), np.ones(n, np.float32)]
    W = np.linalg.lstsq(Xb[:s], Y[:s].astype(np.float32), rcond=None)[0]
    return r2(Xb[s:] @ W, Y[s:].astype(np.float32))

def x_normed(x_np):
    rms = np.sqrt(np.mean(x_np ** 2, axis=-1, keepdims=True) + 1e-06)
    return x_np / rms
seeds = ['Once upon a time', 'The scientist looked at', 'In a distant future', 'The old library held', 'A young programmer wrote', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed through', 'A dog sat quietly', 'She found the key', 'The storm was coming', 'The teacher explained how', 'A bird flew over', 'He picked up the phone', 'The car stopped suddenly']
print(f'Generating {len(seeds) * 5} texts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(5):
            torch.manual_seed(i * 50 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=35, do_sample=True, temperature=0.8 + j * 0.05, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(all_texts)} texts.')
test_layers = [0, 5, 14, 29]
store = {l: {'pre_in': [], 'pre_out': [], 'post_in': [], 'post_out': []} for l in test_layers}
final_store = {'in': [], 'out': []}
hooks = []
for li in test_layers:
    b = model.model.layers[li]

    def make(l):

        def h_pre_in(m, inp, out):
            for tok in inp[0][0].detach().float().numpy():
                store[l]['pre_in'].append(tok)

        def h_pre_out(m, inp, out):
            for tok in out[0].detach().float().numpy():
                store[l]['pre_out'].append(tok)

        def h_post_in(m, inp, out):
            for tok in inp[0][0].detach().float().numpy():
                store[l]['post_in'].append(tok)

        def h_post_out(m, inp, out):
            for tok in out[0].detach().float().numpy():
                store[l]['post_out'].append(tok)
        return (h_pre_in, h_pre_out, h_post_in, h_post_out)
    hi, ho, hpi, hpo = make(li)
    hooks += [b.input_layernorm.register_forward_hook(hi), b.input_layernorm.register_forward_hook(ho), b.post_attention_layernorm.register_forward_hook(hpi), b.post_attention_layernorm.register_forward_hook(hpo)]

def h_fn_in(m, inp, out):
    for tok in inp[0][0].detach().float().numpy():
        final_store['in'].append(tok)

def h_fn_out(m, inp, out):
    for tok in out[0].detach().float().numpy():
        final_store['out'].append(tok)
hooks += [model.model.norm.register_forward_hook(h_fn_in), model.model.norm.register_forward_hook(h_fn_out)]
print(f'Running {len(all_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(all_texts):
        if i % 25 == 0:
            print(f'  {i}/{len(all_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
print(f"\n{'=' * 68}")
print(f'  RMSNORM LAW — SmolLM-135M')
print(f"{'=' * 68}")
print(f'\n  input_layernorm (pre-attention):')
print(f"  {'Layer':<6} {'x→out':<12} {'x/RMS→out':<14} {'natural space'}")
print(f"  {'─' * 55}")
for li in test_layers:
    XI = np.array(store[li]['pre_in'], dtype=np.float32)
    XO = np.array(store[li]['pre_out'], dtype=np.float32)
    XN = x_normed(XI)
    r_raw = fit_r2(XI, XO)
    r_norm = fit_r2(XN, XO)
    if r_norm > 0.999:
        space = 'x/RMS(x)  ✓'
    elif r_raw > 0.999:
        space = 'x directly ✓'
    elif r_norm > r_raw:
        space = f'x/RMS better (+{r_norm - r_raw:.3f})'
    else:
        space = 'neither — find deeper'

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {li:<6} {f(r_raw):<12} {f(r_norm):<14} {space}')
print(f'\n  post_attention_layernorm (pre-FFN):')
print(f"  {'Layer':<6} {'x→out':<12} {'x/RMS→out':<14} {'natural space'}")
print(f"  {'─' * 55}")
for li in test_layers:
    XI = np.array(store[li]['post_in'], dtype=np.float32)
    XO = np.array(store[li]['post_out'], dtype=np.float32)
    XN = x_normed(XI)
    r_raw = fit_r2(XI, XO)
    r_norm = fit_r2(XN, XO)
    if r_norm > 0.999:
        space = 'x/RMS(x)  ✓'
    elif r_raw > 0.999:
        space = 'x directly ✓'
    elif r_norm > r_raw:
        space = f'x/RMS better (+{r_norm - r_raw:.3f})'
    else:
        space = 'neither'

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {li:<6} {f(r_raw):<12} {f(r_norm):<14} {space}')
FI = np.array(final_store['in'], dtype=np.float32)
FO = np.array(final_store['out'], dtype=np.float32)
FN = x_normed(FI)
r_raw = fit_r2(FI, FO)
r_norm = fit_r2(FN, FO)

def f(v):
    return '✓1.000' if v > 0.999 else f'{v:.4f}'
print(f'\n  model.norm (final):')
print(f'  x→out={f(r_raw)}  x/RMS→out={f(r_norm)}')
print(f"\n{'=' * 68}")
print(f'\n  WHAT THIS MEANS:\n\n  IF x/RMS(x) → out = 1.000:\n    RMSNorm natural space = x/RMS(x).\n    Same as LayerNorm but without mean subtraction.\n    Law: normalized_x → normed_out is linear.\n    W principle holds for RMSNorm.\n\n  IF x → out = 1.000 directly:\n    Even simpler. Raw x is the natural space.\n    RMSNorm = pure linear map from x.\n\n  COMPARISON WITH LAYERNORM:\n    LayerNorm natural space: (x-mean)/std\n    RMSNorm natural space:   x/RMS(x)  (hypothesis)\n    Both = normalize → apply gamma.\n    Same principle. Different normalization formula.\n\n  AFTER THIS TEST:\n    All laws confirmed.\n    RMSNorm = last piece.\n    Then: KERNEL ATTEMPT.\n    Input embedding → output. One pass. Instant.\n')
print('=' * 68 + '\n')
