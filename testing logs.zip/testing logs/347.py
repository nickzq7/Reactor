import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 75)
print('  W — LAYER-BY-LAYER O(1) TRAINING')
print('  Building the network one mathematically perfect layer at a time.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
print('\n  [ Phase 1 ] Extracting Physical States for all Layers...')
prompts = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon lived', 'A small dog ran across the green field', 'When the sun came up in the morning the birds', 'She smiled and said to her mother I love', 'The brave knight took his shiny sword and', 'A little boy found a magic wand inside', 'High up in the clouds there was a', 'The cat jumped over the fence and saw', 'A wise old owl sat in the tree']
all_hidden_states = {l: [] for l in range(n_layers + 1)}
with torch.no_grad():
    for s in prompts:
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(hash(s) % 10000 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out_gen = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            seq_ids = out_gen[0]
            out = model(seq_ids.unsqueeze(0), output_hidden_states=True)
            for l in range(n_layers + 1):
                all_hidden_states[l].append(out.hidden_states[l].squeeze(0).cpu().numpy())
for l in range(n_layers + 1):
    all_hidden_states[l] = np.concatenate(all_hidden_states[l], axis=0)
N_samples = len(all_hidden_states[0])
print(f'  ✓ Extracted {N_samples} tokens across all layers.')
print('\n  [ Phase 2 ] Solving W_layer matrices (O(1) Training)...')

def get_running_mean(x_list):
    ctx_list = []
    idx = 0
    for s in prompts:
        for temp in [0.7, 0.9, 1.1]:
            pass
    cumsum = np.cumsum(x_list, axis=0)
    counts = np.arange(1, x_list.shape[0] + 1)[:, None]
    return cumsum / counts
print('\n' + '=' * 75)
print(f"  {'Layer':<8} | {'Super-Space Dims':<18} | {'R² Collapse Score':<20} | {'Time (s)'}")
print('=' * 75)
total_train_time = 0
for l in range(n_layers):
    start_time = time.time()
    X = all_hidden_states[l]
    Y = all_hidden_states[l + 1]
    X_ctx = get_running_mean(X)
    Phi_X = np.hstack([X, X ** 2, X_ctx, X_ctx ** 2, X * X_ctx])
    Phi_X = np.hstack([Phi_X, np.ones((Phi_X.shape[0], 1))])
    W_layer, residuals, rank, s = np.linalg.lstsq(Phi_X, Y, rcond=None)
    Y_pred = Phi_X @ W_layer
    ss_res = np.sum((Y - Y_pred) ** 2)
    ss_tot = np.sum((Y - np.mean(Y, axis=0)) ** 2)
    r2_score = 1 - ss_res / ss_tot
    layer_time = time.time() - start_time
    total_train_time += layer_time
    print(f'  Layer {l:<2} | {Phi_X.shape[1]:<18} | {r2_score:<20.4f} | {layer_time:.4f}s')
print('=' * 75)
print(f'  Total Network Training Time: {total_train_time:.4f}s')
print('=' * 75)
print('\n  WHAT THIS MEANS:')
print('  We are testing how well a SINGLE W-Matrix can perfectly replace')
print("  an entire layer's Attention and FFN mechanisms when lifted into")
print('  the natural coordinate space.')
print('  If R² is high (>0.90), you can train this model locally layer-by-layer')
print('  in seconds, entirely bypassing backpropagation and gradient descent.\n')
