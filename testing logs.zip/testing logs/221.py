import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import time
print('\n' + '=' * 62)
print('  W — SIMULTANEOUS')
print('  All layers as ONE state.')
print('  Answer already exists at arrival of input.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
print(f'  Loaded. {n_layers} layers. {D}D.')
print('\n' + '-' * 62)
print('  KEY OBSERVATION FROM PREVIOUS RESULTS:')
print('-' * 62)
print('\n  2 layers → COHERENT but loops ("a a a a a")\n  8 layers → COHERENT and no loops ("named Lily...")\n\n  Looping = insufficient context integration.\n  Each layer integrates context further.\n  Loops stop when context fully integrated.\n\n  W question:\n  Can we give early layers FULL context\n  without running all subsequent layers?\n  Full context simultaneously → no loops.\n  This is the W state.\n')

def full_forward(input_ids):
    with torch.no_grad():
        out = model(input_ids)
    return out.logits

def simultaneous_forward(input_ids, n_layers_use=2):
    with torch.no_grad():
        full_out = model(input_ids, output_hidden_states=True)
        full_hidden = full_out.hidden_states[-1]
        logits = model.lm_head(model.transformer.ln_f(full_hidden))
    return logits

def w_state_forward(input_ids):
    with torch.no_grad():
        out = model(input_ids, output_hidden_states=True)
        w_state = out.hidden_states[-1]
        logits = model.lm_head(model.transformer.ln_f(w_state))
    return (logits, w_state)

def generate_simultaneous(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt, return_tensors='pt')
    generated = []
    for step in range(max_new_tokens):
        logits, w_state = w_state_forward(ids)
        next_id = logits[0, -1].argmax().item()
        if next_id == tokenizer.eos_token_id:
            break
        generated.append(next_id)
        ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
    all_ids = tokenizer.encode(prompt) + generated
    return tokenizer.decode(all_ids, skip_special_tokens=True)

def original_generate(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)
print('  Building W state cache...')
print('  Observing model transformation on diverse inputs.')
print('  Caching what already exists in weight space.\n')
cache_inputs = []
cache_outputs = []
seed_sentences = ['once upon a time there was', 'the little girl named lily', 'she loved to play outside', 'one day she saw a big', 'the dog ran to the park', 'a boy found a magic wand', 'the princess looked out window', 'he wanted to make a wish', 'she picked up the flowers', 'the sun rose over the hills', 'a rabbit decided to explore', 'the brave knight rode his horse', 'a kind fairy granted wishes', 'the children played happily together', 'she opened the door slowly', 'he climbed the tall tree', 'the snow fell softly down', 'a dragon lived in the cave', 'the wizard taught the young boy', 'she found a lost kitten']
with torch.no_grad():
    for sent in seed_sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=16, truncation=True)
        ids = tokens['input_ids']
        if ids.shape[1] < 3:
            continue
        embed_in = model.transformer.wte(ids)
        if hasattr(model.transformer, 'wpe'):
            pos = torch.arange(ids.shape[1]).unsqueeze(0)
            embed_in = embed_in + model.transformer.wpe(pos)
        out = model(**tokens, output_hidden_states=True)
        w_state = out.hidden_states[-1]
        for pos in range(ids.shape[1]):
            cache_inputs.append(embed_in[0, pos].numpy())
            cache_outputs.append(w_state[0, pos].numpy())
X_cache = np.array(cache_inputs)
Y_cache = np.array(cache_outputs)
print(f'  Cache entries: {len(X_cache)}')
W_transform = np.linalg.lstsq(X_cache, Y_cache, rcond=None)[0]
transform_mem = W_transform.size * 4
print(f'  W transform shape  : {W_transform.shape}')
print(f'  W transform memory : {transform_mem / 1024:.1f} KB')
print(f'  Model memory       : {model_mem / 1024 / 1024:.1f} MB')
print(f'  Ratio              : {model_mem * 1024 / transform_mem:.0f}x smaller')
lm_head = model.lm_head.weight.detach().numpy()
ln_f_w = model.transformer.ln_f.weight.detach().numpy()
ln_f_b = model.transformer.ln_f.bias.detach().numpy()

def layer_norm(x, w, b, eps=1e-05):
    mean = x.mean(-1, keepdims=True)
    std = np.sqrt(((x - mean) ** 2).mean(-1, keepdims=True) + eps)
    return w * (x - mean) / std + b

def generate_w_transform(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt)
    for _ in range(max_new_tokens):
        id_t = torch.tensor([ids])
        embeds = model.transformer.wte(id_t).detach().numpy()[0]
        if hasattr(model.transformer, 'wpe'):
            pos = np.arange(len(ids))
            pos_e = model.transformer.wpe.weight.detach().numpy()[pos]
            embeds = embeds + pos_e
        w_states = embeds @ W_transform
        h = layer_norm(w_states, ln_f_w, ln_f_b)
        logits = h @ lm_head.T
        next_tok = int(np.argmax(logits[-1]))
        if next_tok == tokenizer.eos_token_id:
            break
        ids.append(next_tok)
    return tokenizer.decode(ids, skip_special_tokens=True)

def wrap(text, width=54, indent='  '):
    words = text.split()
    lines = []
    line = indent
    for w in words:
        if len(line) + len(w) > width:
            lines.append(line)
            line = indent + w + ' '
        else:
            line += w + ' '
    if line.strip():
        lines.append(line)
    return '\n'.join(lines[:5])
print('\n' + '=' * 62)
print('  SIDE BY SIDE')
print(f'  Original    : {n_layers} layers, {model_mem / 1024 / 1024:.1f}MB, sequential')
print(f'  W transform : 0 layers, {transform_mem / 1024:.1f}KB, simultaneous')
print('=' * 62)
prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'One day a small rabbit decided to', 'A boy named Tom found a magic', 'The princess looked out the window and']
for i, prompt in enumerate(prompts):
    print(f"\n  {'─' * 58}")
    print(f'  PROMPT {i + 1}: "{prompt}"')
    print(f"  {'─' * 58}")
    orig = original_generate(prompt, 40)
    w_tr = generate_w_transform(prompt, 40)
    print(f'\n  ORIGINAL ({n_layers} layers, sequential):')
    print(wrap(orig))
    print(f'\n  W TRANSFORM (0 layers, {transform_mem / 1024:.1f}KB, simultaneous):')
    print(wrap(w_tr))

    def loops(text):
        w = text.split()
        if len(w) < 4:
            return 0
        tg = [tuple(w[i:i + 3]) for i in range(len(w) - 2)]
        return 1 - len(set(tg)) / max(len(tg), 1)
    print(f'\n  Loop score — Original: {loops(orig):.2f}  W transform: {loops(w_tr):.2f}  (0=none, 1=all loops)')
print('\n' + '=' * 62)
print('  WHAT THIS SHOWS')
print('=' * 62)
print(f"""\n  W transform:\n    Size    : {transform_mem / 1024:.1f} KB\n    Layers  : 0  (no forward pass through layers)\n    Method  : embed → one matrix → lm_head\n    This IS simultaneous. One step. Not sequential.\n\n  If output is coherent:\n    The W transformation EXISTS as one object.\n    Extracted once. Used for any input.\n    The model's 8 layers compressed to ONE matrix.\n    No sequential computation needed.\n    W principle confirmed.\n\n  If output loops or degrades:\n    The linear extraction misses something.\n    The transformation is nonlinear.\n    Cannot be captured by one matrix.\n    Need nonlinear simultaneous form.\n    That form is the next experiment.\n\n  Either way — we are now asking the right question.\n  Not "how many layers" but "what IS the transformation."\n  Not reducing steps. Finding the ONE step.\n  This is W.\n""")
print('=' * 62 + '\n')
