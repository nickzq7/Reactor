import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
DIM = 16

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(1000)
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

def build_W(geo, out_dim, in_dim):
    if geo == 'flat':
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    elif geo == 'prime':
        arr = np.array(BEST_PRIMES[:out_dim], dtype=np.float32)
    elif geo == 'powers2':
        arr = np.array([2.0 ** i for i in range(out_dim)], dtype=np.float32)
    elif geo == 'uniform':
        arr = np.linspace(-1, 1, out_dim).astype(np.float32)
    elif geo == 'fibonacci':
        f = [1, 1]
        while len(f) < out_dim:
            f.append(f[-1] + f[-2])
        arr = np.array(f[:out_dim], dtype=np.float32)
    elif geo == 'log':
        arr = np.array([np.log(i + 2) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'sine':
        arr = np.array([np.sin(i * np.pi / out_dim) for i in range(out_dim)], dtype=np.float32)
    else:
        arr = np.zeros(out_dim, dtype=np.float32)
    arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
    arr = arr / (np.max(np.abs(arr)) + 1e-08)
    W = np.zeros((out_dim, in_dim), dtype=np.float32)
    for col in range(in_dim):
        W[:, col] = arr * (col + 1) / in_dim
    return W

def build_net(dim, geo_list):
    layers = []
    in_d = SEQ_LEN
    for geo in geo_list:
        lin = nn.Linear(in_d, dim)
        with torch.no_grad():
            lin.weight.copy_(torch.tensor(build_W(geo, dim, in_d)))
        layers += [lin, nn.Tanh()]
        in_d = dim
    layers.append(nn.Linear(dim, 1))

    class Net(nn.Module):

        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(*layers)

        def forward(self, x):
            return self.net(x)
    return Net()

def train_net(model, epochs=800, lr=0.003):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-05)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
    if best_st:
        model.load_state_dict(best_st)
    return best

def score_model(model):
    model.eval()
    correct = 0
    with torch.no_grad():
        for seq, true_next in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            pred = model(xt).item() * NORM
            if abs(pred - true_next) / NORM <= TOL:
                correct += 1
    return correct

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
print_sep('PART 3 — 10-LAYER GEOMETRY SEARCH')
hypotheses_10 = [('all flat + uniform end', ['flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'uniform']), ('flat×2, powers2×6, uniform×2', ['flat', 'flat', 'powers2', 'powers2', 'powers2', 'powers2', 'powers2', 'powers2', 'uniform', 'uniform']), ('graduated: fib→prime→powers2→uniform', ['fibonacci', 'fibonacci', 'prime', 'prime', 'powers2', 'powers2', 'powers2', 'log', 'uniform', 'uniform']), ('all flat baseline', ['flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat', 'flat']), ('alternating flat+powers2', ['flat', 'powers2', 'flat', 'powers2', 'flat', 'powers2', 'flat', 'powers2', 'flat', 'powers2']), ('pyramid: richer middle', ['flat', 'fibonacci', 'prime', 'powers2', 'powers2', 'powers2', 'powers2', 'log', 'uniform', 'uniform']), ('3-layer pattern ×3 + uniform', ['flat', 'flat', 'uniform', 'flat', 'flat', 'uniform', 'flat', 'flat', 'uniform', 'uniform']), ('seeing×2 + thinking×6 + deciding×2', ['flat', 'flat', 'powers2', 'powers2', 'powers2', 'powers2', 'powers2', 'powers2', 'uniform', 'uniform']), ('flat start, fibonacci middle, uniform end', ['flat', 'flat', 'fibonacci', 'fibonacci', 'fibonacci', 'fibonacci', 'fibonacci', 'fibonacci', 'uniform', 'uniform']), ('flat start, sine middle, uniform end', ['flat', 'flat', 'sine', 'sine', 'sine', 'sine', 'sine', 'sine', 'uniform', 'uniform'])]
for label, geos in hypotheses_10:
    assert len(geos) == 10, f"'{label}' has {len(geos)} layers"
print(f'\n  Testing {len(hypotheses_10)} hypotheses...\n')
results10 = []
for label, geos in hypotheses_10:
    np.random.seed(42)
    m = build_net(DIM, geos).to(device)
    l = train_net(m, epochs=1000, lr=0.003)
    s = score_model(m)
    results10.append((s, l, label, geos))
    del m
    torch.cuda.empty_cache()
    print(f'  {s:>2}/{len(TESTS)}  loss={l:>10.4f}  {label}')
results10.sort(key=lambda x: (-x[0], x[1]))
print(f'\n  TOP 5 — 10-LAYER:')
print(f"  {'#':>3}  {'Score':>7}  {'Loss':>10}  Label")
print(f"  {'─' * 65}")
for rank, (s, l, label, geos) in enumerate(results10[:5]):
    print(f'  {rank + 1:>3}  {s:>4}/{len(TESTS)}  {l:>10.4f}  {label}')
    print(f"       {' → '.join(geos)}\n")
print_sep('PART 4 — PRINCIPLE CHECK ACROSS DEPTHS (3,5,7,10 layers)')
print(f'  For each depth: principled vs all-flat\n')
print(f"  {'Depth':>7}  {'Principled':>12}  {'All-flat':>10}  Winner")
print(f"  {'─' * 50}")
depth_results = []
for n in [3, 5, 7, 10]:
    principled = ['flat'] * (n - 1) + ['uniform']
    flat_all = ['flat'] * n
    np.random.seed(42)
    m_p = build_net(DIM, principled).to(device)
    l_p = train_net(m_p, epochs=800, lr=0.003)
    s_p = score_model(m_p)
    del m_p
    torch.cuda.empty_cache()
    np.random.seed(42)
    m_f = build_net(DIM, flat_all).to(device)
    l_f = train_net(m_f, epochs=800, lr=0.003)
    s_f = score_model(m_f)
    del m_f
    torch.cuda.empty_cache()
    depth_results.append((n, s_p, l_p, s_f, l_f))
    winner = 'PRINCIPLED ✓' if s_p > s_f else 'TIE' if s_p == s_f else 'FLAT'
    print(f'  {n:>7}  {s_p:>5}/{len(TESTS)}       {s_f:>4}/{len(TESTS)}     {winner}')
print_sep('FINAL SUMMARY')
print(f"\n  KNOWN (from Parts 1+2):\n    3-layer: flat → flat → uniform  best pattern\n    Layer 2 in 5-layer: flat wins avg=16.37\n    Layer 3 in 5-layer: uniform wins avg=14.65\n\n  10-LAYER WINNER:\n    {results10[0][2]}\n    {' → '.join(results10[0][3])}\n    Score: {results10[0][0]}/{len(TESTS)}\n\n  PRINCIPLE ACROSS DEPTHS:\n    flat(all layers except last) + uniform(last layer)\n    Depth   Principled   Flat       Winner")
for n, s_p, l_p, s_f, l_f in depth_results:
    w = 'PRINCIPLED' if s_p > s_f else 'TIE' if s_p == s_f else 'FLAT'
    print(f'    {n:>5}   {s_p:>4}/{len(TESTS)}       {s_f:>4}/{len(TESTS)}     {w}')
print(f'\n  CONCLUSION:\n    The deciding layer (last) = uniform geometry\n    All middle layers = flat (freedom to adapt)\n    First layer = flat (no bias at input)\n\n    The only fixed structure needed = UNIFORM at output\n    Everything else = freedom\n\n    This means:\n    Intelligence = freedom everywhere + structure at decision point\n    Like subconscious: thinks freely, decides with balance\n')
