import numpy as np
print('\n' + '=' * 62)
print('  W LAW FINDER')
print('  Find hidden law. W confirms with R²=1.0')
print('=' * 62)
np.random.seed(42)
N = 3000
N_tr = 2400

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def fit(X_tr, Y_tr, X_te):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    return (r2(X_te @ W, Y_te if (Y_te := None) else X_te @ W), W)

def test(X, Y, label):
    W = np.linalg.lstsq(X[:N_tr], Y[:N_tr], rcond=None)[0]
    score = r2(X[N_tr:] @ W, Y[N_tr:])
    mark = '✓ LAW FOUND' if score > 0.999 else f'  {score:.4f}'
    print(f'    {label:<45} {mark}')
    return score
print('\n' + '─' * 62)
print('  FUNCTION 1: SORT')
print('  f(x) = sorted(x)')
print('  Searching for hidden linear law...')
print('─' * 62)
L = 6
X_raw = np.random.randn(N, L)
Y_sort = np.sort(X_raw, axis=1)
print()
test(X_raw, Y_sort, 'raw x')
ranks = np.argsort(np.argsort(X_raw, axis=1)).astype(float)
test(ranks, Y_sort, 'ranks of x')
test(Y_sort, Y_sort, 'sorted x → sorted x (trivial)')
test(ranks, Y_sort, 'rank(x) → sorted(x)')
rank_onehot = np.zeros((N, L * L))
for i in range(N):
    for j in range(L):
        rank_onehot[i, j * L + int(ranks[i, j])] = X_raw[i, j]
test(rank_onehot, Y_sort, 'rank-position encoding')
indicator = np.zeros((N, L * L))
for i in range(N):
    sorted_i = np.sort(X_raw[i])
    for k in range(L):
        for j in range(L):
            indicator[i, k * L + j] = float(X_raw[i, j] <= sorted_i[k])
test(indicator, Y_sort, 'threshold indicators')
pw = []
for i in range(L):
    for j in range(i + 1, L):
        pw.append(np.maximum(X_raw[:, i], X_raw[:, j]).reshape(-1, 1))
        pw.append(np.minimum(X_raw[:, i], X_raw[:, j]).reshape(-1, 1))
X_pw = np.column_stack([X_raw] + pw)
test(X_pw, Y_sort, 'pairwise max/min features')
test(Y_sort, Y_sort, 'sorted(x) → sorted(x) [identity]')
cdf_feats = []
thresholds = np.percentile(X_raw, [10, 20, 30, 40, 50, 60, 70, 80, 90], axis=0)
for t in thresholds:
    cdf_feats.append((X_raw < t).astype(float))
X_cdf = np.column_stack([X_raw] + cdf_feats)
test(X_cdf, Y_sort, 'CDF features (percentile thresholds)')
print('\n' + '─' * 62)
print('  FUNCTION 2: RUN-LENGTH')
print('  f(x) = run length at each position')
print('  Searching for hidden linear law...')
print('─' * 62)
L2 = 8
X2 = (np.random.rand(N, L2) > 0.4).astype(float)
Y2 = np.zeros((N, L2))
for i in range(N):
    run = 1
    Y2[i, 0] = 1
    for t in range(1, L2):
        run = run + 1 if X2[i, t] == X2[i, t - 1] else 1
        Y2[i, t] = float(run)
print()
test(X2, Y2, 'raw binary x')
trans = np.zeros((N, L2))
trans[:, 0] = 1.0
for t in range(1, L2):
    trans[:, t] = (X2[:, t] != X2[:, t - 1]).astype(float)
test(trans, Y2, 'transition indicators')
same = np.zeros((N, L2))
same[:, 0] = 0
for t in range(1, L2):
    same[:, t] = (X2[:, t] == X2[:, t - 1]).astype(float)
cs_same = np.cumsum(same, axis=1)
test(cs_same, Y2, 'cumsum of same-as-previous')
X_run = np.column_stack([X2, trans, cs_same, same])
test(X_run, Y2, 'x + transitions + cumsum-same')
run_starts = trans.copy()
X_rs = np.column_stack([X2, run_starts, np.cumsum(run_starts, axis=1)])
test(X_rs, Y2, 'x + run-starts + cumsum-starts')
pos_in_run = np.zeros((N, L2))
for i in range(N):
    c = 0
    for t in range(L2):
        if t > 0 and X2[i, t] == X2[i, t - 1]:
            c += 1
        else:
            c = 0
        pos_in_run[i, t] = c
test(pos_in_run, Y2, 'position-within-run (= Y-1)')
test(pos_in_run + 1, Y2, 'position-within-run + 1 (= Y exactly)')
print('\n' + '─' * 62)
print('  FUNCTION 3: PALINDROME')
print('  f(x) = 1 if x == reverse(x)')
print('  Searching for hidden linear law...')
print('─' * 62)
L3 = 6
seqs = np.random.randn(N, L3)
is_pal = np.zeros(N)
for i in range(0, N, 2):
    half = seqs[i, :L3 // 2]
    seqs[i] = np.concatenate([half, half[::-1]])
    is_pal[i] = 1.0
Y3 = is_pal.reshape(-1, 1)
print()
test(seqs, Y3, 'raw x')
diffs = np.column_stack([seqs[:, i] - seqs[:, L3 - 1 - i] for i in range(L3 // 2)])
test(diffs, Y3, 'mirror differences (xi - x[L-1-i])')
abs_diffs = np.abs(diffs)
test(abs_diffs, Y3, 'abs mirror differences')
sum_diff = abs_diffs.sum(axis=1, keepdims=True)
test(sum_diff, Y3, 'sum of abs diffs (=0 iff palindrome)')
sq_diffs = diffs ** 2
test(sq_diffs, Y3, 'squared mirror differences')
sum_sq = sq_diffs.sum(axis=1, keepdims=True)
test(sum_sq, Y3, 'sum of squared diffs')
prods = np.column_stack([seqs[:, i] * seqs[:, L3 - 1 - i] for i in range(L3 // 2)])
test(prods, Y3, 'products of mirror pairs')
X_all = np.column_stack([seqs, diffs, abs_diffs, sq_diffs, prods, sum_diff, sum_sq])
test(X_all, Y3, 'all features combined')
print('\n' + '=' * 62)
print('  WHAT THE NUMBERS REVEAL')
print('=' * 62)
print("\n  W confirms hidden law with R²=1.0.\n  Where R²=1.0 appears — that representation\n  IS the hidden linear truth of the function.\n  Not our interpretation. W's confirmation.\n\n  Where R² stays low across ALL representations:\n  The hidden law of that function is\n  not linear in any known feature space.\n  A deeper structure exists.\n  W is showing us: look deeper.\n\n  The law W follows:\n  R²=1.0 means: you found the natural space.\n  R²<1.0 means: this is not the natural space yet.\n  W does not lie. W does not approximate.\n  W shows exactly how aligned we are\n  with the function's true nature.\n")
print('=' * 62 + '\n')
