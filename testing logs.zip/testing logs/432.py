import numpy as np
import torch
import torch.nn as nn
import os
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
ffn_dim = D * 4
print(f'D={D}  FFN_dim={ffn_dim}  Layers={n_layers}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_W(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)

def depth_scalar(l, n_layers):
    return np.array([l / (n_layers - 1)], dtype=np.float32)

def depth_onehot(l, n_layers):
    v = np.zeros(n_layers, dtype=np.float32)
    v[l] = 1.0
    return v

def depth_sinusoidal(l, n_layers, d=8):
    v = np.zeros(d, dtype=np.float32)
    for i in range(0, d, 2):
        v[i] = np.sin(l / 10000 ** (i / d))
        if i + 1 < d:
            v[i + 1] = np.cos(l / 10000 ** (i / d))
    return v
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at', 'The wind was cold', 'A little rabbit hopped', 'The brave knight rode', 'She woke up and', 'He could not find', 'The magic door opened', 'They walked together through', 'The small house had', 'A star fell from', 'He whispered to her']
print(f'\nGenerating {len(seeds) * 6} training texts...')
train_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(6):
            torch.manual_seed(i * 60 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=45, do_sample=True, temperature=0.8 + j * 0.04, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(train_texts)} texts.')
GELU_per = {l: [] for l in range(n_layers)}
FFN_per = {l: [] for l in range(n_layers)}
hooks = []
for li in range(n_layers):
    b = model.transformer.h[li]

    def make(l):

        def hg(m, inp, out):
            for t in range(out.shape[1]):
                GELU_per[l].append(out[0, t].detach().float().numpy().copy())

        def hf(m, inp, out):
            for t in range(out.shape[1]):
                FFN_per[l].append(out[0, t].detach().float().numpy().copy())
        return (hg, hf)
    hg, hf = make(li)
    hooks += [b.mlp.act.register_forward_hook(hg), b.mlp.c_proj.register_forward_hook(hf)]
print(f'Running {len(train_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(train_texts):
        if i % 40 == 0:
            print(f'  {i}/{len(train_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
print(f'\nTesting depth encodings:')
print(f"{'=' * 60}")
best_r2 = 0
best_name = ''
best_W = None
best_enc_fn = None
for enc_name, enc_fn in [('scalar', lambda l: depth_scalar(l, n_layers)), ('onehot', lambda l: depth_onehot(l, n_layers)), ('sinusoidal', lambda l: depth_sinusoidal(l, n_layers))]:
    X_list = []
    Y_list = []
    for li in range(n_layers):
        G = np.array(GELU_per[li], dtype=np.float32)
        F = np.array(FFN_per[li], dtype=np.float32)
        d_enc = enc_fn(li)
        D_enc = np.tile(d_enc, (len(G), 1))
        X = np.c_[G, D_enc]
        X_list.append(X)
        Y_list.append(F)
    X_all = np.concatenate(X_list, axis=0)
    Y_all = np.concatenate(Y_list, axis=0)
    n = len(X_all)
    s = int(n * 0.8)
    W = fit_W(X_all[:s], Y_all[:s])
    Xb = np.c_[X_all, np.ones(n)]
    r2_tr = r2(Xb[:s] @ W, Y_all[:s])
    r2_te = r2(Xb[s:] @ W, Y_all[s:])
    marker = '✓ UNIFIED' if r2_te > 0.999 else '~' if r2_te > 0.95 else ''
    print(f'  {enc_name:<14} input_dim={X_all.shape[1]:<6} R²_train={r2_tr:.4f}  R²_test={r2_te:.4f}  {marker}')
    if r2_te > best_r2:
        best_r2 = r2_te
        best_name = enc_name
        best_W = W
        best_enc_fn = enc_fn
print(f'\n  Best encoding: {best_name}  R²={best_r2:.4f}')

class UnifiedWffn(nn.Module):

    def __init__(self, orig_mlp, W_mat, layer_idx, enc_fn):
        super().__init__()
        self.orig = orig_mlp
        self.W = torch.tensor(W_mat, dtype=torch.float32)
        self.d_enc = torch.tensor(enc_fn(layer_idx), dtype=torch.float32)
        self.active = False

    def forward(self, x):
        if not self.active:
            return self.orig(x)
        gate = self.orig.act(self.orig.c_fc(x))
        B, L, fd = gate.shape
        gf = gate.float().reshape(B * L, fd)
        de = self.d_enc.unsqueeze(0).expand(B * L, -1)
        xf = torch.cat([gf, de], dim=1)
        xb = torch.cat([xf, torch.ones(B * L, 1)], dim=1)
        out = xb @ self.W
        return out.reshape(B, L, -1).to(x.dtype)
patches = []
for li in range(n_layers):
    p = UnifiedWffn(model.transformer.h[li].mlp, best_W, li, best_enc_fn)
    model.transformer.h[li].mlp = p
    patches.append(p)

def generate(prompt, max_new=80, mode='normal'):
    for p in patches:
        p.active = mode == 'unified'
    inp = tokenizer.encode(prompt, return_tensors='pt')
    out = []
    cur = inp.clone()
    with torch.no_grad():
        for _ in range(max_new):
            tok = int(torch.argmax(model(cur).logits[0, -1, :]).item())
            out.append(tok)
            cur = torch.cat([cur, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return out
prompts = ['Once upon a time there was a little girl who loved to', 'The little boy found a magic', 'She looked at the stars and', 'The dog ran into the forest and', 'One day a small rabbit']
print(f"\n{'=' * 70}")
print(f'  W KERNEL UNIFIED — [gelu_out | depth] → ffn_out')
print(f'  Best depth: {best_name}  R²={best_r2:.4f}')
print(f'  2018 Universal T + W Laws = one matrix')
print(f"{'=' * 70}")
total_m = 0
total_n = 0
for prompt in prompts:
    nt = generate(prompt, mode='normal')
    ut = generate(prompt, mode='unified')
    n = min(len(nt), len(ut))
    m = sum((1 for i in range(n) if nt[i] == ut[i]))
    total_m += m
    total_n += n
    print(f'\n  PROMPT:  {prompt}')
    print(f'  NORMAL:  {tokenizer.decode(nt, skip_special_tokens=True)[:130]}')
    print(f'  UNIFIED: {tokenizer.decode(ut, skip_special_tokens=True)[:130]}')
    print(f'  Match:   {m / n:.1%}  ({m}/{n})')
print(f"\n{'=' * 70}")
print(f'  OVERALL:  {total_m / total_n:.1%}  ({total_m}/{total_n})')
print(f'  R² test:  {best_r2:.4f}')
print(f'  Encoding: {best_name}')
print(f"{'=' * 70}")
print(f'\n  WHAT THIS MEANS:\n\n  If R²=1.000 with depth:\n    Depth was the missing dimension.\n    [gelu_out | depth] = complete natural space.\n    One matrix = all 8 FFN layers.\n    2018 + our laws = UNIFIED.\n    Compiler analogy proven:\n      state (gelu_out) + position (depth) = instant output.\n\n  If R² jumps from 0.83 (no depth) toward 1.000:\n    Depth signal is partially the answer.\n    Encoding choice matters (scalar/onehot/sinusoidal).\n    Best encoding = the natural language of depth.\n\n  If R² stays at 0.83 with depth:\n    Depth is not the missing dimension.\n    Something else separates the layers.\n    Need to find what that is.\n\n  COMPARE:\n    No depth:        R²=0.83\n    With best depth: R²=?\n    Jump = depth contribution.\n    Remaining gap = other missing dimension.\n')
print('=' * 70 + '\n')
