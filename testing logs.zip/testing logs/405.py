import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'EleutherAI/pythia-160m'
print(f'Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
rotary_ndims = model.gpt_neox.layers[0].attention.rotary_ndims
print(f'D={D} Heads={n_heads} Head_dim={head_dim} rotary_ndims={rotary_ndims}')

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2_np(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def apply_rope(x, seq_offset=0, base=10000):
    rd = rotary_ndims
    half = rd // 2
    CTX = x.shape[0]
    theta = 1.0 / base ** (np.arange(half, dtype=np.float32) * 2 / rd)
    pos = np.arange(seq_offset, seq_offset + CTX, dtype=np.float32)
    freqs = np.outer(pos, theta)
    cos_t = np.cos(freqs)
    sin_t = np.sin(freqs)
    x_out = x.copy()
    x1 = x[:, :half]
    x2 = x[:, half:rd]
    x_out[:, :half] = x1 * cos_t - x2 * sin_t
    x_out[:, half:rd] = x1 * sin_t + x2 * cos_t
    return x_out
text = 'Once upon a time there was a little girl who'
toks = tokenizer(text, return_tensors='pt')
L = toks['input_ids'].shape[1]
print(f'\nText length: {L} tokens')
print(f"Tokens: {tokenizer.convert_ids_to_tokens(toks['input_ids'][0].tolist())}")
layer_idx = 0
block = model.gpt_neox.layers[layer_idx]
CTX = min(8, L)
captured = {}

def hook_dense_in(mod, inp, out):
    captured['dense_in'] = inp[0].detach().float()

def hook_dense_out(mod, inp, out):
    captured['dense_out'] = out[0].detach().float()
hk1 = block.attention.dense.register_forward_hook(hook_dense_in)
hk2 = block.attention.dense.register_forward_hook(hook_dense_out)
with torch.no_grad():
    out_m = model(**toks, output_hidden_states=True)
hk1.remove()
hk2.remove()
hs = out_m.hidden_states
x16 = hs[layer_idx][0, :CTX]
print(f'\nShapes:')
print(f"  dense_in:  {captured['dense_in'].shape}")
print(f"  dense_out: {captured['dense_out'].shape}")
actual_concat = captured['dense_in'][:CTX].numpy()
att_out = captured['dense_out'][:CTX].numpy()
n = CTX
Xb = np.c_[actual_concat, np.ones(n)]
W = np.linalg.lstsq(Xb, att_out, rcond=None)[0]
pred = Xb @ W
r_actual = r2_np(pred, att_out)
print(f'\nTest 1 — actual_concat → att_out: R²={r_actual:.6f}')
print(f'  (Should be ~1.0 if hook captures correctly)')
hd = head_dim
qkv_raw = block.attention.query_key_value.weight.detach().float().numpy()
b_raw = block.attention.query_key_value.bias
b_np = b_raw.detach().float().numpy() if b_raw is not None else None
Wq_h = [qkv_raw[h * 3 * hd:h * 3 * hd + hd, :] for h in range(n_heads)]
Wk_h = [qkv_raw[h * 3 * hd + hd:h * 3 * hd + 2 * hd, :] for h in range(n_heads)]
Wv_h = [qkv_raw[h * 3 * hd + 2 * hd:h * 3 * hd + 3 * hd, :] for h in range(n_heads)]
bq_h = [b_np[h * 3 * hd:h * 3 * hd + hd] for h in range(n_heads)] if b_np is not None else [0] * n_heads
bk_h = [b_np[h * 3 * hd + hd:h * 3 * hd + 2 * hd] for h in range(n_heads)] if b_np is not None else [0] * n_heads
bv_h = [b_np[h * 3 * hd + 2 * hd:h * 3 * hd + 3 * hd] for h in range(n_heads)] if b_np is not None else [0] * n_heads
ln1_np = block.input_layernorm(x16).detach().float().numpy()
our_feats = []
for h in range(n_heads):
    Qh = ln1_np @ Wq_h[h].T + bq_h[h]
    Kh = ln1_np @ Wk_h[h].T + bk_h[h]
    Vh = ln1_np @ Wv_h[h].T + bv_h[h]
    Qh_r = apply_rope(Qh)
    Kh_r = apply_rope(Kh)
    scr = Qh_r @ Kh_r.T / np.sqrt(head_dim)
    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
    ah = softmax_np(scr + msk)
    our_feats.append(ah @ Vh)
our_concat = np.concatenate(our_feats, axis=1)
Xb2 = np.c_[our_concat, np.ones(n)]
W2 = np.linalg.lstsq(Xb2, att_out, rcond=None)[0]
r_ours = r2_np(Xb2 @ W2, att_out)
print(f'Test 2 — our_concat   → att_out: R²={r_ours:.6f}')
print(f'  (Should match actual if our QKV/RoPE is correct)')
diff = our_concat - actual_concat
print(f'\nDirect comparison: our_concat vs actual_concat')
print(f'  our_concat    norm: {np.linalg.norm(our_concat):.4f}')
print(f'  actual_concat norm: {np.linalg.norm(actual_concat):.4f}')
print(f'  difference    norm: {np.linalg.norm(diff):.4f}')
print(f'  relative diff:      {np.linalg.norm(diff) / np.linalg.norm(actual_concat):.4f}')
Xb3 = np.c_[actual_concat, np.ones(n)]
W3 = np.linalg.lstsq(Xb3, our_concat, rcond=None)[0]
r_cross = r2_np(Xb3 @ W3, our_concat)
print(f'\nTest 3 — actual_concat → our_concat: R²={r_cross:.6f}')
print(f'  (How linearly related are they?)')
print(f'\nHead 0 inspection:')
Qh0 = ln1_np @ Wq_h[0].T + bq_h[0]
Kh0 = ln1_np @ Wk_h[0].T + bk_h[0]
Vh0 = ln1_np @ Wv_h[0].T + bv_h[0]
actual_h0 = actual_concat[:, 0:head_dim]
our_h0_noRoPE = softmax_np(Qh0 @ Kh0.T / np.sqrt(head_dim) + np.triu(np.full((CTX, CTX), -1000000000.0), 1)) @ Vh0
Qh0_r = apply_rope(Qh0)
Kh0_r = apply_rope(Kh0)
our_h0_RoPE = softmax_np(Qh0_r @ Kh0_r.T / np.sqrt(head_dim) + np.triu(np.full((CTX, CTX), -1000000000.0), 1)) @ Vh0
print(f'  actual_h0 norm:       {np.linalg.norm(actual_h0):.4f}')
print(f'  our_h0 (noRoPE) norm: {np.linalg.norm(our_h0_noRoPE):.4f}')
print(f'  our_h0 (RoPE)   norm: {np.linalg.norm(our_h0_RoPE):.4f}')
print(f'  diff noRoPE: {np.linalg.norm(our_h0_noRoPE - actual_h0):.4f}')
print(f'  diff RoPE:   {np.linalg.norm(our_h0_RoPE - actual_h0):.4f}')
print(f'\nQKV layout check — block vs interleaved:')
qkv_block_q = qkv_raw[:D, :]
qkv_block_k = qkv_raw[D:2 * D, :]
qkv_block_v = qkv_raw[2 * D:3 * D, :]
Qh0_block = ln1_np @ qkv_block_q[:head_dim, :].T
Kh0_block = ln1_np @ qkv_block_k[:head_dim, :].T
Vh0_block = ln1_np @ qkv_block_v[:head_dim, :].T
our_h0_block = softmax_np(Qh0_block @ Kh0_block.T / np.sqrt(head_dim) + np.triu(np.full((CTX, CTX), -1000000000.0), 1)) @ Vh0_block
print(f'  our_h0 (block layout) norm: {np.linalg.norm(our_h0_block):.4f}')
print(f'  diff block layout: {np.linalg.norm(our_h0_block - actual_h0):.4f}')
print(f'  (If diff smaller than interleaved → layout is block not interleaved)')
print('\nDiagnosis complete. Now we know exactly where divergence happens.')
