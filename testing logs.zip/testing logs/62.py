import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
N_HIDDEN = 74

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

class ResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class ResNet(nn.Module):

    def __init__(self, n_hidden, dim):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(SEQ_LEN, dim), nn.Tanh())
        self.blocks = nn.ModuleList([ResBlock(dim) for _ in range(n_hidden)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for blk in self.blocks:
            x = blk(x)
        return self.output(x)

def train(model, epochs=5000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 1000 == 0:
            s = score(model)
            print(f'    {label:<14} ep{ep:>5}  loss={best:>14.8f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def score_precise(model):
    model.eval()
    errors = []
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            errors.append(abs(model(xt).item() * NORM - tn))
    return errors

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
DIMS = [4, 8, 16, 32, 64, 128, 256]
EPOCHS = 5000
CHECKPTS = [1000, 2000, 3000, 4000, 5000]
BASELINE_LOSS = 5.083e-05
print_sep(f'DIM SWEEP — 75-layer residual, {EPOCHS} epochs each')
print(f'  Dims: {DIMS}')
print(f'  Baseline (dim=16): loss={BASELINE_LOSS}')
print(f'  n_hidden={N_HIDDEN}\n')
all_results = []
all_logs = {}
for dim in DIMS:
    print(f'\n  ── DIM={dim} ──')
    np.random.seed(42)
    m = ResNet(N_HIDDEN, dim).to(device)
    params = sum((p.numel() for p in m.parameters()))
    print(f'  Params: {params:,}')
    t0 = time.time()
    best_loss, log = train(m, EPOCHS, lr=0.001, label=f'dim={dim}')
    s = score(m)
    errors = score_precise(m)
    avg_err = np.mean(errors)
    max_err = np.max(errors)
    elapsed = time.time() - t0
    all_results.append((dim, params, best_loss, s, avg_err, max_err, elapsed))
    all_logs[dim] = log
    del m
    torch.cuda.empty_cache()
    gain = BASELINE_LOSS / (best_loss + 1e-12)
    direction = '↑ BETTER' if best_loss < BASELINE_LOSS else '↓ WORSE'
    print(f'  DONE: dim={dim}  loss={best_loss:.8f}  score={s}/{len(TESTS)}  vs baseline={gain:.1f}x  {direction}')
print_sep('CONVERGENCE TABLE')
print(f"\n  {'Epoch':>6}", end='')
for dim in DIMS:
    print(f'  dim={dim:>3}', end='')
print()
print(f"  {'─' * 80}")
for ep in CHECKPTS:
    print(f'  {ep:>6}', end='')
    for dim in DIMS:
        v = all_logs[dim][min(ep - 1, len(all_logs[dim]) - 1)]
        print(f'  {v:>8.5f}', end='')
    print()
print_sep('FINAL SCOREBOARD — sorted by precision')
sorted_r = sorted(all_results, key=lambda x: x[2])
print(f'\n  Baseline (dim=16, proven): loss={BASELINE_LOSS:.8f}\n')
print(f"  {'DIM':>6}  {'Params':>10}  {'Score':>7}  {'Loss':>14}  {'vs baseline':>13}  {'Avg Err':>9}")
print(f"  {'─' * 75}")
for dim, params, loss, s, avg_err, max_err, _ in sorted_r:
    gain = BASELINE_LOSS / (loss + 1e-12)
    direction = '↑' if loss < BASELINE_LOSS else '↓'
    marker = ' ← PEAK' if dim == sorted_r[0][0] else ''
    print(f'  {dim:>6}  {params:>10,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {direction}{gain:>11.1f}x  {avg_err:>9.4f}{marker}')
print_sep('PRECISION CURVE — DIM vs LOSS')
print(f"\n  {'DIM':>6}  {'Loss':>14}  Curve")
print(f"  {'─' * 55}")
losses = [r[2] for r in all_results]
min_l = min(losses)
for dim, params, loss, s, avg_err, max_err, _ in all_results:
    bar_len = max(1, int(50 * (1 - loss / (max(losses) + 1e-10))))
    marker = ' ← PEAK' if loss == min_l else ''
    print(f"  {dim:>6}  {loss:>14.8f}  {'█' * bar_len}{marker}")
print_sep('CONCLUSION — NATURAL DIMENSION')
best_dim = sorted_r[0]
print(f'\n  NATURAL DIMENSION: {best_dim[0]}\n  Loss at natural dim: {best_dim[2]:.8f}\n  Score: {best_dim[3]}/{len(TESTS)}\n  Params: {best_dim[1]:,}\n\n  CURVE SHAPE:\n    If precision peaks at small dim → problem is simple\n      small dim enough to capture all structure\n      bigger dim = wasted capacity = noise\n\n    If precision peaks at large dim → problem needs width\n      more neurons = more pattern capacity\n      bigger = better up to a point\n\n    If precision peaks in middle → natural width exists\n      like natural depth — every problem has natural dim\n      below = undercapacity\n      above = redundancy degrades signal\n\n  COMBINED WITH DEPTH FINDING:\n    Natural depth = 75 layers\n    Natural dim   = {best_dim[0]}\n    These two together = the natural shape of this problem.\n\n    Intelligence = finding the natural shape.\n    Natural shape = minimum structure needed to solve perfectly.\n    Minimum structure = maximum efficiency.\n    This is the W Principle at full resolution.\n')
