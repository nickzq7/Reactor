import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN = 200
N_TEST = 50
MAX_SEQ = 64
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={DEVICE}')
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(DEVICE).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD = H // NH
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
with torch.no_grad():
    Wte = teacher.transformer.wte.weight.float().cpu().numpy()
    Wpe = teacher.transformer.wpe.weight.float().cpu().numpy()
    lnf_g = teacher.transformer.ln_f.weight.float().cpu().numpy()
    lnf_b = teacher.transformer.ln_f.bias.float().cpu().numpy()
    Wlm = teacher.lm_head.weight.float().cpu().numpy()
    LN = []
    for li in range(NL):
        bl = teacher.transformer.h[li]
        LN.append({'ln1_g': bl.ln_1.weight.float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.float().cpu().numpy(), 'type': ATT[li] if li < len(ATT) else 'global'})
del teacher
torch.cuda.empty_cache()
VOCAB = Wlm.shape[0]
print(f'  NL={NL} H={H} NH={NH} HD={HD}  VOCAB={VOCAB}')

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (g * (x - m) / np.sqrt(v + eps) + b).astype(np.float32)

def gelu(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def solve(X, Y):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.concatenate([X64, np.ones((len(X64), 1))], 1)
    res, _, _, _ = lstsq(Xb, Y64, rcond=None)
    W = res[:-1].T.astype(np.float32)
    b = res[-1].astype(np.float32)
    Yp = X64 @ res[:-1] + res[-1]
    r2 = float(1 - ((Y64 - Yp) ** 2).sum() / (((Y64 - Y64.mean(0)) ** 2).sum() + 1e-12))
    return (W, b, r2)

def causal_attn(h, li, Wo=None, bo=None):
    sl = h.shape[0]
    ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
    Q = ln1_h.reshape(sl, NH, HD).transpose(1, 0, 2)
    K = Q.copy()
    V = Q.copy()
    scores = np.matmul(Q, K.transpose(0, 2, 1)).astype(np.float32)
    mask = np.full((sl, sl), -1000000000.0, np.float32)
    atype = LN[li].get('type', 'global')
    for i in range(sl):
        s = max(0, i - WIN + 1) if atype == 'local' else 0
        mask[i, s:i + 1] = 0.0
    scores += mask[np.newaxis]
    scores -= scores.max(-1, keepdims=True)
    e = np.exp(scores)
    w = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    ctx = np.matmul(w, V).transpose(1, 0, 2).reshape(sl, H).astype(np.float32)
    if Wo is not None:
        return (ctx @ Wo.T + bo).astype(np.float32)
    return ctx

def ffn_forward(hm, li, W1, b1, W2, b2):
    ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
    pre = (ln2_h @ W1.T + b1).astype(np.float32)
    ffn = (gelu(pre) @ W2.T + b2).astype(np.float32)
    return ffn
print(f'\n  Loading {N_TRAIN + N_TEST} stories...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
stories = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 300:
        stories.append(t)
    if len(stories) >= N_TRAIN + N_TEST:
        break

def tokenise(story_list):
    seqs = []
    for s in story_list:
        ids = tok(s, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'][0].tolist()
        if len(ids) >= 4:
            seqs.append(ids)
    return seqs
train_seqs = tokenise(stories[:N_TRAIN])
test_seqs = tokenise(stories[N_TRAIN:N_TRAIN + N_TEST])
print(f'  Train seqs: {len(train_seqs)}  Test seqs: {len(test_seqs)}')

def collect_activations(seqs, weights=None):
    ctx_all = [[] for _ in range(NL)]
    atgt_all = [[] for _ in range(NL)]
    hmid_all = [[] for _ in range(NL)]
    ftgt_all = [[] for _ in range(NL)]
    ln2_all = [[] for _ in range(NL)]
    h0_all, htgt_all, nxt_all = ([], [], [])
    for ids in seqs:
        sl = len(ids) - 1
        pos_ids = ids[:sl]
        nxt_ids = ids[1:]
        h = (Wte[np.array(pos_ids)] + Wpe[np.arange(sl)]).astype(np.float32)
        h0_seq = h.copy()
        h0_all.append(h0_seq)
        htgt_seq = Wlm[np.array(nxt_ids)]
        htgt_all.append(htgt_seq)
        nxt_all.append(np.array(nxt_ids))
        for li in range(NL):
            frac = (li + 1) / NL
            h_tgt = ((1 - frac) * h0_seq + frac * htgt_seq).astype(np.float32)
            if weights is None:
                ctx = causal_attn(h, li)
                att = np.zeros_like(h)
            else:
                w = weights[li]
                ctx = causal_attn(h, li)
                att = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
            hm = (h + att).astype(np.float32)
            att_tgt = (h_tgt - h).astype(np.float32)
            ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
            if weights is None:
                ffn = np.zeros_like(h)
            else:
                w = weights[li]
                pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
                ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
            ffn_tgt = (h_tgt - hm).astype(np.float32)
            ctx_all[li].append(ctx)
            atgt_all[li].append(att_tgt)
            hmid_all[li].append(hm)
            ftgt_all[li].append(ffn_tgt)
            ln2_all[li].append(ln2_h)
            h = (hm + ffn).astype(np.float32)
    result = []
    for li in range(NL):
        result.append({'ctx': np.concatenate(ctx_all[li], 0), 'att_tgt': np.concatenate(atgt_all[li], 0), 'ln2': np.concatenate(ln2_all[li], 0), 'ffn_tgt': np.concatenate(ftgt_all[li], 0)})
    h0 = np.concatenate(h0_all, 0)
    htgt = np.concatenate(htgt_all, 0)
    nxt = np.concatenate(nxt_all, 0)
    return (result, h0, htgt, nxt)

def solve_weights(layer_data):
    weights = []
    print(f"  {'Layer':<6} {'R²_Wo':>8} {'R²_W2':>8}")
    print(f"  {'-' * 28}")
    for li in range(NL):
        d = layer_data[li]
        Wo, bo, r2_o = solve(d['ctx'], d['att_tgt'])
        W1, b1, _ = solve(d['ln2'], d['ln2'])
        pre = (d['ln2'] @ W1.T + b1).astype(np.float32)
        W2, b2, r2_2 = solve(gelu(pre), d['ffn_tgt'])
        print(f'  {li:<6} {r2_o:8.4f} {r2_2:8.4f}')
        weights.append(dict(Wo=Wo, bo=bo, W1=W1, b1=b1, W2=W2, b2=b2))
    return weights

def eval_acc(seqs, weights):
    correct, total = (0, 0)
    for ids in seqs:
        sl = len(ids) - 1
        h = (Wte[np.array(ids[:sl])] + Wpe[np.arange(sl)]).astype(np.float32)
        for li, w in enumerate(weights):
            ctx = causal_attn(h, li)
            att = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
            hm = (h + att).astype(np.float32)
            ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
            pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
            ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
            h = (hm + ffn).astype(np.float32)
        logits = (ln(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32)
        preds = np.argmax(logits, -1)
        correct += int((preds == np.array(ids[1:])).sum())
        total += sl
    return correct / total

def gen(prompt, weights, n=60):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    for _ in range(n):
        sl = len(ids)
        h = (Wte[np.array(ids)] + Wpe[np.arange(sl)]).astype(np.float32)
        for li, w in enumerate(weights):
            ctx = causal_attn(h, li)
            att = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
            hm = (h + att).astype(np.float32)
            ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
            pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
            ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
            h = (hm + ffn).astype(np.float32)
        next_id = int(np.argmax((ln(h, lnf_g, lnf_b) @ Wlm.T)[-1]))
        if next_id == tok.eos_token_id:
            break
        ids.append(next_id)
    plen = len(tok(prompt)['input_ids'])
    return tok.decode(ids[plen:], skip_special_tokens=True)

def gen_teacher(prompt, n=60):
    t = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(DEVICE).eval()
    inp = tok(prompt, return_tensors='pt').to(DEVICE)
    with torch.no_grad():
        out = t.generate(inp['input_ids'], max_new_tokens=n, do_sample=False, use_cache=True, pad_token_id=tok.eos_token_id)
    del t
    torch.cuda.empty_cache()
    return tok.decode(out[0][inp['input_ids'].shape[1]:], skip_special_tokens=True)
print(f'\n  Random baseline: {1 / VOCAB * 100:.4f}%')
print('\n' + '=' * 55)
print('  PASS 1 — sequence-level lstsq (causal ctx, no prev model)')
print('=' * 55)
t0 = time.perf_counter()
layer_data1, _, _, _ = collect_activations(train_seqs, weights=None)
W1 = solve_weights(layer_data1)
acc1_tr = eval_acc(train_seqs, W1)
acc1_te = eval_acc(test_seqs, W1)
print(f'  Train: {acc1_tr * 100:.3f}%  Test: {acc1_te * 100:.3f}%  ({acc1_te / (1 / VOCAB):.0f}x random)')
print('\n' + '=' * 55)
print('  PASS 2 — EM refinement (Pass 1 activations)')
print('=' * 55)
layer_data2, _, _, _ = collect_activations(train_seqs, weights=W1)
W2 = solve_weights(layer_data2)
acc2_tr = eval_acc(train_seqs, W2)
acc2_te = eval_acc(test_seqs, W2)
t_total = time.perf_counter() - t0
print(f'  Train: {acc2_tr * 100:.3f}%  Test: {acc2_te * 100:.3f}%  ({acc2_te / (1 / VOCAB):.0f}x random)')
print(f'  Total time: {t_total:.1f}s  |  Gradient steps: 0')
PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'Tom wanted to play but', 'In the forest there lived a']
print('\n' + '=' * 55)
print('  GENERATION — SCRATCH vs TEACHER')
print('=' * 55)
for p in PROMPTS:
    print(f'\n  Prompt  : "{p}"')
    print(f'  Scratch : {gen(p, W2, n=50).strip()}')
print('\n  --- Teacher comparison ---')
p = PROMPTS[0]
print(f'\n  Prompt  : "{p}"')
print(f'  Teacher : {gen_teacher(p, n=50).strip()}')
print(f'  Scratch : {gen(p, W2, n=50).strip()}')
print(f'\n  FINAL: Test {acc2_te * 100:.2f}%  |  {acc2_te / (1 / VOCAB):.0f}x random  |  {t_total:.1f}s  |  0 gradients')
