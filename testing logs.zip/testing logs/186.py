import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — ALL LAYERS TEST')
print('  Same laws on layers 1-7?')
print('  Or new hidden laws in deeper layers?')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
CTX = 8
print(f'  D={D}  Heads={n_heads}  Head_dim={head_dim}  Layers={n_layers}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def fit_r2(X_tr, Y_tr, X_te, Y_te):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    return r2(X_te @ W, Y_te)
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came', 'The dog ran fast', 'The children went to', 'It was a sunny', 'Deep in the woods', 'Every morning the bird', 'The brave knight rode', 'She found a lost', 'The baby bear found', 'A tiny seed grew', 'The two friends walked', 'A rainbow appeared', 'The kind queen shared', 'A yellow duck learned', 'The snow fell softly', 'He wished upon a', 'The cat chased the', 'The children found a', 'She drew a picture', 'The moon shone bright', 'A boy climbed the', 'He discovered a door', 'Three little bears came', 'The frog jumped across', 'A butterfly emerged', 'An owl sat watching', 'The kitten played with', 'A girl named Emma', 'The farmer woke up', 'A genie appeared to', 'The turtle and rabbit', 'She sang a song to', 'The brave little mouse', 'A young girl read', 'The old farmer fed', 'A baby elephant learned', 'The wolf huffed and']
print(f'\n  Generating from {len(starts)} prompts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=50, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} texts.')
print(f'\n  Collecting features for all {n_layers} layers...')
layer_data = {l: {'X': [], 'delta': [], 'att': [], 'ffn': [], 'per_head': []} for l in range(n_layers)}
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for layer_idx in range(n_layers):
            block = model.transformer.h[layer_idx]
            attn_mod = block.attn.attention
            Wq = attn_mod.q_proj.weight.detach().numpy().T
            Wk = attn_mod.k_proj.weight.detach().numpy().T
            Wv = attn_mod.v_proj.weight.detach().numpy().T
            for start in range(L - CTX + 1):
                x_t = hs[layer_idx][0, start:start + CTX]
                x_np = x_t.numpy()
                y_np = hs[layer_idx + 1][0, start:start + CTX].numpy()
                delta = y_np - x_np
                ln1 = block.ln_1(x_t).detach().numpy()
                att_out = block.attn(block.ln_1(x_t).unsqueeze(0))[0].squeeze(0).detach().numpy()
                x2 = x_t + torch.tensor(att_out, dtype=torch.float32)
                ln2 = block.ln_2(x2).detach().numpy()
                pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).detach().numpy()
                act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).detach().numpy()
                ffn = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).detach().numpy()
                gelu_act = act * (pre > 0).astype(float)
                Q_full = ln1 @ Wq
                K_full = ln1 @ Wk
                V_full = ln1 @ Wv
                head_feats = []
                for h in range(n_heads):
                    s_h = h * head_dim
                    e_h = s_h + head_dim
                    Q_h = Q_full[:, s_h:e_h]
                    K_h = K_full[:, s_h:e_h]
                    V_h = V_full[:, s_h:e_h]
                    scr = Q_h @ K_h.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    att_h = softmax(scr + msk)
                    head_feats.append((att_h @ V_h).flatten())
                per_head = np.concatenate(head_feats)
                d = layer_data[layer_idx]
                d['X'].append(x_np.flatten())
                d['delta'].append(delta.flatten())
                d['att'].append(att_out.flatten())
                d['ffn'].append(ffn.flatten())
                d['per_head'].append(per_head)
                d['gelu'] = d.get('gelu', [])
                d['gelu'].append(gelu_act.flatten())
print(f'  Collection done.')
print('\n' + '=' * 62)
print('  RESULTS — ALL LAYERS')
print('  Same laws? Or new hidden laws?')
print('=' * 62)
print(f"\n  {'Layer':<6} {'x→delta':<10} {'x→att':<10} {'per_head→att':<14} {'x+gelu→ffn':<12} {'att+ffn→delta':<14}")
print('  ' + '─' * 62)
layer_results = []
for layer_idx in range(n_layers):
    d = layer_data[layer_idx]
    N = len(d['X'])
    N_tr = int(N * 0.8)
    X = np.array(d['X'])
    DEL = np.array(d['delta'])
    ATT = np.array(d['att'])
    FFN = np.array(d['ffn'])
    PH = np.array(d['per_head'])
    GEL = np.array(d['gelu'])
    r_xdel = fit_r2(X[:N_tr], DEL[:N_tr], X[N_tr:], DEL[N_tr:])
    r_xatt = fit_r2(X[:N_tr], ATT[:N_tr], X[N_tr:], ATT[N_tr:])
    r_phatt = fit_r2(PH[:N_tr], ATT[:N_tr], PH[N_tr:], ATT[N_tr:])
    XG = np.column_stack([X, GEL])
    r_ffn = fit_r2(XG[:N_tr], FFN[:N_tr], XG[N_tr:], FFN[N_tr:])
    AF = np.column_stack([ATT, FFN])
    r_af = fit_r2(AF[:N_tr], DEL[:N_tr], AF[N_tr:], DEL[N_tr:])
    layer_results.append({'layer': layer_idx, 'x_delta': r_xdel, 'x_att': r_xatt, 'ph_att': r_phatt, 'ffn': r_ffn, 'af_delta': r_af, 'N': N})

    def fmt(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {layer_idx:<6} {fmt(r_xdel):<10} {fmt(r_xatt):<10} {fmt(r_phatt):<14} {fmt(r_ffn):<12} {fmt(r_af):<14}  N={N}')
print('\n' + '=' * 62)
print('  ANOMALY DETECTION')
print('  Where do laws change across layers?')
print('=' * 62)
print()
baseline = layer_results[0]
for res in layer_results[1:]:
    l = res['layer']
    diffs = {'x_delta': res['x_delta'] - baseline['x_delta'], 'x_att': res['x_att'] - baseline['x_att'], 'ph_att': res['ph_att'] - baseline['ph_att'], 'ffn': res['ffn'] - baseline['ffn'], 'af_delta': res['af_delta'] - baseline['af_delta']}
    anomalies = {k: v for k, v in diffs.items() if abs(v) > 0.02}
    if anomalies:
        print(f'  Layer {l} differs from layer 0:')
        for k, v in anomalies.items():
            direction = '▲ IMPROVES' if v > 0 else '▼ DROPS'
            print(f'    {k:<14} {direction}  Δ={v:+.4f}')
    else:
        print(f'  Layer {l}: same laws. No anomaly.')
print('\n' + '=' * 62)
print('  WHAT IS REVEALED')
print('=' * 62)
print('\n  If all layers show same R²:\n    Law is universal across depth.\n    W principle holds at all levels of abstraction.\n    Deeper layers = same natural spaces.\n    Abstraction does not create new nonlinearity.\n    Universe does not change its law with depth.\n\n  If R² drops at deeper layers:\n    More abstract representations are\n    harder to predict from input alone.\n    Layer sees emergent structure that\n    earlier layers built up.\n    New natural space needed.\n    Hidden law at that depth.\n\n  If R² improves at deeper layers:\n    Representations become MORE linear with depth.\n    Training drives toward natural space.\n    Deepest layers = most aligned with W.\n    Closest to the answer before argmax.\n\n  att+ffn → delta should be R²=1.0 at ALL layers.\n  That is mathematical — not a law to find.\n  delta = att + ffn always.\n  Any deviation = measurement error.\n\n  The interesting columns:\n    x → delta: how predictable is each layer?\n    per_head → att: does per-head rule hold deep?\n    x+gelu → ffn: does gelu rule hold deep?\n')
print('=' * 62 + '\n')
