import torch
import numpy as np
from collections import Counter, defaultdict
from transformers import AutoModelForCausalLM, AutoTokenizer
import math, re
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
print_sep('LOAD TinyStories-1M')
MODEL_NAME = 'roneneldan/TinyStories-1M'
ts_tok = AutoTokenizer.from_pretrained(MODEL_NAME)
if ts_tok.pad_token is None:
    ts_tok.pad_token = ts_tok.eos_token
try:
    ts_model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float32, use_safetensors=True)
except:
    ts_model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, torch_dtype=torch.float32)
ts_model = ts_model.to(device)
ts_model.eval()
print(f'  Loaded: {sum((p.numel() for p in ts_model.parameters())):,} params')

def generate(prompt, max_new=120, temp=0.8):
    inputs = ts_tok(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        out = ts_model.generate(**inputs, max_new_tokens=max_new, temperature=temp, do_sample=True, pad_token_id=ts_tok.eos_token_id)
    return ts_tok.decode(out[0], skip_special_tokens=True)

def text_to_words(text):
    text = text.lower().strip()
    words = text.split()
    words = [w for w in words if w]
    return words

def sent_to_word_ids(sentence, vocab):
    words = text_to_words(sentence)
    return [vocab.get(w, 0) for w in words]
print_sep('GENERATE STORIES — WORD LEVEL')
PROMPTS = ['Once upon a time', 'One day', 'There was a little', 'A small boy named', 'The girl wanted to', 'In the forest', 'Tom went to', 'She looked at', 'The dog ran', 'Once there was', 'A tiny cat', 'The children played', 'He found a', 'She was very', 'The old man', 'One morning', 'They went to', 'A little bird', 'The kind girl', 'Once a bunny'] * 5
print(f'\n  Generating {len(PROMPTS)} stories...')
all_sentences = []
for i, prompt in enumerate(PROMPTS):
    text = generate(prompt, max_new=120)
    sents = [s.strip() for s in re.split('(?<=[.!?])\\s+', text) if 3 < len(s.strip()) < 200]
    all_sentences.extend(sents)
    if (i + 1) % 25 == 0:
        print(f'  {i + 1}/{len(PROMPTS)} stories... ({len(all_sentences)} sentences)')
print(f'\n  Total sentences: {len(all_sentences)}')
all_word_seqs = []
for sent in all_sentences:
    words = text_to_words(sent)
    if 3 <= len(words) <= 25:
        all_word_seqs.append(words)
print(f'  Valid word sequences: {len(all_word_seqs)}')
print(f'  Avg length: {np.mean([len(s) for s in all_word_seqs]):.1f} words')
print(f'\n  Sample word sequences:')
for seq in all_word_seqs[:5]:
    print(f'    {seq}')
word_counter = Counter((w for seq in all_word_seqs for w in seq))
vocab = {w: i for i, (w, _) in enumerate(word_counter.most_common())}
inv_vocab = {i: w for w, i in vocab.items()}
all_id_seqs = [[vocab[w] for w in seq] for seq in all_word_seqs]
print(f'\n  Vocabulary size: {len(vocab)} unique words')
print(f'  Top 20 words: {[w for w, _ in word_counter.most_common(20)]}')
print_sep('ATOM DISCOVERY — WORD LEVEL PMI')
print(f'\n  Now working at WORD level.\n  "Once" and "upon" are already single units.\n  PMI will find real semantic combinations.\n  No tokenizer artifacts.\n')

def compute_pmi(id_seqs, inv_vocab):
    bigram_count = Counter()
    unigram_count = Counter()
    for seq in id_seqs:
        for i in range(len(seq) - 1):
            bigram_count[seq[i], seq[i + 1]] += 1
            unigram_count[seq[i]] += 1
        if seq:
            unigram_count[seq[-1]] += 1
    total = sum(unigram_count.values())
    scores = {}
    for (a, b), count in bigram_count.items():
        if count < 3:
            continue
        p_ab = count / total
        p_a = unigram_count[a] / total
        p_b = unigram_count[b] / total
        if p_a > 0 and p_b > 0:
            pmi = math.log2(p_ab / (p_a * p_b))
            scores[a, b] = (pmi, count)
    return scores

def merge_pair(id_seqs, a, b, new_id):
    result = []
    for seq in id_seqs:
        new_seq = []
        i = 0
        while i < len(seq):
            if i < len(seq) - 1 and seq[i] == a and (seq[i + 1] == b):
                new_seq.append(new_id)
                i += 2
            else:
                new_seq.append(seq[i])
                i += 1
        result.append(new_seq)
    return result

def id_to_str(atom_id, inv_vocab, atom_names):
    if atom_id in atom_names:
        return atom_names[atom_id]
    return inv_vocab.get(atom_id, f'?{atom_id}')
working_seqs = [list(s) for s in all_id_seqs]
next_id = max(vocab.values()) + 1
atom_names = {}
atoms_found = []
PMI_THRESH = 4.0
MIN_COUNT = 4
MAX_ATOMS = 50
print(f'  PMI threshold: {PMI_THRESH}  Min count: {MIN_COUNT}\n')
print(f"  {'#':>3}  {'Atom':<30}  {'PMI':>7}  {'Count':>6}  {'Compression':>11}")
print(f"  {'─' * 65}")
for iteration in range(MAX_ATOMS):
    scores = compute_pmi(working_seqs, inv_vocab)
    if not scores:
        break
    best = max(scores.items(), key=lambda x: x[1][0])
    (a, b), (pmi, count) = best
    if pmi < PMI_THRESH:
        break
    name_a = id_to_str(a, inv_vocab, atom_names)
    name_b = id_to_str(b, inv_vocab, atom_names)
    atom_name = f'{name_a}_{name_b}'
    atom_names[next_id] = atom_name
    atoms_found.append((a, b, pmi, count, atom_name, next_id))
    working_seqs = merge_pair(working_seqs, a, b, next_id)
    next_id += 1
    avg_len = np.mean([len(s) for s in working_seqs])
    orig_len = np.mean([len(s) for s in all_id_seqs])
    ratio = orig_len / avg_len
    print(f'  {iteration + 1:>3}  {atom_name:<30}  {pmi:>7.3f}  {count:>6}  {ratio:>10.3f}x')
orig_avg = np.mean([len(s) for s in all_id_seqs])
comp_avg = np.mean([len(s) for s in working_seqs])
ratio = orig_avg / comp_avg
print_sep('RESULTS — REAL ATOMS FOUND')
print(f'\n  Original:   {orig_avg:.2f} words/sentence\n  Compressed: {comp_avg:.2f} units/sentence\n  Ratio:      {ratio:.2f}x real compression\n\n  Atoms found: {len(atoms_found)}\n')
print(f'  STORY ATOMS (what TinyStories actually compresses to):\n')
print(f"  {'Atom':<35}  {'PMI':>7}  {'Count':>6}  Meaning")
print(f"  {'─' * 70}")
for a, b, pmi, count, name, aid in atoms_found:
    if any((w in name for w in ['once', 'one_day', 'one_morning', 'there_was'])):
        kind = '← story opener'
    elif any((w in name for w in ['and_they', 'they_lived', 'the_end', 'happy'])):
        kind = '← story closer'
    elif any((w in name for w in ['said', 'told', 'asked', 'replied'])):
        kind = '← dialogue'
    elif any((w in name for w in ['went_to', 'ran_to', 'looked_at', 'picked_up'])):
        kind = '← action'
    elif any((w in name for w in ["didn't", "couldn't", "wouldn't", "don't"])):
        kind = '← negation'
    elif any((w in name for w in ['but_then', 'all_of', 'a_lot'])):
        kind = '← narrative turn'
    else:
        kind = ''
    print(f'  {name:<35}  {pmi:>7.3f}  {count:>6}  {kind}')
print_sep('PYTHON CODE — SAME ANALYSIS')
print(f'\n  Now: Python code at word/token level.\n  "Python tokens" = meaningful units: def, (, :, return, etc.\n  \n  What does Python actually compress to?\n')
PYTHON_CORPUS = '\ndef add ( a , b ) :\n    return a + b\n\ndef greet ( name ) :\n    print ( "Hello" , name )\n    return name\n\nfor i in range ( 10 ) :\n    print ( i )\n\nx = 0\nwhile x < 10 :\n    x = x + 1\n\ndef factorial ( n ) :\n    if n == 0 :\n        return 1\n    return n * factorial ( n - 1 )\n\nclass Dog :\n    def __init__ ( self , name ) :\n        self . name = name\n    def bark ( self ) :\n        print ( "Woof" )\n\nnumbers = [ 1 , 2 , 3 , 4 , 5 ]\nfor num in numbers :\n    if num > 2 :\n        print ( num )\n\ndef find_max ( lst ) :\n    max_val = lst [ 0 ]\n    for item in lst :\n        if item > max_val :\n            max_val = item\n    return max_val\n\nimport os\nimport sys\nfrom collections import Counter\n\ndef read_file ( path ) :\n    with open ( path ) as f :\n        return f . read ( )\n\nresult = [ ]\nfor i in range ( 100 ) :\n    if i % 2 == 0 :\n        result . append ( i )\n\ndef is_prime ( n ) :\n    if n < 2 :\n        return False\n    for i in range ( 2 , n ) :\n        if n % i == 0 :\n            return False\n    return True\n\ntry :\n    x = int ( input ( ) )\nexcept ValueError :\n    print ( "not a number" )\n\ndata = { "name" : "Alice" , "age" : 30 }\nfor key , value in data . items ( ) :\n    print ( key , value )\n\ndef bubble_sort ( arr ) :\n    n = len ( arr )\n    for i in range ( n ) :\n        for j in range ( n - i - 1 ) :\n            if arr [ j ] > arr [ j + 1 ] :\n                arr [ j ] , arr [ j + 1 ] = arr [ j + 1 ] , arr [ j ]\n    return arr\n\nassert result is not None\nassert len ( result ) > 0\n' * 12
py_lines = [l.strip() for l in PYTHON_CORPUS.split('\n') if l.strip() and (not l.strip().startswith('#'))]
py_word_seqs = [l.split() for l in py_lines if 2 <= len(l.split()) <= 20]
print(f'  Python lines: {len(py_word_seqs)}')
print(f'  Avg length: {np.mean([len(s) for s in py_word_seqs]):.1f} tokens')
print(f'\n  Sample lines:')
for seq in py_word_seqs[:5]:
    print(f'    {seq}')
py_word_counter = Counter((w for seq in py_word_seqs for w in seq))
py_vocab = {w: i for i, (w, _) in enumerate(py_word_counter.most_common())}
py_inv_vocab = {i: w for w, i in py_vocab.items()}
py_id_seqs = [[py_vocab[w] for w in seq] for seq in py_word_seqs]
print(f'\n  Python vocabulary: {len(py_vocab)} unique tokens')
print(f'  Top tokens: {[w for w, _ in py_word_counter.most_common(20)]}')
py_working = [list(s) for s in py_id_seqs]
py_next_id = max(py_vocab.values()) + 1
py_atom_names = {}
py_atoms_found = []
print(f"\n  {'#':>3}  {'Atom':<35}  {'PMI':>7}  {'Count':>6}  {'Compression':>11}")
print(f"  {'─' * 68}")
for iteration in range(MAX_ATOMS):
    scores = compute_pmi(py_working, py_inv_vocab)
    if not scores:
        break
    best = max(scores.items(), key=lambda x: x[1][0])
    (a, b), (pmi, count) = best
    if pmi < PMI_THRESH:
        break
    name_a = id_to_str(a, py_inv_vocab, py_atom_names)
    name_b = id_to_str(b, py_inv_vocab, py_atom_names)
    atom_name = f'{name_a}_{name_b}'
    py_atom_names[py_next_id] = atom_name
    py_atoms_found.append((a, b, pmi, count, atom_name, py_next_id))
    py_working = merge_pair(py_working, a, b, py_next_id)
    py_next_id += 1
    avg_len = np.mean([len(s) for s in py_working])
    orig_len = np.mean([len(s) for s in py_id_seqs])
    ratio = orig_len / avg_len
    print(f'  {iteration + 1:>3}  {atom_name:<35}  {pmi:>7.3f}  {count:>6}  {ratio:>10.3f}x')
py_orig = np.mean([len(s) for s in py_id_seqs])
py_comp = np.mean([len(s) for s in py_working])
py_ratio = py_orig / py_comp
print_sep('FINAL COMPARISON — STORIES vs CODE')
ts_atoms = [(name, pmi, count) for _, _, pmi, count, name, _ in atoms_found]
py_atoms = [(name, pmi, count) for _, _, pmi, count, name, _ in py_atoms_found]
print(f'\n  TINYSTORIES atoms ({len(ts_atoms)} found, {ratio:.2f}x compression):\n')
for name, pmi, count in ts_atoms[:15]:
    print(f"    '{name}'  (pmi={pmi:.2f}, n={count})")
print(f'\n  PYTHON CODE atoms ({len(py_atoms)} found, {py_ratio:.2f}x compression):\n')
for name, pmi, count in py_atoms[:15]:
    print(f"    '{name}'  (pmi={pmi:.2f}, n={count})")
print(f'\n  ── WHAT THE DATA SAYS ──\n\n  Stories compress {ratio:.2f}x using narrative atoms.\n  Code compresses {py_ratio:.2f}x using syntax atoms.\n\n  Stories natural units: openings, actions, dialogue, closings.\n  Code natural units:    declarations, conditions, loops, returns.\n\n  SAME OPERATION — DIFFERENT ATOMS:\n    Both found by PMI (what always appears together).\n    Neither domain told us what to look for.\n    Data found its own compression units.\n\n  This IS what the subconscious does:\n    Not: "I will look for subjects and verbs"\n    But: "what always appears together?" → those are my units.\n    \n  Stories: "once_upon" always together → one unit\n  Code:    "return_False" always together → one unit\n  Math:    diff2 always constant → one formula\n\n  Same principle. Every domain. One mind.\n')
