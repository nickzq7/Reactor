import numpy as np
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'HuggingFaceTB/SmolLM-135M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_layers = len(model.model.layers)
ffn_dim = model.config.intermediate_size
print(f'D={D}  Layers={n_layers}  FFN_dim={ffn_dim}')

def fit_W(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)
seeds = ['Once upon a time', 'The scientist looked at', 'In a distant future', 'The old library held', 'A young programmer wrote', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed through', 'A dog sat quietly', 'She found the key', 'The storm was coming', 'The teacher explained how', 'A bird flew over', 'He picked up the phone', 'The car stopped suddenly', 'Deep in the forest', 'The robot walked toward', 'After many years had', 'The question was simple', 'Nobody knew what had', 'The door opened slowly', 'Light filled the room', 'She ran as fast', 'The answer was clear', 'He stood at the edge']
print(f'\nGenerating {len(seeds) * 6} training texts for W extraction...')
train_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(6):
            torch.manual_seed(i * 60 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=35, do_sample=True, temperature=0.8 + j * 0.04, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(train_texts)} texts.')
store = {l: {'gate_act': [], 'ffn_out': []} for l in range(n_layers)}
hooks = []
for li in range(n_layers):

    def make(l):

        def hg(m, inp, out):
            for tok in inp[0][0].detach().float().numpy():
                store[l]['gate_act'].append(tok)

        def hf(m, inp, out):
            for tok in out[0].detach().float().numpy():
                store[l]['ffn_out'].append(tok)
        return (hg, hf)
    hg, hf = make(li)
    hooks += [model.model.layers[li].mlp.down_proj.register_forward_hook(hg), model.model.layers[li].mlp.down_proj.register_forward_hook(hf)]
print(f'Running {len(train_texts)} forward passes to collect features...')
with torch.no_grad():
    for i, text in enumerate(train_texts):
        if i % 40 == 0:
            print(f'  {i}/{len(train_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
print(f'\nFitting W_ffn for all {n_layers} layers...')
W_ffn = {}
for li in range(n_layers):
    GA = np.array(store[li]['gate_act'], dtype=np.float32)
    FO = np.array(store[li]['ffn_out'], dtype=np.float32)
    W_ffn[li] = fit_W(GA, FO)
    if li % 5 == 0:
        n = len(GA)
        s = int(n * 0.8)
        Xb = np.c_[GA, np.ones(n)]
        pred = Xb[s:] @ W_ffn[li]
        err = np.mean((pred - FO[s:]) ** 2)
        var = np.var(FO[s:])
        r2 = 1 - err / var
        print(f'  Layer {li}: R²={r2:.4f}  N={n}')
print(f'W_ffn extracted for all {n_layers} layers.')

class WffnPatch(nn.Module):

    def __init__(self, original_mlp, W_mat):
        super().__init__()
        self.original_mlp = original_mlp
        self.W = torch.tensor(W_mat, dtype=torch.float32)
        self.active = False

    def forward(self, x):
        if not self.active:
            return self.original_mlp(x)
        gate = self.original_mlp.act_fn(self.original_mlp.gate_proj(x))
        up = self.original_mlp.up_proj(x)
        gate_act = (gate * up).float()
        B, L, fd = gate_act.shape
        ga_flat = gate_act.reshape(B * L, fd)
        ga_bias = torch.cat([ga_flat, torch.ones(B * L, 1, dtype=torch.float32)], dim=1)
        out = ga_bias @ self.W
        return out.reshape(B, L, -1).to(x.dtype)
patches = []
for li in range(n_layers):
    patch = WffnPatch(model.model.layers[li].mlp, W_ffn[li])
    model.model.layers[li].mlp = patch
    patches.append(patch)

def generate_text(prompt, max_new=60, mode='normal'):
    for p in patches:
        p.active = mode == 'w'
    inp = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(inp, max_new_tokens=max_new, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)
prompts = ['Once upon a time there was a little girl who', 'The scientist discovered that the experiment', 'In a world where machines could think,', 'She opened the old book and found', 'The last thing he remembered was']
print(f"\n{'=' * 70}")
print(f'  GENERATION COMPARISON — NORMAL vs W')
print(f'  Attention: identical in both modes')
print(f'  FFN: full model vs W_ffn @ gate_activated')
print(f"{'=' * 70}")
for prompt in prompts:
    normal = generate_text(prompt, max_new=50, mode='normal')
    w_text = generate_text(prompt, max_new=50, mode='w')
    print(f'\n  PROMPT: {prompt}')
    print(f"  {'─' * 60}")
    print(f'  NORMAL: {normal[len(prompt):]}')
    print(f'  W MODE: {w_text[len(prompt):]}')
    n_toks = set(tokenizer.encode(normal))
    w_toks = set(tokenizer.encode(w_text))
    overlap = len(n_toks & w_toks) / len(n_toks | w_toks)
    print(f'  Token overlap: {overlap:.1%}')
print(f"\n{'=' * 70}")
print(f'\n  WHAT THIS PROVES:\n\n  If W mode output is coherent:\n    SwiGLU law works at generation time.\n    Not just held-out test data.\n    W replaces FFN in real autoregressive inference.\n    Proven on Llama-family architecture.\n\n  If W mode loops or degrades:\n    Training data not sufficient.\n    Or: need more layers covered.\n    Increase training texts.\n\n  Token overlap > 50%:\n    W mode tracking normal closely.\n    Same semantic content.\n\n  Token overlap > 80%:\n    Nearly identical generation.\n    W is a true replacement.\n\n  COMPARE WITH TINYSTORIES:\n    TinyStories W mode: coherent story.\n    SmolLM W mode: ?\n    If both coherent: W universal across families.\n')
print('=' * 70 + '\n')
