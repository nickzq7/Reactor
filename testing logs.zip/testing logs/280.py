import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  CROSS-FAMILY SURGERY')
print('  TinyStories-1M (GPT-Neo) ↔ Pythia-70M (GPT-NeoX)')
print('  Different family. Different data. Different PE. Different D.')
print('=' * 70)
try:
    import transformers.modeling_utils as _mu
    _mu.check_torch_load_is_safe = lambda: None
except:
    pass
print('\n  Loading TinyStories-1M (GPT-Neo)...')
tokA = AutoTokenizer.from_pretrained('roneneldan/TinyStories-1M')
mdlA = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
mdlA.eval()
print('  Loading pythia-70m (GPT-NeoX)...')
tokB = AutoTokenizer.from_pretrained('EleutherAI/pythia-70m')
mdlB = AutoModelForCausalLM.from_pretrained('EleutherAI/pythia-70m')
mdlB.eval()
cfgA = mdlA.config
cfgB = mdlB.config
DA = cfgA.hidden_size
DB = cfgB.hidden_size
HA = cfgA.num_attention_heads
HB = cfgB.num_attention_heads
NLA = cfgA.num_layers
NLB = cfgB.num_hidden_layers
hdA = DA // HA
hdB = DB // HB
attA = getattr(cfgA, 'attention_layers', ['global'] * NLA)
winA = getattr(cfgA, 'window_size', 256)
VSA = cfgA.vocab_size
VSB = cfgB.vocab_size
print(f'\n  Model A — TinyStories-1M: D={DA} H={HA} hd={hdA} layers={NLA} VS={VSA}')
print(f'  Model B — pythia-70m:     D={DB} H={HB} hd={hdB} layers={NLB} VS={VSB}')
print(f'  D ratio: {DB}/{DA} = {DB // DA}x  |  Layers: {NLA} vs {NLB}')

def f64(t):
    return t.detach().numpy().astype(np.float64)
with torch.no_grad():
    wteA = f64(mdlA.transformer.wte.weight)
    wpeA = f64(mdlA.transformer.wpe.weight)
    lfgA = f64(mdlA.transformer.ln_f.weight)
    lfbA = f64(mdlA.transformer.ln_f.bias)
    lmhA = f64(mdlA.lm_head.weight)
    LA = []
    for l in range(NLA):
        blk = mdlA.transformer.h[l]
        at = blk.attn.attention
        ml = blk.mlp
        LA.append({'WQ': f64(at.q_proj.weight), 'WK': f64(at.k_proj.weight), 'WV': f64(at.v_proj.weight), 'WO': f64(at.out_proj.weight), 'bO': f64(at.out_proj.bias), 'W1': f64(ml.c_fc.weight), 'b1': f64(ml.c_fc.bias), 'W2': f64(ml.c_proj.weight), 'b2': f64(ml.c_proj.bias), 'LN1g': f64(blk.ln_1.weight), 'LN1b': f64(blk.ln_1.bias), 'LN2g': f64(blk.ln_2.weight), 'LN2b': f64(blk.ln_2.bias)})
    FFNA = LA[0]['W1'].shape[0]
with torch.no_grad():
    wteB = f64(mdlB.gpt_neox.embed_in.weight)
    lfgB = f64(mdlB.gpt_neox.final_layer_norm.weight)
    lfbB = f64(mdlB.gpt_neox.final_layer_norm.bias)
    lmhB = f64(mdlB.embed_out.weight)
    LB = []
    for l in range(NLB):
        blk = mdlB.gpt_neox.layers[l]
        at = blk.attention
        ml = blk.mlp
        qkv = f64(at.query_key_value.weight)
        WQ = qkv[:DB]
        WK = qkv[DB:2 * DB]
        WV = qkv[2 * DB:]
        bqkv = f64(at.query_key_value.bias)
        LB.append({'WQ': WQ, 'WK': WK, 'WV': WV, 'bQ': bqkv[:DB], 'bK': bqkv[DB:2 * DB], 'bV': bqkv[2 * DB:], 'WO': f64(at.dense.weight), 'bO': f64(at.dense.bias), 'W1': f64(ml.dense_h_to_4h.weight), 'b1': f64(ml.dense_h_to_4h.bias), 'W2': f64(ml.dense_4h_to_h.weight), 'b2': f64(ml.dense_4h_to_h.bias), 'LN1g': f64(blk.input_layernorm.weight), 'LN1b': f64(blk.input_layernorm.bias), 'LN2g': f64(blk.post_attention_layernorm.weight), 'LN2b': f64(blk.post_attention_layernorm.bias)})
    FFNB = LB[0]['W1'].shape[0]
print(f'  FFN A={FFNA}  FFN B={FFNB}')
print(f'  ✓ Weights extracted')

def ln(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=False):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    W, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)
    return W

def r2(p, t):
    p = np.asarray(p, np.float64).ravel()
    t = np.asarray(t, np.float64).ravel()
    sv = np.var(t)
    return float(1 - np.mean((p - t) ** 2) / sv) if sv > 1e-12 else 1.0

def causal_mask(n):
    return np.triu(np.full((n, n), -1000000000.0), k=1)

def local_mask(n, w):
    m = causal_mask(n)
    for i in range(n):
        for j in range(max(0, i - w)):
            m[i, j] = -1000000000.0
    return m

def rope_neox(x, pos):
    slen, H, hd = x.shape
    half = hd // 2
    theta = 1.0 / 10000 ** (np.arange(0, hd, 2) / hd)
    angles = np.outer(pos, theta)
    cos_a = np.cos(angles)
    sin_a = np.sin(angles)
    x_even = x[:, :, 0::2]
    x_odd = x[:, :, 1::2]
    x_rot_even = x_even * cos_a[:, None, :] - x_odd * sin_a[:, None, :]
    x_rot_odd = x_even * sin_a[:, None, :] + x_odd * cos_a[:, None, :]
    out = np.zeros_like(x)
    out[:, :, 0::2] = x_rot_even
    out[:, :, 1::2] = x_rot_odd
    return out
PROMPTS = ['Once upon a time there was a little girl named', 'The brave knight walked into the dark forest and', 'A small rabbit found a carrot in the garden', 'The old wizard opened his magic book and said', 'One morning the children woke up early to play', 'A friendly dog wagged his tail and ran to', 'The princess smiled and looked out the window at', 'Deep in the woods a tiny house was hidden', 'The little boy found a shiny coin near the', 'Every night the stars came out and the moon']

def tokenize_prompts(prompts, tok, maxlen=24):
    seqs = []
    for p in prompts:
        ids = tok.encode(p)[:maxlen]
        if len(ids) >= 4:
            seqs.append(ids)
    return seqs
seqsA = tokenize_prompts(PROMPTS, tokA)
seqsB = tokenize_prompts(PROMPTS, tokB)
print(f'\n  Shared prompts: {len(PROMPTS)} → A={len(seqsA)} B={len(seqsB)} sequences')

def collect_A(seqs):
    store = {l: {k: [] for k in ['h_in', 'ln1', 'Q', 'K', 'V', 'ctx', 'att', 'hm', 'ln2', 'pre', 'gelu', 'ffn']} for l in range(NLA)}
    for seq in seqs:
        slen = len(seq)
        x = wteA[seq] + wpeA[np.arange(slen)]
        for l in range(NLA):
            lw = LA[l]
            at = attA[l] if l < len(attA) else 'global'
            store[l]['h_in'].append(x.copy())
            ln1 = ln(x, lw['LN1g'], lw['LN1b'])
            store[l]['ln1'].append(ln1)
            Q = ln1 @ lw['WQ'].T
            K_ = ln1 @ lw['WK'].T
            V = ln1 @ lw['WV'].T
            store[l]['Q'].append(Q)
            store[l]['K'].append(K_)
            store[l]['V'].append(V)
            Qh = Q.reshape(slen, HA, hdA).transpose(1, 0, 2)
            Kh = K_.reshape(slen, HA, hdA).transpose(1, 0, 2)
            Vh = V.reshape(slen, HA, hdA).transpose(1, 0, 2)
            mk = local_mask(slen, winA) if at == 'local' else causal_mask(slen)
            heads = []
            for h in range(HA):
                p = softmax(Qh[h] @ Kh[h].T + mk)
                heads.append(p @ Vh[h])
            ctx = np.stack(heads, axis=1).reshape(slen, DA)
            att = ctx @ lw['WO'].T + lw['bO']
            store[l]['ctx'].append(ctx)
            store[l]['att'].append(att)
            hm = x + att
            store[l]['hm'].append(hm)
            ln2 = ln(hm, lw['LN2g'], lw['LN2b'])
            store[l]['ln2'].append(ln2)
            pre = ln2 @ lw['W1'].T + lw['b1']
            store[l]['pre'].append(pre)
            g = gelu(pre)
            store[l]['gelu'].append(g)
            ffn = g @ lw['W2'].T + lw['b2']
            store[l]['ffn'].append(ffn)
            x = hm + ffn
    cat = lambda l: [np.concatenate(store[l][k], 0) for k in store[l]]
    for l in range(NLA):
        keys = list(store[l].keys())
        vals = [np.concatenate(store[l][k], 0) for k in keys]
        for k, v in zip(keys, vals):
            store[l][k] = v
    return store

def collect_B(seqs):
    store = {l: {k: [] for k in ['h_in', 'ln1', 'Q', 'K', 'V', 'ctx', 'att', 'hm', 'ln2', 'pre', 'gelu', 'ffn']} for l in range(NLB)}
    for seq in seqs:
        slen = len(seq)
        x = wteB[seq]
        pos = np.arange(slen)
        for l in range(NLB):
            lw = LB[l]
            store[l]['h_in'].append(x.copy())
            ln1 = ln(x, lw['LN1g'], lw['LN1b'])
            store[l]['ln1'].append(ln1)
            Q = ln1 @ lw['WQ'].T + lw['bQ']
            K_ = ln1 @ lw['WK'].T + lw['bK']
            V = ln1 @ lw['WV'].T + lw['bV']
            Qh = Q.reshape(slen, HB, hdB).transpose(1, 0, 2).transpose(0, 1, 2)
            Kh = K_.reshape(slen, HB, hdB).transpose(1, 0, 2).transpose(0, 1, 2)
            Vh = V.reshape(slen, HB, hdB).transpose(1, 0, 2).transpose(0, 1, 2)
            Qr = np.zeros_like(Qh)
            Kr = np.zeros_like(Kh)
            for h in range(HB):
                q_ = Q.reshape(slen, HB, hdB)[:, h, :].reshape(slen, 1, hdB)
                k_ = K_.reshape(slen, HB, hdB)[:, h, :].reshape(slen, 1, hdB)
                Qr[h] = rope_neox(q_.reshape(slen, 1, hdB), pos)[:, 0, :]
                Kr[h] = rope_neox(k_.reshape(slen, 1, hdB), pos)[:, 0, :]
            store[l]['Q'].append(Q)
            store[l]['K'].append(K_)
            store[l]['V'].append(V)
            mk = causal_mask(slen)
            heads = []
            for h in range(HB):
                p = softmax(Qr[h] @ Kr[h].T + mk)
                heads.append(p @ Vh[h])
            ctx = np.stack(heads, axis=1).reshape(slen, DB)
            att = ctx @ lw['WO'].T + lw['bO']
            store[l]['ctx'].append(ctx)
            store[l]['att'].append(att)
            hm = x + att
            store[l]['hm'].append(hm)
            ln2 = ln(x, lw['LN2g'], lw['LN2b'])
            store[l]['ln2'].append(ln2)
            pre = ln2 @ lw['W1'].T + lw['b1']
            store[l]['pre'].append(pre)
            g = gelu(pre)
            store[l]['gelu'].append(g)
            ffn = g @ lw['W2'].T + lw['b2']
            store[l]['ffn'].append(ffn)
            x = hm + ffn
    for l in range(NLB):
        for k in store[l]:
            store[l][k] = np.concatenate(store[l][k], 0)
    return store
print('\n  Collecting activations from both models...')
sA = collect_A(seqsA)
sB = collect_B(seqsB)
NA = len(sA[0]['h_in'])
NB = len(sB[0]['h_in'])
print(f'  Model A: {NA} token samples  (D={DA})')
print(f'  Model B: {NB} token samples  (D={DB})')
print('\n' + '=' * 70)
print('  STEP 1 — LAW VERIFICATION ON BOTH MODELS')
print('=' * 70)

def verify(store, NL, name):
    print(f'\n  {name}')
    print(f"  {'L':<4} {'WQ':>8} {'WO':>8} {'W1':>8} {'GeLU':>8} {'W2':>8} {'ALL'}")
    print(f"  {'─' * 52}")
    all_ok = True
    for l in range(NL):
        s = store[l]
        n = len(s['ln1'])
        rq = r2(s['ln1'] @ solve(s['ln1'], s['Q']), s['Q'])
        ro = r2(s['ctx'] @ solve(s['ctx'], s['att']), s['att'])
        rw1 = r2(np.c_[s['ln2'], np.ones(n)] @ solve(s['ln2'], s['pre'], True), s['pre'])
        pns = np.c_[s['pre'], s['pre'] ** 2]
        rg = r2(pns @ solve(pns, s['gelu']), s['gelu'])
        rw2 = r2(np.c_[s['gelu'], np.ones(n)] @ solve(s['gelu'], s['ffn'], True), s['ffn'])
        ok = all((v > 0.999 for v in [rq, ro, rw1, rg, rw2]))
        all_ok &= ok
        print(f"  L{l:<3} {rq:>8.4f} {ro:>8.4f} {rw1:>8.4f} {rg:>8.4f} {rw2:>8.4f}  {('✓' if ok else '✗')}")
    print(f"  → {('ALL LAWS PASS ✓' if all_ok else 'SOME LAWS FAIL ✗')}")
    return all_ok
okA = verify(sA, NLA, 'Model A — TinyStories-1M (GPT-Neo, D=64)')
okB = verify(sB, NLB, 'Model B — Pythia-70M    (GPT-NeoX, D=512)')
print('\n' + '=' * 70)
print('  STEP 2 — CROSS-FAMILY PROJECTION ALIGNMENT')
print(f'  P = lstsq(B_acts[D={DB}], A_acts[D={DA}])')
print(f"  Finds linear map: B's {DB}-dim space → A's {DA}-dim space")
print('=' * 70)
n_layers = min(NLA, NLB)
ns = min(NA, NB)
print(f"\n  {'Layer':<8} {'Q: R²(P)':>12} {'att: R²(P)':>12} {'pre: R²(P)':>12} {'ffn: R²(P)':>12}")
print(f"  {'─' * 60}")
PROJS = {}
for l in range(n_layers):
    aA = sA[l]
    aB = sB[l]
    ns_l = min(len(aA['Q']), len(aB['Q']))
    projs = {}
    row = f'  L{l:<7}'
    for mat, kA, kB in [('Q', 'Q', 'Q'), ('att', 'att', 'att'), ('pre', 'pre', 'pre'), ('ffn', 'ffn', 'ffn')]:
        actA = aA[kA][:ns_l]
        actB = aB[kB][:ns_l]
        P = solve(actB, actA, bias=False)
        r2p = r2(actB @ P, actA)
        projs[mat] = P
        row += f' {r2p:>12.6f}'
    PROJS[l] = projs
    print(row)
print('\n' + '=' * 70)
print('  STEP 3 — CROSS-FAMILY SURGERY')
print("  Build A's W matrices using B's knowledge (projected)")
print('  WQ_new: lstsq(A_ln1, B_Q_projected_into_A_space)')
print('=' * 70)
print(f"\n  {'Layer':<8} {'WQ R²':>8} {'WO R²':>8} {'W1 R²':>8} {'W2 R²':>8}")
print(f"  {'─' * 42}")
LA_surgery_WQ = [lw.copy() for lw in LA]
LA_surgery_FFN = [lw.copy() for lw in LA]
LA_surgery_ALL = [lw.copy() for lw in LA]
for l in range(n_layers):
    aA = sA[l]
    aB = sB[l]
    ns_l = min(len(aA['ln1']), len(aB['Q']))
    P_Q = PROJS[l]['Q']
    P_att = PROJS[l]['att']
    P_pre = PROJS[l]['pre']
    P_ffn = PROJS[l]['ffn']
    Q_B_inA = aB['Q'][:ns_l] @ P_Q
    att_B_inA = aB['att'][:ns_l] @ P_att
    pre_B_inA = aB['pre'][:ns_l] @ P_pre
    ffn_B_inA = aB['ffn'][:ns_l] @ P_ffn
    ln1A = aA['ln1'][:ns_l]
    ctxA = aA['ctx'][:ns_l]
    ln2A = aA['ln2'][:ns_l]
    gluA = aA['gelu'][:ns_l]
    n = ns_l
    Wq_new = solve(ln1A, Q_B_inA, bias=False)
    Wo_new = solve(ctxA, att_B_inA, bias=False)
    W1_new = solve(ln2A, pre_B_inA, bias=True)
    W2_new = solve(gluA, ffn_B_inA, bias=True)
    rq = r2(ln1A @ Wq_new, Q_B_inA)
    ro = r2(ctxA @ Wo_new, att_B_inA)
    rw1 = r2(np.c_[ln2A, np.ones(n)] @ W1_new, pre_B_inA)
    rw2 = r2(np.c_[gluA, np.ones(n)] @ W2_new, ffn_B_inA)
    print(f'  L{l:<7} {rq:>8.4f} {ro:>8.4f} {rw1:>8.4f} {rw2:>8.4f}')
    new_lyr = LA[l].copy()
    new_lyr['WQ'] = Wq_new.T
    new_lyr['WO'] = Wo_new.T
    new_lyr['W1'] = W1_new[:-1].T
    new_lyr['b1'] = W1_new[-1]
    new_lyr['W2'] = W2_new[:-1].T
    new_lyr['b2'] = W2_new[-1]
    LA_surgery_WQ[l] = {**LA[l], 'WQ': new_lyr['WQ']}
    LA_surgery_FFN[l] = {**LA[l], 'W1': new_lyr['W1'], 'b1': new_lyr['b1'], 'W2': new_lyr['W2'], 'b2': new_lyr['b2']}
    LA_surgery_ALL[l] = new_lyr
print('\n' + '=' * 70)
print('  STEP 4 — GENERATION: 4 VARIANTS')
print('  A_orig | B_orig | A+B_WQ | A+B_FFN | A+B_ALL')
print('=' * 70)

def genA(layers, prompt, n=40):
    ids = tokA.encode(prompt)
    for _ in range(n):
        seq = ids[-64:]
        slen = len(seq)
        x = wteA[seq] + wpeA[np.arange(slen)]
        for l, lw in enumerate(layers):
            at = attA[l] if l < len(attA) else 'global'
            ln1 = ln(x, lw['LN1g'], lw['LN1b'])
            Q = ln1 @ lw['WQ'].T
            K_ = ln1 @ lw['WK'].T
            V = ln1 @ lw['WV'].T
            Qh = Q.reshape(slen, HA, hdA).transpose(1, 0, 2)
            Kh = K_.reshape(slen, HA, hdA).transpose(1, 0, 2)
            Vh = V.reshape(slen, HA, hdA).transpose(1, 0, 2)
            mk = local_mask(slen, winA) if at == 'local' else causal_mask(slen)
            heads = []
            for h in range(HA):
                p = softmax(Qh[h] @ Kh[h].T + mk)
                heads.append(p @ Vh[h])
            ctx = np.stack(heads, axis=1).reshape(slen, DA)
            att = ctx @ lw['WO'].T + lw['bO']
            hm = x + att
            ln2 = ln(hm, lw['LN2g'], lw['LN2b'])
            pre = ln2 @ lw['W1'].T + lw['b1']
            g = gelu(pre)
            ffn = g @ lw['W2'].T + lw['b2']
            x = hm + ffn
        lf = ln(x, lfgA, lfbA)
        logits = lf @ lmhA.T
        ids.append(int(np.argmax(logits[-1])))
    return tokA.decode(ids)

def genB(prompt, n=40):
    ids = tokB.encode(prompt)
    pos = np.arange(len(ids))
    for _ in range(n):
        seq = ids[-64:]
        slen = len(seq)
        pos = np.arange(slen)
        x = wteB[seq]
        for l, lw in enumerate(LB):
            ln1 = ln(x, lw['LN1g'], lw['LN1b'])
            Q = ln1 @ lw['WQ'].T + lw['bQ']
            K_ = ln1 @ lw['WK'].T + lw['bK']
            V = ln1 @ lw['WV'].T + lw['bV']
            Qr = np.zeros_like(Q.reshape(slen, HB, hdB))
            Kr = np.zeros_like(K_.reshape(slen, HB, hdB))
            for h in range(HB):
                qh = Q.reshape(slen, HB, hdB)[:, h:h + 1, :]
                kh = K_.reshape(slen, HB, hdB)[:, h:h + 1, :]
                Qr[:, h, :] = rope_neox(qh, pos)[:, 0, :]
                Kr[:, h, :] = rope_neox(kh, pos)[:, 0, :]
            Vh = V.reshape(slen, HB, hdB).transpose(1, 0, 2)
            Qrh = Qr.transpose(1, 0, 2)
            Krh = Kr.transpose(1, 0, 2)
            mk = causal_mask(slen)
            heads = []
            for h in range(HB):
                p = softmax(Qrh[h] @ Krh[h].T + mk)
                heads.append(p @ Vh[h])
            ctx = np.stack(heads, axis=1).reshape(slen, DB)
            att = ctx @ lw['WO'].T + lw['bO']
            hm = x + att
            ln2 = ln(x, lw['LN2g'], lw['LN2b'])
            pre = ln2 @ lw['W1'].T + lw['b1']
            g = gelu(pre)
            ffn = g @ lw['W2'].T + lw['b2']
            x = hm + ffn
        lf = ln(x, lfgB, lfbB)
        logits = lf @ lmhB.T
        ids.append(int(np.argmax(logits[-1])))
    return tokB.decode(ids)
TEST = ['Once upon a time there was a little girl', 'The brave knight walked into the dark forest', 'A small rabbit found a carrot and']
CLIP = 120
for prompt in TEST:
    print(f'\n  Prompt: "{prompt}"')
    print(f"  {'─' * 65}")
    tA = genA(LA, prompt)
    tB = genB(prompt)
    tWQ = genA(LA_surgery_WQ, prompt)
    tFF = genA(LA_surgery_FFN, prompt)
    tAL = genA(LA_surgery_ALL, prompt)
    print(f'  [A  orig-1M ]: {tA[len(prompt):len(prompt) + CLIP]}')
    print(f'  [B  orig-70M]: {tB[len(prompt):len(prompt) + CLIP]}')
    print(f'  [A + B_WQ   ]: {tWQ[len(prompt):len(prompt) + CLIP]}')
    print(f'  [A + B_FFN  ]: {tFF[len(prompt):len(prompt) + CLIP]}')
    print(f'  [A + B_ALL  ]: {tAL[len(prompt):len(prompt) + CLIP]}')
print('\n' + '=' * 70)
print('  CROSS-FAMILY SURGERY VERDICT')
print('=' * 70)
print(f"\n  Models:\n    A = TinyStories-1M  GPT-Neo   D=64  children's stories\n    B = Pythia-70M      GPT-NeoX  D=512 internet text (The Pile)\n\n  Differences:\n    Architecture family:  GPT-Neo ≠ GPT-NeoX         ✓ different\n    Position encoding:    Learned WPE ≠ RoPE          ✓ different\n    Attention mechanism:  local+global ≠ full causal  ✓ different\n    Training data:        fairy tales ≠ internet       ✓ different\n    Dimension:            D=64 ≠ D=512                ✓ 8x different\n    Vocab:                {VSA} ≠ {VSB}          ✓ different\n\n  Laws R²=1.000: A={('✓' if okA else '✗')}  B={('✓' if okB else '✗')}\n\n  Projection P (B→A, {DB}→{DA}):\n    R² measures linearity of cross-family alignment\n    If R² ≈ 1.000 → different family W-spaces are linearly related\n    This would be LAW 45: Cross-family alignment is linear.\n\n  Surgery results: see generation above.\n  If A+B_ALL generates coherent text → intelligence transferred.\n")
print('=' * 70 + '\n')
