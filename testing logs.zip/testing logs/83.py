import numpy as np, math
print('\n' + '=' * 60)
print('  W-KERNEL SENTENCE PROBE')
print('  One sentence. Find natural space.')
print('=' * 60)
SENTENCES = {'simple': 'the cat sat on the mat and looked at the rat', 'story': 'the brave knight rode across the wide open forest', 'nature': 'birds fly high above the green rolling hills each morning', 'numbers': 'zero one two three four five six seven eight nine ten'}

def run_sentence(name, sentence, K=4, L=3):
    print(f"\n{'─' * 60}")
    print(f"  SENTENCE: '{sentence}'")
    chars = sorted(set(sentence))
    c2i = {c: i for i, c in enumerate(chars)}
    i2c = {i: c for c, i in c2i.items()}
    VS = len(chars)
    toks = [c2i[c] for c in sentence]
    N = len(toks)
    D = VS
    WTE = np.eye(VS, dtype=np.float64)
    tri_i, tri_j = np.triu_indices(D)
    D_q = D * (D + 1) // 2

    def phi_b(X):
        return X[:, tri_i] * X[:, tri_j]

    def phi(x):
        return x[tri_i] * x[tri_j]

    def pinv_s(Ph, R, lam=1e-06):
        A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
        return np.linalg.solve(A, Ph.T @ R)
    M = N - K
    y = np.array(toks[K:])
    X0 = np.zeros((M, D))
    for i in range(K, N):
        X0[i - K] = WTE[toks[i - K:i]].mean(0)
    T = WTE[y]
    print(f'  Vocab={VS}  Tokens={N}  K={K}  D_quad={D_q}  N/D={M}/{D_q}={M / D_q:.1f}x')
    ctx_example = sentence[:K]
    x_ex = np.array([c2i[c] for c in ctx_example])
    mean_ex = WTE[x_ex].mean(0)
    nonzero = [(chars[i], f'{mean_ex[i]:.2f}') for i in np.where(mean_ex > 0)[0]]
    print(f"  Context '{ctx_example}' mean: {nonzero}")
    ctx_rev = ctx_example[::-1]
    x_rev = np.array([c2i[c] for c in ctx_rev])
    mean_rev = WTE[x_rev].mean(0)
    same = np.allclose(mean_ex, mean_rev)
    print(f"  Context '{ctx_rev}' mean: SAME={same}  ← ORDER LOST={same}")

    def fwd(X, Wl):
        xs = [X.copy()]
        for W in Wl:
            xs.append(xs[-1] + phi_b(xs[-1]) @ W)
        return xs
    W_layers = [np.zeros((D_q, D)) for _ in range(L)]

    def get_acc(Wl):
        x = fwd(X0, Wl)[-1]
        return 100 * np.mean(np.argmax(x @ WTE.T, 1) == y)
    best_a = get_acc(W_layers)
    best_W = [w.copy() for w in W_layers]
    for rnd in range(10):
        imp = False
        for l in range(L):
            xs = fwd(X0, W_layers)
            R = T - xs[l]
            Wn = pinv_s(phi_b(xs[l]), R)
            Wt = [w.copy() for w in W_layers]
            Wt[l] = Wn
            a = get_acc(Wt)
            if a > best_a:
                best_a = a
                W_layers = Wt
                best_W = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W_layers = best_W
    print(f'  Train acc={best_a:.1f}%')

    def predict_n(seed_str, n_steps, greedy=True):
        ids = [c2i[c] for c in seed_str if c in c2i]
        generated = []
        for _ in range(n_steps):
            ctx = list(ids[-K:]) if len(ids) >= K else [0] * (K - len(ids)) + list(ids)
            x = WTE[ctx].mean(0).copy()
            for W in W_layers:
                x = x + phi(x) @ W
            lg = x @ WTE.T
            if greedy:
                pred = int(np.argmax(lg))
            else:
                lg -= lg.max()
                p = np.exp(lg)
                p /= p.sum()
                pred = int(np.random.choice(VS, p=p))
            ids.append(pred)
            generated.append(i2c[pred])
        return ''.join(generated)
    words = sentence.split()
    half = len(sentence) // 2
    while half < len(sentence) and sentence[half] != ' ':
        half += 1
    seed = sentence[:half]
    true_rest = sentence[half:]
    print(f"\n  Seed:      '{seed}'")
    print(f"  True rest: '{true_rest}'")
    for n_steps in [1, 2, 3, 5, len(true_rest)]:
        if n_steps > len(true_rest):
            continue
        gen = predict_n(seed, n_steps, greedy=True)
        true = true_rest[:n_steps]
        matches = sum((a == b for a, b in zip(gen, true)))
        pct = 100 * matches / n_steps if n_steps > 0 else 0
        mark = '✓' if matches == n_steps else f'{matches}/{n_steps}'
        print(f"  n={n_steps:2d}: gen='{gen}'  true='{true}'  {mark} ({pct:.0f}%)")
    print(f'\n  ORDER LOSS TEST (mean context = same for anagrams):')
    test_pairs = [(sentence[:K], sentence[K:K + 1])]
    real_ctx = list(sentence[:K])
    shuf_ctx = sorted(real_ctx)
    print(f"  real  context '{sentence[:K]}' → pred='{predict_n(sentence[:K], 1)}'  true='{sentence[K]}'")
    print(f"  sorted context '{''.join(shuf_ctx)}' → pred='{predict_n(''.join(shuf_ctx), 1)}'")
    same_pred = predict_n(sentence[:K], 1) == predict_n(''.join(shuf_ctx), 1)
    print(f'  Same prediction despite different order? {same_pred}  ← ORDER BLIND={same_pred}')
    return best_a
results = {}
for name, sent in SENTENCES.items():
    results[name] = run_sentence(name, sent)
print(f"\n{'=' * 60}")
print(f'  SUMMARY — ACC AND ORDER LOSS:')
for name, acc in results.items():
    print(f'  {name:10s}: acc={acc:.1f}%')
print(f"\n  KEY FINDING:\n  Context mean = ORDER BLIND.\n  'the ' and ' eht' give SAME x_0.\n  Numbers succeed because [3,4,5,6] has NO repeated digits.\n  Mean is unique for each position.\n  \n  Language fails because 't','h','e' repeat everywhere.\n  Mean of ['t','h','e','r'] = mean of ['r','e','h','t'].\n  W-Kernel cannot tell them apart.\n  \n  SOLUTION = POSITIONAL ENCODING (not averaging):\n    x_0 = concat(WTE[t-K], WTE[t-K+1], ..., WTE[t-1])\n    = K*VS dimensional (K*28 = 168 for K=6)\n    = ORDER PRESERVED\n    \n  This is what a real transformer does.\n  W-Kernel + concat context = full positional awareness.\n  N/D_quad = 5865 / (168*169/2) = 5865/14196 = 0.4x  TOO SMALL.\n  \n  Need either: smaller K, or more text, or D-reduction first.\n")
