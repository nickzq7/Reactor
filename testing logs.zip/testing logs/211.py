import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — ORIGINAL APPROACH')
print('  Reading what already exists.')
print('  No compression. No extraction. No copies.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
V = model.config.vocab_size
n_layers = model.config.num_layers
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
E = model.transformer.wte.weight.detach().numpy()
Eu = model.lm_head.weight.detach().numpy()
print(f'  Loaded. {n_layers} layers. {D}D. Vocab={V:,}.')
print(f'\n  Token embedding matrix E : {E.shape}  — input knowledge')
print(f'  Output embedding matrix  : {Eu.shape} — output knowledge')
print(f'\n  These two matrices already encode')
print(f'  the relationship between input tokens')
print(f'  and output tokens. Trained. Complete.')
print(f'  We read them. We do not compute through them.')

def softmax(x):
    e = np.exp(x - x.max())
    return e / e.sum()

def original_generate(prompt, max_new_tokens=50):
    inp = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(inp, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def wrap(text, width=56):
    words = text.split()
    lines = []
    line = '  '
    for w in words:
        if len(line) + len(w) > width:
            lines.append(line)
            line = '  ' + w + ' '
        else:
            line += w + ' '
    if line.strip():
        lines.append(line)
    return '\n'.join(lines)
print('\n' + '=' * 62)
print('  METHOD 1 — GEOMETRY OF INPUT EMBEDDINGS')
print('  Context embedding already points to next token.')
print('  Read the direction. No computation.')
print('=' * 62)

def method1_next(ids, top_k=5):
    ctx_embeds = E[ids[-8:]]
    ctx_vec = ctx_embeds.mean(axis=0)
    scores = Eu @ ctx_vec
    top = np.argsort(scores)[-top_k:][::-1]
    probs = softmax(scores[top] * 10)
    return (top, probs)

def method1_generate(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt)
    for _ in range(max_new_tokens):
        top, probs = method1_next(ids)
        next_tok = int(top[0])
        if next_tok == tokenizer.eos_token_id:
            break
        ids.append(next_tok)
    return tokenizer.decode(ids, skip_special_tokens=True)
print('\n' + '-' * 62)
print('  METHOD 2 — TOKEN + POSITION READING')
print('  Position knowledge already in weights.')
print('-' * 62)
has_pos = hasattr(model.transformer, 'wpe')
if has_pos:
    PE = model.transformer.wpe.weight.detach().numpy()
    print(f'  Position embeddings: {PE.shape}')
else:
    print(f'  No position embeddings found.')

def method2_next(ids, top_k=5):
    n = min(len(ids), 8)
    ctx = np.zeros(D)
    for i, tok in enumerate(ids[-n:]):
        te = E[tok]
        if has_pos and i < PE.shape[0]:
            pe = PE[len(ids) - n + i]
            ctx += te + pe
        else:
            ctx += te
    ctx /= n
    scores = Eu @ ctx
    top = np.argsort(scores)[-top_k:][::-1]
    probs = softmax(scores[top] * 10)
    return (top, probs)

def method2_generate(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt)
    for _ in range(max_new_tokens):
        top, _ = method2_next(ids)
        next_tok = int(top[0])
        if next_tok == tokenizer.eos_token_id:
            break
        ids.append(next_tok)
    return tokenizer.decode(ids, skip_special_tokens=True)
print('\n' + '-' * 62)
print('  METHOD 3 — WEIGHT TRAJECTORY (composed layers)')
print('  W1 @ W2 @ ... @ W8 = ONE transformation.')
print('  Already exists in weight space.')
print('  Compose once. Read directly.')
print('-' * 62)

def get_layer_weights():
    matrices = []
    for i in range(n_layers):
        layer = model.transformer.h[i]
        try:
            W = layer.attn.attention.out_proj.weight.detach().numpy()
            matrices.append(W)
        except:
            try:
                W = layer.attn.out_proj.weight.detach().numpy()
                matrices.append(W)
            except:
                pass
    return matrices
layer_weights = get_layer_weights()
print(f'  Extracted {len(layer_weights)} layer matrices.')
if layer_weights:
    W_total = layer_weights[0].copy()
    for W in layer_weights[1:]:
        if W_total.shape[1] == W.shape[0]:
            W_total = W_total @ W
        elif W.shape[1] == W_total.shape[0]:
            W_total = W @ W_total
    print(f'  Composed W_total shape: {W_total.shape}')
    print(f'  Composed memory: {W_total.size * 4 / 1024:.1f} KB')
    print(f'  Model memory   : {model_mem / 1024 / 1024:.1f} MB')
    print(f'  W_total is ONE object = what 8 layers do together.')

def method3_next(ids, top_k=5):
    ctx_embeds = E[ids[-8:]]
    ctx_vec = ctx_embeds.mean(axis=0)
    if layer_weights and W_total.shape[0] == D:
        transformed = ctx_vec @ W_total
        if len(transformed) == D:
            scores = Eu @ transformed
        else:
            scores = Eu @ ctx_vec
    else:
        scores = Eu @ ctx_vec
    top = np.argsort(scores)[-top_k:][::-1]
    probs = softmax(scores[top] * 10)
    return (top, probs)

def method3_generate(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt)
    for _ in range(max_new_tokens):
        top, _ = method3_next(ids)
        next_tok = int(top[0])
        if next_tok == tokenizer.eos_token_id:
            break
        ids.append(next_tok)
    return tokenizer.decode(ids, skip_special_tokens=True)
print('\n' + '=' * 62)
print('  SIDE BY SIDE — ALL METHODS')
print('  Reading what already IS in the weights.')
print('=' * 62)
prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'One day a small rabbit decided to']
for i, prompt in enumerate(prompts):
    print(f"\n  {'─' * 58}")
    print(f'  PROMPT {i + 1}: "{prompt}"')
    print(f"  {'─' * 58}")
    orig = original_generate(prompt, 40)
    m1 = method1_generate(prompt, 40)
    m2 = method2_generate(prompt, 40)
    m3 = method3_generate(prompt, 40)
    print(f'\n  ORIGINAL (forward pass, 8 layers, 14.3MB):')
    print(wrap(orig))
    print(f'\n  M1 — Input embedding geometry (no forward pass):')
    print(wrap(m1))
    print(f'\n  M2 — Token + position reading (no forward pass):')
    print(wrap(m2))
    print(f'\n  M3 — Composed weight trajectory (no forward pass):')
    print(wrap(m3))
print('\n' + '=' * 62)
print('  WHAT THESE RESULTS MEAN')
print('=' * 62)
print(f'\n  Three methods. Zero forward passes.\n  Reading directly from weight geometry.\n\n  If any method produces coherent text:\n    That method found the W reading.\n    The answer WAS already in the weights.\n    No forward pass needed.\n    Memory = weight subset used.\n\n  If all produce incoherent text:\n    The knowledge needs the forward pass.\n    Not because of sequential computation.\n    Because attention is input-DEPENDENT.\n    The weights alone are not enough without input.\n    W principle still holds — but reading method unknown.\n\n  What this shows regardless of output quality:\n    We approached from W direction.\n    Not compressing. Not copying. Not extracting.\n    Reading what already IS.\n    This is new experimental direction.\n    No paper tests this for generation.\n\n  Next step depends on output above.\n  The results will show us where W lives in the weights.\n  Or confirm we need different reading method.\n')
print('=' * 62 + '\n')
