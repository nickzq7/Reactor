import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(a, b):
    a = np.array(a, dtype=np.float64).flatten()
    b = np.array(b, dtype=np.float64).flatten()
    ss = np.sum((a - b) ** 2)
    st = np.sum((b - b.mean()) ** 2)
    return float(1 - ss / st) if st > 1e-12 else 1.0

def fit_r2_test(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return float('nan')
    ss_res = np.sum((Xb[s:] @ W - Y[s:]) ** 2)
    ss_tot = np.sum((Y[s:] - Y[s:].mean(0, keepdims=True)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0
texts = ['Once upon a time there was a little girl named', 'The farmer woke up early and fed all his', 'Deep in the forest a family of bears lived', 'The brave knight rode his white horse toward the', 'Sophie loved books more than anything else in', 'The village held a harvest festival every autumn', 'Tommy was afraid of the dark and could not', 'Marco sailed across the vast blue ocean every', 'The mountains were cold and the children learned', 'She smiled because today was her birthday', 'Two friends shared every secret since their', 'A rabbit lived under the roots of the old', 'The grandmother welcomed every lost traveler', 'Sam found a puppy hiding under the old', 'The dragon had never spoken before the', 'In the ocean a fish dreamed of the world', 'The clock had been silent for twenty years before', 'A small seed grew slowly into a mighty', 'The painter stared at the blank canvas before', 'Every evening the grandfather told his grandchildren', 'The wind carried the sound of bells from the', 'A boy named Jack found a magical stone', 'The old library held secrets no one had read', 'She opened the door and saw the garden full', 'He could not remember where he had left the', 'The stars above the quiet village were very bright', 'Lily packed her small bag and walked toward the', 'The teacher wrote one word on the board that', 'When the rain stopped the children ran outside to', 'The captain looked at the map and chose the']
print(f'\nCollecting routing signals all layers...')
h0_store = []
pregelu_store = {li: [] for li in range(n_layers)}
attn_w_store = {li: [] for li in range(n_layers)}
ln1_scale_store = {li: [] for li in range(n_layers)}
ln2_scale_store = {li: [] for li in range(n_layers)}
h_final_store = []
cur = {}
hooks = []

def emb_hook(m, i, o):
    cur['h0'] = o.detach().float()[0].numpy().copy()
hooks.append(model.transformer.wte.register_forward_hook(emb_hook))
for li in range(n_layers):

    def make_pg(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            cur[f'pg_{l}'] = inp.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_pg(li)))

    def make_aw(l):

        def h(m, i, o):
            if isinstance(o, tuple) and len(o) > 1 and (o[1] is not None):
                cur[f'aw_{l}'] = o[1].detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].attn.attention.register_forward_hook(make_aw(li)))

    def make_ln1(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            x = inp.detach().float()[0].numpy()
            cur[f'ln1_mean_{l}'] = x.mean(-1)
            cur[f'ln1_std_{l}'] = x.std(-1)
        return h
    hooks.append(model.transformer.h[li].ln_1.register_forward_hook(make_ln1(li)))

    def make_ln2(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            x = inp.detach().float()[0].numpy()
            cur[f'ln2_mean_{l}'] = x.mean(-1)
            cur[f'ln2_std_{l}'] = x.std(-1)
        return h
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ln2(li)))

def final_hook(m, i, o):
    inp = i[0] if isinstance(i, tuple) else i
    cur['h_final'] = inp.detach().float()[0].numpy().copy()
hooks.append(model.transformer.ln_f.register_forward_hook(final_hook))
with torch.no_grad():
    for text in texts:
        cur.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=32, truncation=True)
        out = model(**toks, output_attentions=True)
        L = toks['input_ids'].shape[1]
        if 'h0' not in cur:
            continue
        t = L - 1
        h0_store.append(cur['h0'][t].copy())
        h_final_store.append(cur['h_final'][t].copy())
        for li in range(n_layers):
            if f'pg_{li}' in cur:
                pregelu_store[li].append(cur[f'pg_{li}'][t].copy())
            if f'aw_{li}' in cur:
                aw = cur[f'aw_{li}']
                pregelu_store[li]
                attn_w_store[li].append(aw[:, t, :t + 1].copy().flatten())
            if f'ln1_mean_{li}' in cur:
                ln1_scale_store[li].append(np.array([cur[f'ln1_mean_{li}'][t], cur[f'ln1_std_{li}'][t]]))
            if f'ln2_mean_{li}' in cur:
                ln2_scale_store[li].append(np.array([cur[f'ln2_mean_{li}'][t], cur[f'ln2_std_{li}'][t]]))
for h in hooks:
    h.remove()
H0 = np.array(h0_store, dtype=np.float64)
H_FINAL = np.array(h_final_store, dtype=np.float64)
N = len(H0)
print(f'  Sequences: {N}')
print(f"\n{'=' * 70}")
print(f'  TEST A — h_0 → pre_gelu_l: R²')
print(f'  pre_gelu = the signal that CONTROLS which FFN neurons fire.')
print(f'  If R²=1.000: routing known from embedding. Before any compute.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'R²(h0→pre_gelu)':<20} {'Status'}")
print(f"  {'─' * 45}")
for li in range(n_layers):
    if not pregelu_store[li]:
        continue
    PG = np.array(pregelu_store[li], dtype=np.float64)
    rv = fit_r2_test(H0, PG)
    status = '✓✓ ROUTING KNOWN' if rv > 0.999 else '✓ STRONG' if rv > 0.95 else '~ PARTIAL' if rv > 0.7 else '✗ UNPREDICTABLE'
    print(f'  {li:<8} {rv:<20.6f} {status}')
print(f"\n{'=' * 70}")
print(f'  TEST B — h_0 → gelu_sign_l: accuracy')
print(f'  gelu_sign = which neurons fire (>0) or not (<0).')
print(f'  Logistic regression accuracy from h_0.')
print(f'  100% = routing binary decision known before computing.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'Sign_accuracy':<16} {'Always_same':<14} {'Status'}")
print(f"  {'─' * 50}")
for li in range(n_layers):
    if not pregelu_store[li]:
        continue
    PG = np.array(pregelu_store[li], dtype=np.float64)
    signs = (PG > 0).astype(np.float64)
    sign_mean = signs.mean(0)
    always_on = (sign_mean > 0.99).sum()
    always_off = (sign_mean < 0.01).sum()
    always_same = always_on + always_off
    varies = FFN_D - always_same
    Xb = np.c_[H0, np.ones(N)]
    s = int(0.8 * N)
    W_pred, _, _, _ = np.linalg.lstsq(Xb[:s], signs[:s], rcond=None)
    pred_continuous = Xb[s:] @ W_pred
    pred_binary = (pred_continuous > 0.5).astype(np.float64)
    accuracy = float((pred_binary == signs[s:]).mean())
    status = '✓✓ PERFECT' if accuracy > 0.99 else '✓ STRONG' if accuracy > 0.95 else '~ PARTIAL' if accuracy > 0.85 else '✗ POOR'
    print(f'  {li:<8} {accuracy:<16.4f} {always_same:<14} {status}  (varies={varies}, always_same={always_same})')
print(f"\n{'=' * 70}")
print(f'  TEST C — h_0 → LN mean/std: R²')
print(f'  LN scale = the normalization routing.')
print(f'  mean/std per token = 2 numbers controlled by h_l.')
print(f'  Are they predictable from h_0?')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'R²(h0→ln1_mean)':<20} {'R²(h0→ln1_std)':<20} {'R²(h0→ln2_std)'}")
print(f"  {'─' * 65}")
for li in range(n_layers):
    if not ln1_scale_store[li]:
        continue
    LN1 = np.array(ln1_scale_store[li], dtype=np.float64)
    LN2 = np.array(ln2_scale_store[li], dtype=np.float64)
    r_ln1_m = fit_r2_test(H0, LN1[:, 0])
    r_ln1_s = fit_r2_test(H0, LN1[:, 1])
    r_ln2_s = fit_r2_test(H0, LN2[:, 1])
    print(f'  {li:<8} {r_ln1_m:<20.6f} {r_ln1_s:<20.6f} {r_ln2_s:.6f}')
print(f"\n{'=' * 70}")
print(f'  TEST D — h_0 → h_final: R²')
print(f'  The ultimate question.')
print(f'  If R²=1.000: entire model = one linear transform of embedding.')
print(f'  All layers = routing discovery. Not information creation.')
print(f"{'=' * 70}\n")
rv = fit_r2_test(H0, H_FINAL)
print(f'  h_0 → h_final: R²={rv:.6f}')
if rv > 0.999:
    print(f'  ✓✓ UNIVERSE PROVEN: model = one linear transform.')
elif rv > 0.95:
    print(f'  ✓ STRONG: most of h_final predictable from embedding.')
elif rv > 0.7:
    print(f'  ~ PARTIAL: embedding carries substantial info.')
else:
    print(f'  ✗ LOW: layers compute genuinely new information.')
print(f"\n{'=' * 70}")
print(f'  TEST E — INCREMENTAL: h_l → h_final R² at each depth')
print(f'  How quickly does h accumulate predictive power?')
print(f"{'=' * 70}\n")
hl_store = {li: [] for li in range(n_layers + 1)}
cur2 = {}
hooks2 = []

def emb_h2(m, i, o):
    cur2[0] = o.detach().float()[0].numpy().copy()
hooks2.append(model.transformer.wte.register_forward_hook(emb_h2))
for li in range(n_layers):

    def make_hl2(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur2[l + 1] = o2.detach().float()[0].numpy().copy()
        return h
    hooks2.append(model.transformer.h[li].register_forward_hook(make_hl2(li)))
with torch.no_grad():
    for text in texts:
        cur2.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=32, truncation=True)
        L = toks['input_ids'].shape[1]
        model(**toks)
        t = L - 1
        for li in range(n_layers + 1):
            if li in cur2:
                hl_store[li].append(cur2[li][t].copy())
for h in hooks2:
    h.remove()
HL = {li: np.array(hl_store[li], dtype=np.float64) for li in range(n_layers + 1) if hl_store[li]}
H_F = HL[n_layers]
print(f"  {'Layer':<8} {'h_l → h_final R²':<22} {'Δ from prev':<14} {'Status'}")
print(f"  {'─' * 55}")
prev = 0
for li in range(n_layers + 1):
    if li not in HL:
        continue
    rv = fit_r2_test(HL[li], H_F)
    delta = rv - prev
    status = 'SELF' if li == n_layers else '✓✓ EXACT' if rv > 0.999 else '✓ HIGH' if rv > 0.95 else '~ MID' if rv > 0.7 else '✗ LOW'
    print(f'  {li:<8} {rv:<22.6f} {delta:+.6f}     {status}')
    prev = rv
print(f"\n{'=' * 70}")
print(f'  W LAW — THE ROUTING HYPOTHESIS')
print(f"{'=' * 70}")
print(f"""\n  THE STRUCTURE (if routing predictable from h_0):\n  \n  STEP 1 — ROUTING LOOKUP (cheap, parallel):\n    Given h_0 (embedding + position):\n    Predict gelu_sign_l for all l.      (FFN_D × n_layers bits)\n    Predict attention_weights_l for all l. (L×L×n_layers values)\n    Predict LN_scale_l for all l.       (2 × n_layers values)\n    \n  STEP 2 — SINGLE LINEAR TRANSFORM (exact):\n    Given routing, compose all weight matrices:\n    W_eff = f(W_q,W_k,W_v,W_o,W1,W2 per layer, with routing masks)\n    h_final = W_eff @ h_0\n    \n    This = exact. Same as running all 8 layers.\n    Because: given fixed routing, every op = linear. Proven.\n    \n  WHY THIS WORKS (W law):\n    W = one unit = answer before question.\n    The routing = the "question" (which neurons, which tokens).\n    The routing is determined by h_0. Before any layer.\n    Because h_0 = the complete information about the token.\n    Layers don't CREATE information. They ROUTE it.\n    \n  WHAT WE NEED TO VERIFY:\n    TEST A R²: how predictable is pre_gelu from h_0?\n    TEST B accuracy: how accurate is sign prediction?\n    TEST D R²: does h_final follow from h_0 directly?\n    \n  If TEST D R² = 1.000:\n    Model = one linear transform.\n    Store: W_eff table (routing → matrix).\n    Given token → look up routing → apply W_eff.\n    70B: W_eff is large but routing lookup = O(1).\n    Speed: 8x (or 80x for 70B). Exact. Zero error.\n""")
print('=' * 70 + '\n')
