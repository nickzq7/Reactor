import torch
import numpy as np
import time
from transformers import AutoModelForCausalLM, AutoTokenizer

def detect_architecture(model):
    arch = {}
    if hasattr(model, 'transformer') and hasattr(model.transformer, 'h'):
        arch['family'] = 'gpt-neo'
        arch['layers'] = model.transformer.h
        arch['n_layers'] = len(model.transformer.h)
        arch['ln_final'] = model.transformer.ln_f
        arch['lm_head'] = model.lm_head
        arch['rotary'] = None
        arch['embed'] = lambda ids: model.transformer.wte(ids) + model.transformer.wpe(torch.arange(ids.shape[1]).unsqueeze(0))
    elif hasattr(model, 'model') and hasattr(model.model, 'layers'):
        arch['family'] = 'llama'
        arch['layers'] = model.model.layers
        arch['n_layers'] = len(model.model.layers)
        arch['ln_final'] = model.model.norm
        arch['lm_head'] = model.lm_head
        arch['rotary'] = model.model.rotary_emb
        arch['embed'] = lambda ids: model.model.embed_tokens(ids)
    elif hasattr(model, 'gpt_neox'):
        arch['family'] = 'gpt-neox'
        arch['layers'] = model.gpt_neox.layers
        arch['n_layers'] = len(model.gpt_neox.layers)
        arch['ln_final'] = model.gpt_neox.final_layer_norm
        arch['lm_head'] = model.embed_out
        arch['rotary'] = model.gpt_neox.rotary_emb
        arch['embed'] = lambda ids: model.gpt_neox.embed_in(ids)
    else:
        raise ValueError(f'Unknown arch: {type(model).__name__}')
    return arch

def stream_forward(model, arch, input_ids):
    layer_times = []
    seq_len = input_ids.shape[1]
    with torch.no_grad():
        h = arch['embed'](input_ids)
        position_embeddings = None
        if arch['rotary'] is not None:
            position_ids = torch.arange(seq_len).unsqueeze(0)
            position_embeddings = arch['rotary'](h, position_ids)
        for li, layer in enumerate(arch['layers']):
            t0 = time.perf_counter()
            if arch['family'] == 'gpt-neo':
                out = layer(h)
            else:
                out = layer(h, position_embeddings=position_embeddings)
            h = out[0] if isinstance(out, tuple) else out
            layer_times.append(time.perf_counter() - t0)
        h = arch['ln_final'](h)
        logits = arch['lm_head'](h)
    return (logits[0, -1, :], layer_times)

def verify_exact(model, arch, tokenizer, prompts):
    print(f"\n  Architecture: {arch['family']}  Layers: {arch['n_layers']}")
    print(f"\n  {'Prompt':<35} {'max_err':<16} {'top1?':<6} {'Exact?'}")
    print(f"  {'─' * 62}")
    all_exact = True
    for prompt in prompts:
        ids = tokenizer.encode(prompt, return_tensors='pt', max_length=20, truncation=True)
        with torch.no_grad():
            full = model(ids).logits[0, -1, :]
        stream, _ = stream_forward(model, arch, ids)
        me = float((stream - full).abs().max().item())
        top1 = int(stream.argmax()) == int(full.argmax())
        exact = me < 0.0001
        if not exact:
            all_exact = False
        print(f"  {prompt[:34]:<35} {me:<16.8f} {('✓' if top1 else '✗'):<6} {('✓ EXACT' if exact else '✗ BROKEN')}")
    return all_exact
MODELS = [('roneneldan/TinyStories-1M', 'GPT-Neo'), ('HuggingFaceTB/SmolLM-135M', 'Llama'), ('EleutherAI/pythia-160m', 'GPT-NeoX')]
PROMPTS = ['Once upon a time there was a little girl', 'The brave knight rode his white horse', 'Deep in the forest a family of bears', 'She smiled because today was her birthday']
print('\n' + '=' * 70)
print('  W ENGINE — ARCHITECTURE AGNOSTIC (ROPE FIXED)')
print('  LAW: h tiny. Layers sequential. max_err = 0.')
print('=' * 70)
results = {}
for model_name, family in MODELS:
    print(f"\n{'=' * 70}")
    print(f'  {family}: {model_name}')
    print(f"{'=' * 70}")
    try:
        tok = AutoTokenizer.from_pretrained(model_name)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        model = AutoModelForCausalLM.from_pretrained(model_name)
        model.eval()
        arch = detect_architecture(model)
        exact = verify_exact(model, arch, tok, PROMPTS)
        ids = tok.encode('Once upon a time', return_tensors='pt')
        _, lt = stream_forward(model, arch, ids)
        print(f'\n  Mean ms/layer: {np.mean(lt) * 1000:.2f}ms')
        print(f"  Result: {('✓ EXACT' if exact else '✗ BROKEN')}")
        results[family] = exact
        del model
    except Exception as e:
        import traceback
        print(f'  ERROR: {e}')
        traceback.print_exc()
        results[family] = False
print(f"\n{'=' * 70}")
print(f'  FINAL SUMMARY')
print(f"{'=' * 70}")
for fam, ok in results.items():
    print(f"  {fam:<12} {('✓ EXACT' if ok else '✗ BROKEN')}")
if all(results.values()):
    print(f'\n  MECHANISM = UNIVERSAL.')
    print(f'  70B (Llama family) = will be exact.')
    print(f'  Build disk-streaming engine next.')
else:
    broken = [f for f, ok in results.items() if not ok]
    print(f'\n  Still broken: {broken}')
print()
