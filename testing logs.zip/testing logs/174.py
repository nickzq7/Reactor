import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — PERFECT GENERATION (TOKEN-LEVEL)')
print('  No architectural cheating. Pure linear progression.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
CTX = 8

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and']
print(f'\n  Generating sample text for pure W extraction...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.8, 1.0]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=20, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Extracting W_att and W_ffn for all {n_layers} layers...')
W_matrices = {}
with torch.no_grad():
    for layer_idx in range(n_layers):
        block = model.transformer.h[layer_idx]
        Wq = block.attn.attention.q_proj.weight.detach().numpy().T
        Wk = block.attn.attention.k_proj.weight.detach().numpy().T
        Wv = block.attn.attention.v_proj.weight.detach().numpy().T
        ATT_IN, ATT_OUT, FFN_IN, FFN_OUT = ([], [], [], [])
        for text in all_texts:
            tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
            ids = tokens['input_ids']
            L = ids.shape[1]
            if L < CTX:
                continue
            out = model(**tokens, output_hidden_states=True)
            hs = out.hidden_states
            for start in range(L - CTX + 1):
                x_t = hs[layer_idx][0, start:start + CTX]
                ln1 = block.ln_1(x_t).numpy()
                Q_full, K_full, V_full = (ln1 @ Wq, ln1 @ Wk, ln1 @ Wv)
                head_feats = []
                for h in range(n_heads):
                    s_h, e_h = (h * head_dim, (h + 1) * head_dim)
                    Q_h, K_h, V_h = (Q_full[:, s_h:e_h], K_full[:, s_h:e_h], V_full[:, s_h:e_h])
                    scr = Q_h @ K_h.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    att_h = softmax(scr + msk)
                    head_feats.append(att_h @ V_h)
                att_in_unflat = np.concatenate(head_feats, axis=1)
                att_out_unflat = block.attn(block.ln_1(x_t).unsqueeze(0))[0].squeeze(0).numpy()
                x2 = x_t.numpy() + att_out_unflat
                ln2 = block.ln_2(torch.tensor(x2, dtype=torch.float32)).numpy()
                pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
                act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
                ffn_out_unflat = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).numpy()
                ATT_IN.append(att_in_unflat)
                ATT_OUT.append(att_out_unflat)
                FFN_IN.append(act)
                FFN_OUT.append(ffn_out_unflat)
        ATT_IN_flat = np.array(ATT_IN).reshape(-1, D)
        ATT_OUT_flat = np.array(ATT_OUT).reshape(-1, D)
        FFN_IN_flat = np.array(FFN_IN).reshape(-1, D * 4)
        FFN_OUT_flat = np.array(FFN_OUT).reshape(-1, D)
        ATT_IN_b = np.c_[ATT_IN_flat, np.ones(ATT_IN_flat.shape[0])]
        FFN_IN_b = np.c_[FFN_IN_flat, np.ones(FFN_IN_flat.shape[0])]
        W_att = np.linalg.lstsq(ATT_IN_b, ATT_OUT_flat, rcond=None)[0]
        W_ffn = np.linalg.lstsq(FFN_IN_b, FFN_OUT_flat, rcond=None)[0]
        W_matrices[layer_idx] = {'att': W_att, 'ffn': W_ffn}
        print(f'    Layer {layer_idx} W_att and W_ffn perfectly extracted.')
print('\n' + '─' * 62)
print('  GENERATION LOOP (PURE W, NO MODEL BLOCKS)')
print('─' * 62)
prompt = 'Once upon a time, a little girl named'
print(f"\n  Prompt: '{prompt}'")
input_ids = tokenizer.encode(prompt, return_tensors='pt')
generated_tokens = input_ids[0].tolist()
tokens_to_generate = 20
print(f'  Generating {tokens_to_generate} tokens...\n')
print(f'  {prompt}', end=' ', flush=True)
with torch.no_grad():
    for step in range(tokens_to_generate):
        current_ids = torch.tensor([generated_tokens[-CTX:]])
        if current_ids.shape[1] < CTX:
            pad_len = CTX - current_ids.shape[1]
            pad = torch.full((1, pad_len), tokenizer.eos_token_id)
            current_ids = torch.cat([pad, current_ids], dim=1)
        h = model.transformer.wte(current_ids) + model.transformer.wpe(torch.arange(0, CTX).unsqueeze(0))
        h_np = h[0].numpy()
        for layer_idx in range(n_layers):
            block = model.transformer.h[layer_idx]
            Wq = block.attn.attention.q_proj.weight.detach().numpy().T
            Wk = block.attn.attention.k_proj.weight.detach().numpy().T
            Wv = block.attn.attention.v_proj.weight.detach().numpy().T
            W_att = W_matrices[layer_idx]['att']
            W_ffn = W_matrices[layer_idx]['ffn']
            ln1 = block.ln_1(torch.tensor(h_np, dtype=torch.float32)).numpy()
            Q_full, K_full, V_full = (ln1 @ Wq, ln1 @ Wk, ln1 @ Wv)
            head_feats = []
            for h_id in range(n_heads):
                s_h, e_h = (h_id * head_dim, (h_id + 1) * head_dim)
                Q_h, K_h, V_h = (Q_full[:, s_h:e_h], K_full[:, s_h:e_h], V_full[:, s_h:e_h])
                scr = Q_h @ K_h.T / np.sqrt(head_dim)
                msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                att_h = softmax(scr + msk)
                head_feats.append(att_h @ V_h)
            att_in = np.concatenate(head_feats, axis=1)
            att_in_b = np.c_[att_in, np.ones(att_in.shape[0])]
            att_out = att_in_b @ W_att
            h_np = h_np + att_out
            ln2 = block.ln_2(torch.tensor(h_np, dtype=torch.float32)).numpy()
            pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
            ffn_in = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
            ffn_in_b = np.c_[ffn_in, np.ones(ffn_in.shape[0])]
            ffn_out = ffn_in_b @ W_ffn
            h_np = h_np + ffn_out
        h_final = torch.tensor(h_np, dtype=torch.float32)
        h_norm = model.transformer.ln_f(h_final)
        logits = model.lm_head(h_norm)
        next_token_logit = logits[-1, :]
        next_token_id = torch.argmax(next_token_logit).item()
        generated_tokens.append(next_token_id)
        word = tokenizer.decode([next_token_id])
        print(word, end='', flush=True)
print('\n\n' + '=' * 62)
print('  IF THIS READS PERFECTLY: THE LAWS ARE ABSOLUTE.')
print('=' * 62 + '\n')
