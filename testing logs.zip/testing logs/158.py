import os
import transformers.utils.import_utils as _iu
_iu.check_torch_load_is_safe = lambda: None
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTNeoConfig
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def banner(text, width=70):
    print(f"\n{'=' * width}\n  {text}\n{'=' * width}")
banner(f'RAW KERNEL → V16 → CODE TRAINING   device={device}')
banner('STEP 1 — RAW KERNEL  (random weights, no pre-training)')
KERNEL_CONFIG = GPTNeoConfig(vocab_size=50257, hidden_size=256, num_layers=4, attention_types=[[['global', 'local'], 2]], num_heads=4, intermediate_size=1024, max_position_embeddings=512, window_size=256, resid_pdrop=0.1, embed_pdrop=0.1, attention_dropout=0.1)
kernel = AutoModelForCausalLM.from_config(KERNEL_CONFIG).to(device)
tok = AutoTokenizer.from_pretrained('gpt2')
tok.pad_token = tok.eos_token
p_kernel = sum((p.numel() for p in kernel.parameters()))
print(f'  Architecture : GPT-Neo (from scratch, random weights)')
print(f'  Params       : {p_kernel:,}')
print(f'  D            : {KERNEL_CONFIG.hidden_size}')
print(f'  Layers       : {KERNEL_CONFIG.num_layers}')
banner('STEP 2 — V16 FROM CODEGEN-350M → RAW KERNEL')
print('  Loading CodeGen-350M (teacher)...')
tok_big = AutoTokenizer.from_pretrained('Salesforce/codegen-350M-mono')
model_big = AutoModelForCausalLM.from_pretrained('Salesforce/codegen-350M-mono', use_safetensors=True).to(device).eval()
p_big = sum((p.numel() for p in model_big.parameters()))
print(f'  Teacher: D={model_big.config.n_embd}  params={p_big:,}')
print(f'  Kernel:  D={KERNEL_CONFIG.hidden_size}  params={p_kernel:,}')
print(f'  Compression: {p_big / p_kernel:.1f}x\n')

def v16_transfer(wte_big, wte_small, k=3):
    P = np.linalg.lstsq(wte_big, wte_small, rcond=None)[0]
    wte_proj = wte_big @ P
    wte_blend = 0.5 * wte_small + 0.5 * wte_proj
    agree_d = np.sum(wte_small * wte_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    wte_child = wte_blend.copy()
    wte_child[:, flip_dims] *= -1
    return (wte_child, flip_dims, agree_d)
WTE_big = model_big.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
WTE_kernel = kernel.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
VS_use = min(WTE_big.shape[0], WTE_kernel.shape[0])
WTE_big_a = WTE_big[:VS_use]
WTE_ker_a = WTE_kernel[:VS_use]
WTE_child, flip_dims, agree_d = v16_transfer(WTE_big_a, WTE_ker_a, k=3)
print(f'  Agreement range : {agree_d.min():.2f} → {agree_d.max():.2f}')
print(f'  All constructive: {np.all(agree_d > 0)}')
print(f'  Flipped dims    : {flip_dims.tolist()}')
with torch.no_grad():
    kernel.transformer.wte.weight[:VS_use].copy_(torch.tensor(WTE_child, dtype=torch.float32).to(device))
print('\n  ✓ CodeGen-350M geometry injected into raw kernel.')
model_big.cpu()
torch.cuda.empty_cache()
print('  ✓ Teacher freed from GPU.')
banner('STEP 3 — TRAIN ON CODE  (30 epochs, WTE frozen)')
print('  WTE frozen — holds CodeGen geometry.')
print('  FFN + attention learn from scratch to read code geometry.\n')
CODE_SNIPPETS = ['def add(a, b):\n    return a + b\n', 'def subtract(a, b):\n    return a - b\n', 'def multiply(a, b):\n    return a * b\n', 'def divide(a, b):\n    if b == 0: return None\n    return a / b\n', 'def is_even(n):\n    return n % 2 == 0\n', 'def is_odd(n):\n    return n % 2 != 0\n', 'def absolute(n):\n    return n if n >= 0 else -n\n', 'def square(n):\n    return n * n\n', 'def reverse_string(s):\n    return s[::-1]\n', "def count_vowels(s):\n    return sum(1 for c in s.lower() if c in 'aeiou')\n", "def is_palindrome(s):\n    s = s.lower().replace(' ', '')\n    return s == s[::-1]\n", 'def factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n - 1)\n', 'def fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)\n', 'def fibonacci_memo(n, memo={}):\n    if n in memo: return memo[n]\n    if n <= 1: return n\n    memo[n] = fibonacci_memo(n-1, memo) + fibonacci_memo(n-2, memo)\n    return memo[n]\n', 'def gcd(a, b):\n    while b:\n        a, b = b, a % b\n    return a\n', 'def is_prime(n):\n    if n < 2: return False\n    for i in range(2, int(n**0.5)+1):\n        if n % i == 0: return False\n    return True\n', 'def sum_list(lst):\n    return sum(lst)\n', 'def average(lst):\n    return sum(lst) / len(lst) if lst else 0\n', 'def max_of_list(lst):\n    return max(lst)\n', 'def flatten(lst):\n    result = []\n    for item in lst:\n        if isinstance(item, list): result.extend(flatten(item))\n        else: result.append(item)\n    return result\n', 'def remove_duplicates(lst):\n    seen = set()\n    return [x for x in lst if not (x in seen or seen.add(x))]\n', 'def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    while lo <= hi:\n        mid = (lo+hi)//2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid+1\n        else: hi = mid-1\n    return -1\n', 'def merge_sort(arr):\n    if len(arr) <= 1: return arr\n    mid = len(arr)//2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    result = []\n    i = j = 0\n    while i < len(left) and j < len(right):\n        if left[i] < right[j]: result.append(left[i]); i += 1\n        else: result.append(right[j]); j += 1\n    result.extend(left[i:]); result.extend(right[j:])\n    return result\n', 'def two_sum(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        if target - n in seen: return [seen[target-n], i]\n        seen[n] = i\n    return []\n', 'class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, x): self.items.append(x)\n    def pop(self): return self.items.pop() if self.items else None\n    def peek(self): return self.items[-1] if self.items else None\n    def is_empty(self): return len(self.items) == 0\n', 'def safe_divide(a, b):\n    try:\n        return a / b\n    except ZeroDivisionError:\n        return None\n', 'def count_words(text):\n    words = text.lower().split()\n    counts = {}\n    for w in words: counts[w] = counts.get(w, 0) + 1\n    return dict(sorted(counts.items(), key=lambda x: -x[1]))\n', 'class BankAccount:\n    def __init__(self, owner, balance=0):\n        self.owner = owner\n        self.balance = balance\n    def deposit(self, amount):\n        if amount > 0: self.balance += amount\n    def withdraw(self, amount):\n        if 0 < amount <= self.balance: self.balance -= amount; return True\n        return False\n', "def validate_email(email):\n    if '@' not in email: return False\n    parts = email.split('@')\n    if len(parts) != 2: return False\n    return '.' in parts[1]\n", 'def clamp(value, min_val, max_val):\n    return max(min_val, min(max_val, value))\n', 'def is_sorted(lst):\n    return all(lst[i] <= lst[i+1] for i in range(len(lst)-1))\n', 'def merge_dicts(*dicts):\n    result = {}\n    for d in dicts: result.update(d)\n    return result\n', 'def invert_dict(d):\n    return {v: k for k, v in d.items()}\n', 'def running_average(nums):\n    total = 0; result = []\n    for i, n in enumerate(nums):\n        total += n; result.append(total / (i+1))\n    return result\n', 'def nth_largest(lst, n):\n    return sorted(lst, reverse=True)[n-1]\n', 'def rotate_list(lst, k):\n    k = k % len(lst)\n    return lst[k:] + lst[:k]\n']

class CodeDataset(Dataset):

    def __init__(self, texts, tok, maxlen=128):
        self.data = []
        for t in texts:
            enc = tok(t, truncation=True, max_length=maxlen, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]

def generate(model, tokenizer, prompt, max_new=80):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.1, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def code_quality(prompt, output):
    gen = output[len(prompt):]
    lines = [l for l in gen.split('\n') if l.strip()]
    words = gen.split()
    uniq = len(set(words))
    n = max(len(words), 1)
    good_tokens = ['return', 'if', 'else', 'for', 'while', 'try', 'except', 'def', 'class', ':', '=', 'None', 'True', 'False']
    good_count = sum((1 for t in good_tokens if t in gen))
    score = round(min(good_count / 6, 1.0) * 0.5 + uniq / n * 0.3 + min(len(lines) / 8, 1.0) * 0.2, 3)
    return (score, good_count)
EASY_PROMPTS = ['def add(a, b):\n    ', 'def is_even(n):\n    ', 'def reverse_string(s):\n    ', 'def factorial(n):\n    ', 'def max_of_list(lst):\n    ']
HARD_PROMPTS = ['def binary_search(arr, target):\n    # Returns index, -1 if not found\n    ', 'def is_palindrome(s):\n    # Ignore case and spaces\n    ', 'def flatten_list(nested):\n    # Recursively flatten\n    ', 'class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, item):\n        ', 'def two_sum(nums, target):\n    # O(n) solution\n    ', 'def safe_divide(a, b):\n    # Handle ZeroDivisionError\n    ', 'def fibonacci_memo(n, memo={}):\n    # Memoized recursion\n    ', 'def merge_sort(arr):\n    if len(arr) <= 1:\n        return arr\n    ', 'def count_words(text):\n    # Sorted by frequency\n    ', 'class BankAccount:\n    def __init__(self, owner, balance=0):\n        self.owner = owner\n        self.balance = balance\n    def deposit(self, amount):\n        ']

def run_all(model, tokenizer, label):
    banner(label)
    easy_total = hard_total = 0
    results = []
    for i, (prompt, tag) in enumerate([(p, 'EASY') for p in EASY_PROMPTS] + [(p, 'HARD') for p in HARD_PROMPTS]):
        out = generate(model, tokenizer, prompt, max_new=100)
        q, good = code_quality(prompt, out)
        gen = out[len(prompt):].replace('\n', ' ↵ ')
        if tag == 'EASY':
            easy_total += q
        else:
            hard_total += q
        results.append((prompt, out, q, tag))
        bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
        print(f'\n  [{tag}][{i + 1:>2}] {bar} Q={q:.2f}  good={good}')
        print(f"   PROMPT: {prompt[:55].replace(chr(10), ' ')}")
        print(f'   OUTPUT: {gen[:100]}')
    ea = easy_total / len(EASY_PROMPTS)
    ha = hard_total / len(HARD_PROMPTS)
    print(f'\n  ┌──────────────────────────────────┐')
    print(f'  │  Easy avg : {ea:.3f}                 │')
    print(f'  │  Hard avg : {ha:.3f}                 │')
    print(f'  │  Overall  : {(easy_total + hard_total) / (len(EASY_PROMPTS) + len(HARD_PROMPTS)):.3f}                 │')
    print(f'  └──────────────────────────────────┘')
    return (results, ea, ha)
kernel.transformer.wte.weight.requires_grad_(False)
ds = CodeDataset(CODE_SNIPPETS * 40, tok, maxlen=128)
loader = DataLoader(ds, batch_size=16, shuffle=True)
opt = torch.optim.AdamW([p for p in kernel.parameters() if p.requires_grad], lr=0.0005)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=30, eta_min=1e-05)
WATCH_EASY = 'def is_even(n):\n    '
WATCH_HARD = 'def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    '
print(f"  {'Ep':>3}  {'Loss':>8}  {'EasyQ':>6}  {'HardQ':>6}  {'Best':>5}  Hard preview")
print(f"  {'─' * 78}")
best_score = -1
best_state = None
epoch_log = []
for epoch in range(1, 31):
    kernel.train()
    total = 0
    steps = 0
    for batch in loader:
        batch = batch.to(device)
        out = kernel(batch, labels=batch)
        opt.zero_grad()
        out.loss.backward()
        nn.utils.clip_grad_norm_(kernel.parameters(), 1.0)
        opt.step()
        total += out.loss.item()
        steps += 1
    sched.step()
    avg_loss = total / steps
    easy_out = generate(kernel, tok, WATCH_EASY, max_new=40)
    hard_out = generate(kernel, tok, WATCH_HARD, max_new=60)
    eq, _ = code_quality(WATCH_EASY, easy_out)
    hq, _ = code_quality(WATCH_HARD, hard_out)
    combined = eq * 0.4 + hq * 0.6
    hard_gen = hard_out[len(WATCH_HARD):].replace('\n', ' ↵ ')
    is_best = combined > best_score
    if is_best:
        best_score = combined
        best_state = {k: v.clone().cpu() for k, v in kernel.state_dict().items()}
        star = ' ← BEST'
    else:
        star = ''
    print(f'  {epoch:>3}  {avg_loss:>8.4f}  {eq:>6.2f}  {hq:>6.2f}  {combined:>5.2f}{star}')
    print(f'       Hard → {hard_gen[:75]}\n')
    epoch_log.append((epoch, avg_loss, eq, hq, combined, is_best))
print(f'\n  ✓ Restoring best checkpoint (score={best_score:.3f})...')
kernel.load_state_dict(best_state)
results_final, easy_fin, hard_fin = run_all(kernel, tok, 'FINAL — Raw Kernel + CodeGen V16 + Code Training')
banner('FINAL REPORT')
print(f"\n  Pipeline:  Random Weights → V16 from CodeGen-350M → Code Training\n  {'─' * 60}\n  Teacher CodeGen-350M   {p_big:>12,}   Easy=0.796  Hard=0.872\n  Raw Kernel (this)      {p_kernel:>12,}   Easy={easy_fin:.3f}  Hard={hard_fin:.3f}\n  Compression: {p_big / p_kernel:.1f}x\n")
print(f'  Learning curve:')
print(f"  {'Ep':>3}  {'Loss':>8}  {'EasyQ':>6}  {'HardQ':>6}  Bar")
print(f"  {'─' * 50}")
for ep, loss, eq, hq, combined, is_best in epoch_log:
    star = ' ★' if is_best else ''
    print(f"  {ep:>3}  {loss:>8.4f}  {eq:>6.2f}  {hq:>6.2f}  {'█' * int(hq * 20)}{star}")
_dir = os.path.dirname(os.path.abspath(__file__))
out_dir = os.path.join(_dir, 'raw_kernel_v16_coder')
kernel.save_pretrained(out_dir)
tok.save_pretrained(out_dir)
print(f'\n  ✓ Saved to: {out_dir}')
banner('DONE')
