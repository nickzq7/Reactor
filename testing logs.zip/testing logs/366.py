import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def cosine(A, B):
    A = A.flatten().astype(np.float64)
    B = B.flatten().astype(np.float64)
    return float(np.dot(A, B) / (np.linalg.norm(A) * np.linalg.norm(B) + 1e-10))

def max_err(a, b):
    return float(np.max(np.abs(np.array(a, dtype=np.float64) - np.array(b, dtype=np.float64))))
Wq = [model.transformer.h[li].attn.attention.q_proj.weight.detach().float().numpy() for li in range(n_layers)]
Wk = [model.transformer.h[li].attn.attention.k_proj.weight.detach().float().numpy() for li in range(n_layers)]
Wv = [model.transformer.h[li].attn.attention.v_proj.weight.detach().float().numpy() for li in range(n_layers)]
Wo = [model.transformer.h[li].attn.attention.out_proj.weight.detach().float().numpy() for li in range(n_layers)]
W1 = [model.transformer.h[li].mlp.c_fc.weight.detach().float().numpy() for li in range(n_layers)]
W2 = [model.transformer.h[li].mlp.c_proj.weight.detach().float().numpy() for li in range(n_layers)]
matrices = {'W_q': Wq, 'W_k': Wk, 'W_v': Wv, 'W_o': Wo, 'W1': W1, 'W2': W2}
print(f"\n{'=' * 70}")
print(f'  TEST A — COSINE SIMILARITY: W_l vs W_l+1')
print(f'  High cosine = adjacent layers = similar weights.')
print(f'  If cosine ≈ 1.0: weights nearly identical. Redundant?')
print(f"{'=' * 70}\n")
for mname, mlist in matrices.items():
    sims = []
    for li in range(n_layers - 1):
        s = cosine(mlist[li], mlist[li + 1])
        sims.append(s)
    print(f'  {mname:<8}: ' + '  '.join([f'{s:+.4f}' for s in sims]) + f'  mean={np.mean(sims):.4f}')
print(f"\n{'=' * 70}")
print(f"  TEST B — TRANSFORMATION LAW: W_{'{l+1}'} = T @ W_l ?")
print(f"  Fit T such that T @ W_l = W_{'{l+1}'}")
print(f'  If R²=1.000: weights = one seed + T^l transformation.')
print(f"{'=' * 70}\n")
from numpy.linalg import lstsq
for mname, mlist in matrices.items():
    print(f'  {mname}:')
    r2_vals = []
    for li in range(n_layers - 1):
        A = mlist[li].astype(np.float64)
        B = mlist[li + 1].astype(np.float64)
        T = B @ np.linalg.pinv(A)
        B_pred = T @ A
        rv = r2(B_pred.flatten(), B.flatten())
        me = max_err(B_pred, B)
        r2_vals.append(rv)
    print(f'    R² per layer: ' + '  '.join([f'{v:.4f}' for v in r2_vals]))
    print(f'    Mean R²: {np.mean(r2_vals):.6f}  Min: {np.min(r2_vals):.6f}')
print(f"\n{'=' * 70}")
print(f'  TEST C — SHARED SVD BASIS ACROSS LAYERS')
print(f'  W_l = U @ diag(s_l) @ V^T for shared U,V?')
print(f'  Only s_l (singular values) differ per layer?')
print(f'  Compute: how aligned are U,V across layers?')
print(f"{'=' * 70}\n")
for mname, mlist in matrices.items():
    svds = []
    for li in range(n_layers):
        U, S, Vt = np.linalg.svd(mlist[li].astype(np.float64), full_matrices=False)
        svds.append((U, S, Vt))
    U0 = svds[0][0]
    alignments = []
    for li in range(1, n_layers):
        Ul = svds[li][0]
        overlap = np.linalg.norm(U0.T @ Ul, 'fro') / np.sqrt(U0.shape[1])
        alignments.append(overlap)
    Vt0 = svds[0][2]
    v_alignments = []
    for li in range(1, n_layers):
        Vtl = svds[li][2]
        overlap = np.linalg.norm(Vt0 @ Vtl.T, 'fro') / np.sqrt(Vt0.shape[0])
        v_alignments.append(overlap)
    print(f'  {mname:<8}:')
    print(f'    U alignment (l=0 vs l=1..7): ' + '  '.join([f'{a:.4f}' for a in alignments]))
    print(f'    V alignment (l=0 vs l=1..7): ' + '  '.join([f'{a:.4f}' for a in v_alignments]))
    print(f'    Mean U-align: {np.mean(alignments):.4f}  (random baseline ≈ {np.sqrt(U0.shape[1] / U0.shape[0]):.4f})')
print(f"\n{'=' * 70}")
print(f'  TEST D — LINEAR INTERPOLATION ACROSS DEPTH')
print(f'  W_l = W_0 + l/(L-1) × (W_{n_layers - 1} - W_0)?')
print(f'  If R²=1.000: store W_0 + W_7 only. Reconstruct all.')
print(f"{'=' * 70}\n")
for mname, mlist in matrices.items():
    W_start = mlist[0].astype(np.float64)
    W_end = mlist[-1].astype(np.float64)
    r2_vals = []
    me_vals = []
    for li in range(n_layers):
        t = li / (n_layers - 1)
        W_interp = (1 - t) * W_start + t * W_end
        rv = r2(W_interp.flatten(), mlist[li].astype(np.float64).flatten())
        me = max_err(W_interp, mlist[li])
        r2_vals.append(rv)
        me_vals.append(me)
    print(f'  {mname:<8}: R²=' + ' '.join([f'{v:.4f}' for v in r2_vals]))
    print(f'           max_err=' + ' '.join([f'{v:.4f}' for v in me_vals]))
    print(f'           Mean R²={np.mean(r2_vals):.6f}  Max R² at boundaries: {r2_vals[0]:.4f},{r2_vals[-1]:.4f}')
    print()
print(f"\n{'=' * 70}")
print(f'  TEST E — DO SINGULAR VALUES FOLLOW DEPTH LAW?')
print(f'  Each W_l has singular values S_l.')
print(f'  Do S_l follow a pattern across l?')
print(f'  Like: S_l = f(S_0, l)?')
print(f"{'=' * 70}\n")
for mname, mlist in [('W_q', Wq), ('W1', W1)]:
    all_S = []
    for li in range(n_layers):
        _, S, _ = np.linalg.svd(mlist[li].astype(np.float64), full_matrices=False)
        all_S.append(S)
    print(f'  {mname} — top 5 singular values per layer:')
    print(f"  {'Layer':<8} " + '  '.join([f'σ{i + 1:<7}' for i in range(5)]))
    print(f"  {'─' * 45}")
    for li in range(n_layers):
        print(f'  {li:<8} ' + '  '.join([f'{all_S[li][i]:.4f}' for i in range(5)]))
    max_S = [all_S[li][0] for li in range(n_layers)]
    norms = [np.linalg.norm(mlist[li], 'fro') for li in range(n_layers)]
    print(f'\n  Frobenius norms per layer: ' + '  '.join([f'{v:.4f}' for v in norms]))
    layers = np.arange(n_layers, dtype=np.float64)
    coeffs = np.polyfit(layers, norms, 1)
    norms_fit = np.polyval(coeffs, layers)
    rv = r2(norms_fit, norms)
    print(f'  Linear fit R²={rv:.6f}  slope={coeffs[0]:.6f}  ' + ('✓✓ DEPTH LAW' if rv > 0.9 else '✗ NO LAW'))
    print()
print(f"\n{'=' * 70}")
print(f'  TEST F — WEIGHT DELTA (residual) LAW')
print(f'  delta_l = W_l+1 - W_l per layer.')
print(f'  Do deltas follow a pattern?')
print(f'  delta_0, delta_1, ..., delta_6: related?')
print(f"{'=' * 70}\n")
for mname, mlist in [('W_q', Wq), ('W1', W1), ('W2', W2)]:
    deltas = [mlist[li + 1].astype(np.float64) - mlist[li].astype(np.float64) for li in range(n_layers - 1)]
    delta_norms = [np.linalg.norm(d, 'fro') for d in deltas]
    weight_norms = [np.linalg.norm(mlist[li], 'fro') for li in range(n_layers)]
    print(f'  {mname}:')
    print(f'    Weight norms:  ' + '  '.join([f'{v:.4f}' for v in weight_norms]))
    print(f'    Delta norms:   ' + '  '.join([f'{v:.4f}' for v in delta_norms]))
    print(f'    Delta/Weight:  ' + '  '.join([f'{delta_norms[i] / weight_norms[i]:.3f}' for i in range(len(delta_norms))]))
    delta_cos = [cosine(deltas[i], deltas[i + 1]) for i in range(len(deltas) - 1)]
    print(f'    Delta cosines: ' + '  '.join([f'{v:+.4f}' for v in delta_cos]))
    print()
print(f"\n{'=' * 70}")
print(f'  WHAT W LAW SAYS ABOUT CROSS-LAYER WEIGHTS')
print(f"{'=' * 70}")
print(f'\n  W = one unit = no separation.\n  All layers obey identical law (proven).\n  \n  IF weights follow a law across depth:\n    W_l = f(W_0, l): store one matrix + function.\n    f linear: linear interpolation. Test D.\n    f multiplicative: T^l transformation. Test B.\n    f = shared basis: U,V shared + s_l. Test C.\n    \n  CORRECT COMPRESSION (no residual error):\n    Not: modify individual weights (breaks residual).\n    Yes: if W_l = f(W_0, l) EXACTLY:\n         Compute any W_l on demand from W_0.\n         Store only W_0. Memory = 1/n_layers.\n         For 70B (80 layers): store 1/80 of weights.\n         Load and compute per layer during inference.\n         \n  KEY: if R²=1.000 in test D or B:\n    This IS the W law for weights.\n    Same exactness principle.\n    Applied to weight space, not activation space.\n    8 layers → 1 layer equivalent stored.\n    70B → effectively 0.875B stored. Runs on laptop.\n')
print('=' * 70 + '\n')
