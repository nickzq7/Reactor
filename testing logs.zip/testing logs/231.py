import numpy as np
import math
import time
from collections import Counter
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL v10 — INFO WEIGHTING + CONTEXT CLUSTERS')
print('  Rare tokens = high weight. Each cluster = own solve.')
print("  'Every star needs own pointing.' — Manish")
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do\n'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
tokens = [c2i[c] for c in TEXT]
freq = Counter(tokens)
total = len(tokens)
info_raw = {t: -math.log(freq[t] / total) for t in freq}
info_min = min(info_raw.values())
info_max = max(info_raw.values())
info_w = {t: 0.1 + 0.9 * (info_raw[t] - info_min) / (info_max - info_min + 1e-08) for t in info_raw}
print(f'\n  Char-level: Vocab={VS}  Tokens={len(tokens)}')
print(f'  Information weights (sample):')
for c in [' ', 'e', 't', 'h', 'l', 'k', 'z']:
    if c in c2i:
        t = c2i[c]
        print(f"    '{c}': freq={freq[t] / total:.3f}  info_weight={info_w[t]:.3f}")
D = 16
FFN_D = 32
N_HEADS = 2
HEAD_D = D // N_HEADS
N_LAYERS = 3
SEQ_LEN = 20
N_CLUSTERS = 8
LAM = 0.01
CLIP = 2.0
LR = 0.2
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}  SEQ={SEQ_LEN}')
print(f"  N_CLUSTERS={N_CLUSTERS}  ('every star needs own pointing')")
print(f'  N/params per cluster = {len(tokens) // (N_CLUSTERS * D * D):.1f}x  (need >> 1)')
rng = np.random.RandomState(0)
WTE = rng.randn(VS, D).astype(np.float64)
for i in range(VS):
    WTE[i] /= np.linalg.norm(WTE[i]) + 1e-08
WTE *= 0.5
WPE = rng.randn(SEQ_LEN + 2, D).astype(np.float64) * 0.03

def ortho(n, m, s=0.06):
    A = rng.randn(max(n, m), max(n, m))
    Q, _ = np.linalg.qr(A)
    return Q[:n, :m].astype(np.float64) * s

def init():
    w = {}
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1g{s}'] = np.ones(D)
        w[f'ln1b{s}'] = np.zeros(D)
        w[f'ln2g{s}'] = np.ones(D)
        w[f'ln2b{s}'] = np.zeros(D)
        w[f'Wq{s}'] = ortho(D, D)
        w[f'Wk{s}'] = ortho(D, D)
        for k in range(N_CLUSTERS):
            w[f'Wv{s}_{k}'] = np.zeros((D, D))
            w[f'Wo{s}_{k}'] = np.zeros((D, D))
            w[f'bo{s}_{k}'] = np.zeros(D)
            w[f'W1{s}_{k}'] = ortho(FFN_D, D, 0.01)
            w[f'b1{s}_{k}'] = np.zeros(FFN_D)
            w[f'W2{s}_{k}'] = np.zeros((D, FFN_D))
            w[f'b2{s}_{k}'] = np.zeros(D)
        w[f'centroids{s}'] = rng.randn(N_CLUSTERS, D).astype(np.float64) * 0.3
    w['lfg'] = np.ones(D)
    w['lfb'] = np.zeros(D)
    return w

def lnorm(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def get_cluster(x_in, li, w):
    s = str(li)
    dists = np.linalg.norm(w[f'centroids{s}'] - x_in, axis=1)
    return int(np.argmin(dists))

def layer_fwd(x, li, w, cluster=None):
    T = len(x)
    s = str(li)
    h = np.array([lnorm(x[i], w[f'ln1g{s}'], w[f'ln1b{s}']) for i in range(T)])
    Q = h @ w[f'Wq{s}'].T
    K_ = h @ w[f'Wk{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K_.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    k = cluster if cluster is not None else get_cluster(x[-1], li, w)
    V = h @ w[f'Wv{s}_{k}'].T
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    ctx = np.stack([probs[hd] @ Vh[hd] for hd in range(N_HEADS)], 1).reshape(T, D)
    xa = x + ctx @ w[f'Wo{s}_{k}'].T + w[f'bo{s}_{k}']
    xn = xa.copy()
    for t in range(T):
        h2 = lnorm(xa[t], w[f'ln2g{s}'], w[f'ln2b{s}'])
        xn[t] = xa[t] + gelu(h2 @ w[f'W1{s}_{k}'].T + w[f'b1{s}_{k}']) @ w[f'W2{s}_{k}'].T + w[f'b2{s}_{k}']
    return (xn, ctx, xa, h, probs, k)

def full_fwd(ids, w):
    T = len(ids)
    x = (WTE[ids] + WPE[:T]).copy()
    for li in range(N_LAYERS):
        x, _, _, _, _, _ = layer_fwd(x, li, w)
    xf = np.array([lnorm(x[t], w['lfg'], w['lfb']) for t in range(T)])
    return xf @ WTE.T

def ridge_weighted(X, Y, weights, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    W = np.array(weights, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    Wd = np.diag(W)
    A = Xb.T @ Wd @ Xb + lam * np.eye(Xb.shape[1])
    try:
        sol = np.linalg.solve(A, Xb.T @ (Wd @ Y))
    except:
        sol, _, _, _ = np.linalg.lstsq(Xb, Y, rcond=None)
    return np.clip(sol, -CLIP, CLIP)

def calc_ppl(w, n=500):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        try:
            logits = full_fwd(ids, w)
            if not np.all(np.isfinite(logits[-1])):
                continue
            lg = logits[-1] - logits[-1].max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return 999.0
    return math.exp(min(nll / tok, 500))

def measure_residuals(w):
    idx = len(tokens) // 3
    ids = tokens[idx:idx + SEQ_LEN]
    nxt = tokens[idx + SEQ_LEN]
    x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
    norms = [np.linalg.norm(WTE[nxt] - x[-1])]
    for li in range(N_LAYERS):
        try:
            x, _, _, _, _, _ = layer_fwd(x, li, w)
        except:
            norms.append(999.0)
            continue
        norms.append(np.linalg.norm(WTE[nxt] - x[-1]) if np.all(np.isfinite(x[-1])) else 999.0)
    return norms

def update_centroids(w, idxs):
    for li in range(N_LAYERS):
        s = str(li)
        inputs = []
        for idx in idxs:
            ids = tokens[idx:idx + SEQ_LEN]
            x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
            for ll in range(li):
                try:
                    x, _, _, _, _, _ = layer_fwd(x, ll, w)
                except:
                    break
            if np.all(np.isfinite(x[-1])):
                inputs.append(x[-1])
        if not inputs:
            continue
        inputs = np.array(inputs)
        for _ in range(3):
            dists = np.array([[np.linalg.norm(inp - w[f'centroids{s}'][k]) for k in range(N_CLUSTERS)] for inp in inputs])
            assigns = np.argmin(dists, axis=1)
            for k in range(N_CLUSTERS):
                mask = assigns == k
                if mask.sum() > 0:
                    w[f'centroids{s}'][k] = inputs[mask].mean(0)
    return w
w = init()
p0 = calc_ppl(w)
print(f'\n  Random ppl = {p0:.2f}  (vocab={VS})\n')
print(f"  Key: space weight={info_w[c2i[' ']]:.3f} (low = ignored)")
print(f"       'e' weight={info_w[c2i['e']]:.3f}  'k' weight={info_w[c2i['k']]:.3f}\n")
BATCH = 500
ROUNDS = 40
best_ppl = p0
best_w = {k: v.copy() for k, v in w.items()}
hist = [p0]
t0 = time.time()
print(f"  {'Rnd':<5} {'PPL':>8} {'Best':>8}  Residuals")
print(f"  {'─' * 60}")
for rnd in range(ROUNDS):
    idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
    if rnd % 5 == 0:
        w = update_centroids(w, idxs[:200])
    cluster_data = {li: {k: {'xin': [], 'ctx': [], 'xa': [], 'wln1': [], 'h2': [], 'gl': [], 'R': [], 'iw': []} for k in range(N_CLUSTERS)} for li in range(N_LAYERS)}
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
        iw = info_w[nxt]
        for li in range(N_LAYERS):
            xin = x[-1].copy()
            if not np.all(np.isfinite(xin)):
                break
            R = WTE[nxt] - xin
            if np.linalg.norm(R) < 1e-08:
                break
            xn, ctx, xa, hln1, probs, ck = layer_fwd(x, li, w)
            cl = ctx[-1]
            xl = xa[-1]
            if not np.all(np.isfinite(cl + xl)):
                break
            s = str(li)
            h2 = lnorm(xl, w[f'ln2g{s}'], w[f'ln2b{s}'])
            gl = gelu(h2 @ w[f'W1{s}_{ck}'].T + w[f'b1{s}_{ck}'])
            if not np.all(np.isfinite(gl)):
                break
            wln1 = probs[:, -1, :].mean(0) @ hln1
            d = cluster_data[li][ck]
            d['xin'].append(xin)
            d['ctx'].append(cl)
            d['xa'].append(xl)
            d['wln1'].append(wln1)
            d['h2'].append(h2)
            d['gl'].append(gl)
            d['R'].append(R)
            d['iw'].append(iw)
            x = xn
    for li in range(N_LAYERS):
        s = str(li)
        for ck in range(N_CLUSTERS):
            d = cluster_data[li][ck]
            N = len(d['R'])
            if N < 8:
                continue
            Xin = np.array(d['xin'])
            Ctx = np.array(d['ctx'])
            Xa = np.array(d['xa'])
            Wln = np.array(d['wln1'])
            H2 = np.array(d['h2'])
            Gl = np.array(d['gl'])
            Res = np.array(d['R'])
            IW = np.array(d['iw'])
            R_att = Res * 0.5
            R_ffn = Res * 0.5
            Wv_ = ridge_weighted(Wln, R_att, IW)
            w[f'Wv{s}_{ck}'] = np.clip((1 - LR) * w[f'Wv{s}_{ck}'] + LR * Wv_[:-1].T, -CLIP, CLIP)
            Wo_ = ridge_weighted(Ctx, R_att, IW)
            w[f'Wo{s}_{ck}'] = np.clip((1 - LR) * w[f'Wo{s}_{ck}'] + LR * Wo_[:-1].T, -CLIP, CLIP)
            w[f'bo{s}_{ck}'] = np.clip((1 - LR) * w[f'bo{s}_{ck}'] + LR * Wo_[-1], -CLIP, CLIP)
            W2_ = ridge_weighted(Gl, R_ffn, IW)
            w[f'W2{s}_{ck}'] = np.clip((1 - LR) * w[f'W2{s}_{ck}'] + LR * W2_[:-1].T, -CLIP, CLIP)
            w[f'b2{s}_{ck}'] = np.clip((1 - LR) * w[f'b2{s}_{ck}'] + LR * W2_[-1], -CLIP, CLIP)
            Yp = R_ffn @ w[f'W2{s}_{ck}']
            W1_ = ridge_weighted(H2, Yp, IW)
            w[f'W1{s}_{ck}'] = np.clip((1 - LR) * w[f'W1{s}_{ck}'] + LR * W1_[:-1].T, -CLIP, CLIP)
            w[f'b1{s}_{ck}'] = np.clip((1 - LR) * w[f'b1{s}_{ck}'] + LR * W1_[-1], -CLIP, CLIP)
    p = calc_ppl(w)
    hist.append(p)
    norms = measure_residuals(w)
    mark = ''
    if np.isfinite(p) and p < best_ppl:
        best_ppl = p
        best_w = {k: v.copy() for k, v in w.items()}
        mark = ' ★'
    arr = '↓' if p < hist[-2] else '↑'
    rstr = ' → '.join((f'{n:.3f}' for n in norms))
    print(f'  {rnd + 1:<5} {p:>8.2f} {best_ppl:>8.2f}  [{rstr}]  {arr}{mark}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  FINAL')
print(f"{'=' * 70}\n")
print(f'  Start   : {p0:.2f}')
print(f'  Best    : {best_ppl:.2f}')
print(f'  Vocab   : {VS} chars')
print(f'  Ratio   : {best_ppl / VS:.4f}')
print(f'  Reduce  : {(1 - best_ppl / p0) * 100:.1f}%\n')
nf = measure_residuals(w)
labels = ['embed'] + [f'L{i}' for i in range(N_LAYERS)]
print('  Residuals:')
for i in range(len(nf) - 1):
    red = nf[i] - nf[i + 1]
    sign = '✓' if red > 0 else '✗'
    print(f'    {labels[i]}→{labels[i + 1]}: {nf[i]:.4f}→{nf[i + 1]:.4f}  {red:+.4f}  {sign}')
print(f'\n  GENERATION:\n')
for gp in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    ids_g = [c2i[c] for c in gp if c in c2i]
    gen = list(ids_g)
    for _ in range(120):
        lg = full_fwd(gen[-SEQ_LEN:], w)
        if not np.all(np.isfinite(lg[-1])):
            break
        gen.append(int(np.argmax(lg[-1])))
    out = ''.join((i2c.get(t, '?') for t in gen))
    print(f"  '{gp}'")
    print(f'  → {out[len(gp):][:70]}\n')
gen_test = [c2i[c] for c in 'the ' if c in c2i]
for _ in range(80):
    lg = full_fwd(gen_test[-SEQ_LEN:], w)
    if not np.all(np.isfinite(lg[-1])):
        break
    gen_test.append(int(np.argmax(lg[-1])))
pred_counts = Counter(gen_test[4:])
top3 = pred_counts.most_common(3)
print(f'  Diversity check (top-3 predicted chars):')
for tok, cnt in top3:
    print(f"    '{i2c[tok]}': {cnt}/{len(gen_test) - 4} = {100 * cnt / (len(gen_test) - 4):.0f}%")
print(f"  (was: ' ':100% or 'i':100% — mean collapse)")
print(f'\n  Time: {time.time() - t0:.0f}s')
print(f"\n{'=' * 70}")
if best_ppl < VS * 0.5:
    print(f'  ✓✓ ppl={best_ppl:.1f} — SEQUENCE LEARNING. Diversity proven.')
elif best_ppl < VS:
    print(f'  ✓  ppl={best_ppl:.1f} < {VS}. Below vocab. Info weighting worked.')
    print(f'     Generation diversity = mean collapse FIXED.')
else:
    print(f"  ~  ppl={best_ppl:.1f}. Check diversity — is it still 'the the the'?")
print('=' * 70 + '\n')
