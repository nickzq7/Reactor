import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]

def make_data(n=3000):
    X, Y = ([], [])
    for i in range(1, n):
        x = i / n
        X.append(x)
        Y.append(np.sin(x * 2 * np.pi) * 0.5 + 0.5)
        X.append(x)
        Y.append(x ** 2)
        X.append(x)
        Y.append(x * (1 - x))
        X.append(x)
        Y.append(x ** 0.5)
        X.append(x)
        Y.append(1 - x)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32).unsqueeze(1)
    Yt = torch.tensor([a[1] for a in arr], dtype=torch.float32).unsqueeze(1)
    return (Xt, Yt)
X, Y = make_data()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Data: {len(X)} samples')

class Net(nn.Module):

    def __init__(self, dim, numbers=None):
        super().__init__()
        self.dim = dim
        self.net = nn.Sequential(nn.Linear(1, dim), nn.Tanh(), nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, 1))
        if numbers is not None:
            arr = np.array(numbers, dtype=np.float32)
            arr = arr / np.max(np.abs(arr))
            W = torch.tensor(arr, dtype=torch.float32).unsqueeze(1)
            with torch.no_grad():
                self.net[0].weight.copy_(W)

    def forward(self, x):
        return self.net(x)

def train(model, epochs=800, lr=0.01, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        opt.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        if ep % 200 == 0:
            print(f'    {label}  ep{ep}  best={best:.6f}')
    if best_st:
        model.load_state_dict(best_st)
    return best

def v16_transfer(teacher, student):
    W_T = teacher.net[0].weight.detach().cpu().numpy().astype(np.float64).flatten()
    W_S = student.net[0].weight.detach().cpu().numpy().astype(np.float64).flatten()
    t_idx = np.linspace(0, len(W_T) - 1, len(W_S))
    proj = np.interp(t_idx, np.arange(len(W_T)), W_T)
    proj = proj / (np.max(np.abs(proj)) + 1e-08) * np.std(W_S)
    blend = 0.5 * W_S + 0.5 * proj
    agree = W_S * proj
    flips = np.argsort(agree)[-3:]
    blend[flips] *= -1
    with torch.no_grad():
        student.net[0].weight.copy_(torch.tensor(blend, dtype=torch.float32).to(device).unsqueeze(1))
    print(f'  V16 injected  teacher_dim=16 → student_dim=256  flips={flips.tolist()}')
TASKS = [('square:  1,4,9,16,25 → next=?', 0.5, 0.25, 0.03), ('square:  1,4,9,16,25,36 → next=?', 0.6, 0.36, 0.03), ('square:  next after 49=?', 0.7, 0.49, 0.03), ('square:  next after 64=?', 0.8, 0.64, 0.03), ('square:  next after 81=?', 0.9, 0.81, 0.03), ('parabola: x=0.2 → ?', 0.2, 0.16, 0.03), ('parabola: x=0.3 → ?', 0.3, 0.21, 0.03), ('parabola: x=0.4 → ?', 0.4, 0.24, 0.03), ('parabola: x=0.6 → ?', 0.6, 0.24, 0.03), ('parabola: x=0.7 → ?', 0.7, 0.21, 0.03), ('sine: x=0.25 → ?', 0.25, 1.0, 0.05), ('sine: x=0.5  → ?', 0.5, 0.5, 0.05), ('sine: x=0.75 → ?', 0.75, 0.0, 0.05), ('sine: x=0.1  → ?', 0.1, 0.654, 0.05), ('sine: x=0.9  → ?', 0.9, 0.346, 0.05), ('sqrt: x=0.04 → ?', 0.04, 0.2, 0.03), ('sqrt: x=0.09 → ?', 0.09, 0.3, 0.03), ('sqrt: x=0.16 → ?', 0.16, 0.4, 0.03), ('sqrt: x=0.25 → ?', 0.25, 0.5, 0.03), ('sqrt: x=0.36 → ?', 0.36, 0.6, 0.03), ('inverse: x=0.2 → 1-x=?', 0.2, 0.8, 0.03), ('inverse: x=0.3 → 1-x=?', 0.3, 0.7, 0.03), ('inverse: x=0.6 → 1-x=?', 0.6, 0.4, 0.03), ('inverse: x=0.7 → 1-x=?', 0.7, 0.3, 0.03), ('inverse: x=0.9 → 1-x=?', 0.9, 0.1, 0.03), ('missing: 0.1,?,0.3 → middle=?', 0.2, 0.04, 0.03), ('missing: 0.2,?,0.4 → middle=?', 0.3, 0.21, 0.03), ('missing: 0.3,?,0.5 → middle=?', 0.4, 0.24, 0.03), ('missing: 0.4,?,0.6 → middle=?', 0.5, 0.25, 0.03), ('missing: 0.6,?,0.8 → middle=?', 0.7, 0.21, 0.03)]

def evaluate(model, label):
    model.eval()
    correct = 0
    print(f'\n  ── {label} ──')
    print(f"  {'Task':<42} {'True':>6}  {'Pred':>6}  {'Err':>6}  Result")
    print(f"  {'─' * 70}")
    with torch.no_grad():
        for desc, x, true_y, tol in TASKS:
            xt = torch.tensor([[x]], dtype=torch.float32).to(device)
            pred = model(xt).item()
            err = abs(pred - true_y)
            ok = err <= tol
            if ok:
                correct += 1
            tag = '✓' if ok else '✗'
            print(f'  {desc:<42} {true_y:>6.3f}  {pred:>6.3f}  {err:>6.3f}  {tag}')
    pct = correct / len(TASKS) * 100
    print(f'\n  Score: {correct}/{len(TASKS)}  ({pct:.1f}%)')
    return correct
print(f"\n{'=' * 65}")
print('  STEP 1 — 16-dim PRIME TEACHER')
print(f"{'=' * 65}")
teacher = Net(16, numbers=BEST_PRIMES).to(device)
print(f'  Params: {sum((p.numel() for p in teacher.parameters())):,}')
train(teacher, epochs=800, lr=0.01, label='TEACHER')
print(f"\n{'=' * 65}")
print('  STEP 2 — 256-dim FLAT trained alone (Model A)')
print(f"{'=' * 65}")
model_A = Net(256).to(device)
print(f'  Params: {sum((p.numel() for p in model_A.parameters())):,}')
train(model_A, epochs=800, lr=0.01, label='MODEL_A')
print(f"\n{'=' * 65}")
print('  STEP 3 — V16 TRANSFER: prime teacher → 256-dim (Model B)')
print(f"{'=' * 65}")
model_B = Net(256).to(device)
v16_transfer(teacher, model_B)
train(model_B, epochs=800, lr=0.01, label='MODEL_B')
print(f"\n{'=' * 65}")
print('  STEP 4 — GENERATION TEST (30 tasks)')
print(f"{'=' * 65}")
score_T = evaluate(teacher, 'MODEL C — 16-dim PRIME TEACHER')
score_A = evaluate(model_A, 'MODEL A — 256-dim FLAT alone')
score_B = evaluate(model_B, 'MODEL B — 256-dim + V16 from prime teacher')
print(f"\n{'=' * 65}")
print(f'  FINAL SCOREBOARD')
print(f"{'=' * 65}")
print(f'  Model C  16-dim  prime teacher  : {score_T}/{len(TASKS)}  ({score_T / len(TASKS) * 100:.1f}%)')
print(f'  Model A  256-dim flat alone     : {score_A}/{len(TASKS)}  ({score_A / len(TASKS) * 100:.1f}%)')
print(f'  Model B  256-dim + V16 prime    : {score_B}/{len(TASKS)}  ({score_B / len(TASKS) * 100:.1f}%)')
print(f"{'=' * 65}")
best = max(score_T, score_A, score_B)
if score_B == best and score_B > score_A:
    print(f'\n  ✓ V16 PRIME TRANSFER WINS')
    print(f'  Prime geometry transferred to big model = smartest')
elif score_T == best:
    print(f'\n  ✓ SMALL PRIME TEACHER WINS')
    print(f'  Structure beats size even at generation')
elif score_A == best:
    print(f'\n  Flat 256 wins — structure not sufficient yet')
