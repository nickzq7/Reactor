import numpy as np
import json
import math
print('\n' + '=' * 65)
print('  KERNEL vs MODEL — EXACT MATCH TEST')
print('  Laws only. No backprop. Raw text → lstsq → kernel.')
print('=' * 65)
npz = np.load('tiny_transformer_weights.npz')
meta = json.load(open('tiny_transformer_meta.json'))
w2i = meta['w2i']
i2w = {int(k): v for k, v in meta['i2w'].items()}
VS, D, H = (meta['VS'], meta['D'], meta['H'])
NL, K, FFN = (meta['NL'], meta['K'], meta['FFN'])
TEXT = meta['text']
hd = D // H
print(f'\n  VS={VS} D={D} H={H} NL={NL} K={K} FFN={FFN}')
WTE = npz['WTE'].astype(np.float64)
WPE = npz['WPE'].astype(np.float64)
LNfg = npz['LNfg'].astype(np.float64)
LNfb = npz['LNfb'].astype(np.float64)
TL = [{k: npz[f'{k}{l}'].astype(np.float64) for k in ['WQ', 'WK', 'WV', 'WO', 'W1', 'b1', 'W2', 'b2', 'LN1g', 'LN1b', 'LN2g', 'LN2b']} for l in range(NL)]

def ln(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=True):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    W, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)
    return W

def apply(W, X, bias=True):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    return X @ W

def r2(p, t):
    ss = np.mean((np.array(p).ravel() - np.array(t).ravel()) ** 2)
    sv = np.var(np.array(t).ravel())
    return float(1 - ss / sv) if sv > 1e-12 else 1.0
words = TEXT.split()
toks = [w2i[w] for w in words]
N = len(toks) - K
X_ids = np.array([toks[i:i + K] for i in range(N)])
y_ids = np.array([toks[i + 1:i + K + 1] for i in range(N)])
print(f'  Training sequences: {N}')
print(f'\n  Collecting activations from raw text...')
store = {l: {k: [] for k in ['h_in', 'ln1', 'Q', 'K', 'V', 'ctx', 'att', 'hm', 'ln2', 'pre', 'pre_ns', 'gelu', 'ffn']} for l in range(NL)}
s_lnf_in = []
s_lnf_out = []
s_lmh_out = []

def collect_forward(seq):
    slen = len(seq)
    x = WTE[seq] + WPE[np.arange(slen)]
    for l in range(NL):
        lw = TL[l]
        store[l]['h_in'].append(x.copy())
        ln1 = ln(x, lw['LN1g'], lw['LN1b'])
        store[l]['ln1'].append(ln1)
        Q = ln1 @ lw['WQ'].T
        K_ = ln1 @ lw['WK'].T
        V = ln1 @ lw['WV'].T
        store[l]['Q'].append(Q)
        store[l]['K'].append(K_)
        store[l]['V'].append(V)
        Q_h = Q.reshape(slen, H, hd).transpose(1, 0, 2)
        K_h = K_.reshape(slen, H, hd).transpose(1, 0, 2)
        V_h = V.reshape(slen, H, hd).transpose(1, 0, 2)
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            p = softmax(Q_h[h] @ K_h[h].T + mk)
            heads.append(p @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(slen, D)
        att = ctx @ lw['WO'].T
        store[l]['ctx'].append(ctx)
        store[l]['att'].append(att)
        hm = x + att
        store[l]['hm'].append(hm)
        ln2 = ln(hm, lw['LN2g'], lw['LN2b'])
        store[l]['ln2'].append(ln2)
        pre = ln2 @ lw['W1'].T + lw['b1']
        store[l]['pre'].append(pre)
        store[l]['pre_ns'].append(np.c_[pre, pre ** 2])
        g = gelu(pre)
        store[l]['gelu'].append(g)
        ffn = g @ lw['W2'].T + lw['b2']
        store[l]['ffn'].append(ffn)
        x = hm + ffn
    s_lnf_in.append(x.copy())
    lf = ln(x, LNfg, LNfb)
    s_lnf_out.append(lf)
    s_lmh_out.append(lf @ WTE.T)
for i in range(N):
    collect_forward(X_ids[i].tolist())
cat = lambda l: np.concatenate(l, axis=0)
for l in range(NL):
    for k in store[l]:
        store[l][k] = cat(store[l][k])
lnf_in = cat(s_lnf_in)
lnf_out = cat(s_lnf_out)
lmh_out = cat(s_lmh_out)
Ns = len(store[0]['h_in'])
print(f'  Collected {Ns} token-position samples from {N} sequences')
print(f'\n' + '=' * 65)
print(f'  KERNEL TRAINING — lstsq per law')
print(f'  R² must = 1.000000 or kernel rejects')
print(f'=' * 65)
KL = []
for l in range(NL):
    s = store[l]
    lw = TL[l]
    print(f'\n  Layer {l}:')
    W_q = solve(s['ln1'], s['Q'], bias=False)
    rq = r2(s['ln1'] @ W_q, s['Q'])
    W_k = solve(s['ln1'], s['K'], bias=False)
    rk = r2(s['ln1'] @ W_k, s['K'])
    W_v = solve(s['ln1'], s['V'], bias=False)
    rv = r2(s['ln1'] @ W_v, s['V'])
    print(f'    WQ R²={rq:.6f}  WK R²={rk:.6f}  WV R²={rv:.6f}')
    W_o = solve(s['ctx'], s['att'], bias=False)
    ro = r2(s['ctx'] @ W_o, s['att'])
    print(f'    WO R²={ro:.6f}')
    W1 = solve(s['ln2'], s['pre'], bias=True)
    r1 = r2(np.c_[s['ln2'], np.ones(Ns)] @ W1, s['pre'])
    print(f'    W1 R²={r1:.6f}')
    Wg = solve(s['pre_ns'], s['gelu'], bias=False)
    rg = r2(s['pre_ns'] @ Wg, s['gelu'])
    print(f'    W_gelu R²={rg:.6f}  ← natural space (x, x²)')
    W2 = solve(s['gelu'], s['ffn'], bias=True)
    r2w = r2(np.c_[s['gelu'], np.ones(Ns)] @ W2, s['ffn'])
    print(f'    W2 R²={r2w:.6f}')
    assert all((v > 0.999 for v in [rq, rk, rv, ro, r1, rg, r2w])), f'FAIL: law not satisfied at layer {l}'
    KL.append({'W_q': W_q, 'W_k': W_k, 'W_v': W_v, 'W_o': W_o, 'W1': W1, 'Wg': Wg, 'W2': W2, 'LN1g': lw['LN1g'], 'LN1b': lw['LN1b'], 'LN2g': lw['LN2g'], 'LN2b': lw['LN2b']})
W_lmh = solve(lnf_out, lmh_out, bias=False)
rl = r2(lnf_out @ W_lmh, lmh_out)
print(f'\n  W_lmh R²={rl:.6f}')
assert rl > 0.999, 'FAIL: lm_head law not satisfied'
print(f'\n  ALL LAWS SATISFIED ✓')

def kernel_forward(seq):
    slen = len(seq)
    x = WTE[seq] + WPE[np.arange(slen)]
    for l in range(NL):
        kw = KL[l]
        ln1 = ln(x, kw['LN1g'], kw['LN1b'])
        Q = ln1 @ kw['W_q']
        K_ = ln1 @ kw['W_k']
        V = ln1 @ kw['W_v']
        Q_h = Q.reshape(slen, H, hd).transpose(1, 0, 2)
        K_h = K_.reshape(slen, H, hd).transpose(1, 0, 2)
        V_h = V.reshape(slen, H, hd).transpose(1, 0, 2)
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            p = softmax(Q_h[h] @ K_h[h].T + mk)
            heads.append(p @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(slen, D)
        att = ctx @ kw['W_o']
        hm = x + att
        ln2 = ln(hm, kw['LN2g'], kw['LN2b'])
        pre = np.c_[ln2, np.ones(slen)] @ kw['W1']
        gout = gelu(pre)
        ffn = np.c_[gout, np.ones(slen)] @ kw['W2']
        x = hm + ffn
    lf = ln(x, LNfg, LNfb)
    return lf @ W_lmh

def model_forward(seq):
    slen = len(seq)
    x = WTE[seq] + WPE[np.arange(slen)]
    for l in range(NL):
        lw = TL[l]
        ln1 = ln(x, lw['LN1g'], lw['LN1b'])
        Q = ln1 @ lw['WQ'].T
        K_ = ln1 @ lw['WK'].T
        V = ln1 @ lw['WV'].T
        Q_h = Q.reshape(slen, H, hd).transpose(1, 0, 2)
        K_h = K_.reshape(slen, H, hd).transpose(1, 0, 2)
        V_h = V.reshape(slen, H, hd).transpose(1, 0, 2)
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            p = softmax(Q_h[h] @ K_h[h].T + mk)
            heads.append(p @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(slen, D)
        att = ctx @ lw['WO'].T
        hm = x + att
        ln2 = ln(hm, lw['LN2g'], lw['LN2b'])
        pre = ln2 @ lw['W1'].T + lw['b1']
        gout = gelu(pre)
        ffn = gout @ lw['W2'].T + lw['b2']
        x = hm + ffn
    lf = ln(x, LNfg, LNfb)
    return lf @ WTE.T
print(f'\n' + '=' * 65)
print(f'  ACCURACY — TRANSFORMER vs KERNEL')
print(f'=' * 65)
correct_m = correct_k = correct_both = 0
for i in range(N):
    seq = X_ids[i].tolist()
    lm = model_forward(seq)
    lk = kernel_forward(seq)
    pm = np.argmax(lm, axis=-1)
    pk = np.argmax(lk, axis=-1)
    gt = y_ids[i]
    correct_m += int((pm == gt).sum())
    correct_k += int((pk == gt).sum())
    correct_both += int((pm == pk).sum())
total = N * K
acc_m = 100 * correct_m / total
acc_k = 100 * correct_k / total
tok_match = 100 * correct_both / total
print(f'\n  Transformer accuracy: {acc_m:.1f}%')
print(f'  Kernel accuracy:      {acc_k:.1f}%')
print(f'  Accuracy gap:         {abs(acc_m - acc_k):.1f}%')
print(f'  Token-level match:    {tok_match:.1f}%  ({correct_both}/{total} tokens)')
print(f'\n' + '=' * 65)
print(f'  GENERATION — TRANSFORMER vs KERNEL (20 tokens)')
print(f'=' * 65)
seeds = [['the', 'cat', 'sat', 'on'], ['the', 'dog', 'ran', 'on'], ['they', 'both', 'sat', 'on'], ['the', 'cat', 'looked', 'at']]
for seed in seeds:
    ids_m = [w2i[w] for w in seed]
    for _ in range(20):
        lg = model_forward(ids_m[-K:])
        ids_m.append(int(np.argmax(lg[-1])))
    ids_k = [w2i[w] for w in seed]
    for _ in range(20):
        lg = kernel_forward(ids_k[-K:])
        ids_k.append(int(np.argmax(lg[-1])))
    text_m = ' '.join((i2w[i] for i in ids_m))
    text_k = ' '.join((i2w[i] for i in ids_k))
    gen_m = ids_m[K:]
    gen_k = ids_k[K:]
    match = sum((a == b for a, b in zip(gen_m, gen_k)))
    same = '✓ IDENTICAL' if match == 20 else f'~ {match}/20 match'
    print(f"\n  Seed: {' '.join(seed)}")
    print(f'  Model:  {text_m}')
    print(f'  Kernel: {text_k}')
    print(f'  Match:  {same}')
print(f'\n' + '=' * 65)
print(f'  FINAL VERDICT')
print(f'=' * 65)
print(f"\n  Transformer:  {acc_m:.1f}%\n  Kernel:       {acc_k:.1f}%\n  Token match:  {tok_match:.1f}%\n\n  {('✓ KERNEL = MODEL — Laws are complete. Ready for 70B.' if tok_match > 99 else '~ KERNEL ≈ MODEL — Small numerical gap only.' if tok_match > 90 else '△ GAP EXISTS — Check which law has R² < 1.000 above.')}\n")
print('=' * 65 + '\n')
