import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import Counter
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (W-ATLAS)')
print('  Chaining 4-Token K-Signatures to Kill Entity Drift.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
HAMMING_THRESHOLD = 30
CONSENSUS_QUORUM = 5
ENTROPY_THRESHOLD = 0.9
print('\n  [ Phase 1 ] Building W-Atlas (4-Token Key Windows)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a blue dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden']
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_key = {l: [] for l in range(n_layers)}

def hook_key(l):

    def hook(m, i, o):
        store_key[l].append((o[:, -1, :] > 0).detach().cpu().numpy().astype(int))
    return hook
hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(hook_key(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        window_history = {l: [] for l in range(n_layers)}
        for _ in range(40):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                k_bits = store_key[l].pop()[0]
                window_history[l].append(k_bits)
                if len(window_history[l]) > 4:
                    window_history[l].pop(0)
                if len(window_history[l]) == 4:
                    atlas_key = np.concatenate(window_history[l])
                    RAM_chains[l].append(atlas_key)
                    RAM_sequences[l].append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    chains = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = [tuple(tokens[i:i + JUMP_LENGTH].tolist()) for i in range(len(tokens) - JUMP_LENGTH)]
    RAM_chains[l], RAM_sequences[l] = (chains[:len(seqs)], seqs)
print(f'  ✓ Saturated {len(RAM_sequences[0])} W-Atlas Chains.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 60
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] THE RACE: BASELINE vs. W-ATLAS')
print('─' * 75)
print('  Generating Baseline Truth...')
baseline_ids = tokenizer.encode(test_prompt, return_tensors='pt')
with torch.no_grad():
    for _ in range(tokens_to_gen):
        out = model(baseline_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        baseline_ids = torch.cat([baseline_ids, torch.tensor([[next_id]])], dim=1)
baseline_text = tokenizer.decode(baseline_ids[0])
print('  Executing W-Atlas Engine...')
atlas_history = {l: [] for l in range(n_layers)}
live_key = {l: None for l in range(n_layers)}

def get_key_hook(l):

    def hook(m, i, o):
        live_key[l] = (o[:, -1, :] > 0).detach().cpu().numpy().astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(get_key_hook(l)) for l in range(n_layers)]
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen = 0
start_time = time.time()
with torch.no_grad():
    while total_gen < tokens_to_gen:
        out = model(hub_ids)
        probs = torch.nn.functional.softmax(out.logits[0, -1, :], dim=-1)
        conf, truth_id = torch.max(probs, dim=-1)
        truth_id = truth_id.item()
        confidence = conf.item()
        for l in range(n_layers):
            atlas_history[l].append(live_key[l])
            if len(atlas_history[l]) > 4:
                atlas_history[l].pop(0)
        jump_found = False
        if confidence >= ENTROPY_THRESHOLD and len(atlas_history[0]) == 4:
            votes = []
            for l in range(n_layers):
                current_atlas = np.concatenate(atlas_history[l])
                mismatches = 1024 - np.sum(RAM_chains[l] == current_atlas, axis=1)
                best_idx = np.argmin(mismatches)
                if mismatches[best_idx] <= HAMMING_THRESHOLD:
                    votes.append(RAM_sequences[l][best_idx])
            if votes:
                vote_counts = Counter(votes)
                top_sequence, count = vote_counts.most_common(1)[0]
                if count >= CONSENSUS_QUORUM and top_sequence[0] == truth_id:
                    jump_text = tokenizer.decode(list(top_sequence))
                    print(f"  [✓ ATLAS JUMP ({count} Layers | Dist {mismatches[best_idx]})]: '{jump_text.strip()}'")
                    hub_ids = torch.cat([hub_ids, torch.tensor([list(top_sequence)])], dim=1)
                    for layer in range(n_layers):
                        atlas_history[layer] = []
                    total_gen += JUMP_LENGTH
                    jump_found = True
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            total_gen += 1
for h in live_hooks:
    h.remove()
hub_time = time.time() - start_time
hub_text = tokenizer.decode(hub_ids[0])
print('\n' + '=' * 75)
print('  W-ATLAS ENGINE VERDICT')
print('=' * 75)
print(f'  Execution Time  : {hub_time:.4f}s')
print(f'\n[ NORMAL MODEL ]:\n{baseline_text}')
print(f'\n[ W-ATLAS HUB ]:\n{hub_text}')
match_score = sum((1 for a, b in zip(baseline_text.split(), hub_text.split()) if a == b))
print(f'\n  Final Result: {match_score} words matched baseline.')
print('  W-Atlas uses 1024-bit contextual windows to separate')
print('  similar word trajectories, preventing gender/entity drift.')
print('=' * 75 + '\n')
