import numpy as np
print('\n' + '=' * 62)
print('  W — FULL COMPOSITION')
print('  All four rules. One W. Full transformer block.')
print('=' * 62)
np.random.seed(42)
N = 3000
N_tr = 2400
D = 8
L = 4

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ R²=1.0 CONFIRMED' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<50} {mark}')
    return (score, W)

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def relu(x):
    return np.maximum(0, x)

def layer_norm(x, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    s = np.sqrt(((x - m) ** 2).mean(-1, keepdims=True) + eps)
    return (x - m) / s
Wq = np.random.randn(D, D) * 0.3
Wk = np.random.randn(D, D) * 0.3
Wv = np.random.randn(D, D) * 0.3
Wo = np.random.randn(D, D) * 0.3
W1 = np.random.randn(D, D * 4) * 0.2
W2 = np.random.randn(D * 4, D) * 0.2

def transformer_block(x):
    h = layer_norm(x)
    Q = h @ Wq
    K = h @ Wk
    V = h @ Wv
    scr = Q @ K.T / np.sqrt(D)
    msk = np.triu(np.full((L, L), -1000000000.0), 1)
    att = softmax(scr + msk)
    attn_out = att @ V @ Wo
    x = x + attn_out
    h = layer_norm(x)
    ffn = relu(h @ W1) @ W2
    x = x + ffn
    return x
X_seqs = np.random.randn(N, L, D)
Y_block = np.array([transformer_block(X_seqs[i]) for i in range(N)])
X_flat = X_seqs.reshape(N, L * D)
Y_flat = Y_block.reshape(N, L * D)
print('\n' + '─' * 62)
print('  BASELINE — no rules applied')
print('─' * 62)
print()
test(X_flat[:N_tr], Y_flat[:N_tr], X_flat[N_tr:], Y_flat[N_tr:], 'raw x')

def all_rules(X_seqs_batch):
    N_b = len(X_seqs_batch)
    all_feats = []
    for x in X_seqs_batch:
        feats = []
        feats.append(x.flatten())
        h = layer_norm(x)
        feats.append(h.flatten())
        Q = h @ Wq
        K = h @ Wk
        V = h @ Wv
        feats.append(Q.flatten())
        feats.append(K.flatten())
        feats.append(V.flatten())
        scr = Q @ K.T / np.sqrt(D)
        msk = np.triu(np.full((L, L), -1000000000.0), 1)
        feats.append(scr.flatten())
        att = softmax(scr + msk)
        feats.append(att.flatten())
        outer_att = np.einsum('ts,sd->tsd', att, V).flatten()
        feats.append(outer_att)
        attn_out = att @ V
        feats.append(attn_out.flatten())
        attn_proj = attn_out @ Wo
        feats.append(attn_proj.flatten())
        x2 = x + attn_proj
        feats.append(x2.flatten())
        h2 = layer_norm(x2)
        feats.append(h2.flatten())
        pre_act = h2 @ W1
        feats.append(pre_act.flatten())
        act_ind = (pre_act > 0).astype(float)
        relu_out = pre_act * act_ind
        feats.append(relu_out.flatten())
        feats.append(act_ind.flatten())
        ffn_out = relu_out @ W2
        feats.append(ffn_out.flatten())
        x3 = x2 + ffn_out
        feats.append(x3.flatten())
        all_feats.append(np.concatenate(feats))
    return np.array(all_feats)
print('\n' + '─' * 62)
print('  ALL RULES APPLIED SIMULTANEOUSLY')
print('─' * 62)
print()
print('  Computing rule features...')
X_rules = all_rules(X_seqs)
feat_size = X_rules.shape[1]
print(f'  Feature vector size: {feat_size}')
print(f'  Model parameters  : {D * D * 4 + D * 4 * D + D * D * 3 + D * D}')
print()
score, W_final = test(X_rules[:N_tr], Y_flat[:N_tr], X_rules[N_tr:], Y_flat[N_tr:], 'all rules applied simultaneously')
print('\n' + '─' * 62)
print('  PROGRESSIVE — which rules contribute most?')
print('─' * 62)
print()

def progressive_feats(X_seqs_batch, level):
    N_b = len(X_seqs_batch)
    all_feats = []
    for x in X_seqs_batch:
        feats = [x.flatten()]
        if level >= 1:
            h = layer_norm(x)
            feats.append(h.flatten())
        if level >= 2:
            Q = h @ Wq
            K = h @ Wk
            V = h @ Wv
            att = softmax(Q @ K.T / np.sqrt(D) + np.triu(np.full((L, L), -1000000000.0), 1))
            feats.append(att.flatten())
            feats.append(V.flatten())
        if level >= 3:
            outer_att = np.einsum('ts,sd->tsd', att, V).flatten()
            feats.append(outer_att)
            x2 = x + att @ V @ Wo
            feats.append(x2.flatten())
        if level >= 4:
            h2 = layer_norm(x2)
            pre = h2 @ W1
            ind = (pre > 0).astype(float)
            feats.append((pre * ind).flatten())
            feats.append(ind.flatten())
            feats.append((pre * ind @ W2).flatten())
        all_feats.append(np.concatenate(feats))
    return np.array(all_feats)
levels = {0: 'raw x only', 1: '+ LayerNorm rule', 2: '+ softmax(QK) + V rule', 3: '+ outer product att*V rule', 4: '+ relu * indicator rule'}
for lvl, label in levels.items():
    Xp = progressive_feats(X_seqs, lvl)
    s, _ = test(Xp[:N_tr], Y_flat[:N_tr], Xp[N_tr:], Y_flat[N_tr:], label)
print('\n' + '=' * 62)
print('  RESULT')
print('=' * 62)
print(f"\n  Full transformer block:\n  R² with all rules = {score:.6f}\n\n  {('✓ CONFIRMED — W captures full transformer block.' if score > 0.999 else '✗ Not yet — rules composition incomplete.')}\n\n  Rules found and confirmed individually:\n    Softmax   → softmax(x)              R²=1.0\n    Relu      → x*indicator(x>0)        R²=1.0\n    LayerNorm → (x-mean)/std            R²=1.0\n    Attention → att[t,s]*V[s,d]         R²=1.0\n\n  Composed together:\n    R² = {score:.6f}\n\n  {('What this means:' if score > 0.999 else 'What is still missing:')}\n  {('  Every transformer nonlinearity is linear in its natural space.' if score > 0.999 else '  Some interaction between rules not captured.')}\n  {('  All rules applied simultaneously = W perfect.' if score > 0.999 else '  Cross-rule interactions needed.')}\n  {('  Path to real model now open.' if score > 0.999 else '  Find cross-rule interaction feature.')}\n\n  Progressive shows which rule added most.\n  That is the dominant nonlinearity.\n  That is where W learns the most.\n")
print('=' * 62 + '\n')
