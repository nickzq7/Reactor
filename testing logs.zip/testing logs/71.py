import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]
SEQ_LEN = 4
NORM = 1000.0

def gen_sequences(n_each=500):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) ** 3 for j in range(SEQ_LEN + 1)]
        if seq[-1] < NORM * 10:
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences(n_each=300)
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Data: {len(X)} sequences  input={SEQ_LEN} values → predict 1')

class Net(nn.Module):

    def __init__(self, dim, numbers=None):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(SEQ_LEN, dim), nn.Tanh(), nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, 1))
        if numbers is not None:
            arr = np.array(numbers, dtype=np.float32)
            arr = arr / np.max(np.abs(arr))
            tiled = np.tile(arr, int(np.ceil(dim / len(arr))))[:dim]
            W = np.zeros((dim, SEQ_LEN), dtype=np.float32)
            for col in range(SEQ_LEN):
                W[:, col] = tiled * (col + 1) / SEQ_LEN
            with torch.no_grad():
                self.net[0].weight.copy_(torch.tensor(W))

    def forward(self, x):
        return self.net(x)

def train(model, epochs=1000, lr=0.005, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-05)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        if ep % 200 == 0:
            print(f'    {label}  ep{ep}  best={best:.6f}')
    if best_st:
        model.load_state_dict(best_st)
    return best

def v16_transfer(teacher, student):
    W_T = teacher.net[0].weight.detach().cpu().numpy()
    W_S = student.net[0].weight.detach().cpu().numpy()
    proj = np.zeros_like(W_S)
    for col in range(SEQ_LEN):
        proj[:, col] = np.interp(np.linspace(0, len(W_T) - 1, len(W_S)), np.arange(len(W_T)), W_T[:, col])
    scale = np.std(W_S) / (np.std(proj) + 1e-08)
    proj = proj * scale
    blend = 0.5 * W_S + 0.5 * proj
    agree = np.sum(W_S * proj, axis=1)
    flips = np.argsort(agree)[-3:]
    blend[flips, :] *= -1
    with torch.no_grad():
        student.net[0].weight.copy_(torch.tensor(blend, dtype=torch.float32).to(device))
    print(f'  V16 injected  16→256  flips={flips.tolist()}')
TESTS = [('squares:  1,4,9,16→?', [1, 4, 9, 16], 25), ('squares:  4,9,16,25→?', [4, 9, 16, 25], 36), ('squares:  9,16,25,36→?', [9, 16, 25, 36], 49), ('squares:  16,25,36,49→?', [16, 25, 36, 49], 64), ('squares:  25,36,49,64→?', [25, 36, 49, 64], 81), ('arith+2:  2,4,6,8→?', [2, 4, 6, 8], 10), ('arith+2:  10,12,14,16→?', [10, 12, 14, 16], 18), ('arith+3:  3,6,9,12→?', [3, 6, 9, 12], 15), ('arith+5:  5,10,15,20→?', [5, 10, 15, 20], 25), ('arith+7:  7,14,21,28→?', [7, 14, 21, 28], 35), ('geom×2:   1,2,4,8→?', [1, 2, 4, 8], 16), ('geom×2:   2,4,8,16→?', [2, 4, 8, 16], 32), ('geom×2:   3,6,12,24→?', [3, 6, 12, 24], 48), ('geom×3:   1,3,9,27→?', [1, 3, 9, 27], 81), ('geom×3:   2,6,18,54→?', [2, 6, 18, 54], 162), ('fib:      1,1,2,3→?', [1, 1, 2, 3], 5), ('fib:      1,2,3,5→?', [1, 2, 3, 5], 8), ('fib:      2,3,5,8→?', [2, 3, 5, 8], 13), ('fib:      3,5,8,13→?', [3, 5, 8, 13], 21), ('fib:      5,8,13,21→?', [5, 8, 13, 21], 34), ('tri:      1,3,6,10→?', [1, 3, 6, 10], 15), ('tri:      3,6,10,15→?', [3, 6, 10, 15], 21), ('tri:      6,10,15,21→?', [6, 10, 15, 21], 28), ('tri:      10,15,21,28→?', [10, 15, 21, 28], 36), ('tri:      15,21,28,36→?', [15, 21, 28, 36], 45), ('cubes:    1,8,27,64→?', [1, 8, 27, 64], 125), ('cubes:    8,27,64,125→?', [8, 27, 64, 125], 216), ('arith+1:  1,2,3,4→?', [1, 2, 3, 4], 5), ('arith+1:  10,11,12,13→?', [10, 11, 12, 13], 14), ('arith+1:  99,100,101,102→?', [99, 100, 101, 102], 103)]
TOL = 0.05

def evaluate(model, label):
    model.eval()
    correct = 0
    print(f'\n  ── {label} ──')
    print(f"  {'Task':<35} {'True':>7}  {'Pred':>7}  {'Err':>7}  Result")
    print(f"  {'─' * 65}")
    with torch.no_grad():
        for desc, seq, true_next in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            pred = model(xt).item() * NORM
            err = abs(pred - true_next) / NORM
            ok = err <= TOL
            if ok:
                correct += 1
            tag = '✓' if ok else '✗'
            print(f'  {desc:<35} {true_next:>7.0f}  {pred:>7.1f}  {err * NORM:>7.1f}  {tag}')
    pct = correct / len(TESTS) * 100
    print(f'\n  Score: {correct}/{len(TESTS)}  ({pct:.1f}%)')
    return correct
print(f"\n{'=' * 65}")
print('  STEP 1 — 16-dim PRIME TEACHER')
print(f"{'=' * 65}")
teacher = Net(16, numbers=BEST_PRIMES).to(device)
print(f'  Params: {sum((p.numel() for p in teacher.parameters())):,}')
train(teacher, epochs=1000, lr=0.005, label='TEACHER')
print(f"\n{'=' * 65}")
print('  STEP 2 — 256-dim FLAT alone (Model A)')
print(f"{'=' * 65}")
model_A = Net(256).to(device)
print(f'  Params: {sum((p.numel() for p in model_A.parameters())):,}')
train(model_A, epochs=1000, lr=0.005, label='MODEL_A')
print(f"\n{'=' * 65}")
print('  STEP 3 — V16: prime teacher → 256-dim (Model B)')
print(f"{'=' * 65}")
model_B = Net(256).to(device)
v16_transfer(teacher, model_B)
train(model_B, epochs=1000, lr=0.005, label='MODEL_B')
print(f"\n{'=' * 65}")
print('  GENERATION TEST — 30 sequences')
print(f"{'=' * 65}")
score_T = evaluate(teacher, 'MODEL C — 16-dim PRIME TEACHER')
score_A = evaluate(model_A, 'MODEL A — 256-dim FLAT alone')
score_B = evaluate(model_B, 'MODEL B — 256-dim + V16 prime')
print(f"\n{'=' * 65}")
print(f'  FINAL SCOREBOARD')
print(f"{'=' * 65}")
print(f'  Model C  16-dim  prime   params=321      : {score_T}/{len(TESTS)}  ({score_T / len(TESTS) * 100:.1f}%)')
print(f'  Model A  256-dim flat    params=66,561   : {score_A}/{len(TESTS)}  ({score_A / len(TESTS) * 100:.1f}%)')
print(f'  Model B  256-dim+V16     params=66,561   : {score_B}/{len(TESTS)}  ({score_B / len(TESTS) * 100:.1f}%)')
print(f"{'=' * 65}")
best = max(score_T, score_A, score_B)
if score_B == best and score_B > score_A:
    print(f'\n  ✓ V16 PRIME TRANSFER WINS — structure transfers to big model')
elif score_T == best and score_T >= score_A:
    print(f'\n  ✓ SMALL PRIME STRUCTURE WINS — 321 params beats 66,561')
else:
    print(f'\n  Flat 256 leads — structure needs more refinement')
