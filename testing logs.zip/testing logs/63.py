import numpy as np
import torch
import torch.nn as nn
import time
from scipy import stats
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
DIM = 16
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(1000)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

class FlatNet(nn.Module):

    def __init__(self, n_layers=10, dim=DIM):
        super().__init__()
        layers = [nn.Linear(SEQ_LEN, dim), nn.Tanh()]
        for _ in range(n_layers - 1):
            layers += [nn.Linear(dim, dim), nn.Tanh()]
        layers.append(nn.Linear(dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

    def get_linear_layers(self):
        return [m for m in self.net if isinstance(m, nn.Linear)]

def score_model(model):
    model.eval()
    correct = 0
    with torch.no_grad():
        for seq, true_next in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            pred = model(xt).item() * NORM
            if abs(pred - true_next) / NORM <= TOL:
                correct += 1
    return correct
print(f"\n{'=' * 65}")
print('  TRAINING 10-layer flat model to perfect score...')
print(f"{'=' * 65}")
model = FlatNet(n_layers=10, dim=DIM).to(device)
print(f'  Params: {sum((p.numel() for p in model.parameters())):,}')
opt = torch.optim.Adam(model.parameters(), lr=0.003)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=2000, eta_min=1e-05)
loss_fn = nn.MSELoss()
best = 9999.0
best_st = None
for ep in range(1, 2001):
    model.train()
    l = loss_fn(model(X_tr), Y_tr)
    opt.zero_grad()
    l.backward()
    opt.step()
    sched.step()
    with torch.no_grad():
        v = loss_fn(model(X_te), Y_te).item()
    if not np.isnan(v) and v < best:
        best = v
        best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
    if ep % 400 == 0:
        s = score_model(model)
        print(f'    ep{ep}  loss={best:.4f}  score={s}/{len(TESTS)}')
model.load_state_dict(best_st)
final_score = score_model(model)
print(f'\n  Final: loss={best:.4f}  score={final_score}/{len(TESTS)}')
print(f"\n{'=' * 65}")
print('  EXTRACTING LEARNED GEOMETRY FROM EVERY LAYER')
print(f"{'=' * 65}")
linears = model.get_linear_layers()
print(f'  Linear layers found: {len(linears)}')

def normalize(arr):
    arr = np.array(arr, dtype=np.float64)
    arr = arr - arr.min()
    if arr.max() > 0:
        arr = arr / arr.max()
    return arr
fibs = [1, 1]
while len(fibs) < DIM:
    fibs.append(fibs[-1] + fibs[-2])
REFERENCES = {'prime': normalize(BEST_PRIMES[:DIM]), 'fibonacci': normalize(fibs[:DIM]), 'powers2': normalize([2.0 ** i for i in range(DIM)]), 'uniform': normalize(np.linspace(0, 1, DIM)), 'log': normalize([np.log(i + 2) for i in range(DIM)]), 'sine': normalize([np.sin(i * np.pi / DIM) for i in range(DIM)]), 'linear': normalize(list(range(DIM))), 'sqrt': normalize([np.sqrt(i + 1) for i in range(DIM)]), 'exp': normalize([np.exp(i / DIM) for i in range(DIM)]), 'gaps': normalize([ALL_PRIMES[i + 1] - ALL_PRIMES[i] for i in range(DIM)]), 'triangular': normalize([i * (i + 1) / 2 for i in range(1, DIM + 1)]), 'every6th': normalize(ALL_PRIMES[::6][:DIM])}

def analyze_layer(W, layer_idx, layer_name):
    W = W.detach().cpu().numpy()
    row_norms = np.linalg.norm(W, axis=1)
    sorted_norms = np.sort(row_norms)
    sig = normalize(sorted_norms)
    print(f'\n  ── {layer_name} (shape={W.shape}) ──')
    similarities = {}
    for ref_name, ref_arr in REFERENCES.items():
        if len(ref_arr) == len(sig):
            corr, pval = stats.pearsonr(sig, ref_arr)
            similarities[ref_name] = corr
    ranked = sorted(similarities.items(), key=lambda x: abs(x[1]), reverse=True)
    print(f'  Neuron norm distribution (sorted):')
    print(f'    min={sorted_norms.min():.4f}  max={sorted_norms.max():.4f}  mean={sorted_norms.mean():.4f}  std={sorted_norms.std():.4f}')
    print(f'\n  Similarity to known geometries:')
    for ref_name, corr in ranked[:5]:
        bar = '█' * int(abs(corr) * 20)
        direction = '+' if corr > 0 else '-'
        print(f'    {ref_name:<14} r={corr:>+.4f}  {bar}')
    best_match = ranked[0][0]
    best_corr = ranked[0][1]
    gaps = np.diff(sorted_norms)
    gap_std = np.std(gaps)
    gap_mean = np.mean(gaps)
    cv = gap_std / (gap_mean + 1e-08)
    if cv < 0.3:
        spacing = 'UNIFORM spacing'
    elif cv < 0.8:
        spacing = 'MODERATE variation'
    else:
        spacing = 'HIGH variation (structured)'
    print(f'\n  Gap CV={cv:.3f} → {spacing}')
    print(f'  Best match: {best_match} (r={best_corr:.4f})')
    return (best_match, best_corr, sig, sorted_norms)
layer_results = []
for i, lin in enumerate(linears[:-1]):
    name = f'Layer {i + 1}'
    best_match, corr, sig, norms = analyze_layer(lin.weight, i, name)
    layer_results.append((name, best_match, corr, norms))
print(f"\n{'=' * 65}")
print('  CROSS-LAYER GEOMETRY EVOLUTION')
print(f"{'=' * 65}")
print(f'\n  How geometry changes from layer 1 → layer 10:')
print(f"  {'Layer':<10}  {'Best Match':<16}  {'Correlation':>12}  Pattern")
print(f"  {'─' * 55}")
for name, best_match, corr, norms in layer_results:
    bar = '█' * int(abs(corr) * 15)
    print(f'  {name:<10}  {best_match:<16}  {corr:>+12.4f}  {bar}')
print(f"\n{'=' * 65}")
print('  WHAT DID THE MODEL DISCOVER?')
print(f"{'=' * 65}")
all_matches = [r[1] for r in layer_results]
match_counts = {}
for m in all_matches:
    match_counts[m] = match_counts.get(m, 0) + 1
most_common = sorted(match_counts.items(), key=lambda x: -x[1])
print(f'\n  Most common geometry across all layers:')
for geo, count in most_common:
    bar = '█' * count
    print(f'    {geo:<14} found in {count} layers  {bar}')
print(f"\n{'=' * 65}")
print('  VALIDATION: Is discovered geometry better than imposed?')
print(f"{'=' * 65}")
dominant_geo = most_common[0][0]
print(f'\n  Dominant discovered geometry: {dominant_geo}')

def build_W_from_geo(geo, out_dim, in_dim):
    if geo == 'prime':
        arr = np.array(BEST_PRIMES[:out_dim], dtype=np.float32)
    elif geo == 'fibonacci':
        f = [1, 1]
        while len(f) < out_dim:
            f.append(f[-1] + f[-2])
        arr = np.array(f[:out_dim], dtype=np.float32)
    elif geo == 'powers2':
        arr = np.array([2.0 ** i for i in range(out_dim)], dtype=np.float32)
    elif geo == 'uniform':
        arr = np.linspace(-1, 1, out_dim).astype(np.float32)
    elif geo == 'log':
        arr = np.array([np.log(i + 2) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'sqrt':
        arr = np.array([np.sqrt(i + 1) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'exp':
        arr = np.array([np.exp(i / out_dim) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'linear':
        arr = np.array(list(range(out_dim)), dtype=np.float32)
    else:
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
    arr = arr / (np.max(np.abs(arr)) + 1e-08)
    W = np.zeros((out_dim, in_dim), dtype=np.float32)
    for col in range(in_dim):
        W[:, col] = arr * (col + 1) / in_dim
    return W

class ImposedNet(nn.Module):

    def __init__(self, geo, n_layers=10, dim=DIM):
        super().__init__()
        layers = []
        in_d = SEQ_LEN
        for _ in range(n_layers):
            lin = nn.Linear(in_d, dim)
            with torch.no_grad():
                lin.weight.copy_(torch.tensor(build_W_from_geo(geo, dim, in_d)))
            layers += [lin, nn.Tanh()]
            in_d = dim
        layers.append(nn.Linear(dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

def train_and_score(model, label, epochs=1000, lr=0.003):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-05)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
    if best_st:
        model.load_state_dict(best_st)
    s = score_model(model)
    print(f'  {label:<35} score={s}/{len(TESTS)}  loss={best:.4f}')
    return (s, best)
print(f'\n  Comparing: flat (self-discovers) vs imposed {dominant_geo}')
np.random.seed(42)
m_flat = FlatNet(10, DIM).to(device)
s_flat, l_flat = train_and_score(m_flat, '10-layer FLAT (self-discovers)')
np.random.seed(42)
m_imp = ImposedNet(dominant_geo, 10, DIM).to(device)
s_imp, l_imp = train_and_score(m_imp, f'10-layer {dominant_geo.upper()} (imposed)')
print(f"\n{'=' * 65}")
print(f'  FINAL ANSWER — What geometry did the deep model discover?')
print(f"{'=' * 65}")
print(f'\n  Geometry found in each layer:')
for name, match, corr, _ in layer_results:
    print(f'    {name}: {match} (r={corr:.3f})')
print(f'\n  Most common: {dominant_geo}')
print(f'\n  Flat (discovers naturally): {s_flat}/{len(TESTS)}')
print(f'  {dominant_geo} (imposed):         {s_imp}/{len(TESTS)}')
if s_flat >= s_imp:
    print(f'\n  CONCLUSION: Self-discovered geometry = BETTER')
    print(f'  The model found something that cannot be pre-designed')
    print(f'  Natural emergence > imposed structure')
    print(f'  This is the deepest finding: true intelligence')
    print(f'  cannot be designed — it must be discovered')
else:
    print(f'\n  CONCLUSION: Imposed {dominant_geo} matches discovered geometry')
    print(f'  The model converges to a known mathematical structure')
    print(f'  This structure can be pre-designed for faster convergence')
