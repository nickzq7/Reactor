import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer
import time
print('\n' + '=' * 62)
print('  W — MINIMUM MEETING')
print('  How few layers before coherence breaks?')
print('  That minimum IS the W kernel.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
print(f'  Loaded. {n_layers} layers. {D}D. {model_mem / 1024 / 1024:.1f}MB.')

def partial_forward(input_ids, n_layers_use):
    with torch.no_grad():
        h = model.transformer.wte(input_ids)
        if hasattr(model.transformer, 'wpe'):
            pos = torch.arange(input_ids.shape[1]).unsqueeze(0)
            h = h + model.transformer.wpe(pos)
        for i in range(min(n_layers_use, n_layers)):
            h = model.transformer.h[i](h)[0]
        h = model.transformer.ln_f(h)
        logits = model.lm_head(h)
    return logits

def generate_with_n_layers(prompt, n_layers_use, max_new_tokens=50):
    ids = tokenizer.encode(prompt, return_tensors='pt')
    for _ in range(max_new_tokens):
        logits = partial_forward(ids, n_layers_use)
        next_id = logits[0, -1].argmax().item()
        if next_id == tokenizer.eos_token_id:
            break
        ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
    return tokenizer.decode(ids[0], skip_special_tokens=True)
common = set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 'up', 'down', 'out', 'is', 'was', 'are', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'shall', 'he', 'she', 'it', 'they', 'we', 'you', 'i', 'his', 'her', 'its', 'their', 'our', 'your', 'my', 'this', 'that', 'these', 'those', 'not', 'no', 'yes', 'so', 'as', 'if', 'then', 'than', 'when', 'where', 'who', 'what', 'how', 'there', 'here', 'little', 'big', 'small', 'old', 'new', 'good', 'great', 'happy', 'sad', 'said', 'went', 'came', 'saw', 'got', 'took', 'made', 'looked', 'wanted', 'liked', 'loved', 'played', 'ran', 'walked', 'smiled', 'laughed', 'cried', 'found', 'heard', 'once', 'upon', 'time', 'day', 'one', 'two', 'three', 'she', 'he', 'her', 'him', 'they', 'them', 'his', 'girl', 'boy', 'dog', 'cat', 'tree', 'house', 'park', 'pond', 'woods', 'forest', 'sky', 'sun', 'named', 'lily', 'tom', 'emma', 'jack', 'mom', 'dad', 'friend'])

def coherence_score(text, prompt):
    generated = text[len(prompt):].strip()
    if not generated:
        return 0.0
    words = [w.lower().strip('.,!?"\'') for w in generated.split()]
    if not words:
        return 0.0
    real = sum((1 for w in words if w in common or len(w) <= 3))
    return real / len(words)

def loop_score(text):
    words = text.split()
    if len(words) < 4:
        return 0.0
    trigrams = [tuple(words[i:i + 3]) for i in range(len(words) - 2)]
    unique = len(set(trigrams))
    total = len(trigrams)
    return 1.0 - unique / max(total, 1)

def wrap(text, width=54, indent='    '):
    words = text.split()
    lines = []
    line = indent
    for w in words:
        if len(line) + len(w) > width:
            lines.append(line)
            line = indent + w + ' '
        else:
            line += w + ' '
    if line.strip():
        lines.append(line)
    return '\n'.join(lines[:4])

def memory_for_n_layers(n):
    embed_mem = (model.transformer.wte.weight.numel() + (model.transformer.wpe.weight.numel() if hasattr(model.transformer, 'wpe') else 0)) * 4
    layer_mem = sum((sum((p.numel() for p in model.transformer.h[i].parameters())) * 4 for i in range(min(n, n_layers))))
    head_mem = model.lm_head.weight.numel() * 4
    ln_mem = sum((p.numel() for p in model.transformer.ln_f.parameters())) * 4
    return embed_mem + layer_mem + head_mem + ln_mem
print('\n' + '=' * 62)
print('  TESTING 0 TO 8 LAYERS')
print('  Finding minimum meeting point.')
print('=' * 62)
prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'One day a small rabbit decided to']
print(f"\n  {'Layers':>7} {'Memory':>9} {'Coherence':>11} {'Loops':>8} {'Verdict':>10}")
print(f"  {'-' * 52}")
results = {}
for n in range(0, n_layers + 1):
    mem = memory_for_n_layers(n)
    coh_scores = []
    loop_scores = []
    for prompt in prompts:
        try:
            text = generate_with_n_layers(prompt, n, max_new_tokens=40)
            coh = coherence_score(text, prompt)
            loops = loop_score(text)
            coh_scores.append(coh)
            loop_scores.append(loops)
        except Exception as e:
            coh_scores.append(0)
            loop_scores.append(1)
    avg_coh = np.mean(coh_scores)
    avg_loop = np.mean(loop_scores)
    if avg_coh > 0.5 and avg_loop < 0.3:
        verdict = 'COHERENT'
    elif avg_coh > 0.3 and avg_loop < 0.5:
        verdict = 'PARTIAL'
    elif avg_loop > 0.7:
        verdict = 'LOOPING'
    else:
        verdict = 'INCOHERENT'
    results[n] = {'mem': mem, 'coh': avg_coh, 'loop': avg_loop, 'verdict': verdict}
    bar = '█' * int(avg_coh * 10)
    print(f'  {n:>7} {mem / 1024 / 1024:>7.2f}MB {avg_coh * 100:>9.1f}% {avg_loop * 100:>6.1f}% {verdict:>12}')
min_coherent = None
for n in range(n_layers + 1):
    if results[n]['verdict'] in ('COHERENT', 'PARTIAL'):
        min_coherent = n
        break
print('\n' + '=' * 62)
print('  TEXT OUTPUT AT KEY POINTS')
print('=' * 62)
key_layers = [0, 1, 2, 4, 8]
prompt = 'Once upon a time there was a little girl'
print(f'\n  Prompt: "{prompt}"\n')
for n in key_layers:
    text = generate_with_n_layers(prompt, n, max_new_tokens=40)
    mem = results[n]['mem']
    coh = results[n]['coh']
    v = results[n]['verdict']
    print(f"  ── {n} layer{('s' if n != 1 else ' ')} ({mem / 1024 / 1024:.2f}MB) [{v}] ──")
    print(wrap(text))
    print()
print('=' * 62)
print('  THE W FINDING')
print('=' * 62)
min_c = min_coherent if min_coherent is not None else n_layers
mem_min = results[min_c]['mem']
mem_full = results[n_layers]['mem']
print(f"\n  Full model   : {n_layers} layers, {mem_full / 1024 / 1024:.2f}MB\n  W minimum    : {min_c} layer{('s' if min_c != 1 else ' ')}, {mem_min / 1024 / 1024:.2f}MB\n  Reduction    : {mem_full / mem_min:.1f}x smaller\n\n  The minimum meeting point:\n  Arrow (weights) and particle (input)\n  must meet for at least {min_c} layer{('s' if min_c != 1 else '')}.\n  Below that — coherence breaks.\n  At that point — coherence holds.\n\n  That minimum IS the W kernel depth.\n  Not chosen by theory.\n  Found by experiment.\n  The universe answered.\n\n  For 70B model (same ratio):\n  Full 70B     : 80 layers, ~140GB\n  W minimum    : {int(80 * min_c / n_layers)} layers, ~{140 * min_c / n_layers:.1f}GB\n  Fits in 6GB  : {('YES' if 140 * min_c / n_layers < 6 else 'NOT YET — but reduction is real')}\n\n  Next question:\n  Why does coherence need {min_c} layer{('s' if min_c != 1 else '')}?\n  What specifically happens in those layers\n  that cannot happen without them?\n  That answer = the true W kernel form.\n")
print('=' * 62 + '\n')
