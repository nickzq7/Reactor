import numpy as np
import torch
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL TRAINER v2 — FIXED FORWARD PASS')
print('  Full sequence propagation. W-Kernel on last token only.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model_ref = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model_ref.eval()
n_layers = model_ref.config.num_layers
n_heads = model_ref.config.num_attention_heads
D = model_ref.config.hidden_size
head_dim = D // n_heads
FFN_D = model_ref.transformer.h[0].mlp.c_fc.weight.shape[0]

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_np(x):
    x = x.astype(np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def quad_kernel(x):
    x = np.array(x, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(1, -1)
    N, d = x.shape
    idx_i, idx_j = np.triu_indices(d)
    cross = x[:, idx_i] * x[:, idx_j]
    return np.hstack([x, cross])

def solve_exact(Phi, Y):
    Phi = np.array(Phi, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Phi_b = np.hstack([Phi, np.ones((len(Phi), 1))])
    W, _, _, _ = np.linalg.lstsq(Phi_b, Y, rcond=None)
    Yp = Phi_b @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    r2 = float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0
    return (W, r2)
TRAIN_PROMPTS = ['Once upon a time a little girl named Lily', 'Deep in the forest there lived a dragon', 'A small dog ran across the green field', 'The brave knight rode into the dark cave', 'She opened the door and smiled at her friend', 'Every morning the birds sang in the tall tree', 'He found a golden key under the old bridge', 'The children played and laughed in the garden', 'Far away there lived a kind old wizard', 'A tiny mouse found some cheese in the barn', 'The princess wore a crown and sat on the throne', 'A rainbow appeared in the sky after the rain', 'The farmer planted seeds in the rich dark soil', 'She read a book about dragons and magic spells', 'The river flowed gently through the green valley', 'A butterfly landed softly on the red flower', 'The ship sailed across the deep blue ocean', 'The moon rose high above the sleeping town', 'A bear found honey in a hollow tree trunk', 'The wind carried the leaves high into the air', 'Once there was a boy who loved to explore', 'The cat sat by the warm fire and purred', 'He climbed the tall mountain and saw the sky', 'She sang a song that made everyone smile', 'A fox ran through the forest looking for food', 'The old man told stories to the young children', 'A baby bird fell from its nest in the oak', 'The cook made a soup that smelled wonderful', 'He drew a picture of his house and garden', 'The queen walked through the market with grace', 'Once a young prince found a magic mirror', 'The stars shone bright above the sleeping child', 'A little fish swam in the clear blue pond', 'The baker made fresh bread every single morning', 'She found a map that led to buried treasure', 'The little rabbit hopped through the meadow', 'Once a young boy found a magic stone', 'The old lighthouse stood by the stormy sea', 'A girl named Emma loved to paint pictures', 'The dragon breathed fire and the village ran', 'A kind witch lived in the old apple orchard', 'The tiny boat sailed far across the great lake', 'He whispered a secret into the old oak tree', 'The clever fox outsmarted the hungry wolf again', 'A magic carpet flew high above the golden city', 'The snow fell softly on the sleeping village', 'She found a door hidden behind the waterfall', 'The little prince asked why the stars were bright', 'A dragon egg hatched under the full blue moon', 'The shepherd counted stars until he fell asleep', 'The old clock ticked slowly in the quiet room', 'A young girl learned to fly on a broomstick', 'The river whispered secrets to the listening stones', 'He opened the treasure chest and found a map', 'The wolf howled at the moon above the hills', 'She planted a seed and a great tree grew', 'The knight bowed before the wise old queen', 'A tiny star fell gently into the child hand', 'The baker smiled and gave the boy fresh bread', 'Deep underground a city of gnomes was hidden', 'The little owl asked who had taken the moon', 'A princess danced alone in the empty tower', 'The giant sat down and the earth shook gently', 'He found a bottle with a message inside it', 'The fairy left a gift under the sleeping child', 'A wolf pup howled for the first time at dawn', 'The wizard opened his eyes and saw the future', 'She whispered to the river and it changed course', 'A golden bird sang and the flowers all bloomed', 'The boy asked the star how far away it was', 'Deep in the cave the treasure chest glowed bright', 'The little turtle walked slowly to the big lake', 'A kind dragon helped the children cross the river', 'The moon asked the sun to share some of its light', 'She baked a cake and the whole village smelled it', 'The tiny elf repaired shoes while everyone slept', 'A blue whale swam under the boat and smiled up', 'The old tower had a secret room at the very top', 'He taught the young rabbits how to find their way', 'The enchanted forest glowed softly in the moonlight', 'A small girl found a door in the base of the tree']
TEST_PROMPTS = ['The little fox found a shiny stone by the river', 'Once a kind farmer helped a lost baby deer', 'She climbed the tall tree and saw the whole village', 'A brave boy sailed across the dark stormy sea', 'The old wizard gave the child a glowing lantern', 'A rabbit and a turtle became the best of friends', 'The queen looked out her window at the falling snow', 'He woke up early and saw the first light of dawn', 'A small seed grew into the tallest tree in the land', 'The sleepy bear found a cave and curled up inside']
SEQ_LEN = 10
N_STEPS = 70
wte = model_ref.transformer.wte.weight.detach().numpy()
wpe = model_ref.transformer.wpe.weight.detach().numpy()
print(f'\n  Collecting training data ({len(TRAIN_PROMPTS)}×{N_STEPS})...')
t0 = time.time()
data = {li: {'ln2': [], 'delta_ffn': [], 'context': [], 'delta_att': []} for li in range(n_layers)}
with torch.no_grad():
    for prompt in TRAIN_PROMPTS:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model_ref(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        for step in range(N_STEPS):
            ids_use = ids[-SEQ_LEN:]
            T = SEQ_LEN
            x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
            for li in range(n_layers):
                blk = model_ref.transformer.h[li]
                ln1_w = blk.ln_1.weight.detach().numpy()
                ln1_b = blk.ln_1.bias.detach().numpy()
                ln2_w = blk.ln_2.weight.detach().numpy()
                ln2_b = blk.ln_2.bias.detach().numpy()
                att = blk.attn.attention
                Wq = att.q_proj.weight.detach().numpy()
                Wk = att.k_proj.weight.detach().numpy()
                Wv = att.v_proj.weight.detach().numpy()
                Wo = att.out_proj.weight.detach().numpy()
                bo = att.out_proj.bias.detach().numpy()
                W1 = blk.mlp.c_fc.weight.detach().numpy()
                b1 = blk.mlp.c_fc.bias.detach().numpy()
                W2 = blk.mlp.c_proj.weight.detach().numpy()
                b2 = blk.mlp.c_proj.bias.detach().numpy()
                ln1 = np.array([ln_np(x[i:i + 1], ln1_w, ln1_b)[0] for i in range(T)])
                Q = ln1 @ Wq.T
                K = ln1 @ Wk.T
                V = ln1 @ Wv.T
                Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                mask = np.triu(np.full((T, T), float('-inf')), 1)
                probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
                heads = [probs[h] @ Vh[h] for h in range(n_heads)]
                context = np.stack(heads, 1).reshape(T, D)
                att_out = context @ Wo.T + bo
                x_att = x + att_out
                x_new = x_att.copy()
                for t in range(T):
                    ln2_t = ln_np(x_att[t:t + 1], ln2_w, ln2_b)[0]
                    pre_t = ln2_t @ W1.T + b1
                    act_t = gelu_np(pre_t)
                    ffn_t = act_t @ W2.T + b2
                    x_new[t] = x_att[t] + ffn_t
                ln2_last = ln_np(x_att[-1:], ln2_w, ln2_b)[0]
                ffn_last = x_new[-1] - x_att[-1]
                data[li]['ln2'].append(ln2_last.copy())
                data[li]['delta_ffn'].append(ffn_last.copy())
                data[li]['context'].append(context[-1].copy())
                data[li]['delta_att'].append(att_out[-1].copy())
                x = x_new
            out2 = model_ref(torch.tensor([ids_use]))
            ids.append(torch.argmax(out2.logits[0, -1, :]).item())
N = len(data[0]['ln2'])
for li in range(n_layers):
    for k in data[li]:
        data[li][k] = np.array(data[li][k], dtype=np.float64)
print(f'  N={N} in {time.time() - t0:.1f}s')
print(f"\n{'=' * 70}")
print(f'  W-KERNEL SOLVE')
print(f"{'=' * 70}\n")
t_solve = time.time()
solved = {}
print(f"  {'Layer':<8} {'FFN_R²':>12} {'ATT_R²':>12}")
print(f"  {'─' * 36}")
for li in range(n_layers):
    Phi_ffn = quad_kernel(data[li]['ln2'])
    W_ffn, r2_ffn = solve_exact(Phi_ffn, data[li]['delta_ffn'])
    W_att, r2_att = solve_exact(data[li]['context'], data[li]['delta_att'])
    solved[li] = {'W_ffn': W_ffn, 'W_att': W_att}
    vf = '✓' if r2_ffn > 0.9999 else '~'
    va = '✓' if r2_att > 0.9999 else '~'
    print(f'  L{li:<7} {r2_ffn:.6f} {vf}  {r2_att:.6f} {va}')
print(f'  Solve time: {time.time() - t_solve:.1f}s\n')

def wk_forward_v2(ids_use, use_wkernel_ffn=True, use_wkernel_att=True):
    T = len(ids_use)
    x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
    for li in range(n_layers):
        blk = model_ref.transformer.h[li]
        ln1_w = blk.ln_1.weight.detach().numpy()
        ln1_b = blk.ln_1.bias.detach().numpy()
        ln2_w = blk.ln_2.weight.detach().numpy()
        ln2_b = blk.ln_2.bias.detach().numpy()
        att = blk.attn.attention
        Wq = att.q_proj.weight.detach().numpy()
        Wk = att.k_proj.weight.detach().numpy()
        Wv = att.v_proj.weight.detach().numpy()
        Wo = att.out_proj.weight.detach().numpy()
        bo = att.out_proj.bias.detach().numpy()
        W1 = blk.mlp.c_fc.weight.detach().numpy()
        b1 = blk.mlp.c_fc.bias.detach().numpy()
        W2 = blk.mlp.c_proj.weight.detach().numpy()
        b2 = blk.mlp.c_proj.bias.detach().numpy()
        W_ffn = solved[li]['W_ffn']
        W_att = solved[li]['W_att']
        ln1 = np.array([ln_np(x[i:i + 1], ln1_w, ln1_b)[0] for i in range(T)])
        Q = ln1 @ Wq.T
        K = ln1 @ Wk.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads, 1).reshape(T, D)
        att_out_ref = context @ Wo.T + bo
        x_att = x + att_out_ref
        if use_wkernel_att:
            ctx_b = np.append(context[-1], 1.0)
            att_out_wk_last = ctx_b @ W_att
            x_att[-1] = x[-1] + att_out_wk_last
        x_new = x_att.copy()
        for t in range(T):
            ln2_t = ln_np(x_att[t:t + 1], ln2_w, ln2_b)[0]
            if t == T - 1 and use_wkernel_ffn:
                Phi_t = quad_kernel(ln2_t.reshape(1, -1))[0]
                Phi_b = np.append(Phi_t, 1.0)
                ffn_t = Phi_b @ W_ffn
            else:
                pre_t = ln2_t @ W1.T + b1
                act_t = gelu_np(pre_t)
                ffn_t = act_t @ W2.T + b2
            x_new[t] = x_att[t] + ffn_t
        x = x_new
    lnf_w = model_ref.transformer.ln_f.weight.detach().numpy()
    lnf_b = model_ref.transformer.ln_f.bias.detach().numpy()
    lm_w = model_ref.lm_head.weight.detach().numpy()
    h_final = ln_np(x[-1:], lnf_w, lnf_b)[0]
    return h_final @ lm_w.T
print(f"{'=' * 70}")
print(f'  EVALUATION — HELD-OUT TEST PROMPTS')
print(f"{'=' * 70}\n")

def calc_perplexity(prompts, label, mode='ref'):
    total_nll = 0.0
    total_tok = 0
    correct = 0
    with torch.no_grad():
        for prompt in prompts:
            ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
            if len(ids) < 3:
                continue
            for i in range(1, min(len(ids), SEQ_LEN)):
                ctx = ids[:i]
                true_next = ids[i]
                if mode == 'ref':
                    out = model_ref(torch.tensor([ctx]))
                    logits = out.logits[0, -1, :].numpy().astype(np.float64)
                elif mode == 'wk_both':
                    logits = wk_forward_v2(ctx, True, True)
                elif mode == 'wk_ffn_only':
                    logits = wk_forward_v2(ctx, True, False)
                elif mode == 'wk_att_only':
                    logits = wk_forward_v2(ctx, False, True)
                lg = logits - logits.max()
                lp = lg - np.log(np.sum(np.exp(lg)))
                total_nll += -lp[true_next]
                total_tok += 1
                if int(np.argmax(logits)) == true_next:
                    correct += 1
    ppl = math.exp(total_nll / total_tok) if total_tok > 0 else float('inf')
    acc = correct / total_tok * 100 if total_tok > 0 else 0
    print(f'  {label:<35} ppl={ppl:>8.2f}  acc={acc:>5.1f}%')
    return (ppl, acc)
ppl_ref, acc_ref = calc_perplexity(TEST_PROMPTS, 'Reference (gradient descent)', 'ref')
ppl_ffn, acc_ffn = calc_perplexity(TEST_PROMPTS, 'W-Kernel FFN only', 'wk_ffn_only')
ppl_att, acc_att = calc_perplexity(TEST_PROMPTS, 'W-Kernel ATT only', 'wk_att_only')
ppl_both, acc_both = calc_perplexity(TEST_PROMPTS, 'W-Kernel FFN + ATT', 'wk_both')
print(f"\n  {'─' * 60}")
print(f'  FFN ratio:      {ppl_ffn / ppl_ref:.6f}  (1.000 = perfect)')
print(f'  ATT ratio:      {ppl_att / ppl_ref:.6f}  (1.000 = perfect)')
print(f'  Both ratio:     {ppl_both / ppl_ref:.6f}  (1.000 = perfect)')
print(f"\n{'=' * 70}")
print(f'  GENERATION — REFERENCE vs W-KERNEL')
print(f"{'=' * 70}\n")
gen_prompts = ['Once upon a time a little', 'Deep in the forest lived', 'The brave knight found a']
for prompt in gen_prompts:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    ids_r = ids[:]
    ids_w = ids[:]
    ref_tok = []
    wk_tok = []
    for _ in range(10):
        with torch.no_grad():
            out_r = model_ref(torch.tensor([ids_r]))
            nr = torch.argmax(out_r.logits[0, -1, :]).item()
        ids_r.append(nr)
        ref_tok.append(nr)
        lg_w = wk_forward_v2(ids_w, True, True)
        nw = int(np.argmax(lg_w))
        ids_w.append(nw)
        wk_tok.append(nw)
    print(f"  '{prompt}'")
    print(f'    REF : {tokenizer.decode(ref_tok)}')
    print(f'    WK  : {tokenizer.decode(wk_tok)}')
    print(f'    match: {sum((a == b for a, b in zip(ref_tok, wk_tok)))}/10\n')
print(f"{'=' * 70}")
print(f'  DIAGNOSIS — WHY IS RATIO ≠ 1.000?')
print(f"{'=' * 70}\n")
print(f'\n  If FFN ratio ≈ 1.000:\n    Quadratic kernel correctly replaces W1→gelu→W2.\n    R²=1.000000 at training data = generalizes to test.\n    FFN W-Kernel = working.\n\n  If ATT ratio ≈ 1.000:\n    W_att correctly replaces out_proj.\n    Context → att_out = linear. Working.\n\n  If ratio > 1.01:\n    Generalization gap. Training distribution ≠ test.\n    Quadratic kernel = exact on seen data.\n    On unseen inputs: may not generalize.\n    \n    WHY: quadratic kernel has 2144 dimensions.\n    With N=5670 samples: slightly overdetermined.\n    But test prompts = different distribution.\n    \n    SOLUTION: more diverse training data.\n    W-Kernel = interpolation method.\n    More data = better generalization.\n    Same as neural network: more data = better.\n    \n    KEY DIFFERENCE FROM GRADIENT DESCENT:\n      Gradient descent: iterative approximation.\n      W-Kernel: exact on training data.\n      Both need sufficient training data.\n      W-Kernel: one step. Gradient descent: 100k steps.\n')
print('=' * 70 + '\n')
