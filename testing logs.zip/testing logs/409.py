import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'EleutherAI/pythia-160m'
print(f'Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_hidden_layers
print(f'D={D} Heads={n_heads} Head_dim={head_dim} Layers={n_layers}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2(X, Y, split=0.8):
    n = len(X)
    s = int(n * split)
    Xf = X.astype(np.float32)
    Yf = Y.astype(np.float32)
    Xb = np.c_[Xf, np.ones(n, np.float32)]
    W = np.linalg.lstsq(Xb[:s], Yf[:s], rcond=None)[0]
    return r2(Xb[s:] @ W, Yf[s:])
seeds = ['Once upon a time', 'The scientist looked at', 'In a distant future', 'The old library held', 'A young programmer wrote', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed through', 'A dog sat quietly', 'She found the key', 'The storm was coming', 'The teacher explained how', 'A bird flew over', 'He picked up the phone', 'The car stopped suddenly', 'She smiled and said', 'The book was about', 'Deep in the forest', 'The robot walked toward', 'After many years had', 'The question was simple', 'Nobody knew what had', 'The door opened slowly', 'Light filled the room', 'She ran as fast']
print(f'Generating 300 texts (30 seeds × 10 temperatures)...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(10):
            torch.manual_seed(i * 100 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=30, do_sample=True, temperature=0.7 + j * 0.05, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(all_texts)} texts.')
test_layers = [0, 2, 5, 8, 11]
CTX = 8
print(f"\n{'=' * 72}")
print(f'  PYTHIA-160M — FFN LAW + ATTENTION WINDOW LAW')
print(f"{'=' * 72}")
print(f"\n  {'Layer':<6} {'gelu→ffn':<12} {'N_tok':<10} {'ratio':<8} {'window→att':<12} {'N_win'}")
print(f"  {'─' * 65}")
for layer_idx in test_layers:
    block = model.gpt_neox.layers[layer_idx]
    cap = {}

    def h_concat(mod, inp, out):
        cap['concat'] = inp[0].detach().float()

    def h_att(mod, inp, out):
        cap['att'] = out[0].detach().float()

    def h_gelu(mod, inp, out):
        cap['gelu'] = out.detach().float()

    def h_ffn(mod, inp, out):
        cap['ffn'] = out.detach().float()
    hk = [block.attention.dense.register_forward_hook(h_concat), block.attention.dense.register_forward_hook(h_att), block.mlp.act.register_forward_hook(h_gelu), block.mlp.dense_4h_to_h.register_forward_hook(h_ffn)]
    GELU_tok = []
    FFN_tok = []
    CONCAT_win = []
    ATT_win = []
    with torch.no_grad():
        for text in all_texts:
            toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
            L = toks['input_ids'].shape[1]
            if L < CTX:
                continue
            out_m = model(**toks, output_hidden_states=True)
            gelu_np = cap['gelu'][0].numpy()
            ffn_np = cap['ffn'][0].numpy()
            concat_np = cap['concat'][0].numpy()
            att_np = cap['att'][0].numpy()
            for t in range(L):
                GELU_tok.append(gelu_np[t])
                FFN_tok.append(ffn_np[t])
            for start in range(L - CTX + 1):
                c_win = concat_np[start:start + CTX].flatten()
                a_win = att_np[start:start + CTX].flatten()
                CONCAT_win.append(c_win)
                ATT_win.append(a_win)
    for hk_ in hk:
        hk_.remove()
    G = np.array(GELU_tok, dtype=np.float32)
    F = np.array(FFN_tok, dtype=np.float32)
    C = np.array(CONCAT_win, dtype=np.float32)
    A = np.array(ATT_win, dtype=np.float32)
    ffn_feat_dim = G.shape[1]
    ratio = len(G) / ffn_feat_dim
    r_ffn = fit_r2(G, F)
    r_win = fit_r2(C, A)

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {layer_idx:<6} {f(r_ffn):<12} {len(G):<10} {ratio:<8.1f} {f(r_win):<12} {len(C)}')
print(f"\n{'=' * 72}")
print(f'\n  WHAT EACH COLUMN MEANS:\n\n  gelu→ffn (token-level):\n    Same law as TinyStories.\n    Expected 1.000 with enough data (ratio > 3).\n    ratio = N_tokens / FFN_feature_dim.\n    TinyStories: dim=256, ratio=8  → 1.000\n    Pythia-160m: dim=3072, need 9000+ tokens.\n\n  window→att (window-level):\n    concat is cross-token. Cannot test per-token.\n    Window = CTX tokens flattened as one sample.\n    concat_window → att_window.\n    If 1.000: attention law holds at window level.\n    Natural space of attention = full context window.\n\n  SUMMARY:\n    If gelu→ffn = 1.000: FFN law universal. ✓\n    If window→att = 1.000: ATT law universal at window level. ✓\n    Both = W principle holds for Pythia family.\n    Then move to TinyLlama (SwiGLU).\n')
print('=' * 72 + '\n')
