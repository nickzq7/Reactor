import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN = 300
N_TEST = 50
MAX_SEQ = 32
GEN_TOKENS = 20
TEST_PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('\n' + '=' * 60)
print('  PHASE 0: LOAD')
print('=' * 60)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD, VOCAB = (H // NH, cfg.vocab_size)
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
FFN_D = teacher.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'  NL={NL} H={H} NH={NH} FFN_D={FFN_D} VOCAB={VOCAB}')
with torch.no_grad():
    Wte = teacher.transformer.wte.weight.detach().float().cpu().numpy()
    Wpe = teacher.transformer.wpe.weight.detach().float().cpu().numpy()
    lnf_g = teacher.transformer.ln_f.weight.detach().float().cpu().numpy()
    lnf_b = teacher.transformer.ln_f.bias.detach().float().cpu().numpy()
    Wlm = teacher.lm_head.weight.detach().float().cpu().numpy()
    teacher_ln = []
    for li in range(NL):
        bl = teacher.transformer.h[li]
        teacher_ln.append({'ln1_g': bl.ln_1.weight.detach().float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.detach().float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.detach().float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.detach().float().cpu().numpy(), 'attn_type': ATT[li] if li < len(ATT) else 'global', 'window': WIN})
print(f'  We train: W_q,W_k,W_v,W_o,W1,W2 × {NL} layers = {NL * 6} matrices')
print(f'  Wte/Wpe/Wlm = shared vocabulary (not trained)')
print('\n' + '=' * 60)
print(f'  LOAD DATA  ({N_TRAIN} train + {N_TEST} test)')
print('=' * 60)
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
all_stories = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 300:
        all_stories.append(t)
    if len(all_stories) >= N_TRAIN + N_TEST:
        break
train_stories = all_stories[:N_TRAIN]
test_stories = all_stories[N_TRAIN:N_TRAIN + N_TEST]
print(f'  Train: {len(train_stories)}  Test: {len(test_stories)}')

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (g * (x - m) / np.sqrt(v + eps) + b).astype(np.float32)

def gelu_np(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def solve_W(X, Y):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.concatenate([X64, np.ones((len(X64), 1))], 1)
    res, _, _, _ = lstsq(Xb, Y64, rcond=None)
    W = res[:-1].T.astype(np.float32)
    b = res[-1].astype(np.float32)
    Yp = X64 @ res[:-1] + res[-1]
    r2 = float(1 - ((Y64 - Yp) ** 2).sum() / (((Y64 - Y64.mean(0)) ** 2).sum() + 1e-12))
    return (W, b, r2)
print('\n' + '=' * 60)
print('  PHASE 1: COLLECT  (no teacher activations)')
print('=' * 60)
t0 = time.perf_counter()
h0_list, target_id_list, h_target_list = ([], [], [])
n_tok = 0
for sent in train_stories:
    ids = tok(sent, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'][0].tolist()
    if len(ids) < 2:
        continue
    for pos in range(len(ids) - 1):
        h0_list.append(Wte[ids[pos]] + Wpe[pos])
        target_id_list.append(ids[pos + 1])
        h_target_list.append(Wlm[ids[pos + 1]])
        n_tok += 1
h0_arr = np.array(h0_list, dtype=np.float32)
target_ids = np.array(target_id_list, dtype=np.int32)
h_target = np.array(h_target_list, dtype=np.float32)
print(f'  {n_tok} token positions in {time.perf_counter() - t0:.1f}s')
print(f'  h_0: {h0_arr.shape}   h_target: {h_target.shape}')
print(f'  h_target = Wlm[next_token]  — from data labels only, no teacher')
print('\n' + '=' * 60)
print('  PHASE 2: BASELINE — 0 layers, direct h_0 → h_target')
print('=' * 60)
feat_0 = np.concatenate([h0_arr, h0_arr ** 2], -1)
W_direct, b_direct, r2_direct = solve_W(feat_0, h_target)
logits_direct = (feat_0 @ W_direct.T + b_direct) @ Wlm.T
acc_direct = float((np.argmax(logits_direct, -1) == target_ids).mean())
print(f'  R²={r2_direct:.6f}   train_acc={acc_direct * 100:.2f}%   random={1 / VOCAB * 100:.4f}%   {acc_direct / (1 / VOCAB):.1f}x random')
print('\n' + '=' * 60)
print('  PHASE 3: TRAIN ALL LAYERS  (analytical target propagation)')
print(f'  h_target = Wlm[next_token]  interpolated across {NL} layers')
print('=' * 60)
print(f"\n  {'Layer':<8} {'frac':>6}  {'Wq':>7} {'Wk':>7} {'Wv':>7} {'Wo':>7} {'W1':>7} {'W2':>7}")
print(f"  {'-' * 60}")
scratch_W = []
h_current = h0_arr.copy()
t_train = time.perf_counter()
for li in range(NL):
    frac = (li + 1) / NL
    h_layer_target = ((1 - frac) * h0_arr + frac * h_target).astype(np.float32)
    ln1 = ln_np(h_current, teacher_ln[li]['ln1_g'], teacher_ln[li]['ln1_b'])
    att_target = (h_layer_target - h_current).astype(np.float32)
    W_q, b_q, r2_q = solve_W(ln1, ln1)
    W_k, b_k, r2_k = solve_W(ln1, ln1)
    W_v, b_v, r2_v = solve_W(ln1, ln1)
    W_o, b_o, r2_o = solve_W(ln1, att_target)
    att_out = (ln1 @ W_o.T + b_o).astype(np.float32)
    h_mid = (h_current + att_out).astype(np.float32)
    ln2 = ln_np(h_mid, teacher_ln[li]['ln2_g'], teacher_ln[li]['ln2_b'])
    ffn_target = (h_layer_target - h_mid).astype(np.float32)
    W1, b1, r2_1 = solve_W(ln2, ln2)
    pre = (ln2 @ W1.T + b1).astype(np.float32)
    gelu_out = gelu_np(pre)
    W2, b2, r2_2 = solve_W(gelu_out, ffn_target)
    ffn_out = (gelu_out @ W2.T + b2).astype(np.float32)
    h_current = (h_mid + ffn_out).astype(np.float32)
    scratch_W.append({'W_q': W_q, 'b_q': b_q, 'W_k': W_k, 'b_k': b_k, 'W_v': W_v, 'b_v': b_v, 'W_o': W_o, 'b_o': b_o, 'W1': W1, 'b1': b1, 'W2': W2, 'b2': b2, **teacher_ln[li]})
    print(f'  Layer {li:<3}  {frac:6.3f}  {r2_q:7.4f} {r2_k:7.4f} {r2_v:7.4f} {r2_o:7.4f} {r2_1:7.4f} {r2_2:7.4f}')
t_train = time.perf_counter() - t_train
h_final_scratch = ln_np(h_current, lnf_g, lnf_b)
logits_scratch = (h_final_scratch @ Wlm.T).astype(np.float32)
acc_scratch_train = float((np.argmax(logits_scratch, -1) == target_ids).mean())
print(f'\n  Done in {t_train:.2f}s  (zero gradient steps)')
print(f'  Train acc: {acc_scratch_train * 100:.2f}%')
print('\n' + '=' * 60)
print('  PHASE 4: GENERATION')
print('=' * 60)

def scratch_layer(h, li, kv_cache=None):
    w = scratch_W[li]
    sl = h.shape[0]
    ln1 = ln_np(h, w['ln1_g'], w['ln1_b'])
    Q = (ln1 @ w['W_q'].T + w['b_q']).astype(np.float32)
    K = (ln1 @ w['W_k'].T + w['b_k']).astype(np.float32)
    V = (ln1 @ w['W_v'].T + w['b_v']).astype(np.float32)
    Kf = np.concatenate([kv_cache['K'], K], 0) if kv_cache else K
    Vf = np.concatenate([kv_cache['V'], V], 0) if kv_cache else V
    past, full = (Kf.shape[0] - sl, Kf.shape[0])
    Qh = Q.reshape(sl, NH, HD).transpose(1, 0, 2)
    Kh = Kf.reshape(full, NH, HD).transpose(1, 0, 2)
    Vh = Vf.reshape(full, NH, HD).transpose(1, 0, 2)
    sc = np.matmul(Qh, Kh.transpose(0, 2, 1)).astype(np.float32)
    mk = np.full((sl, full), -1000000000.0, np.float32)
    at = w.get('attn_type', 'global')
    wn = w.get('window', WIN)
    for i in range(sl):
        ia = past + i
        s = max(0, ia - wn + 1) if at == 'local' else 0
        mk[i, s:ia + 1] = 0.0
    sc += mk[np.newaxis]
    sc -= sc.max(-1, keepdims=True)
    e = np.exp(sc)
    p = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    ctx = np.matmul(p, Vh).transpose(1, 0, 2).reshape(sl, H).astype(np.float32)
    att = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
    hm = (h + att).astype(np.float32)
    ln2 = ln_np(hm, w['ln2_g'], w['ln2_b'])
    pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
    ffn = (gelu_np(pre) @ w['W2'].T + w['b2']).astype(np.float32)
    return ((hm + ffn).astype(np.float32), K, V)

def scratch_forward(ids, caches=None):
    ids = np.array(ids, np.int32)
    sl = len(ids)
    ps = caches[0]['K'].shape[0] if caches else 0
    h = (Wte[ids] + Wpe[np.arange(ps, ps + sl)]).astype(np.float32)
    nc = []
    for li in range(NL):
        c = caches[li] if caches else None
        h, K, V = scratch_layer(h, li, c)
        if caches:
            nc.append({'K': np.concatenate([caches[li]['K'], K], 0), 'V': np.concatenate([caches[li]['V'], V], 0)})
        else:
            nc.append({'K': K, 'V': V})
    return ((ln_np(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32), nc)

def empty_cache():
    return [{'K': np.zeros((0, H), np.float32), 'V': np.zeros((0, H), np.float32)} for _ in range(NL)]

def gen_scratch(prompt, n):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    logits, cache = scratch_forward(ids, empty_cache())
    new = [int(np.argmax(logits[-1]))]
    for _ in range(n - 1):
        logits, cache = scratch_forward([new[-1]], cache)
        new.append(int(np.argmax(logits[-1])))
    return new

def gen_teacher(prompt, n):
    ids = tok(prompt, return_tensors='pt')['input_ids'].to(device)
    with torch.no_grad():
        out = teacher.generate(ids, max_new_tokens=n, do_sample=False, use_cache=True)
    return out[0][ids.shape[1]:].cpu().tolist()
for prompt in TEST_PROMPTS:
    ids_t = gen_teacher(prompt, GEN_TOKENS)
    ids_s = gen_scratch(prompt, GEN_TOKENS)
    match = sum((a == b for a, b in zip(ids_t, ids_s)))
    print(f'\n  Prompt:  "{prompt[:50]}"')
    print(f'  Teacher: {repr(tok.decode(ids_t)[:70])}')
    print(f'  Scratch: {repr(tok.decode(ids_s)[:70])}')
    print(f'  Match:   {match}/{GEN_TOKENS}')
print('\n' + '=' * 60)
print('  PHASE 5: HELD-OUT TEST ACCURACY')
print('=' * 60)
test_h0, test_next = ([], [])
for sent in test_stories:
    ids = tok(sent, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'][0].tolist()
    if len(ids) < 2:
        continue
    for pos in range(len(ids) - 1):
        test_h0.append(Wte[ids[pos]] + Wpe[pos])
        test_next.append(ids[pos + 1])
test_h0 = np.array(test_h0, np.float32)
test_next = np.array(test_next, np.int32)
h = test_h0.copy()
for li in range(NL):
    w = scratch_W[li]
    ln1 = ln_np(h, w['ln1_g'], w['ln1_b'])
    att = (ln1 @ w['W_o'].T + w['b_o']).astype(np.float32)
    hm = (h + att).astype(np.float32)
    ln2 = ln_np(hm, w['ln2_g'], w['ln2_b'])
    pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
    ffn = (gelu_np(pre) @ w['W2'].T + w['b2']).astype(np.float32)
    h = (hm + ffn).astype(np.float32)
acc_test = float((np.argmax(ln_np(h, lnf_g, lnf_b) @ Wlm.T, -1) == test_next).mean())
print(f"\n  {'Method':<28} {'Train':>8}  {'Test':>8}  {'vs random':>10}")
print(f"  {'-' * 58}")
print(f"  {'Random':<28} {1 / VOCAB * 100:8.4f}%  {1 / VOCAB * 100:8.4f}%  {'1.0x':>10}")
print(f"  {'0-layer direct':<28} {acc_direct * 100:8.2f}%  {'N/A':>8}   {acc_direct / (1 / VOCAB):>9.1f}x")
print(f"  {'REACTOR-SCRATCH':<28} {acc_scratch_train * 100:8.2f}%  {acc_test * 100:8.2f}%  {acc_test / (1 / VOCAB):>9.1f}x")
print('\n' + '=' * 60)
print('  VERDICT')
print('=' * 60)
ratio = acc_test / (1 / VOCAB)
if ratio > 5000:
    print(f'  ✓ STRONG: {ratio:.0f}x random — from-scratch O(1) training WORKS')
elif ratio > 500:
    print(f'  ✓ POSITIVE: {ratio:.0f}x random — clear signal, needs refinement')
elif ratio > 50:
    print(f'  ~ WEAK SIGNAL: {ratio:.0f}x random — direction correct, targets need work')
else:
    print(f'  ~ {ratio:.0f}x random — target propagation needs better strategy')
print(f"\n  KEY NUMBERS:\n    Training time:   {t_train:.2f}s   (zero gradient steps)\n    Train positions: {n_tok}\n    Random baseline: {1 / VOCAB * 100:.4f}%\n    REACTOR-SCRATCH: {acc_test * 100:.4f}%  ({ratio:.1f}x random)\n\n  WHAT THIS MEANS:\n    If >100x random: from-scratch O(1) training has real signal.\n    The W Principle extends beyond model recovery.\n    Target propagation (h_target = Wlm[next_token]) is valid.\n\n  NEXT STEP (if signal is weak):\n    Iterative pass — use rough model's attention patterns\n    to derive better Q,K,V targets, solve again.\n    2-3 passes. Still O(data). Never O(epochs).\n")
