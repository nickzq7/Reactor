import os, json, time
import numpy as np
import torch
import torch.nn as nn
print('\n' + '=' * 65)
print('  W-HASH STEP 1 — TINY TRANSFORMER (PyTorch)')
print('=' * 65)
TEXT = 'the cat sat on the mat the dog ran on the log the cat and the dog sat on the big red mat the dog ran past the cat the cat ran back to the mat the dog sat still the cat looked at the dog the dog looked at the cat they both sat on the mat together the end'
words = TEXT.split()
vocab = sorted(set(words))
w2i = {w: i for i, w in enumerate(vocab)}
i2w = {i: w for w, i in w2i.items()}
VS = len(vocab)
toks = [w2i[w] for w in words]
print(f'\n  Words={len(words)}  Vocab={VS}: {vocab}')
D = 32
H = 2
NL = 2
K = 4
FFN = D * 4
cuda_ok = torch.cuda.is_available()
print(f'  CUDA: {cuda_ok}')
if cuda_ok:
    print(f'  GPU: {torch.cuda.get_device_name(0)}')
device = torch.device('cuda' if cuda_ok else 'cpu')
print(f'  Device={device}')

class TinyTransformer(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, FFN), nn.GELU(), nn.Linear(FFN, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for layer in self.layers:
            xn = layer['ln1'](x)
            a, _ = layer['attn'](xn, xn, xn, attn_mask=mask)
            x = x + a
            x = x + layer['ff'](layer['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T
M = len(toks) - K
X = torch.tensor([toks[i:i + K] for i in range(M)], device=device)
y = torch.tensor([toks[i + 1:i + K + 1] for i in range(M)], device=device)
print(f'\n  Training pairs={M}')
model = TinyTransformer().to(device)
print(f'  Params={sum((p.numel() for p in model.parameters()))}')
opt = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=0.0001)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=5000, eta_min=0.0001)
loss_fn = nn.CrossEntropyLoss()
print(f"\n  {'Epoch':>6} {'Loss':>8} {'Acc':>7} {'LR':>10}")
print(f"  {'─' * 38}")
t0 = time.time()
best_acc = 0.0
best_state = None
for epoch in range(1, 5001):
    model.train()
    opt.zero_grad()
    logits = model(X)
    loss = loss_fn(logits.view(-1, VS), y.view(-1))
    loss.backward()
    opt.step()
    sched.step()
    if epoch % 200 == 0 or loss.item() < 0.01:
        model.eval()
        with torch.no_grad():
            preds = model(X).argmax(-1)
            acc = 100 * (preds == y).float().mean().item()
        lr_now = opt.param_groups[0]['lr']
        print(f'  {epoch:>6} {loss.item():>8.4f} {acc:>6.1f}% {lr_now:>10.6f}')
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        if loss.item() < 0.01 and acc >= 99:
            print(f'  ✓ Converged!')
            break
model.load_state_dict(best_state)
model.eval()
with torch.no_grad():
    preds = model(X).argmax(-1)
    final_acc = 100 * (preds == y).float().mean().item()
print(f'\n  FINAL acc={final_acc:.1f}%  loss={loss.item():.4f}')
W = {}
W['WTE'] = model.wte.weight.detach().cpu().numpy()
W['WPE'] = model.wpe.weight.detach().cpu().numpy()
for lyr in range(NL):
    layer = model.layers[lyr]
    ip = layer['attn'].in_proj_weight.detach().cpu().numpy()
    W[f'WQ{lyr}'] = ip[:D, :]
    W[f'WK{lyr}'] = ip[D:2 * D, :]
    W[f'WV{lyr}'] = ip[2 * D:, :]
    W[f'WO{lyr}'] = layer['attn'].out_proj.weight.detach().cpu().numpy()
    W[f'W1{lyr}'] = layer['ff'][0].weight.detach().cpu().numpy()
    W[f'b1{lyr}'] = layer['ff'][0].bias.detach().cpu().numpy()
    W[f'W2{lyr}'] = layer['ff'][2].weight.detach().cpu().numpy()
    W[f'b2{lyr}'] = layer['ff'][2].bias.detach().cpu().numpy()
    W[f'LN1g{lyr}'] = layer['ln1'].weight.detach().cpu().numpy()
    W[f'LN1b{lyr}'] = layer['ln1'].bias.detach().cpu().numpy()
    W[f'LN2g{lyr}'] = layer['ln2'].weight.detach().cpu().numpy()
    W[f'LN2b{lyr}'] = layer['ln2'].bias.detach().cpu().numpy()
W['LNfg'] = model.ln_f.weight.detach().cpu().numpy()
W['LNfb'] = model.ln_f.bias.detach().cpu().numpy()
np.savez('tiny_transformer_weights.npz', **W)
with open('tiny_transformer_meta.json', 'w') as f:
    json.dump({'vocab': vocab, 'w2i': w2i, 'i2w': {str(k): v for k, v in i2w.items()}, 'VS': VS, 'D': D, 'H': H, 'NL': NL, 'K': K, 'FFN': FFN, 'acc': float(final_acc), 'text': TEXT}, f, indent=2)
print(f'\n  Saved: tiny_transformer_weights.npz')
print(f'  Saved: tiny_transformer_meta.json')
print(f'  Keys: {list(W.keys())}')
print(f"  WTE={W['WTE'].shape} WQ0={W['WQ0'].shape} W10={W['W10'].shape}")
print(f'\n  GENERATION:')

def gen(seed, n=5):
    ids = [w2i.get(w, 0) for w in seed[-K:]]
    out = list(seed)
    model.eval()
    with torch.no_grad():
        for _ in range(n):
            lg = model(torch.tensor([ids[-K:]], device=device))[0]
            p = int(lg[-1].argmax())
            out.append(i2w[p])
            ids.append(p)
    return ' '.join(out)
for sw in [['the', 'cat', 'sat', 'on'], ['the', 'dog', 'ran', 'on'], ['they', 'both', 'sat', 'on']]:
    print(f'  {gen(sw)}')
print(f'\n  Time={time.time() - t0:.1f}s')
print(f'\n  STEP 1 COMPLETE. Files in current directory.')
print(f'  Next: STEP 2 — W-HASH (geometric fingerprint).\n')
