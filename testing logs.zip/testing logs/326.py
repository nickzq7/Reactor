import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — SEMANTIC EARLY EXIT V2 (GENERALIZATION)')
print('  Testing if GeLU states are universal across contexts.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
BIT_THRESHOLD = 252
print('\n  [ Phase 1 ] Populating RAM from SET A (General Knowledge)...')
set_a_prompts = ['Once upon a time, a little girl named Lily found a', 'Deep in the dark forest, a large dragon was', 'A small dog ran across the green field and', 'The sun was very hot in the summer and', 'Every morning the bird sang a beautiful song', 'The old man sat on the wooden bench', 'A cat climbed the tall tree to catch', 'The rain fell softly on the flowers in', 'A boy named Tom liked to play with', 'The red car drove very fast down the', 'The moon was bright and the stars were', 'The fish swam in the cold blue water', 'A giant giant lived in a big house', 'The teacher told the children a story about', 'She wore a blue dress to the party']
RAM_bits = {l: [] for l in range(n_layers)}
RAM_tokens = {l: [] for l in range(n_layers)}
store_pre = {l: [] for l in range(n_layers)}

def get_hook(l):

    def hook(m, i, o):
        store_pre[l].append(o[:, -1, :].detach().cpu().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_hook(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        for _ in range(20):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                bits = (store_pre[l].pop()[0] > 0).astype(int)
                RAM_bits[l].append(bits)
                RAM_tokens[l].append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM_bits[l] = np.array(RAM_bits[l])
    RAM_tokens[l] = np.array(RAM_tokens[l])
print(f'  ✓ RAM Banks loaded with {len(RAM_tokens[0])} states from SET A.')
print('\n' + '─' * 70)
print(f'  [ Phase 2 ] TESTING GENERALIZATION ON SET B')
print(f'  Threshold: {BIT_THRESHOLD}/256 bits')
print('─' * 70)
test_prompt = 'The brave knight took his sword and'
print(f'  Test Prompt: {test_prompt}\n')
live_store = {l: [] for l in range(n_layers)}

def get_live_hook(l):

    def hook(m, i, o):
        live_store[l] = (o[:, -1, :].detach().cpu().numpy() > 0).astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_live_hook(l)) for l in range(n_layers)]
pt_ids = tokenizer.encode(test_prompt, return_tensors='pt')
correct_hits = 0
total_attempts = 15
with torch.no_grad():
    for step in range(total_attempts):
        out = model(pt_ids)
        final_id = torch.argmax(out.logits[0, -1, :]).item()
        final_word = tokenizer.decode([final_id])
        found_match = False
        prediction = None
        exit_layer = -1
        for l in range(n_layers):
            current_bits = live_store[l]
            matches = np.sum(RAM_bits[l] == current_bits, axis=1)
            best_match_val = np.max(matches)
            if best_match_val >= BIT_THRESHOLD:
                best_idx = np.argmax(matches)
                prediction = int(RAM_tokens[l][best_idx])
                exit_layer = l
                found_match = True
                break
        status = '✗ MISSED'
        if found_match:
            if prediction == final_id:
                status = f'✓ HIT at Layer {exit_layer}'
                correct_hits += 1
            else:
                status = f"⚠ WRONG at Layer {exit_layer} (Pred: '{tokenizer.decode([prediction]).strip()}')"
        print(f'  Token {step + 1}: [{final_word.strip():<10}] -> {status}')
        pt_ids = torch.cat([pt_ids, torch.tensor([[final_id]])], dim=1)
for h in live_hooks:
    h.remove()
print('\n' + '=' * 70)
print('  THE GENERALIZATION VERDICT')
print('=' * 70)
hit_rate = correct_hits / total_attempts * 100
print(f'  Semantic RAM Hit Rate: {hit_rate:.1f}%')
if hit_rate > 70:
    print('\n  RESULT: PHYSICS PROVEN.')
    print('  The GeLU states are universal. Even in unseen contexts, the')
    print('  model reaches identical computation states for the same words.')
elif hit_rate > 30:
    print('\n  RESULT: SEMI-UNIVERSAL.')
    print('  The states overlap occasionally, but context-drift is real.')
else:
    print('\n  RESULT: RECOGNITION ONLY.')
    print('  The states are unique to the prompt. W is a local map, not a global one.')
print('=' * 70 + '\n')
