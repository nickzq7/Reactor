import numpy as np, math, time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v25 — MULTI-PASS + NUCLEUS SAMPLING')
print('  Same v24 physics. More rounds. Better sampling.')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
K = 6
D = VS
L = 3
DECAY = 0.5
D_quad = D * (D + 1) // 2
WTE = np.eye(VS, dtype=np.float64)
decay_w = np.array([DECAY ** j for j in range(K)], dtype=np.float64)
decay_w /= decay_w.sum()
M = N - K
y = np.array(toks[K:])
X0 = np.zeros((M, D), dtype=np.float64)
for i in range(K, N):
    for j in range(K):
        X0[i - K] += decay_w[j] * WTE[toks[i - 1 - j]]
T = WTE[y]
tri_i, tri_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_s(Ph, R, lam=1e-06):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    return np.linalg.solve(A, Ph.T @ R)

def fwd(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs

def ppl_acc(Wl, n_sample=2000):
    x = fwd(X0, Wl)[-1]
    lg = x @ WTE.T
    preds = np.argmax(lg, 1)
    acc = 100 * np.mean(preds == y)
    step = max(1, M // n_sample)
    nll = 0.0
    ne = 0
    for i in range(0, M, step):
        l = lg[i] - lg[i].max()
        l = l - np.log(np.sum(np.exp(l)))
        nll -= l[y[i]]
        ne += 1
    return (math.exp(min(nll / ne, 500)), acc)
W_layers = [np.zeros((D_quad, D)) for _ in range(L)]
p0, a0 = ppl_acc(W_layers)
print(f'\n  Vocab={VS} N={N} D_quad={D_quad} N/D={N // D_quad}x')
print(f'  Initial: ppl={p0:.2f}  acc={a0:.1f}%')
print(f'\n  Multi-pass coordinate descent (accept any improvement):')
print(f"  {'Rnd':>4} {'L':>2} {'ppl':>8} {'acc':>7} {'res':>8}")
print(f"  {'─' * 40}")
best_p = p0
best_W = [w.copy() for w in W_layers]
no_improve_count = 0
for rnd in range(20):
    imp = False
    for l in range(L):
        xs = fwd(X0, W_layers)
        R = T - xs[l]
        rb = np.mean(np.linalg.norm(R, axis=1))
        Wn = pinv_s(phi_b(xs[l]), R)
        Wt = [w.copy() for w in W_layers]
        Wt[l] = Wn
        p, a = ppl_acc(Wt)
        mk = '★' if p < best_p - 0.001 else ' '
        print(f'  {rnd + 1:>4} {l:>2} {p:>8.2f} {a:>6.1f}% {rb:>8.4f} {mk}')
        if p < best_p - 0.001:
            best_p = p
            W_layers = Wt
            best_W = [w.copy() for w in Wt]
            imp = True
    if not imp:
        no_improve_count += 1
        if no_improve_count >= 2:
            print(f'  Fully converged.')
            break
    else:
        no_improve_count = 0
W_layers = best_W
fp, fa = ppl_acc(W_layers)
print(f'\n  Final: ppl={fp:.2f}  acc={fa:.1f}%')
xs = fwd(X0, W_layers)
print(f'\n  RESIDUAL ANALYSIS:')
for l in range(L):
    r0 = np.mean(np.linalg.norm(T - xs[l], axis=1))
    r1 = np.mean(np.linalg.norm(T - xs[l + 1], axis=1))
    print(f'  Layer {l}: {r0:.4f} → {r1:.4f}  Δ={r0 - r1:.4f}')
print(f'\n  BIGRAM CHECK (2-char decay context):')
for prev in ['t', 'h', 'e', ' ', 'a', 'n', 'd', 'o']:
    if prev not in c2i:
        continue
    before = [toks[i - 1] for i in range(1, N) if toks[i] == c2i[prev]]
    if not before:
        continue
    most_common_before = Counter(before).most_common(1)[0][0]
    x = decay_w[0] * WTE[c2i[prev]] + decay_w[1] * WTE[most_common_before]
    for W in W_layers:
        x = x + phi(x) @ W
    lg = x @ WTE.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  '{i2c[most_common_before]}{prev}' → {top3}")
print(f'\n  TRIGRAM CHECK:')
for bg in ['th', 'he', 'in', 'an', 'on', 'nd']:
    cs = [c2i[c] for c in bg if c in c2i]
    if len(cs) < 2:
        continue
    x = decay_w[0] * WTE[cs[-1]] + decay_w[1] * WTE[cs[0]]
    for W in W_layers:
        x = x + phi(x) @ W
    lg = x @ WTE.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  '{bg}' → {top3}")

def ctx_vec(ids):
    x = np.zeros(D, dtype=np.float64)
    recent = list(ids[-K:]) if len(ids) >= K else [0] * (K - len(ids)) + list(ids)
    for j in range(K):
        x += decay_w[j] * WTE[recent[-1 - j]]
    return x

def forward_ctx(ids):
    x = ctx_vec(ids)
    for W in W_layers:
        x = x + phi(x) @ W
    return x @ WTE.T

def nucleus_sample(lg, p_thresh=0.9, temp=1.0):
    lg = lg - lg.max()
    lg = lg / temp
    probs = np.exp(lg)
    probs /= probs.sum()
    sorted_idx = np.argsort(-probs)
    cumsum = np.cumsum(probs[sorted_idx])
    cutoff = np.searchsorted(cumsum, p_thresh) + 1
    nucleus = sorted_idx[:max(1, cutoff)]
    p_nucleus = probs[nucleus]
    p_nucleus /= p_nucleus.sum()
    return int(np.random.choice(nucleus, p=p_nucleus))

def generate(prompt, n=120, mode='nucleus', seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        lg = forward_ctx(ids)
        if not np.all(np.isfinite(lg)):
            break
        if mode == 'greedy':
            ids.append(int(np.argmax(lg)))
        elif mode == 'nucleus':
            ids.append(nucleus_sample(lg, p_thresh=0.85, temp=0.9))
        else:
            lg2 = lg - lg.max()
            lg2 /= 0.8
            p = np.exp(lg2)
            p /= p.sum()
            ids.append(int(np.random.choice(VS, p=p)))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION (greedy):')
for p in ['once upon a time ', 'the brave knight ']:
    out = generate(p, n=80, mode='greedy')
    print(f"  '{p}'")
    print(f'    {out[len(p):]}')
print(f'\n  GENERATION (nucleus p=0.85, temp=0.9):')
for seed_i, p in enumerate(['once upon a time ', 'the brave knight ', 'deep in the forest ']):
    out = generate(p, n=100, mode='nucleus', seed=seed_i * 7 + 1)
    print(f"  '{p}'")
    print(f'    {out[len(p):]}')
gs = generate('the ', n=300, mode='nucleus', seed=3)
sp = 100 * gs[4:].count(' ') / len(gs[4:])
cnt = Counter(gs[4:])
top5 = [(c, f'{100 * cnt[c] // len(gs[4:])}%') for c, _ in cnt.most_common(5)]
print(f'\n  Space%={sp:.0f}%  Top-5:{top5}')
print(f'  Sample: {gs[4:80]}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  ppl={fp:.2f}  acc={fa:.1f}%  vocab={VS}')
print(f'\n  V24→V25: multi-pass + nucleus sampling.')
print(f'  V24 showed: REAL ENGLISH WORDS in generation.')
print(f'  V25 target: longer coherent English sequences.')
print('=' * 65 + '\n')
