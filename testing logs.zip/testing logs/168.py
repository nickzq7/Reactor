import os, time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTNeoConfig
from datasets import load_dataset
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def banner(text, width=70):
    print(f"\n{'=' * width}\n  {text}\n{'=' * width}")
banner(f'1M KERNEL → TINYSTORIES   device={device}')
banner('STEP 1 — RAW KERNEL  (~1M params, random weights)')
KERNEL_CONFIG = GPTNeoConfig(vocab_size=50257, hidden_size=64, num_layers=4, attention_types=[[['global', 'local'], 2]], num_heads=4, intermediate_size=256, max_position_embeddings=256, window_size=64, resid_pdrop=0.1, embed_pdrop=0.1, attention_dropout=0.1)
kernel = AutoModelForCausalLM.from_config(KERNEL_CONFIG).to(device)
tok = AutoTokenizer.from_pretrained('gpt2')
tok.pad_token = tok.eos_token
p_kernel = sum((p.numel() for p in kernel.parameters()))
print(f'  Params  : {p_kernel:,}')
print(f'  D       : 64   Layers: 4   Heads: 4')
banner('STEP 2 — TINYSTORIES  (1M samples)')
print('  Loading TinyStories...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
texts = []
for i, row in enumerate(ds):
    if i >= 1000000:
        break
    texts.append(row['text'])
    if i % 100000 == 0:
        print(f'  Loaded {i:,}...')
print(f'  Total: {len(texts):,} stories')
banner('STEP 3 — TOKENIZE')

class StoryDataset(Dataset):

    def __init__(self, texts, tok, maxlen=128, n=50000):
        self.data = []
        for t in texts[:n]:
            enc = tok(t, truncation=True, max_length=maxlen, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])
        print(f'  Dataset: {len(self.data):,} samples')

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
dataset = StoryDataset(texts, tok, maxlen=128, n=50000)
loader = DataLoader(dataset, batch_size=64, shuffle=True)
banner('STEP 4 — TRAIN  (20 epochs, best checkpoint only)')

def generate(model, prompt, max_new=60):
    model.eval()
    ids = tok(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.1, pad_token_id=tok.eos_token_id)
    return tok.decode(out[0], skip_special_tokens=True)

def story_quality(output):
    words = output.split()
    uniq = len(set(words))
    n = max(len(words), 1)
    good = ['the', 'and', 'was', 'he', 'she', 'they', 'said', 'went', 'once', 'little']
    gc = sum((1 for w in good if w in output.lower()))
    score = round(uniq / n * 0.4 + min(gc / 5, 1.0) * 0.4 + min(len(words) / 30, 1.0) * 0.2, 3)
    return score
WATCH = 'Once upon a time there was a little'
opt = torch.optim.AdamW(kernel.parameters(), lr=0.0003, weight_decay=0.01)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=20, eta_min=1e-05)
scaler = torch.cuda.amp.GradScaler() if device.type == 'cuda' else None
best_score = -1
best_state = None
epoch_log = []
print(f"  {'Ep':>3}  {'Loss':>8}  {'Q':>6}  {'Time':>6}  Status")
print(f"  {'─' * 55}")
for epoch in range(1, 21):
    kernel.train()
    total = 0
    steps = 0
    t0 = time.time()
    for batch in loader:
        batch = batch.to(device)
        opt.zero_grad()
        if scaler:
            with torch.cuda.amp.autocast():
                out = kernel(batch, labels=batch)
            scaler.scale(out.loss).backward()
            scaler.unscale_(opt)
            nn.utils.clip_grad_norm_(kernel.parameters(), 1.0)
            scaler.step(opt)
            scaler.update()
        else:
            out = kernel(batch, labels=batch)
            out.loss.backward()
            nn.utils.clip_grad_norm_(kernel.parameters(), 1.0)
            opt.step()
        total += out.loss.item()
        steps += 1
    sched.step()
    avg_loss = total / steps
    ep_secs = time.time() - t0
    gen = generate(kernel, WATCH, max_new=60)
    q = story_quality(gen)
    out_text = gen[len(WATCH):].replace('\n', ' ')
    if q > best_score:
        best_score = q
        best_state = {k: v.clone().cpu() for k, v in kernel.state_dict().items()}
        status = f'← BEST {best_score:.3f} ✓'
    else:
        kernel.load_state_dict({k: v.to(device) for k, v in best_state.items()})
        status = f'  ROLLED BACK (best={best_score:.3f})'
    print(f'  {epoch:>3}  {avg_loss:>8.4f}  {q:>6.3f}  {ep_secs:>5.1f}s  {status}')
    print(f'       → {out_text[:80]}\n')
    epoch_log.append((epoch, avg_loss, q, ep_secs, q == best_score))
print(f'\n  ✓ Restoring best (score={best_score:.3f})...')
kernel.load_state_dict(best_state)
banner('FINAL SAMPLE')
kernel.eval()
for prompt in ['Once upon a time there was a little', 'The dog ran to', 'She was happy because']:
    gen = generate(kernel, prompt, max_new=80)
    print(f'  PROMPT: {prompt}')
    print(f'  OUTPUT: {gen[len(prompt):][:120]}\n')
banner('REPORT')
print(f'  Model    : {p_kernel:,} params')
print(f'  Data     : 50,000 TinyStories')
print(f'  Best Q   : {best_score:.3f}')
print(f'\n  Learning curve:')
for ep, loss, q, secs, saved in epoch_log:
    bar = '█' * int(q * 20)
    star = ' ★' if saved else ''
    print(f'  {ep:>3}  {loss:>8.4f}  {q:.3f}  {bar}{star}')
_dir = os.path.dirname(os.path.abspath(__file__))
out_dir = os.path.join(_dir, 'tiny_kernel_stories')
kernel.save_pretrained(out_dir)
tok.save_pretrained(out_dir)
print(f'\n  ✓ Saved to: {out_dir}')
banner('DONE')
