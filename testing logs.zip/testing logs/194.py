import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W KERNEL — CONTEXT AWARE')
print('  Kernel takes context window → next state')
print('  Not one token at a time.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
lm_head = model.lm_head.weight.detach().numpy()
print(f'  {n_layers} layers. {D}D hidden. Loaded.')
CONTEXT = 4
print(f'\n  Collecting context-aware hidden states...')
print(f'  Context window : {CONTEXT} tokens')
print(f'  Kernel input   : {CONTEXT * D} dims  ({CONTEXT} × {D})')
print(f'  Kernel output  : {D} dims')
print(f'  Kernel shape   : ({CONTEXT * D}, {D})')
print(f'  Kernel memory  : {CONTEXT * D * D * 4 / 1024 / 1024:.3f} MB')
sentences = ['once upon a time there was a little girl named lily', 'the dog ran fast through the green field near home', 'a boy found a red ball near the big river today', 'the cat sat on the warm mat beside the fire', 'she picked flowers and smiled at her mother warmly', 'he walked slowly down the quiet road in the rain', 'the bird flew high above the tall trees at dawn', 'a small fish swam in the clear blue lake alone', 'the children played happily together in the sunny yard', 'the old man sat quietly under the big oak tree', 'she opened the door and looked outside at the snow', 'he found a little puppy sleeping near the old house', 'the sun rose slowly over the distant green hills today', 'a rabbit jumped quickly and hid deep in the bushes', 'the little boy cried and ran fast to his mother', 'she baked warm cookies for all the happy children', 'the moon shone bright and clear over the quiet town', 'a dragon lived deep inside the cold and dark cave', 'the princess waited alone in the tall grey stone tower', 'he climbed the tall tree to find his lost kite', 'the wind blew cold and strong across the open field', 'a tiny mouse found a piece of cheese near the wall', 'the farmer woke up early and went to feed animals', 'she drew a colorful picture of her family and house', 'the train moved slowly through the high snowy mountains', 'a baby elephant splashed and played in the muddy water', 'the kind teacher read a long story to the students', 'he closed his eyes and wished upon the first star', 'the snow fell softly and quietly on the sleeping village', 'a kind old woman gave warm bread to hungry children', 'the puppy wagged its tail happily and barked very loud', 'she sang a sweet lullaby to help the baby sleep', 'the brave knight rode his horse into the dark forest', 'a young fox carefully learned to hunt from his mother', 'the flowers bloomed bright and beautiful in the spring sun', 'he discovered a hidden door behind the old bookshelf', 'the butterfly landed gently on a beautiful red rose', 'a little girl lost her way deep in the big woods', 'the friendly giant woke up and smiled at the village', 'she found a shiny magic stone beside the old stone well', 'the little cat chased the butterfly through the green garden', 'a brave boy climbed the mountain to see the whole world', 'the friendly witch made a magic potion in her cottage', 'a small boat sailed across the wide and quiet blue lake', 'the baby bear found honey in the hollow old oak tree', 'she whispered a secret to her best friend in school', 'the rainbow appeared after the long and heavy rain fell', 'a clever fox tricked the big wolf and ran away fast', 'the little prince lived alone on a very small planet', 'a kind fairy granted three wishes to the poor farmer', 'the young knight saved the princess from the dark tower', 'a little seed grew into a tall and beautiful flower', 'the old wizard taught the boy how to use magic', 'she found a lost kitten crying in the cold rain', 'the two friends walked together through the enchanted forest', 'a giant friendly bear helped the children find their way', 'the little mermaid swam up to see the bright stars', 'a boy named jack climbed the tall beanstalk to the sky', 'the kind queen shared food with all the hungry people', 'a little duck learned to swim in the warm sunny pond']
X_ctx, Y_hid, Y_lab = ([], [], [])
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=48, truncation=True)
        ids = tokens['input_ids']
        if ids.shape[1] < CONTEXT + 2:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        seq = ids.shape[1]
        embeds = hs[0][0].numpy()
        h_outs = hs[-1][0].numpy()
        logits = out.logits[0].numpy()
        for pos in range(CONTEXT, seq - 1):
            ctx = embeds[pos - CONTEXT + 1:pos + 1].flatten()
            X_ctx.append(ctx)
            Y_hid.append(h_outs[pos])
            Y_lab.append(ids[0, pos + 1].item())
X = np.array(X_ctx)
Y = np.array(Y_hid)
L = np.array(Y_lab)
N_tr = int(len(X) * 0.8)
X_tr, X_te = (X[:N_tr], X[N_tr:])
Y_tr, Y_te = (Y[:N_tr], Y[N_tr:])
L_tr, L_te = (L[:N_tr], L[N_tr:])
print(f'  Pairs collected: {len(X)}')
print(f'  Train: {N_tr}   Test: {len(X_te)}')
print(f'\n  Building W context kernel...')
K = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
kernel_mem = K.size * 4
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
print(f'  Kernel shape   : {K.shape}')
print(f'  Kernel memory  : {kernel_mem / 1024 / 1024:.3f} MB')
print(f'  Model memory   : {model_mem / 1024 / 1024:.1f} MB')
print(f'  Compression    : {model_mem / kernel_mem:.0f}x')
H_pred = X_te @ K
logits_pred = H_pred @ lm_head.T
with torch.no_grad():
    orig_logits = []
    orig_labels = []
    for sent in sentences[-10:]:
        tokens = tokenizer(sent, return_tensors='pt', max_length=48, truncation=True)
        ids = tokens['input_ids']
        if ids.shape[1] < CONTEXT + 2:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        seq = ids.shape[1]
        lg = out.logits[0].numpy()
        for pos in range(CONTEXT, seq - 1):
            orig_logits.append(lg[pos])
            orig_labels.append(ids[0, pos + 1].item())
OL = np.array(orig_logits)
OY = np.array(orig_labels)
orig_top1 = np.mean(np.argmax(OL, axis=1) == OY)
kern_top1 = np.mean(np.argmax(logits_pred, axis=1) == L_te)
kern_top5 = np.mean([L_te[i] in np.argsort(logits_pred[i])[-5:] for i in range(len(L_te))])
print(f'\n  Token prediction quality:')
print(f'  Original Top-1 : {orig_top1 * 100:.1f}%')
print(f'  Kernel   Top-1 : {kern_top1 * 100:.1f}%')
print(f'  Kernel   Top-5 : {kern_top5 * 100:.1f}%')
print(f'  Gap            : {abs(kern_top1 - orig_top1) * 100:.1f}%')

def softmax(x):
    e = np.exp(x - x.max())
    return e / e.sum()

def w_context_generate(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt)
    with torch.no_grad():
        id_tensor = torch.tensor([ids])
        embeds = model.transformer.wte(id_tensor)[0].numpy()
    for _ in range(max_new_tokens):
        seq_len = len(embeds)
        if seq_len < CONTEXT:
            pad = np.zeros((CONTEXT - seq_len, D))
            ctx_embeds = np.vstack([pad, embeds])
        else:
            ctx_embeds = embeds[-CONTEXT:]
        ctx_vec = ctx_embeds.flatten()
        h_pred = ctx_vec @ K
        logits = h_pred @ lm_head.T
        next_token = int(np.argmax(logits))
        if next_token == tokenizer.eos_token_id:
            break
        ids.append(next_token)
        with torch.no_grad():
            new_embed = model.transformer.wte(torch.tensor([[next_token]]))[0, 0].numpy()
        embeds = np.vstack([embeds, new_embed])
    return tokenizer.decode(ids, skip_special_tokens=True)

def original_generate(prompt, max_new_tokens=50):
    inp = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(inp, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def wrap(text, width=56):
    words = text.split()
    lines, line = ([], '  ')
    for w in words:
        if len(line) + len(w) > width:
            lines.append(line)
            line = '  ' + w + ' '
        else:
            line += w + ' '
    if line.strip():
        lines.append(line)
    return '\n'.join(lines)
print('\n' + '=' * 62)
print('  SIDE BY SIDE TEXT GENERATION')
print('=' * 62)
prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'A boy named Tom found a magic', 'The princess looked out the window and', 'One day a small rabbit decided to']
for i, prompt in enumerate(prompts):
    print(f"\n  {'─' * 58}")
    print(f'  PROMPT {i + 1}: "{prompt}"')
    print(f"  {'─' * 58}")
    orig = original_generate(prompt, 40)
    kern = w_context_generate(prompt, 40)
    print(f'\n  ORIGINAL (14.3MB, 8 layers, attention):')
    print(wrap(orig))
    print(f'\n  W KERNEL ({kernel_mem / 1024 / 1024:.3f}MB, 1 matrix, context={CONTEXT}):')
    print(wrap(kern))
    ow = set(orig.lower().split())
    kw = set(kern.lower().split())
    ov = len(ow & kw) / max(len(ow), 1)
    real_words = sum((1 for w in kern.split() if w.lower().strip('.,!?') in set(tokenizer.get_vocab().keys())))
    coherence = real_words / max(len(kern.split()), 1)
    print(f'\n  Word overlap    : {ov * 100:.0f}%')
    print(f'  W kernel words real : {coherence * 100:.0f}%')
print('\n' + '=' * 62)
print('  WHAT CHANGED FROM PREVIOUS ATTEMPT')
print('=' * 62)
print(f'\n  Previous kernel (FAILED):\n    Input  : one token embedding (64 dims)\n    Output : hidden state\n    Problem: no context — context-free mapping\n    Result : loops immediately, garbage\n\n  This kernel (context-aware):\n    Input  : {CONTEXT} token embeddings concatenated ({CONTEXT * D} dims)\n    Output : hidden state\n    Context: sees last {CONTEXT} tokens before predicting\n    Memory : {kernel_mem / 1024 / 1024:.3f} MB   (still tiny)\n\n  Key insight:\n    Attention captures relationships between tokens.\n    Context window captures same information differently.\n    Not: "what is this token?"\n    But: "what comes after THIS sequence of tokens?"\n\n  If output above is coherent:\n    Context kernel works.\n    Compression holds.\n    Generation works.\n    Path to 70B is real.\n')
print('=' * 62 + '\n')
