import os, time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
_dir = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def banner(text, char='=', width=68):
    print(f"\n{'=' * width}")
    print(f'  {text}')
    print(f"{'=' * width}")

def section(text):
    print(f"\n  ── {text} {'─' * (60 - len(text))}")
banner(f'TINYSTORIES INTELLIGENCE TRANSFER   device={device}')
section('Downloading models')
tokenizer = AutoTokenizer.from_pretrained('roneneldan/TinyStories-33M')
tokenizer.pad_token = tokenizer.eos_token
print('  Loading TinyStories-33M (teacher)...')
model_big = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-33M', use_safetensors=True).to(device).eval()
print('  Loading TinyStories-8M  (student)...')
model_small = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-8M', use_safetensors=True).to(device)
D_big = model_big.config.hidden_size
D_small = model_small.config.hidden_size
VS = model_big.config.vocab_size
p_big = sum((p.numel() for p in model_big.parameters()))
p_small = sum((p.numel() for p in model_small.parameters()))
print(f'\n  Teacher  33M : D={D_big:<6} params={p_big:>12,}')
print(f'  Student   8M : D={D_small:<6} params={p_small:>12,}')
print(f'  Compression  : {p_big / p_small:.1f}x fewer params in student')
print(f'  Vocab size   : {VS:,}')
PROMPTS = ['Once upon a time, there was a little girl named Lily.', 'Tom was a small boy who loved to play with his dog.', 'One day, a bunny found a big carrot in the garden.', 'The sun was shining and the birds were singing.', 'A little bear lived in a cozy cave in the forest.', 'The children ran to the playground and', 'Max saw a butterfly and decided to', 'It was raining outside so Anna decided to', 'The puppy was lost and started to', 'Sam found a shiny coin and', 'Lily was very sad because she', 'Ben was so happy when he', 'The little dragon was scared of', 'Emma felt proud when she', 'Jake was angry because his friend', 'There was a magic tree that could', 'The friendly robot learned how to', 'Deep in the ocean, a fish discovered', 'The baby elephant wanted to learn', 'One night, the stars started to', 'Once there was a kind old man who lived alone. Every day he fed the birds. One morning he woke up and', 'Lucy had a red balloon. She loved it very much. One day the wind blew it away and', 'The three little pigs built their houses. The wolf came and blew them down but']

def generate(model, prompt, max_new=80):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.3, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def quality(prompt, output):
    gen = output[len(prompt):]
    words = gen.split()
    uniq = len(set((w.lower() for w in words)))
    n = max(len(words), 1)
    score = round(uniq / n * 0.4 + min(n, 80) / 80 * 0.4 + output.rstrip().endswith(('.', '!', '?')) * 0.2, 3)
    return (score, len(words), uniq)

def run_all(model, label):
    banner(label)
    results = []
    total_q = 0
    for i, prompt in enumerate(PROMPTS):
        out = generate(model, prompt)
        q, ln, uniq = quality(prompt, out)
        total_q += q
        results.append((prompt, out, q, ln))
        gen_text = out[len(prompt):].strip().replace('\n', ' ')
        bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
        print(f'  [{i + 1:>2}] {bar} Q={q:.2f}  "{prompt[:40]}..."')
        print(f'       → {gen_text[:100]}')
    avg_q = total_q / len(PROMPTS)
    print(f'\n  Average quality: {avg_q:.3f}/1.0')
    return (results, avg_q)

def solve(A, B):
    return np.linalg.lstsq(A, B, rcond=None)[0]

def v16_transfer(wte_big, wte_small, k=3):
    P = solve(wte_big, wte_small)
    wte_proj = wte_big @ P
    wte_blend = 0.5 * wte_small + 0.5 * wte_proj
    agree_d = np.sum(wte_small * wte_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    wte_child = wte_blend.copy()
    wte_child[:, flip_dims] *= -1
    return (wte_child, flip_dims, agree_d)

class StoryDataset(Dataset):

    def __init__(self, texts, tok, maxlen=128):
        self.data = []
        for t in texts:
            enc = tok(t, truncation=True, max_length=maxlen, return_tensors='pt', padding='max_length')
            ids = enc.input_ids[0]
            self.data.append(ids)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
results_big, q_big = run_all(model_big, 'TEACHER — TinyStories-33M')
results_before, q_before = run_all(model_small, 'STUDENT BEFORE TRANSFER — TinyStories-8M')
banner('APPLYING V16 TRANSFER  (33M → 8M)')
WTE_big = model_big.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
WTE_small = model_small.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
print(f'  Teacher WTE : {WTE_big.shape}   D={D_big}')
print(f'  Student WTE : {WTE_small.shape}  D={D_small}')
WTE_child, flip_dims, agree_d = v16_transfer(WTE_big, WTE_small, k=3)
print(f'\n  Agreement range : {agree_d.min():.2f} → {agree_d.max():.2f}')
print(f'  All constructive: {np.all(agree_d > 0)}')
print(f'  Flipped dims    : {flip_dims.tolist()}')
with torch.no_grad():
    model_small.transformer.wte.weight.copy_(torch.tensor(WTE_child, dtype=torch.float32).to(device))
print('\n  ✓ Teacher WTE geometry injected into student.')
banner('FINE-TUNING STUDENT  (8 epochs, WTE frozen)')
print('  WTE is frozen. Only attention + FFN layers adapt to new geometry.')
print('  Watch the student learn after each epoch:\n')
model_small.transformer.wte.weight.requires_grad_(False)
print('  Loading training data...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
texts = []
for i, item in enumerate(ds):
    texts.append(item['text'])
    if len(texts) >= 2000:
        break
print(f'  Loaded {len(texts)} stories for fine-tuning.')
train_ds = StoryDataset(texts, tokenizer, maxlen=128)
loader = DataLoader(train_ds, batch_size=16, shuffle=True)
optimizer = torch.optim.AdamW([p for p in model_small.parameters() if p.requires_grad], lr=5e-05)
loss_fn = nn.CrossEntropyLoss(ignore_index=tokenizer.pad_token_id)
EPOCHS = 8
WATCH_PROMPT = 'Once upon a time, there was a little bear who'
print(f'\n  Watching prompt: "{WATCH_PROMPT}"\n')
print(f"  {'Epoch':>6}  {'Loss':>8}  {'Quality':>8}  Output preview")
print(f"  {'─' * 65}")
epoch_results = []
for epoch in range(1, EPOCHS + 1):
    model_small.train()
    total_loss = 0
    steps = 0
    t0 = time.time()
    for batch in loader:
        batch = batch.to(device)
        out = model_small(batch, labels=batch)
        loss = out.loss
        optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(model_small.parameters(), 1.0)
        optimizer.step()
        total_loss += loss.item()
        steps += 1
    avg_loss = total_loss / steps
    watch_out = generate(model_small, WATCH_PROMPT, max_new=50)
    watch_gen = watch_out[len(WATCH_PROMPT):].strip().replace('\n', ' ')
    q, ln, _ = quality(WATCH_PROMPT, watch_out)
    bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
    print(f'  Epoch {epoch:>2}/8   loss={avg_loss:.4f}   Q={q:.2f} {bar}')
    print(f'            → {watch_gen[:90]}')
    if epoch < EPOCHS:
        print()
    epoch_results.append((epoch, avg_loss, q))
print(f'\n  ✓ Fine-tuning complete.')
results_after, q_after = run_all(model_small, 'STUDENT AFTER TRANSFER — TinyStories-8M (V16 + fine-tuned)')
banner('FINAL COMPARISON')
print(f"  {'Model':>30}  {'Avg Quality':>12}  {'vs Before':>10}")
print(f"  {'─' * 55}")
print(f"  {'Teacher  33M':>30}  {q_big:>12.3f}  {'(reference)':>10}")
print(f"  {'Student   8M  BEFORE':>30}  {q_before:>12.3f}  {'baseline':>10}")
print(f"  {'Student   8M  AFTER':>30}  {q_after:>12.3f}  {q_after - q_before:>+10.3f}")
print(f'\n  Learning curve during fine-tuning:')
print(f"  {'Epoch':>6}  {'Loss':>8}  {'Quality':>8}  Progress")
print(f"  {'─' * 50}")
for ep, loss, q in epoch_results:
    bar = '█' * int(q * 20)
    print(f'  {ep:>6}  {loss:>8.4f}  {q:>8.3f}  {bar}')
print(f'\n  SIDE BY SIDE — first 5 prompts:')
print(f"  {'─' * 65}")
for i in range(5):
    p = PROMPTS[i]
    t = results_big[i][1][len(p):].strip().replace('\n', ' ')[:90]
    bef = results_before[i][1][len(p):].strip().replace('\n', ' ')[:90]
    aft = results_after[i][1][len(p):].strip().replace('\n', ' ')[:90]
    print(f'\n  Prompt  : {p}')
    print(f'  Teacher : {t}')
    print(f'  Before  : {bef}')
    print(f'  After   : {aft}')
save_path = os.path.join(_dir, 'tinystories_8m_after_transfer')
model_small.save_pretrained(save_path)
tokenizer.save_pretrained(save_path)
print(f'\n\n  ✓ Saved to: {save_path}')
banner('DONE')
