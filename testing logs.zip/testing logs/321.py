import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — SEMANTIC EARLY EXIT DIAGNOSTIC')
print('  Watching the physical memory crystallize layer by layer.')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
print('\n  [ Phase 1 ] Populating Semantic RAM Banks for ALL layers...')
RAM_bits = {l: [] for l in range(n_layers)}
RAM_tokens = []
store_pre = {l: [] for l in range(n_layers)}

def get_hook(l):

    def hook(m, i, o):
        store_pre[l].append(o[:, -1, :].detach().cpu().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.c_fc.register_forward_hook(get_hook(l)) for l in range(n_layers)]
seed_prompts = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon', 'A small dog ran across the green field', 'The king sat on his golden throne and', 'When the sun came up in the morning, the']
with torch.no_grad():
    for s in seed_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        for _ in range(15):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                bits = (store_pre[l].pop()[0] > 0).astype(int)
                RAM_bits[l].append(bits)
            RAM_tokens.append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM_bits[l] = np.array(RAM_bits[l])
RAM_tokens = np.array(RAM_tokens)
print(f'  ✓ {n_layers} Memory Banks loaded with {len(RAM_tokens)} states.')
print('\n' + '─' * 66)
print(f'  [ Phase 2 ] THE CRYSTALLIZATION TRAJECTORY')
print('  At what layer does the semantic address lock in?')
print('─' * 66)
test_prompt = 'The brave knight took his sword and'
print(f'  Prompt: {test_prompt}\n')
live_store = {l: [] for l in range(n_layers)}

def get_live_hook(l):

    def hook(m, i, o):
        live_store[l] = (o[:, -1, :].detach().cpu().numpy() > 0).astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].mlp.c_fc.register_forward_hook(get_live_hook(l)) for l in range(n_layers)]
pt_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_layers_saved = 0
total_tokens_generated = 10
with torch.no_grad():
    for step in range(total_tokens_generated):
        out = model(pt_ids)
        final_id = torch.argmax(out.logits[0, -1, :]).item()
        final_word = tokenizer.decode([final_id])
        print(f'  Token {step + 1}: Target -> [{final_word.strip()}]')
        locked_in_layer = -1
        for l in range(n_layers):
            current_bits = live_store[l]
            matches = np.sum(RAM_bits[l] == current_bits, axis=1)
            best_idx = np.argmax(matches)
            predicted_id = int(RAM_tokens[best_idx])
            predicted_word = tokenizer.decode([predicted_id])
            status = ''
            if predicted_id == final_id:
                if locked_in_layer == -1:
                    locked_in_layer = l
                    status = ' <--- [ LOCKED IN EARLY ]'
            print(f'    Layer {l}: {predicted_word.strip():<12} {status}')
        if locked_in_layer != -1:
            layers_saved = n_layers - 1 - locked_in_layer
            total_layers_saved += layers_saved
            print(f'    * Result: We could have amputated {layers_saved} layers of compute.')
        else:
            print(f'    * Result: Required all 8 layers to resolve.')
        print('-' * 40)
        pt_ids = torch.cat([pt_ids, torch.tensor([[final_id]])], dim=1)
for h in live_hooks:
    h.remove()
print('\n' + '=' * 66)
print('  EARLY EXIT VERDICT:')
print(f'  By listening to the GeLU Semantic RAM, we could have')
print(f'  bypassed {total_layers_saved} total layers of heavy math across {total_tokens_generated} tokens!')
print('=' * 66 + '\n')
