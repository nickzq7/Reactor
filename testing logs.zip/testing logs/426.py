import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import time, math, copy
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForCausalLM
D = 64
N_LAYERS = 8
FFN_DIM = 256
N_HEADS = 4
MAX_LEN = 128
VOCAB = 50257
BATCH = 16
LR = 0.0003
EPOCHS = 3
N_TEXTS = 500
DEVICE = 'cpu'
R2_FLOOR = 0.999
LOSS_PATIENCE = 3
print(f'\nW-LAW TRAINING + IMPOSSIBILITY CHECK')
print(f'D={D}  Layers={N_LAYERS}  R²_floor={R2_FLOOR}')
tokenizer = AutoTokenizer.from_pretrained('roneneldan/TinyStories-1M')
ref_model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
ref_model.eval()
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at', 'The wind was cold', 'A little rabbit hopped', 'The brave knight rode', 'She woke up and', 'He could not find', 'The magic door opened', 'They walked together through', 'The small house had', 'A star fell from', 'He whispered to her', 'The princess lived in', 'A young fox played', 'The river was cold', 'She picked up the', 'Two friends walked to', 'The baby smiled at']
print(f'\nGenerating {N_TEXTS} training texts...')
train_texts = []
with torch.no_grad():
    i = 0
    while len(train_texts) < N_TEXTS:
        s = seeds[i % len(seeds)]
        torch.manual_seed(i)
        inp = tokenizer.encode(s, return_tensors='pt')
        out = ref_model.generate(inp, max_new_tokens=50, do_sample=True, temperature=0.85, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
        train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
        i += 1
print(f'Generated {len(train_texts)} texts.')
del ref_model
all_ids = []
for t in train_texts:
    ids = tokenizer.encode(t, max_length=MAX_LEN, truncation=True)
    if len(ids) > 8:
        all_ids.append(torch.tensor(ids, dtype=torch.long))

class TextDS(Dataset):

    def __init__(self, ids):
        self.ids = ids

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, i):
        return self.ids[i]

def collate(batch):
    L = max((b.shape[0] for b in batch))
    x = torch.zeros(len(batch), L, dtype=torch.long)
    for i, b in enumerate(batch):
        x[i, :b.shape[0]] = b
    return x
loader = DataLoader(TextDS(all_ids), batch_size=BATCH, shuffle=True, collate_fn=collate)
print(f'Dataset: {len(all_ids)} sequences')

class SharedFFN(nn.Module):

    def __init__(self):
        super().__init__()
        self.c_fc = nn.Linear(D, FFN_DIM)
        self.act = nn.GELU()
        self.W_ffn = nn.Parameter(torch.randn(FFN_DIM + 1, D) * 0.01, requires_grad=False)
        self.use_Wffn = False
        self.c_proj = nn.Linear(FFN_DIM, D)
        self._last_gelu = None
        self._last_out = None

    def forward(self, x):
        gate = self.act(self.c_fc(x))
        self._last_gelu = gate.detach()
        if self.use_Wffn:
            B, L, fd = gate.shape
            gf = gate.float().reshape(B * L, fd)
            gb = torch.cat([gf, torch.ones(B * L, 1)], dim=1)
            out = gb @ self.W_ffn
            out = out.reshape(B, L, -1).to(x.dtype)
            self._last_out = out.detach()
            return out
        else:
            out = self.c_proj(gate)
            self._last_out = out.detach()
            return out

class SharedAttn(nn.Module):

    def __init__(self):
        super().__init__()
        self.nh = N_HEADS
        self.hd = D // N_HEADS
        self.q = nn.Linear(D, D)
        self.k = nn.Linear(D, D)
        self.v = nn.Linear(D, D)
        self.o = nn.Linear(D, D)

    def forward(self, x, mask=None):
        B, L, _ = x.shape
        q = self.q(x).reshape(B, L, self.nh, self.hd).transpose(1, 2)
        k = self.k(x).reshape(B, L, self.nh, self.hd).transpose(1, 2)
        v = self.v(x).reshape(B, L, self.nh, self.hd).transpose(1, 2)
        sc = q @ k.transpose(-2, -1) / math.sqrt(self.hd)
        if mask is not None:
            sc = sc + mask
        w = torch.softmax(sc.float(), dim=-1).to(x.dtype)
        return self.o((w @ v).transpose(1, 2).reshape(B, L, D))

class ULayer(nn.Module):

    def __init__(self, ffn):
        super().__init__()
        self.attn = SharedAttn()
        self.ln1 = nn.LayerNorm(D)
        self.ln2 = nn.LayerNorm(D)
        self.ffn = ffn

    def forward(self, x):
        L = x.shape[1]
        mask = torch.tril(torch.ones(L, L, device=x.device))
        mask = (1.0 - mask) * -1000000000.0
        x = x + self.attn(self.ln1(x), mask)
        x = x + self.ffn(self.ln2(x))
        return x

class UModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VOCAB, D)
        self.wpe = nn.Embedding(MAX_LEN, D)
        self.shared_ffn = SharedFFN()
        self.layers = nn.ModuleList([ULayer(self.shared_ffn) for _ in range(N_LAYERS)])
        self.ln_f = nn.LayerNorm(D)
        self.lm_head = nn.Linear(D, VOCAB, bias=False)

    def forward(self, ids):
        B, L = ids.shape
        pos = torch.arange(L, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        for layer in self.layers:
            x = layer(x)
        return self.lm_head(self.ln_f(x))

    def attn_params(self):
        skip = set(self.shared_ffn.parameters())
        return [p for p in self.parameters() if p not in skip]

def r2_np(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_wffn(model, texts, n=200):
    G_buf = []
    F_buf = []
    hooks = []
    model.shared_ffn.use_Wffn = False

    def hg(m, inp, out):
        for t in range(out.shape[1]):
            G_buf.append(out[0, t].detach().cpu().float().numpy().copy())

    def hf(m, inp, out):
        for t in range(out.shape[1]):
            F_buf.append(out[0, t].detach().cpu().float().numpy().copy())
    h1 = model.shared_ffn.act.register_forward_hook(hg)
    h2 = model.shared_ffn.c_proj.register_forward_hook(hf)
    model.eval()
    with torch.no_grad():
        for text in texts[:n]:
            ids = tokenizer.encode(text, return_tensors='pt', max_length=MAX_LEN, truncation=True)
            model(ids)
    h1.remove()
    h2.remove()
    G = np.array(G_buf, np.float32)
    F = np.array(F_buf, np.float32)
    Xb = np.c_[G.astype(np.float64), np.ones(len(G))]
    W = np.linalg.lstsq(Xb, F.astype(np.float64), rcond=None)[0].astype(np.float32)
    pred = (Xb @ W).astype(np.float32)
    rv = r2_np(pred, F)
    with torch.no_grad():
        model.shared_ffn.W_ffn.copy_(torch.tensor(W))
    model.shared_ffn.use_Wffn = True
    return rv

def check_r2_fast(model):
    g = model.shared_ffn._last_gelu
    o = model.shared_ffn._last_out
    if g is None or o is None:
        return 1.0
    B, L, fd = g.shape
    gf = g.float().reshape(B * L, fd).numpy()
    of = o.float().reshape(B * L, -1).numpy()
    Xb = np.c_[gf, np.ones(B * L)]
    W = model.shared_ffn.W_ffn.detach().numpy()
    pred = Xb @ W
    return r2_np(pred, of)

def generate(model, prompt, max_new=60):
    model.eval()
    model.shared_ffn.use_Wffn = True
    ids = tokenizer.encode(prompt, return_tensors='pt')
    out = []
    with torch.no_grad():
        for _ in range(max_new):
            if ids.shape[1] >= MAX_LEN:
                break
            logits = model(ids)
            tok = int(torch.argmax(logits[0, -1, :]).item())
            out.append(tok)
            ids = torch.cat([ids, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return tokenizer.decode(out, skip_special_tokens=True)
print(f"\n{'=' * 60}")
print(f'RUN A: Baseline — W-law training, no impossibility check')
print(f"{'=' * 60}")
model_A = UModel()
fit_wffn(model_A, train_texts)
opt_A = optim.AdamW(model_A.attn_params(), lr=LR, weight_decay=0.01)
crit = nn.CrossEntropyLoss(ignore_index=0)
stats_A = {'steps': 0, 'wasted': 0, 'loss_hist': [], 'r2_hist': []}
t_A = time.time()
for epoch in range(EPOCHS):
    model_A.train()
    model_A.shared_ffn.use_Wffn = True
    ep_loss = 0
    for step, batch in enumerate(loader):
        if batch.shape[1] < 2:
            continue
        logits = model_A(batch[:, :-1])
        loss = crit(logits.reshape(-1, VOCAB), batch[:, 1:].reshape(-1))
        opt_A.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model_A.attn_params(), 1.0)
        opt_A.step()
        stats_A['steps'] += 1
        ep_loss += loss.item()
        if step % 50 == 0:
            print(f'  A Epoch{epoch + 1} step{step:4d} loss={loss.item():.4f}', flush=True)
    r2_ep = fit_wffn(model_A, train_texts)
    stats_A['loss_hist'].append(ep_loss / max(1, step + 1))
    stats_A['r2_hist'].append(r2_ep)
    print(f'  A Epoch{epoch + 1} done: loss={ep_loss / max(1, step + 1):.4f} W_ffn_R²={r2_ep:.4f}')
time_A = time.time() - t_A
stats_A['time'] = time_A
print(f"  Run A total: {time_A:.0f}s  steps={stats_A['steps']}")
print(f"\n{'=' * 60}")
print(f'RUN B: Impossibility checks active')
print(f'  CHECK 1: R² guard — refit if R² drops below {R2_FLOOR}')
print(f'  CHECK 2: gradient projection — scale law-breaking components')
print(f'  CHECK 3: loss patience — skip impossible direction after {LOSS_PATIENCE} bad steps')
print(f"{'=' * 60}")
model_B = UModel()
fit_wffn(model_B, train_texts)
opt_B = optim.AdamW(model_B.attn_params(), lr=LR, weight_decay=0.01)
stats_B = {'steps': 0, 'skipped': 0, 'r2_fixes': 0, 'loss_hist': [], 'r2_hist': [], 'wasted_saved': 0}
best_loss_B = float('inf')
bad_streak = 0
best_state_B = copy.deepcopy(model_B.state_dict())
t_B = time.time()
for epoch in range(EPOCHS):
    model_B.train()
    model_B.shared_ffn.use_Wffn = True
    ep_loss = 0
    ep_steps = 0
    for step, batch in enumerate(loader):
        if batch.shape[1] < 2:
            continue
        logits = model_B(batch[:, :-1])
        loss = crit(logits.reshape(-1, VOCAB), batch[:, 1:].reshape(-1))
        if loss.item() > best_loss_B * 1.15 and step > 10:
            bad_streak += 1
            if bad_streak >= LOSS_PATIENCE:
                model_B.load_state_dict(best_state_B)
                opt_B = optim.AdamW(model_B.attn_params(), lr=LR * 0.7, weight_decay=0.01)
                bad_streak = 0
                stats_B['skipped'] += 1
                if step % 50 == 0:
                    print(f'  B IMPOSSIBLE direction at step {step}. Skip.', flush=True)
                continue
        else:
            bad_streak = 0
            if loss.item() < best_loss_B:
                best_loss_B = loss.item()
                best_state_B = copy.deepcopy(model_B.state_dict())
        opt_B.zero_grad()
        loss.backward()
        total_grad_norm = 0
        for p in model_B.attn_params():
            if p.grad is not None:
                total_grad_norm += p.grad.norm().item() ** 2
        total_grad_norm = total_grad_norm ** 0.5
        law_scale = min(1.0, math.sqrt(D) / (total_grad_norm + 1e-08))
        if law_scale < 1.0:
            for p in model_B.attn_params():
                if p.grad is not None:
                    p.grad.mul_(law_scale)
            stats_B['wasted_saved'] += 1 - law_scale
        torch.nn.utils.clip_grad_norm_(model_B.attn_params(), 1.0)
        opt_B.step()
        stats_B['steps'] += 1
        ep_loss += loss.item()
        ep_steps += 1
        r2_now = check_r2_fast(model_B)
        if r2_now < R2_FLOOR:
            fit_wffn(model_B, train_texts[:50])
            stats_B['r2_fixes'] += 1
        if step % 50 == 0:
            print(f"  B Epoch{epoch + 1} step{step:4d} loss={loss.item():.4f} r2={r2_now:.4f} skipped={stats_B['skipped']}", flush=True)
    r2_ep = fit_wffn(model_B, train_texts)
    stats_B['loss_hist'].append(ep_loss / max(1, ep_steps))
    stats_B['r2_hist'].append(r2_ep)
    print(f"  B Epoch{epoch + 1} done: loss={ep_loss / max(1, ep_steps):.4f} W_ffn_R²={r2_ep:.4f} skipped={stats_B['skipped']} r2_fixes={stats_B['r2_fixes']}")
time_B = time.time() - t_B
stats_B['time'] = time_B
print(f"  Run B total: {time_B:.0f}s  valid_steps={stats_B['steps']}")
prompts = ['Once upon a time there was a little girl', 'The little boy found a magic', 'She looked at the stars and', 'One day a small rabbit']
print(f"\n{'=' * 70}")
print(f'  FINAL COMPARISON')
print(f"{'=' * 70}")
print(f'\n  TRAINING:')
print(f"  {'Metric':<30} {'Run A (baseline)':<22} {'Run B (impossible)'}")
print(f"  {'─' * 70}")
print(f"  {'Time (seconds)':<30} {time_A:<22.0f} {time_B:.0f}")
print(f"  {'Valid steps':<30} {stats_A['steps']:<22} {stats_B['steps']}")
print(f"  {'Impossible skips':<30} {'0':<22} {stats_B['skipped']}")
print(f"  {'R² fixes':<30} {'0':<22} {stats_B['r2_fixes']}")
print(f"  {'Final loss':<30} {stats_A['loss_hist'][-1]:<22.4f} {stats_B['loss_hist'][-1]:.4f}")
print(f"  {'Final W_ffn R²':<30} {stats_A['r2_hist'][-1]:<22.4f} {stats_B['r2_hist'][-1]:.4f}")
print(f"  {'Speedup B vs A':<30} {'—':<22} {time_A / time_B:.2f}x")
print(f'\n  GENERATION:')
for p in prompts:
    ga = generate(model_A, p)
    gb = generate(model_B, p)
    print(f'\n  PROMPT: {p}')
    print(f'  A: {ga[:120]}')
    print(f'  B: {gb[:120]}')
print(f"\n{'=' * 70}")
print(f'\n  WHAT THE NUMBERS MEAN:\n\n  If B loss < A loss in same time:\n    Impossibility check = faster convergence proven.\n    Eliminating impossible directions = cleaner gradient.\n\n  If B time < A time for same loss:\n    Impossibility saves compute.\n    Fewer wasted steps.\n\n  If B skipped > 0:\n    Bad directions were detected and avoided.\n    Those steps would have been wasted in A.\n    Each skip = saved compute.\n\n  If R² fixes > 0:\n    FFN left natural space during training.\n    Check caught it. Refitted instantly.\n    Without check: error would compound.\n    With check: law maintained always.\n\n  Key insight:\n    Laws define what is impossible.\n    Impossible = never compute.\n    Every skip = real saved time.\n    This scales: 70B model = 70B× more impossible directions.\n    Impossibility check = more valuable at larger scale.\n')
print('=' * 70 + '\n')
