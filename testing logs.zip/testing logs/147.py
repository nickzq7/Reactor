import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D16 = meta['DA']
H16 = meta['HA']
NL = meta['NLA']
D2 = 2
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s
fib = gen_fib(60)

def make_level(name):
    pats = {}
    if name == 'L1_counting':
        for start in range(8):
            seq = [(start + i) % VS for i in range(20)]
            pats[f'count_{start}'] = (seq, (start + 20) % VS)
    elif name == 'L2_evens':
        for off in range(8):
            seq = [(off + i * 2) % VS for i in range(20)]
            pats[f'even_{off}'] = (seq, (off + 40) % VS)
    elif name == 'L3_threes':
        for off in range(8):
            seq = [(off + i * 3) % VS for i in range(20)]
            pats[f'three_{off}'] = (seq, (off + 60) % VS)
    elif name == 'L4_arithmetic':
        for step in range(1, 9):
            seq = [i * step % VS for i in range(20)]
            pats[f'arith_{step}'] = (seq, 20 * step % VS)
    elif name == 'L5_fibonacci':
        for off in range(8):
            pats[f'fib_{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
    return pats
LEVEL_NAMES = ['L1_counting', 'L2_evens', 'L3_threes', 'L4_arithmetic', 'L5_fibonacci']

class SeqT(nn.Module):

    def __init__(self, d, h=1):
        super().__init__()
        self.d = d
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, h, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_donor(di):
    path = os.path.join(_dir, f'donor_{di:02d}.npz')
    W = np.load(path)
    state = {k: torch.tensor(v.astype(np.float32)) for k, v in W.items()}
    m = SeqT(D16, H16).to(device)
    m.load_state_dict(state, strict=True)
    return m

def eval_model(model, pats):
    model.eval()
    scores = []
    for pn, (seq, truth) in pats.items():
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        scores.append(p == truth)
    return (sum(scores), scores)

def build_tensors(pats):
    Xs = []
    Ys = []
    for pn, (seq, _) in pats.items():
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))

def train(model, pats, steps=3000, lr=0.003, label='', print_every=500):
    X, Y = build_tensors(pats)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(X).view(-1, VS), Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, _ = eval_model(model, pats)
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'    [{label}] step {step:>5}: {sc}/{len(pats)}', flush=True)
            if sc == len(pats):
                break
    if best_state:
        model.load_state_dict(best_state)
    return eval_model(model, pats)

def get_state(m):
    return {k: v.detach().cpu().numpy().astype(np.float64) for k, v in m.state_dict().items()}

def set_state(m, s):
    m.load_state_dict({k: torch.tensor(v.astype(np.float32)) for k, v in s.items()})

def clone(s):
    return {k: v.copy() for k, v in s.items()}

def mutate_full(state, rng, strength=None):
    s = clone(state)
    if strength is None:
        strength = rng.uniform(0.01, 0.5)
    op = rng.choice(['point', 'layer', 'sign_flip', 'rot_wte', 'wte_inject', 'scale', 'big_noise', 'ff_scale'])
    keys = list(s.keys())
    if op == 'point':
        k = rng.choice(keys)
        s[k] += rng.randn(*s[k].shape) * np.std(s[k]) * strength
    elif op == 'layer':
        l = rng.randint(NL)
        for k in keys:
            if f'layers.{l}.' in k:
                s[k] += rng.randn(*s[k].shape) * np.std(s[k]) * strength
    elif op == 'sign_flip':
        for k in keys:
            if s[k].ndim >= 2 and s[k].shape[-1] >= 2:
                d = rng.randint(min(2, s[k].shape[-1]))
                s[k][..., d] *= -1
    elif op == 'rot_wte':
        if 'wte.weight' in s:
            ang = rng.uniform(0, 2 * math.pi)
            c, ss = (math.cos(ang), math.sin(ang))
            x0 = s['wte.weight'][:, 0].copy()
            x1 = s['wte.weight'][:, 1].copy()
            s['wte.weight'][:, 0] = c * x0 - ss * x1
            s['wte.weight'][:, 1] = ss * x0 + c * x1
    elif op == 'wte_inject':
        if 'wte.weight' in s:
            angles = np.linspace(0, 2 * math.pi, VS, endpoint=False)
            angles += rng.uniform(0, 2 * math.pi)
            r = np.std(s['wte.weight']) * rng.uniform(0.5, 2.0)
            circle = np.stack([r * np.cos(angles), r * np.sin(angles)], axis=1)
            alpha = rng.uniform(0.05, 0.6)
            s['wte.weight'] = (1 - alpha) * s['wte.weight'] + alpha * circle
    elif op == 'scale':
        k = rng.choice(keys)
        s[k] *= rng.uniform(0.3, 2.5)
    elif op == 'big_noise':
        for k in rng.choice(keys, rng.randint(1, len(keys) // 2 + 1), replace=False):
            s[k] += rng.randn(*s[k].shape) * np.std(s[k]) * rng.uniform(0.1, 0.8)
    elif op == 'ff_scale':
        factor = rng.uniform(0.1, 3.0)
        for k in keys:
            if 'ff' in k:
                s[k] *= factor
    return s

def cross_mutate(states, rng):
    child = clone(states[0])
    groups = {}
    for k in child.keys():
        g = 'wte' if 'wte' in k else 'wpe' if 'wpe' in k else 'ln_f' if 'ln_f' in k else k.split('.')[0] + '.' + k.split('.')[1]
        groups.setdefault(g, []).append(k)
    for g, ks in groups.items():
        parent = states[rng.randint(len(states))]
        for k in ks:
            if k in parent:
                child[k] = parent[k].copy()
    return child

def meta_mutate(state, rng):
    s = clone(state)
    for _ in range(rng.randint(2, 6)):
        s = mutate_full(s, rng, strength=rng.uniform(0.01, 0.8))
    return s

def viral_search(pats, seed_states, n_gen=20, pool_size=100, children_per_gen=300, label=''):
    rng = np.random.RandomState(42)
    scratch = SeqT(D2, 1).to(device)

    def score(state):
        set_state(scratch, state)
        sc, _ = eval_model(scratch, pats)
        return sc
    pool = [(score(s), clone(s)) for s in seed_states]
    pool.sort(key=lambda x: x[0], reverse=True)
    global_best = pool[0]
    for gen in range(n_gen):
        survivors = [s for _, s in pool[:max(5, pool_size // 5)]]
        children = []
        for _ in range(children_per_gen):
            r = rng.rand()
            if r < 0.3:
                base = clone(survivors[rng.randint(len(survivors))])
                child = mutate_full(base, rng)
            elif r < 0.55:
                base = clone(survivors[rng.randint(len(survivors))])
                child = meta_mutate(base, rng)
            elif r < 0.8:
                n_p = min(rng.randint(2, 5), len(survivors))
                child = cross_mutate([survivors[i] for i in rng.choice(len(survivors), n_p, replace=False)], rng)
            else:
                n_p = min(rng.randint(2, 4), len(survivors))
                child = cross_mutate([survivors[i] for i in rng.choice(len(survivors), n_p, replace=False)], rng)
                child = mutate_full(child, rng)
            sc = score(child)
            children.append((sc, child))
            if sc > global_best[0]:
                global_best = (sc, clone(child))
                bar_sc = sc
                print(f'    [{label}] gen {gen} NEW BEST {sc}/{len(pats)}', flush=True)
                if sc == len(pats):
                    break
        if global_best[0] == len(pats):
            break
        pool = sorted(pool + children, key=lambda x: x[0], reverse=True)[:pool_size]
        print(f'    [{label}] gen {gen:>3}  best={pool[0][0]}/{len(pats)}  global={global_best[0]}/{len(pats)}', flush=True)
    return global_best

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def v16_d16_to_d2(wte16, k_flip=3):
    U, s, Vt = np.linalg.svd(wte16, full_matrices=False)
    WTE_B2 = (U[:, :D2] * s[:D2]).astype(np.float64)
    rng = np.random.RandomState(0)
    WTE_A = rng.randn(VS, D2) * 0.02
    P = solve(WTE_B2, WTE_A)
    WTE_B_proj = WTE_B2 @ P
    WTE_h = 0.5 * WTE_A + 0.5 * WTE_B_proj
    agree_d = np.sum(WTE_A * WTE_B_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k_flip:]
    WTE_h[:, flip_dims] *= -1
    return (WTE_h, flip_dims, agree_d)

def plot_geometry(model, pats, label):
    wte = model.wte.weight.detach().numpy()
    sc, scores = eval_model(model, pats)
    fig, axes = plt.subplots(1, 2, figsize=(13, 6))
    fig.suptitle(f'D=2 Geometry — {label}  score={sc}/{len(pats)}', fontsize=12)
    ax = axes[0]
    ax.scatter(wte[:, 0], wte[:, 1], c=np.arange(VS), cmap='hsv', s=80, zorder=3, edgecolors='black', linewidths=0.3)
    for i in range(VS):
        ax.annotate(str(i), (wte[i, 0], wte[i, 1]), fontsize=6.5, ha='center', va='bottom')
    r = np.mean(np.linalg.norm(wte, axis=1))
    th = np.linspace(0, 2 * np.pi, 200)
    ax.plot(r * np.cos(th), r * np.sin(th), 'gray', lw=0.5, ls='--', alpha=0.4)
    ax.set_title('Token positions (colored by index)')
    ax.set_aspect('equal')
    ax.axhline(0, color='gray', lw=0.4)
    ax.axvline(0, color='gray', lw=0.4)
    ax = axes[1]
    ax.scatter(wte[:, 0], wte[:, 1], c='lightgray', s=40, zorder=2)
    for i in range(VS):
        ax.annotate(str(i), (wte[i, 0], wte[i, 1]), fontsize=6, color='gray')
    colors_path = plt.cm.plasma(np.linspace(0, 1, 15))
    first_seq = list(pats.values())[0][0]
    for i in range(min(14, len(first_seq) - 1)):
        t0, t1 = (first_seq[i] % VS, first_seq[i + 1] % VS)
        ax.annotate('', xy=(wte[t1, 0], wte[t1, 1]), xytext=(wte[t0, 0], wte[t0, 1]), arrowprops=dict(arrowstyle='->', color=colors_path[i], lw=1.5, alpha=0.8))
    pts = np.array([wte[t % VS] for t in first_seq[:15]])
    ax.scatter(pts[:, 0], pts[:, 1], c='red', s=100, zorder=4, edgecolors='black', linewidths=0.4)
    ax.set_title(f'First pattern path (red=visited tokens)')
    ax.set_aspect('equal')
    ax.axhline(0, color='gray', lw=0.4)
    ax.axvline(0, color='gray', lw=0.4)
    bar = ''.join(('█' if x else '░' for x in scores))
    fig.text(0.5, 0.01, f'{bar}', ha='center', fontsize=10, color='green' if sc == len(pats) else 'orange' if sc > 0 else 'red')
    plt.tight_layout()
    path = os.path.join(_dir, f'test2_{label}.png')
    plt.savefig(path, dpi=120, bbox_inches='tight')
    plt.close()
    print(f'    → Plot: test2_{label}.png', flush=True)
print('=' * 65)
print('  TEST 2 — ALL PATTERNS × D=2')
print('  PART 1: scratch training + viral mutations')
print('  PART 2: V16 formula D=16 → D=2')
print('=' * 65)
results_p1 = {}
results_p2 = {}
t_total = time.time()
for level_name in LEVEL_NAMES:
    pats = make_level(level_name)
    print(f"\n{'=' * 65}")
    print(f'  LEVEL: {level_name}  ({len(pats)} patterns)')
    print(f"{'=' * 65}")
    print(f'\n  PART 1 — Scratch + Viral Mutations')
    t0 = time.time()
    best_sc_p1 = 0
    best_model_p1 = None
    for seed in [7, 42, 99]:
        torch.manual_seed(seed)
        np.random.seed(seed)
        m = SeqT(D2, 1).to(device)
        sc, _ = train(m, pats, steps=2000, lr=0.003, label=f'{level_name}_s{seed}', print_every=500)
        if sc == len(pats):
            best_sc_p1 = sc
            best_model_p1 = m
            print(f'    Seed {seed}: {sc}/{len(pats)} ✓ SOLVED by training alone')
            break
        seed_states = [get_state(m)]
        for _ in range(4):
            mm = SeqT(D2, 1).to(device)
            seed_states.append(get_state(mm))
        best_sc, best_state = viral_search(pats, seed_states, n_gen=15, pool_size=80, children_per_gen=200, label=f'{level_name}_s{seed}')
        if best_sc > best_sc_p1:
            best_sc_p1 = best_sc
            best_model_p1 = SeqT(D2, 1).to(device)
            set_state(best_model_p1, best_state)
        print(f'    Seed {seed}: after viral search → {best_sc}/{len(pats)}')
        if best_sc_p1 == len(pats):
            break
    if best_model_p1 is not None and best_sc_p1 < len(pats):
        print(f'    Training best found state further (1000 steps)...')
        sc_final, _ = train(best_model_p1, pats, steps=1000, lr=0.001, label=f'{level_name}_refine', print_every=500)
        if sc_final > best_sc_p1:
            best_sc_p1 = sc_final
    results_p1[level_name] = best_sc_p1
    print(f'  PART 1 RESULT: {best_sc_p1}/{len(pats)}  ({time.time() - t0:.0f}s)')
    if best_model_p1:
        plot_geometry(best_model_p1, pats, f'p1_{level_name}')
    print(f'\n  PART 2 — V16 Formula D=16 → D=2')
    t0 = time.time()
    donor_map = {'L1_counting': 0, 'L2_evens': 0, 'L3_threes': 0, 'L4_arithmetic': 0, 'L5_fibonacci': 4}
    donor_idx = donor_map[level_name]
    try:
        donor = load_donor(donor_idx)
        wte16 = donor.wte.weight.detach().numpy().astype(np.float64)
        donor_sc, _ = eval_model(donor, pats)
        print(f'    Donor {donor_idx + 1} score on this level: {donor_sc}/{len(pats)}')
    except Exception as e:
        print(f'    Could not load donor: {e}')
        results_p2[level_name] = 0
        continue
    best_sc_p2 = 0
    best_model_p2 = None
    for k in [1, 2]:
        wte2_v16, flip_dims, agree_d = v16_d16_to_d2(wte16, k_flip=k)
        print(f'    V16 k={k}: flip_dims={flip_dims}  agree={agree_d.round(3)}')
        torch.manual_seed(0)
        m = SeqT(D2, 1).to(device)
        with torch.no_grad():
            m.wte.weight.copy_(torch.tensor(wte2_v16, dtype=torch.float32))
        sc, _ = train(m, pats, steps=2000, lr=0.003, label=f'{level_name}_v16_k{k}', print_every=500)
        if sc > best_sc_p2:
            best_sc_p2 = sc
            best_model_p2 = m
        print(f'    V16 k={k} after training: {sc}/{len(pats)}')
        if sc == len(pats):
            break
    if best_sc_p2 < len(pats):
        print(f'    Viral search from V16 init...')
        wte2_v16, _, _ = v16_d16_to_d2(wte16, k_flip=1)
        m_v16 = SeqT(D2, 1).to(device)
        with torch.no_grad():
            m_v16.wte.weight.copy_(torch.tensor(wte2_v16, dtype=torch.float32))
        seed_states = [get_state(m_v16)]
        for _ in range(3):
            mm = SeqT(D2, 1).to(device)
            seed_states.append(get_state(mm))
        sc_v, best_state_v = viral_search(pats, seed_states, n_gen=10, pool_size=60, children_per_gen=150, label=f'{level_name}_v16_viral')
        if sc_v > best_sc_p2:
            best_sc_p2 = sc_v
            best_model_p2 = SeqT(D2, 1).to(device)
            set_state(best_model_p2, best_state_v)
        print(f'    V16 + viral search: {sc_v}/{len(pats)}')
    results_p2[level_name] = best_sc_p2
    print(f'  PART 2 RESULT: {best_sc_p2}/{len(pats)}  ({time.time() - t0:.0f}s)')
    if best_model_p2:
        plot_geometry(best_model_p2, pats, f'p2_{level_name}')
print(f"\n{'=' * 65}")
print(f'  FINAL COMPARISON — D=2 RESULTS')
print(f"{'=' * 65}")
print(f"\n  {'Level':>20}  {'P1 scratch+mut':>16}  {'P2 V16 D16→D2':>15}")
print(f"  {'─' * 58}")
for lv in LEVEL_NAMES:
    n = len(make_level(lv))
    p1 = results_p1.get(lv, 0)
    p2 = results_p2.get(lv, 0)
    p1_bar = '█' * p1 + '░' * (n - p1)
    p2_bar = '█' * p2 + '░' * (n - p2)
    print(f'  {lv:>20}  {p1:>2}/{n} {p1_bar}  {p2:>2}/{n} {p2_bar}')
print(f'\n  Total time: {time.time() - t_total:.0f}s')
print(f'\n  KEY QUESTION: Where does D=2 break?')
print(f'  KEY QUESTION: Does V16 help for D=16→D=2?')
print(f'  Answers are in the table above and in the plots.')
print(f'\n  Plots saved:')
for lv in LEVEL_NAMES:
    print(f'    test2_p1_{lv}.png  |  test2_p2_{lv}.png')
print('=' * 65)
