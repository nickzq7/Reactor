import os, time
import transformers.utils.import_utils as _iu
_iu.check_torch_load_is_safe = lambda: None
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
_dir = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def banner(text, width=70):
    print(f"\n{'=' * width}")
    print(f'  {text}')
    print(f"{'=' * width}")

def sep(text=''):
    print(f"\n  ── {text} {'─' * (58 - len(text))}")
banner(f'CODE INTELLIGENCE TRANSFER: 350M → 125M   device={device}')
sep('Downloading models')
print('  Loading CodeGen-350M (teacher)...')
tok_big = AutoTokenizer.from_pretrained('Salesforce/codegen-350M-mono')
model_big = AutoModelForCausalLM.from_pretrained('Salesforce/codegen-350M-mono', use_safetensors=True).to(device).eval()
print('  Loading GPT-Neo-125M (student)...')
tok_small = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
tok_small.pad_token = tok_small.eos_token
model_small = AutoModelForCausalLM.from_pretrained('EleutherAI/gpt-neo-125M', use_safetensors=True).to(device)
D_big = model_big.config.n_embd
D_small = model_small.config.hidden_size
VS_big = model_big.config.vocab_size
VS_sml = model_small.config.vocab_size
p_big = sum((p.numel() for p in model_big.parameters()))
p_small = sum((p.numel() for p in model_small.parameters()))
print(f'\n  Teacher 350M : D={D_big}   params={p_big:>12,}   VS={VS_big}')
print(f'  Student 125M : D={D_small}   params={p_small:>12,}   VS={VS_sml}')
print(f'  Compression  : {p_big / p_small:.1f}x fewer params in student')
if VS_big != VS_sml:
    print(f'\n  ⚠ VOCAB MISMATCH: {VS_big} vs {VS_sml}')
    print(f'  Will align to smaller vocab ({min(VS_big, VS_sml)}) for transfer.')
EASY = ['def add(a, b):\n    ', 'def is_even(n):\n    ', 'def reverse_string(s):\n    ', 'def factorial(n):\n    ', 'def max_of_list(lst):\n    ']
HARD = ['def binary_search(arr, target):\n    # Returns index of target in sorted arr, -1 if not found\n    ', 'def is_palindrome(s):\n    # Returns True if s is palindrome ignoring case and spaces\n    ', 'def flatten_list(nested):\n    # Recursively flatten a nested list\n    ', 'class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, item):\n        ', 'def two_sum(nums, target):\n    # Return indices of two numbers that add up to target\n    # Use O(n) solution\n    ', 'def safe_divide(a, b):\n    # Handle division by zero gracefully\n    ', 'def read_json_file(filepath):\n    # Read and parse JSON, handle file not found and invalid JSON\n    ', 'def fibonacci(n):\n    # Return nth fibonacci number using recursion with memoization\n    ', 'def merge_sort(arr):\n    # Sort array using merge sort algorithm\n    if len(arr) <= 1:\n        return arr\n    ', 'def count_words(text):\n    # Count frequency of each word, return sorted dict by frequency\n    ', 'def validate_email(email):\n    # Basic email validation without regex\n    ', 'class BankAccount:\n    def __init__(self, owner, balance=0):\n        self.owner = owner\n        self.balance = balance\n    def deposit(self, amount):\n        ']
ALL_PROMPTS = EASY + HARD

def generate(model, tokenizer, prompt, max_new=120):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, temperature=1.0, repetition_penalty=1.1, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def code_quality(prompt, output):
    gen = output[len(prompt):]
    lines = [l for l in gen.split('\n') if l.strip()]
    words = gen.split()
    uniq = len(set(words))
    n = max(len(words), 1)
    good_tokens = ['return', 'if', 'else', 'for', 'while', 'try', 'except', 'def', 'class', ':', '=', 'None', 'True', 'False']
    good_count = sum((1 for t in good_tokens if t in gen))
    good_score = min(good_count / 6, 1.0)
    diversity = uniq / n
    length_score = min(len(lines) / 8, 1.0)
    score = round(good_score * 0.5 + diversity * 0.3 + length_score * 0.2, 3)
    return (score, len(lines), good_count)

def run_all(model, tokenizer, label):
    banner(label)
    easy_total = 0
    hard_total = 0
    results = []
    for i, prompt in enumerate(ALL_PROMPTS):
        tag = 'EASY' if i < len(EASY) else 'HARD'
        out = generate(model, tokenizer, prompt, max_new=120)
        q, lines, good = code_quality(prompt, out)
        gen = out[len(prompt):].replace('\n', ' ↵ ')
        if tag == 'EASY':
            easy_total += q
        else:
            hard_total += q
        results.append((prompt, out, q, tag))
        bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
        print(f'\n  [{tag}][{i + 1:>2}] {bar} Q={q:.2f}  good_tokens={good}')
        print(f"   PROMPT: {prompt[:60].replace(chr(10), ' ')}")
        print(f'   OUTPUT: {gen[:120]}')
    easy_avg = easy_total / len(EASY)
    hard_avg = hard_total / len(HARD)
    print(f'\n  ┌─────────────────────────────────┐')
    print(f'  │  Easy avg : {easy_avg:.3f}                │')
    print(f'  │  Hard avg : {hard_avg:.3f}                │')
    print(f'  │  Overall  : {(easy_total + hard_total) / len(ALL_PROMPTS):.3f}                │')
    print(f'  └─────────────────────────────────┘')
    return (results, easy_avg, hard_avg)

def v16_transfer(wte_big, wte_small, k=3):
    P = np.linalg.lstsq(wte_big, wte_small, rcond=None)[0]
    wte_proj = wte_big @ P
    wte_blend = 0.5 * wte_small + 0.5 * wte_proj
    agree_d = np.sum(wte_small * wte_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    wte_child = wte_blend.copy()
    wte_child[:, flip_dims] *= -1
    return (wte_child, flip_dims, agree_d)
PYTHON_SNIPPETS = ['def add(a, b):\n    return a + b\n\ndef subtract(a, b):\n    return a - b\n', 'def factorial(n):\n    if n == 0:\n        return 1\n    return n * factorial(n-1)\n', 'def reverse(s):\n    return s[::-1]\n\ndef is_palindrome(s):\n    return s == s[::-1]\n', 'class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, x):\n        self.items.append(x)\n    def pop(self):\n        return self.items.pop()\n', 'def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    while lo <= hi:\n        mid = (lo+hi)//2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid+1\n        else: hi = mid-1\n    return -1\n', 'def merge_sort(arr):\n    if len(arr) <= 1:\n        return arr\n    mid = len(arr)//2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    return merge(left, right)\n', 'def two_sum(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        if target-n in seen:\n            return [seen[target-n], i]\n        seen[n] = i\n    return []\n', 'def flatten(lst):\n    result = []\n    for item in lst:\n        if isinstance(item, list):\n            result.extend(flatten(item))\n        else:\n            result.append(item)\n    return result\n', 'def count_words(text):\n    words = text.lower().split()\n    counts = {}\n    for w in words:\n        counts[w] = counts.get(w, 0) + 1\n    return dict(sorted(counts.items(), key=lambda x: -x[1]))\n', 'def safe_divide(a, b):\n    try:\n        return a / b\n    except ZeroDivisionError:\n        return None\n', 'def fibonacci(n, memo={}):\n    if n in memo: return memo[n]\n    if n <= 1: return n\n    memo[n] = fibonacci(n-1, memo) + fibonacci(n-2, memo)\n    return memo[n]\n', 'class BankAccount:\n    def __init__(self, owner):\n        self.owner = owner\n        self.balance = 0\n    def deposit(self, amount):\n        if amount > 0:\n            self.balance += amount\n    def withdraw(self, amount):\n        if amount <= self.balance:\n            self.balance -= amount\n'] * 60

class CodeDataset(Dataset):

    def __init__(self, snippets, tok, maxlen=128):
        self.data = []
        for s in snippets:
            enc = tok(s, truncation=True, max_length=maxlen, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
results_big, easy_big, hard_big = run_all(model_big, tok_big, 'TEACHER — CodeGen-350M')
results_before, easy_bef, hard_bef = run_all(model_small, tok_small, 'STUDENT BEFORE — GPT-Neo-125M (original)')
banner('APPLYING V16 TRANSFER  (350M → 125M)')
WTE_big = model_big.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
WTE_small = model_small.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
VS_use = min(WTE_big.shape[0], WTE_small.shape[0])
WTE_big_a = WTE_big[:VS_use]
WTE_small_a = WTE_small[:VS_use]
print(f'  Teacher WTE : {WTE_big.shape}   D={D_big}')
print(f'  Student WTE : {WTE_small.shape}  D={D_small}')
print(f'  Using vocab : {VS_use} tokens for transfer\n')
WTE_child, flip_dims, agree_d = v16_transfer(WTE_big_a, WTE_small_a, k=3)
print(f'  Agreement range : {agree_d.min():.2f} → {agree_d.max():.2f}')
print(f'  All constructive: {np.all(agree_d > 0)}')
print(f'  Flipped dims    : {flip_dims.tolist()}')
with torch.no_grad():
    model_small.transformer.wte.weight[:VS_use].copy_(torch.tensor(WTE_child, dtype=torch.float32).to(device))
print('\n  ✓ CodeGen-350M WTE geometry injected into GPT-Neo-125M.')
model_big.cpu()
torch.cuda.empty_cache()
print('  ✓ Teacher moved to CPU. GPU freed.')
banner('FINE-TUNING 125M  (15 epochs, WTE frozen, best checkpoint saved)')
print('  WTE frozen. Attention + FFN adapt to 350M code geometry.')
model_small.transformer.wte.weight.requires_grad_(False)
code_texts = ['def add(a, b):\n    return a + b\n', 'def subtract(a, b):\n    return a - b\n', 'def multiply(a, b):\n    return a * b\n', 'def divide(a, b):\n    if b == 0: return None\n    return a / b\n', 'def power(base, exp):\n    return base ** exp\n', 'def is_even(n):\n    return n % 2 == 0\n', 'def is_odd(n):\n    return n % 2 != 0\n', 'def absolute(n):\n    return n if n >= 0 else -n\n', 'def square(n):\n    return n * n\n', 'def cube(n):\n    return n ** 3\n', 'def reverse_string(s):\n    return s[::-1]\n', "def capitalize_words(s):\n    return ' '.join(w.capitalize() for w in s.split())\n", "def count_vowels(s):\n    return sum(1 for c in s.lower() if c in 'aeiou')\n", "def remove_spaces(s):\n    return s.replace(' ', '')\n", "def is_palindrome(s):\n    s = s.lower().replace(' ', '')\n    return s == s[::-1]\n", 'def repeat_string(s, n):\n    return s * n\n', 'def first_n_chars(s, n):\n    return s[:n]\n', 'def last_n_chars(s, n):\n    return s[-n:]\n', 'def string_to_list(s):\n    return list(s)\n', "def join_list(lst, sep=''):\n    return sep.join(lst)\n", 'def factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n - 1)\n', 'def fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)\n', 'def gcd(a, b):\n    while b:\n        a, b = b, a % b\n    return a\n', 'def lcm(a, b):\n    return a * b // gcd(a, b)\n', 'def is_prime(n):\n    if n < 2: return False\n    for i in range(2, int(n**0.5)+1):\n        if n % i == 0: return False\n    return True\n', 'def primes_up_to(n):\n    return [i for i in range(2, n+1) if is_prime(i)]\n', 'def sum_list(lst):\n    return sum(lst)\n', 'def max_list(lst):\n    return max(lst)\n', 'def min_list(lst):\n    return min(lst)\n', 'def average(lst):\n    return sum(lst) / len(lst) if lst else 0\n', 'def flatten(lst):\n    result = []\n    for item in lst:\n        if isinstance(item, list): result.extend(flatten(item))\n        else: result.append(item)\n    return result\n', 'def unique(lst):\n    return list(set(lst))\n', 'def remove_duplicates(lst):\n    seen = set()\n    return [x for x in lst if not (x in seen or seen.add(x))]\n', 'def chunk_list(lst, n):\n    return [lst[i:i+n] for i in range(0, len(lst), n)]\n', 'def zip_lists(a, b):\n    return list(zip(a, b))\n', 'def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    while lo <= hi:\n        mid = (lo+hi)//2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid+1\n        else: hi = mid-1\n    return -1\n', 'def bubble_sort(arr):\n    n = len(arr)\n    for i in range(n):\n        for j in range(0, n-i-1):\n            if arr[j] > arr[j+1]: arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n', 'def insertion_sort(arr):\n    for i in range(1, len(arr)):\n        key = arr[i]\n        j = i - 1\n        while j >= 0 and arr[j] > key:\n            arr[j+1] = arr[j]; j -= 1\n        arr[j+1] = key\n    return arr\n', 'def merge_sort(arr):\n    if len(arr) <= 1: return arr\n    mid = len(arr)//2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    return merge(left, right)\n', 'def two_sum(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        if target - n in seen: return [seen[target-n], i]\n        seen[n] = i\n    return []\n', 'class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, x): self.items.append(x)\n    def pop(self): return self.items.pop() if self.items else None\n    def peek(self): return self.items[-1] if self.items else None\n    def is_empty(self): return len(self.items) == 0\n', 'class Queue:\n    def __init__(self):\n        self.items = []\n    def enqueue(self, x): self.items.append(x)\n    def dequeue(self): return self.items.pop(0) if self.items else None\n    def is_empty(self): return len(self.items) == 0\n', 'class Node:\n    def __init__(self, val):\n        self.val = val\n        self.next = None\n', 'class LinkedList:\n    def __init__(self):\n        self.head = None\n    def append(self, val):\n        node = Node(val)\n        if not self.head: self.head = node; return\n        cur = self.head\n        while cur.next: cur = cur.next\n        cur.next = node\n', 'def safe_divide(a, b):\n    try:\n        return a / b\n    except ZeroDivisionError:\n        return None\n', 'def safe_int(s):\n    try:\n        return int(s)\n    except (ValueError, TypeError):\n        return None\n', 'def read_file(path):\n    try:\n        with open(path) as f: return f.read()\n    except FileNotFoundError:\n        return None\n', "def write_file(path, content):\n    try:\n        with open(path, 'w') as f: f.write(content)\n        return True\n    except IOError:\n        return False\n", 'def read_json(path):\n    import json\n    try:\n        with open(path) as f: return json.load(f)\n    except (FileNotFoundError, json.JSONDecodeError):\n        return None\n', "def write_json(path, data):\n    import json\n    with open(path, 'w') as f:\n        json.dump(data, f, indent=2)\n", 'def fibonacci_memo(n, memo={}):\n    if n in memo: return memo[n]\n    if n <= 1: return n\n    memo[n] = fibonacci_memo(n-1, memo) + fibonacci_memo(n-2, memo)\n    return memo[n]\n', 'def count_words(text):\n    words = text.lower().split()\n    counts = {}\n    for w in words: counts[w] = counts.get(w, 0) + 1\n    return dict(sorted(counts.items(), key=lambda x: -x[1]))\n', 'def most_common(lst):\n    return max(set(lst), key=lst.count)\n', 'def rotate_list(lst, k):\n    k = k % len(lst)\n    return lst[k:] + lst[:k]\n', 'def matrix_transpose(matrix):\n    return [[row[i] for row in matrix] for i in range(len(matrix[0]))]\n', 'def dot_product(a, b):\n    return sum(x*y for x, y in zip(a, b))\n', "class BankAccount:\n    def __init__(self, owner, balance=0):\n        self.owner = owner\n        self.balance = balance\n    def deposit(self, amount):\n        if amount > 0: self.balance += amount\n    def withdraw(self, amount):\n        if 0 < amount <= self.balance: self.balance -= amount; return True\n        return False\n    def __repr__(self): return f'BankAccount({self.owner}, {self.balance})'\n", 'class Circle:\n    import math\n    def __init__(self, r): self.r = r\n    def area(self): return 3.14159 * self.r ** 2\n    def perimeter(self): return 2 * 3.14159 * self.r\n', 'class Rectangle:\n    def __init__(self, w, h): self.w = w; self.h = h\n    def area(self): return self.w * self.h\n    def perimeter(self): return 2 * (self.w + self.h)\n', 'def celsius_to_fahrenheit(c):\n    return c * 9/5 + 32\n', 'def fahrenheit_to_celsius(f):\n    return (f - 32) * 5/9\n', 'def is_leap_year(year):\n    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)\n', 'def days_in_month(month, year):\n    days = [31,28,31,30,31,30,31,31,30,31,30,31]\n    if month == 2 and is_leap_year(year): return 29\n    return days[month-1]\n', "def validate_email(email):\n    if '@' not in email: return False\n    parts = email.split('@')\n    if len(parts) != 2: return False\n    return '.' in parts[1]\n", "def slugify(text):\n    return text.lower().replace(' ', '-').strip()\n", "def truncate(text, max_len, suffix='...'):\n    if len(text) <= max_len: return text\n    return text[:max_len-len(suffix)] + suffix\n", 'def deep_copy_dict(d):\n    import copy\n    return copy.deepcopy(d)\n', 'def merge_dicts(*dicts):\n    result = {}\n    for d in dicts: result.update(d)\n    return result\n', 'def invert_dict(d):\n    return {v: k for k, v in d.items()}\n', 'def group_by(lst, key_fn):\n    groups = {}\n    for item in lst:\n        k = key_fn(item)\n        groups.setdefault(k, []).append(item)\n    return groups\n', 'def running_average(nums):\n    total = 0\n    result = []\n    for i, n in enumerate(nums):\n        total += n\n        result.append(total / (i+1))\n    return result\n', 'def clamp(value, min_val, max_val):\n    return max(min_val, min(max_val, value))\n', 'def is_sorted(lst):\n    return all(lst[i] <= lst[i+1] for i in range(len(lst)-1))\n', 'def nth_largest(lst, n):\n    return sorted(lst, reverse=True)[n-1]\n', 'def dedupe_preserve_order(lst):\n    seen = set()\n    return [x for x in lst if not (x in seen or seen.add(x))]\n']
print(f'  Loaded {len(code_texts)} built-in Python snippets (diverse, no download needed).')
dataset = CodeDataset(code_texts * 20, tok_small, maxlen=128)
loader = DataLoader(dataset, batch_size=8, shuffle=True)
opt = torch.optim.AdamW([p for p in model_small.parameters() if p.requires_grad], lr=5e-05)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=15, eta_min=1e-06)
WATCH_EASY = 'def is_even(n):\n    '
WATCH_HARD = 'def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    '
print(f'  Easy watch: {repr(WATCH_EASY)}')
print(f'  Hard watch: {repr(WATCH_HARD[:50])}\n')
print(f"  {'Ep':>3}  {'Loss':>8}  {'EasyQ':>6}  {'HardQ':>6}  {'Best':>5}  Hard output preview")
print(f"  {'─' * 78}")
epoch_log = []
best_score = -1
best_state = None
EPOCHS = 15
for epoch in range(1, EPOCHS + 1):
    model_small.train()
    total = 0
    steps = 0
    for batch in loader:
        batch = batch.to(device)
        out = model_small(batch, labels=batch)
        opt.zero_grad()
        out.loss.backward()
        nn.utils.clip_grad_norm_(model_small.parameters(), 1.0)
        opt.step()
        total += out.loss.item()
        steps += 1
    sched.step()
    avg_loss = total / steps
    easy_out = generate(model_small, tok_small, WATCH_EASY, max_new=40)
    hard_out = generate(model_small, tok_small, WATCH_HARD, max_new=60)
    eq, _, _ = code_quality(WATCH_EASY, easy_out)
    hq, _, _ = code_quality(WATCH_HARD, hard_out)
    combined = eq * 0.4 + hq * 0.6
    hard_gen = hard_out[len(WATCH_HARD):].replace('\n', ' ↵ ')
    bar = '█' * int(hq * 10) + '░' * (10 - int(hq * 10))
    is_best = combined > best_score
    if is_best:
        best_score = combined
        best_state = {k: v.clone().cpu() for k, v in model_small.state_dict().items()}
        star = ' ← BEST'
    else:
        star = ''
    print(f'  {epoch:>3}  {avg_loss:>8.4f}  {eq:>6.2f}  {hq:>6.2f}  {combined:>5.2f}{star}')
    print(f'       Hard → {hard_gen[:75]}\n')
    epoch_log.append((epoch, avg_loss, eq, hq, combined, is_best))
print(f'\n  ✓ Restoring best checkpoint (score={best_score:.3f})...')
model_small.load_state_dict(best_state)
print('  ✓ Fine-tuning complete.')
results_after, easy_aft, hard_aft = run_all(model_small, tok_small, 'STUDENT AFTER — GPT-Neo-125M (V16 + fine-tuned)')
banner('FINAL COMPARISON')
print(f"\n  {'Model':>32}  {'Params':>12}  {'Easy':>6}  {'Hard':>6}")
print(f"  {'─' * 62}")
print(f"  {'Teacher  CodeGen-350M':>32}  {p_big:>12,}  {easy_big:>6.3f}  {hard_big:>6.3f}")
print(f"  {'Student 125M  BEFORE':>32}  {p_small:>12,}  {easy_bef:>6.3f}  {hard_bef:>6.3f}")
print(f"  {'Student 125M  AFTER':>32}  {p_small:>12,}  {easy_aft:>6.3f}  {hard_aft:>6.3f}")
print(f'\n  Transfer gain → Easy: {easy_aft - easy_bef:>+.3f}   Hard: {hard_aft - hard_bef:>+.3f}')
print(f'  Compression   → {p_big:,} → {p_small:,}  ({p_big / p_small:.1f}x)')
print(f'\n  Learning curve:')
print(f"  {'Ep':>3}  {'Loss':>8}  {'EasyQ':>6}  {'HardQ':>6}  Bar (hard)")
print(f"  {'─' * 52}")
for ep, loss, eq, hq, combined, is_best in epoch_log:
    best_tag = ' ★' if is_best else ''
    print(f"  {ep:>3}  {loss:>8.4f}  {eq:>6.2f}  {hq:>6.2f}  {'█' * int(hq * 20)}{best_tag}")
print(f'\n  HARD PROMPT SIDE BY SIDE:')
print(f"  {'─' * 70}")
for i, prompt in enumerate(HARD):
    idx = len(EASY) + i
    t = results_big[idx][1][len(prompt):].replace('\n', ' ↵ ')[:80]
    bef = results_before[idx][1][len(prompt):].replace('\n', ' ↵ ')[:80]
    aft = results_after[idx][1][len(prompt):].replace('\n', ' ↵ ')[:80]
    q_t = results_big[idx][2]
    q_bef = results_before[idx][2]
    q_aft = results_after[idx][2]
    print(f"\n  [{i + 1}] {prompt[:55].replace(chr(10), ' ')}")
    print(f'  350M  (Q={q_t:.2f}): {t}')
    print(f'  Before(Q={q_bef:.2f}): {bef}')
    print(f'  After (Q={q_aft:.2f}): {aft}')
save_path = os.path.join(_dir, 'pycodegpt_after_transfer')
model_small.save_pretrained(save_path)
tok_small.save_pretrained(save_path)
print(f'\n\n  ✓ Saved to: {save_path}')
banner('DONE')
