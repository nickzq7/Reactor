import numpy as np
import json
import math
print('\n' + '=' * 70)
print('  W-HASH STEP 3 — KERNEL + GEOMETRIC FINGERPRINT')
print('  Train kernel via laws. Hash both. Find the gap.')
print('=' * 70)
W_npz = np.load('tiny_transformer_weights.npz')
with open('tiny_transformer_meta.json') as f:
    meta = json.load(f)
w2i = meta['w2i']
i2w = {int(k): v for k, v in meta['i2w'].items()}
VS, D, H = (meta['VS'], meta['D'], meta['H'])
NL, K, FFN = (meta['NL'], meta['K'], meta['FFN'])
TEXT = meta['text']
head_dim = D // H
print(f'\n  VS={VS} D={D} H={H} NL={NL} K={K} FFN={FFN}')
WTE = W_npz['WTE'].astype(np.float64)
WPE = W_npz['WPE'].astype(np.float64)
LNfg = W_npz['LNfg'].astype(np.float64)
LNfb = W_npz['LNfb'].astype(np.float64)
T_layers = []
for l in range(NL):
    T_layers.append({'WQ': W_npz[f'WQ{l}'].astype(np.float64), 'WK': W_npz[f'WK{l}'].astype(np.float64), 'WV': W_npz[f'WV{l}'].astype(np.float64), 'WO': W_npz[f'WO{l}'].astype(np.float64), 'W1': W_npz[f'W1{l}'].astype(np.float64), 'b1': W_npz[f'b1{l}'].astype(np.float64), 'W2': W_npz[f'W2{l}'].astype(np.float64), 'b2': W_npz[f'b2{l}'].astype(np.float64), 'LN1g': W_npz[f'LN1g{l}'].astype(np.float64), 'LN1b': W_npz[f'LN1b{l}'].astype(np.float64), 'LN2g': W_npz[f'LN2g{l}'].astype(np.float64), 'LN2b': W_npz[f'LN2b{l}'].astype(np.float64)})

def ln(x, gamma, beta, eps=1e-05):
    mean = x.mean(axis=-1, keepdims=True)
    var = ((x - mean) ** 2).mean(axis=-1, keepdims=True)
    return (x - mean) / np.sqrt(var + eps) * gamma + beta

def ln_ns(x, eps=1e-05):
    mean = x.mean(axis=-1, keepdims=True)
    var = ((x - mean) ** 2).mean(axis=-1, keepdims=True)
    return (x - mean) / np.sqrt(var + eps)

def gelu(x):
    c = math.sqrt(2.0 / math.pi)
    return 0.5 * x * (1.0 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)

def solve(X, Y, bias=True):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    W, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)
    return W

def apply_W(W, X, bias=True):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    return X @ W

def r2(pred, true):
    ss_res = np.mean((pred.ravel() - true.ravel()) ** 2)
    ss_tot = np.var(true.ravel())
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0
words = TEXT.split()
toks = [w2i[w] for w in words]
M = len(toks) - K
X_ids = np.array([toks[i:i + K] for i in range(M)])
y_ids = np.array([toks[i + 1:i + K + 1] for i in range(M)])

def transformer_forward(seq_ids, collect=False):
    seq_len = len(seq_ids)
    x = WTE[seq_ids] + WPE[np.arange(seq_len)]
    acts = [] if collect else None
    for l in range(NL):
        lw = T_layers[l]
        ln1_out = ln(x, lw['LN1g'], lw['LN1b'])
        Q = ln1_out @ lw['WQ'].T
        K_ = ln1_out @ lw['WK'].T
        V = ln1_out @ lw['WV'].T
        Q_h = Q.reshape(seq_len, H, head_dim).transpose(1, 0, 2)
        K_h = K_.reshape(seq_len, H, head_dim).transpose(1, 0, 2)
        V_h = V.reshape(seq_len, H, head_dim).transpose(1, 0, 2)
        scale = 1.0 / math.sqrt(head_dim)
        mask = np.triu(np.full((seq_len, seq_len), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            probs = softmax(Q_h[h] @ K_h[h].T * scale + mask)
            heads.append(probs @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(seq_len, D)
        att_out = ctx @ lw['WO'].T
        h_mid = x + att_out
        ln2_out = ln(h_mid, lw['LN2g'], lw['LN2b'])
        pre_gelu = ln2_out @ lw['W1'].T + lw['b1']
        gelu_out = gelu(pre_gelu)
        ffn_out = gelu_out @ lw['W2'].T + lw['b2']
        x = h_mid + ffn_out
        if collect:
            acts.append({'h_in': h_mid - ffn_out - att_out, 'ln1_ns': ln_ns(h_mid - ffn_out - att_out), 'ln1_out': ln1_out, 'Q': Q, 'K': K_, 'V': V, 'ctx': ctx, 'att_out': att_out, 'h_mid': h_mid, 'ln2_ns': ln_ns(h_mid), 'ln2_out': ln2_out, 'pre_gelu': pre_gelu, 'pre_gelu_ns': np.c_[pre_gelu, pre_gelu ** 2], 'gelu_out': gelu_out, 'ffn_out': ffn_out, 'h_out': x})
    lnf_out = ln(x, LNfg, LNfb)
    logits = lnf_out @ WTE.T
    if collect:
        return (logits, acts, x, lnf_out)
    return logits
print('\n  Collecting transformer activations...')
all_acts = {l: {k: [] for k in ['h_in', 'ln1_ns', 'ln1_out', 'Q', 'K', 'V', 'ctx', 'att_out', 'h_mid', 'ln2_ns', 'ln2_out', 'pre_gelu', 'pre_gelu_ns', 'gelu_out', 'ffn_out', 'h_out']} for l in range(NL)}
all_lnf_ns = []
all_lnf_out = []
all_logits = []
correct_t = 0
for i in range(M):
    logits, acts, x_final, lnf_out = transformer_forward(X_ids[i].tolist(), collect=True)
    preds = np.argmax(logits, axis=-1)
    correct_t += int((preds == y_ids[i]).sum())
    for l in range(NL):
        for k in all_acts[l]:
            all_acts[l][k].append(acts[l][k])
    all_lnf_ns.append(ln_ns(x_final))
    all_lnf_out.append(lnf_out)
    all_logits.append(logits)
acc_t = 100.0 * correct_t / (M * K)
print(f'  Transformer accuracy: {acc_t:.1f}%')
for l in range(NL):
    for k in all_acts[l]:
        all_acts[l][k] = np.concatenate(all_acts[l][k], axis=0)
all_lnf_ns = np.concatenate(all_lnf_ns, axis=0)
all_lnf_out = np.concatenate(all_lnf_out, axis=0)
all_logits = np.concatenate(all_logits, axis=0)
N = len(all_acts[0]['h_in'])
print(f'  Samples: {N}')
print('\n' + '=' * 70)
print('  KERNEL TRAINING — O(1) via W-Principle Laws')
print('  No transformer. No gradient. Pure lstsq per law.')
print('=' * 70)
K_layers = []
for l in range(NL):
    s = all_acts[l]
    print(f'\n  Layer {l} — solving W matrices...')
    W_ln1 = solve(s['ln1_ns'], s['ln1_out'], bias=True)
    r = r2(apply_W(W_ln1, s['ln1_ns']), s['ln1_out'])
    print(f'    W_ln1  R²={r:.6f}')
    W_q = solve(s['ln1_out'], s['Q'], bias=False)
    W_k = solve(s['ln1_out'], s['K'], bias=False)
    W_v = solve(s['ln1_out'], s['V'], bias=False)
    rq = r2(s['ln1_out'] @ W_q, s['Q'])
    rk = r2(s['ln1_out'] @ W_k, s['K'])
    rv = r2(s['ln1_out'] @ W_v, s['V'])
    print(f'    W_q    R²={rq:.6f}  W_k R²={rk:.6f}  W_v R²={rv:.6f}')
    W_o = solve(s['ctx'], s['att_out'], bias=False)
    ro = r2(s['ctx'] @ W_o, s['att_out'])
    print(f'    W_o    R²={ro:.6f}')
    W_ln2 = solve(s['ln2_ns'], s['ln2_out'], bias=True)
    r2ln2 = r2(apply_W(W_ln2, s['ln2_ns']), s['ln2_out'])
    print(f'    W_ln2  R²={r2ln2:.6f}')
    W1 = solve(s['ln2_out'], s['pre_gelu'], bias=True)
    r1 = r2(apply_W(W1, s['ln2_out']), s['pre_gelu'])
    print(f'    W1     R²={r1:.6f}')
    W_gelu = solve(s['pre_gelu_ns'], s['gelu_out'], bias=False)
    rg = r2(s['pre_gelu_ns'] @ W_gelu, s['gelu_out'])
    print(f'    W_gelu R²={rg:.6f}  (natural space: x,x²)')
    W2 = solve(s['gelu_out'], s['ffn_out'], bias=True)
    r2w = r2(apply_W(W2, s['gelu_out']), s['ffn_out'])
    print(f'    W2     R²={r2w:.6f}')
    K_layers.append({'W_ln1': W_ln1, 'W_q': W_q, 'W_k': W_k, 'W_v': W_v, 'W_o': W_o, 'W_ln2': W_ln2, 'W1': W1, 'W_gelu': W_gelu, 'W2': W2})
print(f'\n  Global laws...')
W_lnf = solve(all_lnf_ns, all_lnf_out, bias=True)
r_lnf = r2(apply_W(W_lnf, all_lnf_ns), all_lnf_out)
print(f'    W_lnf  R²={r_lnf:.6f}')
W_lmh = solve(all_lnf_out, all_logits, bias=False)
r_lmh = r2(all_lnf_out @ W_lmh, all_logits)
print(f'    W_lmh  R²={r_lmh:.6f}')
K_global = {'W_lnf': W_lnf, 'W_lmh': W_lmh}

def kernel_forward(seq_ids):
    seq_len = len(seq_ids)
    x = WTE[seq_ids] + WPE[np.arange(seq_len)]
    for l in range(NL):
        kw = K_layers[l]
        ln1_out = apply_W(kw['W_ln1'], ln_ns(x))
        Q = ln1_out @ kw['W_q']
        K_ = ln1_out @ kw['W_k']
        V = ln1_out @ kw['W_v']
        Q_h = Q.reshape(seq_len, H, head_dim).transpose(1, 0, 2)
        K_h = K_.reshape(seq_len, H, head_dim).transpose(1, 0, 2)
        V_h = V.reshape(seq_len, H, head_dim).transpose(1, 0, 2)
        scale = 1.0 / math.sqrt(head_dim)
        mask = np.triu(np.full((seq_len, seq_len), -1000000000.0), k=1)
        heads = []
        for h in range(H):
            probs = softmax(Q_h[h] @ K_h[h].T * scale + mask)
            heads.append(probs @ V_h[h])
        ctx = np.stack(heads, axis=1).reshape(seq_len, D)
        att_out = ctx @ kw['W_o']
        h_mid = x + att_out
        ln2_out = apply_W(kw['W_ln2'], ln_ns(h_mid))
        pre_gelu = apply_W(kw['W1'], ln2_out)
        gelu_out = gelu(pre_gelu)
        ffn_out = apply_W(kw['W2'], gelu_out)
        x = h_mid + ffn_out
    lnf_out = apply_W(K_global['W_lnf'], ln_ns(x))
    logits = lnf_out @ K_global['W_lmh']
    return logits
correct_k = 0
for i in range(M):
    logits = kernel_forward(X_ids[i].tolist())
    preds = np.argmax(logits, axis=-1)
    correct_k += int((preds == y_ids[i]).sum())
acc_k = 100.0 * correct_k / (M * K)
print(f'\n  Kernel accuracy: {acc_k:.1f}%')
print('\n' + '=' * 70)
print('  W-HASH — GEOMETRIC FINGERPRINT')
print('  Comparing transformer vs kernel W-space geometry')
print('=' * 70)

def w_hash(mat, name):
    M2 = np.array(mat, dtype=np.float64)
    if M2.ndim == 2:
        core = M2[:-1] if M2.shape[0] > M2.shape[1] else M2
    else:
        return {}
    try:
        U, S, Vt = np.linalg.svd(core, full_matrices=False)
    except:
        return {}
    frob = float(np.linalg.norm(core, 'fro'))
    nuclear = float(np.sum(S))
    spec = float(S[0])
    s_norm = S / (S[0] + 1e-12)
    eff_rank = float(np.exp(-np.sum(s_norm * np.log(s_norm + 1e-12))))
    cond = float(S[0] / (S[-1] + 1e-12))
    return {'S': S, 'frob': frob, 'nuclear': nuclear, 'spectral': spec, 'eff_rank': eff_rank, 'cond': cond, 'shape': core.shape}

def hash_gap(h_t, h_k, name):
    if not h_t or not h_k:
        return {}
    S_t, S_k = (h_t['S'], h_k['S'])
    min_len = min(len(S_t), len(S_k))
    sv_gap = float(np.mean(np.abs(S_t[:min_len] - S_k[:min_len])))
    sv_rel = sv_gap / (float(np.mean(S_t[:min_len])) + 1e-12)
    frob_gap = abs(h_t['frob'] - h_k['frob'])
    rank_gap = abs(h_t['eff_rank'] - h_k['eff_rank'])
    cond_gap = abs(h_t['cond'] - h_k['cond'])
    return {'sv_gap': sv_gap, 'sv_rel_pct': sv_rel * 100, 'frob_gap': frob_gap, 'rank_gap': rank_gap, 'cond_gap': cond_gap, 'frob_T': h_t['frob'], 'frob_K': h_k['frob'], 'eff_rank_T': h_t['eff_rank'], 'eff_rank_K': h_k['eff_rank'], 'spectral_T': h_t['spectral'], 'spectral_K': h_k['spectral']}
print(f"\n  {'Layer':<8} {'Matrix':<12} {'Frob_T':>9} {'Frob_K':>9} {'SV_gap%':>9} {'EffRank_T':>11} {'EffRank_K':>11} {'Diagnosis'}")
print(f"  {'─' * 100}")
total_gap = []
for l in range(NL):
    lw = T_layers[l]
    kw = K_layers[l]
    pairs = [('WQ', lw['WQ'].T, kw['W_q']), ('WK', lw['WK'].T, kw['W_k']), ('WV', lw['WV'].T, kw['W_v']), ('WO', lw['WO'].T, kw['W_o']), ('W1', np.c_[lw['W1'].T, lw['b1']].T if False else lw['W1'].T, kw['W1'][:-1]), ('W2', lw['W2'].T, kw['W2'][:-1])]
    for name, W_t, W_k in pairs:
        h_t = w_hash(W_t, name)
        h_k = w_hash(W_k, name)
        if not h_t or not h_k:
            continue
        g = hash_gap(h_t, h_k, name)
        sv_pct = g['sv_rel_pct']
        total_gap.append(sv_pct)
        if sv_pct < 1.0:
            diag = '✓ IDENTICAL'
        elif sv_pct < 5.0:
            diag = '~ CLOSE'
        elif sv_pct < 20.0:
            diag = '△ GAP'
        else:
            diag = '✗ DIVERGED'
        print(f"  L{l:<7} {name:<12} {g['frob_T']:>9.3f} {g['frob_K']:>9.3f} {sv_pct:>8.2f}% {g['eff_rank_T']:>11.2f} {g['eff_rank_K']:>11.2f}  {diag}")
print(f"  {'─' * 100}")
mean_gap = float(np.mean(total_gap))
max_gap = float(np.max(total_gap))
print(f'\n  Mean SV gap: {mean_gap:.2f}%   Max SV gap: {max_gap:.2f}%')
print(f'\n  LAYER-WISE TOTAL GEOMETRIC DISTANCE')
print(f"  {'─' * 50}")
for l in range(NL):
    lw = T_layers[l]
    kw = K_layers[l]
    d_q = np.linalg.norm(lw['WQ'].T - kw['W_q'], 'fro')
    d_k = np.linalg.norm(lw['WK'].T - kw['W_k'], 'fro')
    d_v = np.linalg.norm(lw['WV'].T - kw['W_v'], 'fro')
    d_o = np.linalg.norm(lw['WO'].T - kw['W_o'], 'fro')
    d_w1 = np.linalg.norm(lw['W1'].T - kw['W1'][:-1], 'fro')
    d_w2 = np.linalg.norm(lw['W2'].T - kw['W2'][:-1], 'fro')
    total_d = d_q + d_k + d_v + d_o + d_w1 + d_w2
    frob_t = np.linalg.norm(lw['WQ'], 'fro') + np.linalg.norm(lw['WK'], 'fro') + np.linalg.norm(lw['WV'], 'fro') + np.linalg.norm(lw['WO'], 'fro') + np.linalg.norm(lw['W1'], 'fro') + np.linalg.norm(lw['W2'], 'fro')
    pct = 100.0 * total_d / (frob_t + 1e-12)
    bar = '█' * int(pct / 2) + '░' * (50 - int(pct / 2))
    print(f'  Layer {l}: |{bar[:30]}| {pct:.1f}% gap')
    print(f'           WQ={d_q:.3f} WK={d_k:.3f} WV={d_v:.3f} WO={d_o:.3f} W1={d_w1:.3f} W2={d_w2:.3f}')
print(f'\n  SINGULAR VALUE SPECTRUM — WHERE INTELLIGENCE LIVES')
print(f"  {'─' * 65}")
for l in range(NL):
    lw = T_layers[l]
    kw = K_layers[l]
    for mat_name, W_t, W_k in [('WQ', lw['WQ'].T, kw['W_q']), ('W1', lw['W1'].T, kw['W1'][:-1])]:
        _, S_t, _ = np.linalg.svd(W_t, full_matrices=False)
        _, S_k, _ = np.linalg.svd(W_k, full_matrices=False)
        n = min(8, len(S_t), len(S_k))
        print(f'\n  L{l} {mat_name} top-{n} singular values:')
        print(f"    Transformer: {' '.join((f'{v:.3f}' for v in S_t[:n]))}")
        print(f"    Kernel:      {' '.join((f'{v:.3f}' for v in S_k[:n]))}")
        gap = S_t[:n] - S_k[:n]
        print(f"    Gap:         {' '.join((f'{v:+.3f}' for v in gap))}")
        print(f"    Explanation: {('✓ aligned' if np.max(np.abs(gap)) < 0.5 else '△ kernel missing high-freq components')}")
print('\n' + '=' * 70)
print('  ACCURACY SUMMARY')
print('=' * 70)
print(f'\n  Transformer accuracy: {acc_t:.1f}%')
print(f'  Kernel accuracy:      {acc_k:.1f}%')
acc_gap = acc_t - acc_k
print(f'  Accuracy gap:         {acc_gap:.1f}%')
if acc_gap == 0.0:
    print('  → Kernel = Transformer exactly. W-Hash gap is numerical noise.')
elif acc_gap < 5.0:
    print('  → Kernel nearly matches. Gap is in fine-grained singular values.')
elif acc_gap < 20.0:
    print('  → Meaningful gap. Check which layer/matrix has highest SV gap above.')
else:
    print('  → Large gap. Kernel is missing significant structure.')
    print('  → Look at W1/W2 SV spectrum — those carry most of the intelligence.')
print('\n' + '=' * 70)
print('  W-HASH DIAGNOSIS — ROADMAP TO 70B')
print('=' * 70)
print(f'\n  WHAT THE HASH TELLS US:\n\n  1. Where kernel diverges from transformer:\n     → Look at highest SV_gap% rows above\n     → That matrix, that layer = where intelligence is not captured\n\n  2. Why divergence happens:\n     → Transformer was trained by backprop on full distribution\n     → Kernel was trained by lstsq on observed activations only\n     → Missing: rare token combinations, long-range patterns\n     → The SV gap quantifies exactly how much is missing\n\n  3. How to fill the gap:\n     → Add more diverse training sequences → lstsq sees more activation space\n     → The singular values will converge toward transformer values\n     → When SV_gap < 1% on all matrices → kernel = transformer exactly\n\n  4. For 70B model:\n     → Same pipeline: extract W matrices per law\n     → W-Hash gives compression ratio: keep top-K singular values\n     → JPEG analogy: quality slider = how many SVs to keep\n     → 10% SVs → ~10% memory, ~90% intelligence preserved\n     → Run on laptop: load layer by layer, hash, compress, free\n\n  NEXT STEP: Add more training data → watch SV gap shrink toward zero.\n')
print('=' * 70 + '\n')
