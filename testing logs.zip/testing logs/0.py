import numpy as np
import math
import time
import warnings
from numpy.linalg import lstsq, matrix_rank
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
warnings.filterwarnings('ignore')

class CrystalLaws:

    @staticmethod
    def gelu(x: np.ndarray) -> np.ndarray:
        x = x.astype(np.float32)
        return (0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

    @staticmethod
    def natural_gelu(x: np.ndarray) -> np.ndarray:
        return np.concatenate([x, x ** 2], axis=-1).astype(np.float32)

    @staticmethod
    def softmax(x: np.ndarray) -> np.ndarray:
        x = x.astype(np.float32)
        e = np.exp(x - x.max(axis=-1, keepdims=True))
        return (e / e.sum(axis=-1, keepdims=True)).astype(np.float32)

    @staticmethod
    def layernorm(x: np.ndarray, gamma: np.ndarray, beta: np.ndarray, eps: float=1e-05) -> np.ndarray:
        x = x.astype(np.float32)
        mean = x.mean(axis=-1, keepdims=True)
        var = ((x - mean) ** 2).mean(axis=-1, keepdims=True)
        return (gamma * (x - mean) / np.sqrt(var + eps) + beta).astype(np.float32)

    @staticmethod
    def solve(X: np.ndarray, Y: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
        X64 = X.astype(np.float64)
        Y64 = Y.astype(np.float64)
        Xb = np.concatenate([X64, np.ones((len(X64), 1))], axis=1)
        result, _, _, _ = lstsq(Xb, Y64, rcond=None)
        W = result[:-1].T.astype(np.float32)
        b = result[-1].astype(np.float32)
        Y_pred = X64 @ result[:-1] + result[-1]
        ss_res = float(((Y64 - Y_pred) ** 2).sum())
        ss_tot = float(((Y64 - Y64.mean(0)) ** 2).sum())
        r2 = float(1.0 - ss_res / (ss_tot + 1e-12))
        return (W, b, r2)

@dataclass
class ReactorConfig:
    n_layers: int = 8
    hidden_size: int = 64
    n_heads: int = 16
    ffn_size: int = 256
    vocab_size: int = 50257
    max_pos: int = 2048
    window_size: int = 256
    attention_layers: List[str] = field(default_factory=lambda: ['global', 'local'] * 4)
    activation: str = 'gelu_new'
    eps: float = 1e-05

    @property
    def head_dim(self) -> int:
        return self.hidden_size // self.n_heads

    @classmethod
    def from_hf_config(cls, cfg) -> 'ReactorConfig':
        return cls(n_layers=cfg.num_layers, hidden_size=cfg.hidden_size, n_heads=cfg.num_attention_heads, ffn_size=cfg.intermediate_size if hasattr(cfg, 'intermediate_size') else cfg.hidden_size * 4, vocab_size=cfg.vocab_size, max_pos=cfg.max_position_embeddings, window_size=getattr(cfg, 'window_size', 256), attention_layers=getattr(cfg, 'attention_layers', ['global'] * cfg.num_layers), activation=getattr(cfg, 'activation_function', 'gelu_new'))

class Reactor:

    def __init__(self, config: ReactorConfig):
        self.cfg = config
        self.laws = CrystalLaws()
        self.layers = [{} for _ in range(config.n_layers)]
        self.globals = {}
        self.trained = False
        self.solve_stats = {}

    def _layer_forward(self, h: np.ndarray, li: int, kv_cache: Optional[Dict]=None) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        cfg = self.cfg
        w = self.layers[li]
        sl = h.shape[0]
        ln1 = self.laws.layernorm(h, w['ln1_g'], w['ln1_b'], cfg.eps)
        Q = (ln1 @ w['W_q'].T + w['b_q']).astype(np.float32)
        K = (ln1 @ w['W_k'].T + w['b_k']).astype(np.float32)
        V = (ln1 @ w['W_v'].T + w['b_v']).astype(np.float32)
        if kv_cache is not None:
            K_full = np.concatenate([kv_cache['K'], K], axis=0)
            V_full = np.concatenate([kv_cache['V'], V], axis=0)
        else:
            K_full, V_full = (K, V)
        past_len = K_full.shape[0] - sl
        full_len = K_full.shape[0]
        Q_h = Q.reshape(sl, cfg.n_heads, cfg.head_dim).transpose(1, 0, 2)
        K_h = K_full.reshape(full_len, cfg.n_heads, cfg.head_dim).transpose(1, 0, 2)
        V_h = V_full.reshape(full_len, cfg.n_heads, cfg.head_dim).transpose(1, 0, 2)
        scores = np.matmul(Q_h, K_h.transpose(0, 2, 1)).astype(np.float32)
        mask = np.full((sl, full_len), -1000000000.0, dtype=np.float32)
        att_type = w.get('attn_type', 'global')
        win = w.get('window', cfg.window_size)
        for i in range(sl):
            i_abs = past_len + i
            start = max(0, i_abs - win + 1) if att_type == 'local' else 0
            mask[i, start:i_abs + 1] = 0.0
        scores += mask[np.newaxis]
        scores -= scores.max(axis=-1, keepdims=True)
        e = np.exp(scores)
        probs = (e / e.sum(axis=-1, keepdims=True)).astype(np.float32)
        ctx = np.matmul(probs, V_h).transpose(1, 0, 2).reshape(sl, cfg.hidden_size)
        att_out = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
        h_mid = (h + att_out).astype(np.float32)
        ln2 = self.laws.layernorm(h_mid, w['ln2_g'], w['ln2_b'], cfg.eps)
        pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
        act = self.laws.gelu(pre)
        ffn_out = (act @ w['W2'].T + w['b2']).astype(np.float32)
        h_out = (h_mid + ffn_out).astype(np.float32)
        return (h_out, K, V)

    def forward(self, input_ids: List[int], kv_caches: Optional[List[Dict]]=None) -> Tuple[np.ndarray, List[Dict]]:
        assert self.trained, 'Model not trained. Call reactor.train(sentences) first.'
        g = self.globals
        ids = np.array(input_ids, dtype=np.int32)
        sl = len(ids)
        past_len = kv_caches[0]['K'].shape[0] if kv_caches else 0
        h = (g['Wte'][ids] + g['Wpe'][np.arange(past_len, past_len + sl)]).astype(np.float32)
        new_caches = []
        for li in range(self.cfg.n_layers):
            cache = kv_caches[li] if kv_caches else None
            h, K_new, V_new = self._layer_forward(h, li, cache)
            if kv_caches:
                new_caches.append({'K': np.concatenate([kv_caches[li]['K'], K_new], axis=0), 'V': np.concatenate([kv_caches[li]['V'], V_new], axis=0)})
            else:
                new_caches.append({'K': K_new, 'V': V_new})
        h_final = self.laws.layernorm(h, g['lnf_g'], g['lnf_b'], self.cfg.eps)
        logits = (h_final @ g['Wlm'].T).astype(np.float32)
        return (logits, new_caches)

    def empty_cache(self) -> List[Dict]:
        H = self.cfg.hidden_size
        return [{'K': np.zeros((0, H), np.float32), 'V': np.zeros((0, H), np.float32)} for _ in range(self.cfg.n_layers)]

    def generate(self, input_ids: List[int], n_tokens: int, temperature: float=1.0, top_k: int=0) -> List[int]:
        logits, cache = self.forward(input_ids)
        new_ids = [self._sample(logits[-1], temperature, top_k)]
        for _ in range(n_tokens - 1):
            logits, cache = self.forward([new_ids[-1]], cache)
            new_ids.append(self._sample(logits[-1], temperature, top_k))
        return new_ids

    def _sample(self, logits: np.ndarray, temperature: float, top_k: int) -> int:
        if temperature == 1.0 and top_k == 0:
            return int(np.argmax(logits))
        logits = logits.astype(np.float32) / max(temperature, 1e-08)
        if top_k > 0:
            topk_idx = np.argsort(logits)[-top_k:]
            mask = np.full_like(logits, -1000000000.0)
            mask[topk_idx] = logits[topk_idx]
            logits = mask
        probs = self.laws.softmax(logits[np.newaxis])[0]
        return int(np.random.choice(len(probs), p=probs.astype(np.float64) / probs.astype(np.float64).sum()))

    @classmethod
    def from_teacher(cls, hf_model, tokenizer, sentences: List[str], max_seq: int=64, verbose: bool=True) -> 'Reactor':
        import torch
        cfg_hf = hf_model.config
        config = ReactorConfig.from_hf_config(cfg_hf)
        reactor = cls(config)
        NL = config.n_layers
        H = config.hidden_size
        FFN_D = hf_model.transformer.h[0].mlp.c_fc.weight.shape[0]
        device = next(hf_model.parameters()).device
        if verbose:
            print(f"\n{'=' * 60}")
            print(f'  REACTOR O(1) TRAINING')
            print(f'  NL={NL} H={H} FFN_D={FFN_D}')
            print(f'  Sentences: {len(sentences)}')
            print(f"{'=' * 60}")
        buffers = {li: {k: [] for k in ['ln1', 'Q', 'K', 'V', 'ctx', 'att_out', 'ln2', 'pre_gelu', 'gelu_out', 'ffn_out']} for li in range(NL)}
        hooks = []
        for li in range(NL):
            bl = hf_model.transformer.h[li]
            at = bl.attn.attention

            def _ln1(l):

                def fn(m, i, o):
                    buffers[l]['ln1'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn

            def _q(l):

                def fn(m, i, o):
                    buffers[l]['Q'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn

            def _k(l):

                def fn(m, i, o):
                    buffers[l]['K'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn

            def _v(l):

                def fn(m, i, o):
                    buffers[l]['V'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn

            def _ctx(l):

                def fn(m, i, o):
                    buffers[l]['ctx'].append(i[0].detach().float().cpu().reshape(-1, H).numpy())
                    buffers[l]['att_out'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn

            def _ln2(l):

                def fn(m, i, o):
                    buffers[l]['ln2'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn

            def _fc(l):
                import torch as _torch

                def fn(m, i, o):
                    buffers[l]['pre_gelu'].append(o.detach().float().cpu().reshape(-1, FFN_D).numpy())
                    pre = o.detach().float().cpu()
                    g = 0.5 * pre * (1 + _torch.tanh(math.sqrt(2 / math.pi) * (pre + 0.044715 * pre ** 3)))
                    buffers[l]['gelu_out'].append(g.reshape(-1, FFN_D).numpy())
                return fn

            def _ffn(l):

                def fn(m, i, o):
                    buffers[l]['ffn_out'].append(o.detach().float().cpu().reshape(-1, H).numpy())
                return fn
            hooks += [bl.ln_1.register_forward_hook(_ln1(li)), at.q_proj.register_forward_hook(_q(li)), at.k_proj.register_forward_hook(_k(li)), at.v_proj.register_forward_hook(_v(li)), at.out_proj.register_forward_hook(_ctx(li)), bl.ln_2.register_forward_hook(_ln2(li)), bl.mlp.c_fc.register_forward_hook(_fc(li)), bl.mlp.c_proj.register_forward_hook(_ffn(li))]
        t0 = time.perf_counter()
        import torch
        n_tok = 0
        with torch.no_grad():
            for si, sent in enumerate(sentences):
                ids = tokenizer(sent, return_tensors='pt', max_length=max_seq, truncation=True)['input_ids'].to(device)
                hf_model(ids)
                n_tok += ids.shape[1]
                if verbose and (si + 1) % 500 == 0:
                    print(f'  Collected {si + 1}/{len(sentences)} stories  {n_tok} tokens')
        for hk in hooks:
            hk.remove()
        t_collect = time.perf_counter() - t0
        for li in range(NL):
            for k in buffers[li]:
                if buffers[li][k]:
                    buffers[li][k] = np.concatenate(buffers[li][k], 0).astype(np.float32)
        N = buffers[0]['ln1'].shape[0]
        rk = matrix_rank(buffers[0]['ln1'].astype(np.float64))
        if verbose:
            print(f'\n  Collected {n_tok} tokens in {t_collect:.1f}s')
            print(f"  Activation rank: {rk}/{H} {('✓ FULL RANK' if rk >= H else '⚠ RANK DEFICIENT')}")
            if rk < H:
                print(f'  ⚠ Need more diverse data for unique solution.')
                print(f'  ⚠ Recommend: ~{H ** 2} unique token positions ({H ** 2 // 15} stories approx)')
        if verbose:
            print(f'\n  SOLVING W MATRICES (O(1) — zero gradient steps)')
            print(f"  {'Layer':<8} {'Wq':>8} {'Wk':>8} {'Wv':>8} {'Wo':>8} {'W1':>8} {'W2':>8}")
            print(f"  {'-' * 56}")
        t_solve = time.perf_counter()
        all_r2 = []
        for li in range(NL):
            b = buffers[li]
            W_q, bq, r2q = CrystalLaws.solve(b['ln1'], b['Q'])
            W_k, bk, r2k = CrystalLaws.solve(b['ln1'], b['K'])
            W_v, bv, r2v = CrystalLaws.solve(b['ln1'], b['V'])
            W_o, bo, r2o = CrystalLaws.solve(b['ctx'], b['att_out'])
            W1, b1, r21 = CrystalLaws.solve(b['ln2'], b['pre_gelu'])
            W2, b2, r22 = CrystalLaws.solve(b['gelu_out'], b['ffn_out'])
            reactor.layers[li] = {'W_q': W_q, 'b_q': bq, 'W_k': W_k, 'b_k': bk, 'W_v': W_v, 'b_v': bv, 'W_o': W_o, 'b_o': bo, 'W1': W1, 'b1': b1, 'W2': W2, 'b2': b2}
            reactor.solve_stats[li] = [r2q, r2k, r2v, r2o, r21, r22]
            all_r2.extend([r2q, r2k, r2v, r2o, r21, r22])
            mark = '✓' if min(r2q, r2k, r2v, r2o, r21, r22) > 0.9999 else '~'
            if verbose:
                print(f'  Layer {li:<3}  {r2q:8.6f} {r2k:8.6f} {r2v:8.6f} {r2o:8.6f} {r21:8.6f} {r22:8.6f}  {mark}')
        t_solve = time.perf_counter() - t_solve
        with torch.no_grad():
            for li in range(NL):
                bl = hf_model.transformer.h[li]
                reactor.layers[li].update({'ln1_g': bl.ln_1.weight.detach().float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.detach().float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.detach().float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.detach().float().cpu().numpy(), 'attn_type': config.attention_layers[li] if li < len(config.attention_layers) else 'global', 'window': config.window_size})
            reactor.globals = {'Wte': hf_model.transformer.wte.weight.detach().float().cpu().numpy(), 'Wpe': hf_model.transformer.wpe.weight.detach().float().cpu().numpy(), 'lnf_g': hf_model.transformer.ln_f.weight.detach().float().cpu().numpy(), 'lnf_b': hf_model.transformer.ln_f.bias.detach().float().cpu().numpy(), 'Wlm': hf_model.lm_head.weight.detach().float().cpu().numpy()}
        reactor.trained = True
        if verbose:
            avg_r2 = float(np.mean(all_r2))
            min_r2 = float(np.min(all_r2))
            print(f'\n  Solve time:   {t_solve:.2f}s')
            print(f'  Total time:   {t_collect + t_solve:.2f}s  (vs hours of gradient training)')
            print(f'  Avg R²:       {avg_r2:.8f}')
            print(f'  Min R²:       {min_r2:.8f}')
            verdict = '✓ O(1) TRAINING COMPLETE' if min_r2 > 0.9999 else '~ NEAR (more data needed)'
            print(f'  Verdict:      {verdict}')
        return reactor

    def save(self, path: str):
        data = {}
        for li in range(self.cfg.n_layers):
            for k, v in self.layers[li].items():
                if isinstance(v, np.ndarray):
                    data[f'layer_{li}_{k}'] = v
                else:
                    data[f'layer_{li}_{k}_str'] = np.array([str(v)])
        for k, v in self.globals.items():
            data[f'global_{k}'] = v
        cfg = self.cfg
        data['config'] = np.array([cfg.n_layers, cfg.hidden_size, cfg.n_heads, cfg.ffn_size, cfg.vocab_size, cfg.max_pos, cfg.window_size])
        np.savez_compressed(path, **data)
        size_mb = sum((v.nbytes for v in data.values() if isinstance(v, np.ndarray))) / 1000000.0
        print(f'  Saved REACTOR to {path}  ({size_mb:.1f}MB)')

    @classmethod
    def load(cls, path: str) -> 'Reactor':
        data = np.load(path, allow_pickle=True)
        cfg_arr = data['config']
        config = ReactorConfig(n_layers=int(cfg_arr[0]), hidden_size=int(cfg_arr[1]), n_heads=int(cfg_arr[2]), ffn_size=int(cfg_arr[3]), vocab_size=int(cfg_arr[4]), max_pos=int(cfg_arr[5]), window_size=int(cfg_arr[6]))
        reactor = cls(config)
        for li in range(config.n_layers):
            reactor.layers[li] = {}
            for k in data.files:
                if k.startswith(f'layer_{li}_') and (not k.endswith('_str')):
                    key = k[len(f'layer_{li}_'):]
                    reactor.layers[li][key] = data[k]
                elif k.startswith(f'layer_{li}_') and k.endswith('_str'):
                    key = k[len(f'layer_{li}_'):-4]
                    reactor.layers[li][key] = str(data[k][0])
        reactor.globals = {k[7:]: data[k] for k in data.files if k.startswith('global_')}
        reactor.trained = True
        print(f'  Loaded REACTOR from {path}')
        return reactor
if __name__ == '__main__':
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from datasets import load_dataset
    MODEL_ID = 'roneneldan/TinyStories-1M'
    N_TRAIN = 2000
    GEN_TOKENS = 40
    SAVE_PATH = 'reactor_tinystories.npz'
    TEST_PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'In the forest there lived a']
    print('╔══════════════════════════════════════════════╗')
    print('║  REACTOR DEMO — TinyStories-1M              ║')
    print('╚══════════════════════════════════════════════╝')
    print(f'\nLoading {MODEL_ID}...')
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).eval()
    print(f'Loading {N_TRAIN} TinyStories...')
    ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
    sentences = []
    for item in ds:
        t = item['text'].strip()
        if 20 < len(t) < 300:
            sentences.append(t)
        if len(sentences) >= N_TRAIN:
            break
    reactor = Reactor.from_teacher(teacher, tokenizer, sentences, max_seq=64, verbose=True)
    reactor.save(SAVE_PATH)
    print(f"\n{'=' * 60}")
    print('  GENERATION COMPARISON')
    print(f"{'=' * 60}")
    total_match = 0
    total_tok = 0
    for prompt in TEST_PROMPTS:
        ids_prompt = tokenizer(prompt, return_tensors='pt')['input_ids'][0].tolist()
        with torch.no_grad():
            out = teacher.generate(torch.tensor([ids_prompt]), max_new_tokens=GEN_TOKENS, do_sample=False, use_cache=True)
        ids_teacher = out[0][len(ids_prompt):].tolist()
        ids_reactor = reactor.generate(ids_prompt, GEN_TOKENS)
        match = sum((a == b for a, b in zip(ids_teacher, ids_reactor)))
        total_match += match
        total_tok += GEN_TOKENS
        print(f'\n  Prompt:   "{prompt}"')
        print(f'  Teacher:  {repr(tokenizer.decode(ids_teacher)[:65])}')
        print(f'  REACTOR:  {repr(tokenizer.decode(ids_reactor)[:65])}')
        print(f"  Match:    {match}/{GEN_TOKENS}  {('✓' if match == GEN_TOKENS else '~')}")
    pct = 100 * total_match / total_tok
    print(f"\n{'=' * 60}")
    print(f'  FINAL: {total_match}/{total_tok} = {pct:.1f}% token match')
    print(f"  {('✓ O(1) TRAINING PROVEN' if pct == 100 else '~ See README for data requirements')}")
    print(f"{'=' * 60}")
