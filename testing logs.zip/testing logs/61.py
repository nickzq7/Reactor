import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
DIM = 16

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

class ResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class ResNet(nn.Module):

    def __init__(self, n_hidden, dim=DIM):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(SEQ_LEN, dim), nn.Tanh())
        self.blocks = nn.ModuleList([ResBlock(dim) for _ in range(n_hidden)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for blk in self.blocks:
            x = blk(x)
        return self.output(x)

def train(model, epochs=5000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 1000 == 0:
            s = score(model)
            print(f'    {label:<18} ep{ep:>5}  loss={best:>12.6f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def score_precise(model):
    model.eval()
    errors = []
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            pred = model(xt).item() * NORM
            errors.append(abs(pred - tn))
    return errors

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
DEPTHS = [3, 5, 10, 20, 30, 50, 75, 100]
EPOCHS = 5000
CHECKPTS = [1000, 2000, 3000, 4000, 5000]
print_sep('DEPTH SWEEP — flat+residual, 5000 epochs each')
print(f'  Depths: {DEPTHS}')
print(f'  DIM={DIM}, epochs={EPOCHS}\n')
all_results = []
all_logs = {}
for n_layers in DEPTHS:
    n_hidden = n_layers - 1
    print(f'\n  ── {n_layers}-layer (n_hidden={n_hidden}) ──')
    np.random.seed(42)
    m = ResNet(n_hidden, DIM).to(device)
    params = sum((p.numel() for p in m.parameters()))
    print(f'  Params: {params:,}')
    t0 = time.time()
    best_loss, log = train(m, EPOCHS, lr=0.001, label=f'{n_layers}L-res')
    s = score(m)
    errors = score_precise(m)
    avg_err = np.mean(errors)
    max_err = np.max(errors)
    elapsed = time.time() - t0
    all_results.append((n_layers, n_hidden, params, best_loss, s, avg_err, max_err, elapsed))
    all_logs[n_layers] = log
    del m
    torch.cuda.empty_cache()
    print(f'  DONE: loss={best_loss:.8f}  score={s}/{len(TESTS)}  avg_err={avg_err:.4f}  time={elapsed:.0f}s')
print_sep('CONVERGENCE TABLE — loss at each checkpoint')
print(f"  {'Epoch':>6}", end='')
for d in DEPTHS:
    print(f'  {d}L-res', end='')
print()
print(f"  {'─' * 90}")
for ep in CHECKPTS:
    print(f'  {ep:>6}', end='')
    for d in DEPTHS:
        log = all_logs[d]
        v = log[min(ep - 1, len(log) - 1)]
        print(f'  {v:>8.4f}', end='')
    print()
print_sep('FINAL SCOREBOARD — sorted by precision (loss)')
sorted_results = sorted(all_results, key=lambda x: x[3])
print(f"\n  {'Depth':>7}  {'Params':>8}  {'Score':>7}  {'Loss':>14}  {'Avg Err':>10}  {'Max Err':>10}")
print(f"  {'─' * 72}")
for n_layers, n_hidden, params, loss, s, avg_err, max_err, elapsed in sorted_results:
    marker = ' ← PEAK' if n_layers == sorted_results[0][0] else ''
    print(f'  {n_layers:>7}L  {params:>8,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {avg_err:>10.4f}  {max_err:>10.4f}{marker}')
print_sep('PRECISION ANALYSIS — how precise is each depth?')
print(f'\n  All scores in context:')
print(f'  Shallow (no residual) = 20/20 but loss~57')
print(f'  Deep+residual precision at each depth:\n')
for n_layers, _, params, loss, s, avg_err, max_err, _ in sorted_results:
    precision_gain = 57.3 / (loss + 1e-10)
    bar = '█' * min(50, int(np.log10(precision_gain + 1) * 15))
    print(f'  {n_layers:>4}L  score={s}/{len(TESTS)}  loss={loss:.6f}  precision_vs_10L={precision_gain:.0f}x  {bar}')
print_sep('PEAK DEPTH CONCLUSION')
best = sorted_results[0]
print(f"\n  OPTIMAL DEPTH: {best[0]} layers\n  Score        : {best[4]}/{len(TESTS)}\n  Loss         : {best[3]:.8f}\n  Avg error    : {best[5]:.4f}\n  Params       : {best[2]:,}\n\n  DEPTH vs PRECISION CURVE:\n  3L   → baseline shallow\n  ...increasing...\n  {best[0]}L → PEAK PRECISION\n  ...then?...\n\n  Like intelligence:\n    Too shallow = not enough reasoning depth\n    Optimal = perfect balance of depth and signal\n    Too deep = diminishing returns or collapse\n\n  The optimal depth IS the natural depth of the problem.\n  This problem's natural depth = {best[0]} layers.\n  Every problem has its own natural depth.\n  Finding it = finding the geometry of that problem.\n")
