import torch, numpy as np, math, warnings
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_ID = 'roneneldan/TinyStories-1M'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}\n')
tok = AutoTokenizer.from_pretrained(MODEL_ID)
model = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = model.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD = H // NH
W = {}
for li in range(NL):
    bl = model.transformer.h[li]
    at = bl.attn.attention
    W[li] = {'ln1_g': bl.ln_1.weight.detach().float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.detach().float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.detach().float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.detach().float().cpu().numpy(), 'W_q': at.q_proj.weight.detach().float().cpu().numpy(), 'W_k': at.k_proj.weight.detach().float().cpu().numpy(), 'W_v': at.v_proj.weight.detach().float().cpu().numpy(), 'W_o': at.out_proj.weight.detach().float().cpu().numpy(), 'b_o': at.out_proj.bias.detach().float().cpu().numpy(), 'W1': bl.mlp.c_fc.weight.detach().float().cpu().numpy(), 'b1': bl.mlp.c_fc.bias.detach().float().cpu().numpy(), 'W2': bl.mlp.c_proj.weight.detach().float().cpu().numpy(), 'b2': bl.mlp.c_proj.bias.detach().float().cpu().numpy()}
    try:
        W[li]['attn_type'] = cfg.attention_layers[li]
    except:
        W[li]['attn_type'] = 'global'
    try:
        W[li]['window'] = cfg.window_size
    except:
        W[li]['window'] = 256
Wte = model.transformer.wte.weight.detach().float().cpu().numpy()
Wpe = model.transformer.wpe.weight.detach().float().cpu().numpy()
lnf_g = model.transformer.ln_f.weight.detach().float().cpu().numpy()
lnf_b = model.transformer.ln_f.bias.detach().float().cpu().numpy()
Wlm = model.lm_head.weight.detach().float().cpu().numpy()

def ln(x, g, b):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (g * (x - mean) / np.sqrt(var + 1e-05) + b).astype(np.float32)

def gelu_np(x):
    return (0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def corr(a, b):
    a, b = (a.ravel().astype(np.float64), b.ravel().astype(np.float64))
    return float(np.corrcoef(a, b)[0, 1])

def maxdiff(a, b):
    return float(np.max(np.abs(a.astype(np.float32) - b.astype(np.float32))))
PROBE = 0
probe = {}

def hook_ln1(mod, inp, out):
    probe['ln1_out'] = out.detach().float().cpu().numpy()[0]

def hook_attn(mod, inp, out):
    probe['att_out'] = out[0].detach().float().cpu().numpy()[0]

def hook_ln2(mod, inp, out):
    probe['ln2_out'] = out.detach().float().cpu().numpy()[0]

def hook_fc(mod, inp, out):
    probe['pre_gelu'] = out.detach().float().cpu().numpy()[0]

def hook_mlp(mod, inp, out):
    probe['ffn_out'] = out.detach().float().cpu().numpy()[0]

def hook_outproj(mod, inp, out):
    probe['concat_ctx'] = inp[0].detach().float().cpu().numpy()[0]

def hook_block(mod, inp, out):
    x = out[0] if isinstance(out, tuple) else out
    probe['h_out'] = x.detach().float().cpu().numpy()[0]

def hook_h_in(mod, inp):
    x = inp[0] if isinstance(inp, tuple) else inp
    probe['h_in'] = x.detach().float().cpu().numpy()[0]
hs = []
bl0 = model.transformer.h[PROBE]
hs.append(bl0.ln_1.register_forward_hook(hook_ln1))
hs.append(bl0.attn.register_forward_hook(hook_attn))
hs.append(bl0.ln_2.register_forward_hook(hook_ln2))
hs.append(bl0.mlp.c_fc.register_forward_hook(hook_fc))
hs.append(bl0.mlp.register_forward_hook(hook_mlp))
hs.append(bl0.attn.attention.out_proj.register_forward_hook(hook_outproj))
hs.append(bl0.register_forward_hook(hook_block))
hs.append(bl0.register_forward_pre_hook(hook_h_in))
stream = {}

def make_stream_hook(li):

    def fn(mod, inp, out):
        x = out[0] if isinstance(out, tuple) else out
        stream[li] = x.detach().float().cpu().numpy()[0]
    return fn
for li in range(NL):
    hs.append(model.transformer.h[li].register_forward_hook(make_stream_hook(li)))
text = 'Once upon a time there was a little girl'
ids = tok(text, return_tensors='pt')['input_ids']
ids_np = ids[0].tolist()
sl = len(ids_np)
with torch.no_grad():
    pt_logits = model(ids.to(device)).logits[0].float().cpu().numpy()
for hk in hs:
    hk.remove()
h = (Wte[ids_np] + Wpe[np.arange(sl)]).astype(np.float32)
print('=' * 65)
print('  LAYER-BY-LAYER STREAM COMPARISON')
print('=' * 65)
print(f"  {'Layer':<8} {'stream_corr':>12}  {'stream_maxdiff':>15}  notes")
print(f"  {'-' * 60}")

def crystal_layer_full(h, li):
    w = W[li]
    sl = h.shape[0]
    ln1 = ln(h, w['ln1_g'], w['ln1_b'])
    Q = (ln1 @ w['W_q'].T).astype(np.float32)
    K = (ln1 @ w['W_k'].T).astype(np.float32)
    V = (ln1 @ w['W_v'].T).astype(np.float32)
    scale = 1.0 / math.sqrt(HD)
    head_ctxs = []
    for hh in range(NH):
        s, e = (hh * HD, hh * HD + HD)
        Q_h = Q[:, s:e]
        K_h = K[:, s:e]
        V_h = V[:, s:e]
        scores = (Q_h @ K_h.T * scale).astype(np.float32)
        mask = np.full((sl, sl), -1000000000.0, dtype=np.float32)
        for i in range(sl):
            start = max(0, i - w['window'] + 1) if w['attn_type'] == 'local' else 0
            mask[i, start:i + 1] = 0.0
        probs = softmax_np(scores + mask)
        head_ctxs.append((probs @ V_h).astype(np.float32))
    ctx = np.concatenate(head_ctxs, axis=-1).astype(np.float32)
    att_out = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
    h_mid = (h + att_out).astype(np.float32)
    ln2 = ln(h_mid, w['ln2_g'], w['ln2_b'])
    pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
    act = gelu_np(pre)
    ffn_out = (act @ w['W2'].T + w['b2']).astype(np.float32)
    return (h_mid + ffn_out).astype(np.float32)
for li in range(NL):
    h = crystal_layer_full(h, li)
    c = corr(h, stream[li])
    md = maxdiff(h, stream[li])
    note = '✓' if c > 0.9999 else 'near' if c > 0.999 else 'FAIL'
    print(f'  Layer {li:<3}  {c:12.8f}  {md:15.2e}  {note}')
print()
print('=' * 65)
print('  LAYER 0 SUB-OPERATION PROBE')
print('=' * 65)
h0 = (Wte[ids_np] + Wpe[np.arange(sl)]).astype(np.float32)
w = W[0]
cr_ln1 = ln(h0, w['ln1_g'], w['ln1_b'])
cr_Q = (cr_ln1 @ w['W_q'].T).astype(np.float32)
cr_K = (cr_ln1 @ w['W_k'].T).astype(np.float32)
cr_V = (cr_ln1 @ w['W_v'].T).astype(np.float32)
scale = 1.0 / math.sqrt(HD)
head_ctxs = []
for hh in range(NH):
    s, e = (hh * HD, hh * HD + HD)
    scores = (cr_Q[:, s:e] @ cr_K[:, s:e].T * scale).astype(np.float32)
    mask = np.full((sl, sl), -1000000000.0, dtype=np.float32)
    for i in range(sl):
        start = max(0, i - w['window'] + 1) if w['attn_type'] == 'local' else 0
        mask[i, start:i + 1] = 0.0
    probs = softmax_np(scores + mask)
    head_ctxs.append((probs @ cr_V[:, s:e]).astype(np.float32))
cr_ctx = np.concatenate(head_ctxs, axis=-1).astype(np.float32)
cr_att_out = (cr_ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
cr_h_mid = (h0 + cr_att_out).astype(np.float32)
cr_ln2 = ln(cr_h_mid, w['ln2_g'], w['ln2_b'])
cr_pre = (cr_ln2 @ w['W1'].T + w['b1']).astype(np.float32)
cr_act = gelu_np(cr_pre)
cr_ffn_out = (cr_act @ w['W2'].T + w['b2']).astype(np.float32)
cr_h_out = (cr_h_mid + cr_ffn_out).astype(np.float32)
ops = [('h_in', h0, probe.get('h_in')), ('ln1_out', cr_ln1, probe.get('ln1_out')), ('att_ctx', cr_ctx, probe.get('concat_ctx')), ('att_out', cr_att_out, probe.get('att_out')), ('ln2_out', cr_ln2, probe.get('ln2_out')), ('pre_gelu', cr_pre, probe.get('pre_gelu')), ('ffn_out', cr_ffn_out, probe.get('ffn_out')), ('h_out', cr_h_out, probe.get('h_out'))]
print(f"  {'op':<14} {'corr':>12}  {'maxdiff':>12}  status")
print(f"  {'-' * 50}")
for name, cr_val, pt_val in ops:
    if pt_val is None:
        print(f"  {name:<14}  {'(not hooked)':>12}")
        continue
    c = corr(cr_val, pt_val)
    md = maxdiff(cr_val, pt_val)
    ok = '✓' if c > 0.9999 else 'near' if c > 0.999 else 'FAIL ←'
    print(f'  {name:<14}  {c:12.8f}  {md:12.2e}  {ok}')
h = (Wte[ids_np] + Wpe[np.arange(sl)]).astype(np.float32)
for li in range(NL):
    h = crystal_layer_full(h, li)
h_final = ln(h, lnf_g, lnf_b)
cr_logits = (h_final @ Wlm.T).astype(np.float32)
print()
print('=' * 65)
print('  FINAL LOGIT COMPARISON  (last position)')
print('=' * 65)
pos = -1
pt_top5 = np.argsort(pt_logits[pos])[-5:][::-1]
cr_top5 = np.argsort(cr_logits[pos])[-5:][::-1]
print(f'  PyTorch top5: {[tok.decode([t]) for t in pt_top5]}')
print(f'  Crystal top5: {[tok.decode([t]) for t in cr_top5]}')
print(f'  Logit corr (last pos): {corr(pt_logits[pos], cr_logits[pos]):.8f}')
print(f'  Logit maxdiff:         {maxdiff(pt_logits[pos], cr_logits[pos]):.2e}')
print(f"  Argmax match: {('✓' if np.argmax(pt_logits[pos]) == np.argmax(cr_logits[pos]) else '✗')}")
