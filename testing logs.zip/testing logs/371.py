import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    return (r2(Xb[:s] @ W, Y[:s]), r2(Xb[s:] @ W, Y[s:]))

def show(name, r2_tr, r2_te):
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<55} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly in the shadows. Lily gently picked up the kitten and held it close to her heart to keep it warm.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding the animals he would go to the fields and work until the sun went down.', 'Deep in the forest there was a small house where a family of bears lived together happily. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the woods nearby. One day the baby bear followed a butterfly deep into the forest and got lost alone.', 'There was once a brave young knight who lived in a castle near the mountains high above. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go and face the dragon and bring peace to the kingdom.', 'A small girl named Sophie loved books more than anything else in the whole wide world today. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her stories directly.', 'The little village sat quietly at the edge of a great forest full of ancient tall trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest time. Children would run through the market eating apples and drinking warm spiced cider joyfully. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight came.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him. The first night Tommy shone the light and saw only his toys and books and nothing scary. His father explained that darkness was just the absence of light and nothing more.', 'The ocean was vast and blue and stretched as far as the eye could possibly see each day. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water. One night a terrible storm came and blew his boat far off course into unknown waters far. When morning came he saw an island he had never seen before on any map.', 'High up in the mountains there was a small school where children came from very far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way. Some children learned by reading and some by drawing and some by building things with hands. She gave each child the kind of lesson that matched the way their mind worked.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished and it had a rope ladder and window.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the path and picked it up. The stone glowed with a soft blue light that pulsed slowly like a heartbeat in her paw. She brought it home and placed it in her burrow where it lit up warmly.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest. She spent her days tending her garden and feeding the birds that came to visit her daily. Every evening she would sit by the fire and read her old favorite books by the light. One day a lost child appeared at her door cold and hungry and very frightened. She welcomed the child inside and gave food and warmth and comfort without hesitation.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day. The puppy was wet and cold and very hungry and it looked up at him with big eyes. Sam picked up the puppy and carried it home carefully to show his mother right away. His mother smiled and said they could keep the puppy if Sam promised to care for it. Sam promised and from that day on the puppy followed him everywhere he went.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone before. Every day she would watch the village below and wish she could play with the children there. One day a brave girl climbed the mountain and sat down quietly beside the dragon. The dragon was surprised but did not fly away because the girl was kind and gentle. They talked for hours and from that day became the best of friends forever.', 'In the deep blue ocean there lived a curious fish who wanted to see the world above it. Every day she would swim to the surface and peek at the sky and the tall green trees. One morning she jumped very high and for a moment she could see everything around. She saw hills and rivers and roads and tiny people walking far below in the distance. From that day she knew the world was much bigger than her small blue ocean.', 'The old clock in the corner of the room had not worked for many many long quiet years. One rainy afternoon the little girl decided to try to fix it with her small toy tools. She turned the gears carefully and wound the spring slowly and tightened every loose screw. Suddenly with a soft click and a gentle whir the clock began to tick again steadily. The girl smiled proudly and her grandfather hugged her and said she was very clever indeed.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below. Rain fell gently on it for many days and the warm sun shone down on the earth. Slowly a small green shoot appeared pushing up through the dark soil toward the light above. It grew taller every day stretching upward until it became a sapling strong and straight. Years later it was a great tree itself with birds nesting in its leafy branches.', 'The young painter stood in front of the blank white canvas and did not know where to start. She dipped her brush in the bright blue paint and made one small careful stroke across it. Then she added yellow and red and slowly a beautiful sunrise began to appear before her. She painted clouds and birds and a river winding through green fields in the valley. When she finished she stepped back and saw it was the most beautiful thing she made.', 'Every evening the grandfather would sit in his old wooden chair and tell stories to the children. The children would gather around him and listen with wide open eyes in the warm firelight. His stories were always about adventures in faraway lands and magical creatures and brave young heroes. He remembered every detail perfectly and his voice rose and fell like music as he spoke. The children never wanted the stories to end and always begged for just one more tale.']
print(f'\nCollecting gelu activations all layers...')
gelu_store = {li: [] for li in range(n_layers)}
cur_gelu = {li: None for li in range(n_layers)}
hooks = []
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur_gelu[l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
with torch.no_grad():
    for text in long_texts:
        for li in range(n_layers):
            cur_gelu[li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        L = toks['input_ids'].shape[1]
        for li in range(n_layers):
            if cur_gelu[li] is not None:
                for t in range(L):
                    gelu_store[li].append(cur_gelu[li][t].copy())
for h in hooks:
    h.remove()
G = {li: np.array(gelu_store[li], dtype=np.float32) for li in range(n_layers)}
N = len(G[0])
print(f'Tokens per layer: {N}')
print(f"\n{'=' * 70}")
print(f'  TEST 1 — Direct crystal prediction')
print(f'  gelu_0 → gelu_l for each layer l')
print(f'  If 1.000: first crystal contains all future crystals.')
print(f"{'=' * 70}\n")
r2_direct = {}
for li in range(1, n_layers):
    r2_tr, r2_te = fit_r2(G[0], G[li])
    r2_direct[li] = r2_te
    show(f'  gelu_0 → gelu_{li}', r2_tr, r2_te)
print(f"\n{'=' * 70}")
print(f'  TEST 2 — Crystal with depth encoding')
print(f'  [gelu_0, depth/n_layers] → gelu_l')
print(f'  Does knowing depth close the gap?')
print(f"{'=' * 70}\n")
r2_depth = {}
for li in range(1, n_layers):
    depth_feat = np.full((N, 1), li / n_layers, dtype=np.float32)
    X_depth = np.c_[G[0], depth_feat]
    r2_tr, r2_te = fit_r2(X_depth, G[li])
    r2_depth[li] = r2_te
    lift = r2_te - r2_direct.get(li, 0)
    show(f'  [gelu_0, depth={li}] → gelu_{li}', r2_tr, r2_te)
    print(f'    lift from depth: {lift:+.6f}')
print(f"\n{'=' * 70}")
print(f'  TEST 3 — Crystal chain gap analysis')
print(f'  gelu_l → gelu_l+1. What causes the 0.07-0.15 gap?')
print(f"{'=' * 70}\n")
print(f"  {'Chain':<25} {'R²_te':<12} {'Gap':<12} {'Gap source?'}")
print(f"  {'─' * 60}")
for li in range(n_layers - 1):
    r2_tr, r2_te = fit_r2(G[li], G[li + 1])
    gap = 1.0 - r2_te
    print(f'  gelu_{li} → gelu_{li + 1:<15} {r2_te:.6f}    {gap:.6f}')
print(f"\n{'=' * 70}")
print(f'  TEST 4 — Crystal similarity across layers')
print(f'  Cosine similarity: mean(cos(gelu_l, gelu_0)) per token')
print(f'  1.0 = same direction. 0.0 = orthogonal. -1.0 = opposite.')
print(f"{'=' * 70}\n")
g0_norm = G[0] / (np.linalg.norm(G[0], axis=1, keepdims=True) + 1e-08)
print(f"  {'Layer':<10} {'Mean cosine':<16} {'Std cosine':<14} {'Pattern'}")
print(f"  {'─' * 50}")
cosines = []
for li in range(n_layers):
    gl_norm = G[li] / (np.linalg.norm(G[li], axis=1, keepdims=True) + 1e-08)
    cos = np.sum(g0_norm * gl_norm, axis=1)
    mean_c = float(np.mean(cos))
    std_c = float(np.std(cos))
    cosines.append(mean_c)
    pattern = 'SAME' if mean_c > 0.95 else 'SIMILAR' if mean_c > 0.7 else 'ROTATED' if mean_c > 0.3 else 'ORTHOGONAL' if mean_c > -0.1 else 'OPPOSITE'
    print(f'  {li:<10} {mean_c:<16.4f} {std_c:<14.4f} {pattern}')
print(f"\n{'=' * 70}")
print(f'  TEST 5 — Residual crystal: gelu_l - gelu_0')
print(f'  What does each layer ADD to the first crystal?')
print(f'  Small residual = first crystal dominates.')
print(f'  Structured residual = law in what is added.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<10} {'Residual norm':<18} {'% of gelu_0':<16} {'Signal?'}")
print(f"  {'─' * 55}")
g0_norm_val = float(np.mean(np.linalg.norm(G[0], axis=1)))
for li in range(1, n_layers):
    residual = G[li] - G[0]
    res_norm = float(np.mean(np.linalg.norm(residual, axis=1)))
    pct = res_norm / g0_norm_val * 100
    signal = 'SMALL' if pct < 20 else 'MEDIUM' if pct < 60 else 'LARGE'
    print(f'  {li:<10} {res_norm:<18.4f} {pct:<16.1f} {signal}')
print(f'\n  Can gelu_0 predict the residual? (residual = gelu_l - gelu_0)')
print(f'  If yes: residual is structured. gelu_0 contains it.')
for li in range(1, n_layers):
    residual = G[li] - G[0]
    r2_tr, r2_te = fit_r2(G[0], residual)
    show(f'  gelu_0 → residual_{li}', r2_tr, r2_te)
print(f"\n{'=' * 70}")
print(f'  TEST 6 — Crystal basis: do all layers share same subspace?')
print(f'  PCA top dims of gelu_l vs gelu_0.')
print(f'  If same dims: one coordinate system for all crystals.')
print(f"{'=' * 70}\n")
g0c = G[0] - G[0].mean(axis=0)
_, _, Vt0 = np.linalg.svd(g0c, full_matrices=False)
print(f"  {'Layer':<10} {'top-5 alignment':<20} {'top-10 alignment':<20} {'Shared basis?'}")
print(f"  {'─' * 60}")
for li in range(n_layers):
    glc = G[li] - G[li].mean(axis=0)
    _, _, Vtl = np.linalg.svd(glc, full_matrices=False)

    def subspace_align(V1, V2, k):
        M = V1[:k] @ V2[:k].T
        s = np.linalg.svd(M, compute_uv=False)
        return float(np.mean(np.clip(s, 0, 1)))
    a5 = subspace_align(Vt0, Vtl, 5)
    a10 = subspace_align(Vt0, Vtl, 10)
    shared = '✓ SHARED' if a5 > 0.9 else '~ PARTIAL' if a5 > 0.7 else '✗ DIFFERENT'
    print(f'  {li:<10} {a5:<20.4f} {a10:<20.4f} {shared}')
print(f"\n{'=' * 70}")
print(f'  TEST 3 — CRYSTAL RESONANCE SUMMARY')
print(f"{'=' * 70}")
print(f'\n  READING THE RESULTS:\n\n  TEST 1 (gelu_0 → gelu_l):\n    R²=1.000: first crystal = complete. Contains all future.\n    R² drops: crystals diverge. Each layer independent.\n    Partial: resonance exists but incomplete.\n\n  TEST 2 (depth encoding):\n    Lift > 0.05: depth IS information. Crystal evolves with depth.\n    Lift ≈ 0: crystal does not depend on depth. Depth is irrelevant.\n\n  TEST 3 (chain gap):\n    Gap comes from attention between layers.\n    gelu_l → attention → gelu_l+1.\n    Gap = what attention adds between crystals.\n    If gap is constant: attention adds same amount each time.\n    If gap varies: some layers more attention-dependent.\n\n  TEST 4 (cosine similarity):\n    High cosine: crystals point same direction. Scale changes.\n    Medium cosine: crystals rotate slowly with depth.\n    Low cosine: crystals are independent per layer.\n    Pattern tells us if ONE crystal coordinate system exists.\n\n  TEST 5 (residual):\n    Small residual + predictable: gelu_0 dominates all.\n    Large residual + unpredictable: each layer builds fresh.\n    This tells us if first crystal is the source of all.\n\n  TEST 6 (shared basis):\n    Same PCA dims: one crystal coordinate system for all layers.\n    Different dims: each layer has own crystal space.\n    If same: project all layers to basis of gelu_0.\n    Work only in that space. Skip rest.\n\n  IF RESONANCE CONFIRMED:\n    gelu_0 = seed crystal.\n    All deeper crystals = transformation of seed.\n    Run only layer 0 FFN. Transform by depth. Skip rest.\n    That = massive speedup. Real. Proven. Not approximate.\n')
print('=' * 70 + '\n')
