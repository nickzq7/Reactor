import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
H = 1
NL = meta['NLA']
D2 = 2
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s
fib = gen_fib(60)
ALL_PATS = {}
for off in range(8):
    ALL_PATS[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
PAT_NAMES = list(ALL_PATS.keys())

class SeqT2(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D2)
        self.wpe = nn.Embedding(K, D2)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D2), 'attn': nn.MultiheadAttention(D2, H, batch_first=True), 'ln2': nn.LayerNorm(D2), 'ff': nn.Sequential(nn.Linear(D2, D2 * 4), nn.GELU(), nn.Linear(D2 * 4, D2))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D2)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def eval_model(model):
    model.eval()
    scores = []
    for pn in PAT_NAMES:
        seq, truth = ALL_PATS[pn]
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        scores.append(p == truth)
    return (sum(scores), scores)

def plot_geometry(model, label, step=None, scores=None):
    wte = model.wte.weight.detach().numpy()
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    title = f'D=2 Fibonacci Natural Space — {label}'
    if step:
        title += f' (step {step})'
    fig.suptitle(title, fontsize=13)
    ax = axes[0]
    colors = plt.cm.hsv(np.linspace(0, 1, VS))
    ax.scatter(wte[:, 0], wte[:, 1], c=colors, s=90, zorder=3, edgecolors='black', linewidths=0.3)
    for i in range(VS):
        ax.annotate(str(i), (wte[i, 0], wte[i, 1]), fontsize=6.5, ha='center', va='bottom', fontweight='bold')
    theta = np.linspace(0, 2 * np.pi, 200)
    r_mean = np.mean(np.linalg.norm(wte, axis=1))
    ax.plot(r_mean * np.cos(theta), r_mean * np.sin(theta), 'gray', linewidth=0.5, linestyle='--', alpha=0.4)
    ax.set_title('All tokens (colored by index)')
    ax.set_xlabel('dim 0')
    ax.set_ylabel('dim 1')
    ax.axhline(0, color='gray', lw=0.5)
    ax.axvline(0, color='gray', lw=0.5)
    ax.set_aspect('equal')
    ax = axes[1]
    fib_seq = [f % VS for f in fib[:20]]
    fib_unique = list(dict.fromkeys(fib_seq))
    ax.scatter(wte[:, 0], wte[:, 1], c='lightgray', s=40, zorder=2)
    for i in range(VS):
        ax.annotate(str(i), (wte[i, 0], wte[i, 1]), fontsize=6, ha='center', va='bottom', color='gray')
    fib_colors = plt.cm.plasma(np.linspace(0, 1, len(fib_seq) - 1))
    for i in range(len(fib_seq) - 1):
        t0, t1 = (fib_seq[i], fib_seq[i + 1])
        ax.annotate('', xy=(wte[t1, 0], wte[t1, 1]), xytext=(wte[t0, 0], wte[t0, 1]), arrowprops=dict(arrowstyle='->', color=fib_colors[i], lw=1.5, alpha=0.8))
    fib_pts = np.array([wte[t] for t in fib_unique])
    ax.scatter(fib_pts[:, 0], fib_pts[:, 1], c='red', s=120, zorder=4, edgecolors='black', linewidths=0.5)
    for t in fib_unique:
        ax.annotate(str(t), (wte[t, 0] + 0.02, wte[t, 1] + 0.02), fontsize=8, color='red', fontweight='bold')
    ax.set_title('Fibonacci path (red=fib tokens, color=time)')
    ax.set_xlabel('dim 0')
    ax.set_ylabel('dim 1')
    ax.axhline(0, color='gray', lw=0.5)
    ax.axvline(0, color='gray', lw=0.5)
    ax.set_aspect('equal')
    ax = axes[2]
    norms = np.linalg.norm(wte, axis=1)
    angles = np.arctan2(wte[:, 1], wte[:, 0])
    order = np.argsort(angles)
    ax.plot(range(VS), np.sort(angles) * 180 / np.pi, 'b-o', markersize=4, label='sorted angles')
    fib_set = set(fib_seq)
    ax_colors = ['red' if i in fib_set else 'blue' for i in order]
    for idx, (x, col) in enumerate(zip(range(VS), ax_colors)):
        ax.plot(x, np.sort(angles)[idx] * 180 / np.pi, 'o', color=col, markersize=6 if col == 'red' else 3)
    for idx, tok in enumerate(order[::3]):
        ax.annotate(str(tok), (idx * 3, np.sort(angles)[idx * 3] * 180 / np.pi + 5), fontsize=6, color='gray')
    ax.set_title('Token angles (red=fibonacci tokens)')
    ax.set_xlabel('rank by angle')
    ax.set_ylabel('angle (degrees)')
    ax.legend()
    if scores is not None:
        sc = sum(scores)
        bar = ''.join(('█' if x else '░' for x in scores))
        fig.text(0.5, 0.01, f'Score: {sc}/8  {bar}', ha='center', fontsize=11, color='green' if sc == 8 else 'red')
    plt.tight_layout()
    path = os.path.join(_dir, f'scriptA_{label}.png')
    plt.savefig(path, dpi=130, bbox_inches='tight')
    plt.close()
    print(f'  → Plot saved: scriptA_{label}.png', flush=True)

def build_tensors():
    Xs = []
    Ys = []
    for pn in PAT_NAMES:
        seq, _ = ALL_PATS[pn]
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))
ALL_X, ALL_Y = build_tensors()
print('=' * 60)
print('  SCRIPT A — D=2 NATURAL SPACE DISCOVERY')
print('  Training from scratch. No donor compression.')
print('  D=2 finds its OWN natural space.')
print('=' * 60)
N_RUNS = 5
STEPS = 5000
LR = 0.003
SNAP_AT = [100, 500, 1000, 2000, 5000]
best_overall = (0, None)
all_run_scores = []
for run in range(N_RUNS):
    seed = run * 42 + 7
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = SeqT2().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=STEPS, eta_min=1e-05)
    print(f'\n  ── Run {run + 1}/{N_RUNS}  seed={seed} ──')
    best_s = 0
    best_state = None
    t0 = time.time()
    for step in range(1, STEPS + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step in SNAP_AT or step % 500 == 0:
            sc, scores = eval_model(model)
            bar = ''.join(('█' if x else '░' for x in scores))
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  step {step:>5}: {sc}/8  {bar}', flush=True)
            if run == 0 and step in SNAP_AT:
                plot_geometry(model, f'run0_step{step}', step=step, scores=scores)
    if best_state:
        model.load_state_dict(best_state)
    sc, scores = eval_model(model)
    all_run_scores.append(sc)
    print(f'  Run {run + 1} best: {sc}/8  time={time.time() - t0:.0f}s')
    if sc > best_overall[0]:
        best_overall = (sc, {k: v.clone() for k, v in model.state_dict().items()})
    plot_geometry(model, f'run{run + 1}_final', scores=scores)
print(f"\n{'=' * 60}")
print(f'  RESULTS ACROSS {N_RUNS} RUNS')
print(f"{'=' * 60}")
print(f'  Scores: {all_run_scores}')
print(f'  Best:   {best_overall[0]}/8')
print(f'  Mean:   {np.mean(all_run_scores):.2f}/8')
best_model = SeqT2().to(device)
best_model.load_state_dict(best_overall[1])
sc, scores = eval_model(best_model)
wte = best_model.wte.weight.detach().numpy()
norms = np.linalg.norm(wte, axis=1)
angles = np.arctan2(wte[:, 1], wte[:, 0]) * 180 / np.pi
print(f'\n  GEOMETRY ANALYSIS of best model:')
print(f'  Circle test: std(norms)/mean = {norms.std() / norms.mean():.4f}  (0=perfect circle)')
print(f'  Token norms: min={norms.min():.3f}  max={norms.max():.3f}  mean={norms.mean():.3f}')
angle_order = np.argsort(np.arctan2(wte[:, 1], wte[:, 0]))
print(f'\n  Tokens in angle order (clockwise):')
print(f'  {angle_order.tolist()}')
raw_angles = np.arctan2(wte[:, 1], wte[:, 0])
print(f'\n  Are consecutive numbers adjacent on circle?')
diffs = []
for i in range(VS - 1):
    d = raw_angles[i + 1] - raw_angles[i]
    if d > math.pi:
        d -= 2 * math.pi
    if d < -math.pi:
        d += 2 * math.pi
    diffs.append(abs(d))
print(f'  Mean angle diff between i and i+1: {np.mean(diffs) * 180 / math.pi:.2f}°')
print(f'  Std: {np.std(diffs) * 180 / math.pi:.2f}°  (low std = regular spacing)')
fib_tokens = list(dict.fromkeys([f % VS for f in fib[:20]]))
fib_angles = raw_angles[fib_tokens]
print(f'\n  Fibonacci token positions (angle):')
for tok, ang in zip(fib_tokens, fib_angles):
    print(f'    token {tok:>3}: {ang * 180 / math.pi:>8.2f}°  norm={norms[tok]:.3f}')
plot_geometry(best_model, 'BEST_FINAL', scores=scores)
print(f'\n  Images saved in: {_dir}')
print(f'  Files: scriptA_run0_step100.png  ← early geometry')
print(f'         scriptA_run0_step500.png')
print(f'         scriptA_run0_step1000.png')
print(f'         scriptA_run0_step2000.png')
print(f'         scriptA_run0_step5000.png ← late geometry')
print(f'         scriptA_run1_final.png through scriptA_run5_final.png')
print(f'         scriptA_BEST_FINAL.png    ← best model geometry')
print(f'\n  WHAT TO LOOK FOR IN THE PLOTS:')
print(f'  1. Do tokens form a circle?')
print(f'  2. Do fibonacci tokens cluster together?')
print(f'  3. Does the geometry evolve smoothly or jump?')
print(f'  4. Is there a consistent pattern across all 5 runs?')
print(f"\n  This tells us D=2's natural language for fibonacci.")
print('=' * 60)
