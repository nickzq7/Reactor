import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    if s < 10:
        return (float('nan'), float('nan'))
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    return (r2(Xb[:s] @ W, Y[:s]), r2(Xb[s:] @ W, Y[s:]))

def fit_multi(*arrays, Y, split=0.8):
    X = np.concatenate([np.array(a, dtype=np.float64) for a in arrays], axis=1)
    return fit_r2(X, Y, split)

def show(name, r2_tr, r2_te, width=60):
    if not np.isfinite(r2_te):
        print(f'  {name:<{width}} NaN')
        return
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<{width}} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
print(f'\nCollecting activations...')
stores = {k: {li: [] for li in range(n_layers)} for k in ['gelu', 'pre_gelu', 'h_layer', 'attn', 'h_after_attn', 'ln2_out', 'ln1_out']}
cur = {k: {li: None for li in range(n_layers)} for k in stores}
hooks = []
for li in range(n_layers):

    def make_g(l):

        def h(m, i, o):
            cur['gelu'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))

    def make_pg(l):

        def h(m, i, o):
            cur['pre_gelu'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].mlp.c_fc.register_forward_hook(make_pg(li)))

    def make_hl(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur['h_layer'][l] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].register_forward_hook(make_hl(li)))

    def make_a(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur['attn'][l] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_a(li)))

    def make_ha(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            cur['h_after_attn'][l] = inp.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ha(li)))

    def make_ln2(l):

        def h(m, i, o):
            cur['ln2_out'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ln2(li)))

    def make_ln1(l):

        def h(m, i, o):
            cur['ln1_out'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].ln_1.register_forward_hook(make_ln1(li)))
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly. Lily gently picked it up and held it close to her heart to keep it warm and safe.', 'The old farmer woke up very early every morning before the sun had risen in the sky above. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast eagerly. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding them he would go to the fields and work hard until the sun set.', 'Deep in the forest there was a small house where a family of bears lived together happily. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the nearby woods alone. One day the baby bear followed a butterfly deep into the forest and got lost.', 'There was once a brave young knight who lived in a castle near the tall mountains high above. He spent his days training hard with his sword and shield and riding his white horse. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go face the dragon and bring peace to all.', 'A small girl named Sophie loved books more than anything else in the whole wide world always. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her stories.', 'The little village sat quietly at the edge of a great forest full of ancient tall oak trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest time. Children would run through the market eating apples and drinking warm spiced cider joyfully. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him most. The first night Tommy shone the light and saw only his toys and books and nothing scary at all. His father explained that darkness was just the absence of light and nothing more.', 'The ocean was vast and blue and stretched as far as the eye could possibly see each day. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water safely. One night a terrible storm came and blew his boat far off course into unknown waters. When morning came he saw an island he had never seen before on any map.', 'High up in the mountains there was a small school where children came from very far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way always. Some children learned by reading and some by drawing and some by building things with their hands. She gave each child the lesson that matched the way their mind worked best.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below her. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak tree at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished with a rope ladder and a window.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the middle of the path and picked it up. The stone glowed with a soft blue light that pulsed slowly like a heartbeat in her paw. She brought it home and placed it in her burrow where it lit everything warmly.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest. She spent her days tending her garden and feeding the birds that came to visit her daily. Every evening she would sit by the fire and read her old favorite books by the warm light. One day a lost child appeared at her door cold and hungry and very frightened and alone. She welcomed the child inside and gave food and warmth and comfort without any hesitation.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day. The puppy was wet and cold and very hungry and it looked up at him with big sad eyes. Sam picked up the puppy and carried it home carefully to show his mother right away. His mother smiled and said they could keep it if Sam promised to care for it. Sam promised and from that day on the puppy followed him everywhere he went always.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone before ever. Every day she would watch the village below and wish she could play with the children there. One day a brave girl climbed the mountain and sat down quietly beside the small dragon. The dragon was surprised but did not fly away because the girl was very kind and gentle. They talked for hours and from that day they became the very best of friends.', 'In the deep blue ocean there lived a curious fish who wanted to see the world far above. Every day she would swim to the surface and peek at the sky and the tall green trees. One morning she jumped very high and for a moment she could see everything around her clearly. She saw hills and rivers and roads and tiny people walking far below in the distance. From that day she knew the world was much bigger than her small blue ocean.', 'The old clock in the corner of the room had not worked for many many long quiet years now. One rainy afternoon the little girl decided to try to fix it with her small toy tools. She turned the gears very carefully and wound the spring slowly and tightened every loose screw. Suddenly with a soft click and a gentle whir the old clock began to tick again steadily. The girl smiled proudly and her grandfather hugged her and said she was very clever.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below it. Rain fell gently on it for many days and the warm sun shone down on the earth. Slowly a small green shoot appeared pushing up through the dark soil toward the bright light. It grew taller every day stretching upward until it became a sapling strong and straight. Years later it had become a great tree itself with birds nesting in its leafy branches.', 'The young painter stood in front of the blank white canvas and did not know where to start. She dipped her brush in the bright blue paint and made one small careful stroke across it. Then she added yellow and red and slowly a beautiful sunrise began to appear before her eyes. She painted clouds and birds and a river winding through green fields in the valley below. When she finally finished she stepped back and saw it was the most beautiful thing she had made.', 'Every evening the grandfather would sit in his old wooden rocking chair and tell stories to the children. The children would gather around him and listen with wide open eyes in the warm firelight. His stories were always about adventures in faraway lands and magical creatures and brave young heroes. He remembered every detail perfectly and his voice rose and fell like music as he told them. The children never wanted the stories to end and always begged for just one more tale.']
with torch.no_grad():
    for text in long_texts:
        for k in cur:
            for li in range(n_layers):
                cur[k][li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        L = toks['input_ids'].shape[1]
        for li in range(n_layers):
            for k in stores:
                if cur[k][li] is not None:
                    arr = cur[k][li]
                    for t in range(min(L, arr.shape[0])):
                        stores[k][li].append(arr[t].copy())
for h in hooks:
    h.remove()
S = {k: {li: np.array(stores[k][li], dtype=np.float32) for li in range(n_layers)} for k in stores}
N = len(S['gelu'][0])
print(f'Tokens: {N}')
for k in S:
    if S[k][0].shape[0] > 0:
        print(f'  {k}: {S[k][0].shape}')
print(f"\n{'=' * 70}")
print(f'  TEST A — ln2_out → pre_gelu (ACTUAL LN2 output)')
print(f'  This is W1 @ ln2_out = pre_gelu. Pure linear. Must = 1.000.')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    r2_tr, r2_te = fit_r2(S['ln2_out'][li], S['pre_gelu'][li])
    show(f'  ln2_out_{li} → pre_gelu_{li}', r2_tr, r2_te)
print(f"\n{'=' * 70}")
print(f'  TEST B — manual LN2: (h_after_attn - mean)/std → pre_gelu')
print(f'  Apply natural space of LN2 manually. Should = 1.000.')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    h = S['h_after_attn'][li].astype(np.float64)
    pg = S['pre_gelu'][li].astype(np.float64)
    mu = h.mean(axis=1, keepdims=True)
    std = h.std(axis=1, keepdims=True) + 1e-05
    h_ln = (h - mu) / std
    r2_tr, r2_te = fit_r2(h_ln, pg)
    show(f'  manual_LN(h_after_attn_{li}) → pre_gelu_{li}', r2_tr, r2_te)
print(f"\n{'=' * 70}")
print(f'  TEST C — The LN2 gap')
print(f'  h_after_attn → ln2_out: how nonlinear is LN2?')
print(f'  This gap = why h_after_attn → pre_gelu was 0.994 not 1.000')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    r2_raw_ln2, r2_raw_ln2_te = fit_r2(S['h_after_attn'][li], S['ln2_out'][li])
    r2_norm_ln2, r2_norm_ln2_te = fit_r2((S['h_after_attn'][li] - S['h_after_attn'][li].mean(1, keepdims=True)) / (S['h_after_attn'][li].std(1, keepdims=True) + 1e-05), S['ln2_out'][li])
    show(f'  raw_h_{li} → ln2_out_{li}', r2_raw_ln2, r2_raw_ln2_te)
    show(f'  norm_h_{li} → ln2_out_{li}', r2_norm_ln2, r2_norm_ln2_te)
    print()
print(f"\n{'=' * 70}")
print(f'  TEST D — Full natural chain: every step R²=?')
print(f'  gelu_l → W2 → +attn → LN2_natural → W1 → pre_gelu_{{l+1}}')
print(f'  Each step measured in its natural space.')
print(f"{'=' * 70}\n")
for li in range(n_layers - 1):
    print(f'  ── Layer {li} → {li + 1} ──')
    r2_tr, r2_te = fit_r2(S['gelu'][li], S['h_layer'][li])
    show(f'    gelu_{li} → h_after_ffn_{li} (W2+residual)', r2_tr, r2_te)
    predicted = S['h_layer'][li].astype(np.float64) + S['attn'][li + 1].astype(np.float64)
    actual = S['h_after_attn'][li + 1].astype(np.float64)
    max_err = float(np.max(np.abs(predicted - actual)))
    r2_sum = r2(predicted, actual)
    print(f'    h_after_ffn_{li} + attn_{li + 1} = h_after_attn_{li + 1}:  R²={r2_sum:.6f}  max_err={max_err:.4f}')
    h = S['h_after_attn'][li + 1].astype(np.float64)
    mu = h.mean(1, keepdims=True)
    std = h.std(1, keepdims=True) + 1e-05
    h_ln = (h - mu) / std
    r2_tr, r2_te = fit_r2(h_ln, S['ln2_out'][li + 1])
    show(f'    norm(h_after_attn_{li + 1}) → ln2_out_{li + 1}', r2_tr, r2_te)
    r2_tr, r2_te = fit_r2(S['ln2_out'][li + 1], S['pre_gelu'][li + 1])
    show(f'    ln2_out_{li + 1} → pre_gelu_{li + 1} (W1)', r2_tr, r2_te)
    r2_tr, r2_te = fit_r2(S['pre_gelu'][li + 1], S['gelu'][li + 1])
    show(f'    pre_gelu_{li + 1} → gelu_{li + 1} (CRYSTAL)', r2_tr, r2_te)
    print()
print(f"\n{'=' * 70}")
print(f'  TEST E — KEY QUESTION: can we predict attn_{{l+1}} from h_l?')
print(f'  h_l → attn_{{l+1}}: R²=?')
print(f'  This = real answer to whether layer skipping is possible.')
print(f"{'=' * 70}\n")
print(f"  {'Predictor':<45} {'R²_te'}")
print(f"  {'─' * 55}")
for li in range(n_layers - 1):
    preds = [(f'h_layer_{li} → attn_{li + 1}', S['h_layer'][li]), (f'gelu_{li} → attn_{li + 1}', S['gelu'][li]), (f'pre_gelu_{li} → attn_{li + 1}', S['pre_gelu'][li]), (f'ln2_out_{li} → attn_{li + 1}', S['ln2_out'][li])]
    for name, X in preds:
        _, r2_te = fit_r2(X, S['attn'][li + 1])
        marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
        print(f'  {name:<45} {r2_te:.6f}  {marker}')
    _, r2_multi = fit_multi(S['h_layer'][li], S['gelu'][li], Y=S['attn'][li + 1].astype(np.float64))
    print(f"  [h_{li}, gelu_{li}] → attn_{li + 1}{'':17} {r2_multi:.6f}  " + ('✓✓ EXACT' if r2_multi > 0.9999 else '~  STRONG' if r2_multi > 0.95 else '·  PARTIAL' if r2_multi > 0.5 else '✗  LOW'))
    print()
print(f"\n{'=' * 70}")
print(f'  TEST F — Attention natural space')
print(f'  attn_l = W_o @ softmax_out (proven R²=1.000)')
print(f'  What predicts attn_l in its natural space?')
print(f'  h_l-1 → attn_l: does PREVIOUS layer h predict current attn?')
print(f"{'=' * 70}\n")
for li in range(1, n_layers):
    _, r2_prev_h = fit_r2(S['h_layer'][li - 1], S['attn'][li])
    _, r2_ln1 = fit_r2(S['ln1_out'][li], S['attn'][li])
    _, r2_ha = fit_r2(S['h_after_attn'][li], S['attn'][li])
    print(f'  Layer {li}: h_{li - 1}→attn_{li}: {r2_prev_h:.4f}  ln1_{li}→attn_{li}: {r2_ln1:.4f}  h_after_attn_{li}→attn_{li}: {r2_ha:.4f}')
print(f"\n{'=' * 70}")
print(f'  COMPLETE CRYSTAL CHAIN — FINAL LAWS')
print(f"{'=' * 70}")
print(f'\n  CONFIRMED NATURAL SPACES (each step):\n\n  LAYER l → LAYER l+1 — FULL PATH:\n\n    1. gelu_l → W2 → + h_in = h_after_ffn_l\n       Natural space: gelu space. R²=1.000. ✓ (proven)\n\n    2. h_after_ffn_l + attn_l+1 = h_after_attn_l+1\n       Linear sum. Exact. No law needed. ✓\n\n    3. h_after_attn_l+1 → LN2_l+1\n       CRYSTAL. Natural space = (h-mean)/std.\n       norm(h_after_attn) → ln2_out: R²=?\n       If 1.000: LN2 crystal proven in natural space. ✓\n\n    4. ln2_out_l+1 → W1 → pre_gelu_l+1\n       Linear. R²=1.000. ✓ (proven)\n\n    5. pre_gelu_l+1 → gelu_l+1\n       CRYSTAL. Cannot be 1.000 by design. ✓\n\n  CRYSTALS IN FULL MODEL (per layer):\n    LN1 → softmax (attention crystal)\n    LN2 → gelu (FFN crystal)\n    TOTAL: 4 crystals per layer. Not 2.\n\n  LN1 and LN2 are ALSO crystals.\n  Natural space = (h-mean)/std.\n  In natural space: R²=1.000.\n  Outside natural space: 0.994.\n\n  KEY QUESTION (TEST E):\n    h_l → attn_l+1: R²=?\n    If high: attention is compressible from residual.\n    If low: attention is irreducibly content-dependent.\n    This R² = the answer to 70B on laptop.\n')
print('=' * 70 + '\n')
