import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
n_heads = model.config.num_heads
FFN_D = D * 4
head_ffn = FFN_D // n_heads
print(f'D={D}  Layers={n_layers}  Heads={n_heads}  FFN_D={FFN_D}  head_ffn={head_ffn}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    if s < 10:
        return (float('nan'), float('nan'))
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    return (r2(Xb[:s] @ W, Y[:s]), r2(Xb[s:] @ W, Y[s:]))

def fit_r2_concat(X1, X2, Y, split=0.8):
    X = np.c_[X1, X2]
    return fit_r2(X, Y, split)

def show(name, r2_tr, r2_te, width=58):
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<{width}} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly in the shadows. Lily gently picked up the kitten and held it close to her heart to keep it warm.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding the animals he would go to the fields and work until the sun went down.', 'Deep in the forest there was a small house where a family of bears lived together happily. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the woods nearby. One day the baby bear followed a butterfly deep into the forest and got lost alone.', 'There was once a brave young knight who lived in a castle near the mountains high above. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go and face the dragon and bring peace to the kingdom.', 'A small girl named Sophie loved books more than anything else in the whole wide world today. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her stories directly.', 'The little village sat quietly at the edge of a great forest full of ancient tall trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest time. Children would run through the market eating apples and drinking warm spiced cider joyfully. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight came.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him. The first night Tommy shone the light and saw only his toys and books and nothing scary. His father explained that darkness was just the absence of light and nothing more.', 'The ocean was vast and blue and stretched as far as the eye could possibly see each day. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water. One night a terrible storm came and blew his boat far off course into unknown waters far. When morning came he saw an island he had never seen before on any map.', 'High up in the mountains there was a small school where children came from very far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way. Some children learned by reading and some by drawing and some by building things with hands. She gave each child the kind of lesson that matched the way their mind worked.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished and it had a rope ladder and window.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the path and picked it up. The stone glowed with a soft blue light that pulsed slowly like a heartbeat in her paw. She brought it home and placed it in her burrow where it lit up warmly.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest. She spent her days tending her garden and feeding the birds that came to visit her daily. Every evening she would sit by the fire and read her old favorite books by the light. One day a lost child appeared at her door cold and hungry and very frightened alone. She welcomed the child inside and gave food and warmth and comfort without hesitation.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day. The puppy was wet and cold and very hungry and it looked up at him with big eyes. Sam picked up the puppy and carried it home carefully to show his mother right away. His mother smiled and said they could keep the puppy if Sam promised to care for it. Sam promised and from that day on the puppy followed him everywhere he went.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone before. Every day she would watch the village below and wish she could play with the children there. One day a brave girl climbed the mountain and sat down quietly beside the dragon alone. The dragon was surprised but did not fly away because the girl was kind and gentle. They talked for hours and from that day became the best of friends forever.', 'In the deep blue ocean there lived a curious fish who wanted to see the world above it. Every day she would swim to the surface and peek at the sky and the tall green trees. One morning she jumped very high and for a moment she could see everything around her. She saw hills and rivers and roads and tiny people walking far below in distance. From that day she knew the world was much bigger than her small blue ocean.', 'The old clock in the corner of the room had not worked for many many long quiet years. One rainy afternoon the little girl decided to try to fix it with her small toy tools. She turned the gears carefully and wound the spring slowly and tightened every loose screw. Suddenly with a soft click and a gentle whir the clock began to tick again steadily. The girl smiled proudly and her grandfather hugged her and said she was very clever indeed.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below. Rain fell gently on it for many days and the warm sun shone down on the earth always. Slowly a small green shoot appeared pushing up through the dark soil toward the bright light. It grew taller every day stretching upward until it became a sapling strong and straight. Years later it was a great tree itself with birds nesting in its leafy branches.', 'The young painter stood in front of the blank white canvas and did not know where to start. She dipped her brush in the bright blue paint and made one small careful stroke across it. Then she added yellow and red and slowly a beautiful sunrise began to appear before her. She painted clouds and birds and a river winding through green fields in the valley. When she finished she stepped back and saw it was the most beautiful thing she made.', 'Every evening the grandfather would sit in his old wooden chair and tell stories to the children. The children would gather around him and listen with wide open eyes in the warm firelight. His stories were always about adventures in faraway lands and magical creatures and brave young heroes. He remembered every detail perfectly and his voice rose and fell like music as he spoke. The children never wanted the stories to end and always begged for just one more tale.']
print(f'\nCollecting gelu + attention activations all layers...')
gelu_store = {li: [] for li in range(n_layers)}
attn_store = {li: [] for li in range(n_layers)}
cur_gelu = {li: None for li in range(n_layers)}
cur_attn = {li: None for li in range(n_layers)}
hooks = []
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur_gelu[l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
for li in range(n_layers):

    def make_a(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur_attn[l] = o.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_a(li)))
with torch.no_grad():
    for text in long_texts:
        for li in range(n_layers):
            cur_gelu[li] = None
            cur_attn[li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        L = toks['input_ids'].shape[1]
        for li in range(n_layers):
            if cur_gelu[li] is not None:
                for t in range(L):
                    gelu_store[li].append(cur_gelu[li][t].copy())
                    attn_store[li].append(cur_attn[li][t].copy())
for h in hooks:
    h.remove()
G = {li: np.array(gelu_store[li], dtype=np.float32) for li in range(n_layers)}
A = {li: np.array(attn_store[li], dtype=np.float32) for li in range(n_layers)}
N = len(G[0])
print(f'Tokens per layer: {N}')
print(f"\n{'=' * 70}")
print(f'  MISSING 1 — Full N×N crystal prediction matrix')
print(f'  Every layer as seed → every other layer as target')
print(f'  R² grid: rows=seed, cols=target')
print(f"{'=' * 70}\n")
matrix = np.zeros((n_layers, n_layers))
for seed in range(n_layers):
    row = []
    for tgt in range(n_layers):
        if seed == tgt:
            matrix[seed][tgt] = 1.0
            row.append('  1.000')
        else:
            _, r2_te = fit_r2(G[seed], G[tgt])
            matrix[seed][tgt] = r2_te if np.isfinite(r2_te) else 0.0
            row.append(f'  {r2_te:.3f}')
    print(f"  seed={seed}  [{' '.join(row)}  ]")
print(f'\n  Column max (best seed for each target):')
for tgt in range(n_layers):
    col = matrix[:, tgt]
    col[tgt] = 0
    best_seed = int(np.argmax(col))
    best_r2 = float(np.max(col))
    print(f'  target gelu_{tgt}: best seed = gelu_{best_seed}  R²={best_r2:.4f}')
print(f'\n  Row max (which target each seed predicts best):')
for seed in range(n_layers):
    row = matrix[seed, :].copy()
    row[seed] = 0
    best_tgt = int(np.argmax(row))
    best_r2 = float(np.max(row))
    print(f'  seed gelu_{seed}: best target = gelu_{best_tgt}  R²={best_r2:.4f}')
print(f"\n{'=' * 70}")
print(f'  MISSING 2 — Attention bridge')
print(f'  Does gelu_l + attn_l → gelu_l+1 close the gap?')
print(f'  Chain gap was 0.05-0.13. What fills it?')
print(f"{'=' * 70}\n")
print(f"  {'Test':<50} {'R²_te (gelu only)':<22} {'R²_te (gelu+attn)'}")
print(f"  {'─' * 80}")
for li in range(n_layers - 1):
    _, r2_gelu = fit_r2(G[li], G[li + 1])
    _, r2_both = fit_r2_concat(G[li], A[li], G[li + 1])
    lift = r2_both - r2_gelu
    marker = '✓✓ CLOSED' if r2_both > 0.9999 else '✓  NEAR' if r2_both > 0.999 else '~  BETTER' if lift > 0.01 else '· NO HELP'
    print(f'  gelu_{li}+attn_{li} → gelu_{li + 1:<20} {r2_gelu:.4f}               {r2_both:.4f}  {marker}  lift={lift:+.4f}')
print(f'\n  What if we use NEXT layer attention (attn at l+1)?')
for li in range(n_layers - 1):
    _, r2_both = fit_r2_concat(G[li], A[li + 1], G[li + 1])
    _, r2_gelu = fit_r2(G[li], G[li + 1])
    lift = r2_both - r2_gelu
    print(f'  gelu_{li}+attn_{li + 1} → gelu_{li + 1}:  R²={r2_both:.4f}  lift={lift:+.4f}')
print(f"\n{'=' * 70}")
print(f'  MISSING 3 — Rotation matrix: fixed law or content-dependent?')
print(f'  Fit rotation R_l on first half. Apply to second half.')
print(f'  R² on second half = how fixed is the rotation?')
print(f'  Fixed R²=1.000: rotation is a law. Same for all tokens.')
print(f'  R² drops: rotation depends on content. Not a fixed law.')
print(f"{'=' * 70}\n")
n = N
half = n // 2
for li in range(1, n_layers):
    X_tr = G[0][:half].astype(np.float64)
    Y_tr = G[li][:half].astype(np.float64)
    Xb = np.c_[X_tr, np.ones(half)]
    try:
        W_rot = np.linalg.lstsq(Xb, Y_tr, rcond=None)[0]
    except:
        continue
    X_te = G[0][half:].astype(np.float64)
    Y_te = G[li][half:].astype(np.float64)
    Xb_te = np.c_[X_te, np.ones(n - half)]
    pred = Xb_te @ W_rot
    r2_te = r2(pred, Y_te)
    marker = '✓✓ FIXED LAW' if r2_te > 0.9999 else '✓  NEAR FIXED' if r2_te > 0.999 else '~  MOSTLY FIXED' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  CONTENT-DEP'
    print(f'  Rotation gelu_0→gelu_{li}: R²_te={r2_te:.6f}  {marker}')
print(f"\n{'=' * 70}")
print(f'  MISSING 4 — Per-head crystal resonance')
print(f'  Split FFN_D={FFN_D} into {n_heads} slices of {head_ffn} dims')
print(f'  Test: gelu_0[head_h] → gelu_l[head_h] per head')
print(f'  Maybe per-head resonance = 1.000')
print(f"{'=' * 70}\n")
print(f"  {'Pair':<25} {'mean_R²':<12} {'min_R²':<12} {'max_R²':<12} {'Pattern'}")
print(f"  {'─' * 65}")
for li in [1, 3, 5, 7]:
    head_r2s = []
    for h_idx in range(n_heads):
        s = h_idx * head_ffn
        e = s + head_ffn
        g0_h = G[0][:, s:e]
        gl_h = G[li][:, s:e]
        _, rv = fit_r2(g0_h, gl_h)
        if np.isfinite(rv):
            head_r2s.append(rv)
    if head_r2s:
        mean_r = float(np.mean(head_r2s))
        min_r = float(np.min(head_r2s))
        max_r = float(np.max(head_r2s))
        marker = '✓✓ EXACT' if mean_r > 0.9999 else '✓  NEAR' if mean_r > 0.999 else '~  STRONG' if mean_r > 0.95 else '·  PARTIAL' if mean_r > 0.5 else '✗  LOW'
        print(f'  gelu_0→gelu_{li} per-head:   {mean_r:.4f}      {min_r:.4f}      {max_r:.4f}      {marker}')
print(f'\n  Per-head chain: gelu_l → gelu_l+1 per head')
for li in range(n_layers - 1):
    head_r2s = []
    for h_idx in range(n_heads):
        s = h_idx * head_ffn
        e = s + head_ffn
        _, rv = fit_r2(G[li][:, s:e], G[li + 1][:, s:e])
        if np.isfinite(rv):
            head_r2s.append(rv)
    if head_r2s:
        mean_r = float(np.mean(head_r2s))
        max_r = float(np.max(head_r2s))
        print(f'  Chain {li}→{li + 1} per-head:  mean={mean_r:.4f}  max={max_r:.4f}')
print(f"\n{'=' * 70}")
print(f'  MISSING 5 — Rank of crystal transformation')
print(f'  gelu_0 → gelu_7 via rank-k approximation')
print(f'  Minimum rank for R²>0.99 = true information dimension')
print(f"{'=' * 70}\n")

def fit_rank_k(X, Y, k, split=0.8):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    n = len(X64)
    s = int(n * split)
    Xc = X64 - X64.mean(axis=0)
    U, S_x, Vt = np.linalg.svd(Xc, full_matrices=False)
    X_k = U[:, :k] * S_x[:k]
    Xb = np.c_[X_k, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y64[:s], rcond=None)[0]
        pred = Xb[s:] @ W
        return r2(pred, Y64[s:])
    except:
        return float('nan')
print(f'  Rank  R²(gelu_0→gelu_7)  R²(gelu_0→gelu_4)  R²(gelu_0→gelu_1)')
print(f"  {'─' * 60}")
for k in [1, 2, 4, 8, 16, 32, 64, 128, 256]:
    if k > FFN_D:
        break
    r2_7 = fit_rank_k(G[0], G[7], k)
    r2_4 = fit_rank_k(G[0], G[4], k)
    r2_1 = fit_rank_k(G[0], G[1], k)
    marker = '✓ R²>0.99' if r2_7 > 0.99 else '~ R²>0.95' if r2_7 > 0.95 else '· partial'
    print(f'  k={k:<6} {r2_7:<22.4f} {r2_4:<22.4f} {r2_1:.4f}  {marker}')
print(f'\n  Minimum rank for chain R²>0.99 per step:')
for li in range(n_layers - 1):
    for k in [1, 2, 4, 8, 16, 32, 64, 128, 256]:
        if k > FFN_D:
            break
        rv = fit_rank_k(G[li], G[li + 1], k)
        if rv > 0.99:
            print(f'  Chain {li}→{li + 1}: rank={k}  R²={rv:.4f}')
            break
print(f"\n{'=' * 70}")
print(f'  TEST 3 COMPLETE — CRYSTAL RESONANCE FINAL')
print(f"{'=' * 70}")
print(f'\n  KEY QUESTIONS ANSWERED:\n\n  1. Which seed predicts best?\n     See N×N matrix. Best seed column.\n     If adjacent layer always best: chain resonance.\n     If layer 0 beats all: seed resonance.\n     If middle layer best: core resonance.\n\n  2. Does attention close the gap?\n     gelu_l + attn_l → gelu_l+1 = R²?\n     If 1.000: gap = exactly what attention adds.\n     Attention = the bridge between crystals. Proven.\n\n  3. Is rotation fixed?\n     If R²=1.000 on held-out data: rotation is a law.\n     Same W for all tokens. Deterministic. Fixed.\n     Implication: learn W once. Apply everywhere.\n\n  4. Per-head resonance?\n     If per-head R² > full R²:\n     Heads are the natural unit of crystal resonance.\n     Not full FFN. Per-head FFN.\n     Compress at head level not model level.\n\n  5. Minimum rank?\n     k where R²>0.99 = true dimension of crystal info.\n     k=8 means: 8 numbers per token = full crystal.\n     k=256 means: need all dims. No compression possible.\n     Low k = massive compression possible. Real speedup.\n')
print('=' * 70 + '\n')
