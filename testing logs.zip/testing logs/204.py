import subprocess, sys, os

def ensure(package, import_name=None):
    name = import_name or package
    try:
        __import__(name)
    except ImportError:
        print(f'  Installing {package}...')
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', package, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W KERNEL TEXT GENERATOR')
print('  Original model vs W kernel — side by side')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
n_layers = model.config.num_layers
hidden_dim = model.config.hidden_size
lm_head = model.lm_head.weight.detach().numpy()
print(f'  Loaded. {n_layers} layers. {hidden_dim}D hidden.')
print('\n  Building W kernel from model knowledge...')
sentences = ['once upon a time there was a little girl named lily', 'the dog ran fast through the green field near home', 'a boy found a red ball near the big river today', 'the cat sat on the warm mat beside the fire', 'she picked flowers and smiled at her mother warmly', 'he walked slowly down the quiet road in the rain', 'the bird flew high above the tall trees at dawn', 'a small fish swam in the clear blue lake alone', 'the children played happily together in the sunny yard', 'the old man sat quietly under the big oak tree', 'she opened the door and looked outside at the snow', 'he found a little puppy sleeping near the old house', 'the sun rose slowly over the distant green hills today', 'a rabbit jumped quickly and hid deep in the bushes', 'the little boy cried and ran fast to his mother', 'she baked warm cookies for all the happy children', 'the moon shone bright and clear over the quiet town', 'a dragon lived deep inside the cold and dark cave', 'the princess waited alone in the tall grey stone tower', 'he climbed the tall tree to find his lost kite', 'the wind blew cold and strong across the open field', 'a tiny mouse found a piece of cheese near the wall', 'the farmer woke up early and went to feed animals', 'she drew a colorful picture of her family and house', 'the train moved slowly through the high snowy mountains', 'a baby elephant splashed and played in the muddy water', 'the kind teacher read a long story to the students', 'he closed his eyes and wished upon the first star', 'the snow fell softly and quietly on the sleeping village', 'a kind old woman gave warm bread to hungry children', 'the puppy wagged its tail happily and barked very loud', 'she sang a sweet lullaby to help the baby sleep', 'the brave knight rode his horse into the dark forest', 'a young fox carefully learned to hunt from his mother', 'the flowers bloomed bright and beautiful in the spring sun', 'he discovered a hidden door behind the old bookshelf', 'the butterfly landed gently on a beautiful red rose', 'a little girl lost her way deep in the big woods', 'the friendly giant woke up and smiled at the village', 'she found a shiny magic stone beside the old stone well', 'the little cat chased the butterfly through the green garden', 'a brave boy climbed the mountain to see the whole world', 'the friendly witch made a magic potion in her cottage', 'a small boat sailed across the wide and quiet blue lake', 'the baby bear found honey in the hollow old oak tree', 'she whispered a secret to her best friend in school', 'the rainbow appeared after the long and heavy rain fell', 'a clever fox tricked the big wolf and ran away fast', 'the little prince lived alone on a very small planet', 'a kind fairy granted three wishes to the poor farmer', 'the young knight saved the princess from the dark tower', 'a little seed grew into a tall and beautiful flower', 'the old wizard taught the boy how to use magic', 'she found a lost kitten crying in the cold rain', 'the two friends walked together through the enchanted forest', 'a giant friendly bear helped the children find their way', 'the little mermaid swam up to see the bright stars', 'a boy named jack climbed the tall beanstalk to the sky', 'the kind queen shared her food with all the hungry people', 'a little duck learned to swim in the warm sunny pond']
H_inputs, H_outputs = ([], [])
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=32, truncation=True)
        ids = tokens['input_ids']
        if ids.shape[1] < 4:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        seq = ids.shape[1]
        for pos in range(1, seq - 1):
            H_inputs.append(hs[0][0, pos].numpy())
            H_outputs.append(hs[-1][0, pos].numpy())
H_in = np.array(H_inputs)
H_out = np.array(H_outputs)
K = np.linalg.lstsq(H_in, H_out, rcond=None)[0]
kernel_mem = K.size * 4
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
print(f'  W kernel built.')
print(f'  Kernel shape  : {K.shape}')
print(f'  Kernel memory : {kernel_mem / 1024 / 1024:.3f} MB')
print(f'  Model memory  : {model_mem / 1024 / 1024:.1f} MB')
print(f'  Compression   : {model_mem / kernel_mem:.0f}x smaller')

def w_kernel_forward(input_ids, K, model):
    with torch.no_grad():
        h = model.transformer.wte(input_ids).detach().numpy()
        seq_len = h.shape[1]
        h_out = np.zeros_like(h)
        for pos in range(seq_len):
            h_out[0, pos] = h[0, pos] @ K
        logits = h_out[0] @ lm_head.T
    return logits

def w_kernel_generate(prompt, max_new_tokens=60):
    input_ids = tokenizer.encode(prompt, return_tensors='pt')
    generated = input_ids[0].tolist()
    for _ in range(max_new_tokens):
        ids = torch.tensor([generated])
        logits = w_kernel_forward(ids, K, model)
        next_token_logits = logits[-1]
        next_token = int(np.argmax(next_token_logits))
        if next_token == tokenizer.eos_token_id:
            break
        generated.append(next_token)
    return tokenizer.decode(generated, skip_special_tokens=True)

def original_generate(prompt, max_new_tokens=60):
    input_ids = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(input_ids, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)
print('\n' + '=' * 62)
print('  SIDE BY SIDE TEXT GENERATION')
print('  Original model (8 layers, 14.3MB)')
print('  vs')
print(f'  W kernel (1 matrix, {kernel_mem / 1024 / 1024:.3f}MB)')
print('=' * 62)
prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'A boy named Tom found a magic', 'The princess looked out the window and', 'One day a small rabbit decided to']
for i, prompt in enumerate(prompts):
    print(f"\n  {'─' * 58}")
    print(f'  PROMPT {i + 1}: "{prompt}"')
    print(f"  {'─' * 58}")
    orig_text = original_generate(prompt, max_new_tokens=40)
    print(f'\n  ORIGINAL (14.3MB, 8 layers):')
    words = orig_text.split()
    line = '  '
    for w in words:
        if len(line) + len(w) > 57:
            print(line)
            line = '  ' + w + ' '
        else:
            line += w + ' '
    if line.strip():
        print(line)
    kern_text = w_kernel_generate(prompt, max_new_tokens=40)
    print(f'\n  W KERNEL ({kernel_mem / 1024 / 1024:.3f}MB, 1 matrix):')
    words = kern_text.split()
    line = '  '
    for w in words:
        if len(line) + len(w) > 57:
            print(line)
            line = '  ' + w + ' '
        else:
            line += w + ' '
    if line.strip():
        print(line)
    orig_words = set(orig_text.lower().split())
    kern_words = set(kern_text.lower().split())
    overlap = len(orig_words & kern_words) / max(len(orig_words), 1)
    print(f'\n  Word overlap with original: {overlap * 100:.0f}%')
print('\n' + '=' * 62)
print('  SUMMARY')
print('=' * 62)
print(f'\n  Original model:\n    Layers  : {n_layers}\n    Memory  : {model_mem / 1024 / 1024:.1f} MB\n    Generates coherent English stories.\n\n  W kernel:\n    Layers  : 1 matrix  ({K.shape[0]}×{K.shape[1]})\n    Memory  : {kernel_mem / 1024 / 1024:.3f} MB\n    Compression: {model_mem / kernel_mem:.0f}x smaller\n    Generates: see output above\n\n  For 70B model:\n    Original : ~140,000 MB (140 GB)\n    W kernel : ~256 MB\n    Reduction: ~550x\n    Fits 6GB : YES\n\n  If W kernel output above is coherent —\n  the principle works for generation.\n  Not just token prediction numbers.\n  Actual readable text.\n  Same principle. Scale to 70B.\n')
print('=' * 62 + '\n')
