import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (LONG-FORM VALIDATION)')
print('  Comparing Standard Logic vs. Fuzzy Hub Jumps (100 Token Target)')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
HAMMING_THRESHOLD = 4
print('\n  [ Phase 1 ] Mapping Semantic Hubs (Massive Saturation)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden', 'A clever fox hid in the bushes', 'The farmer planted seeds in the soil', 'A little mouse found a piece of cheese', 'The wizard used a magic wand', 'The ocean waves hit the sandy beach', 'A big elephant walked slowly', 'The squirrel gathered nuts for winter', 'A happy family went on a picnic', 'The clock on the wall struck twelve', 'A brave hero saved the day']
RAM_bits = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_pre = {l: [] for l in range(n_layers)}

def hook_pre_gelu(l):

    def hook(m, i, o):
        store_pre[l].append(o[:, -1, :].detach().cpu().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.act.register_forward_hook(hook_pre_gelu(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        for _ in range(35):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                bits = (store_pre[l].pop()[0] > 0).astype(int)
                RAM_bits[l].append(bits)
                RAM_sequences[l].append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    bits = np.array(RAM_bits[l])
    tokens = np.array(RAM_sequences[l])
    seqs = []
    for i in range(len(tokens) - JUMP_LENGTH):
        seqs.append(tokens[i:i + JUMP_LENGTH])
    RAM_bits[l] = bits[:len(seqs)]
    RAM_sequences[l] = np.array(seqs)
print(f'  ✓ Saturated {len(RAM_sequences[0])} Hubs. Ready for long-form race.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 100
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] THE RACE: NORMAL vs. W-HUB (100 Tokens)')
print('─' * 75)
start_time = time.time()
pt_ids = tokenizer.encode(test_prompt, return_tensors='pt')
with torch.no_grad():
    for _ in range(tokens_to_gen):
        out = model(pt_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        pt_ids = torch.cat([pt_ids, torch.tensor([[next_id]])], dim=1)
normal_time = time.time() - start_time
normal_text = tokenizer.decode(pt_ids[0])
current_state = {l: None for l in range(n_layers)}

def get_live_hook(l):

    def hook(m, i, o):
        current_state[l] = (o[:, -1, :].detach().cpu().numpy() > 0).astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_live_hook(l)) for l in range(n_layers)]
start_time = time.time()
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
jumps_done = 0
total_gen_hub = 0
layers_saved = 0
with torch.no_grad():
    while total_gen_hub < tokens_to_gen:
        out = model(hub_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        jump_found = False
        for l in range(3, n_layers):
            bits = current_state[l]
            mismatches = 256 - np.sum(RAM_bits[l] == bits, axis=1)
            best_match_idx = np.argmin(mismatches)
            if mismatches[best_match_idx] <= HAMMING_THRESHOLD:
                speculative_seq = RAM_sequences[l][best_match_idx]
                jump_tensor = torch.tensor(np.array([speculative_seq]))
                hub_ids = torch.cat([hub_ids, jump_tensor], dim=1)
                num_new_tokens = len(speculative_seq)
                total_gen_hub += num_new_tokens
                jumps_done += 1
                layers_saved += n_layers - l + n_layers * (num_new_tokens - 1)
                jump_found = True
                break
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[next_id]])], dim=1)
            total_gen_hub += 1
hub_time = time.time() - start_time
hub_text = tokenizer.decode(hub_ids[0])
for h in live_hooks:
    h.remove()
print(f'\n[ NORMAL MODEL (100 Tokens) ]:\n{normal_text}')
print(f'\n[ W-HUB ENGINE (100 Tokens) ]:\n{hub_text}')
print('\n' + '=' * 75)
print('  FINAL VALIDATION RESULTS')
print('=' * 75)
print(f'  Standard Time       : {normal_time:.4f}s')
print(f'  W-Hub Time          : {hub_time:.4f}s')
print(f'  Successful Jumps    : {jumps_done}')
total_layers_possible = total_gen_hub * n_layers
efficiency = layers_saved / total_layers_possible * 100
print(f'  Compute Efficiency  : {efficiency:.1f}% operations skipped')
match_status = 'FLAWLESS' if normal_text[:150] == hub_text[:150] else 'SEMANTIC DRIFT'
print(f'  Match Accuracy      : {match_status}')
print('\n  THE INTERPRETER WALL:')
print("  Note that W-Hub Time reflects Python's list-searching overhead.")
print("  In a compiled C++ environment, the 'Compute Efficiency' is")
print('  the metric that dictates power consumption and true speed.')
print('=' * 75 + '\n')
