import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — SEMANTIC RAM v2')
print('  Does 256-bit GeLU pattern generalize to new prompts?')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
att_layers = getattr(model.config, 'attention_layers', ['global'] * n_layers)
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={n_layers}')
print(f'  256-bit address space = 2^{FFN_D} possible addresses')
print(f'  Vocabulary size = {model.config.vocab_size}')
LW = {}
with torch.no_grad():
    for l in range(n_layers):
        blk = model.transformer.h[l]
        att = blk.attn.attention
        LW[l] = {'Wq': att.q_proj.weight.detach().numpy(), 'Wk': att.k_proj.weight.detach().numpy(), 'Wv': att.v_proj.weight.detach().numpy(), 'Wo': att.out_proj.weight.detach().numpy(), 'bo': att.out_proj.bias.detach().numpy(), 'W1': blk.mlp.c_fc.weight.detach().numpy(), 'b1': blk.mlp.c_fc.bias.detach().numpy(), 'W2': blk.mlp.c_proj.weight.detach().numpy(), 'b2': blk.mlp.c_proj.bias.detach().numpy(), 'ln1_w': blk.ln_1.weight.detach().numpy(), 'ln1_b': blk.ln_1.bias.detach().numpy(), 'ln2_w': blk.ln_2.weight.detach().numpy(), 'ln2_b': blk.ln_2.bias.detach().numpy()}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu_new(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def forward_get_pre_gelu_L7(token_ids):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
    for l in range(n_layers):
        W = LW[l]
        ln1 = ln_np(x, W['ln1_w'], W['ln1_b'])
        Q = ln1 @ W['Wq'].T
        K = ln1 @ W['Wk'].T
        V = ln1 @ W['Wv'].T
        Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        heads = []
        for h in range(n_heads):
            sc = Qh[h] @ Kh[h].T
            heads.append(softmax_np(sc + mask) @ Vh[h])
        concat = np.stack(heads, 1).reshape(seq_len, D)
        att_out = concat @ W['Wo'].T + W['bo']
        x = x + att_out
        ln2 = ln_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['W1'].T + W['b1']
        if l == n_layers - 1:
            pre_gelu_last = pre[-1]
            g = gelu_new(pre)
            ffn_out = g @ W['W2'].T + W['b2']
            x = x + ffn_out
            h_f = ln_np(x, lnf_w, lnf_b)
            logits = (h_f[-1:] @ lm_w.T)[0]
            true_next = int(np.argmax(logits))
            return (pre_gelu_last, true_next)
        else:
            g = gelu_new(pre)
            ffn_out = g @ W['W2'].T + W['b2']
            x = x + ffn_out
print(f"\n{'=' * 66}")
print(f'  PHASE 1 — BUILD SEMANTIC RAM FROM SET A')
print(f'  These prompts populate the address book.')
print(f"{'=' * 66}\n")
SET_A = ['Once upon a time', 'The little girl smiled', 'A brave knight rode', 'Deep in the forest', 'The old woman said', 'Every morning the bird', 'She opened the door', 'The dragon flew over', 'A tiny seed grew', 'The children laughed and', 'He wished upon a star', 'The magic spell worked', 'Her mother called her name', 'The sun was very bright', 'They walked together slowly', 'A rainbow appeared after', 'The dog found a bone', 'Once there was a king', 'The baby bear said', 'A yellow duck swam', 'The snow fell softly', 'He ran very fast', 'The cat sat on', 'She drew a picture', 'The wind blew hard']
ram_bits_list = []
ram_tokens = []
ram_pre_list = []
print(f'  Building RAM from {len(SET_A)} seed prompts (20 tokens each)...')
ids_by_prompt = []
for prompt in SET_A:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for step in range(20):
        pre, true_next = forward_get_pre_gelu_L7(ids)
        bits = (pre > 0).astype(np.int8)
        ram_bits_list.append(bits)
        ram_tokens.append(true_next)
        ram_pre_list.append(pre)
        ids.append(true_next)
RAM_bits = np.array(ram_bits_list, dtype=np.int8)
RAM_tokens = np.array(ram_tokens, dtype=np.int32)
RAM_pre = np.array(ram_pre_list, dtype=np.float32)
print(f'  RAM loaded: {len(RAM_bits)} entries')
print(f'  Unique tokens covered: {len(np.unique(RAM_tokens))}')
print(f'  RAM size: {RAM_bits.nbytes / 1024:.1f} KB (bits) + {RAM_pre.nbytes / 1024:.1f} KB (floats)')
print(f"\n{'=' * 66}")
print(f'  PHASE 2 — GENERALIZATION TEST ON SET B')
print(f'  These prompts were NEVER seen during RAM building.')
print(f"{'=' * 66}\n")
SET_B = ['The princess looked at', 'In a land far away', 'The wizard learned that', 'A small fish swam', 'The farmer planted seeds', 'Her eyes were blue', 'The train arrived at', 'A monkey climbed the']
print(f"  {'Step':<6} {'True token':<18} {'RAM token':<18} {'overlap%':<10} {'correct?'}")
print(f"  {'─' * 62}")
total_tokens = 0
correct_exact = 0
correct_top3 = 0
overlap_when_correct = []
overlap_when_incorrect = []
for prompt in SET_B:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for step in range(15):
        pre, true_next = forward_get_pre_gelu_L7(ids)
        bits = (pre > 0).astype(np.int8)
        overlaps = np.sum(RAM_bits == bits[np.newaxis, :], axis=1)
        best_idx = np.argmax(overlaps)
        ram_next = int(RAM_tokens[best_idx])
        overlap_pct = 100.0 * overlaps[best_idx] / FFN_D
        top3_idx = np.argsort(overlaps)[-3:][::-1]
        top3_tokens = RAM_tokens[top3_idx]
        is_correct = ram_next == true_next
        in_top3 = true_next in top3_tokens
        if is_correct:
            correct_exact += 1
            overlap_when_correct.append(overlap_pct)
        else:
            overlap_when_incorrect.append(overlap_pct)
        if in_top3:
            correct_top3 += 1
        total_tokens += 1
        true_str = repr(tokenizer.decode([true_next]))[:16]
        ram_str = repr(tokenizer.decode([ram_next]))[:16]
        mark = '✓' if is_correct else '~' if in_top3 else '✗'
        print(f'  {step + 1:<6} {true_str:<18} {ram_str:<18} {overlap_pct:<10.1f}% {mark}')
        ids.append(true_next)
    print()
print(f'\n  GENERALIZATION RESULTS:')
print(f'  Total tokens tested:    {total_tokens}')
print(f'  Exact match:            {correct_exact}/{total_tokens} = {100 * correct_exact / total_tokens:.1f}%')
print(f'  Top-3 match:            {correct_top3}/{total_tokens} = {100 * correct_top3 / total_tokens:.1f}%')
if overlap_when_correct:
    print(f'  Mean overlap (correct): {np.mean(overlap_when_correct):.1f}%')
if overlap_when_incorrect:
    print(f'  Mean overlap (wrong):   {np.mean(overlap_when_incorrect):.1f}%')
print(f"\n{'=' * 66}")
print(f'  PHASE 3 — OVERLAP THRESHOLD')
print(f'  At what % overlap does the RAM prediction become reliable?')
print(f"{'=' * 66}\n")
threshold_results = {t: {'correct': 0, 'total': 0} for t in [70, 75, 80, 85, 90, 95, 100]}
for prompt in SET_B:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for step in range(15):
        pre, true_next = forward_get_pre_gelu_L7(ids)
        bits = (pre > 0).astype(np.int8)
        overlaps = np.sum(RAM_bits == bits[np.newaxis, :], axis=1)
        best_idx = np.argmax(overlaps)
        ram_next = int(RAM_tokens[best_idx])
        pct = 100.0 * overlaps[best_idx] / FFN_D
        for thresh in threshold_results:
            if pct >= thresh:
                threshold_results[thresh]['total'] += 1
                if ram_next == true_next:
                    threshold_results[thresh]['correct'] += 1
        ids.append(true_next)
print(f"  {'Threshold':<12} {'Covered':<12} {'Accuracy':<12} {'verdict'}")
print(f"  {'─' * 45}")
for t in sorted(threshold_results.keys()):
    r = threshold_results[t]
    if r['total'] > 0:
        acc = 100 * r['correct'] / r['total']
        cov = 100 * r['total'] / total_tokens
        v = '✓ EXACT' if acc == 100 else '✓ GOOD' if acc >= 90 else '~ USABLE' if acc >= 70 else '✗ POOR'
        print(f'  {t:<12}% {cov:<12.1f}% {acc:<12.1f}% {v}')
print(f"\n{'=' * 66}")
print(f'  PHASE 4 — VOCABULARY COVERAGE')
print(f'  How many of the 50,257 tokens have known RAM addresses?')
print(f"{'=' * 66}\n")
unique_tokens_in_ram = np.unique(RAM_tokens)
print(f'  Tokens with known addresses: {len(unique_tokens_in_ram)}')
print(f'  Total vocabulary:            {model.config.vocab_size}')
print(f'  Coverage:                    {100 * len(unique_tokens_in_ram) / model.config.vocab_size:.2f}%')
print(f'\n  Sample of covered tokens:')
sample = unique_tokens_in_ram[:30]
print(f'  {[tokenizer.decode([t]) for t in sample]}')
print(f"\n{'=' * 66}")
print(f'  FINAL SUMMARY — SEMANTIC RAM GENERALIZATION')
print(f"{'=' * 66}\n")
exact_pct = 100 * correct_exact / total_tokens
top3_pct = 100 * correct_top3 / total_tokens
print(f'\n  PHASE 1 RESULT (same prompt):\n    100% match — PROVEN in v1\n    256-bit pattern = exact token address for seen data.\n\n  PHASE 2 RESULT (new prompts):\n    Exact match: {exact_pct:.1f}%\n    Top-3 match: {top3_pct:.1f}%\n    \n  WHAT THIS MEANS:\n  \n  If exact match > 90% on new prompts:\n    256-bit GeLU pattern = universal semantic address.\n    W2 + lm_head = never needed.\n    Replace with 1.6MB address book.\n    Zero IO for final layer. Zero quality loss.\n    THIS IS THE BREAKTHROUGH.\n    \n  If exact match 50-90%:\n    Pattern partially generalizes.\n    Needs larger RAM bank (more prompts).\n    Or needs soft matching (cosine on floats not bits).\n    \n  If exact match < 50%:\n    Pattern is context-dependent.\n    Need full float vector, not just bits.\n    But SOFT RAM (cosine lookup on pre-GeLU floats)\n    may still replace lm_head entirely.\n    Test: pre-GeLU float cosine vs lm_head argmax.\n\n  THE REAL DISCOVERY EITHER WAY:\n    The answer is determined at GeLU crystal.\n    Everything after = translation not thinking.\n    W law showed us where the computation ends.\n    Sanskrit address at layer 7 pre-GeLU = the token.\n')
print('=' * 66 + '\n')
