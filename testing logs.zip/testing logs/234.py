import numpy as np
import math
import time
from collections import Counter
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL v12 — EXPLICIT CONTEXT WINDOW')
print('  No random attention. Direct sequence learning.')
print('  context=[WTE[t-K]...WTE[t-1]] → W-Kernel → next char')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do\n'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
tokens = [c2i[c] for c in TEXT]
freq = Counter(tokens)
total = len(tokens)
info_raw = {t: -math.log(freq[t] / total) for t in freq}
mn, mx = (min(info_raw.values()), max(info_raw.values()))
info_w = {t: 0.5 + 0.5 * (info_raw[t] - mn) / (mx - mn + 1e-08) for t in info_raw}
print(f'\n  Vocab={VS}  Tokens={len(tokens)}')
print(f"  Weights: space={info_w[c2i[' ']]:.2f}  e={info_w[c2i['e']]:.2f}  k={info_w[c2i['k']]:.2f}  z={info_w[c2i['z']]:.2f}")
K = 8
D_emb = VS
D_in = K * D_emb
D_h = 64
LAM = 0.001
CLIP = 3.0
LR = 0.25
N_ROUNDS = 50
print(f'\n  K={K} chars context  D_emb={D_emb} (one-hot)  D_in={D_in}')
print(f'  D_h={D_h}  LAM={LAM}')
print(f'  N/D_in = {len(tokens) // D_in:.1f}x  (need > 5 for stable solve)')
WTE = np.eye(VS, dtype=np.float64)

def get_context(ids, K):
    ctx = np.zeros(K * VS, dtype=np.float64)
    for i, tok in enumerate(ids[-K:]):
        pos = K - len(ids[-K:]) + i
        ctx[pos * VS:(pos + 1) * VS] = WTE[tok]
    return ctx

def init():
    rng = np.random.RandomState(42)
    w = {}
    w['W0'] = rng.randn(D_h, D_in).astype(np.float64) * 0.01
    w['b0'] = np.zeros(D_h)
    w['W1'] = np.eye(D_h, dtype=np.float64) * 0.1
    w['b1'] = np.zeros(D_h)
    w['W2'] = rng.randn(VS, D_h).astype(np.float64) * 0.01
    w['b2'] = np.zeros(VS)
    return w

def fwd(ctx_flat, w):
    h0 = np.tanh(w['W0'] @ ctx_flat + w['b0'])
    h1 = np.tanh(w['W1'] @ h0 + w['b1'])
    logits = w['W2'] @ h1 + w['b2']
    return (logits, h1, h0)

def ridge_w(X, Y, weights, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    W = np.array(weights, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    Wd = np.diag(W)
    A = Xb.T @ Wd @ Xb + lam * np.eye(Xb.shape[1])
    try:
        sol = np.linalg.solve(A, Xb.T @ (Wd @ Y))
    except:
        sol, _, _, _ = np.linalg.lstsq(Xb, Y, rcond=None)
    return np.clip(sol, -CLIP, CLIP)

def calc_ppl(w, n=500):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - K - 1) // n)
    for s in range(K, len(tokens) - 1, step):
        ctx_flat = get_context(tokens[max(0, s - K):s], K)
        tgt = tokens[s]
        try:
            logits, _, _ = fwd(ctx_flat, w)
            if not np.all(np.isfinite(logits)):
                continue
            lg = logits - logits.max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return 999.0
    return math.exp(min(nll / tok, 500))

def bigram_check(generated):
    text = ''.join((i2c.get(t, '?') for t in generated))
    bigrams = ['th', 'he', 'in', 'er', 'an', 're', 'on', 'en', 'at', 'nd']
    found = [bg for bg in bigrams if bg in text]
    return (found, text)
w = init()
p0 = calc_ppl(w)
print(f'\n  Random ppl={p0:.2f}  (unigram ≈ {math.log(VS):.1f} nats = {VS:.0f})\n')
BATCH = 600
best_ppl = p0
best_w = {k: v.copy() for k, v in w.items()}
hist = [p0]
t0 = time.time()
print(f"  {'Rnd':<5} {'PPL':>8} {'Best':>8}  Note")
print(f"  {'─' * 45}")
for rnd in range(N_ROUNDS):
    idxs = np.random.choice(range(K, len(tokens) - 1), BATCH, replace=False)
    X0 = []
    X1 = []
    X2 = []
    Y0 = []
    Y1 = []
    Y2 = []
    IW = []
    for idx in idxs:
        ctx_flat = get_context(tokens[max(0, idx - K):idx], K)
        nxt = tokens[idx]
        iw = info_w.get(nxt, 0.5)
        logits, h1, h0 = fwd(ctx_flat, w)
        if not np.all(np.isfinite(h0 + h1)):
            continue
        target_logit = WTE[nxt]
        X2.append(h1)
        Y2.append(target_logit)
        X1.append(h0)
        Y1.append(w['W2'].T @ target_logit)
        X0.append(ctx_flat)
        Y0.append(w['W1'].T @ (w['W2'].T @ target_logit))
        IW.append(iw)
    if len(X0) < 20:
        continue
    X0 = np.array(X0)
    X1 = np.array(X1)
    X2 = np.array(X2)
    Y0 = np.array(Y0)
    Y1 = np.array(Y1)
    Y2 = np.array(Y2)
    IW = np.array(IW)
    W2_new = ridge_w(X2, Y2, IW)
    w['W2'] = np.clip((1 - LR) * w['W2'] + LR * W2_new[:-1].T, -CLIP, CLIP)
    w['b2'] = np.clip((1 - LR) * w['b2'] + LR * W2_new[-1], -CLIP, CLIP)
    W1_new = ridge_w(X1, Y1, IW)
    w['W1'] = np.clip((1 - LR) * w['W1'] + LR * W1_new[:-1].T, -CLIP, CLIP)
    w['b1'] = np.clip((1 - LR) * w['b1'] + LR * W1_new[-1], -CLIP, CLIP)
    W0_new = ridge_w(X0, Y0, IW)
    w['W0'] = np.clip((1 - LR) * w['W0'] + LR * W0_new[:-1].T, -CLIP, CLIP)
    w['b0'] = np.clip((1 - LR) * w['b0'] + LR * W0_new[-1], -CLIP, CLIP)
    p = calc_ppl(w)
    hist.append(p)
    mark = ''
    if np.isfinite(p) and p < best_ppl:
        best_ppl = p
        best_w = {k: v.copy() for k, v in w.items()}
        mark = ' ★'
    arr = '↓' if p < hist[-2] else '↑'
    print(f'  {rnd + 1:<5} {p:>8.2f} {best_ppl:>8.2f}  {arr}{mark}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  ppl={best_ppl:.2f}  vocab={VS}  ratio={best_ppl / VS:.3f}')
print(f"{'=' * 70}\n")

def generate(prompt, n=150, temp=0.8, top_k=8, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        ctx = get_context(ids, K)
        logits, _, _ = fwd(ctx, w)
        if not np.all(np.isfinite(logits)):
            break
        lg = logits - logits.max()
        lg = lg / temp
        if top_k < len(lg):
            thresh = np.sort(lg)[-top_k]
            lg[lg < thresh] = -1000000000.0
        p = np.exp(lg)
        p /= p.sum()
        ids.append(int(np.random.choice(VS, p=p)))
    return ids
print('  GENERATION:\n')
for temp in [1.0, 0.8, 0.6]:
    print(f'  Temperature={temp}:')
    for prompt in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
        gen = generate(prompt, n=100, temp=temp)
        found_bg, text = bigram_check(gen)
        out = text[len(prompt):][:70]
        print(f"  '{prompt}' →")
        print(f'    {out}')
        print(f'    bigrams found: {found_bg}')
    print()
gen_d = generate('the ', n=300, temp=0.85)
text_d = ''.join((i2c.get(t, '?') for t in gen_d))
cnt = Counter(gen_d[4:])
space_pct = 100 * cnt.get(c2i[' '], 0) / len(gen_d[4:])
top5 = [(i2c[t], f'{100 * c // len(gen_d[4:])}%') for t, c in cnt.most_common(5)]
print(f'  Space% = {space_pct:.0f}%  (target ≈ 18%)')
print(f'  Top-5: {top5}')
print(f'  Sample 80 chars: {text_d[4:84]}')
print(f'\n  W0 BIGRAM ANALYSIS:')
print(f'  (shows what sequence patterns were learned)')
for prev_char in ['t', 'h', 'e', ' ', 'o', 'a']:
    if prev_char not in c2i:
        continue
    pc = c2i[prev_char]
    ctx = np.zeros(K * VS)
    ctx[-VS + pc] = 1.0
    logits, _, _ = fwd(ctx, w)
    lg = logits - logits.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = np.argsort(-p)[:3]
    preds = [(i2c[t], f'{100 * p[t]:.0f}%') for t in top3]
    print(f"  after '{prev_char}': {preds}")
print(f'\n  Time: {time.time() - t0:.0f}s')
print(f"\n{'=' * 70}")
if best_ppl < VS * 0.5:
    print(f'  ✓✓ ppl={best_ppl:.1f} — SEQUENCE LEARNING. Bigrams working.')
elif best_ppl < VS:
    print(f'  ✓  ppl={best_ppl:.1f} < {VS}. Below vocab ceiling.')
    print(f'     Check bigrams and space% for sequence evidence.')
print(f'\n  W-KERNEL ALGORITHM:')
print(f'  context=[one-hot(t-K)...one-hot(t-1)] → ridge → next')
print(f'  No gradient. No attention. No random mixing.')
print(f'  Pure W-Kernel on explicit sequence features.')
print('=' * 70 + '\n')
