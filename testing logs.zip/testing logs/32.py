import numpy as np
import torch
import torch.nn as nn
import math
from dataclasses import dataclass
from typing import Any, Optional
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
EPS = 1e-06

def build_library():
    lib = []

    def try_constant(seq):
        if len(set((round(x, 8) for x in seq))) == 1:
            v = seq[0]
            return ({'v': v}, lambda s: v, f'={v:.4g}')
        return None

    def try_arithmetic(seq):
        d = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]
        if not d:
            return None
        m = sum(d) / len(d)
        if all((abs(v - m) < EPS * (abs(m) + 1) for v in d)):
            return ({'d': m}, lambda s: s[-1] + m, f'last+{m:.4g}')
        return None

    def try_geometric(seq):
        if not all((abs(x) > EPS for x in seq)):
            return None
        r = [seq[i + 1] / seq[i] for i in range(len(seq) - 1)]
        if not r:
            return None
        m = sum(r) / len(r)
        if all((abs(v - m) < EPS * (abs(m) + 1) for v in r)):
            return ({'r': m}, lambda s: s[-1] * m, f'last×{m:.4g}')
        return None

    def try_fibonacci(seq):
        if len(seq) < 3:
            return None
        errs = [abs(seq[i] - seq[i - 1] - seq[i - 2]) for i in range(2, len(seq))]
        if all((e < EPS * (abs(seq[i]) + 1) for i, e in zip(range(2, len(seq)), errs))):
            return ({}, lambda s: s[-2] + s[-1], 'prev+last')
        return None

    def try_tribonacci(seq):
        if len(seq) < 4:
            return None
        errs = [abs(seq[i] - seq[i - 1] - seq[i - 2] - seq[i - 3]) for i in range(3, len(seq))]
        if all((e < EPS * (abs(seq[i]) + 1) for i, e in zip(range(3, len(seq)), errs))):
            return ({}, lambda s: s[-3] + s[-2] + s[-1], 'prev3+prev2+last')
        return None

    def try_quadratic(seq):
        if len(seq) < 3:
            return None
        d1 = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]
        d2 = [d1[i + 1] - d1[i] for i in range(len(d1) - 1)]
        if not d2:
            return None
        m = sum(d2) / len(d2)
        if all((abs(v - m) < EPS * (abs(m) + 1) for v in d2)):
            return ({'d2': m}, lambda s: s[-1] + (s[-1] - s[-2]) + m, f'last+d1+{m:.4g}')
        return None

    def try_cubic(seq):
        if len(seq) < 4:
            return None
        d1 = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]
        d2 = [d1[i + 1] - d1[i] for i in range(len(d1) - 1)]
        d3 = [d2[i + 1] - d2[i] for i in range(len(d2) - 1)]
        if not d3:
            return None
        m = sum(d3) / len(d3)
        if all((abs(v - m) < EPS * (abs(m) + 1) for v in d3)):
            d2l = d2[-1]
            d1l = d1[-1]

            def pred(s, m=m, d2l=d2l, d1l=d1l):
                nd2 = d2l + m
                nd1 = d1l + nd2
                return s[-1] + nd1
            return ({'d3': m}, pred, f'last+d1+d2+{m:.4g}')
        return None

    def try_factorial(seq):
        if len(seq) < 2:
            return None
        if not all((abs(x) > EPS for x in seq)):
            return None
        r = [seq[i + 1] / seq[i] for i in range(len(seq) - 1)]
        e = [float(i + 2) for i in range(len(r))]
        if all((abs(r[i] - e[i]) < EPS * (e[i] + 1) for i in range(len(r)))):
            return ({}, lambda s: s[-1] * (len(s) + 1), 'last×n')
        return None
    for name, fn, c in [('constant', try_constant, 1), ('arithmetic', try_arithmetic, 2), ('geometric', try_geometric, 3), ('fibonacci', try_fibonacci, 4), ('tribonacci', try_tribonacci, 5), ('quadratic', try_quadratic, 6), ('cubic', try_cubic, 7), ('factorial', try_factorial, 8)]:
        lib.append((name, fn, c))
    return lib
LIBRARY = build_library()

def compress_seq(seq):
    seq = [float(x) for x in seq]
    for name, fn, _ in LIBRARY:
        result = fn(seq)
        if result:
            params, predict, formula_str = result
            return (name, predict, formula_str)
    return None

def verify_exact(seq, true_answer, predict_fn):
    pred = predict_fn([float(x) for x in seq])
    err = abs(pred - float(true_answer))
    tol = 1e-06 * (abs(float(true_answer)) + 1)
    return (err < tol, err)

@dataclass
class Law:
    name: str
    formula_str: str
    predict: Any
    complexity: int
    examples_seen: int = 0

class Subconscious:

    def __init__(self):
        self.laws = {}

    def learn_law(self, name, predict_fn, formula_str, complexity):
        if name not in self.laws:
            print(f"    [SUBCONSCIOUS] New law learned: '{name}' = '{formula_str}'")
        self.laws[name] = Law(name, formula_str, predict_fn, complexity)

    def answer(self, seq):
        seq = [float(x) for x in seq]
        result = compress_seq(seq)
        if result is None:
            return (None, None)
        name, predict_fn, formula_str = result
        if name in self.laws:
            pred = predict_fn(seq)
            return (pred, name)
        return (None, None)

    def knows_pattern(self, seq):
        result = compress_seq([float(x) for x in seq])
        if result is None:
            return False
        return result[0] in self.laws

class ConsciousNet(nn.Module):

    def __init__(self, dim=16, n_blocks=10, seq_len=SEQ_LEN):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(seq_len, dim), nn.Tanh())
        self.blocks = nn.ModuleList([nn.Sequential(nn.Linear(dim, dim), nn.Tanh()) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        h = self.proj(x)
        for blk in self.blocks:
            h = h + blk(h)
        return self.output(h)

    def introspect_r2(self, X, Y):
        self.eval()
        with torch.no_grad():
            X_np = X.cpu().numpy()
            Y_np = Y.cpu().numpy().flatten()
            ss_tot = np.sum((Y_np - Y_np.mean()) ** 2)
            if ss_tot < 1e-10:
                return 1.0
            best_r2 = 0.0
            for feats in [X_np, np.diff(X_np, axis=1), X_np[:, -1:], np.diff(X_np, axis=1)[:, :-1] if X_np.shape[1] > 2 else X_np]:
                aug = np.hstack([feats, np.ones((len(feats), 1))])
                try:
                    W, _, _, _ = np.linalg.lstsq(aug, Y_np, rcond=None)
                    pred = aug @ W
                    r2 = 1 - np.sum((Y_np - pred) ** 2) / (ss_tot + 1e-10)
                    best_r2 = max(best_r2, r2)
                except:
                    pass
        return best_r2

class HybridMind:

    def __init__(self):
        self.subconscious = Subconscious()
        self.conscious = ConsciousNet().to(device)
        self.opt = torch.optim.Adam(self.conscious.parameters(), lr=0.001)
        self.sch = torch.optim.lr_scheduler.CosineAnnealingLR(self.opt, T_max=2000, eta_min=1e-06)
        self.unknown_buffer = []

    def see(self, seq, true_answer):
        if self.subconscious.knows_pattern(seq):
            ans, law = self.subconscious.answer(seq)
            return (ans, 'subconscious', True)
        self.unknown_buffer.append((list(seq), float(true_answer)))
        return (None, 'buffered', False)

    def train_to_find_formula(self, n_epochs=2000, introspect_every=100, verbose=True):
        if not self.unknown_buffer:
            return {'status': 'nothing_to_train'}
        seqs = [x[0] for x in self.unknown_buffer]
        answers = [x[1] for x in self.unknown_buffer]
        scale = max((abs(a) for a in answers)) + 1.0
        X = torch.tensor([[v / scale for v in s] for s in seqs], dtype=torch.float32).to(device)
        Y = torch.tensor([[a / scale] for a in answers], dtype=torch.float32).to(device)
        loss_fn = nn.MSELoss()
        best_r2 = 0.0
        found_law = None
        for ep in range(1, n_epochs + 1):
            self.conscious.train()
            pred = self.conscious(X)
            loss = loss_fn(pred, Y)
            self.opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.conscious.parameters(), 1.0)
            self.opt.step()
            self.sch.step()
            if ep % introspect_every == 0:
                r2 = self.conscious.introspect_r2(X, Y)
                best_r2 = max(best_r2, r2)
                if verbose:
                    print(f'    ep{ep:>5}  loss={loss.item():.6f}  R²={r2:.6f}  searching for formula...')
                if r2 > 0.9999:
                    verified_law = None
                    all_exact = True
                    for seq, ans in zip(seqs, answers):
                        result = compress_seq(seq)
                        if result is None:
                            all_exact = False
                            break
                        name, predict_fn, formula_str = result
                        exact, err = verify_exact(seq, ans, predict_fn)
                        if not exact:
                            if verbose:
                                print(f"    ✗ Gate 2 FAIL: '{formula_str}' gave error={err:.8f} on {seq}→{ans}")
                                print(f'      Would hallucinate at scale. Continuing search.')
                            all_exact = False
                            break
                        if verified_law is None:
                            verified_law = (name, predict_fn, formula_str)
                        elif verified_law[0] != name:
                            all_exact = False
                            break
                    if all_exact and verified_law:
                        name, predict_fn, formula_str = verified_law
                        if verbose:
                            print(f'\n    ✓ BOTH GATES PASSED at ep{ep}')
                            print(f"      Law: '{name}' = '{formula_str}'")
                            print(f'      Verified exact on all {len(seqs)} training sequences')
                        self.subconscious.learn_law(name, predict_fn, formula_str, 0)
                        self.unknown_buffer.clear()
                        found_law = name
                        break
        return {'status': 'found' if found_law else 'still_searching', 'law': found_law, 'best_r2': best_r2, 'epochs': ep}

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
mind = HybridMind()
print_sep('HYBRID MIND v2 — LAWS{} STARTS EMPTY')
print(f'\n  Subconscious laws at start: {list(mind.subconscious.laws.keys())} (empty)\n  \n  Stage 1: Arithmetic → truly unknown → conscious trains → finds law\n  Stage 2: Arithmetic again → subconscious answers instantly\n  Stage 3: Tribonacci → unknown → conscious trains → finds law\n  Stage 4: Bad pattern → conscious trains → cannot verify → says unknown\n')
STAGES = [{'name': 'STAGE 1 — Arithmetic (truly unknown first time)', 'train': [([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([10, 20, 30, 40], 50), ([7, 14, 21, 28], 35), ([1, 3, 5, 7], 9)], 'test': [([100, 200, 300, 400], 500), ([11, 22, 33, 44], 55)]}, {'name': 'STAGE 2 — Arithmetic again (should use subconscious)', 'train': [], 'test': [([6, 12, 18, 24], 30), ([50, 100, 150, 200], 250)]}, {'name': 'STAGE 3 — Tribonacci (unknown, must be found)', 'train': [([1, 1, 2, 4], 7), ([1, 2, 4, 7], 13), ([2, 4, 7, 13], 24), ([4, 7, 13, 24], 44), ([1, 2, 3, 6], 11), ([1, 3, 5, 9], 17)], 'test': [([1, 2, 4, 7], 13), ([2, 4, 7, 13], 24)]}, {'name': 'STAGE 4 — Alternating (unknown, library cannot verify)', 'train': [([1, 3, 6, 8], 11), ([2, 4, 7, 9], 12), ([5, 7, 10, 12], 15), ([0, 2, 5, 7], 10)], 'test': [([4, 6, 9, 11], 14)]}]
all_results = []
for stage in STAGES:
    print_sep(stage['name'])
    if stage['train']:
        print(f"\n  Feeding {len(stage['train'])} sequences...")
        for seq, ans in stage['train']:
            _, source, _ = mind.see(seq, ans)
        if mind.unknown_buffer:
            print(f'  {len(mind.unknown_buffer)} sequences unknown → conscious training')
            print(f'  Goal: find formula, not minimize loss\n')
            result = mind.train_to_find_formula(n_epochs=2000, introspect_every=200, verbose=True)
            print(f"\n  Training result: {result['status']}")
            if result['law']:
                print(f"  Law found: '{result['law']}'")
            else:
                print(f"  Best R²={result['best_r2']:.6f} — formula not verified — conscious holds buffer")
        else:
            print(f'  All sequences already known to subconscious.')
    else:
        print(f'\n  No training sequences — testing subconscious directly.')
    print(f"\n  {'Sequence':<22}  {'True':>6}  {'Got':>10}  {'Err':>6}  Source")
    print(f"  {'─' * 60}")
    for seq, true_ans in stage['test']:
        sc_ans, law = mind.subconscious.answer(seq)
        if sc_ans is not None:
            err = abs(sc_ans - true_ans)
            ok = '✓' if err < 0.01 else '✗'
            print(f'  {str(seq):<22}  {true_ans:>6}  {sc_ans:>10.2f}  {err:>6.4f}  {ok} subconscious ({law})')
            all_results.append((ok == '✓', 'subconscious', stage['name']))
        else:
            mind.conscious.eval()
            with torch.no_grad():
                scale = true_ans if true_ans != 0 else 1.0
                xt = torch.tensor([[v / scale for v in seq]], dtype=torch.float32).to(device)
                approx = mind.conscious(xt).item() * scale
            err = abs(approx - true_ans)
            print(f'  {str(seq):<22}  {true_ans:>6}  {approx:>10.2f}  {err:>6.2f}  ? conscious (approximate)')
            print(f"  {'':22}  {'':>6}  {'I dont know exactly':>10}  {'':>6}  no hallucination")
            all_results.append((False, 'conscious', stage['name']))
print_sep('FINAL STATE')
print(f'\n  SUBCONSCIOUS LAWS (learned, verified exact):')
if mind.subconscious.laws:
    for name, law in mind.subconscious.laws.items():
        print(f"    '{name}': {law.formula_str}")
else:
    print(f'    (none learned)')
print(f'\n  CONSCIOUS BUFFER (still searching):')
print(f'    {len(mind.unknown_buffer)} sequences pending')
if mind.unknown_buffer:
    for seq, ans in mind.unknown_buffer[:3]:
        print(f'    {seq} → {ans}')
total = len(all_results)
exact = sum((1 for ok, _, _ in all_results if ok))
sc_answers = sum((1 for _, src, _ in all_results if src == 'subconscious'))
print(f"""\n  Results: {exact}/{total} exact\n  Subconscious answers: {sc_answers}/{total}\n  \n  KEY:\n    Subconscious = exact, instant, verified\n    Conscious    = approximate + "I don't know exactly"\n    \n    Approximate + honest = better than confident + wrong.\n    No hallucination. No false certainty.\n    Uncertainty is real intelligence.\n""")
