import os, json, math, time, copy
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_primes(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s

def make_all_patterns():
    pats = {}
    for step in range(1, 25):
        pats[f'a{step}'] = ([i * step % VS for i in range(20)], 20 * step % VS)
    for start in range(25, 33):
        pats[f'd{start}'] = ([(start - i) % VS for i in range(20)], (start - 20) % VS)
    fib = gen_fib(40)
    for off in range(8):
        pats[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
    for r in [2, 3, 4, 5, 6, 7, 8, 9]:
        pats[f'g{r}'] = ([r ** i % VS for i in range(20)], r ** 20 % VS)
    for c in range(8):
        pats[f'sq{c}'] = ([(i + c) ** 2 % VS for i in range(20)], (20 + c) ** 2 % VS)
    for step in [3, 5]:
        for off in range(4):
            pats[f's{step}o{off}'] = ([(i * step + off) % VS for i in range(20)], (20 * step + off) % VS)
    return pats
ALL_PATS = make_all_patterns()
PAT_NAMES = list(ALL_PATS.keys())
N_DONORS = 8
DONOR_PATS = [PAT_NAMES[i * 8:(i + 1) * 8] for i in range(N_DONORS)]

class SeqT(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_donor(path):
    W = np.load(path)
    state = {k: torch.tensor(v.astype(np.float32)) for k, v in W.items()}
    m = SeqT().to(device)
    m.load_state_dict(state, strict=True)
    return m

def get_state(model):
    return {k: v.detach().cpu().numpy().astype(np.float64) for k, v in model.state_dict().items()}

def set_state(model, state_np):
    state_t = {k: torch.tensor(v.astype(np.float32)) for k, v in state_np.items()}
    model.load_state_dict(state_t, strict=True)

def clone_state(state_np):
    return {k: v.copy() for k, v in state_np.items()}

def get_components(state_keys):
    comps = {'wte': ['wte.weight'], 'wpe': ['wpe.weight'], 'ln_f': ['ln_f.weight', 'ln_f.bias']}
    for l in range(NL):
        comps[f'ln1_{l}'] = [f'layers.{l}.ln1.weight', f'layers.{l}.ln1.bias']
        comps[f'attn_{l}'] = [f'layers.{l}.attn.in_proj_weight', f'layers.{l}.attn.in_proj_bias', f'layers.{l}.attn.out_proj.weight', f'layers.{l}.attn.out_proj.bias']
        comps[f'ln2_{l}'] = [f'layers.{l}.ln2.weight', f'layers.{l}.ln2.bias']
        comps[f'ff_{l}'] = [f'layers.{l}.ff.0.weight', f'layers.{l}.ff.0.bias', f'layers.{l}.ff.2.weight', f'layers.{l}.ff.2.bias']
    return comps
COMP_NAMES = None

def crossbreed_components(donor_states, rng, comp_names, comps):
    child = clone_state(donor_states[0])
    assignment = {}
    for cname in comp_names:
        di = rng.randint(N_DONORS)
        assignment[cname] = di
        for key in comps[cname]:
            child[key] = donor_states[di][key].copy()
    return (child, assignment)

def mutate_full(state_np, rng, strength=None):
    s = clone_state(state_np)
    keys = list(s.keys())
    op = rng.choice(['noise', 'scale', 'sign_flip_dim', 'layer_scale', 'component_noise'])
    if strength is None:
        strength = rng.uniform(0.02, 0.3)
    if op == 'noise':
        n_tensors = rng.randint(1, len(keys) + 1)
        chosen = rng.choice(keys, n_tensors, replace=False)
        for k in chosen:
            std = np.std(s[k]) * strength
            s[k] += rng.randn(*s[k].shape) * std
    elif op == 'scale':
        comp_keys = rng.choice(keys, rng.randint(1, 4), replace=False)
        factor = rng.uniform(0.7, 1.4)
        for k in comp_keys:
            s[k] *= factor
    elif op == 'sign_flip_dim':
        for k in keys:
            if s[k].ndim >= 2:
                dim = rng.randint(min(s[k].shape))
                axis = rng.randint(s[k].ndim)
                if s[k].shape[axis] == s[k].shape[min(range(s[k].ndim), key=lambda i: s[k].shape[i])]:
                    idx = [slice(None)] * s[k].ndim
                    if dim < s[k].shape[axis]:
                        idx[axis] = dim
                        s[k][tuple(idx)] *= -1
    elif op == 'layer_scale':
        l = rng.randint(NL)
        factor = rng.uniform(0.5, 1.5)
        for k in keys:
            if f'layers.{l}.' in k:
                s[k] *= factor
    elif op == 'component_noise':
        heavy_key = rng.choice(keys)
        std_heavy = np.std(s[heavy_key]) * rng.uniform(0.1, 0.5)
        s[heavy_key] += rng.randn(*s[heavy_key].shape) * std_heavy
    return s

def eval_all(model):
    model.eval()
    per_donor = []
    for di in range(N_DONORS):
        sc = 0
        for pn in DONOR_PATS[di]:
            seq, truth = ALL_PATS[pn]
            ids = torch.tensor([seq[-K:]], dtype=torch.long)
            with torch.no_grad():
                p = int(model(ids)[0, -1].argmax())
            sc += p == truth
        per_donor.append(sc)
    return (sum(per_donor), per_donor)

def eval_state(state_np, scratch_model):
    set_state(scratch_model, state_np)
    return eval_all(scratch_model)

def build_tensors():
    Xs = []
    Ys = []
    for pn in PAT_NAMES:
        seq, _ = ALL_PATS[pn]
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long, device=device), torch.tensor(Ys, dtype=torch.long, device=device))
ALL_X, ALL_Y = build_tensors()

def train_child(init_state, steps=3000, lr=0.003, label='child', print_every=300):
    model = SeqT().to(device)
    set_state(model, init_state)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=5e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, per = eval_all(model)
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  [{label}] step {step:>5}: {sc:>2}/64  {per}', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    sc, per = eval_all(model)
    return (sc, per, model)
print('=' * 60)
print('  PHASE 2 — HYBRID: CROSSBREED + FULL MODEL MUTATION')
print('  Loading pre-trained donors...')
print('=' * 60)
donors = []
donor_states = []
for di in range(N_DONORS):
    path = os.path.join(_dir, f'donor_{di:02d}.npz')
    m = load_donor(path)
    sc, per = eval_all(m)
    donors.append(m)
    donor_states.append(get_state(m))
    print(f'  Donor {di + 1}/8  total={sc}/64  per_donor={per}', flush=True)
comps = get_components(list(donor_states[0].keys()))
COMP_NAMES = list(comps.keys())
print(f'\n  Components ({len(COMP_NAMES)}): {COMP_NAMES}')
scratch = SeqT().to(device)
rng = np.random.RandomState(42)
N_CROSS = 10000
NICHE_SIZE = 8
print(f"\n{'=' * 60}")
print(f'  STEP 1 — COMPONENT CROSSBREED SEARCH ({N_CROSS} combinations)')
print(f'  Picking each component from a different donor')
print(f"{'=' * 60}")
niches = [[] for _ in range(N_DONORS)]
global_best = (0, None, None)
t0 = time.time()
for ci in range(N_CROSS):
    state, assignment = crossbreed_components(donor_states, rng, COMP_NAMES, comps)
    total, per = eval_state(state, scratch)
    if total > global_best[0]:
        global_best = (total, per[:], clone_state(state))
        print(f'  cross {ci:>6}  NEW BEST: {total}/64  {per}  assign={assignment}', flush=True)
    for di in range(N_DONORS):
        if per[di] > 0:
            niches[di].append((per[di], total, clone_state(state)))
            niches[di].sort(key=lambda x: (x[0], x[1]), reverse=True)
            niches[di] = niches[di][:NICHE_SIZE]
    if (ci + 1) % 1000 == 0:
        elapsed = time.time() - t0
        print(f'  {ci + 1:>6}/{N_CROSS}  best={global_best[0]}/64  niches={[len(n) for n in niches]}  {elapsed:.0f}s', flush=True)
print(f'\n  Step 1 done. Best: {global_best[0]}/64  per={global_best[1]}')
N_MUTATE = 5000
print(f"\n{'=' * 60}")
print(f'  STEP 2 — FULL MODEL MUTATION ({N_MUTATE} mutations)')
print(f'  Mutating ALL weight tensors, not just WTE')
print(f"{'=' * 60}")
for mi in range(N_MUTATE):
    r = rng.rand()
    if r < 0.4:
        base = clone_state(global_best[2]) if global_best[2] else clone_state(donor_states[0])
    elif r < 0.8:
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        ni = rng.choice(nonempty)
        _, _, base = niches[ni][rng.randint(len(niches[ni]))]
        base = clone_state(base)
    else:
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        if len(nonempty) >= 2:
            ni1, ni2 = rng.choice(nonempty, 2, replace=False)
            s1 = niches[ni1][rng.randint(len(niches[ni1]))][2]
            s2 = niches[ni2][rng.randint(len(niches[ni2]))][2]
            base = {}
            for cname in COMP_NAMES:
                src = s1 if rng.rand() < 0.5 else s2
                for key in comps[cname]:
                    base[key] = src[key].copy()
        else:
            base = clone_state(global_best[2])
    n_ops = 1 if rng.rand() < 0.6 else 2
    mut = base
    for _ in range(n_ops):
        mut = mutate_full(mut, rng)
    total, per = eval_state(mut, scratch)
    if total > global_best[0]:
        global_best = (total, per[:], clone_state(mut))
        print(f'  mut {mi:>6}  NEW BEST: {total}/64  {per}', flush=True)
    for di in range(N_DONORS):
        if per[di] > 0:
            niches[di].append((per[di], total, clone_state(mut)))
            niches[di].sort(key=lambda x: (x[0], x[1]), reverse=True)
            niches[di] = niches[di][:NICHE_SIZE]
    if (mi + 1) % 1000 == 0:
        elapsed = time.time() - t0
        print(f'  {mi + 1:>6}/{N_MUTATE}  best={global_best[0]}/64  niches={[len(n) for n in niches]}  {elapsed:.0f}s', flush=True)
print(f'\n  Step 2 done. Best: {global_best[0]}/64  per={global_best[1]}')
N_GENERATIONS = 5
N_CHILDREN = 300
print(f"\n{'=' * 60}")
print(f'  STEP 3 — MULTI-GENERATION NICHE CROSSBREED')
print(f'  {N_GENERATIONS} generations × {N_CHILDREN} children')
print(f"{'=' * 60}")
for gen in range(N_GENERATIONS):
    print(f'\n  Generation {gen + 1}:')
    gen_best = (0, None, None)
    for ci in range(N_CHILDREN):
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        n_parents = min(rng.randint(2, 5), len(nonempty))
        parent_niches = rng.choice(nonempty, n_parents, replace=False)
        parent_states = []
        for ni in parent_niches:
            _, _, ps = niches[ni][rng.randint(len(niches[ni]))]
            parent_states.append(ps)
        child_state = {}
        for cname in COMP_NAMES:
            src = parent_states[rng.randint(len(parent_states))]
            for key in comps[cname]:
                child_state[key] = src[key].copy()
        if rng.rand() < 0.5:
            child_state = mutate_full(child_state, rng, strength=rng.uniform(0.01, 0.15))
        total, per = eval_state(child_state, scratch)
        if total > global_best[0]:
            global_best = (total, per[:], clone_state(child_state))
            print(f'    child {ci:>4}  NEW GLOBAL BEST: {total}/64  {per}', flush=True)
        if total > gen_best[0]:
            gen_best = (total, per[:], clone_state(child_state))
        for di in range(N_DONORS):
            if per[di] > 0:
                niches[di].append((per[di], total, clone_state(child_state)))
                niches[di].sort(key=lambda x: (x[0], x[1]), reverse=True)
                niches[di] = niches[di][:NICHE_SIZE]
    print(f'    Gen {gen + 1} best: {gen_best[0]}/64  per={gen_best[1]}')
    print(f'    Global best so far: {global_best[0]}/64')
print(f"\n{'=' * 60}")
print(f'  STEP 4 — TRAINING BEST CHILD')
print(f'  Init score before training: {global_best[0]}/64  per={global_best[1]}')
print(f'  3000 steps on all 64 patterns')
print(f"{'=' * 60}\n")
final_sc, final_per, final_model = train_child(global_best[2], steps=3000, lr=0.003, label='best_child', print_every=300)
print(f"\n{'=' * 60}")
print(f'  FINAL RESULTS')
print(f"{'=' * 60}")
sc, per = eval_all(final_model)
print(f'\n  Score: {sc}/64')
for di in range(N_DONORS):
    correct = []
    for pn in DONOR_PATS[di]:
        seq, truth = ALL_PATS[pn]
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(final_model(ids)[0, -1].argmax())
        correct.append(p == truth)
    bar = ''.join(('█' if c else '░' for c in correct))
    print(f'  Donor {di + 1}  {bar}  {sum(correct)}/8  pats={DONOR_PATS[di][:2]}..')
print(f'\n  TOTAL TIME: {time.time() - t0:.0f}s\n\n  WHAT WAS TRIED:\n    Step 1: {N_CROSS} component crossbreeds (pick each layer from different donor)\n    Step 2: {N_MUTATE} full model mutations on survivors\n    Step 3: {N_GENERATIONS}×{N_CHILDREN} generation niche crossbreeding\n    Step 4: 3000 step training on all 64 patterns\n')
print('=' * 60)
