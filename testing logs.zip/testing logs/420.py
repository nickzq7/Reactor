import torch
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL = 'roneneldan/TinyStories-1M'
print('\n' + '=' * 70)
print('  W META LAW — THE LAW THAT GENERATES THE LAWS')
print('  Question: what generates W_ffn across layers?')
print('=' * 70)
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL)
model.eval()
D = model.config.hidden_size
N_LAYERS = model.config.num_hidden_layers
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}')
print(f'\n  Extracting W2 (c_proj) matrices directly from weights...')
W2 = {}
W1 = {}
for l in range(N_LAYERS):
    W2[l] = model.transformer.h[l].mlp.c_proj.weight.detach().numpy()
    W1[l] = model.transformer.h[l].mlp.c_fc.weight.detach().numpy()
    print(f'    Layer {l}: W2 shape={W2[l].shape}  W1 shape={W1[l].shape}')
print(f"\n{'=' * 70}")
print(f'  TEST 1 — LOW-RANK STRUCTURE OF EACH W2')
print(f'  How many singular values needed to capture 99% variance?')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'Full rank':<12} {'99% rank':<12} {'95% rank':<12} {'90% rank':<12} {'compression'}")
print(f"  {'─' * 65}")
ranks_99 = []
for l in range(N_LAYERS):
    W = W2[l]
    U, S, Vt = np.linalg.svd(W, full_matrices=False)
    total_var = np.sum(S ** 2)
    cumvar = np.cumsum(S ** 2) / total_var
    rank_99 = int(np.searchsorted(cumvar, 0.99)) + 1
    rank_95 = int(np.searchsorted(cumvar, 0.95)) + 1
    rank_90 = int(np.searchsorted(cumvar, 0.9)) + 1
    full_r = min(W.shape)
    orig_params = W.shape[0] * W.shape[1]
    compressed_99 = W.shape[0] * rank_99 + rank_99 + rank_99 * W.shape[1]
    compression = orig_params / compressed_99
    ranks_99.append(rank_99)
    print(f'  {l:<8} {full_r:<12} {rank_99:<12} {rank_95:<12} {rank_90:<12} {compression:.1f}x')
print(f'\n  Mean rank for 99%: {np.mean(ranks_99):.1f} / {min(W2[0].shape)} full rank')
print(f'  Mean compression:  {min(W2[0].shape) / np.mean(ranks_99):.1f}x per layer')
print(f"\n{'=' * 70}")
print(f'  TEST 2 — SHARED BASIS ACROSS ALL LAYERS')
print(f'  Stack all W2 matrices → find common singular vectors')
print(f'  If shared: store basis once + small per-layer coefficients')
print(f"{'=' * 70}\n")
W2_stacked = np.hstack([W2[l] for l in range(N_LAYERS)])
print(f'  Stacked W2 shape: {W2_stacked.shape}')
U_shared, S_shared, Vt_shared = np.linalg.svd(W2_stacked, full_matrices=False)
print(f'  Shared left basis U: {U_shared.shape}')
print(f'\n  Reconstruction quality using shared left basis (U_shared):\n')
print(f"  {'Layer':<8} {'k=4':<10} {'k=8':<10} {'k=16':<10} {'k=32':<10} {'k=64':<10}")
print(f"  {'─' * 58}")
for l in range(N_LAYERS):
    W = W2[l]
    scores = []
    for k in [4, 8, 16, 32, 64]:
        if k > U_shared.shape[1]:
            scores.append(float('nan'))
            continue
        U_k = U_shared[:, :k]
        coeffs = U_k.T @ W
        W_recon = U_k @ coeffs
        ss_res = np.sum((W - W_recon) ** 2)
        ss_tot = np.sum((W - W.mean()) ** 2)
        r2 = 1 - ss_res / (ss_tot + 1e-10)
        scores.append(r2)
    print(f'  {l:<8}', end='')
    for r in scores:
        if np.isnan(r):
            print(f"  {'N/A':<8}", end='')
        else:
            print(f'  {r:<8.4f}', end='')
    print()
print(f"\n{'=' * 70}")
print(f'  TEST 3 — META-W: can layer_index generate W2?')
print(f'  W2[l] = f(layer_features) × W_meta')
print(f'  If R²≈1.000: one meta-matrix = all FFN laws')
print(f"{'=' * 70}\n")
W2_flat = np.vstack([W2[l].flatten() for l in range(N_LAYERS)])
print(f'  W2 flattened: {W2_flat.shape}  (8 layers × {D * FFN_D} params each)')
layer_features = {'one_hot': np.eye(N_LAYERS), 'linear': np.arange(N_LAYERS).reshape(-1, 1) / N_LAYERS, 'sin_cos': np.column_stack([np.sin(np.arange(N_LAYERS) * np.pi / N_LAYERS), np.cos(np.arange(N_LAYERS) * np.pi / N_LAYERS)]), 'polynomial': np.column_stack([(np.arange(N_LAYERS) / N_LAYERS) ** p for p in range(1, 5)])}
print(f'\n  Can layer index alone predict W2?\n')
print(f"  {'Feature':<15} {'R² (W2 prediction)':<22} {'verdict'}")
print(f"  {'─' * 50}")
for fname, feats in layer_features.items():
    r2s = []
    for held_out in range(N_LAYERS):
        train_idx = [i for i in range(N_LAYERS) if i != held_out]
        X_tr = np.hstack([feats[train_idx], np.ones((len(train_idx), 1))])
        Y_tr = W2_flat[train_idx]
        X_te = np.hstack([feats[[held_out]], np.ones((1, 1))])
        Y_te = W2_flat[[held_out]]
        W_meta = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
        pred = X_te @ W_meta
        ss_res = np.sum((Y_te - pred) ** 2)
        ss_tot = np.sum((Y_te - Y_te.mean()) ** 2)
        r2s.append(1 - ss_res / (ss_tot + 1e-10))
    mean_r2 = np.mean(r2s)
    verdict = '✓ GENERATIVE' if mean_r2 > 0.95 else '~ partial' if mean_r2 > 0.8 else '~ weak' if mean_r2 > 0.5 else '✗ no'
    print(f'  {fname:<15} {mean_r2:<22.6f} {verdict}')
print(f"\n{'=' * 70}")
print(f'  TEST 4 — DELTA LAW: W2[l] → W2[l+1]')
print(f'  Is the change between consecutive W2 matrices regular?')
print(f"{'=' * 70}\n")
print(f"  {'Step':<12} {'||W2[l+1] - W2[l]||':<22} {'cosine similarity':<20} {'ratio'}")
print(f"  {'─' * 65}")
deltas = []
cosines = []
for l in range(N_LAYERS - 1):
    delta = W2[l + 1] - W2[l]
    delta_norm = np.linalg.norm(delta)
    w_norm = np.linalg.norm(W2[l])
    cos = np.sum(W2[l] * W2[l + 1]) / (np.linalg.norm(W2[l]) * np.linalg.norm(W2[l + 1]) + 1e-10)
    ratio = np.linalg.norm(W2[l + 1]) / np.linalg.norm(W2[l])
    deltas.append(delta_norm)
    cosines.append(cos)
    print(f'  {l}→{l + 1:<9} {delta_norm:<22.4f} {cos:<20.6f} {ratio:.4f}')
print(f'\n  Mean delta norm:    {np.mean(deltas):.4f}  (std={np.std(deltas):.4f})')
print(f'  Mean cosine sim:    {np.mean(cosines):.6f}  (std={np.std(cosines):.6f})')
print(f"  {('Regular change' if np.std(deltas) / np.mean(deltas) < 0.5 else 'Irregular change')}")
print(f'\n  Can W2[l] linearly predict W2[l+1]?')
predictions = []
for l in range(N_LAYERS - 1):
    pairs_X = [W2[i].flatten() for i in range(N_LAYERS - 1) if i != l]
    pairs_Y = [W2[i + 1].flatten() for i in range(N_LAYERS - 1) if i != l]
    X_tr = np.vstack(pairs_X)
    Y_tr = np.vstack(pairs_Y)
    corr = np.corrcoef(W2[l].flatten(), W2[l + 1].flatten())[0, 1]
    predictions.append(corr)
    print(f'    W2[{l}] → W2[{l + 1}]: correlation = {corr:.6f}')
print(f"\n{'=' * 70}")
print(f'  TEST 5 — PRINCIPAL ANGLES BETWEEN W2 COLUMN SPACES')
print(f'  Are W2 matrices living in the same subspace?')
print(f"{'=' * 70}\n")

def col_space(W, k=16):
    U, S, Vt = np.linalg.svd(W.T, full_matrices=False)
    return U[:, :k]
print(f'  Overlap of column spaces (top-16 singular vectors):\n')
print(f"  {'Layer':<8}", end='')
for l in range(N_LAYERS):
    print(f'  {l:<7}', end='')
print()
print(f"  {'─' * 70}")
col_spaces = [col_space(W2[l]) for l in range(N_LAYERS)]
for i in range(N_LAYERS):
    print(f'  {i:<8}', end='')
    for j in range(N_LAYERS):
        Q_i, Q_j = (col_spaces[i], col_spaces[j])
        overlap = np.linalg.norm(Q_i.T @ Q_j, 'fro') ** 2 / 16
        print(f'  {overlap:<7.3f}', end='')
    print()
print(f'\n  Diagonal = 1.0 (self-overlap)')
print(f'  Off-diagonal > 0.5 = substantial shared subspace')
print(f'  Off-diagonal < 0.2 = mostly independent subspaces')
print(f"\n{'=' * 70}")
print(f'  SUMMARY — WHAT THE META-LAW REVEALS')
print(f"{'=' * 70}\n")
avg_rank_99 = np.mean(ranks_99)
compression_per_layer = min(W2[0].shape) / avg_rank_99
print(f'\n  FINDING 1 — LOW RANK:\n    Each W2 needs only {avg_rank_99:.0f}/{min(W2[0].shape)} singular values for 99% variance.\n    Compression per layer: {compression_per_layer:.1f}x\n    This is independent of shared basis question.\n    ALREADY ACHIEVABLE TODAY.\n\n  FINDING 2 — SHARED BASIS:\n    Check numbers above.\n    If k=16 gives R²>0.95: store U_shared once + small coeffs per layer.\n\n  FINDING 3 — META-W:\n    Check numbers above.\n    If layer_features → W2 gives R²>0.95: generative compression proven.\n\n  FINDING 4 — DELTA LAW:\n    Check cosine similarities above.\n    High cosine + regular delta = recursive generation possible.\n    W2[0] → M → W2[1] → M → ... → W2[7].\n    Store W2[0] + M = store 2 matrices = generate all 8.\n\n  THE HONEST QUESTION:\n    W_ffn per layer = exact (R²=1.000). Law is proven.\n    The law that generates W_ffn across layers = this test finds it.\n    Whatever the highest R² method above = that is the meta-law.\n')
print('=' * 70 + '\n')
