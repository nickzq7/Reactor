import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — THE LAST GAP (HOOK METHOD)')
print('  Targeting the 6% FFN gap and 0.7% ATT gap at Layer 7.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
CTX = 8
layer_idx = 7

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def fit_r2(X_tr, Y_tr, X_te, Y_te):
    X_tr_b = np.c_[X_tr, np.ones(X_tr.shape[0])]
    X_te_b = np.c_[X_te, np.ones(X_te.shape[0])]
    W = np.linalg.lstsq(X_tr_b, Y_tr, rcond=None)[0]
    return r2(X_te_b @ W, Y_te)
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came']
print(f'\n  Generating sample data...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
ATT_IN = []
ATT_OUT = []
FFN_IN = []
FFN_OUT = []
block = model.transformer.h[layer_idx]
store = {'a_in': [], 'a_out': [], 'f_in': [], 'f_out': []}

def hook_att(m, i, o):
    store['a_in'].append(i[0].detach().float().numpy())
    store['a_out'].append(o.detach().float().numpy())

def hook_ffn(m, i, o):
    store['f_in'].append(i[0].detach().float().numpy())
    store['f_out'].append(o.detach().float().numpy())
h_att = block.attn.attention.out_proj.register_forward_hook(hook_att)
h_ffn = block.mlp.c_proj.register_forward_hook(hook_ffn)
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        L = tokens['input_ids'].shape[1]
        if L < CTX:
            continue
        model(**tokens)
        a_in = store['a_in'].pop()[0]
        a_out = store['a_out'].pop()[0]
        f_in = store['f_in'].pop()[0]
        f_out = store['f_out'].pop()[0]
        for start in range(L - CTX + 1):
            ATT_IN.append(a_in[start:start + CTX, :])
            ATT_OUT.append(a_out[start:start + CTX, :])
            FFN_IN.append(f_in[start:start + CTX, :])
            FFN_OUT.append(f_out[start:start + CTX, :])
h_att.remove()
h_ffn.remove()
ATT_IN = np.array(ATT_IN)
ATT_OUT = np.array(ATT_OUT)
FFN_IN = np.array(FFN_IN)
FFN_OUT = np.array(FFN_OUT)
N = len(ATT_IN)
N_tr = int(N * 0.8)
print(f'  Samples collected: {N}')
print('\n' + '─' * 62)
print('  TEST 1: WINDOW-LEVEL (Flattened Context)')
print('  Forcing W to learn cross-token projections.')
print('─' * 62)
ATT_IN_flat = ATT_IN.reshape(N, -1)
ATT_OUT_flat = ATT_OUT.reshape(N, -1)
FFN_IN_flat = FFN_IN.reshape(N, -1)
FFN_OUT_flat = FFN_OUT.reshape(N, -1)
att_score_flat = fit_r2(ATT_IN_flat[:N_tr], ATT_OUT_flat[:N_tr], ATT_IN_flat[N_tr:], ATT_OUT_flat[N_tr:])
ffn_score_flat = fit_r2(FFN_IN_flat[:N_tr], FFN_OUT_flat[:N_tr], FFN_IN_flat[N_tr:], FFN_OUT_flat[N_tr:])
print(f'    per_head → att_out  :  {att_score_flat:.6f} (Notice the gap)')
print(f'    gelu_act → ffn_out  :  {ffn_score_flat:.6f} (Notice the large gap)')
print('\n' + '─' * 62)
print('  TEST 2: TOKEN-LEVEL (Positional Independence)')
print('  Allowing W to learn pure position-wise projection.')
print('─' * 62)
ATT_IN_tok = ATT_IN.reshape(-1, D)
ATT_OUT_tok = ATT_OUT.reshape(-1, D)
FFN_IN_tok = FFN_IN.reshape(-1, D * 4)
FFN_OUT_tok = FFN_OUT.reshape(-1, D)
N_tok = len(ATT_IN_tok)
N_tr_tok = int(N_tok * 0.8)
att_score_tok = fit_r2(ATT_IN_tok[:N_tr_tok], ATT_OUT_tok[:N_tr_tok], ATT_IN_tok[N_tr_tok:], ATT_OUT_tok[N_tr_tok:])
ffn_score_tok = fit_r2(FFN_IN_tok[:N_tr_tok], FFN_OUT_tok[:N_tr_tok], FFN_IN_tok[N_tr_tok:], FFN_OUT_tok[N_tr_tok:])

def fmt(v):
    return '✓ 1.000000 (EXACT)' if v > 0.99999 else f'{v:.6f}'
print(f'    per_head → att_out  :  {fmt(att_score_tok)}')
print(f'    gelu_act → ffn_out  :  {fmt(ffn_score_tok)}')
print('\n' + '=' * 62)
print('  THE FINAL BOUNDARY REVEALED')
print('=' * 62)
print('\n  If Test 2 hits EXACTLY 1.000000 for both:\n    There is no missing law inside the transformer.\n    The gaps were an illusion caused by blurring the geometry.\n    W_o and c_proj are strictly local to the token.\n    When W views them in their correct positional geometry,\n    the linearity is absolute.\n\n  Where does W fail? Where is the true non-linear boundary?\n  Only at the ARGMAX.\n\n  Inside the model:\n    Everything is a linear rotation in its natural space.\n    Probability is a continuous, linear landscape.\n\n  At the output (Argmax):\n    The continuous landscape collapses into ONE integer token.\n    You cannot represent a hard choice with a matrix multiplication.\n    This is Class 3. The quantum collapse of the network.\n    W reveals the landscape; the argmax forces the reality.\n')
print('=' * 62 + '\n')
