import numpy as np, math
print('\n' + '=' * 60)
print('  W-KERNEL MICRO TEST — ANATOMY OF ONE PREDICTION')
print('=' * 60)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
D = VS
WTE = np.eye(VS, dtype=np.float64)
K = 6
DECAY = 0.5
L = 3
decay_w = np.array([DECAY ** j for j in range(K)], dtype=np.float64)
decay_w /= decay_w.sum()
M = N - K
y = np.array(toks[K:])
X0 = np.zeros((M, D))
for i in range(K, N):
    for j in range(K):
        X0[i - K] += decay_w[j] * WTE[toks[i - 1 - j]]
T = WTE[y]
tri_i, tri_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_s(Ph, R, lam=1e-06):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    return np.linalg.solve(A, Ph.T @ R)

def fwd(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs
W_layers = [np.zeros((D * (D + 1) // 2, D)) for _ in range(L)]
best_p = 999
best_W = [w.copy() for w in W_layers]
for rnd in range(5):
    imp = False
    for l in range(L):
        xs = fwd(X0, W_layers)
        Wn = pinv_s(phi_b(xs[l]), T - xs[l])
        Wt = [w.copy() for w in W_layers]
        Wt[l] = Wn
        x = fwd(X0, Wt)[-1]
        lg = x @ WTE.T
        nll = sum((-(lambda l2: l2 - np.log(np.sum(np.exp(l2))))(lg[i] - lg[i].max())[y[i]] for i in range(0, M, max(1, M // 500))))
        p = math.exp(min(nll / (M // max(1, M // 500)), 500))
        if p < best_p:
            best_p = p
            W_layers = Wt
            best_W = [w.copy() for w in Wt]
            imp = True
    if not imp:
        break
W_layers = best_W
print(f'  Model trained: ppl={best_p:.2f}')
print(f"\n{'─' * 60}")
print(f'  Q1: WHERE DOES x_final POINT? (direction analysis)')
print(f"{'─' * 60}")
test_contexts = [('th', 'e'), ('he', ' '), ('the ', 'b'), (' the', ' '), ('and', ' ')]
for ctx_str, true_next in test_contexts:
    ids = [c2i[c] for c in ctx_str if c in c2i]
    x = np.zeros(D)
    for j in range(min(K, len(ids))):
        x += decay_w[j] * WTE[ids[-1 - j]]
    x0 = x.copy()
    xs = [x0.copy()]
    for W in W_layers:
        xs.append(xs[-1] + phi(xs[-1]) @ W)
    x_f = xs[-1]
    true_id = c2i.get(true_next, -1)
    lg = x_f @ WTE.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.1f}%') for i in np.argsort(-p)[:3]]
    cos_true = x_f @ WTE[true_id] / (np.linalg.norm(x_f) + 1e-08) if true_id >= 0 else 0
    sorted_lg = np.sort(lg)[::-1]
    gap = sorted_lg[0] - sorted_lg[1]
    print(f"\n  Context='{ctx_str}' → true='{true_next}'")
    print(f'    x_0 norm={np.linalg.norm(x0):.4f}  x_final norm={np.linalg.norm(x_f):.4f}')
    print(f"    cos(x_final, WTE['{true_next}'])={cos_true:.4f}  (want→1.0)")
    print(f'    logit_gap(best-2nd)={gap:.4f}  (want>>0)')
    print(f'    top3={top3}')
    if true_id >= 0:
        for li, xi in enumerate(xs):
            r = np.linalg.norm(WTE[true_id] - xi)
            cos = xi @ WTE[true_id] / (np.linalg.norm(xi) + 1e-08)
            print(f'    Layer {li}: ||residual||={r:.4f}  cos={cos:.4f}')
print(f"\n{'─' * 60}")
print(f'  Q2: BEST DECAY VALUE? (0=uniform mean, 1=only last char)')
print(f"{'─' * 60}")
print(f"  {'decay':>8} {'ppl':>8} {'acc':>8} {'gap_mean':>10}")
for decay in [0.0, 0.3, 0.5, 0.7, 0.9, 0.95]:
    if decay == 0:
        dw = np.ones(K) / K
    else:
        dw = np.array([decay ** j for j in range(K)])
        dw /= dw.sum()
    X_d = np.zeros((M, D))
    for i in range(K, N):
        for j in range(K):
            X_d[i - K] += dw[j] * WTE[toks[i - 1 - j]]
    W_d = [np.zeros((D * (D + 1) // 2, D)) for _ in range(L)]
    bp = 999
    bW = [w.copy() for w in W_d]
    for rnd in range(5):
        imp = False
        for l in range(L):
            xs = fwd(X_d, W_d)
            Wn = pinv_s(phi_b(xs[l]), T - xs[l])
            Wt = [w.copy() for w in W_d]
            Wt[l] = Wn
            xf = fwd(X_d, Wt)[-1]
            lg = xf @ WTE.T
            nll = sum((-(lambda l2: l2 - np.log(np.sum(np.exp(l2))))(lg[i] - lg[i].max())[y[i]] for i in range(0, M, max(1, M // 500))))
            p = math.exp(min(nll / (M // max(1, M // 500)), 500))
            if p < bp:
                bp = p
                W_d = Wt
                bW = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W_d = bW
    xf = fwd(X_d, W_d)[-1]
    lg = xf @ WTE.T
    acc = 100 * np.mean(np.argmax(lg, 1) == y)
    sorted_lg = np.sort(lg, 1)[:, ::-1]
    gap = np.mean(sorted_lg[:, 0] - sorted_lg[:, 1])
    print(f'  {decay:>8.2f} {bp:>8.2f} {acc:>7.1f}% {gap:>10.4f}')
print(f"\n{'─' * 60}")
print(f'  Q3: SCALE WTE — what if WTE = s*eye?')
print(f'  Larger scale → bigger logit gaps?')
print(f"{'─' * 60}")
print(f"  {'scale':>8} {'ppl':>8} {'gap_mean':>10}")
decay_w2 = np.array([0.5 ** j for j in range(K)], dtype=np.float64)
decay_w2 /= decay_w2.sum()
X_base = np.zeros((M, D))
for i in range(K, N):
    for j in range(K):
        X_base[i - K] += decay_w2[j] * WTE[toks[i - 1 - j]]
for scale in [0.5, 1.0, 2.0, 4.0, 8.0]:
    T_s = (WTE * scale)[y]
    W_s = [np.zeros((D * (D + 1) // 2, D)) for _ in range(L)]
    bp = 999
    bW = [w.copy() for w in W_s]
    for rnd in range(5):
        imp = False
        for l in range(L):
            xs = fwd(X_base, W_s)
            Wn = pinv_s(phi_b(xs[l]), T_s - xs[l])
            Wt = [w.copy() for w in W_s]
            Wt[l] = Wn
            xf = fwd(X_base, Wt)[-1]
            lg = xf @ (WTE * scale).T
            nll = sum((-(lambda l2: l2 - np.log(np.sum(np.exp(l2))))(lg[i] - lg[i].max())[y[i]] for i in range(0, M, max(1, M // 500))))
            p = math.exp(min(nll / (M // max(1, M // 500)), 500))
            if p < bp:
                bp = p
                W_s = Wt
                bW = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W_s = bW
    xf = fwd(X_base, W_s)[-1]
    lg = xf @ (WTE * scale).T
    sorted_lg = np.sort(lg, 1)[:, ::-1]
    gap = np.mean(sorted_lg[:, 0] - sorted_lg[:, 1])
    print(f'  {scale:>8.1f} {bp:>8.2f} {gap:>10.4f}')
print(f"\n{'=' * 60}")
print(f'  MICRO TEST CONCLUSIONS:')
print(f'  Q1: cos(x_final, WTE[correct]) shows if direction right')
print(f'  Q2: Best decay shows optimal context weighting')
print(f'  Q3: Scale shows if logit flatness = magnitude problem')
print(f'\n  IF cos→1 but gap small: scale problem → fix: WTE=s*eye')
print(f'  IF cos<0.5:             direction problem → different kernel')
print(f'  IF decay=0.9 best:      only last char matters → K=1 enough')
print('=' * 60 + '\n')
