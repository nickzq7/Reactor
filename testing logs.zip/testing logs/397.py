import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
n_heads = model.config.num_heads
head_dim = D // n_heads
print(f'D={D}  Layers={n_layers}  Heads={n_heads}  HeadDim={head_dim}')
print(f'\nAttention types per layer:')
for li in range(n_layers):
    att_type = model.transformer.h[li].attn.attention_type
    print(f'  Layer {li}: {att_type}')

def r2_score(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def test_linear_seq(X, Y, name, split=0.8):
    if not X or not Y or len(X) != len(Y):
        print(f'  {name:<55} empty/mismatch')
        return (float('nan'), float('nan'))
    X_flat = np.array([x.flatten() for x in X], dtype=np.float64)
    Y_flat = np.array([y.flatten() for y in Y], dtype=np.float64)
    if not np.all(np.isfinite(X_flat)) or not np.all(np.isfinite(Y_flat)):
        print(f'  {name:<55} NaN/Inf')
        return (float('nan'), float('nan'))
    n = len(X_flat)
    s = int(n * 0.8)
    if s < 5:
        print(f'  {name:<55} too few sequences ({n})')
        return (float('nan'), float('nan'))
    Xb = np.c_[X_flat, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y_flat[:s], rcond=None)[0]
    except Exception as e:
        print(f'  {name:<55} FAILED: {e}')
        return (float('nan'), float('nan'))
    r2_tr = r2_score(Xb[:s] @ W, Y_flat[:s])
    r2_te = r2_score(Xb[s:] @ W, Y_flat[s:])
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<55} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
    return (r2_tr, r2_te)

def test_linear_tok(X, Y, name, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    n = len(X)
    s = int(n * 0.8)
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        print(f'  {name:<55} FAILED')
        return (float('nan'), float('nan'))
    r2_tr = r2_score(Xb[:s] @ W, Y[:s])
    r2_te = r2_score(Xb[s:] @ W, Y[s:])
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<55} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
    return (r2_tr, r2_te)
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast.', 'Deep in the forest there was a small house where a family of bears lived together. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family.', 'There was once a brave young knight who lived in a castle near the mountains high. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights and said a dragon had come to the land.', 'A small girl named Sophie loved books more than anything else in the whole wide world. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the books.', 'The little village sat quietly at the edge of a great forest full of ancient tall trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest time. Children would run through the market eating apples and drinking warm spiced cider.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him.', 'The ocean was vast and blue and stretched as far as the eye could possibly see each day. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate the open water.', 'High up in the mountains there was a small school where children came from very far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the path carefully.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest. She spent her days tending her garden and feeding the birds that came to visit her. Every evening she would sit by the fire and read her old favorite books alone.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day. The puppy was wet and cold and very hungry and it looked up at him with big eyes. Sam picked up the puppy and carried it home to show his mother carefully.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone before. Every day she would watch the village below and wish she could play with the children there. One day a brave girl climbed the mountain and sat down beside her quietly.', 'In the deep blue ocean there lived a curious fish who wanted to see the world above. Every day she would swim to the surface and peek at the sky and the tall green trees. One morning she jumped very high and for a moment she could see everything.', 'The old clock in the corner of the room had not worked for many many long years. One rainy afternoon the little girl decided to try to fix it with her small toy tools. She turned the gears carefully and wound the spring and suddenly it began to tick.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below. Rain fell gently on it for many days and the sun shone warmly on the earth. Slowly a small green shoot appeared and reached upward toward the light above.', 'The young painter stood in front of the blank white canvas and did not know where to start. She dipped her brush in the bright blue paint and made one small stroke across the middle. Then she added yellow and red and slowly a beautiful sunrise appeared before her.', 'Every evening the grandfather would sit in his old wooden chair and tell stories to the children. The children would gather around him and listen with wide open eyes in the firelight. His stories were always about adventures in faraway lands and magical creatures and brave heroes.']
print(f'\nCollecting per-sequence activations...')
seq_ln1 = {li: [] for li in range(n_layers)}
seq_soft = {li: [] for li in range(n_layers)}
seq_attn = {li: [] for li in range(n_layers)}
seq_attn_scores = {li: [] for li in range(n_layers)}
attn_weights_store = {li: [] for li in range(n_layers)}
hooks = []
cur_ln1 = {li: None for li in range(n_layers)}
cur_soft = {li: None for li in range(n_layers)}
cur_attn = {li: None for li in range(n_layers)}
for li in range(n_layers):

    def make_ln1(l):

        def hook(m, inp, out):
            cur_ln1[l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].ln_1.register_forward_hook(make_ln1(li)))
for li in range(n_layers):

    def make_wo(l):

        def hook(m, inp, out):
            cur_soft[l] = inp[0].detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].attn.attention.out_proj.register_forward_hook(make_wo(li)))
for li in range(n_layers):

    def make_attn(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur_attn[l] = o.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_attn(li)))
with torch.no_grad():
    for text in long_texts:
        toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        out = model(**toks, output_attentions=True)
        L = toks['input_ids'].shape[1]
        for li in range(n_layers):
            if cur_ln1[li] is not None:
                seq_ln1[li].append(cur_ln1[li][:L].copy())
            if cur_soft[li] is not None:
                seq_soft[li].append(cur_soft[li][:L].copy())
            if cur_attn[li] is not None:
                seq_attn[li].append(cur_attn[li][:L].copy())
            if out.attentions is not None and li < len(out.attentions):
                w = out.attentions[li].detach().float()[0].numpy().copy()
                attn_weights_store[li].append(w)
for h in hooks:
    h.remove()
N_seq = len(long_texts)
print(f'Sequences collected: {N_seq}')
print(f"Example sequence length: {(seq_ln1[0][0].shape[0] if seq_ln1[0] else 'N/A')}")
print(f"\n{'=' * 70}")
print(f'  TEST 1 — Per-SEQUENCE: ln1_out → softmax_out')
print(f'  Previous per-token: R²=0.80-0.97')
print(f'  Now per-sequence: flatten full (L,D) → (L,D) per sequence')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    att_type = model.transformer.h[li].attn.attention_type
    test_linear_seq(seq_ln1[li], seq_soft[li], f'  SEQ: ln1_{li} → soft_{li} [{att_type}]')
print(f"\n{'=' * 70}")
print(f'  TEST 2 — Per-HEAD: ln1_out → softmax_out')
print(f'  Softmax operates per head. Natural space may be per-head.')
print(f'  Split D into {n_heads} heads of {head_dim} dims each.')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    att_type = model.transformer.h[li].attn.attention_type
    if not seq_ln1[li] or not seq_soft[li]:
        continue
    head_r2s = []
    for h_idx in range(n_heads):
        ln1_head = [s[:, h_idx * head_dim:(h_idx + 1) * head_dim] for s in seq_ln1[li]]
        soft_head = [s[:, h_idx * head_dim:(h_idx + 1) * head_dim] for s in seq_soft[li]]
        ln1_tok = np.concatenate(ln1_head, axis=0)
        soft_tok = np.concatenate(soft_head, axis=0)
        n = len(ln1_tok)
        s = int(n * 0.8)
        Xb = np.c_[ln1_tok[:s].astype(np.float64), np.ones(s)]
        try:
            W = np.linalg.lstsq(Xb, soft_tok[:s].astype(np.float64), rcond=None)[0]
            Xb_te = np.c_[ln1_tok[s:].astype(np.float64), np.ones(n - s)]
            rv = r2_score(Xb_te @ W, soft_tok[s:])
        except:
            rv = float('nan')
        head_r2s.append(rv)
    mean_r2 = float(np.nanmean(head_r2s))
    max_r2 = float(np.nanmax(head_r2s))
    min_r2 = float(np.nanmin(head_r2s))
    marker = '✓✓ EXACT' if mean_r2 > 0.9999 else '✓  NEAR' if mean_r2 > 0.999 else '~  STRONG' if mean_r2 > 0.95 else '·  PARTIAL' if mean_r2 > 0.5 else '✗  LOW'
    print(f'  Layer {li} [{att_type}]  mean_R²={mean_r2:.4f}  min={min_r2:.4f}  max={max_r2:.4f}  {marker}')
print(f"\n{'=' * 70}")
print(f'  TEST 3 — Attention weights as natural space')
print(f'  attn_weights (softmax output) → softmax_out (context vectors)')
print(f'  attn_weights shape: (heads, L, L)')
print(f'  context_vectors = attn_weights @ V')
print(f'  If R²=1.000: attn_weights = natural coordinate')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    if not attn_weights_store[li] or not seq_soft[li]:
        continue
    att_type = model.transformer.h[li].attn.attention_type
    aw_flat = [w.flatten() for w in attn_weights_store[li]]
    soft_flat = [s.flatten() for s in seq_soft[li]]
    min_len = min(len(aw_flat), len(soft_flat))
    aw_flat = aw_flat[:min_len]
    soft_flat = soft_flat[:min_len]
    aw_arr = np.array([a[:min(len(a), 1000)] for a in aw_flat], dtype=np.float64)
    soft_arr = np.array([s[:min(len(s), 1000)] for s in soft_flat], dtype=np.float64)
    min_dim = min(aw_arr.shape[1], soft_arr.shape[1])
    aw_arr = aw_arr[:, :min_dim]
    soft_arr = soft_arr[:, :min_dim]
    n = len(aw_arr)
    s = int(n * 0.8)
    if s < 5:
        continue
    Xb = np.c_[aw_arr, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], soft_arr[:s], rcond=None)[0]
        r2_tr = r2_score(Xb[:s] @ W, soft_arr[:s])
        r2_te = r2_score(Xb[s:] @ W, soft_arr[s:])
    except:
        r2_tr = r2_te = float('nan')
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  Layer {li} [{att_type}]  attn_weights → soft_out  R²_tr={r2_tr:.4f}  R²_te={r2_te:.4f}  {marker}')
print(f"\n{'=' * 70}")
print(f'  TEST 4 — Local vs Global attention separated')
print(f'  GPT-Neo alternates: local (even) and global (odd).')
print(f'  Test per-token within each type.')
print(f"{'=' * 70}\n")
local_layers = [li for li in range(n_layers) if model.transformer.h[li].attn.attention_type == 'local']
global_layers = [li for li in range(n_layers) if model.transformer.h[li].attn.attention_type == 'global']
print(f'  Local layers:  {local_layers}')
print(f'  Global layers: {global_layers}\n')
for label, layers in [('LOCAL ', local_layers), ('GLOBAL', global_layers)]:
    all_ln1 = []
    all_soft = []
    for li in layers:
        if seq_ln1[li] and seq_soft[li]:
            all_ln1.append(np.concatenate(seq_ln1[li], axis=0))
            all_soft.append(np.concatenate(seq_soft[li], axis=0))
    if all_ln1:
        X = np.concatenate(all_ln1, axis=0)
        Y = np.concatenate(all_soft, axis=0)
        test_linear_tok(X, Y, f'  {label} all layers combined: ln1→soft')
print(f"\n{'=' * 70}")
print(f'  TEST 5 — QKV projection: ln1_out → Q, K, V separately')
print(f'  QKV = linear projections of ln1_out.')
print(f'  Must be R²=1.000. These are matrices.')
print(f"{'=' * 70}\n")
for li in [0, 3, 7]:
    layer = model.transformer.h[li]
    try:
        W_q = layer.attn.attention.q_proj.weight.detach().float().numpy()
        W_k = layer.attn.attention.k_proj.weight.detach().float().numpy()
        W_v = layer.attn.attention.v_proj.weight.detach().float().numpy()
        if seq_ln1[li]:
            X_tok = np.concatenate(seq_ln1[li], axis=0)
            Q = X_tok @ W_q.T
            K = X_tok @ W_k.T
            V = X_tok @ W_v.T
            test_linear_tok(X_tok, Q, f'  Layer {li}: ln1→Q (matrix mul, no bias)')
            test_linear_tok(X_tok, K, f'  Layer {li}: ln1→K (matrix mul, no bias)')
            test_linear_tok(X_tok, V, f'  Layer {li}: ln1→V (matrix mul, no bias)')
    except Exception as e:
        print(f'  Layer {li}: QKV hook failed: {e}')
print(f"\n{'=' * 70}")
print(f'  SOFTMAX NATURAL SPACE — FINAL SUMMARY')
print(f"{'=' * 70}")
print(f'\n  DECISION MATRIX:\n\n  Per-token ln1 → soft:    0.80-0.97  (proven before)\n    Reason: softmax mixes tokens. Per-token = wrong space.\n\n  Per-sequence ln1 → soft: R²=?  (TEST 1)\n    If 1.000: sequence = natural space of softmax.\n    Softmax natural space = full sequence at once.\n\n  Per-head ln1 → soft:     R²=?  (TEST 2)\n    If 1.000: head = natural space. Softmax is per-head.\n    Each head has own natural space.\n\n  Attn weights → soft:     R²=?  (TEST 3)\n    If 1.000: attn_weights ARE the natural coordinates.\n    Softmax output = linear read of weight patterns.\n\n  QKV projections:         R²=?  (TEST 5)\n    Must be 1.000. Matrices. No nonlinearity.\n    Verification test.\n\n  WHAT THIS PROVES:\n    If any test gives R²=1.000:\n      Found natural space of softmax.\n      Hyper law complete:\n        Per-token space: LN, W1, gelu→W2, W_o, lm_head.\n        Per-[space] space: softmax → R²=1.000.\n      Every operation = exact in its natural space.\n      No error anywhere. LLM = exact machine.\n      Intelligence = crystallization. All else = reading.\n')
print('=' * 70 + '\n')
