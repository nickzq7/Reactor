import torch
import torch.nn as nn
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
import math
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
print_sep('LOAD TinyStories-1M — READ GEOMETRY')
MODEL = 'roneneldan/TinyStories-1M'
tok = AutoTokenizer.from_pretrained(MODEL)
try:
    model = AutoModelForCausalLM.from_pretrained(MODEL, dtype=torch.float32, use_safetensors=True)
except:
    model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.float32)
model.eval()
print(f'  Params: {sum((p.numel() for p in model.parameters())):,}')
print(f'\n  Model structure:')
for name, p in list(model.named_parameters())[:20]:
    print(f'    {name:<55} {str(p.shape)}')
print_sep('EXTRACT W MATRICES — ALL LAYERS')
layers_W = {}
n_layers = model.config.num_layers
hidden = model.config.hidden_size
print(f'  n_layers={n_layers}  hidden_dim={hidden}')
print(f'\n  Extracting W matrices per layer...')
for layer_idx in range(n_layers):
    layer = model.transformer.h[layer_idx]
    W = {}
    try:
        W['attn_q'] = layer.attn.attention.q_proj.weight.detach().float()
        W['attn_k'] = layer.attn.attention.k_proj.weight.detach().float()
        W['attn_v'] = layer.attn.attention.v_proj.weight.detach().float()
        W['attn_o'] = layer.attn.attention.out_proj.weight.detach().float()
    except AttributeError:
        try:
            W['attn_q'] = layer.attn.q_proj.weight.detach().float()
            W['attn_k'] = layer.attn.k_proj.weight.detach().float()
            W['attn_v'] = layer.attn.v_proj.weight.detach().float()
            W['attn_o'] = layer.attn.out_proj.weight.detach().float()
        except:
            pass
    try:
        W['mlp_in'] = layer.mlp.c_fc.weight.detach().float()
        W['mlp_out'] = layer.mlp.c_proj.weight.detach().float()
    except AttributeError:
        try:
            W['mlp_in'] = layer.mlp.fc_in.weight.detach().float()
            W['mlp_out'] = layer.mlp.fc_out.weight.detach().float()
        except:
            pass
    try:
        W['ln1_w'] = layer.ln_1.weight.detach().float()
        W['ln2_w'] = layer.ln_2.weight.detach().float()
    except:
        pass
    layers_W[layer_idx] = W
    keys = list(W.keys())
    shapes = [str(tuple(W[k].shape)) for k in keys[:3]]
    print(f'  Layer {layer_idx}: {keys} shapes={shapes[:3]}')
print_sep('NATURAL FEATURES — WHAT IS CONSTANT ACROSS LAYERS?')
print(f'\n  For each W matrix type, across all {n_layers} layers:\n  Compute geometric properties.\n  \n  Property constant across layers = law of that W type.\n  Same operation as finding constant diff in number sequences.\n  But for matrix geometry.\n')

def matrix_features(W):
    W_np = W.numpy() if isinstance(W, torch.Tensor) else W
    feats = {}
    try:
        U, S, Vt = np.linalg.svd(W_np, full_matrices=False)
        feats['sv_max'] = float(S[0])
        feats['sv_min'] = float(S[-1])
        feats['sv_mean'] = float(S.mean())
        feats['sv_std'] = float(S.std())
        feats['sv_ratio'] = float(S[0] / (S[-1] + 1e-10))
        feats['sv_entropy'] = float(-(S / S.sum() * np.log(S / S.sum() + 1e-10)).sum())
        sv_norm = S / S.sum()
        feats['eff_rank'] = float(np.exp(-(sv_norm * np.log(sv_norm + 1e-10)).sum()))
    except:
        pass
    feats['frob_norm'] = float(np.linalg.norm(W_np, 'fro'))
    feats['spec_norm'] = float(np.linalg.norm(W_np, 2))
    feats['mean'] = float(W_np.mean())
    feats['std'] = float(W_np.std())
    feats['abs_mean'] = float(np.abs(W_np).mean())
    if W_np.ndim == 2:
        try:
            rank = np.linalg.matrix_rank(W_np, tol=0.001)
            feats['rank'] = float(rank)
            feats['rank_ratio'] = float(rank / min(W_np.shape))
        except:
            pass
    return feats

def r_squared(values):
    n = len(values)
    if n < 2:
        return 0.0
    x = np.arange(n, dtype=float)
    y = np.array(values, dtype=float)
    if y.std() < 1e-12:
        return 1.0
    coeffs = np.polyfit(x, y, 1)
    y_pred = np.polyval(coeffs, x)
    ss_res = ((y - y_pred) ** 2).sum()
    ss_tot = ((y - y.mean()) ** 2).sum()
    return float(1 - ss_res / (ss_tot + 1e-12))

def r_squared_const(values):
    y = np.array(values, dtype=float)
    if y.std() < 1e-12:
        return 1.0
    ss_res = ((y - y.mean()) ** 2).sum()
    ss_tot = ((y - 0) ** 2).sum()
    return float(1 - ss_res / (ss_tot + 1e-12))
W_types = ['attn_q', 'attn_k', 'attn_v', 'attn_o', 'mlp_in', 'mlp_out']
W_types = [t for t in W_types if t in layers_W[0]]
print(f'  W types found: {W_types}\n')
all_results = {}
for wtype in W_types:
    feat_series = {}
    for layer_idx in range(n_layers):
        W = layers_W[layer_idx].get(wtype)
        if W is None:
            continue
        feats = matrix_features(W)
        for fname, fval in feats.items():
            if fname not in feat_series:
                feat_series[fname] = []
            feat_series[fname].append(fval)
    all_results[wtype] = feat_series
print_sep('FIND THE META-LAW')
print(f'\n  For each (W_type, feature):\n  R² of feature values across {n_layers} layers.\n  \n  R²=1.0 → perfectly constant → LAW FOUND\n  R²=0.0 → random → no law\n  \n  We are looking for the formula that governs\n  how W matrices evolve from layer 0 to layer 7.\n')
print(f"\n  {'W_type':<12}  {'Feature':<15}  {'Values across layers':<45}  {'R²':>6}  Law?")
print(f"  {'─' * 95}")
meta_laws = []
for wtype in W_types:
    feat_series = all_results[wtype]
    for fname, values in sorted(feat_series.items()):
        if len(values) < n_layers:
            continue
        r2_lin = r_squared(values)
        r2_const = r_squared_const(values)
        r2 = max(r2_lin, r2_const)
        vals_str = ' '.join((f'{v:.3f}' for v in values))
        is_law = r2 > 0.95
        mark = 'LAW ←' if r2 > 0.99 else 'strong' if r2 > 0.95 else ''
        if r2 > 0.85 or fname in ['sv_mean', 'sv_std', 'frob_norm', 'eff_rank']:
            print(f'  {wtype:<12}  {fname:<15}  {vals_str:<45}  {r2:>6.4f}  {mark}')
        if is_law:
            meta_laws.append((wtype, fname, values, r2, 'const' if r2_const > r2_lin else 'linear'))
print_sep('META-LAWS FOUND')
if not meta_laws:
    print(f'  No R²>0.95 laws found with current features.')
    print(f'  Trying deeper analysis...')
    print(f"\n  RATIO ANALYSIS (W_n / W_{'{n-1}'}):")
    print(f"  {'W_type':<12}  {'Feature':<15}  {'Ratios layer0→7':<50}  R²")
    print(f"  {'─' * 85}")
    for wtype in W_types:
        feat_series = all_results[wtype]
        for fname in ['sv_mean', 'frob_norm', 'sv_max', 'eff_rank']:
            values = feat_series.get(fname, [])
            if len(values) < 2:
                continue
            ratios = [values[i] / values[i - 1] for i in range(1, len(values)) if abs(values[i - 1]) > 1e-10]
            if not ratios:
                continue
            r2 = r_squared_const(ratios)
            vals_str = ' '.join((f'{v:.4f}' for v in ratios))
            mark = 'CONSTANT RATIO = LAW ←' if r2 > 0.95 else ''
            print(f'  {wtype:<12}  {fname:<15}  {vals_str:<50}  {r2:.4f}  {mark}')
            if r2 > 0.95:
                meta_laws.append((wtype, f'ratio_{fname}', ratios, r2, 'geometric'))
print_sep('PRINCIPAL ANGLE EVOLUTION')
print(f'\n  Not just magnitude — DIRECTION.\n  How does the principal direction of W rotate\n  from layer 0 to layer {n_layers - 1}?\n  \n  If rotation angle is constant = geometric series law.\n  Model rotates in a formula. Calculate not compute.\n')
for wtype in W_types[:3]:
    print(f'\n  W type: {wtype}')
    W_matrices = [layers_W[i][wtype].numpy() for i in range(n_layers) if wtype in layers_W[i]]
    if len(W_matrices) < 2:
        continue
    principal_dirs = []
    for W in W_matrices:
        try:
            U, S, Vt = np.linalg.svd(W, full_matrices=False)
            principal_dirs.append(U[:, 0])
        except:
            pass
    if len(principal_dirs) < 2:
        continue
    angles = []
    for i in range(1, len(principal_dirs)):
        cos_angle = np.clip(abs(np.dot(principal_dirs[i - 1], principal_dirs[i])), 0, 1)
        angle = math.degrees(math.acos(cos_angle))
        angles.append(angle)
    r2 = r_squared_const(angles)
    print(f"  Rotation angles layer-to-layer: {' '.join((f'{a:.2f}°' for a in angles))}")
    print(f"  R² of constant angle: {r2:.4f}  {('← CONSTANT ROTATION = LAW' if r2 > 0.8 else '')}")
    W0 = W_matrices[0]
    U0, _, _ = np.linalg.svd(W0, full_matrices=False)
    dir0 = U0[:, 0]
    cum_angles = []
    for W in W_matrices:
        Un, _, _ = np.linalg.svd(W, full_matrices=False)
        dirn = Un[:, 0]
        cos_a = np.clip(abs(np.dot(dir0, dirn)), 0, 1)
        cum_angles.append(math.degrees(math.acos(cos_a)))
    layers_x = np.arange(len(cum_angles))
    r2_lin = r_squared(cum_angles)
    print(f"  Cumulative angles from layer 0: {' '.join((f'{a:.1f}°' for a in cum_angles))}")
    print(f"  R² linear fit: {r2_lin:.4f}  {('← LINEAR ROTATION = FORMULA' if r2_lin > 0.9 else '')}")
    if r2_lin > 0.9:
        coeffs = np.polyfit(layers_x, cum_angles, 1)
        print(f'  Formula: angle(layer_n) = {coeffs[0]:.3f}×n + {coeffs[1]:.3f}°')
        meta_laws.append((wtype, 'rotation_angle', cum_angles, r2_lin, 'linear'))
print_sep('META-LAW VERIFICATION')
if meta_laws:
    print(f'\n  Meta-laws found: {len(meta_laws)}\n')
    for wtype, fname, values, r2, law_type in meta_laws:
        print(f'  {wtype}.{fname}: R²={r2:.4f}  type={law_type}')
        print(f'    Values: {[round(v, 4) for v in values[:8]]}')
    best = max(meta_laws, key=lambda x: x[3])
    wtype, fname, values, r2, law_type = best
    print(f'\n  BEST META-LAW: {wtype}.{fname}')
    print(f'  R² = {r2:.6f}')
    print(f'  Type: {law_type}')
    if law_type == 'geometric' and 'ratio' in fname:
        mean_ratio = np.mean(values)
        print(f'\n  Formula: W_n_feature = W_0_feature × {mean_ratio:.6f}^n')
        print(f'\n  Verification — predict each layer from layer 0:')
        orig_feat = fname.replace('ratio_', '')
        orig_vals = all_results[wtype][orig_feat]
        print(f"  {'Layer':>6}  {'Actual':>12}  {'Predicted':>12}  {'Error':>10}")
        print(f"  {'─' * 45}")
        v0 = orig_vals[0]
        for n, actual in enumerate(orig_vals):
            predicted = v0 * mean_ratio ** n
            error = abs(actual - predicted) / (abs(actual) + 1e-10)
            print(f'  {n:>6}  {actual:>12.6f}  {predicted:>12.6f}  {error:>9.4%}')
    elif law_type == 'linear':
        layers_x = np.arange(len(values))
        coeffs = np.polyfit(layers_x, values, 1)
        print(f'\n  Formula: feature(layer_n) = {coeffs[0]:.4f}×n + {coeffs[1]:.4f}')
        print(f'\n  Verification:')
        print(f"  {'Layer':>6}  {'Actual':>10}  {'Predicted':>10}  {'Error':>8}")
        print(f"  {'─' * 40}")
        for n, actual in enumerate(values):
            predicted = np.polyval(coeffs, n)
            error = abs(actual - predicted) / (abs(actual) + 1e-10)
            print(f'  {n:>6}  {actual:>10.4f}  {predicted:>10.4f}  {error:>7.2%}')
else:
    print(f'  No strong meta-laws found yet.')
    print(f"  This means: W matrices don't follow simple formula.")
    print(f'  This itself is a finding — see below.')
print_sep('WHAT THE GEOMETRY ACTUALLY SAYS')
print(f'\n  Raw geometry of each layer (all features):\n')
for wtype in W_types[:2]:
    print(f'  ── {wtype} ──')
    feat_series = all_results[wtype]
    headers = ['frob_norm', 'sv_max', 'sv_mean', 'sv_std', 'eff_rank', 'rank_ratio']
    headers = [h for h in headers if h in feat_series]
    print(f"  {'Layer':>6}  " + '  '.join((f'{h:>12}' for h in headers)))
    print(f"  {'─' * 80}")
    for layer_idx in range(n_layers):
        vals = [feat_series[h][layer_idx] if layer_idx < len(feat_series.get(h, [])) else float('nan') for h in headers]
        print(f'  {layer_idx:>6}  ' + '  '.join((f'{v:>12.4f}' for v in vals)))
    print()
print(f'\n  INTERPRETATION:\n\n  If values are CONSTANT across layers:\n    Model learned same transformation depth.\n    Formula: W_n = W_0 (trivial — just copy).\n    \n  If values follow LINEAR trend:\n    Model gradually transforms.\n    Formula: W_n = W_0 + n×delta.\n    Calculate layer N directly from layer 0.\n    \n  If values follow GEOMETRIC trend:\n    Model exponentially transforms.\n    Formula: W_n = W_0 × ratio^n.\n    Calculate any layer from W_0 and ratio.\n    \n  If values are RANDOM:\n    Each layer learned independently.\n    No meta-law. Model needed all layers.\n    Cannot compress further.\n    \n  Whatever we found — this is the truth of this model.\n  Data says. We listen.\n  \n  This is meta-intelligence:\n  Not processing the world.\n  Understanding own structure.\n  Then: calculate not compute.\n')
