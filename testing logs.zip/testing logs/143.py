import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D16 = meta['DA']
H = meta['HA']
NL = meta['NLA']
D2 = 2
DONOR_IDX = 4
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s
fib = gen_fib(40)

def make_all_patterns():
    pats = {}
    for off in range(8):
        pats[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
    return pats
ALL_PATS = make_all_patterns()
PAT_NAMES = list(ALL_PATS.keys())

class SeqT(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.d = d
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, H, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_donor():
    path = os.path.join(_dir, f'donor_{DONOR_IDX:02d}.npz')
    W = np.load(path)
    state = {k: torch.tensor(v.astype(np.float32)) for k, v in W.items()}
    m = SeqT(D16).to(device)
    m.load_state_dict(state, strict=True)
    return m

def eval_model(model):
    model.eval()
    scores = []
    for pn in PAT_NAMES:
        seq, truth = ALL_PATS[pn]
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        scores.append(p == truth)
    return (sum(scores), scores)

def eval_wte2(wte2_np, scratch):
    with torch.no_grad():
        scratch.wte.weight.copy_(torch.tensor(wte2_np, dtype=torch.float32))
    return eval_model(scratch)

def mutate_wte2(wte, rng):
    w = wte.copy()
    op = rng.choice(['sign_flip', 'rot', 'scale', 'noise', 'token_shift', 'inject', 'stretch'])
    if op == 'sign_flip':
        dims = rng.choice(2, rng.randint(1, 3), replace=False)
        w[:, dims] *= -1
    elif op == 'rot':
        ang = rng.uniform(0, 2 * math.pi)
        c, s = (math.cos(ang), math.sin(ang))
        x0 = w[:, 0].copy()
        x1 = w[:, 1].copy()
        w[:, 0] = c * x0 - s * x1
        w[:, 1] = s * x0 + c * x1
    elif op == 'scale':
        w[:, 0] *= rng.uniform(0.2, 3.0)
        w[:, 1] *= rng.uniform(0.2, 3.0)
    elif op == 'noise':
        strength = rng.uniform(0.01, 0.3) * np.std(w)
        w += rng.randn(*w.shape) * strength
    elif op == 'token_shift':
        toks = rng.choice(VS, rng.randint(1, VS // 3 + 1), replace=False)
        shift = rng.randn(2) * np.std(w) * rng.uniform(0.05, 0.5)
        w[toks] += shift
    elif op == 'inject':
        angles = np.linspace(0, 2 * math.pi, VS, endpoint=False)
        angles += rng.uniform(0, 2 * math.pi)
        r = np.std(w) * rng.uniform(0.5, 2.0)
        circle = np.stack([r * np.cos(angles), r * np.sin(angles)], axis=1)
        alpha = rng.uniform(0.05, 0.5)
        w = (1 - alpha) * w + alpha * circle
    elif op == 'stretch':
        ang = rng.uniform(0, math.pi)
        axis = np.array([math.cos(ang), math.sin(ang)])
        proj = (w @ axis)[:, None] * axis[None, :]
        factor = rng.uniform(0.3, 3.0)
        w = w + (factor - 1) * proj
    return w

def crossbreed_wte2(wte_list, rng):
    child = np.zeros_like(wte_list[0])
    for d in range(D2):
        child[:, d] = wte_list[rng.randint(len(wte_list))][:, d]
    if rng.rand() < 0.5:
        ang = rng.uniform(0, 2 * math.pi)
        c, s = (math.cos(ang), math.sin(ang))
        x0 = child[:, 0].copy()
        x1 = child[:, 1].copy()
        child[:, 0] = c * x0 - s * x1
        child[:, 1] = s * x0 + c * x1
    return child

def build_tensors():
    Xs = []
    Ys = []
    for pn in PAT_NAMES:
        seq, _ = ALL_PATS[pn]
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long, device=device), torch.tensor(Ys, dtype=torch.long, device=device))
ALL_X, ALL_Y = build_tensors()

def train_child2(init_wte2, steps=3000, lr=0.003, print_every=300):
    model = SeqT(D2).to(device)
    for name, param in model.named_parameters():
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.zeros_(param)
    with torch.no_grad():
        model.wte.weight.copy_(torch.tensor(init_wte2, dtype=torch.float32))
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, scores = eval_model(model)
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            bar = ''.join(('█' if x else '░' for x in scores))
            print(f'  step {step:>5}: {sc}/8  {bar}', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    return (best_s, model)

def plot_geometry(model, label):
    wte = model.wte.weight.detach().numpy()
    fig, ax = plt.subplots(1, 1, figsize=(7, 7))
    ax.scatter(wte[:, 0], wte[:, 1], c=np.arange(VS), cmap='hsv', s=80, zorder=3)
    for i in range(VS):
        ax.annotate(str(i), (wte[i, 0], wte[i, 1]), fontsize=7, ha='center', va='bottom')
    fib_seq = [f % VS for f in fib[:20]]
    for i in range(len(fib_seq) - 1):
        t0, t1 = (fib_seq[i], fib_seq[i + 1])
        ax.annotate('', xy=(wte[t1, 0], wte[t1, 1]), xytext=(wte[t0, 0], wte[t0, 1]), arrowprops=dict(arrowstyle='->', color='blue', alpha=0.4))
    ax.set_title(f'D=2 Token Geometry — {label}\nFibonacci path shown in blue')
    ax.set_xlabel('dim 0')
    ax.set_ylabel('dim 1')
    ax.axhline(0, color='gray', linewidth=0.5)
    ax.axvline(0, color='gray', linewidth=0.5)
    ax.set_aspect('equal')
    path = os.path.join(_dir, f'geometry_{label}.png')
    plt.tight_layout()
    plt.savefig(path, dpi=120)
    plt.close()
    print(f'  Plot saved: {path}')
print('=' * 60)
print('  SCRIPT 1 — FIBONACCI D=16 → D=2 CHILD')
print('=' * 60)
print(f'\n  Loading donor_04.npz (fibonacci)...')
donor = load_donor()
sc, scores = eval_model(donor)
print(f"  Donor score: {sc}/8  {''.join(('█' if x else '░' for x in scores))}")
print(f'  Donor WTE shape: {donor.wte.weight.shape}')
wte16 = donor.wte.weight.detach().numpy().astype(np.float64)
try:
    U, s_sv, Vt = np.linalg.svd(wte16, full_matrices=False)
    wte16_2d = U[:, :2] * s_sv[:2]
    donor_2d_model = SeqT(D2).to(device)
    for name, param in donor_2d_model.named_parameters():
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.zeros_(param)
    with torch.no_grad():
        donor_2d_model.wte.weight.copy_(torch.tensor(wte16_2d, dtype=torch.float32))
    plot_geometry(donor_2d_model, 'donor16_pca2d')
    print(f'  Donor PCA-2D geometry plotted (reference only)')
except Exception as e:
    print(f'  Plot skipped: {e}')
N_MUTATIONS = 10000
NICHE_SIZE = 8
print(f"\n{'=' * 60}")
print(f'  MUTATION SEARCH: D=16 → D=2')
print(f'  {N_MUTATIONS} mutations, goal = 8/8')
print(f"{'=' * 60}")
rng = np.random.RandomState(42)
scratch2 = SeqT(D2).to(device)
for name, param in scratch2.named_parameters():
    if 'wte' not in name:
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.zeros_(param)
U, s_sv, Vt = np.linalg.svd(wte16, full_matrices=False)
seed_svd = (U[:, :D2] * s_sv[:D2]).astype(np.float64)
seeds = [seed_svd]
for _ in range(10):
    P = rng.randn(D16, D2) * 0.1
    seeds.append((wte16 @ P).astype(np.float64))
print(f'\n  Seed scores (SVD + random projections):')
best_seed_sc = 0
for i, seed in enumerate(seeds):
    sc, _ = eval_wte2(seed, scratch2)
    if sc > best_seed_sc:
        best_seed_sc = sc
    if i == 0:
        print(f'    SVD seed: {sc}/8')
niches = [[] for _ in range(8)]
global_best = (best_seed_sc, seed_svd.copy())
t0 = time.time()
op_counts = {}
for mi in range(N_MUTATIONS):
    r = rng.rand()
    if r < 0.3:
        base = seeds[rng.randint(len(seeds))].copy()
    elif r < 0.65:
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        if nonempty:
            ni = rng.choice(nonempty)
            _, base = niches[ni][rng.randint(len(niches[ni]))]
            base = base.copy()
        else:
            base = seeds[rng.randint(len(seeds))].copy()
    else:
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        if len(nonempty) >= 2:
            srcs = [niches[rng.choice(nonempty)][0][1] for _ in range(rng.randint(2, 4))]
            base = crossbreed_wte2(srcs, rng)
        else:
            base = seeds[rng.randint(len(seeds))].copy()
    n_ops = 1 if rng.rand() < 0.6 else 2
    wte2 = base
    for _ in range(n_ops):
        wte2 = mutate_wte2(wte2, rng)
    total, scores = eval_wte2(wte2, scratch2)
    if total > global_best[0]:
        global_best = (total, wte2.copy())
        bar = ''.join(('█' if x else '░' for x in scores))
        print(f'  mut {mi:>6}  NEW BEST: {total}/8  {bar}', flush=True)
        if total == 8:
            print(f'  *** 8/8 FOUND at mutation {mi}! ***', flush=True)
            break
    for i, ok in enumerate(scores):
        if ok:
            niches[i].append((1, wte2.copy()))
            niches[i].sort(key=lambda x: x[0], reverse=True)
            niches[i] = niches[i][:NICHE_SIZE]
    if (mi + 1) % 2000 == 0:
        print(f'  {mi + 1}/{N_MUTATIONS}  best={global_best[0]}/8  niches={[len(n) for n in niches]}  {time.time() - t0:.0f}s', flush=True)
print(f'\n  Search done in {time.time() - t0:.1f}s')
print(f'  Best WTE found: {global_best[0]}/8')
print(f"\n{'=' * 60}")
print(f'  TRAINING D=2 CHILD')
print(f'  Init WTE score: {global_best[0]}/8')
print(f'  3000 steps on fibonacci patterns')
print(f"{'=' * 60}\n")
t1 = time.time()
final_sc, child = train_child2(global_best[1], steps=3000, lr=0.003, print_every=300)
print(f'\n  Plotting D=2 geometry of trained child...')
try:
    plot_geometry(child, 'child_d2_fibonacci')
except Exception as e:
    print(f'  Plot failed: {e}')
sc, scores = eval_model(child)
wte2_final = child.wte.weight.detach().numpy()
print(f"\n{'=' * 60}")
print(f'  FINAL RESULTS — FIBONACCI D=16 → D=2')
print(f"{'=' * 60}")
print(f'\n  Transfer score: {sc}/8')
print(f'  Pattern results:')
for i, (pn, ok) in enumerate(zip(PAT_NAMES, scores)):
    seq, truth = ALL_PATS[pn]
    ids = torch.tensor([seq[-K:]], dtype=torch.long)
    with torch.no_grad():
        p = int(child(ids)[0, -1].argmax())
    print(f"    {pn}  {('✓' if ok else '✗')}  truth={truth}  pred={p}")
print(f'\n  D=2 WTE geometry (each token = point in 2D):')
norms = np.linalg.norm(wte2_final, axis=1)
angles = np.arctan2(wte2_final[:, 1], wte2_final[:, 0]) * 180 / math.pi
print(f'  Token norms: min={norms.min():.3f}  max={norms.max():.3f}  mean={norms.mean():.3f}')
print(f'  Are tokens on a circle? std(norms)/mean(norms) = {norms.std() / norms.mean():.3f}  (0=perfect circle)')
fib_tokens = list(dict.fromkeys([f % VS for f in fib[:20]]))
fib_angles = angles[fib_tokens]
print(f'\n  Fibonacci token angles (degrees):')
for tok, ang in zip(fib_tokens[:10], fib_angles[:10]):
    print(f'    token {tok:>3}: {ang:>8.2f}°')
print(f'\n  Total time: {time.time() - t0:.0f}s')
print(f'\n  NEXT STEP:')
print(f'  If {sc}/8 → geometry is clear → move to Script 2 (2 donors)')
print(f'  If <8/8  → mutation search needs adjustment first')
print('=' * 60)
