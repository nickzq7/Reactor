import numpy as np
import torch
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — RESIDUAL STREAM SEMANTIC RAM')
print('  x = complete state. x = the address. W law.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={n_layers}')
print(f'  Address space: {D}-dimensional float vectors')
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()
LW = {}
with torch.no_grad():
    for l in range(n_layers):
        blk = model.transformer.h[l]
        att = blk.attn.attention
        LW[l] = {'Wq': att.q_proj.weight.numpy(), 'Wk': att.k_proj.weight.numpy(), 'Wv': att.v_proj.weight.numpy(), 'Wo': att.out_proj.weight.numpy(), 'bo': att.out_proj.bias.numpy(), 'W1': blk.mlp.c_fc.weight.numpy(), 'b1': blk.mlp.c_fc.bias.numpy(), 'W2': blk.mlp.c_proj.weight.numpy(), 'b2': blk.mlp.c_proj.bias.numpy(), 'ln1_w': blk.ln_1.weight.numpy(), 'ln1_b': blk.ln_1.bias.numpy(), 'ln2_w': blk.ln_2.weight.numpy(), 'ln2_b': blk.ln_2.bias.numpy()}

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def cosine_sim_batch(v, M):
    v_n = v / (np.linalg.norm(v) + 1e-08)
    M_n = M / (np.linalg.norm(M, axis=1, keepdims=True) + 1e-08)
    return M_n @ v_n

def run_layer(x, W, seq_len, last_only=False):
    ln1 = ln(x, W['ln1_w'], W['ln1_b'])
    Q = ln1 @ W['Wq'].T
    K = ln1 @ W['Wk'].T
    V = ln1 @ W['Wv'].T
    Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
    mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
    heads = [softmax(Qh[h] @ Kh[h].T + mask) @ Vh[h] for h in range(n_heads)]
    att_out = np.stack(heads, 1).reshape(seq_len, D) @ W['Wo'].T + W['bo']
    x = x + att_out
    pre = ln(x, W['ln2_w'], W['ln2_b']) @ W['W1'].T + W['b1']
    x = x + gelu(pre) @ W['W2'].T + W['b2']
    return x

def forward_with_x_ram(token_ids, RAM, cos_threshold):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    for l in range(n_layers):
        x = run_layer(x, LW[l], seq_len)
        x_last = x[-1]
        if len(RAM[l]['x']) > 0:
            sims = cosine_sim_batch(x_last, RAM[l]['x'])
            best_idx = int(np.argmax(sims))
            best_sim = float(sims[best_idx])
            if best_sim >= cos_threshold:
                return (int(RAM[l]['tokens'][best_idx]), l, best_sim)
    h_f = ln(x, lnf_w, lnf_b)
    return (int(np.argmax((h_f[-1:] @ lm_w.T)[0])), -1, 0.0)

def forward_full(token_ids):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    for l in range(n_layers):
        x = run_layer(x, LW[l], seq_len)
    h_f = ln(x, lnf_w, lnf_b)
    return int(np.argmax((h_f[-1:] @ lm_w.T)[0]))
print(f"\n{'=' * 70}")
print(f'  PHASE 1 — BUILD RAM (x vectors as addresses)')
print(f"{'=' * 70}\n")
SET_A = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon lived', 'A small dog ran across the green field', 'When the sun came up in the morning the birds', 'She smiled and said to her mother I love', 'The children played in the garden all day long', 'Every morning the little bird sang a sweet song', 'He found a treasure chest in the old cave', 'The princess looked out of her window and saw', 'A tiny mouse ran across the kitchen floor quietly', 'The old wizard cast a magic spell on the dragon', 'They walked through the dark cave together slowly', 'The baby bear found honey in the tall old tree', 'Far away in the mountains there lived a giant', 'A butterfly flew over the flowers in the meadow', 'The farmer woke up early and fed his animals', 'She picked up the book and began to read it', 'The little boat sailed across the calm blue lake', 'A rainbow appeared in the sky after the rain', 'The friendly fox helped the rabbit find her way home']
RAM = {l: {'x': [], 'tokens': []} for l in range(n_layers)}
x_after = {l: [] for l in range(n_layers)}

def make_hook(l):

    def hook(m, inp, out):
        x_after[l].append(out[0][0, -1, :].detach().numpy().copy())
    return hook
hooks = [model.transformer.h[l].register_forward_hook(make_hook(l)) for l in range(n_layers)]
with torch.no_grad():
    for prompt in SET_A:
        ids = tokenizer.encode(prompt, return_tensors='pt')
        for _ in range(25):
            out = model(ids)
            nxt = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                RAM[l]['x'].append(x_after[l].pop())
                RAM[l]['tokens'].append(nxt)
            ids = torch.cat([ids, torch.tensor([[nxt]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM[l]['x'] = np.array(RAM[l]['x'], dtype=np.float32)
    RAM[l]['tokens'] = np.array(RAM[l]['tokens'], dtype=np.int32)
total_ram = len(RAM[0]['tokens'])
print(f'  RAM: {total_ram} entries per layer')
print(f'  Each entry: {D}-float x vector = {D * 4} bytes')
print(f'  Total RAM: {total_ram * D * 4 * n_layers / 1024:.1f} KB')
print(f"  Unique tokens: {len(np.unique(RAM[0]['tokens']))}")
print(f"\n{'=' * 70}")
print(f'  PHASE 2 — GENERALIZATION TEST (SET B, never in SET A)')
print(f"{'=' * 70}\n")
SET_B = ['The queen wore a golden crown and sat', 'A little fish swam in the clear blue pond', 'The farmer planted seeds in the dark soil', 'In a land far away there was a castle', 'Her eyes sparkled when she saw the present', 'The young boy climbed the tall oak tree', 'A white rabbit hopped through the green garden', 'The cook made a delicious soup for everyone']
N_GEN = 20
THRESHOLDS = [0.999, 0.998, 0.995, 0.99, 0.98, 0.95]
print(f"  {'Threshold':<12} {'EE%':<10} {'Acc%':<10} {'Layers/tok':<14} {'verdict'}")
print(f"  {'─' * 54}")
best_result = None
for thresh in THRESHOLDS:
    correct = 0
    total = 0
    ee_count = 0
    layers_sum = 0
    for prompt in SET_B:
        ids_true = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        ids_ee = ids_true.copy()
        for step in range(N_GEN):
            true_next = forward_full(ids_true)
            ids_true.append(true_next)
            ee_next, exit_layer, sim = forward_with_x_ram(ids_ee, RAM, thresh)
            ids_ee.append(ee_next)
            total += 1
            correct += ee_next == true_next
            if exit_layer >= 0:
                ee_count += 1
                layers_sum += exit_layer + 1
            else:
                layers_sum += n_layers
    acc = 100 * correct / total
    ee_pct = 100 * ee_count / total
    avg_layers = layers_sum / total
    v = '✓ EXACT' if acc == 100 else '✓ GOOD' if acc >= 90 else '~ USABLE' if acc >= 70 else '✗ POOR'
    print(f'  {thresh:<12.3f} {ee_pct:<10.1f}% {acc:<10.1f}% {avg_layers:<14.2f} {v}')
    if best_result is None or (acc >= 90 and ee_pct > 0):
        best_result = (thresh, acc, ee_pct, avg_layers)
print(f"\n{'=' * 70}")
print(f'  PHASE 3 — TOKEN VIEW (threshold=0.995)')
print(f"{'=' * 70}\n")
thresh = 0.995
for prompt in SET_B[:2]:
    ids_true = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    ids_ee = ids_true.copy()
    print(f'  Prompt: {prompt}')
    print(f"  {'Step':<6} {'True':<16} {'EE':<16} {'Layer':<12} {'Sim':<8} {'Match'}")
    print(f"  {'─' * 60}")
    for step in range(12):
        true_next = forward_full(ids_true)
        ee_next, el, sim = forward_with_x_ram(ids_ee, RAM, thresh)
        ids_true.append(true_next)
        ids_ee.append(ee_next)
        ts = repr(tokenizer.decode([true_next]))[:14]
        es = repr(tokenizer.decode([ee_next]))[:14]
        el_s = f'L{el}' if el >= 0 else 'full'
        print(f"  {step + 1:<6} {ts:<16} {es:<16} {el_s:<12} {sim:<8.4f} {('✓' if ee_next == true_next else '✗')}")
    print()
print(f"\n{'=' * 70}")
print(f'  PHASE 4 — SPEED RACE (100 tokens)')
print(f"{'=' * 70}\n")
thresh = 0.995
race_prompt = 'The queen wore a golden crown and'
ids_base = tokenizer.encode(race_prompt, return_tensors='pt')[0].tolist()
t0 = time.time()
for _ in range(100):
    ids_base.append(forward_full(ids_base))
t_base = time.time() - t0
ids_ee = tokenizer.encode(race_prompt, return_tensors='pt')[0].tolist()
ee_used = 0
t0 = time.time()
for _ in range(100):
    nxt, el, _ = forward_with_x_ram(ids_ee, RAM, thresh)
    ids_ee.append(nxt)
    if el >= 0:
        ee_used += 1
t_ee = time.time() - t0
match = sum((a == b for a, b in zip(ids_base[len(tokenizer.encode(race_prompt)):], ids_ee[len(tokenizer.encode(race_prompt)):])))
print(f'  Baseline:    {t_base:.3f}s ({100 / t_base:.1f} tok/s)')
print(f'  x-RAM exit:  {t_ee:.3f}s ({100 / t_ee:.1f} tok/s)')
print(f'  Speedup:     {t_base / t_ee:.2f}x')
print(f'  EE used:     {ee_used}/100')
print(f'  Token match: {match}/100 = {match}%')
print(f"\n{'=' * 70}")
print(f'  W LAW CONCLUSION')
print(f"{'=' * 70}\n")
print(f'\n  GeLU bits (256 bits) = FAILED.\n    Lossy projection. Context lost. 65% accuracy max.\n\n  x residual stream (64 floats) = THIS TEST.\n    x = complete universe state (W law).\n    x contains all context accumulated.\n    Cosine similarity on x = true semantic matching.\n\n  If Acc > 90% at any threshold with EE > 0%:\n    x is universal semantic address.\n    W law proven: same x state = same computation = same token.\n    Early exit is valid. Physics, not approximation.\n\n  If Acc < 90%:\n    x states do not repeat across different contexts.\n    Each conversation = unique x trajectory.\n    Early exit only valid as inference cache (repeated queries).\n    \n  EITHER RESULT IS HONEST.\n  The W law is real regardless.\n  x IS the state. The question is only:\n  how often does the same state appear in different contexts?\n')
print('=' * 70 + '\n')
