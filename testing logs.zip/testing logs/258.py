import numpy as np
import torch
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL TRAINER v3 — RIDGE REGRESSION')
print('  Fixing FFN null space. ATT already perfect.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model_ref = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model_ref.eval()
n_layers = model_ref.config.num_layers
n_heads = model_ref.config.num_attention_heads
D = model_ref.config.hidden_size
head_dim = D // n_heads

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_np(x):
    x = x.astype(np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def quad_kernel(x):
    x = np.array(x, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(1, -1)
    N, d = x.shape
    i, j = np.triu_indices(d)
    return np.hstack([x, x[:, i] * x[:, j]])

def solve_ridge(Phi, Y, lam=0.0001):
    Phi = np.array(Phi, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Pb = np.hstack([Phi, np.ones((len(Phi), 1))])
    A = Pb.T @ Pb
    A += lam * np.eye(A.shape[0])
    b = Pb.T @ Y
    W = np.linalg.solve(A, b)
    Yp = Pb @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    r2 = float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0
    return (W, r2)
TRAIN_PROMPTS = ['Once upon a time a little girl named Lily', 'Deep in the forest there lived a dragon', 'A small dog ran across the green field', 'The brave knight rode into the dark cave', 'She opened the door and smiled at her friend', 'Every morning the birds sang in the tall tree', 'He found a golden key under the old bridge', 'The children played and laughed in the garden', 'Far away there lived a kind old wizard', 'A tiny mouse found some cheese in the barn', 'The princess wore a crown and sat on the throne', 'A rainbow appeared in the sky after the rain', 'The farmer planted seeds in the rich dark soil', 'She read a book about dragons and magic spells', 'The river flowed gently through the green valley', 'A butterfly landed softly on the red flower', 'The ship sailed across the deep blue ocean', 'The moon rose high above the sleeping town', 'A bear found honey in a hollow tree trunk', 'The wind carried the leaves high into the air', 'Once there was a boy who loved to explore', 'The cat sat by the warm fire and purred', 'He climbed the tall mountain and saw the sky', 'She sang a song that made everyone smile', 'A fox ran through the forest looking for food', 'The old man told stories to the young children', 'A baby bird fell from its nest in the oak', 'The cook made a soup that smelled wonderful', 'He drew a picture of his house and garden', 'The queen walked through the market with grace', 'Once a young prince found a magic mirror', 'The stars shone bright above the sleeping child', 'A little fish swam in the clear blue pond', 'The baker made fresh bread every single morning', 'She found a map that led to buried treasure', 'The little rabbit hopped through the meadow', 'Once a young boy found a magic stone', 'The old lighthouse stood by the stormy sea', 'A girl named Emma loved to paint pictures', 'The dragon breathed fire and the village ran', 'A kind witch lived in the old apple orchard', 'The tiny boat sailed far across the great lake', 'He whispered a secret into the old oak tree', 'The clever fox outsmarted the hungry wolf again', 'A magic carpet flew high above the golden city', 'The snow fell softly on the sleeping village', 'She found a door hidden behind the waterfall', 'The little prince asked why the stars were bright', 'A dragon egg hatched under the full blue moon', 'The shepherd counted stars until he fell asleep', 'The old clock ticked slowly in the quiet room', 'A young girl learned to fly on a broomstick', 'The river whispered secrets to the listening stones', 'He opened the treasure chest and found a map', 'The wolf howled at the moon above the hills', 'She planted a seed and a great tree grew', 'The knight bowed before the wise old queen', 'A tiny star fell gently into the child hand', 'The baker smiled and gave the boy fresh bread', 'Deep underground a city of gnomes was hidden', 'The little owl asked who had taken the moon', 'A princess danced alone in the empty tower', 'The giant sat down and the earth shook gently', 'He found a bottle with a message inside it', 'The fairy left a gift under the sleeping child', 'A wolf pup howled for the first time at dawn', 'The wizard opened his eyes and saw the future', 'She whispered to the river and it changed course', 'A golden bird sang and the flowers all bloomed', 'The boy asked the star how far away it was', 'Deep in the cave the treasure chest glowed bright', 'The little turtle walked slowly to the big lake', 'A kind dragon helped the children cross the river', 'The moon asked the sun to share some of its light', 'She baked a cake and the whole village smelled it', 'The tiny elf repaired shoes while everyone slept', 'A blue whale swam under the boat and smiled up', 'The old tower had a secret room at the very top', 'He taught the young rabbits how to find their way', 'The enchanted forest glowed softly in the moonlight', 'A small girl found a door in the base of the tree', 'The little boy gave his toy to the crying child', 'A wise turtle taught the fish to swim upstream', 'She drew stars on the ceiling of her small room', 'The sleeping giant woke when the bird sang softly', 'He wrote a letter to the cloud asking for rain', 'A red squirrel hid acorns under the old oak tree', 'The little lamp glowed all night in the dark cave', 'She made wings from feathers and tried to fly high', 'The pond froze over and the ducks slid across it', 'A boy built a boat from sticks and sailed away', 'The old woman kept a flame alive for a hundred years', 'He found a seed that grew into a door in the earth', 'The children danced in the rain until their shoes were wet', 'A dragon learned to breathe flowers instead of fire', 'The little cloud wanted to touch the top of the mountain', 'She gave the bird her last piece of bread and smiled', 'He fell asleep under a tree and dreamed of the sea', 'The fox and the crow became friends by the river', 'A tiny door in the wall led to a secret library', 'The night sky opened and showed the children their names']
TEST_PROMPTS = ['The little fox found a shiny stone by the river', 'Once a kind farmer helped a lost baby deer', 'She climbed the tall tree and saw the whole village', 'A brave boy sailed across the dark stormy sea', 'The old wizard gave the child a glowing lantern', 'A rabbit and a turtle became the best of friends', 'The queen looked out her window at the falling snow', 'He woke up early and saw the first light of dawn', 'A small seed grew into the tallest tree in the land', 'The sleepy bear found a cave and curled up inside']
SEQ_LEN = 10
N_STEPS = 100
wte = model_ref.transformer.wte.weight.detach().numpy()
wpe = model_ref.transformer.wpe.weight.detach().numpy()
print(f'\n  {len(TRAIN_PROMPTS)} prompts × {N_STEPS} steps = {len(TRAIN_PROMPTS) * N_STEPS} sequences')
print(f'  Need N >> {10 * (D + D * (D + 1) // 2)} = 21440 for FFN')
t0 = time.time()
data = {li: {'ln2': [], 'delta_ffn': [], 'context': [], 'delta_att': []} for li in range(n_layers)}
with torch.no_grad():
    for prompt in TRAIN_PROMPTS:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model_ref(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        for step in range(N_STEPS):
            ids_use = ids[-SEQ_LEN:]
            T = SEQ_LEN
            x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
            for li in range(n_layers):
                blk = model_ref.transformer.h[li]
                ln1w = blk.ln_1.weight.detach().numpy()
                ln1b = blk.ln_1.bias.detach().numpy()
                ln2w = blk.ln_2.weight.detach().numpy()
                ln2b = blk.ln_2.bias.detach().numpy()
                att = blk.attn.attention
                Wq = att.q_proj.weight.detach().numpy()
                Wk = att.k_proj.weight.detach().numpy()
                Wv = att.v_proj.weight.detach().numpy()
                Wo = att.out_proj.weight.detach().numpy()
                bo = att.out_proj.bias.detach().numpy()
                W1 = blk.mlp.c_fc.weight.detach().numpy()
                b1 = blk.mlp.c_fc.bias.detach().numpy()
                W2 = blk.mlp.c_proj.weight.detach().numpy()
                b2 = blk.mlp.c_proj.bias.detach().numpy()
                ln1 = np.array([ln_np(x[i:i + 1], ln1w, ln1b)[0] for i in range(T)])
                Q = ln1 @ Wq.T
                K = ln1 @ Wk.T
                V = ln1 @ Wv.T
                Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                mask = np.triu(np.full((T, T), float('-inf')), 1)
                probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
                heads = [probs[h] @ Vh[h] for h in range(n_heads)]
                context = np.stack(heads, 1).reshape(T, D)
                att_out = context @ Wo.T + bo
                x_att = x + att_out
                x_new = x_att.copy()
                for t in range(T):
                    ln2t = ln_np(x_att[t:t + 1], ln2w, ln2b)[0]
                    x_new[t] = x_att[t] + gelu_np(ln2t @ W1.T + b1) @ W2.T + b2
                ln2_last = ln_np(x_att[-1:], ln2w, ln2b)[0]
                data[li]['ln2'].append(ln2_last.copy())
                data[li]['delta_ffn'].append((x_new[-1] - x_att[-1]).copy())
                data[li]['context'].append(context[-1].copy())
                data[li]['delta_att'].append(att_out[-1].copy())
                x = x_new
            out2 = model_ref(torch.tensor([ids_use]))
            ids.append(torch.argmax(out2.logits[0, -1, :]).item())
N = len(data[0]['ln2'])
for li in range(n_layers):
    for k in data[li]:
        data[li][k] = np.array(data[li][k], dtype=np.float64)
print(f'  N={N} in {time.time() - t0:.0f}s')
print(f"\n{'=' * 70}")
print(f'  W-KERNEL SOLVE — RIDGE REGRESSION')
print(f'  Testing λ = 0 (lstsq), 1e-6, 1e-4, 1e-2')
print(f"{'=' * 70}\n")
li_test = 0
ln2_all = data[li_test]['ln2']
delta_ffn_all = data[li_test]['delta_ffn']
Phi_all = quad_kernel(ln2_all)
N_tr = int(0.8 * N)
Phi_tr, Phi_val = (Phi_all[:N_tr], Phi_all[N_tr:])
Y_tr, Y_val = (delta_ffn_all[:N_tr], delta_ffn_all[N_tr:])
print(f'  Layer 0 FFN cross-validation (N_train={N_tr}, N_val={N - N_tr})')
print(f"  {'λ':<12} {'Train R²':>10} {'Val R²':>10}  verdict")
print(f"  {'─' * 44}")
best_lam = 0.0001
best_val_r2 = -np.inf
for lam in [0.0, 1e-08, 1e-06, 0.0001, 0.01, 0.1, 1.0]:
    if lam == 0.0:
        Pb = np.hstack([Phi_tr, np.ones((N_tr, 1))])
        W, _, _, _ = np.linalg.lstsq(Pb, Y_tr, rcond=None)
    else:
        Pb = np.hstack([Phi_tr, np.ones((N_tr, 1))])
        A = Pb.T @ Pb + lam * np.eye(Pb.shape[1])
        W = np.linalg.solve(A, Pb.T @ Y_tr)
    Pb_tr = np.hstack([Phi_tr, np.ones((N_tr, 1))])
    Pb_val = np.hstack([Phi_val, np.ones((N - N_tr, 1))])
    Yp_tr = Pb_tr @ W
    Yp_val = Pb_val @ W

    def r2s(p, t):
        ss_r = np.sum((t - p) ** 2)
        ss_t = np.sum((t - t.mean(0)) ** 2)
        return float(1 - ss_r / ss_t) if ss_t > 1e-15 else 1.0
    r2_tr = r2s(Yp_tr, Y_tr)
    r2_val = r2s(Yp_val, Y_val)
    v = '← best' if r2_val > best_val_r2 else ''
    if r2_val > best_val_r2:
        best_val_r2 = r2_val
        best_lam = lam
        best_W_test = W.copy()
    print(f'  {lam:<12} {r2_tr:>10.6f} {r2_val:>10.6f}  {v}')
print(f'\n  Best λ = {best_lam}')
print(f'\n  Solving all layers with λ={best_lam}...')
print(f"  {'Layer':<8} {'FFN_R²':>12} {'ATT_R²':>12}")
print(f"  {'─' * 36}")
solved = {}
for li in range(n_layers):
    Phi_ffn = quad_kernel(data[li]['ln2'])
    W_ffn, r2_ffn = solve_ridge(Phi_ffn, data[li]['delta_ffn'], lam=best_lam)
    W_att, r2_att = solve_ridge(data[li]['context'], data[li]['delta_att'], lam=1e-08)
    solved[li] = {'W_ffn': W_ffn, 'W_att': W_att}
    vf = '✓' if r2_ffn > 0.9999 else '~'
    va = '✓' if r2_att > 0.9999 else '~'
    print(f'  L{li:<7} {r2_ffn:.6f} {vf}  {r2_att:.6f} {va}')

def wk_forward(ids_use, wk_ffn=True, wk_att=True):
    T = len(ids_use)
    x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
    for li in range(n_layers):
        blk = model_ref.transformer.h[li]
        ln1w = blk.ln_1.weight.detach().numpy()
        ln1b = blk.ln_1.bias.detach().numpy()
        ln2w = blk.ln_2.weight.detach().numpy()
        ln2b = blk.ln_2.bias.detach().numpy()
        att = blk.attn.attention
        Wq = att.q_proj.weight.detach().numpy()
        Wk = att.k_proj.weight.detach().numpy()
        Wv = att.v_proj.weight.detach().numpy()
        Wo = att.out_proj.weight.detach().numpy()
        bo = att.out_proj.bias.detach().numpy()
        W1 = blk.mlp.c_fc.weight.detach().numpy()
        b1 = blk.mlp.c_fc.bias.detach().numpy()
        W2 = blk.mlp.c_proj.weight.detach().numpy()
        b2 = blk.mlp.c_proj.bias.detach().numpy()
        W_ffn = solved[li]['W_ffn']
        W_att = solved[li]['W_att']
        ln1 = np.array([ln_np(x[i:i + 1], ln1w, ln1b)[0] for i in range(T)])
        Q = ln1 @ Wq.T
        K = ln1 @ Wk.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads, 1).reshape(T, D)
        att_out = context @ Wo.T + bo
        x_att = x + att_out
        if wk_att:
            ctx_b = np.append(context[-1], 1.0)
            x_att[-1] = x[-1] + ctx_b @ W_att
        x_new = x_att.copy()
        for t in range(T):
            ln2t = ln_np(x_att[t:t + 1], ln2w, ln2b)[0]
            if t == T - 1 and wk_ffn:
                Pb = np.append(quad_kernel(ln2t.reshape(1, -1))[0], 1.0)
                x_new[t] = x_att[t] + Pb @ W_ffn
            else:
                x_new[t] = x_att[t] + gelu_np(ln2t @ W1.T + b1) @ W2.T + b2
        x = x_new
    lnfw = model_ref.transformer.ln_f.weight.detach().numpy()
    lnfb = model_ref.transformer.ln_f.bias.detach().numpy()
    lmw = model_ref.lm_head.weight.detach().numpy()
    return ln_np(x[-1:], lnfw, lnfb)[0] @ lmw.T
print(f"\n{'=' * 70}")
print(f'  EVALUATION')
print(f"{'=' * 70}\n")

def calc_ppl(prompts, label, mode='ref'):
    nll = 0.0
    tok = 0
    cor = 0
    with torch.no_grad():
        for prompt in prompts:
            ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
            if len(ids) < 3:
                continue
            for i in range(1, min(len(ids), SEQ_LEN)):
                ctx = ids[:i]
                true_next = ids[i]
                if mode == 'ref':
                    out = model_ref(torch.tensor([ctx]))
                    logits = out.logits[0, -1, :].numpy().astype(np.float64)
                elif mode == 'wk_ffn':
                    logits = wk_forward(ctx, True, False)
                elif mode == 'wk_att':
                    logits = wk_forward(ctx, False, True)
                elif mode == 'wk_both':
                    logits = wk_forward(ctx, True, True)
                lg = logits - logits.max()
                lp = lg - np.log(np.sum(np.exp(lg)))
                nll += -lp[true_next]
                tok += 1
                if int(np.argmax(logits)) == true_next:
                    cor += 1
    ppl = math.exp(nll / tok) if tok > 0 else float('inf')
    acc = cor / tok * 100 if tok > 0 else 0
    print(f'  {label:<35} ppl={ppl:>8.2f}  acc={acc:>5.1f}%')
    return (ppl, acc)
ppl_r, acc_r = calc_ppl(TEST_PROMPTS, 'Reference', 'ref')
ppl_f, acc_f = calc_ppl(TEST_PROMPTS, 'W-Kernel FFN only', 'wk_ffn')
ppl_a, acc_a = calc_ppl(TEST_PROMPTS, 'W-Kernel ATT only', 'wk_att')
ppl_b, acc_b = calc_ppl(TEST_PROMPTS, 'W-Kernel FFN+ATT', 'wk_both')
print(f'\n  FFN ratio:  {ppl_f / ppl_r:.6f}   (target: 1.000)')
print(f'  ATT ratio:  {ppl_a / ppl_r:.6f}   (target: 1.000)')
print(f'  Both ratio: {ppl_b / ppl_r:.6f}   (target: 1.000)')
print(f"\n{'=' * 70}")
print(f'  GENERATION COMPARISON')
print(f"{'=' * 70}\n")
for prompt in ['Once upon a time a little', 'Deep in the forest lived', 'The brave knight found a']:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    ir = ids[:]
    iw = ids[:]
    rt = []
    wt = []
    for _ in range(10):
        with torch.no_grad():
            nr = torch.argmax(model_ref(torch.tensor([ir])).logits[0, -1, :]).item()
        ir.append(nr)
        rt.append(nr)
        nw = int(np.argmax(wk_forward(iw, True, True)))
        iw.append(nw)
        wt.append(nw)
    print(f"  '{prompt}'")
    print(f'    REF: {tokenizer.decode(rt)}')
    print(f'    WK:  {tokenizer.decode(wt)}')
    print(f'    match: {sum((a == b for a, b in zip(rt, wt)))}/10\n')
print(f"{'=' * 70}")
print(f'  SUMMARY: N={N}, λ={best_lam}')
print(f'  ATT proven: ratio=1.000 (context→att_out = linear exact)')
print(f'  FFN target: ratio→1.000 with ridge + sufficient N')
print(f'  More data needed: N >> {10 * (D + D * (D + 1) // 2)} = 21440')
print(f"  Current N={N} vs needed 21440: {('sufficient' if N > 21440 else 'need more')}")
print(f"{'=' * 70}\n")
