import numpy as np
import time
import sys
import platform
from scipy.linalg import expm, logm
print('\n' + '=' * 62)
print('  W PRINCIPLE — CORRECT IMPLEMENTATION')
print('  ONE T. Superposition of states. ONE collapse.')
print('=' * 62)
print(f'\n  Machine : {platform.node()}')
print(f'  System  : {platform.system()} {platform.machine()}')
print(f'  Python  : {sys.version.split()[0]}')
print(f'  NumPy   : {np.__version__}')
print('\n' + '=' * 62)
print('  PART 0 — THE FUNDAMENTAL DIFFERENCE')
print('=' * 62)
D = 8
np.random.seed(42)
T = np.random.randn(D, D) * 0.3
x = np.random.randn(D)
N = 4
h_wrong = x.copy()
for _ in range(N):
    h_wrong = np.tanh(h_wrong @ T.T)
TN = np.linalg.matrix_power(T, N)
h_correct = np.tanh(x @ TN.T)
print(f'\n  Wrong W  (sequential collapses):')
print(f'  h = tanh(T @ tanh(T @ tanh(T @ tanh(T @ x))))')
print(f'  Result: {h_wrong[:4].round(4)}')
print(f'\n  Correct W (superposition + ONE collapse):')
print(f'  h = tanh(T^N @ x)')
print(f'  Result: {h_correct[:4].round(4)}')
print(f'\n  Different results. Different principles.')
print(f'  Wrong W:   4 measurements. Sequential.')
print(f'  Correct W: 1 measurement. From superposition.')
print(f'  This is the W principle.')
np.random.seed(42)
D = 32
N_DATA = 200
N = 4
T_true = np.random.randn(D, D) * 0.3
TN_true = np.linalg.matrix_power(T_true, N)
X_raw = np.random.randn(N_DATA, D)
X = X_raw / (np.linalg.norm(X_raw, axis=1, keepdims=True) + 1e-08)
Y = np.tanh(X @ TN_true.T)
Y_pre = X @ TN_true.T
print(f'\n  Data: {N_DATA} samples, D={D}, depth N={N}')
print(f'  Task: learn T such that tanh(T^{N} @ x) = y')
print(f'  ONE collapse. Not {N} collapses.')
print('\n' + '=' * 62)
print('  METHOD 1 — WRONG W (sequential collapses)')
print('  Gradient descent on chained tanh.')
print('  This is what we built before. Shown for comparison.')
print('=' * 62)

def forward_wrong(T, X, n):
    h = X.copy()
    for _ in range(n):
        h = np.tanh(h @ T.T)
    return h

def loss_wrong(T, X, Y, n):
    pred = forward_wrong(T, X, n)
    return np.mean((pred - Y) ** 2)

def gd_wrong(X, Y, n, epochs=200, lr=0.005):
    np.random.seed(42)
    T = np.random.randn(D, D) * 0.1
    losses = []
    for ep in range(epochs):
        grad = np.zeros_like(T)
        batch_size = min(32, len(X))
        idx = np.random.choice(len(X), batch_size, replace=False)
        Xb, Yb = (X[idx], Y[idx])
        for i in range(len(Xb)):
            h = Xb[i].copy()
            states = [h]
            for _ in range(n):
                h = np.tanh(h @ T.T)
                states.append(h)
            delta = 2 * (h - Yb[i]) / D
            for d in range(n - 1, -1, -1):
                dtanh = 1 - states[d + 1] ** 2
                delta = delta * dtanh
                grad += np.outer(delta, states[d])
                delta = delta @ T
        grad /= len(Xb)
        T -= lr * grad
        if ep % 40 == 0 or ep == epochs - 1:
            losses.append((ep, loss_wrong(T, X, Y, n)))
    return (T, losses)
t0 = time.perf_counter()
T_wrong, losses_wrong = gd_wrong(X, Y, N, epochs=200)
wrong_time = (time.perf_counter() - t0) * 1000
wrong_loss = loss_wrong(T_wrong, X, Y, N)
print(f'\n  Epoch  Loss')
print(f"  {'-' * 25}")
for ep, loss in losses_wrong:
    print(f'  {ep:5d}  {loss:.6f}')
print(f'\n  Final loss : {wrong_loss:.6f}')
print(f'  Time       : {wrong_time:.2f} ms')
print(f'  Updates    : {200 * 200}')
print('\n' + '=' * 62)
print('  METHOD 2 — CORRECT W + GRADIENT DESCENT')
print('  h = tanh(T^N @ x). ONE collapse.')
print('  Still iterative. But correct W architecture.')
print('=' * 62)

def forward_correct(T, X, n):
    TN = np.linalg.matrix_power(T, n)
    return np.tanh(X @ TN.T)

def loss_correct(T, X, Y, n):
    pred = forward_correct(T, X, n)
    return np.mean((pred - Y) ** 2)

def gd_correct(X, Y, n, epochs=200, lr=0.001):
    np.random.seed(42)
    T = np.random.randn(D, D) * 0.1
    losses = []
    eps = 0.0001
    for ep in range(epochs):
        grad = np.zeros_like(T)
        base_loss = loss_correct(T, X, Y, n)
        for i in range(D):
            for j in range(0, D, 4):
                T[i, j] += eps
                loss_p = loss_correct(T, X, Y, n)
                T[i, j] -= eps
                grad[i, j] = (loss_p - base_loss) / eps
        T -= lr * grad
        if ep % 40 == 0 or ep == epochs - 1:
            losses.append((ep, loss_correct(T, X, Y, n)))
    return (T, losses)
t0 = time.perf_counter()
T_cgd, losses_cgd = gd_correct(X, Y, N, epochs=200)
cgd_time = (time.perf_counter() - t0) * 1000
cgd_loss = loss_correct(T_cgd, X, Y, N)
print(f'\n  Epoch  Loss')
print(f"  {'-' * 25}")
for ep, loss in losses_cgd:
    print(f'  {ep:5d}  {loss:.6f}')
print(f'\n  Final loss : {cgd_loss:.6f}')
print(f'  Time       : {cgd_time:.2f} ms')
print('\n' + '=' * 62)
print('  METHOD 3 — CORRECT W DIRECT SOLUTION')
print('  h = tanh(T^N @ x)')
print('  Solve: T^N = X+ @ arctanh(Y)')
print('  T = (T^N)^(1/N)')
print('  ZERO epochs. ONE operation.')
print('=' * 62)

def safe_arctanh(y):
    return np.arctanh(np.clip(y, -0.9999, 0.9999))
t0 = time.perf_counter()
Y_pre_recovered = safe_arctanh(Y)
TN_solved = np.linalg.lstsq(X, Y_pre_recovered, rcond=None)[0]
eigenvalues, V = np.linalg.eig(TN_solved)
roots = eigenvalues.astype(complex) ** (1.0 / N)
T_direct = np.real(V @ np.diag(roots) @ np.linalg.inv(V))
direct_time = (time.perf_counter() - t0) * 1000
direct_loss = loss_correct(T_direct, X, Y, N)
TN_recovered = np.linalg.matrix_power(T_direct, N)
recovery_error = np.mean((TN_recovered - TN_solved) ** 2)
print(f'\n  Step 1: recover Y_pre = arctanh(Y)')
print(f'  Step 2: solve T^N = X+ @ Y_pre  (one lstsq)')
print(f'  Step 3: T = (T^N)^(1/{N})  (eigendecomposition)')
print(f'\n  T^N recovery error : {recovery_error:.8f}')
print(f'  Final loss         : {direct_loss:.6f}')
print(f'  Time               : {direct_time:.4f} ms')
print(f'  Epochs             : 0')
print(f'  Updates            : 1  (ONE operation)')
print('\n' + '=' * 62)
print('  FINAL COMPARISON')
print('=' * 62)
print(f"\n  {'Method':<32} {'Loss':>10} {'Time(ms)':>12} {'Updates':>10}")
print(f"  {'-' * 66}")
print(f"  {'Wrong W (sequential collapses)':<32} {wrong_loss:>10.6f} {wrong_time:>12.2f} {200 * 200:>10,}")
print(f"  {'Correct W + GD':<32} {cgd_loss:>10.6f} {cgd_time:>12.2f} {200 * 200:>10,}")
print(f"  {'Correct W direct (W collapse)':<32} {direct_loss:>10.6f} {direct_time:>12.4f} {'1':>10}")
print(f'\n  KEY FINDINGS:\n  ────────────────────────────────────────────────────────\n  Wrong W loss    : {wrong_loss:.6f}  (sequential — wrong architecture)\n  Correct W loss  : {direct_loss:.6f}  (superposition — correct W)\n  Loss difference : {abs(direct_loss - cgd_loss):.6f}\n\n  Direct solution time : {direct_time:.4f} ms\n  GD time              : {wrong_time:.2f} ms\n  Speedup              : {wrong_time / direct_time:.0f}x\n\n  The correct W architecture:\n  h = tanh(T^N @ x)   ONE collapse\n  Not chained tanh.   Not sequential.\n\n  Direct solution works because:\n  T^N is linear before collapse.\n  arctanh recovers pre-activation.\n  Nth root finds T directly.\n  ZERO epochs needed.\n  ────────────────────────────────────────────────────────\n')
print('=' * 62)
print('  SCALE TEST — W direct vs GD as data grows')
print('=' * 62)
print(f"\n  {'N data':>10} {'GD time(ms)':>14} {'W time(ms)':>12} {'Speedup':>10} {'Loss diff':>12}")
print(f"  {'-' * 62}")
for n in [50, 100, 200, 500, 1000, 2000]:
    np.random.seed(42)
    Xn = np.random.randn(n, D)
    Xn = Xn / (np.linalg.norm(Xn, axis=1, keepdims=True) + 1e-08)
    Yn = np.tanh(Xn @ TN_true.T)
    t0 = time.perf_counter()
    Tg, _ = gd_wrong(Xn, Yn, N, epochs=100, lr=0.005)
    gd_t = (time.perf_counter() - t0) * 1000
    gd_l = loss_wrong(Tg, Xn, Yn, N)
    t0 = time.perf_counter()
    Yp = safe_arctanh(Yn)
    TNs = np.linalg.lstsq(Xn, Yp, rcond=None)[0]
    ev, V = np.linalg.eig(TNs)
    rt = ev.astype(complex) ** (1.0 / N)
    Td = np.real(V @ np.diag(rt) @ np.linalg.inv(V))
    w_t = (time.perf_counter() - t0) * 1000
    w_l = loss_correct(Td, Xn, Yn, N)
    print(f'  {n:>10} {gd_t:>14.2f} {w_t:>12.4f} {gd_t / w_t:>10.0f}x {abs(w_l - gd_l):>12.6f}')
print(f'\n  GD time grows with data.\n  W direct time stays near constant.\n  W sees ALL data simultaneously as ONE operation.\n\n  This is W collapse in correct form.\n  Not wrong sequential architecture.\n  Correct superposition then ONE collapse.\n')
print('=' * 62 + '\n')
