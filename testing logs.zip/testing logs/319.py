import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import time
import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — SEMANTIC RAM GENERATION TEST')
print('  Pitting Standard Math against Physical Memory Buckets.')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
print('\n  [ Phase 1 ] Populating Semantic RAM Memory Bank...')
store_bits = []
store_tokens = []

def hook_l7_pre(m, i, o):
    bits = (o[:, -1, :].detach().cpu().numpy() > 0).astype(int)
    store_bits.append(bits[0])
h = model.transformer.h[7].mlp.c_fc.register_forward_hook(hook_l7_pre)
seed_prompts = ['The brave knight took his sword and', 'Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon', 'A small dog ran across the green field', 'The king sat on his golden throne and']
with torch.no_grad():
    for s in seed_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        for _ in range(20):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            store_tokens.append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
h.remove()
RAM_bits = np.array(store_bits)
RAM_tokens = np.array(store_tokens)
print(f'  ✓ Semantic RAM Bank loaded with {len(RAM_bits)} unique physical memory states.')
W_layers = {}
with torch.no_grad():
    for l in range(n_layers):
        block = model.transformer.h[l]
        W_layers[l] = {'q': block.attn.attention.q_proj.weight.detach().numpy().T, 'k': block.attn.attention.k_proj.weight.detach().numpy().T, 'v': block.attn.attention.v_proj.weight.detach().numpy().T, 'o': block.attn.attention.out_proj.weight.detach().numpy().T, 'b_o': block.attn.attention.out_proj.bias.detach().numpy(), '1': block.mlp.c_fc.weight.detach().numpy().T, 'b_1': block.mlp.c_fc.bias.detach().numpy(), '2': block.mlp.c_proj.weight.detach().numpy().T, 'b_2': block.mlp.c_proj.bias.detach().numpy(), 'ln1_w': block.ln_1.weight.detach().numpy(), 'ln1_b': block.ln_1.bias.detach().numpy(), 'ln2_w': block.ln_2.weight.detach().numpy(), 'ln2_b': block.ln_2.bias.detach().numpy()}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
test_prompt = 'The brave knight took his sword and'
print('\n' + '─' * 66)
print(f'  [ Phase 2 ] STANDARD PYTORCH BASELINE')
print('  Calculates billions of floats via lm_head dot products.')
print('─' * 66)
pt_ids = tokenizer.encode(test_prompt, return_tensors='pt')
print(f'  Prompt: {test_prompt}')
print('  Output: ', end='')
with torch.no_grad():
    for _ in range(20):
        out = model(pt_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        word = tokenizer.decode([next_id])
        print(word, end='', flush=True)
        pt_ids = torch.cat([pt_ids, torch.tensor([[next_id]])], dim=1)
print('\n')

def gelu_np(x):
    x = x.astype(np.float32)
    return 0.5 * x * (1.0 + np.tanh(np.float32(math.sqrt(2.0 / math.pi)) * (x + np.float32(0.044715) * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def layernorm_np(x, gamma, beta, eps=1e-05):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (x - mean) / np.sqrt(var + np.float32(eps)) * gamma + beta
print('─' * 66)
print(f'  [ Phase 3 ] NON-ILLUSION SEMANTIC RAM ENGINE')
print('  Amputates lm_head entirely. Navigates via 256-bit bucket matching.')
print('─' * 66)
np_ids = tokenizer.encode(test_prompt)
print(f'  Prompt: {test_prompt}')
print('  Output: ', end='')
overlap_logs = []
for step in range(20):
    seq_len = len(np_ids)
    x = wte[np_ids] + wpe[np.arange(seq_len)]
    x = x.astype(np.float32)
    for l in range(n_layers):
        W = W_layers[l]
        ln1 = layernorm_np(x, W['ln1_w'], W['ln1_b'])
        q = ln1 @ W['q']
        k = ln1 @ W['k']
        v = ln1 @ W['v']
        q_heads = q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        k_heads = k.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        v_heads = v.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        att_h_list = []
        for h_id in range(n_heads):
            scr = q_heads[h_id] @ k_heads[h_id].T
            msk = np.triu(np.full((seq_len, seq_len), -1000000000.0, dtype=np.float32), 1)
            att_w = softmax_np(scr + msk)
            att_h_list.append(att_w @ v_heads[h_id])
        concat_h = np.array(att_h_list).transpose(1, 0, 2).reshape(seq_len, D)
        att_out = concat_h @ W['o'] + W['b_o']
        x = x + att_out
        ln2 = layernorm_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['1'] + W['b_1']
        if l < n_layers - 1:
            gelu = gelu_np(pre)
            ffn_out = gelu @ W['2'] + W['b_2']
            x = x + ffn_out
        else:
            current_bits = (pre[-1] > 0).astype(int)
            matches = np.sum(RAM_bits == current_bits, axis=1)
            best_idx = np.argmax(matches)
            next_id = int(RAM_tokens[best_idx])
            overlap_pct = matches[best_idx] / 256.0 * 100
            np_ids.append(next_id)
            word = tokenizer.decode([next_id])
            print(word, end='', flush=True)
            overlap_logs.append(f'[{word.strip()}] retrieved via {overlap_pct:.1f}% RAM match')
            break
print('\n\n  Semantic RAM Routing Log:')
for log in overlap_logs[:5]:
    print(f'    {log}')
print('    ...')
print('\n' + '=' * 66)
print('  THE FINAL VERDICT:')
print('  Did the Non-Illusion Engine generate the exact same English')
print('  sentence without ever using the final Neural Network math?')
print('=' * 66 + '\n')
