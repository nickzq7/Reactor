import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL FROM SCRATCH v5 — RESIDUAL BOOSTING')
print('  Each layer learns what previous layer missed.')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\nand flowers and all the small creatures that lived among the leaves\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthem with lights and warm bread and kind words the knight stayed\nthe night and left in the morning before anyone else was awake\nleaving only his footprints in the soft mud as a sign that he had\nbeen there and done what he came to do the old miller named otto\nhad run his windmill for forty years every morning he climbed the\nwooden stairs to check the stones and oil the gears and watch the\nsails turn in the wind the flour from his mill was the finest in\nthe region and bakers came from many villages to buy it one summer\nthe wind died and for three weeks the sails stood still otto swept\nthe floors and mended the fences and waited on the twenty second\nday a small cool wind brushed his cheek and by noon the mill was\nrunning at full speed otto laughed out loud which was something he\nalmost never did and he ground twice as much flour that week to\nmake up for the time that had been lost the little rabbit who\nlived at the edge of the meadow had three sisters and one brother\nevery evening they sat together at the entrance to their burrow\nand watched the sun go down over the hills the youngest rabbit\nalways asked the same question why does the sun go down and the\noldest rabbit always gave the same answer so that the stars can\ncome out and find their way home this made the youngest rabbit\nvery happy and she went to sleep thinking about all the stars\nmaking their long journey across the dark sky every single night\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but he was also\nvery curious which sometimes got him into trouble one spring morning\nriku went exploring while his mother was sleeping he found a path\nhe had never followed before and followed it until he reached a farm\nwith a red barn and a vegetable garden behind a low fence the garden\nwas full of green things and the smell of fresh earth riku squeezed\nunder the fence and walked between the rows of vegetables sniffing\neverything he did not mean to do any harm he was just curious\n'.strip()
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VS = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Vocab={VS}  Tokens={len(tokens)}')
D = 48
FFN_D = 96
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 3
SEQ_LEN = 24
LAM = 0.005
CLIP = 2.5
MOM = 0.3
print(f'  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}  SEQ_LEN={SEQ_LEN}')
rng = np.random.RandomState(0)
WTE = rng.randn(VS, D).astype(np.float64)
for i in range(VS):
    n = np.linalg.norm(WTE[i])
    if n > 1e-08:
        WTE[i] /= n
WTE *= 0.5
WPE = rng.randn(SEQ_LEN + 2, D).astype(np.float64) * 0.04

def lnorm(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def ridge(X, Y, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    try:
        W = np.linalg.solve(A, Xb.T @ Y)
    except:
        W, _, _, _ = np.linalg.lstsq(Xb, Y, rcond=None)
    return np.clip(W, -CLIP, CLIP)

def init():
    w = {}
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1g{s}'] = np.ones(D)
        w[f'ln1b{s}'] = np.zeros(D)
        w[f'ln2g{s}'] = np.ones(D)
        w[f'ln2b{s}'] = np.zeros(D)
        w[f'Wq{s}'] = rng.randn(D, D) * 0.01
        w[f'Wk{s}'] = rng.randn(D, D) * 0.01
        w[f'Wv{s}'] = rng.randn(D, D) * 0.01
        w[f'Wo{s}'] = np.zeros((D, D))
        w[f'bo{s}'] = np.zeros(D)
        w[f'W1{s}'] = rng.randn(FFN_D, D) * 0.01
        w[f'b1{s}'] = np.zeros(FFN_D)
        w[f'W2{s}'] = np.zeros((D, FFN_D))
        w[f'b2{s}'] = np.zeros(D)
    w['lfg'] = np.ones(D)
    w['lfb'] = np.zeros(D)
    return w

def layer_fwd(x, li, w):
    T = len(x)
    s = str(li)
    h = np.array([lnorm(x[i], w[f'ln1g{s}'], w[f'ln1b{s}']) for i in range(T)])
    Q = h @ w[f'Wq{s}'].T
    K = h @ w[f'Wk{s}'].T
    V = h @ w[f'Wv{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    p = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    ctx = np.stack([p[h_] @ Vh[h_] for h_ in range(N_HEADS)], 1).reshape(T, D)
    xa = x + ctx @ w[f'Wo{s}'].T + w[f'bo{s}']
    xn = xa.copy()
    for t in range(T):
        h2 = lnorm(xa[t], w[f'ln2g{s}'], w[f'ln2b{s}'])
        xn[t] = xa[t] + gelu(h2 @ w[f'W1{s}'].T + w[f'b1{s}']) @ w[f'W2{s}'].T + w[f'b2{s}']
    return (xn, ctx, xa)

def full_fwd(ids, w):
    T = len(ids)
    x = (WTE[ids] + WPE[:T]).copy()
    for li in range(N_LAYERS):
        x, _, _ = layer_fwd(x, li, w)
    xf = np.array([lnorm(x[t], w['lfg'], w['lfb']) for t in range(T)])
    return xf @ WTE.T

def calc_ppl(w, n=400):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        try:
            logits = full_fwd(ids, w)
            if not np.all(np.isfinite(logits[-1])):
                continue
            lg = logits[-1] - logits[-1].max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return 999.0
    return math.exp(min(nll / tok, 500))

def solve_layer_residual(li, w, idxs):
    s = str(li)
    X_ctx = []
    X_xa = []
    X_ln2 = []
    X_gelu = []
    Y_resid = []
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
        for ll in range(li):
            x, _, _ = layer_fwd(x, ll, w)
        x_prev_last = x[-1].copy()
        if not np.all(np.isfinite(x_prev_last)):
            continue
        residual = WTE[nxt] - x_prev_last
        _, ctx, xa = layer_fwd(x, li, w)
        ctx_l = ctx[-1]
        xa_l = xa[-1]
        if not np.all(np.isfinite(ctx_l)):
            continue
        if not np.all(np.isfinite(xa_l)):
            continue
        h2 = lnorm(xa_l, w[f'ln2g{s}'], w[f'ln2b{s}'])
        pre = h2 @ w[f'W1{s}'].T + w[f'b1{s}']
        gl = gelu(pre)
        if not np.all(np.isfinite(gl)):
            continue
        X_ctx.append(ctx_l)
        X_xa.append(xa_l)
        X_ln2.append(h2)
        X_gelu.append(gl)
        Y_resid.append(residual)
    if len(Y_resid) < 20:
        return w
    Xc = np.array(X_ctx)
    Xa = np.array(X_xa)
    Xl = np.array(X_ln2)
    Xg = np.array(X_gelu)
    Yr = np.array(Y_resid)
    Y_att = Yr * 0.5
    Wo_new = ridge(Xc, Y_att)
    w[f'Wo{s}'] = (1 - MOM) * Wo_new[:-1].T + MOM * w[f'Wo{s}']
    w[f'bo{s}'] = (1 - MOM) * Wo_new[-1] + MOM * w[f'bo{s}']
    w[f'Wo{s}'] = np.clip(w[f'Wo{s}'], -CLIP, CLIP)
    w[f'bo{s}'] = np.clip(w[f'bo{s}'], -CLIP, CLIP)
    Y_ffn = Yr * 0.5
    W2_new = ridge(Xg, Y_ffn)
    w[f'W2{s}'] = (1 - MOM) * W2_new[:-1].T + MOM * w[f'W2{s}']
    w[f'b2{s}'] = (1 - MOM) * W2_new[-1] + MOM * w[f'b2{s}']
    w[f'W2{s}'] = np.clip(w[f'W2{s}'], -CLIP, CLIP)
    w[f'b2{s}'] = np.clip(w[f'b2{s}'], -CLIP, CLIP)
    Y_pre = Y_ffn @ w[f'W2{s}']
    W1_new = ridge(Xl, Y_pre)
    w[f'W1{s}'] = (1 - MOM) * W1_new[:-1].T + MOM * w[f'W1{s}']
    w[f'b1{s}'] = (1 - MOM) * W1_new[-1] + MOM * w[f'b1{s}']
    w[f'W1{s}'] = np.clip(w[f'W1{s}'], -CLIP, CLIP)
    w[f'b1{s}'] = np.clip(w[f'b1{s}'], -CLIP, CLIP)
    return w
w = init()
p0 = calc_ppl(w)
print(f'\n  Random ppl = {p0:.2f}  (vocab={VS})\n')
phases = []
for li in range(N_LAYERS):
    phases.append((li, 15, f'Layer {li} (residual target)'))
for li in range(N_LAYERS):
    phases.append((li, 8, f'Layer {li} fine-tune'))
for li in range(N_LAYERS):
    phases.append((li, 5, f'Layer {li} polish'))
BATCH = 350
best_ppl = p0
best_w = {k: v.copy() for k, v in w.items()}
hist = [p0]
t0 = time.time()
print(f"  {'Phase':<30} {'Rnd':<4} {'PPL':>8} {'Best':>8}")
print(f"  {'─' * 55}")
for active_li, n_rounds, label in phases:
    for rnd in range(n_rounds):
        idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
        w = solve_layer_residual(active_li, w, idxs)
        p = calc_ppl(w)
        hist.append(p)
        mark = ''
        if p < best_ppl:
            best_ppl = p
            best_w = {k: v.copy() for k, v in w.items()}
            mark = ' ★'
        arr = '↓' if p < hist[-2] else '↑'
        lbl = label if rnd == 0 else ''
        print(f'  {lbl:<30} {rnd + 1:<4} {p:>8.2f} {best_ppl:>8.2f}  {arr}{mark}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  FINAL RESULTS — RESIDUAL BOOSTING')
print(f"{'=' * 70}\n")
ppl_f = calc_ppl(w, n=600)
print(f'  Start  : {p0:.2f}')
print(f'  Best   : {best_ppl:.2f}')
print(f'  Vocab  : {VS}')
print(f'  Ratio  : {best_ppl / VS:.4f}  (< 1.0 = learned; < 0.5 = sequence learning)')
print(f'  Reduce : {(1 - best_ppl / p0) * 100:.1f}%\n')
print(f'  RESIDUAL ANALYSIS (what each layer learns):')
test_idx = len(tokens) // 2
ids_t = tokens[test_idx:test_idx + SEQ_LEN]
nxt_t = tokens[test_idx + SEQ_LEN]
x_t = (WTE[ids_t] + WPE[:SEQ_LEN]).copy()
print(f"  Target: '{ivocab[nxt_t]}'  |WTE[target]|={np.linalg.norm(WTE[nxt_t]):.3f}")
for li in range(N_LAYERS):
    resid = WTE[nxt_t] - x_t[-1]
    print(f'  Layer {li} input residual norm: {np.linalg.norm(resid):.4f}')
    x_t, _, _ = layer_fwd(x_t, li, w)
    after = WTE[nxt_t] - x_t[-1]
    print(f'  Layer {li} output residual norm: {np.linalg.norm(after):.4f}  (reduced: {np.linalg.norm(resid) - np.linalg.norm(after):.4f})')
print(f'\n  GENERATION:\n')
for gp in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    ids_g = [vocab[c] for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(150):
        lg = full_fwd(gen[-SEQ_LEN:], w)
        if not np.all(np.isfinite(lg[-1])):
            break
        gen.append(int(np.argmax(lg[-1])))
    out = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  '{gp}'")
    print(f'  → {out[len(gp):][:80]}\n')
print(f'  Actual top-5 chars: ', end='')
freq = np.zeros(VS)
for t in tokens:
    freq[t] += 1
    freq /= freq.sum()
print([repr(ivocab[i]) for i in np.argsort(-freq)[:5]])
print(f'\n  Trajectory: ', end='')
s = max(1, len(hist) // 12)
print(' → '.join((f'{p:.1f}' for p in hist[::s])))
print(f'\n  Time: {time.time() - t0:.0f}s')
print(f"\n{'=' * 70}")
if best_ppl < VS * 0.5:
    print(f'  ✓✓ STRONG — ppl={best_ppl:.1f}. Sequence structure learned.')
    print(f'     W-Kernel trains from scratch. No gradient descent proven.')
elif best_ppl < VS:
    print(f'  ✓ BELOW VOCAB — ppl={best_ppl:.1f}. Learned from text. Real.')
    print(f'    W-Kernel coordinate descent = valid training algorithm.')
elif best_ppl < p0 * 0.5:
    print(f'  ~ 50%+ reduction. Residuals shrinking. On right path.')
    print(f'    More data or longer text will push below vocab ceiling.')
else:
    print(f'  ~ Partial. Residuals shrinking per layer is the right signal.')
print('=' * 70 + '\n')
