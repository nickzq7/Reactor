import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
NORM = 1000.0
N_HIDDEN = 74

def gen_sequences(seq_len, n_each=200):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(seq_len + 1)]
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < seq_len + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(seq_len + 1)]
            X.append([v / NORM for v in seq[:seq_len]])
            Y.append(seq[seq_len] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(seq_len + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:seq_len]])
                Y.append(seq[seq_len] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(seq_len + 1)]
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)

def make_tests(seq_len):
    tests = []
    base = [([1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256], True), ([1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987], True), ([2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32], True), ([3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48], True), ([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768], True), ([1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120, 136], True)]
    for full_seq, _ in base:
        if len(full_seq) > seq_len:
            inp = full_seq[:seq_len]
            true = full_seq[seq_len]
            if true < NORM * 100:
                tests.append((inp, true))
    return tests

class ResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class ResNet(nn.Module):

    def __init__(self, n_hidden, dim, seq_len):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(seq_len, dim), nn.Tanh())
        self.blocks = nn.ModuleList([ResBlock(dim) for _ in range(n_hidden)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for blk in self.blocks:
            x = blk(x)
        return self.output(x)

def train(model, X_tr, Y_tr, X_te, Y_te, epochs=5000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 1000 == 0:
            print(f'    {label:<16} ep{ep:>5}  loss={best:>14.8f}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score_model(model, tests, seq_len):
    model.eval()
    c = 0
    TOL = 0.05
    with torch.no_grad():
        for seq, tn in tests:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 5000
CONFIGS = [(2, 4, [2, 4, 8, 16, 32]), (4, 16, [4, 8, 16, 32, 64]), (8, 64, [8, 16, 32, 64, 128, 256]), (16, 256, [16, 32, 64, 128, 256, 512])]
universal_results = []
for seq_len, predicted_dim, dims in CONFIGS:
    print_sep(f'SEQ_LEN={seq_len}  Predicted natural DIM={predicted_dim} ({seq_len}²)')
    X, Y = gen_sequences(seq_len)
    split = int(len(X) * 0.8)
    X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
    X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
    tests = make_tests(seq_len)
    print(f'  Data: {len(X)} sequences  Tests: {len(tests)}')
    dim_results = []
    for dim in dims:
        print(f"\n  DIM={dim} (predicted={('✓ YES' if dim == predicted_dim else '  no')})")
        np.random.seed(42)
        m = ResNet(N_HIDDEN, dim, seq_len).to(device)
        params = sum((p.numel() for p in m.parameters()))
        loss, log = train(m, X_tr, Y_tr, X_te, Y_te, EPOCHS, lr=0.001, label=f'SL={seq_len} D={dim}')
        s = score_model(m, tests, seq_len)
        dim_results.append((dim, params, loss, s))
        del m
        torch.cuda.empty_cache()
        print(f'  dim={dim:>4}  params={params:>10,}  loss={loss:.8f}  score={s}/{len(tests)}')
    valid = [(d, p, l, s) for d, p, l, s in dim_results if s == max((r[3] for r in dim_results))]
    peak_dim = min(valid, key=lambda x: x[2])[0] if valid else dim_results[0][0]
    confirmed = peak_dim == predicted_dim
    print(f'\n  SEQ_LEN={seq_len} RESULTS:')
    print(f"  {'DIM':>6}  {'Score':>8}  {'Loss':>14}  {'':>5}")
    print(f"  {'─' * 40}")
    for dim, params, loss, s in dim_results:
        tag = '← PEAK' if dim == peak_dim else ''
        pred_tag = f'[predicted={seq_len}²]' if dim == predicted_dim else ''
        print(f'  {dim:>6}  {s:>5}/{len(tests)}  {loss:>14.8f}  {tag} {pred_tag}')
    status = '✓ CONFIRMED' if confirmed else f'✗ WRONG (actual={peak_dim})'
    print(f'\n  Predicted: DIM={predicted_dim} ({seq_len}²)  →  {status}')
    universal_results.append((seq_len, predicted_dim, peak_dim, confirmed, dim_results))
print_sep('UNIVERSAL LAW VERDICT: Natural DIM = SEQ_LEN²?')
confirmed_count = sum((1 for _, _, _, c, _ in universal_results if c))
total = len(universal_results)
print(f"\n  {'SEQ_LEN':>9}  {'Predicted':>12}  {'Actual':>10}  {'Result':>14}")
print(f"  {'─' * 52}")
for seq_len, pred, actual, conf, _ in universal_results:
    result = '✓ CONFIRMED' if conf else f'✗ ACTUAL={actual}'
    print(f'  {seq_len:>9}  {pred:>9} ({seq_len}²)  {actual:>10}  {result}')
print(f'\n  Confirmed: {confirmed_count}/{total}')
if confirmed_count == total:
    print(f'\n  ██████████████████████████████████████████████████\n  UNIVERSAL LAW CONFIRMED:\n  Natural DIM = SEQ_LEN²  =  input_size²\n\n  This means:\n    The natural width of a network = input_size²\n    Because: input has N values\n             N² = all pairwise interactions\n             Each dim captures one unique interaction\n             N² dims = complete pairwise coverage\n\n  Combined with depth law:\n    Natural depth = 75 (for sequence problems)\n    Natural dim   = input_size²\n\n  FULL W PRINCIPLE GEOMETRY LAW:\n    Shape = (depth=75, dim=input²)\n    At this shape → minimum size, maximum precision\n    This is the natural geometry of sequence intelligence.\n  ██████████████████████████████████████████████████\n')
elif confirmed_count >= total // 2:
    print(f'\n  PARTIALLY CONFIRMED ({confirmed_count}/{total}):\n  Law holds for some input sizes but not all.\n  Deeper pattern may exist — not pure N².\n  Need more analysis.\n')
else:
    print(f'\n  LAW NOT CONFIRMED ({confirmed_count}/{total}):\n  Natural DIM does not follow SEQ_LEN² pattern.\n  The actual values suggest a different law:')
    for seq_len, pred, actual, conf, _ in universal_results:
        ratio = actual / seq_len if seq_len > 0 else 0
        print(f'    SEQ_LEN={seq_len} → actual={actual}  ratio={ratio:.2f}')
    print(f'  Look for pattern in ratios above.')
