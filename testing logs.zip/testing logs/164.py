import os, json, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
VS = 1001
D = 16
H = 2
NL = 2
K = 12
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
loss_fn = nn.CrossEntropyLoss()
SEQ = [i % VS for i in range(60)]
TEST_CTX = SEQ[:K]
TEST_TRUTH = SEQ[K]

def build_tensors():
    Xs = []
    Ys = []
    for i in range(len(SEQ) - K):
        Xs.append(SEQ[i:i + K])
        Ys.append(SEQ[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long).to(device), torch.tensor(Ys, dtype=torch.long).to(device))
X, Y = build_tensors()

class SmallModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def eval_model(model):
    model.eval()
    ids = torch.tensor([TEST_CTX], dtype=torch.long).to(device)
    with torch.no_grad():
        p = int(model(ids)[0, -1].argmax())
    return (p == TEST_TRUTH, p)
model = SmallModel().to(device)
params = sum((p.numel() for p in model.parameters()))
print(f'Small model params: {params:,}')
print(f'Device: {device}  D={D}  H={H}  NL={NL}  K={K}')
print(f'Pattern: counting  ctx={TEST_CTX}  truth={TEST_TRUTH}')
opt = torch.optim.Adam(model.parameters(), lr=0.003)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=3000, eta_min=1e-05)
best_sc = 0
best_state = None
t0 = time.time()
for step in range(1, 3001):
    model.train()
    opt.zero_grad()
    loss = loss_fn(model(X).view(-1, VS), Y.view(-1))
    loss.backward()
    nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    opt.step()
    sched.step()
    if step == 1 or step % 300 == 0:
        correct, pred = eval_model(model)
        mark = '✓' if correct else '✗'
        print(f'  step {step:>5}: {mark} pred={pred}  truth={TEST_TRUTH}  ({time.time() - t0:.0f}s)', flush=True)
        if correct:
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            break
if best_state:
    model.load_state_dict(best_state)
correct, pred = eval_model(model)
print(f"\nFinal: {('✓' if correct else '✗')}  pred={pred}  truth={TEST_TRUTH}")
print(f'Params: {params:,}')
np.savez(os.path.join(_dir, 'small_model_weights.npz'), **{k: v.detach().cpu().numpy() for k, v in model.state_dict().items()})
with open(os.path.join(_dir, 'small_model_meta.json'), 'w') as f:
    json.dump({'VS': VS, 'D': D, 'H': H, 'NL': NL, 'K': K, 'params': params, 'pattern': 'counting', 'score': int(correct), 'ctx': TEST_CTX, 'truth': TEST_TRUTH}, f, indent=2)
print(f'Saved: small_model_weights.npz + small_model_meta.json')
