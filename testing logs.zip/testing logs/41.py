import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN = 2000
MAX_SEQ = 64
N_SAMPLE = 500
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('\n' + '=' * 65)
print('  LOAD MODEL + DATASET')
print('=' * 65)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD, VOCAB = (H // NH, cfg.vocab_size)
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
FFN_D = teacher.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'  NL={NL} H={H} NH={NH} HD={HD} FFN_D={FFN_D}')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
sentences = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 300:
        sentences.append(t)
    if len(sentences) >= N_TRAIN:
        break
print(f'  Loaded {len(sentences)} stories')
print('\n' + '=' * 65)
print(f'  COLLECT: h_0 through h_{NL} + logits ({N_SAMPLE} stories)')
print('=' * 65)
h_streams = {-1: [], **{li: [] for li in range(NL)}}
logit_buf = []
hooks = []

def hook_embed(h_in, h_after_embed):
    h_streams[-1].append(h_after_embed.detach().float().cpu().reshape(-1, H).numpy())

def make_block_hook(li):

    def fn(mod, inp, out):
        x = out[0] if isinstance(out, tuple) else out
        h_streams[li].append(x.detach().float().cpu().reshape(-1, H).numpy())
    return fn
for li in range(NL):
    hooks.append(teacher.transformer.h[li].register_forward_hook(make_block_hook(li)))

class EmbedHook:

    def __init__(self):
        self.active = False
        self.buf = []
embed_hook_obj = EmbedHook()

def hook_wte(mod, inp, out):
    pass

def block0_pre(mod, inp):
    x = inp[0] if isinstance(inp, (tuple, list)) else inp
    h_streams[-1].append(x.detach().float().cpu().reshape(-1, H).numpy())
hooks.append(teacher.transformer.h[0].register_forward_pre_hook(block0_pre))
print(f'  Running {N_SAMPLE} stories through teacher...')
t0 = time.perf_counter()
n_tok = 0
with torch.no_grad():
    for si, sent in enumerate(sentences[:N_SAMPLE]):
        ids = tok(sent, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'].to(device)
        out = teacher(ids)
        logit_buf.append(out.logits[0].float().cpu().numpy())
        n_tok += ids.shape[1]
        if (si + 1) % 100 == 0:
            print(f'    {si + 1}/{N_SAMPLE}  tokens={n_tok}')
for hk in hooks:
    hk.remove()
t_collect = time.perf_counter() - t0
print(f'  Collected {n_tok} tokens in {t_collect:.2f}s')
for k in h_streams:
    if h_streams[k]:
        h_streams[k] = np.concatenate(h_streams[k], 0).astype(np.float32)
logits_all = np.concatenate(logit_buf, 0).astype(np.float32)
N = h_streams[-1].shape[0]
print(f'  N={N} positions  logits shape={logits_all.shape}')
print('\n' + '=' * 65)
print('  EXPERIMENT 1: DIRECT FORMULA  h_0 → logits')
print('  (Can we skip ALL 8 layers?)')
print('=' * 65)

def solve_r2(X, Y, name=''):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.concatenate([X64, np.ones((len(X64), 1))], 1)
    W, _, _, _ = lstsq(Xb, Y64, rcond=None)
    Y_pred = (X64 @ W[:-1] + W[-1]).astype(np.float32)
    ss_res = float(((Y.astype(np.float32) - Y_pred) ** 2).sum())
    ss_tot = float(((Y.astype(np.float32) - Y.astype(np.float32).mean(0)) ** 2).sum())
    return (float(1 - ss_res / (ss_tot + 1e-12)), W[:-1].T.astype(np.float32), W[-1].astype(np.float32))

def gelu_np(x):
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)
h0 = h_streams[-1]
print(f"\n  {'Features':<40} {'R²':>12}  {'params':>10}  notes")
print(f"  {'-' * 70}")
feat = h0
r2, _, _ = solve_r2(feat, logits_all, 'h0')
print(f"  {'h_0':<40} {r2:12.8f}  {feat.shape[1] * VOCAB:>10}  raw embedding")
feat = np.concatenate([h0, h0 ** 2], -1)
r2, _, _ = solve_r2(feat, logits_all, 'h0_sq')
print(f"  {'(h_0, h_0²)':<40} {r2:12.8f}  {feat.shape[1] * VOCAB:>10}  GeLU natural space")
feat = np.concatenate([h0, h0 ** 2, h0 ** 3], -1)
r2, _, _ = solve_r2(feat, logits_all, 'h0_cubic')
print(f"  {'(h_0, h_0², h_0³)':<40} {r2:12.8f}  {feat.shape[1] * VOCAB:>10}  cubic features")
print(f"  {'Computing pairwise...':<40}", end='', flush=True)
triu_idx = np.triu_indices(H)
h0_outer = (h0[:, :, None] * h0[:, None, :])[:, triu_idx[0], triu_idx[1]]
feat = np.concatenate([h0, h0 ** 2, h0_outer], -1)
r2, _, _ = solve_r2(feat[:5000], logits_all[:5000], 'h0_outer')
print(f' {r2:12.8f}  {feat.shape[1] * VOCAB:>10}  pairwise products')
print('\n' + '=' * 65)
print('  EXPERIMENT 2: MINIMUM DEPTH')
print('  Adding h_k one layer at a time until R²=1.0')
print('=' * 65)
print(f"\n  {'Features used':<45} {'R²':>12}  {'dim':>8}  status")
print(f"  {'-' * 75}")
NSUB = min(10000, N)
idx = np.random.RandomState(42).choice(N, NSUB, replace=False)

def r2_subset(feat_full, tgt_full):
    f = feat_full[idx].astype(np.float64)
    t = tgt_full[idx].astype(np.float64)
    fb = np.concatenate([f, np.ones((len(f), 1))], 1)
    W, _, _, _ = lstsq(fb, t, rcond=None)
    pred = (f @ W[:-1] + W[-1]).astype(np.float32)
    ss_res = float(((t.astype(np.float32) - pred) ** 2).sum())
    ss_tot = float(((t.astype(np.float32) - t.astype(np.float32).mean(0)) ** 2).sum())
    return float(1 - ss_res / (ss_tot + 1e-12))
h_final = h_streams[NL - 1]
prev_r2 = 0.0
cumulative_features = []
feature_labels = []
tests = [('h_0', h_streams[-1])] + [(f'h_{li}', h_streams[li]) for li in range(NL)]
running_feat = None
for label, h_k in tests:
    if running_feat is None:
        running_feat = h_k
    else:
        running_feat = np.concatenate([running_feat, h_k], -1)
    feat_with_sq = np.concatenate([running_feat, running_feat[:, :H] ** 2], -1)
    r2_plain = r2_subset(running_feat, h_final)
    r2_sq = r2_subset(feat_with_sq, h_final)
    best = max(r2_plain, r2_sq)
    which = '+' if r2_sq > r2_plain else ' '
    delta = best - prev_r2
    status = '✓ SATURATED' if best > 0.9999 else '~' if best > 0.999 else f'+{delta:+.4f}'
    feat_name = f'cumul up to {label}'
    print(f'  {feat_name:<45} {best:12.8f}  {running_feat.shape[1]:>8}  {status}')
    prev_r2 = best
    if best > 0.9999:
        print(f'\n  ✓ R²=1.0 achieved at depth = {label}')
        print(f'    {running_feat.shape[1]} features → full prediction')
        print(f'    Transformer uses {NL} layers for what needs: {label}')
        break
print('\n' + '=' * 65)
print('  EXPERIMENT 3: LAYER CONTRIBUTION')
print('  R² of h_k alone (without cumulative) → which layer matters most?')
print('=' * 65)
print(f"\n  {'Layer':<12} {'R²(h_k alone)':>15}  {'R²(h_k,h_k²)':>15}  notes")
print(f"  {'-' * 60}")
for label, h_k in tests:
    r2_alone = r2_subset(h_k, h_final)
    feat_sq = np.concatenate([h_k, h_k ** 2], -1)
    r2_sq = r2_subset(feat_sq, h_final)
    best = max(r2_alone, r2_sq)
    bar = '█' * int(best * 20) + '░' * (20 - int(best * 20))
    print(f'  {label:<12} {r2_alone:15.8f}  {r2_sq:15.8f}  {bar}')
print('\n' + '=' * 65)
print('  EXPERIMENT 4: MINIMUM REACTOR ARCHITECTURE')
print('  Skip layers: which subset of {0..7} gives R²=1.0?')
print('=' * 65)
best_single = None
best_single_r2 = 0.0
for label, h_k in tests[1:]:
    r2 = r2_subset(h_k, h_final)
    if r2 > best_single_r2:
        best_single_r2 = r2
        best_single = label
print(f'\n  Best single layer:    {best_single}  R²={best_single_r2:.8f}')
print(f'\n  Best layer pairs (top 5):')
pairs = []
layer_list = tests[1:]
for i in range(len(layer_list)):
    for j in range(i + 1, len(layer_list)):
        li, hi = layer_list[i]
        lj, hj = layer_list[j]
        feat = np.concatenate([hi, hj], -1)
        r2 = r2_subset(feat, h_final)
        pairs.append((r2, f'{li}+{lj}'))
pairs.sort(reverse=True)
for r2, name in pairs[:5]:
    bar = '█' * int(r2 * 20)
    print(f'    {name:<15} R²={r2:.8f}  {bar}')
print(f'\n  Best layer triples (top 5):')
triples = []
for i in range(len(layer_list)):
    for j in range(i + 1, len(layer_list)):
        for k in range(j + 1, len(layer_list)):
            li, hi = layer_list[i]
            lj, hj = layer_list[j]
            lk, hk = layer_list[k]
            feat = np.concatenate([hi, hj, hk], -1)
            r2 = r2_subset(feat, h_final)
            triples.append((r2, f'{li}+{lj}+{lk}'))
triples.sort(reverse=True)
for r2, name in triples[:5]:
    bar = '█' * int(r2 * 20)
    print(f'    {name:<20} R²={r2:.8f}  {bar}')
print('\n' + '=' * 65)
print('  SUMMARY — MINIMUM DEPTH ANALYSIS')
print('=' * 65)
print(f'\n  Model: TinyStories-1M  NL={NL} H={H}\n  Data:  {N} token positions from {N_SAMPLE} diverse stories\n\n  DIRECT FORMULA (h_0 → logits, 0 layers):\n    Single h_0:     see above   ← how much does embedding alone explain?\n    (h_0, h_0²):    see above   ← GeLU natural space of embedding\n    Pairwise:       see above   ← full outer product of embedding\n\n  MINIMUM DEPTH:\n    R² saturates at 1.0 when: see Experiment 2 results\n    Transformer uses {NL} layers. True minimum depth: see above.\n\n  LAYER IMPORTANCE (Experiment 3):\n    Early layers vs late layers — which carries more signal?\n    Last layer alone may be close to sufficient (Law 26 prediction).\n\n  REACTOR DESIGN IMPLICATION:\n    If k layers suffice for R²=1.0 where k < {NL}:\n      Build REACTOR with k layers instead of {NL}\n      Same quality, {NL - 1}-k fewer layers\n      Faster training, faster inference\n\n  This answers the question:\n    "Can we go from input to output by formula?"\n    Yes — the minimum formula depth is revealed above.\n')
