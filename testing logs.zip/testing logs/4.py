import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
NORM = 1000.0
SEQ_LEN = 4

class EntangledComplexState:

    @staticmethod
    def entangle(x_real, x_imag, n_groups=4):
        batch, dim = x_real.shape
        group_size = dim // n_groups
        out_real = x_real.clone()
        out_imag = x_imag.clone()
        for g in range(n_groups):
            start = g * group_size
            end = start + group_size if g < n_groups - 1 else dim
            gr = x_real[:, start:end]
            gi = x_imag[:, start:end]
            phases = torch.atan2(gi, gr)
            shared_phi = phases.mean(dim=-1, keepdim=True)
            mag = torch.sqrt(gr ** 2 + gi ** 2 + 1e-08)
            out_real[:, start:end] = mag * torch.cos(shared_phi)
            out_imag[:, start:end] = mag * torch.sin(shared_phi)
        return (out_real, out_imag)

class AdaptiveComplexBlock(nn.Module):

    def __init__(self, dim, n_groups=4):
        super().__init__()
        self.dim = dim
        self.n_groups = n_groups
        state_dim = 3
        self.gen_W_real = nn.Sequential(nn.Linear(state_dim, dim * dim // 4), nn.Tanh(), nn.Linear(dim * dim // 4, dim * dim))
        self.gen_W_imag = nn.Sequential(nn.Linear(state_dim, dim * dim // 4), nn.Tanh(), nn.Linear(dim * dim // 4, dim * dim))
        self.bias_real = nn.Parameter(torch.zeros(dim))
        self.bias_imag = nn.Parameter(torch.zeros(dim))
        self.act_bias = nn.Parameter(torch.zeros(dim) - 1.0)

    def get_state_summary(self, x_real, x_imag):
        mag = torch.sqrt(x_real ** 2 + x_imag ** 2 + 1e-08)
        phase = torch.atan2(x_imag, x_real)
        mag_mean = mag.mean(dim=-1)
        phase_mean = phase.mean(dim=-1)
        mag_std = mag.std(dim=-1)
        summary = torch.stack([mag_mean, phase_mean, mag_std], dim=-1)
        return summary

    def forward(self, x_real, x_imag):
        batch = x_real.shape[0]
        dim = self.dim
        summary = self.get_state_summary(x_real, x_imag)
        W_real_flat = self.gen_W_real(summary)
        W_imag_flat = self.gen_W_imag(summary)
        W_real = W_real_flat.view(batch, dim, dim)
        W_imag = W_imag_flat.view(batch, dim, dim)
        scale = 1.0 / math.sqrt(dim)
        W_real = W_real * scale
        W_imag = W_imag * scale
        xr = x_real.unsqueeze(-1)
        xi = x_imag.unsqueeze(-1)
        yr = (W_real @ xr - W_imag @ xi).squeeze(-1) + self.bias_real
        yi = (W_real @ xi + W_imag @ xr).squeeze(-1) + self.bias_imag
        yr, yi = EntangledComplexState.entangle(yr, yi, self.n_groups)
        mag = torch.sqrt(yr ** 2 + yi ** 2 + 1e-08)
        gate = F.relu(mag + self.act_bias) / mag
        yr, yi = (yr * gate, yi * gate)
        yr = x_real + yr
        yi = x_imag + yi
        return (yr, yi)

class AECNet(nn.Module):

    def __init__(self, dim, n_blocks, n_groups=4, seq_len=SEQ_LEN):
        super().__init__()
        self.dim = dim
        self.input_real = nn.Linear(seq_len, dim)
        self.input_imag = nn.Linear(seq_len, dim)
        nn.init.normal_(self.input_imag.weight, std=0.01)
        self.blocks = nn.ModuleList([AdaptiveComplexBlock(dim, n_groups) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        xr = torch.tanh(self.input_real(x))
        xi = torch.tanh(self.input_imag(x))
        for blk in self.blocks:
            xr, xi = blk(xr, xi)
        mag = torch.sqrt(xr ** 2 + xi ** 2 + 1e-08)
        return self.output(mag)

class ComplexResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.W_real = nn.Linear(dim, dim)
        self.W_imag = nn.Linear(dim, dim, bias=False)
        nn.init.normal_(self.W_imag.weight, std=0.01)
        self.act_bias = nn.Parameter(torch.zeros(dim) - 1.0)

    def forward(self, xr, xi):
        yr = self.W_real(xr) - self.W_imag(xi)
        yi = self.W_real(xi) + self.W_imag(xr)
        mag = torch.sqrt(yr ** 2 + yi ** 2 + 1e-08)
        gate = F.relu(mag + self.act_bias) / mag
        yr, yi = (yr * gate, yi * gate)
        return (xr + yr, xi + yi)

class ComplexNet(nn.Module):

    def __init__(self, dim, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.input_real = nn.Linear(seq_len, dim)
        self.input_imag = nn.Linear(seq_len, dim)
        nn.init.normal_(self.input_imag.weight, std=0.01)
        self.blocks = nn.ModuleList([ComplexResBlock(dim) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        xr = torch.tanh(self.input_real(x))
        xi = torch.tanh(self.input_imag(x))
        for b in self.blocks:
            xr, xi = b(xr, xi)
        mag = torch.sqrt(xr ** 2 + xi ** 2 + 1e-08)
        return self.output(mag)

class FlatResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.l = nn.Linear(dim, dim)
        self.a = nn.Tanh()

    def forward(self, x):
        return self.a(self.l(x)) + x

class FlatNet(nn.Module):

    def __init__(self, dim, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.p = nn.Sequential(nn.Linear(seq_len, dim), nn.Tanh())
        self.b = nn.ModuleList([FlatResBlock(dim) for _ in range(n_blocks)])
        self.o = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.p(x)
        for b in self.b:
            x = b(x)
        return self.o(x)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05
X, Y = gen_sequences()
sp = int(len(X) * 0.8)
X_tr, Y_tr = (X[:sp].to(device), Y[:sp].to(device))
X_te, Y_te = (X[sp:].to(device), Y[sp:].to(device))
print(f'Sequences: {len(X)}')

def train(model, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model)
            print(f'    {label:<24} ep{ep:>5}  loss={best:>12.6f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 3000
configs = [('Flat res dim=16 b=10', FlatNet(16, 10)), ('Flat res dim=16 b=74', FlatNet(16, 74)), ('Complex dim=8 b=10', ComplexNet(8, 10)), ('Complex dim=8 b=74', ComplexNet(8, 74)), ('AEC dim=8 b=4 g=4', AECNet(8, 4, n_groups=4)), ('AEC dim=8 b=8 g=4', AECNet(8, 8, n_groups=4)), ('AEC dim=8 b=4 g=2', AECNet(8, 4, n_groups=2)), ('AEC dim=4 b=8 g=2', AECNet(4, 8, n_groups=2)), ('AEC dim=4 b=4 g=4', AECNet(4, 4, n_groups=4))]
print_sep('ADAPTIVE ENTANGLED COMPLEX vs FLAT vs COMPLEX')
results = []
for label, model in configs:
    model = model.to(device)
    params = sum((p.numel() for p in model.parameters()))
    print(f'\n  ── {label} (params={params:,}) ──')
    np.random.seed(42)
    loss, log = train(model, EPOCHS, lr=0.001, label=label[:24])
    s = score(model)
    results.append((label, params, loss, s, log))
    del model
    torch.cuda.empty_cache()
print_sep('FINAL SCOREBOARD')
results.sort(key=lambda x: (-x[3], x[2]))
print(f"\n  {'Model':<28}  {'Params':>10}  {'Score':>7}  {'Loss':>14}  Type")
print(f"  {'─' * 78}")
for rank, (label, params, loss, s, _) in enumerate(results):
    if 'AEC' in label:
        typ = 'AEC (adaptive+entangled)'
    elif 'Complex' in label:
        typ = 'complex'
    else:
        typ = 'flat'
    mark = ' ← WINNER' if rank == 0 else ''
    print(f'  {label:<28}  {params:>10,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {typ}{mark}')
print_sep('WHAT ADAPTIVE ENTANGLEMENT MEANS')
best_flat = min([r for r in results if 'Flat' in r[0]], key=lambda x: x[2])
best_aec = min([r for r in results if 'AEC' in r[0]], key=lambda x: x[2])
best_comp = min([r for r in results if 'Complex' in r[0]], key=lambda x: x[2])
print(f'\n  Flat (frozen after training):\n    loss={best_flat[2]:.6f}  params={best_flat[1]:,}\n\n  Complex (richer coords, still frozen):\n    loss={best_comp[2]:.6f}  params={best_comp[1]:,}\n\n  AEC (adaptive+entangled, never frozen):\n    loss={best_aec[2]:.6f}  params={best_aec[1]:,}\n\n  ADAPTIVE means:\n    Block weights = f(current state)\n    Every input → slightly different network\n    Network rewrites itself per forward pass\n    This is what the subconscious does —\n    each thought reshapes the next\n\n  ENTANGLED means:\n    Dims within group share one complex phase\n    Change one → all adjust instantly\n    Not communication — shared existence\n    This is genuine multi-state per coordinate\n\n  COMBINED:\n    The most adaptive possible network\n    in the most natural possible space\n    Never frozen. Always contextual.\n    This is the direction of true intelligence.\n')
