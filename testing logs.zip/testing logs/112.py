import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
DC = 8
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_primes(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s

def make_all_patterns():
    pats = {}
    for step in range(1, 25):
        pats[f'a{step}'] = ([i * step % VS for i in range(20)], 20 * step % VS)
    for start in range(25, 33):
        pats[f'd{start}'] = ([(start - i) % VS for i in range(20)], (start - 20) % VS)
    fib = gen_fib(40)
    for off in range(8):
        pats[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
    for r in [2, 3, 4, 5, 6, 7, 8, 9]:
        pats[f'g{r}'] = ([r ** i % VS for i in range(20)], r ** 20 % VS)
    for c in range(8):
        pats[f'sq{c}'] = ([(i + c) ** 2 % VS for i in range(20)], (20 + c) ** 2 % VS)
    for step in [3, 5]:
        for off in range(4):
            pats[f's{step}o{off}'] = ([(i * step + off) % VS for i in range(20)], (20 * step + off) % VS)
    return pats
ALL_PATS = make_all_patterns()
PAT_NAMES = list(ALL_PATS.keys())
N_DONORS = 8
DONOR_PATS = [PAT_NAMES[i * 8:(i + 1) * 8] for i in range(N_DONORS)]
DONOR_SETS = {2: [0, 4], 4: [0, 4, 5, 6], 6: [0, 4, 5, 6, 3, 7], 8: [0, 4, 5, 6, 3, 7, 1, 2]}

class SeqT16(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

class SeqT8(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, DC)
        self.wpe = nn.Embedding(K, DC)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(DC), 'attn': nn.MultiheadAttention(DC, H, batch_first=True), 'ln2': nn.LayerNorm(DC), 'ff': nn.Sequential(nn.Linear(DC, DC * 4), nn.GELU(), nn.Linear(DC * 4, DC))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(DC)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_donor(di):
    path = os.path.join(_dir, f'donor_{di:02d}.npz')
    W = np.load(path)
    state = {k: torch.tensor(v.astype(np.float32)) for k, v in W.items()}
    m = SeqT16().to(device)
    m.load_state_dict(state, strict=True)
    return m

def eval_model(model, donor_indices):
    model.eval()
    per_donor = []
    for di in donor_indices:
        sc = 0
        for pn in DONOR_PATS[di]:
            seq, truth = ALL_PATS[pn]
            ids = torch.tensor([seq[-K:]], dtype=torch.long)
            with torch.no_grad():
                p = int(model(ids)[0, -1].argmax())
            sc += p == truth
        per_donor.append(sc)
    return (sum(per_donor), per_donor)

def eval_wte8(wte8_np, scratch8, donor_indices):
    with torch.no_grad():
        scratch8.wte.weight.copy_(torch.tensor(wte8_np, dtype=torch.float32))
    return eval_model(scratch8, donor_indices)

def mutate_wte(wte, rng):
    w = wte.copy()
    op = rng.choice(['sign_flip', 'scale', 'cross_dims', 'rot', 'noise', 'inject', 'token_shift', 'permute'])
    if op == 'sign_flip':
        dims = rng.choice(DC, rng.randint(1, DC // 2 + 1), replace=False)
        w[:, dims] *= -1
    elif op == 'scale':
        dims = rng.choice(DC, rng.randint(1, DC // 2 + 1), replace=False)
        w[:, dims] *= rng.uniform(0.3, 3.0, len(dims))
    elif op == 'cross_dims':
        d1, d2 = rng.choice(DC, 2, replace=False)
        a = rng.uniform(0.1, 0.9)
        c1 = a * w[:, d1] + (1 - a) * w[:, d2]
        c2 = (1 - a) * w[:, d1] + a * w[:, d2]
        w[:, d1] = c1
        w[:, d2] = c2
    elif op == 'rot':
        d1, d2 = rng.choice(DC, 2, replace=False)
        ang = rng.uniform(0.1, math.pi)
        c, s = (math.cos(ang), math.sin(ang))
        wi = w[:, d1].copy()
        wj = w[:, d2].copy()
        w[:, d1] = c * wi - s * wj
        w[:, d2] = s * wi + c * wj
    elif op == 'noise':
        w += rng.randn(*w.shape) * np.std(w) * rng.uniform(0.02, 0.2)
    elif op == 'inject':
        d = rng.randint(DC)
        v = rng.randn(VS)
        v /= np.linalg.norm(v) + 1e-08
        w[:, d] += v * np.std(w) * rng.uniform(0.1, 1.0)
    elif op == 'token_shift':
        toks = rng.choice(VS, rng.randint(2, VS // 3 + 1), replace=False)
        w[toks] += rng.randn(DC) * np.std(w) * rng.uniform(0.05, 0.3)
    elif op == 'permute':
        dims = rng.choice(DC, rng.randint(2, DC // 2 + 1), replace=False)
        w[:, dims] = w[:, rng.permutation(dims)]
    return w

def crossbreed_wte(wte_list, rng):
    child = np.zeros_like(wte_list[0])
    for d in range(DC):
        child[:, d] = wte_list[rng.randint(len(wte_list))][:, d]
    flip = rng.choice(DC, rng.randint(1, 4), replace=False)
    child[:, flip] *= -1
    return child

def build_tensors_for(donor_indices):
    Xs = []
    Ys = []
    for di in donor_indices:
        for pn in DONOR_PATS[di]:
            seq, _ = ALL_PATS[pn]
            for i in range(len(seq) - K):
                Xs.append(seq[i:i + K])
                Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long, device=device), torch.tensor(Ys, dtype=torch.long, device=device))

def train_child8(init_wte8, donor_indices, steps=2000, lr=0.003, label='child', print_every=200, prev_wte=None):
    model = SeqT8().to(device)
    for name, param in model.named_parameters():
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.zeros_(param)
    with torch.no_grad():
        model.wte.weight.copy_(torch.tensor(init_wte8, dtype=torch.float32))
        if prev_wte is not None:
            model.wpe.weight.copy_(torch.tensor(prev_wte, dtype=torch.float32))
    X, Y = build_tensors_for(donor_indices)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=5e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(X).view(-1, VS), Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, per = eval_model(model, donor_indices)
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  [{label}] step {step:>5}: {sc}/{len(donor_indices) * 8}  {per}', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    return (best_s, model)

def mutation_search_wte8(donor_wtes16, donor_indices, n_mutations=8000, niche_size=6, label=''):
    n = len(donor_indices)
    rng = np.random.RandomState(42)
    scratch = SeqT8().to(device)
    for name, param in scratch.named_parameters():
        if 'wte' not in name:
            if param.dim() > 1:
                nn.init.xavier_uniform_(param)
            else:
                nn.init.zeros_(param)
    pool = []
    for wte16 in donor_wtes16:
        U, s, Vt = np.linalg.svd(wte16, full_matrices=False)
        wte8 = (U[:, :DC] * s[:DC]).astype(np.float64)
        pool.append(wte8)
    mean16 = np.mean(donor_wtes16, axis=0)
    U, s, Vt = np.linalg.svd(mean16, full_matrices=False)
    pool.append((U[:, :DC] * s[:DC]).astype(np.float64))
    niches = [[] for _ in range(n)]
    global_best = (0, None)
    print(f'  Searching {n_mutations} mutations for {n} donors...')
    for mi in range(n_mutations):
        r = rng.rand()
        if r < 0.4:
            base = pool[rng.randint(len(pool))].copy()
        elif r < 0.7:
            nonempty = [i for i, nic in enumerate(niches) if len(nic) > 0]
            if nonempty:
                ni = rng.choice(nonempty)
                _, base = niches[ni][rng.randint(len(niches[ni]))]
                base = base.copy()
            else:
                base = pool[rng.randint(len(pool))].copy()
        else:
            nonempty = [i for i, nic in enumerate(niches) if len(nic) > 0]
            if len(nonempty) >= 2:
                sources = [niches[rng.choice(nonempty)][0][1] for _ in range(rng.randint(2, 4))]
                base = crossbreed_wte(sources, rng)
            else:
                base = pool[rng.randint(len(pool))].copy()
        wte8 = base
        for _ in range(1 if rng.rand() < 0.7 else 2):
            wte8 = mutate_wte(wte8, rng)
        total, per = eval_wte8(wte8, scratch, donor_indices)
        if total > global_best[0]:
            global_best = (total, wte8.copy())
            print(f'    mut {mi:>6}  NEW BEST: {total}/{n * 8}  {per}', flush=True)
        for i, di_score in enumerate(per):
            if di_score > 0:
                niches[i].append((di_score, wte8.copy()))
                niches[i].sort(key=lambda x: x[0], reverse=True)
                niches[i] = niches[i][:niche_size]
        if (mi + 1) % 2000 == 0:
            print(f'    {mi + 1}/{n_mutations}  best={global_best[0]}/{n * 8}  niches={[len(nic) for nic in niches]}', flush=True)
    return (global_best[1], global_best[0])
print('=' * 60)
print('  INCREMENTAL DONOR SCALING: 2 → 4 → 6 → 8 DONORS')
print('  D=16 donors → D=8 child via random mutation search')
print('=' * 60)
print('\n  Loading donors...')
donors = {}
for di in range(N_DONORS):
    m = load_donor(di)
    sc, per = eval_model(m, list(range(N_DONORS)))
    donors[di] = m
    print(f'  Donor {di + 1}  total={sc}/64  {per}')
t_total = time.time()
prev_best_wte8 = None
results = {}
for n_d in [2, 4, 6, 8]:
    d_indices = DONOR_SETS[n_d]
    print(f"\n{'=' * 60}")
    print(f'  STEP: {n_d} DONORS  →  D=8 CHILD')
    print(f'  Donors: {[i + 1 for i in d_indices]}')
    print(f'  Patterns: {n_d * 8} total')
    print(f"{'=' * 60}")
    donor_wtes16 = [donors[di].wte.weight.detach().numpy().astype(np.float64) for di in d_indices]
    print(f'\n  Individual donor scores on their own {n_d * 8} patterns:')
    for idx, di in enumerate(d_indices):
        sc, per = eval_model(donors[di], d_indices)
        print(f'    Donor {di + 1}: {sc}/{n_d * 8}  {per}')
    t0 = time.time()
    print(f'\n  Mutation search (D=16→D=8)...')
    best_wte8, search_score = mutation_search_wte8(donor_wtes16, d_indices, n_mutations=8000, niche_size=6, label=f'{n_d}donors')
    print(f'\n  Best WTE found: {search_score}/{n_d * 8}  ({time.time() - t0:.1f}s)')
    print(f'\n  Training D=8 child on {n_d * 8} patterns (2000 steps)...')
    final_sc, child_model = train_child8(best_wte8, d_indices, steps=2000, lr=0.003, label=f'{n_d}donors', print_every=200)
    sc, per = eval_model(child_model, d_indices)
    results[n_d] = {'score': sc, 'per': per, 'max': n_d * 8}
    prev_best_wte8 = best_wte8
    print(f'\n  ── RESULT: {n_d} donors ──')
    for idx, di in enumerate(d_indices):
        bar = ''.join(('█' if j < per[idx] else '░' for j in range(8)))
        print(f'  Donor {di + 1}  {bar}  {per[idx]}/8  ({DONOR_PATS[di][0][:4]}..) ')
    print(f'  TOTAL: {sc}/{n_d * 8}  ({sc / (n_d * 8) * 100:.1f}%)')
    print(f'  Time: {time.time() - t0:.1f}s')
print(f"\n{'=' * 60}")
print(f'  INCREMENTAL SCALING SUMMARY')
print(f"{'=' * 60}")
print(f"\n  {'Donors':>8}  {'Score':>10}  {'Pct':>6}  {'Per donor'}")
print(f"  {'─' * 55}")
for n_d in [2, 4, 6, 8]:
    r = results[n_d]
    pct = r['score'] / r['max'] * 100
    print(f"  {n_d:>8}  {r['score']:>4}/{r['max']:<5}  {pct:>5.1f}%  {r['per']}")
print(f'\n  Total time: {time.time() - t_total:.0f}s')
print(f'\n  KEY OBSERVATION:')
print(f'  Watch where % drops sharply — that is where the')
print(f'  natural space of D=8 hits its limit for these patterns.')
print('=' * 60)
