import numpy as np
w = np.load('donor_00.npz')
print(list(w.keys()))
