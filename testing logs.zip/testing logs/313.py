import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — PURE NUMPY ENGINE')
print('  Extracting exact native W-Matrices to sever PyTorch.')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
print('\n  Extracting the true native W-Matrices (Bypassing lstsq null-space trap)...')
W_layers = {}
with torch.no_grad():
    for l in range(n_layers):
        block = model.transformer.h[l]
        W_layers[l] = {'q': block.attn.attention.q_proj.weight.detach().numpy().T, 'k': block.attn.attention.k_proj.weight.detach().numpy().T, 'v': block.attn.attention.v_proj.weight.detach().numpy().T, 'o': block.attn.attention.out_proj.weight.detach().numpy().T, 'b_o': block.attn.attention.out_proj.bias.detach().numpy(), '1': block.mlp.c_fc.weight.detach().numpy().T, 'b_1': block.mlp.c_fc.bias.detach().numpy(), '2': block.mlp.c_proj.weight.detach().numpy().T, 'b_2': block.mlp.c_proj.bias.detach().numpy(), 'ln1_w': block.ln_1.weight.detach().numpy(), 'ln1_b': block.ln_1.bias.detach().numpy(), 'ln2_w': block.ln_2.weight.detach().numpy(), 'ln2_b': block.ln_2.bias.detach().numpy()}
print('  ✓ All 48 Native Highways securely extracted.')
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_head_w = model.lm_head.weight.detach().numpy()

def gelu_np(x):
    x = x.astype(np.float32)
    return 0.5 * x * (1.0 + np.tanh(np.float32(math.sqrt(2.0 / math.pi)) * (x + np.float32(0.044715) * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def layernorm_np(x, gamma, beta, eps=1e-05):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = x.var(-1, keepdims=True)
    return (x - mean) / np.sqrt(var + np.float32(eps)) * gamma + beta
prompt = 'Once upon a time, in a small village, there lived a boy named Jack.'
input_ids = tokenizer.encode(prompt, return_tensors='pt')
tokens_to_generate = 30
print('\n' + '─' * 66)
print(f'  GENERATING {tokens_to_generate} TOKENS (Greedy Argmax)')
print('─' * 66)
pt_ids = input_ids.clone()
with torch.no_grad():
    for _ in range(tokens_to_generate):
        logits = model(pt_ids).logits
        next_id = torch.argmax(logits[0, -1, :]).item()
        pt_ids = torch.cat([pt_ids, torch.tensor([[next_id]])], dim=1)
pt_text = tokenizer.decode(pt_ids[0])
print(f'\n  [ PYTORCH ENGINE ]:\n  {pt_text}')
np_ids = input_ids[0].tolist()
for step in range(tokens_to_generate):
    seq_len = len(np_ids)
    x = wte[np_ids] + wpe[np.arange(seq_len)]
    x = x.astype(np.float32)
    for l in range(n_layers):
        W = W_layers[l]
        ln1 = layernorm_np(x, W['ln1_w'], W['ln1_b'])
        q = ln1 @ W['q']
        k = ln1 @ W['k']
        v = ln1 @ W['v']
        q_heads = q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        k_heads = k.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        v_heads = v.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        att_h_list = []
        for h_id in range(n_heads):
            scr = q_heads[h_id] @ k_heads[h_id].T / np.float32(math.sqrt(head_dim))
            msk = np.triu(np.full((seq_len, seq_len), -1000000000.0, dtype=np.float32), 1)
            att_w = softmax_np(scr + msk)
            att_h_list.append(att_w @ v_heads[h_id])
        concat_h = np.array(att_h_list).transpose(1, 0, 2).reshape(seq_len, D)
        att_out = concat_h @ W['o'] + W['b_o']
        x = x + att_out
        ln2 = layernorm_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['1'] + W['b_1']
        gelu = gelu_np(pre)
        ffn_out = gelu @ W['2'] + W['b_2']
        x = x + ffn_out
    h_f = layernorm_np(x[-1:], lnf_w, lnf_b)
    logits = h_f @ lm_head_w.T
    next_id = int(np.argmax(logits[0]))
    np_ids.append(next_id)
np_text = tokenizer.decode(np_ids)
print(f'\n  [ PURE NUMPY ENGINE ]:\n  {np_text}')
print('\n' + '=' * 66)
print('  IF TEXTS MATCH 100%: DEEP LEARNING ARCHITECTURE IS AN ILLUSION.')
print('=' * 66 + '\n')
