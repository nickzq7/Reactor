import os, json, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
STEPS = 1200
LR = 0.005
for i in range(32):
    p = os.path.join(_dir, f'donor_{i:02d}.npz')
    if os.path.exists(p):
        os.remove(p)

def arith(step, n=60):
    return [i * step % VS for i in range(n)]

def countdown(step, n=60):
    return [(VS - 1 - i * step) % VS for i in range(n)]

def fib(a, b, n=60):
    s = [a % VS, b % VS]
    while len(s) < n:
        s.append((s[-1] + s[-2]) % VS)
    return s

def geo(base, n=60):
    s = [1]
    for _ in range(n - 1):
        s.append(s[-1] * base % VS)
    return s

def poly(fn, n=60):
    return [fn(i) % VS for i in range(n)]

def skip(step, offset, n=60):
    return [(offset + i * step) % VS for i in range(n)]
MODEL_PATTERNS = [[('a1', arith(1)), ('a2', arith(2)), ('a3', arith(3)), ('a4', arith(4)), ('a5', arith(5)), ('a6', arith(6)), ('a7', arith(7)), ('a8', arith(8))], [('a9', arith(9)), ('a10', arith(10)), ('a11', arith(11)), ('a12', arith(12)), ('a13', arith(13)), ('a14', arith(14)), ('a15', arith(15)), ('a16', arith(16))], [('a17', arith(17)), ('a18', arith(18)), ('a19', arith(19)), ('a20', arith(20)), ('a21', arith(21)), ('a22', arith(22)), ('a23', arith(23)), ('a24', arith(24))], [('d1', countdown(1)), ('d2', countdown(2)), ('d3', countdown(3)), ('d4', countdown(4)), ('d5', countdown(5)), ('d6', countdown(6)), ('d7', countdown(7)), ('d8', countdown(8))], [('f1', fib(1, 2)), ('f2', fib(3, 7)), ('f3', fib(5, 11)), ('f4', fib(2, 9)), ('f5', fib(7, 13)), ('f6', fib(4, 15)), ('f7', fib(6, 17)), ('f8', fib(8, 19))], [('g2', geo(2)), ('g3', geo(3)), ('g4', geo(4)), ('g5', geo(5)), ('g6', geo(6)), ('g7', geo(7)), ('g9', geo(9)), ('g11', geo(11))], [('sq0', poly(lambda i: i * i)), ('sq1', poly(lambda i: (i + 1) * (i + 1))), ('sq2', poly(lambda i: (i + 2) * (i + 2))), ('sq3', poly(lambda i: (i + 3) * (i + 3))), ('sq4', poly(lambda i: (i + 4) * (i + 4))), ('sq5', poly(lambda i: (i + 5) * (i + 5))), ('sq6', poly(lambda i: (i + 6) * (i + 6))), ('sq7', poly(lambda i: (i + 7) * (i + 7)))], [('s3o0', skip(3, 0)), ('s3o1', skip(3, 1)), ('s3o2', skip(3, 2)), ('s3o3', skip(3, 3)), ('s5o0', skip(5, 0)), ('s5o1', skip(5, 1)), ('s5o2', skip(5, 2)), ('s5o3', skip(5, 3))]]
for mi, mp in enumerate(MODEL_PATTERNS):
    for name, seq in mp:
        bad = [v for v in seq if v < 0 or v >= VS]
        assert not bad, f'Model {mi} {name} out of range: {bad[:3]}'
print(f'VS={VS} K={K} D={D} H={H} NL={NL}')
print(f'64 patterns verified.')

class Transformer(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, x):
        B, T = x.shape
        h = self.wte(x) + self.wpe(torch.arange(T, device=x.device))
        mask = torch.triu(torch.full((T, T), float('-inf'), device=x.device), diagonal=1)
        for ly in self.layers:
            n = ly['ln1'](h)
            a, _ = ly['attn'](n, n, n, attn_mask=mask, need_weights=False)
            h = h + a
            h = h + ly['ff'](ly['ln2'](h))
        return self.ln_f(h) @ self.wte.weight.T

def build_data(patterns):
    X, Y = ([], [])
    for _, seq in patterns:
        for i in range(len(seq) - K):
            X.append(seq[i:i + K])
            Y.append(seq[i + 1:i + K + 1])
    return (torch.tensor(X, dtype=torch.long), torch.tensor(Y, dtype=torch.long))

def score(model, patterns):
    model.eval()
    rows = []
    for name, seq in patterns:
        ctx = torch.tensor([seq[:K]], dtype=torch.long)
        truth = seq[K]
        with torch.no_grad():
            pred = int(model(ctx)[0, -1].argmax())
        rows.append((name, pred, truth, pred == truth))
    return rows
loss_fn = nn.CrossEntropyLoss()
print('=' * 60)
print(f'  PHASE 1  8 donors  {STEPS} steps each')
print('=' * 60)
t0 = time.time()
all_scores = []
for i, patterns_i in enumerate(MODEL_PATTERNS):
    path = os.path.join(_dir, f'donor_{i:02d}.npz')
    torch.manual_seed(i * 13)
    np.random.seed(i * 13)
    model = Transformer()
    for nm, p in model.named_parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
        else:
            nn.init.zeros_(p)
    X, Y = build_data(patterns_i)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=STEPS, eta_min=0.0001)
    best_sc = 0
    best_state = None
    for step in range(1, STEPS + 1):
        model.train()
        opt.zero_grad()
        loss_fn(model(X).view(-1, VS), Y.view(-1)).backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 200 == 0:
            rows = score(model, patterns_i)
            sc = sum((ok for *_, ok in rows))
            if sc > best_sc:
                best_sc = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'    donor {i + 1} step {step}: {sc}/8', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    np.savez(path, **{k: v.detach().numpy() for k, v in model.state_dict().items()})
    rows = score(model, patterns_i)
    sc = sum((ok for *_, ok in rows))
    all_scores.append(sc)
    print(f'\n  Donor {i + 1}/8  score={sc}/8')
    for name, pred, truth, ok in rows:
        print(f"    {('OK' if ok else '--')}  {name:<8} pred={pred:>2} truth={truth:>2}")
    print()
print('=' * 60)
groups = ['arith 1-8', 'arith 9-16', 'arith 17-24', 'countdown', 'fibonacci', 'geometric', 'polynomial', 'skip+offset']
for i, (sc, g) in enumerate(zip(all_scores, groups)):
    bar = '█' * sc + '░' * (8 - sc)
    print(f'  Donor {i + 1}  {bar}  {sc}/8  ({g})')
print(f'\n  Total: {sum(all_scores)}/64  ({sum(all_scores) / 64 * 100:.0f}%)')
print(f'  Time:  {time.time() - t0:.1f}s')
print('=' * 60)
