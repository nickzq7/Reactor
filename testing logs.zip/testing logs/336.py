import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import Counter
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (SENTINEL CONSENSUS)')
print('  Entropy-Aware Gates & Entity-Key Signatures.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
HAMMING_THRESHOLD = 15
CONSENSUS_QUORUM = 5
ENTROPY_THRESHOLD = 0.85
print('\n  [ Phase 1 ] Mapping W-Paths (FFN + Attention Keys)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a blue dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden']
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_ffn = {l: [] for l in range(n_layers)}
store_key = {l: [] for l in range(n_layers)}

def hook_ffn(l):

    def hook(m, i, o):
        store_ffn[l].append((o[:, -1, :] > 0).detach().cpu().numpy().astype(int))
    return hook

def hook_key(l):

    def hook(m, i, o):
        store_key[l].append((o[:, -1, :] > 0).detach().cpu().numpy().astype(int))
    return hook
hooks = []
for l in range(n_layers):
    hooks.append(model.transformer.h[l].mlp.act.register_forward_hook(hook_ffn(l)))
    hooks.append(model.transformer.h[l].attn.attention.k_proj.register_forward_hook(hook_key(l)))
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        prev_sig = [None] * n_layers
        for _ in range(35):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                f_bits, k_bits = (store_ffn[l].pop()[0], store_key[l].pop()[0])
                curr_sig = np.concatenate([f_bits, k_bits])
                if prev_sig[l] is not None:
                    RAM_chains[l].append(np.concatenate([prev_sig[l], curr_sig]))
                    RAM_sequences[l].append(next_id)
                prev_sig[l] = curr_sig
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    chains = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = [tuple(tokens[i:i + JUMP_LENGTH].tolist()) for i in range(len(tokens) - JUMP_LENGTH)]
    RAM_chains[l], RAM_sequences[l] = (chains[:len(seqs)], seqs)
print(f'  ✓ Saturated {len(RAM_sequences[0])} Sentinel Chains.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 60
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] THE RACE: BASELINE vs. SENTINEL HUB')
print('─' * 75)
print('  Calculating Baseline Truth...')
baseline_ids = tokenizer.encode(test_prompt, return_tensors='pt')
with torch.no_grad():
    for _ in range(tokens_to_gen):
        out = model(baseline_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        baseline_ids = torch.cat([baseline_ids, torch.tensor([[next_id]])], dim=1)
baseline_text = tokenizer.decode(baseline_ids[0])
print('  Executing Sentinel Engine...')
sig_history = {l: None for l in range(n_layers)}
live_ffn, live_key = ({l: None for l in range(n_layers)}, {l: None for l in range(n_layers)})

def get_ffn_hook(l):

    def hook(m, i, o):
        live_ffn[l] = (o[:, -1, :] > 0).detach().cpu().numpy().astype(int)[0]
    return hook

def get_key_hook(l):

    def hook(m, i, o):
        live_key[l] = (o[:, -1, :] > 0).detach().cpu().numpy().astype(int)[0]
    return hook
live_hooks = []
for l in range(n_layers):
    live_hooks.append(model.transformer.h[l].mlp.act.register_forward_hook(get_ffn_hook(l)))
    live_hooks.append(model.transformer.h[l].attn.attention.k_proj.register_forward_hook(get_key_hook(l)))
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen = 0
with torch.no_grad():
    while total_gen < tokens_to_gen:
        out = model(hub_ids)
        probs = torch.nn.functional.softmax(out.logits[0, -1, :], dim=-1)
        conf, truth_id = torch.max(probs, dim=-1)
        truth_id = truth_id.item()
        confidence = conf.item()
        jump_found = False
        if confidence >= ENTROPY_THRESHOLD:
            votes = []
            if all((v is not None for v in sig_history.values())):
                for l in range(n_layers):
                    curr_sig = np.concatenate([live_ffn[l], live_key[l]])
                    current_chain = np.concatenate([sig_history[l], curr_sig])
                    mismatches = len(current_chain) - np.sum(RAM_chains[l] == current_chain, axis=1)
                    best_idx = np.argmin(mismatches)
                    if mismatches[best_idx] <= HAMMING_THRESHOLD:
                        votes.append(RAM_sequences[l][best_idx])
            if votes:
                vote_counts = Counter(votes)
                top_sequence, count = vote_counts.most_common(1)[0]
                if count >= CONSENSUS_QUORUM and top_sequence[0] == truth_id:
                    jump_text = tokenizer.decode(list(top_sequence))
                    print(f"  [✓ JUMP ({count} Layers | Conf {confidence:.2f})]: '{jump_text.strip()}'")
                    hub_ids = torch.cat([hub_ids, torch.tensor([list(top_sequence)])], dim=1)
                    for layer in range(n_layers):
                        sig_history[layer] = None
                    total_gen += JUMP_LENGTH
                    jump_found = True
        else:
            pass
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            for l in range(n_layers):
                sig_history[l] = np.concatenate([live_ffn[l], live_key[l]])
            total_gen += 1
for h in live_hooks:
    h.remove()
hub_text = tokenizer.decode(hub_ids[0])
print('\n' + '=' * 75)
print('  SENTINEL ENGINE VERDICT')
print('=' * 75)
print(f'\n[ NORMAL MODEL ]:\n{baseline_text}')
print(f'\n[ SENTINEL HUB ]:\n{hub_text}')
match_score = sum((1 for a, b in zip(baseline_text.split(), hub_text.split()) if a == b))
print(f'\n  Final Result: {match_score} words matched baseline.')
print("  The Sentinel Engine identifies 'High Entropy' moments where")
print('  entities are decided and refuses to jump, preventing drift.')
print('=' * 75 + '\n')
