import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_STORIES = 100
MAX_SEQ = 32
MAX_PAIRS = 8000
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('\n' + '=' * 65)
print('  LOAD')
print('=' * 65)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD = H // NH
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
with torch.no_grad():
    Wte = teacher.transformer.wte.weight.detach().float().cpu().numpy()
    Wpe = teacher.transformer.wpe.weight.detach().float().cpu().numpy()
print(f'  NL={NL} H={H} NH={NH} HD={HD}')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
stories = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 200:
        stories.append(t)
    if len(stories) >= N_STORIES:
        break
print(f'  Loaded {len(stories)} stories')
print('\n' + '=' * 65)
print('  COLLECT ATTENTION DATA')
print('  Hooking: Q, K, V, scores, weights, ctx, att_out')
print('  Layer 0 (all heads), then aggregate')
print('=' * 65)
sentences_data = []
hooks = []
current = {}

def hook_pre0(mod, inp):
    x = inp[0] if isinstance(inp, (tuple, list)) else inp
    current['h0'] = x.detach().float().cpu().numpy()[0]

def hook_q(mod, inp, out):
    current['Q'] = out.detach().float().cpu().numpy()[0]

def hook_k(mod, inp, out):
    current['K'] = out.detach().float().cpu().numpy()[0]

def hook_v(mod, inp, out):
    current['V'] = out.detach().float().cpu().numpy()[0]

def hook_attn(mod, inp, out):
    current['att_out'] = out[0].detach().float().cpu().numpy()[0]
bl0 = teacher.transformer.h[0]
at0 = bl0.attn.attention
hooks.append(bl0.register_forward_pre_hook(hook_pre0))
hooks.append(at0.q_proj.register_forward_hook(hook_q))
hooks.append(at0.k_proj.register_forward_hook(hook_k))
hooks.append(at0.v_proj.register_forward_hook(hook_v))
hooks.append(bl0.attn.register_forward_hook(hook_attn))
t0 = time.perf_counter()
n_pairs = 0
with torch.no_grad():
    for si, sent in enumerate(stories):
        current.clear()
        ids = tok(sent, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'].to(device)
        sl = ids.shape[1]
        if sl < 3:
            continue
        teacher(ids)
        if 'h0' not in current:
            continue
        h0 = current['h0']
        Q = current['Q']
        K = current['K']
        V = current['V']
        att_out = current['att_out']
        scale = 1.0
        scores_all = np.zeros((sl, sl), np.float32)
        weights_all = np.zeros((sl, sl), np.float32)
        for hh in range(NH):
            s, e = (hh * HD, hh * HD + HD)
            Q_h = Q[:, s:e]
            K_h = K[:, s:e]
            sc = (Q_h @ K_h.T).astype(np.float32)
            mask = np.full((sl, sl), -1000000000.0, np.float32)
            for i in range(sl):
                start = max(0, i - WIN + 1) if ATT[0] == 'local' else 0
                mask[i, start:i + 1] = 0.0
            sc += mask
            sc -= sc.max(-1, keepdims=True)
            e_sc = np.exp(sc)
            w_sc = e_sc / e_sc.sum(-1, keepdims=True)
            scores_all += sc / NH
            weights_all += w_sc / NH
        sentences_data.append({'h0': h0, 'Q': Q, 'K': K, 'V': V, 'scores': scores_all, 'weights': weights_all, 'att_out': att_out, 'sl': sl})
        n_pairs += sl * (sl + 1) // 2
for hk in hooks:
    hk.remove()
print(f'  Collected {len(sentences_data)} sentences  ~{n_pairs} pairs  in {time.perf_counter() - t0:.1f}s')
print('\n' + '=' * 65)
print('  BUILD PAIR FEATURES')
print(f'  Outer product dim: H×H = {H * H}')
print('=' * 65)
outer_list = []
h_i_list = []
h_j_list = []
score_list = []
weight_list = []
att_row_outer = []
att_out_list = []
h0_i_for_att = []
rng = np.random.RandomState(42)
for sd in sentences_data:
    h0 = sd['h0']
    sl = sd['sl']
    sc = sd['scores']
    wt = sd['weights']
    ao = sd['att_out']
    for i in range(sl):
        for j in range(i + 1):
            outer = np.outer(h0[i], h0[j]).ravel().astype(np.float32)
            outer_list.append(outer)
            h_i_list.append(h0[i])
            h_j_list.append(h0[j])
            score_list.append(sc[i, j])
            weight_list.append(wt[i, j])
        row_feat = np.zeros(H * H, np.float32)
        for j in range(i + 1):
            row_feat += wt[i, j] * np.outer(h0[i], h0[j]).ravel().astype(np.float32)
        att_row_outer.append(row_feat)
        att_out_list.append(ao[i])
        h0_i_for_att.append(h0[i])
    if len(outer_list) >= MAX_PAIRS:
        break
outer_arr = np.array(outer_list[:MAX_PAIRS], np.float32)
h_i_arr = np.array(h_i_list[:MAX_PAIRS], np.float32)
h_j_arr = np.array(h_j_list[:MAX_PAIRS], np.float32)
score_arr = np.array(score_list[:MAX_PAIRS], np.float32).reshape(-1, 1)
weight_arr = np.array(weight_list[:MAX_PAIRS], np.float32).reshape(-1, 1)
att_outer = np.array(att_row_outer[:MAX_PAIRS], np.float32)
att_out_arr = np.array(att_out_list[:MAX_PAIRS], np.float32)
h0_att_arr = np.array(h0_i_for_att[:MAX_PAIRS], np.float32)
N = len(outer_arr)
print(f'  Pairs collected: {N}')
print(f'  outer_arr shape: {outer_arr.shape}  (H×H={H * H} features per pair)')

def r2_solve(X, Y, name=''):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.concatenate([X64, np.ones((len(X64), 1))], 1)
    W, _, _, _ = lstsq(Xb, Y64, rcond=None)
    pred = X64 @ W[:-1] + W[-1]
    ss_r = float(((Y64 - pred) ** 2).sum())
    ss_t = float(((Y64 - Y64.mean(0)) ** 2).sum())
    r2 = float(1 - ss_r / (ss_t + 1e-12))
    return (r2, W[:-1].T.astype(np.float32), W[-1].astype(np.float32))
print('\n' + '=' * 65)
print('  EXP 1: scores[i,j] — IS IT LINEAR IN OUTER PRODUCT?')
print('  LAW 47 CORE TEST')
print('=' * 65)
print(f"\n  {'Features':<45} {'R²':>12}  notes")
print(f"  {'-' * 65}")
r2, _, _ = r2_solve(h_i_arr, score_arr, 'h_i')
print(f"  {'h_0[i] alone':<45} {r2:12.8f}  query token only")
r2, _, _ = r2_solve(h_j_arr, score_arr, 'h_j')
print(f"  {'h_0[j] alone':<45} {r2:12.8f}  key token only")
feat = np.concatenate([h_i_arr, h_j_arr], -1)
r2, _, _ = r2_solve(feat, score_arr, 'h_i+h_j')
print(f"  {'(h_0[i], h_0[j])':<45} {r2:12.8f}  no interaction term")
print(f'\n  --- LAW 47 CORE ---')
r2_outer, _, _ = r2_solve(outer_arr, score_arr, 'outer')
print(f"  {'h_0[i] ⊗ h_0[j]  (outer product)':<45} {r2_outer:12.8f}  ← LAW 47")
feat = np.concatenate([outer_arr, h_i_arr, h_j_arr], -1)
r2, _, _ = r2_solve(feat, score_arr, 'outer+h')
print(f"  {'h_0[i]⊗h_0[j] + h_0[i] + h_0[j]':<45} {r2:12.8f}  outer + linear")
feat = np.concatenate([outer_arr, h_i_arr ** 2, h_j_arr ** 2], -1)
r2, _, _ = r2_solve(feat, score_arr, 'outer+sq')
print(f"  {'h_0[i]⊗h_0[j] + h_0[i]² + h_0[j]²':<45} {r2:12.8f}  outer + GeLU space")
print('\n' + '=' * 65)
print('  EXP 2: weights[i,j] = softmax(scores)[i,j]')
print('  Can we predict attention weights from h_0?')
print('=' * 65)
print(f"\n  {'Features':<45} {'R²':>12}")
print(f"  {'-' * 60}")
r2, _, _ = r2_solve(outer_arr, weight_arr, 'outer_w')
print(f"  {'h_0[i] ⊗ h_0[j]':<45} {r2:12.8f}")
feat = np.concatenate([outer_arr, h_i_arr, h_j_arr], -1)
r2, _, _ = r2_solve(feat, weight_arr, 'outer+h_w')
print(f"  {'outer + h_0[i] + h_0[j]':<45} {r2:12.8f}")
outer_exp = np.exp(np.clip(outer_arr * 0.01, -10, 10))
feat = np.concatenate([outer_arr, outer_exp], -1)
r2, _, _ = r2_solve(feat, weight_arr, 'outer+exp')
print(f"  {'outer + exp(outer)':<45} {r2:12.8f}  softmax natural space")
print('\n' + '=' * 65)
print('  EXP 3: att_out[i] — attention OUTPUT from h_0 features')
print('  This is the 12% context component directly')
print('=' * 65)
print(f"\n  {'Features':<45} {'R²':>12}  notes")
print(f"  {'-' * 65}")
r2, _, _ = r2_solve(h0_att_arr, att_out_arr, 'h0i_att')
print(f"  {'h_0[i] alone':<45} {r2:12.8f}  self only")
feat = np.concatenate([h0_att_arr, h0_att_arr ** 2], -1)
r2, _, _ = r2_solve(feat, att_out_arr, 'h0i_sq_att')
print(f"  {'(h_0[i], h_0[i]²)':<45} {r2:12.8f}  GeLU natural space")
r2_wout, _, _ = r2_solve(att_outer, att_out_arr, 'wout_att')
print(f"  {'Σ_j w[i,j]·(h_0[i]⊗h_0[j])':<45} {r2_wout:12.8f}  ← weighted outer")
feat = np.concatenate([att_outer, h0_att_arr, h0_att_arr ** 2], -1)
r2_full, _, _ = r2_solve(feat, att_out_arr, 'full_att')
print(f"  {'weighted_outer + h_0[i] + h_0[i]²':<45} {r2_full:12.8f}  full natural space")
print('\n' + '=' * 65)
print('  EXP 4: LAYER-BY-LAYER — outer product R² at each layer')
print('  Does Law 47 generalize across all 8 layers?')
print('=' * 65)
layer_data = {}
hooks2 = []

def make_pre(li):

    def fn(mod, inp):
        x = inp[0] if isinstance(inp, (tuple, list)) else inp
        layer_data[li] = {'h': x.detach().float().cpu().numpy()[0]}
    return fn

def make_attn(li):

    def fn(mod, inp, out):
        layer_data[li]['att_out'] = out[0].detach().float().cpu().numpy()[0]
    return fn
for li in range(NL):
    hooks2.append(teacher.transformer.h[li].register_forward_pre_hook(make_pre(li)))
    hooks2.append(teacher.transformer.h[li].attn.register_forward_hook(make_attn(li)))
sent = stories[0]
ids = tok(sent, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'].to(device)
with torch.no_grad():
    teacher(ids)
for hk in hooks2:
    hk.remove()
sl = ids.shape[1]
print(f'\n  Sentence: "{sent[:50]}"  ({sl} tokens)')
print(f"\n  {'Layer':<8} {'h_k[i]⊗h_k[j]→score R²':>25}  {'h_0[i]⊗h_0[j]→att_out R²':>27}  notes")
print(f"  {'-' * 70}")
h0_sent = layer_data[0]['h']
for li in range(NL):
    h_k = layer_data[li]['h']
    att_out = layer_data[li]['att_out']
    outers, scores_l, att_rows = ([], [], [])
    h0_rows = []
    with torch.no_grad():
        bl = teacher.transformer.h[li]
        at = bl.attn.attention
        ln1_t = bl.ln_1(torch.tensor(h_k[np.newaxis]).to(device))
        Q_t = at.q_proj(ln1_t)[0].float().cpu().numpy()
        K_t = at.k_proj(ln1_t)[0].float().cpu().numpy()
    for i in range(sl):
        for j in range(i + 1):
            outers.append(np.outer(h_k[i], h_k[j]).ravel())
            scores_l.append(float(Q_t[i] @ K_t[j]))
        row = np.zeros(H * H, np.float32)
        sc_row = np.array([Q_t[i] @ K_t[j] for j in range(i + 1)], np.float32)
        mk = np.full(i + 1, -1000000000.0, np.float32)
        mk[:] = sc_row
        mk -= mk.max()
        ew = np.exp(mk)
        ew /= ew.sum()
        for j in range(i + 1):
            row += ew[j] * np.outer(h0_sent[i], h0_sent[j]).ravel().astype(np.float32)
        att_rows.append(row)
        h0_rows.append(h0_sent[i])
    outers_np = np.array(outers, np.float32)
    scores_np = np.array(scores_l, np.float32).reshape(-1, 1)
    att_rows_np = np.array(att_rows, np.float32)
    att_out_np = att_out
    r2_sc, _, _ = r2_solve(outers_np, scores_np, f'L{li}_score')
    r2_at, _, _ = r2_solve(att_rows_np, att_out_np, f'L{li}_att')
    bar_sc = '█' * int(r2_sc * 20) + '░' * (20 - int(r2_sc * 20))
    bar_at = '█' * int(r2_at * 20) + '░' * (20 - int(r2_at * 20))
    note = '✓' if r2_sc > 0.9999 and r2_at > 0.9999 else '~' if r2_sc > 0.99 else ''
    print(f'  Layer {li:<3}  {r2_sc:8.6f} {bar_sc}  {r2_at:8.6f} {bar_at}  {note}')
print('\n' + '=' * 65)
print('  LAW 47 SUMMARY')
print('=' * 65)
print(f'\n  SCORES (bilinear form test):\n    h_0[i] ⊗ h_0[j] → scores[i,j]:  R²={r2_outer:.6f}\n    \n    If R²=1.0: scores are pure bilinear form of inputs.\n               Law 47 proven for attention scores.\n               No computation needed — tensor product suffices.\n\n  ATT_OUT (context component test):\n    weighted outer → att_out[i]:     R²={r2_wout:.6f}\n    + h_0[i] + h_0[i]²:             R²={r2_full:.6f}\n    \n    If R²=1.0: att_out is linear in weighted outer products.\n               The 12% context component = pre-existing.\n               The entire transformer = tensor algebra.\n\n  INTERPRETATION:\n')
if r2_outer > 0.9999:
    print('  ✓ LAW 47 PROVEN: scores[i,j] = (h_0[i]⊗h_0[j]) @ W')
    print('  ✓ Attention is a bilinear form over input embeddings.')
    print('  ✓ The context component is pre-existing in tensor products.')
elif r2_outer > 0.95:
    print('  ~ STRONG: R²>0.95. Outer product captures most of scores.')
    print('  ~ The natural space is close. Missing terms:')
    print('  ~ Try: (h_0[i]⊗h_0[j], h_0[i]⊗h_0[j]², ...) higher order.')
elif r2_outer > 0.8:
    print('  ~ PARTIAL: R²>0.8. Bilinear form is the right direction.')
    print('  ~ The full natural space needs additional terms.')
    print('  ~ Law 47 holds approximately. Exact form not yet found.')
else:
    print('  ~ R² below 0.8. Context component has genuinely new structure.')
    print('  ~ The natural space may require: h_k[i]⊗h_k[j] not h_0[i]⊗h_0[j]')
    print('  ~ i.e. the bilinear form acts on PROCESSED embeddings, not raw.')
print(f"\n  COMPLETING THE W PRINCIPLE:\n    Layer self-path (78%):   h_0 → linear → logits\n    GeLU natural space (+6%): (h_0,h_0²) → linear → logits\n    Cross-token (12%):        h_0[i]⊗h_0[j] → linear → logits?\n\n    R²_outer = {r2_outer:.6f}\n    \n    {('→ 100% pre-existing. The transformer does not compute.' if r2_outer > 0.9999 else '→ Natural space found partially. Higher-order terms needed.' if r2_outer > 0.95 else '→ Direction confirmed. Exact natural space needs refinement.')}\n\n  LAW 47 (candidate):\n    scores[i,j] = (h_0[i] ⊗ h_0[j]) @ W_47   R²={r2_outer:.6f}\n    \n    Natural space of cross-token interaction =\n    tensor product of input embeddings.\n")
