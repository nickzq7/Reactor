import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL v2 — NATURAL SPACE OF COMPOSED OPERATIONS')
print('  Finding the natural space of the full model.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
cfg = model.config
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
VOCAB = model.config.vocab_size

def r2(A, Y):
    A = np.array(A, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    Ab = np.hstack([A, np.ones((len(A), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, Y, rcond=None)
    Yp = Ab @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0

def fmt(v):
    if v > 0.9999:
        return f'{v:.6f} ✓ EXACT'
    if v > 0.999:
        return f'{v:.6f} ~'
    if v > 0.99:
        return f'{v:.6f} !'
    if v > 0.95:
        return f'{v:.6f}'
    return f'{v:.6f} ✗'
PROMPTS = ['Once upon a time a little girl named Lily', 'Deep in the forest there lived a dragon', 'A small dog ran across the green field', 'The brave knight rode into the dark cave', 'She opened the door and smiled at her friend', 'Every morning the birds sang in the tall tree', 'He found a golden key under the old bridge', 'The children played and laughed in the garden', 'Far away there lived a kind old wizard', 'A tiny mouse found some cheese in the barn', 'The princess wore a crown and sat on the throne', 'A rainbow appeared in the sky after the rain', 'The farmer planted seeds in the rich dark soil', 'She read a book about dragons and magic spells', 'The river flowed gently through the green valley', 'A butterfly landed softly on the red flower', 'The ship sailed across the deep blue ocean', 'The moon rose high above the sleeping town', 'A bear found honey in a hollow tree trunk', 'The wind carried the leaves high into the air', 'Once there was a boy who loved to explore', 'The cat sat by the warm fire and purred', 'He climbed the tall mountain and saw the sky', 'She sang a song that made everyone smile', 'A fox ran through the forest looking for food', 'The old man told stories to the young children', 'A baby bird fell from its nest in the oak', 'The cook made a soup that smelled wonderful', 'He drew a picture of his house and garden', 'The queen walked through the market with grace', 'Once a young prince found a magic mirror', 'The stars shone bright above the sleeping child', 'A little fish swam in the clear blue pond', 'The baker made fresh bread every single morning', 'She found a map that led to buried treasure']
SEQ_LEN = 16
N_STEPS = 25
print(f'\n  Collecting hidden states across all layers...')
H_all = []
EMBED_all = []
FINAL_all = []
LOGIT_all = []
TOKEN_all = []
all_ids = []
with torch.no_grad():
    for prompt in PROMPTS:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        all_ids.append(ids[:])
        for _ in range(N_STEPS):
            out = model(torch.tensor([ids]))
            nxt = torch.argmax(out.logits[0, -1, :]).item()
            ids.append(nxt)
            all_ids.append(ids[-SEQ_LEN:])
print(f'  Total sequences: {len(all_ids)}')
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()
with torch.no_grad():
    for ids in all_ids:
        t_ids = torch.tensor([ids])
        outs = model(t_ids, output_hidden_states=True)
        hs = [h.squeeze(0)[-1].numpy() for h in outs.hidden_states]
        H_all.append(hs)
        EMBED_all.append(hs[0])
        FINAL_all.append(hs[-1])
        logits = outs.logits.squeeze(0)[-1].numpy()
        LOGIT_all.append(logits)
        TOKEN_all.append(int(np.argmax(logits)))
H_all = np.array(H_all, dtype=np.float64)
EMBED = np.array(EMBED_all, dtype=np.float64)
FINAL = np.array(FINAL_all, dtype=np.float64)
LOGITS = np.array(LOGIT_all, dtype=np.float64)
N = len(H_all)
print(f'  N={N} samples\n')
print(f"{'=' * 70}")
print(f'  TEST 1: DELTA SPACE')
print(f'  delta[i] = h[i+1] - h[i]')
print(f'  Is delta[i] linear in h[i]?')
print(f'  Is delta[i] linear in (h[i], h[i]²)?')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'h→delta':>12} {'(h,h²)→delta':>14} {'meaning'}")
print(f"  {'─' * 48}")
for li in range(n_layers):
    H_in = H_all[:, li, :]
    H_out = H_all[:, li + 1, :]
    delta = H_out - H_in
    r2_linear = r2(H_in, delta)
    r2_para = r2(np.hstack([H_in, H_in ** 2]), delta)
    m = '✓ linear' if r2_linear > 0.999 else '✓ parabolic' if r2_para > 0.999 else 'deeper space needed'
    print(f'  L{li:<7} {fmt(r2_linear):>12} {fmt(r2_para):>14}  {m}')
print(f"\n{'=' * 70}")
print(f'  TEST 2: TRAJECTORY SPACE')
print(f'  Is h[final] linear in h[0] (embedding)?')
print(f'  Is h[i] predictable from h[0]?')
print(f"{'=' * 70}\n")
print(f"  {'Source':<20} {'Target':<20} {'R²':>12}")
print(f"  {'─' * 54}")
for li in range(1, n_layers + 1):
    H_target = H_all[:, li, :]
    score = r2(EMBED, H_target)
    label = f'h[0] → h[{li}]'
    print(f"  {label:<20} {'':20} {fmt(score):>12}")
score_ef = r2(EMBED, FINAL)
print(f"  {'h[0] → h_final':<20} {'':20} {fmt(score_ef):>12}")
score_ef2 = r2(np.hstack([EMBED, EMBED ** 2]), FINAL)
print(f"  {'(h[0],h[0]²)→h_final':<20} {'':20} {fmt(score_ef2):>12}")
score_el = r2(EMBED, LOGITS)
print(f"  {'h[0] → logits':<20} {'':20} {fmt(score_el):>12}")
print(f"\n{'=' * 70}")
print(f'  TEST 3: ATTENTION CORRECT NATURAL SPACE')
print(f'  att_out[last] depends on ALL tokens.')
print(f'  Correct input = ALL hidden states of sequence.')
print(f'  Flatten full sequence h[0:T] → att_out[last]')
print(f"{'=' * 70}\n")
SEQ_FIXED = 8
att_seq_inputs = []
att_seq_outputs = []

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
blk0 = model.transformer.h[0]
att0 = blk0.attn.attention
Wq0 = att0.q_proj.weight.detach().numpy()
Wk0 = att0.k_proj.weight.detach().numpy()
Wv0 = att0.v_proj.weight.detach().numpy()
Wo0 = att0.out_proj.weight.detach().numpy()
bo0 = att0.out_proj.bias.detach().numpy()
ln1_w0 = blk0.ln_1.weight.detach().numpy()
ln1_b0 = blk0.ln_1.bias.detach().numpy()
with torch.no_grad():
    for ids in all_ids[:200]:
        ids_use = ids[:SEQ_FIXED]
        T = SEQ_FIXED
        x = (wte[ids_use] + wpe[np.arange(T)]).astype(np.float64)
        ln1 = np.array([ln_np(x[i:i + 1], ln1_w0, ln1_b0)[0] for i in range(T)])
        Q = ln1 @ Wq0.T
        K = ln1 @ Wk0.T
        V = ln1 @ Wv0.T
        Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads, 1).reshape(T, D)
        att_out_last = (context @ Wo0.T + bo0)[-1]
        att_seq_inputs.append(ln1.flatten())
        att_seq_outputs.append(att_out_last)
ATT_SEQ_IN = np.array(att_seq_inputs, dtype=np.float64)
ATT_SEQ_OUT = np.array(att_seq_outputs, dtype=np.float64)
N2, dim2 = ATT_SEQ_IN.shape
print(f'  N={N2}, input_dim={dim2} (T×D = {SEQ_FIXED}×{D})')
print(f"  {'ln1_seq → att_out':<35} ", end='')
if N2 > dim2 * 2:
    score_att_full = r2(ATT_SEQ_IN, ATT_SEQ_OUT)
    print(f'R²={fmt(score_att_full)}')
else:
    print(f'N={N2} < 2×dim={dim2 * 2} → unreliable. Need more data.')
    score_att_full = r2(ATT_SEQ_IN, ATT_SEQ_OUT)
    print(f'  (unreliable) R²={fmt(score_att_full)}')
att_context_inputs = []
att_context_outputs = []
with torch.no_grad():
    for ids in all_ids[:500]:
        T = len(ids)
        x = (wte[ids] + wpe[np.arange(T)]).astype(np.float64)
        ln1 = np.array([ln_np(x[i:i + 1], ln1_w0, ln1_b0)[0] for i in range(T)])
        Q = ln1 @ Wq0.T
        K = ln1 @ Wk0.T
        V = ln1 @ Wv0.T
        Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads, 1).reshape(T, D)
        att_out = context @ Wo0.T + bo0
        att_context_inputs.append(context[-1])
        att_context_outputs.append(att_out[-1])
CTX_IN = np.array(att_context_inputs, dtype=np.float64)
CTX_OUT = np.array(att_context_outputs, dtype=np.float64)
score_ctx = r2(CTX_IN, CTX_OUT)
print(f'\n  context[-1] → att_out[-1]: R²={fmt(score_ctx)}  (should be 1.000 — trivial)')
print(f"\n{'=' * 70}")
print(f'  TEST 4: LAYER-PAIR NATURAL SPACE')
print(f'  Consecutive layers: (h[i], h[i+1]) → h[i+2]')
print(f'  Does knowing two states predict the third?')
print(f"{'=' * 70}\n")
print(f"  {'Input':<25} {'Target':<12} {'R²':>12}")
print(f"  {'─' * 50}")
for li in range(n_layers - 1):
    H_i = H_all[:, li, :]
    H_i1 = H_all[:, li + 1, :]
    H_i2 = H_all[:, li + 2, :]
    joint = np.hstack([H_i, H_i1])
    score = r2(joint, H_i2)
    print(f"  (h[{li}], h[{li + 1}]) → h[{li + 2}]      {'':8} {fmt(score):>12}")
print(f"\n{'=' * 70}")
print(f'  TEST 5: WHAT IS THE NATURAL SPACE?')
print(f'  Try different representations of h as input.')
print(f"  Target: predict NEXT layer's h.")
print(f"{'=' * 70}\n")
li = 0
H_in = H_all[:, li, :]
H_out = H_all[:, li + 1, :]
candidates = [('h[i]', H_in), ('(h[i], h[i]²)', np.hstack([H_in, H_in ** 2])), ('(h[i], |h[i]|)', np.hstack([H_in, np.abs(H_in)])), ('(h[i], h[i]², |h[i]|)', np.hstack([H_in, H_in ** 2, np.abs(H_in)])), ('norm(h[i])*direction', H_in / (np.linalg.norm(H_in, axis=1, keepdims=True) + 1e-08)), ('h[i]/||h[i]||', H_in / (np.linalg.norm(H_in, axis=1, keepdims=True) + 1e-08)), ('tanh(h[i])', np.tanh(H_in)), ('exp(h[i]/scale)', np.exp(np.clip(H_in / H_in.std(), -5, 5))), ('sign(h[i])*sqrt(|h[i]|)', np.sign(H_in) * np.sqrt(np.abs(H_in)))]
print(f"  {'Space':<35} {'R²':>12}")
print(f"  {'─' * 50}")
for name, A in candidates:
    score = r2(A, H_out)
    print(f'  {name:<35} {fmt(score):>12}')
print(f"\n{'=' * 70}")
print(f'  CONCLUSION — WHAT IS THE NATURAL SPACE OF THE FULL MODEL?')
print(f"{'=' * 70}\n")
print(f'\n  FINDINGS:\n\n  1. delta[i] = h[i+1] - h[i]:\n     Is delta linear in h[i]?\n     Result above tells us.\n\n  2. Trajectory h[0] → h[final]:\n     How much of final state is predictable from embedding?\n     R² tells us: how much information is in initial embedding\n     vs how much is created by attention (sequence mixing).\n\n  3. Attention correct space:\n     full sequence ln1 → att_out = R²?\n     This is the CORRECT measurement (all context as input).\n\n  4. Layer-pair:\n     (h[i], h[i+1]) → h[i+2] = Markov chain test.\n     Does the residual stream have Markov property?\n\n  MANISH PRINCIPLE AT MODEL LEVEL:\n    If delta[i] = linear in h[i]:\n      Natural space of composition = h itself.\n      Residual stream = linear dynamical system.\n      Each step = linear map in h space.\n      \n    If h[0] → h[final] = low R²:\n      Attention creates NEW information not in embedding.\n      That information = sequence-dependent = irreducible.\n      Natural space of attention = the sequence itself.\n      \n    W PRINCIPLE HOLDS AT EVERY LEVEL:\n      Operation level: each op = linear in its space. ✓\n      Layer level: composition = linear in delta space? TBD.\n      Model level: embedding → final = linear in what space? TBD.\n')
print('=' * 70 + '\n')
