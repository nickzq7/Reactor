import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — FINAL GAP CLOSURE')
print('  FFN: 0.2% remaining. ATT: 3% unknown rule.')
print('  Find both. Close both.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
CTX = 8
layer_idx = 0
block = model.transformer.h[layer_idx]
attn_mod = block.attn.attention
Wq = attn_mod.q_proj.weight.detach().numpy().T
Wk = attn_mod.k_proj.weight.detach().numpy().T
Wv = attn_mod.v_proj.weight.detach().numpy().T

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ CLOSED' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<54} {mark}')
    return score

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came', 'The dog ran fast', 'The children went to', 'It was a sunny', 'Deep in the woods', 'Every morning the bird', 'The brave knight rode', 'She found a lost', 'The baby bear found', 'A tiny seed grew', 'The two friends walked', 'A rainbow appeared', 'The kind queen shared', 'A yellow duck learned', 'The snow fell softly', 'He wished upon a', 'The cat chased the', 'The children found a', 'She drew a picture', 'The moon shone bright', 'A boy climbed the', 'He discovered a door', 'Three little bears came', 'The frog jumped across', 'A butterfly emerged', 'An owl sat watching', 'The kitten played with', 'A girl named Emma', 'The farmer woke up', 'A genie appeared to', 'The turtle and rabbit']
print(f'  Generating from {len(starts)} prompts...')
all_texts = []
with torch.no_grad():
    for i, start in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(start, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=50, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} texts. Collecting...')
X_list = []
A_list = []
F_list = []
GACT_list = []
QKV_list = []
CAUSUM_list = []
ATT_OUTER_list = []
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            x_t = hs[layer_idx][0, start:start + CTX]
            x_np = x_t.numpy()
            ln1 = block.ln_1(x_t).detach().numpy()
            att_out = block.attn(block.ln_1(x_t).unsqueeze(0))[0].squeeze(0).detach().numpy()
            x2 = x_t + torch.tensor(att_out, dtype=torch.float32)
            ln2 = block.ln_2(x2).detach().numpy()
            pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).detach().numpy()
            act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).detach().numpy()
            ffn = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).detach().numpy()
            gelu_act = act * (pre > 0).astype(float)
            Q = ln1 @ Wq
            K = ln1 @ Wk
            V = ln1 @ Wv
            scr = Q @ K.T / np.sqrt(D)
            msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
            att_w = softmax(scr + msk)
            outer = np.einsum('ts,sd->tsd', att_w, V)
            causal_sum = att_w @ V
            X_list.append(x_np.flatten())
            A_list.append(att_out.flatten())
            F_list.append(ffn.flatten())
            GACT_list.append(gelu_act.flatten())
            QKV_list.append(np.concatenate([Q.flatten(), K.flatten(), V.flatten()]))
            CAUSUM_list.append(causal_sum.flatten())
            ATT_OUTER_list.append(outer.flatten())
N = len(X_list)
N_tr = int(N * 0.8)
X_arr = np.array(X_list)
A_arr = np.array(A_list)
F_arr = np.array(F_list)
GACT_arr = np.array(GACT_list)
QKV_arr = np.array(QKV_list)
CAUS_arr = np.array(CAUSUM_list)
OUT_arr = np.array(ATT_OUTER_list)
print(f'  Samples: {N}  Train: {N_tr}')
print('\n' + '─' * 62)
print('  FFN GAP — find remaining 0.2%')
print('  gelu_activated gave 0.9977. Close completely.')
print('─' * 62)
print()
test(X_arr[:N_tr], F_arr[:N_tr], X_arr[N_tr:], F_arr[N_tr:], 'x → ffn  [baseline 0.9828]')
test(np.column_stack([X_arr, GACT_arr])[:N_tr], F_arr[:N_tr], np.column_stack([X_arr, GACT_arr])[N_tr:], F_arr[N_tr:], 'x + gelu_activated → ffn  [was 0.9977]')
test(GACT_arr[:N_tr], F_arr[:N_tr], GACT_arr[N_tr:], F_arr[N_tr:], 'gelu_activated alone → ffn')
pre_arr = np.array([block.mlp.c_fc(torch.tensor(block.ln_2(hs[layer_idx][0, :CTX] + torch.tensor(A_arr[i].reshape(CTX, D))).detach())).detach().numpy().flatten() for i in range(N)])
test(np.column_stack([GACT_arr, GACT_arr ** 2])[:N_tr], F_arr[:N_tr], np.column_stack([GACT_arr, GACT_arr ** 2])[N_tr:], F_arr[N_tr:], 'gelu_act + gelu_act² → ffn')
test(np.column_stack([X_arr, GACT_arr, GACT_arr ** 2])[:N_tr], F_arr[:N_tr], np.column_stack([X_arr, GACT_arr, GACT_arr ** 2])[N_tr:], F_arr[N_tr:], 'x + gelu_act + gelu_act² → ffn')
print('\n' + '─' * 62)
print('  ATT GAP — find the 3% rule')
print('  softmax(QK) failed. Test real att components.')
print('─' * 62)
print()
test(X_arr[:N_tr], A_arr[:N_tr], X_arr[N_tr:], A_arr[N_tr:], 'x → att  [baseline 0.9696]')
test(QKV_arr[:N_tr], A_arr[:N_tr], QKV_arr[N_tr:], A_arr[N_tr:], 'Q+K+V → att')
test(np.column_stack([X_arr, QKV_arr])[:N_tr], A_arr[:N_tr], np.column_stack([X_arr, QKV_arr])[N_tr:], A_arr[N_tr:], 'x + Q+K+V → att')
test(CAUS_arr[:N_tr], A_arr[:N_tr], CAUS_arr[N_tr:], A_arr[N_tr:], 'att_w @ V → att  [causal weighted sum]')
test(np.column_stack([X_arr, CAUS_arr])[:N_tr], A_arr[:N_tr], np.column_stack([X_arr, CAUS_arr])[N_tr:], A_arr[N_tr:], 'x + (att_w@V) → att')
test(OUT_arr[:N_tr], A_arr[:N_tr], OUT_arr[N_tr:], A_arr[N_tr:], 'att_w[t,s]*V[s,d] outer → att')
test(np.column_stack([X_arr, OUT_arr])[:N_tr], A_arr[:N_tr], np.column_stack([X_arr, OUT_arr])[N_tr:], A_arr[N_tr:], 'x + outer → att')
print('\n' + '=' * 62)
print('  WHAT THE NUMBERS SHOW')
print('=' * 62)
print('\n  FFN gap (0.2% remaining):\n    gelu_activated almost closes it.\n    gelu_act² may close the last 0.2%.\n    The remaining gap = second-order gelu effect.\n    gelu has slight curvature above zero.\n    That curvature = gelu_act².\n\n  ATT gap (3% unknown):\n    If causal_sum (att_w@V) closes it → \n      att output is linear in att_w@V.\n      The rule = provide the mixing directly.\n      That mixing is the causal structure.\n\n    If outer product closes it →\n      att_w[t,s]*V[s,d] is the natural space.\n      Same rule as confirmed on synthetic.\n      Real model confirms same law.\n\n    If neither → \n      Out projection (Wo) applies after mixing.\n      That linear step = remaining gap.\n      Provide (att_w@V)@Wo as feature.\n\n  Every gap has a law.\n  Numbers will show which one.\n')
print('=' * 62 + '\n')
