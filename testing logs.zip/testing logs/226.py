import numpy as np
import torch
import struct
import math
from collections import Counter
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — BYTE ANALYSIS ENGINE')
print('  Deepest level: does W law live in the bytes?')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_hidden_layers
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={n_layers}')
print(f'\n  Extracting all weight matrices...')
matrices = {}
with torch.no_grad():
    for l in range(n_layers):
        blk = model.transformer.h[l]
        matrices[f'W2_l{l}'] = blk.mlp.c_proj.weight.detach().numpy()
        matrices[f'W1_l{l}'] = blk.mlp.c_fc.weight.detach().numpy()
        matrices[f'Wq_l{l}'] = blk.attn.attention.q_proj.weight.detach().numpy()
        matrices[f'Wk_l{l}'] = blk.attn.attention.k_proj.weight.detach().numpy()
        matrices[f'Wv_l{l}'] = blk.attn.attention.v_proj.weight.detach().numpy()
        matrices[f'Wo_l{l}'] = blk.attn.attention.out_proj.weight.detach().numpy()
np.random.seed(42)
randoms = {}
for name, W in matrices.items():
    randoms[f'rand_{name}'] = np.random.randn(*W.shape).astype(np.float32)

def byte_entropy(arr):
    raw = arr.astype(np.float32).tobytes()
    counts = Counter(raw)
    total = len(raw)
    entropy = 0.0
    for c in counts.values():
        p = c / total
        entropy -= p * math.log2(p)
    return entropy

def bits_entropy(arr):
    raw = np.frombuffer(arr.astype(np.float32).tobytes(), dtype=np.uint8)
    return byte_entropy(arr)

def sign_entropy(arr):
    flat = arr.astype(np.float32).flatten()
    n_pos = (flat > 0).sum()
    n_neg = (flat < 0).sum()
    n_zero = (flat == 0).sum()
    total = len(flat)
    e = 0.0
    for n in [n_pos, n_neg, n_zero]:
        if n > 0:
            p = n / total
            e -= p * math.log2(p)
    return e

def exponent_entropy(arr):
    raw = np.frombuffer(arr.astype(np.float32).tobytes(), dtype=np.uint8)
    exp_bytes = raw[2::4]
    counts = Counter(exp_bytes.tolist())
    total = len(exp_bytes)
    e = 0.0
    for c in counts.values():
        p = c / total
        e -= p * math.log2(p)
    return e
print(f"\n{'=' * 66}")
print(f'  TEST 1 — BYTE ENTROPY')
print(f'  W matrix bytes vs random matrix bytes')
print(f'  Max possible = 8.0 bits/byte (pure random)')
print(f'  Lower = more structure = more compressible')
print(f"{'=' * 66}\n")
print(f"  {'Matrix':<12} {'W entropy':<14} {'Rand entropy':<14} {'diff':<10} {'verdict'}")
print(f"  {'─' * 58}")
w2_entropies = []
rand_entropies = []
for l in range(n_layers):
    W = matrices[f'W2_l{l}']
    R = randoms[f'rand_W2_l{l}']
    ew = byte_entropy(W)
    er = byte_entropy(R)
    diff = er - ew
    w2_entropies.append(ew)
    rand_entropies.append(er)
    v = '✓ STRUCTURED' if diff > 0.5 else '~ slight' if diff > 0.1 else '= same'
    print(f"  {'W2_L' + str(l):<12} {ew:<14.4f} {er:<14.4f} {diff:<10.4f} {v}")
print(f'\n  Mean W2 entropy:    {np.mean(w2_entropies):.4f}')
print(f'  Mean rand entropy:  {np.mean(rand_entropies):.4f}')
print(f'  Mean difference:    {np.mean(rand_entropies) - np.mean(w2_entropies):.4f}')
print(f'\n  All weight types vs random:\n')
print(f"  {'Type':<10} {'mean W':<12} {'mean Rand':<12} {'structured?'}")
print(f"  {'─' * 45}")
for wtype in ['W1', 'W2', 'Wq', 'Wk', 'Wv', 'Wo']:
    ews = [byte_entropy(matrices[f'{wtype}_l{l}']) for l in range(n_layers)]
    ers = [byte_entropy(randoms[f'rand_{wtype}_l{l}']) for l in range(n_layers)]
    diff = np.mean(ers) - np.mean(ews)
    v = '✓ YES' if diff > 0.3 else '~ slight' if diff > 0.05 else '✗ no'
    print(f'  {wtype:<10} {np.mean(ews):<12.4f} {np.mean(ers):<12.4f} {v}  (diff={diff:.4f})')
print(f"\n{'=' * 66}")
print(f'  TEST 2 — VALUE DISTRIBUTION')
print(f'  What statistical distribution do W bytes follow?')
print(f'  Normal? Laplace? Uniform? Something else?')
print(f"{'=' * 66}\n")
from scipy import stats as scipy_stats
for l in [0, 4, 7]:
    W = matrices[f'W2_l{l}'].flatten()
    mean = W.mean()
    std = W.std()
    kurt = float(scipy_stats.kurtosis(W))
    skew = float(scipy_stats.skew(W))
    _, p_normal = scipy_stats.normaltest(W[:500])
    abs_w = np.abs(W)
    _, p_exp = scipy_stats.kstest(abs_w, 'expon', args=(0, abs_w.mean()))
    print(f'  W2 Layer {l}:')
    print(f'    mean={mean:.6f}  std={std:.6f}')
    print(f'    kurtosis={kurt:.3f}  (normal=0, heavy tail>0)')
    print(f'    skewness={skew:.3f}  (normal=0)')
    print(f"    p_normal={p_normal:.4f}  ({('normal' if p_normal > 0.05 else 'NOT normal')})")
    print(f"    p_laplace_proxy={p_exp:.4f}  ({('fits exp' if p_exp > 0.05 else 'not exp')})\n")
print(f"\n{'=' * 66}")
print(f'  TEST 3 — INTER-LAYER BYTE CORRELATION')
print(f'  Are W bytes correlated ACROSS layers?')
print(f"  If yes: one layer's bytes predicts another's.")
print(f'  That IS compressibility: store diffs, not full matrices.')
print(f"{'=' * 66}\n")
print(f'  W2 cross-layer correlations:\n')
print(f"  {'Pair':<12}", end='')
for l2 in range(n_layers):
    print(f'  L{l2}    ', end='')
print()
print(f"  {'─' * 70}")
w2_flat = {l: matrices[f'W2_l{l}'].flatten() for l in range(n_layers)}
for l1 in range(n_layers):
    print(f'  L{l1}          ', end='')
    for l2 in range(n_layers):
        corr = np.corrcoef(w2_flat[l1], w2_flat[l2])[0, 1]
        print(f'  {corr:+.3f}', end='')
    print()
print(f"\n{'=' * 66}")
print(f'  TEST 4 — SINGULAR VALUE SPECTRUM')
print(f'  W law shaped training → singular values structured?')
print(f'  Random matrix: singular values follow Marchenko-Pastur law')
print(f'  W-shaped matrix: deviations from Marchenko-Pastur = structure')
print(f"{'=' * 66}\n")
print(f"  {'Layer':<8} {'S_max':<10} {'S_min':<10} {'S_mean':<10} {'S_std':<10} {'entropy':<10} {'rand_entropy'}")
print(f"  {'─' * 68}")
sv_entropies_w = []
sv_entropies_rand = []
for l in range(n_layers):
    W = matrices[f'W2_l{l}']
    R = randoms[f'rand_W2_l{l}']
    R_scaled = R * (W.std() / R.std())
    Sw = np.linalg.svd(W, compute_uv=False)
    Sr = np.linalg.svd(R_scaled, compute_uv=False)

    def sv_entropy(s):
        s_norm = s / s.sum()
        return -np.sum(s_norm * np.log2(s_norm + 1e-10))
    ew = sv_entropy(Sw)
    er = sv_entropy(Sr)
    sv_entropies_w.append(ew)
    sv_entropies_rand.append(er)
    print(f'  {l:<8} {Sw.max():<10.4f} {Sw.min():<10.4f} {Sw.mean():<10.4f} {Sw.std():<10.4f} {ew:<10.4f} {er:.4f}')
print(f'\n  Mean SV entropy W:    {np.mean(sv_entropies_w):.4f}')
print(f'  Mean SV entropy rand: {np.mean(sv_entropies_rand):.4f}')
diff = np.mean(sv_entropies_rand) - np.mean(sv_entropies_w)
print(f"  Difference:           {diff:.4f}  ({('✓ W more structured' if diff > 0.5 else '= similar')})")
print(f"\n{'=' * 66}")
print(f'  TEST 5 — SEED COMPRESSION TEST')
print(f'  Can a numpy RNG seed + small parameters')
print(f'  regenerate W bytes to float32 precision?')
print(f'  This tests the fundamental compressibility.')
print(f"{'=' * 66}\n")

def try_reconstruct_from_seed(W, seed, scale=None, mean=None):
    rng = np.random.default_rng(seed)
    s = scale if scale is not None else W.std()
    m = mean if mean is not None else W.mean()
    recon = rng.standard_normal(W.shape).astype(np.float32) * s + m
    err = np.max(np.abs(recon - W))
    r2 = 1 - np.sum((recon - W) ** 2) / (np.sum((W - W.mean()) ** 2) + 1e-10)
    return (err, r2)
print(f'  Testing if weights = seeded random + statistics...\n')
print(f"  {'Layer':<8} {'best_seed':<12} {'max_err':<12} {'R²':<10} {'compressible?'}")
print(f"  {'─' * 52}")
for l in range(n_layers):
    W = matrices[f'W2_l{l}']
    best_err = float('inf')
    best_seed = 0
    best_r2 = 0
    for seed in range(1000):
        err, r2 = try_reconstruct_from_seed(W, seed)
        if err < best_err:
            best_err = err
            best_seed = seed
            best_r2 = r2
    v = '✓ YES' if best_r2 > 0.99 else '~ partial' if best_r2 > 0.5 else '✗ no'
    print(f'  {l:<8} {best_seed:<12} {best_err:<12.4f} {best_r2:<10.4f} {v}')
print(f"\n{'=' * 66}")
print(f'  TEST 6 — DELTA COMPRESSION')
print(f'  Can we store W[0] + small deltas to get W[1]...W[7]?')
print(f'  delta[l] = W[l] - W[0]')
print(f'  If ||delta|| << ||W||: delta compression possible.')
print(f"{'=' * 66}\n")
W0 = matrices['W2_l0']
print(f'  ||W2[0]|| = {np.linalg.norm(W0):.4f}  (reference)\n')
print(f"  {'Layer':<8} {'||W[l]||':<14} {'||delta||':<14} {'ratio':<10} {'compressible?'}")
print(f"  {'─' * 52}")
for l in range(n_layers):
    W = matrices[f'W2_l{l}']
    delta = W - W0
    w_norm = np.linalg.norm(W)
    d_norm = np.linalg.norm(delta)
    ratio = d_norm / (w_norm + 1e-08)
    v = '✓ small delta' if ratio < 0.3 else '~ medium' if ratio < 0.7 else '= same size'
    print(f'  {l:<8} {w_norm:<14.4f} {d_norm:<14.4f} {ratio:<10.4f} {v}')
print(f'\n  Entropy of W vs entropy of delta:\n')
print(f"  {'Layer':<8} {'W entropy':<14} {'delta entropy':<14} {'saving'}")
print(f"  {'─' * 48}")
for l in range(n_layers):
    W = matrices[f'W2_l{l}']
    delta = W - W0
    ew = byte_entropy(W)
    ed = byte_entropy(delta)
    print(f'  {l:<8} {ew:<14.4f} {ed:<14.4f} {ew - ed:+.4f}')
print(f"\n{'=' * 66}")
print(f'  FINAL SUMMARY — WHAT THE BYTES REVEAL')
print(f"{'=' * 66}\n")
mean_w_ent = np.mean(w2_entropies)
mean_r_ent = np.mean(rand_entropies)
mean_sv_diff = np.mean(sv_entropies_rand) - np.mean(sv_entropies_w)
print(f"\n  BYTE ENTROPY:\n    W matrices:     {mean_w_ent:.4f} bits/byte\n    Random:         {mean_r_ent:.4f} bits/byte\n    Difference:     {mean_r_ent - mean_w_ent:.4f} bits/byte\n    \n    {('✓ W bytes have structure — law IS in the bytes' if mean_r_ent - mean_w_ent > 0.3 else '~ Small difference — deeper pattern needed' if mean_r_ent - mean_w_ent > 0.05 else '= Same entropy — bytes look random at surface level')}\n\n  SINGULAR VALUE SPECTRUM:\n    W SV entropy:   {np.mean(sv_entropies_w):.4f}\n    Random SV:      {np.mean(sv_entropies_rand):.4f}\n    Difference:     {mean_sv_diff:.4f}\n    \n    {('✓ W spectrum structured — law visible in eigenspace' if mean_sv_diff > 0.5 else '~ Partial structure in spectrum' if mean_sv_diff > 0.1 else '= Spectrum similar to random')}\n\n  SEED COMPRESSION:\n    Simple seed + statistics → check R² values above.\n    If R² > 0.99: exact reconstruction from tiny seed.\n    \n  HONEST CONCLUSION:\n    Surface bytes: tell us if structure is visible at all.\n    If entropy gap exists → W law left a fingerprint.\n    That fingerprint = the seed = the Sanskrit rule.\n    Seed lives in GPU. Generates weights on demand.\n    Zero IO. Zero quality loss. Exact reconstruction.\n    \n    If no entropy gap:\n    Structure exists in deeper space (singular vectors).\n    Need to work in eigenspace, not raw bytes.\n    The law is there. We need the right coordinate system.\n")
print('=' * 66 + '\n')
