import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — FULL SEQUENCE SIMULTANEOUS')
print('  Whole sequence at once. Not token by token.')
print('  Exact position captured.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
lm_head = model.lm_head.weight.detach().numpy()
ln_f_w = model.transformer.ln_f.weight.detach().numpy()
ln_f_b = model.transformer.ln_f.bias.detach().numpy()
print(f'  Loaded. {n_layers} layers. {D}D.')

def layer_norm(x, w, b, eps=1e-05):
    mean = x.mean(-1, keepdims=True)
    std = np.sqrt(((x - mean) ** 2).mean(-1, keepdims=True) + eps)
    return w * (x - mean) / std + b
CTX = 8
print(f'\n  Context length fixed : {CTX} tokens')
print(f'  W matrix shape       : ({CTX * D}, {CTX * D})')
print(f'  W matrix memory      : {CTX * D * CTX * D * 4 / 1024 / 1024:.2f} MB')
print(f'  Model memory         : {model_mem / 1024 / 1024:.1f} MB')
sentences = ['once upon a time there was a little girl named lily', 'the dog ran fast through the green field near home', 'a boy found a red ball near the big river today', 'the cat sat on the warm mat beside the cozy fire', 'she picked up flowers and smiled at her loving mother', 'he walked slowly down the quiet road in the rain', 'the bird flew high above the tall green trees at dawn', 'a small fish swam in the clear blue calm lake alone', 'the children played happily together in the sunny yard today', 'the old man sat quietly under the big shady oak tree', 'she opened the door and looked outside at the white snow', 'he found a little puppy sleeping near the old red house', 'the sun rose slowly over the distant green rolling hills', 'a rabbit jumped quickly and hid deep inside the green bushes', 'the little boy cried and ran fast to his loving mother', 'she baked warm golden cookies for all the happy children', 'the moon shone bright and clear over the quiet sleeping town', 'a fierce dragon lived deep inside the cold and dark cave', 'the princess waited alone in the tall grey cold stone tower', 'he climbed the tall strong tree to find his lost kite', 'the cold wind blew strong across the wide open green field', 'a tiny grey mouse found a piece of old cheese near wall', 'the old farmer woke up early and went to feed animals', 'she drew a colorful bright picture of her family and house', 'the slow train moved through the high cold snowy mountains', 'a baby elephant splashed and played happily in the muddy water', 'the kind old teacher read a long story to young students', 'he closed his tired eyes and wished upon the first bright star', 'the soft snow fell quietly on the small sleeping village tonight', 'a kind old woman gave warm fresh bread to hungry children', 'the happy puppy wagged its tail and barked very loud outside', 'she sang a sweet soft lullaby to help the baby sleep', 'the brave young knight rode his horse into the dark forest', 'a young clever fox carefully learned to hunt from his mother', 'the bright flowers bloomed beautiful in the warm golden spring sun', 'he discovered a hidden old door behind the dusty wooden bookshelf', 'the yellow butterfly landed gently on a beautiful red rose', 'a small girl lost her way deep in the big dark woods', 'the friendly gentle giant woke up and smiled at the village', 'she found a shiny magic stone beside the old mossy stone well', 'the little cat chased the butterfly through the green sunny garden', 'a brave young boy climbed the tall mountain to see the world', 'the friendly old witch made a magic potion in her cottage', 'a small wooden boat sailed across the wide quiet blue lake', 'the baby bear found golden honey in the hollow old oak tree', 'she whispered a secret to her very best friend at school', 'the bright rainbow appeared after the long and heavy rain fell', 'a clever quick fox tricked the big wolf and ran away', 'the little prince lived alone on a very tiny small planet', 'a kind fairy granted three special wishes to the poor farmer', 'the young brave knight saved the princess from the dark tower', 'a little tiny seed grew into a tall and beautiful flower', 'the wise old wizard taught the young boy how to use magic', 'she gently found a lost kitten crying in the cold rain', 'the two good friends walked together through the enchanted green forest', 'a giant friendly bear helped the lost children find their way home', 'the little mermaid swam slowly up to see the bright stars', 'a young boy named jack climbed the tall beanstalk to the sky', 'the kind queen shared her food with all the hungry people', 'a little yellow duck learned to swim in the warm sunny pond']
print(f'\n  Collecting {CTX}-token sequence pairs...')
X_seq = []
Y_seq = []
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=128, truncation=True)
        ids = tokens['input_ids'][0]
        seq = len(ids)
        if seq < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        embeds = hs[0][0].numpy()
        wstates = hs[-1][0].numpy()
        for start in range(seq - CTX + 1):
            e_window = embeds[start:start + CTX].flatten()
            w_window = wstates[start:start + CTX].flatten()
            X_seq.append(e_window)
            Y_seq.append(w_window)
X = np.array(X_seq)
Y = np.array(Y_seq)
print(f'  Pairs collected: {len(X)}')
print(f'  Each pair: {X.shape[1]} → {Y.shape[1]} dims')
print(f'\n  Extracting W full sequence transform...')
print(f'  Matrix shape: ({CTX * D}, {CTX * D})')
W_full = np.linalg.lstsq(X, Y, rcond=None)[0]
w_mem = W_full.size * 4
print(f'  W matrix memory  : {w_mem / 1024 / 1024:.3f} MB')
print(f'  Model memory     : {model_mem / 1024 / 1024:.1f} MB')
print(f'  Compression      : {model_mem / w_mem:.0f}x')
N_tr = int(len(X) * 0.8)
X_te = X[N_tr:]
Y_te = Y[N_tr:]
Y_pred = X_te @ W_full
err = np.mean((Y_pred - Y_te) ** 2)
sig = np.mean(Y_te ** 2)
r2 = 1 - err / sig
print(f'\n  Extraction quality:')
print(f'  R² score: {r2:.4f}  (1.0 = perfect, 0.0 = random)')
print(f'  This measures how well W captures the full transformation.')

def embed_sequence(ids_list):
    id_t = torch.tensor([ids_list])
    with torch.no_grad():
        e = model.transformer.wte(id_t)
        if hasattr(model.transformer, 'wpe'):
            pos = torch.arange(len(ids_list)).unsqueeze(0)
            e = e + model.transformer.wpe(pos)
    return e[0].numpy()

def w_full_next_token(ids_list):
    if len(ids_list) >= CTX:
        ctx_ids = ids_list[-CTX:]
    else:
        pad = [0] * (CTX - len(ids_list))
        ctx_ids = pad + ids_list
    embeds = embed_sequence(ctx_ids)
    flat_in = embeds.flatten()
    flat_out = flat_in @ W_full
    w_states = flat_out.reshape(CTX, D)
    h_last = layer_norm(w_states[-1], ln_f_w, ln_f_b)
    logits = h_last @ lm_head.T
    return logits

def generate_w_full(prompt, max_new_tokens=50):
    ids = tokenizer.encode(prompt)
    for _ in range(max_new_tokens):
        logits = w_full_next_token(ids)
        next_tok = int(np.argmax(logits))
        if next_tok == tokenizer.eos_token_id:
            break
        ids.append(next_tok)
    return tokenizer.decode(ids, skip_special_tokens=True)

def original_generate(prompt, max_new_tokens=50):
    inp = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(inp, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def wrap(text, width=54, n=5):
    words = text.split()
    lines = []
    line = '  '
    for w in words:
        if len(line) + len(w) > width:
            lines.append(line)
            line = '  ' + w + ' '
        else:
            line += w + ' '
    if line.strip():
        lines.append(line)
    return '\n'.join(lines[:n])

def loop_score(text):
    w = text.split()
    if len(w) < 4:
        return 0.0
    tg = [tuple(w[i:i + 3]) for i in range(len(w) - 2)]
    return 1 - len(set(tg)) / max(len(tg), 1)
print('\n' + '=' * 62)
print('  SIDE BY SIDE')
print(f'  Original : {n_layers} layers sequential, {model_mem / 1024 / 1024:.1f}MB')
print(f'  W full   : 1 matrix, {w_mem / 1024 / 1024:.3f}MB, full context simultaneous')
print('=' * 62)
prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'One day a small rabbit decided to', 'A boy named Tom found a magic', 'The princess looked out the window and']
for i, prompt in enumerate(prompts):
    print(f"\n  {'─' * 58}")
    print(f'  PROMPT {i + 1}: "{prompt}"')
    print(f"  {'─' * 58}")
    orig = original_generate(prompt, 40)
    w_out = generate_w_full(prompt, 40)
    print(f'\n  ORIGINAL ({n_layers} layers, {model_mem / 1024 / 1024:.1f}MB):')
    print(wrap(orig))
    print(f'\n  W FULL ({w_mem / 1024 / 1024:.3f}MB, context={CTX}, simultaneous):')
    print(wrap(w_out))
    print(f'\n  Loop score — Original: {loop_score(orig):.2f}  W full: {loop_score(w_out):.2f}')
print('\n' + '=' * 62)
print('  WHAT CHANGED — THE EXACT FIX')
print('=' * 62)
print(f'\n  Previous W transform (WRONG):\n    Per-token mapping: embed[t] → w_state[t]\n    Position t cannot see position t-1, t-2, ...\n    Result: "basketball and oranges" always.\n    Same attractor regardless of input.\n    Context completely ignored.\n\n  W full sequence (THIS TEST):\n    Full mapping: [embed[0..{CTX}]] → [w_state[0..{CTX}]]\n    Position t CAN see all other positions through W.\n    Cross-position relationships encoded in W.\n    Context IS captured.\n    Exact position IS included.\n\n  W matrix:\n    Shape  : ({CTX * D}, {CTX * D})\n    Memory : {w_mem / 1024 / 1024:.3f} MB\n    R²     : {r2:.4f}\n\n  R² measures capture quality:\n    1.0 = W perfectly captures all-layer transformation\n    0.5 = half the variance captured\n    0.0 = nothing captured\n\n  If text above is coherent:\n    Cross-position W works.\n    Exact position was the missing piece.\n    Confirmed.\n\n  If still degraded:\n    Nonlinearity is the remaining issue.\n    Linear W cannot capture nonlinear attention.\n    Next step: nonlinear W in full sequence space.\n')
print('=' * 62 + '\n')
