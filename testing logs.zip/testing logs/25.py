import torch
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
import time, warnings, math
warnings.filterwarnings('ignore')
MODEL_ID = 'roneneldan/TinyStories-1M'
GEN_TOKENS = 50
PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'In the forest there lived a', 'Tom and his friend went to the', 'The big red ball']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('=' * 65)
print('  LOAD MODEL & EXTRACT WEIGHTS')
print('=' * 65)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
model = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True)
model = model.to(device).eval()
cfg = model.config
NL = cfg.num_layers
H = cfg.hidden_size
NH = cfg.num_heads
HD = H // NH
VOCAB = cfg.vocab_size
FFN_DIM = H * 4
W = {}
for li in range(NL):
    bl = model.transformer.h[li]
    at = bl.attn.attention
    W[li] = {'ln1_g': bl.ln_1.weight.detach().float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.detach().float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.detach().float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.detach().float().cpu().numpy(), 'W_q': at.q_proj.weight.detach().float().cpu().numpy(), 'W_k': at.k_proj.weight.detach().float().cpu().numpy(), 'W_v': at.v_proj.weight.detach().float().cpu().numpy(), 'W_o': at.out_proj.weight.detach().float().cpu().numpy(), 'b_o': at.out_proj.bias.detach().float().cpu().numpy(), 'W1': bl.mlp.c_fc.weight.detach().float().cpu().numpy(), 'b1': bl.mlp.c_fc.bias.detach().float().cpu().numpy(), 'W2': bl.mlp.c_proj.weight.detach().float().cpu().numpy(), 'b2': bl.mlp.c_proj.bias.detach().float().cpu().numpy()}
    try:
        W[li]['attn_type'] = cfg.attention_layers[li]
    except:
        W[li]['attn_type'] = 'global'
    try:
        W[li]['window'] = cfg.window_size
    except:
        W[li]['window'] = 256
Wte = model.transformer.wte.weight.detach().float().cpu().numpy()
Wpe = model.transformer.wpe.weight.detach().float().cpu().numpy()
lnf_g = model.transformer.ln_f.weight.detach().float().cpu().numpy()
lnf_b = model.transformer.ln_f.bias.detach().float().cpu().numpy()
Wlm = model.lm_head.weight.detach().float().cpu().numpy()
print(f'  Extracted {NL} layers. H={H} NH={NH} HD={HD}')

def ln(x, g, b):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (g * (x - mean) / np.sqrt(var + 1e-05) + b).astype(np.float32)

def gelu_np(x):
    return 0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def build_mask(sl, attn_type, window):
    mask = np.full((sl, sl), -1000000000.0, dtype=np.float32)
    for i in range(sl):
        start = max(0, i - window + 1) if attn_type == 'local' else 0
        mask[i, start:i + 1] = 0.0
    return mask

def crystal_layer(h, li, kv_cache=None):
    sl = h.shape[0]
    w = W[li]
    ln1 = ln(h, w['ln1_g'], w['ln1_b'])
    Q = ln1 @ w['W_q'].T
    K = ln1 @ w['W_k'].T
    V = ln1 @ w['W_v'].T
    if kv_cache is not None:
        K_full = np.concatenate([kv_cache['K'], K], axis=0)
        V_full = np.concatenate([kv_cache['V'], V], axis=0)
    else:
        K_full = K
        V_full = V
    past_len = K_full.shape[0] - sl
    full_len = K_full.shape[0]
    head_ctxs = []
    for hh in range(NH):
        s, e = (hh * HD, hh * HD + HD)
        Q_h = Q[:, s:e]
        K_h = K_full[:, s:e]
        V_h = V_full[:, s:e]
        scores = (Q_h @ K_h.T).astype(np.float32)
        mask = np.full((sl, full_len), -1000000000.0, dtype=np.float32)
        for i in range(sl):
            i_abs = past_len + i
            if w['attn_type'] == 'local':
                start = max(0, i_abs - w['window'] + 1)
            else:
                start = 0
            mask[i, start:i_abs + 1] = 0.0
        probs = softmax_np(scores + mask)
        ctx_h = probs @ V_h
        head_ctxs.append(ctx_h)
    ctx = np.concatenate(head_ctxs, axis=-1)
    att_out = ctx @ w['W_o'].T + w['b_o']
    h_mid = h + att_out
    ln2 = ln(h_mid, w['ln2_g'], w['ln2_b'])
    pre = ln2 @ w['W1'].T + w['b1']
    act = gelu_np(pre)
    ffn_out = act @ w['W2'].T + w['b2']
    h_out = h_mid + ffn_out
    return (h_out, K, V)

def crystal_forward(input_ids, kv_caches=None):
    ids = np.array(input_ids, dtype=np.int32)
    sl = len(ids)
    pos = np.arange(0 if kv_caches is None else kv_caches[0]['K'].shape[0], (0 if kv_caches is None else kv_caches[0]['K'].shape[0]) + sl)
    h = (Wte[ids] + Wpe[pos]).astype(np.float32)
    new_caches = []
    for li in range(NL):
        cache = kv_caches[li] if kv_caches is not None else None
        h, K_new, V_new = crystal_layer(h, li, cache)
        if kv_caches is not None:
            new_caches.append({'K': np.concatenate([kv_caches[li]['K'], K_new], axis=0), 'V': np.concatenate([kv_caches[li]['V'], V_new], axis=0)})
        else:
            new_caches.append({'K': K_new, 'V': V_new})
    h_final = ln(h, lnf_g, lnf_b)
    logits = h_final @ Wlm.T
    return (logits, new_caches)

def build_self_path_table():
    print('  Building self-path table for all vocab tokens...')
    t0 = time.perf_counter()
    h = Wte + Wpe[0]
    for li in range(NL):
        w = W[li]
        ln2 = ln(h, w['ln2_g'], w['ln2_b'])
        pre = ln2 @ w['W1'].T + w['b1']
        act = gelu_np(pre)
        ffn_out = act @ w['W2'].T + w['b2']
        h = h + ffn_out
    elapsed = time.perf_counter() - t0
    print(f'  Self-path table built: {h.shape} in {elapsed:.2f}s')
    return h

def generate_pytorch(prompt, n_tokens):
    ids = tok(prompt, return_tensors='pt')['input_ids'].to(device)
    t0 = time.perf_counter()
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=n_tokens, do_sample=False, temperature=1.0, use_cache=True, return_dict_in_generate=True, output_scores=True)
    elapsed = time.perf_counter() - t0
    new_ids = out.sequences[0][ids.shape[1]:].cpu().tolist()
    pt_logits = [s[0].float().cpu().numpy() for s in out.scores]
    return (new_ids, elapsed, pt_logits)

def generate_crystal_nokv(prompt, n_tokens):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    t0 = time.perf_counter()
    for _ in range(n_tokens):
        logits, _ = crystal_forward(ids, kv_caches=None)
        next_id = int(np.argmax(logits[-1]))
        ids.append(next_id)
    elapsed = time.perf_counter() - t0
    return (ids[len(tok(prompt)['input_ids']):], elapsed)

def generate_crystal_kv(prompt, n_tokens, pt_ids_ref=None):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    t0 = time.perf_counter()
    logits, caches = crystal_forward(ids, kv_caches=None)
    next_id = int(np.argmax(logits[-1]))
    new_ids = [next_id]
    for _ in range(n_tokens - 1):
        logits, caches = crystal_forward([next_id], kv_caches=caches)
        next_id = int(np.argmax(logits[-1]))
        new_ids.append(next_id)
    elapsed = time.perf_counter() - t0
    return (new_ids, elapsed)

def teacher_forced_corr(prompt, pt_new_ids):
    prompt_ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    full_ids = prompt_ids + pt_new_ids
    inp = torch.tensor([full_ids]).to(device)
    with torch.no_grad():
        pt_logits = model(inp).logits[0].float().cpu().numpy()
    cr_logits, _ = crystal_forward(full_ids, kv_caches=None)
    corrs = []
    for pos in range(len(prompt_ids) - 1, len(full_ids) - 1):
        pl = pt_logits[pos].astype(np.float64)
        cl = cr_logits[pos].astype(np.float64)
        corr = float(np.corrcoef(pl, cl)[0, 1])
        corrs.append(corr)
    return corrs
print('\n' + '=' * 65)
print('  BENCHMARK: PyTorch vs Crystal numpy vs Crystal+KV')
print('=' * 65)
print(f'  Prompts: {len(PROMPTS)}')
print(f'  Tokens per prompt: {GEN_TOKENS}')
print(f'  Total tokens: {len(PROMPTS) * GEN_TOKENS}')
_ = generate_pytorch(PROMPTS[0], 3)
_ = generate_crystal_kv(PROMPTS[0], 3)
results = []
for pi, prompt in enumerate(PROMPTS):
    print(f'\n  ── Prompt {pi + 1}: "{prompt[:40]}..."')
    ids_pt, t_pt, pt_logits = generate_pytorch(prompt, GEN_TOKENS)
    ids_nokv, t_nokv = generate_crystal_nokv(prompt, GEN_TOKENS)
    ids_kv, t_kv = generate_crystal_kv(prompt, GEN_TOKENS)
    tf_corrs = teacher_forced_corr(prompt, ids_pt)
    avg_corr = float(np.mean(tf_corrs))
    min_corr = float(np.min(tf_corrs))
    tok_pt = tok.decode(ids_pt)
    tok_kv = tok.decode(ids_kv)
    ms_pt = t_pt / GEN_TOKENS * 1000
    ms_nokv = t_nokv / GEN_TOKENS * 1000
    ms_kv = t_kv / GEN_TOKENS * 1000
    spd_nokv = t_pt / t_nokv
    spd_kv = t_pt / t_kv
    print(f'    PyTorch    : {t_pt * 1000:7.1f}ms  {ms_pt:6.2f}ms/tok')
    print(f'    Crystal    : {t_nokv * 1000:7.1f}ms  {ms_nokv:6.2f}ms/tok  x{spd_nokv:.2f}')
    print(f'    Crystal+KV : {t_kv * 1000:7.1f}ms  {ms_kv:6.2f}ms/tok  x{spd_kv:.2f}')
    print(f'    Logit corr (teacher-forced): avg={avg_corr:.8f}  min={min_corr:.8f}')
    print(f'\n    PyTorch    : {repr(tok_pt[:80])}')
    print(f'    Crystal+KV : {repr(tok_kv[:80])}')
    results.append({'prompt': prompt, 't_pt': t_pt, 't_nokv': t_nokv, 't_kv': t_kv, 'ms_pt': ms_pt, 'ms_nokv': ms_nokv, 'ms_kv': ms_kv, 'avg_corr': avg_corr, 'min_corr': min_corr})
print('\n' + '=' * 65)
print('  SUMMARY')
print('=' * 65)
avg_ms_pt = np.mean([r['ms_pt'] for r in results])
avg_ms_nokv = np.mean([r['ms_nokv'] for r in results])
avg_ms_kv = np.mean([r['ms_kv'] for r in results])
avg_corr = np.mean([r['avg_corr'] for r in results])
min_corr = np.min([r['min_corr'] for r in results])
avg_spd_nokv = avg_ms_pt / avg_ms_nokv
avg_spd_kv = avg_ms_pt / avg_ms_kv
print(f"\n  {'Method':<22} {'ms/tok':>8}  {'tok/s':>8}  {'speedup':>9}")
print(f"  {'-' * 52}")
print(f"  {'PyTorch (GPU+cache)':<22} {avg_ms_pt:8.2f}  {1000 / avg_ms_pt:8.1f}  {'baseline':>9}")
print(f"  {'Crystal (no cache)':<22} {avg_ms_nokv:8.2f}  {1000 / avg_ms_nokv:8.1f}  {avg_spd_nokv:>8.2f}x")
print(f"  {'Crystal+KV (CPU)':<22} {avg_ms_kv:8.2f}  {1000 / avg_ms_kv:8.1f}  {avg_spd_kv:>8.2f}x")
print()
print(f'  Teacher-forced logit correlation (crystal vs PyTorch, identical context):')
print(f'    avg corr = {avg_corr:.6f}   min corr = {min_corr:.6f}')
print()
print(f'  NOTE: corr should be ~0.9999 if crystal = PyTorch exactly.')
print(f'  corr=0.89 = there is a real computation gap — diagnosing next.')
print()
print(f'  ── NUMERICAL DIAGNOSIS ──')
print(f'  The remaining gap (corr=0.89 vs expected 0.9999) is likely:')
print(f'  1. position embedding offset in KV-cache decode steps')
print(f'     (crystal uses wrong pos for single-token decode)')
print(f'  2. LN epsilon: PyTorch uses 1e-5, we use 1e-5 — check match')
print(f'  3. Wpe indexing: pos should be past_len, not 0')
