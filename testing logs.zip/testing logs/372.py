import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 1e-10 else 1.0

def fit_and_r2(X, Y, split=0.8):
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    if s < 10 or n - s < 5:
        return (float('nan'), float('nan'))
    X64 = np.c_[X.astype(np.float64), np.ones(n)]
    Y64 = Y.astype(np.float64)
    try:
        W = np.linalg.lstsq(X64[:s], Y64[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    pred_tr = X64[:s] @ W
    pred_te = X64[s:] @ W
    return (r2(pred_tr, Y64[:s]), r2(pred_te, Y64[s:]))

def rms_norm(x):
    rms = np.sqrt(np.mean(x ** 2, axis=1, keepdims=True)) + 1e-06
    return x / rms

def layer_norm(x):
    mu = np.mean(x, axis=1, keepdims=True)
    std = np.std(x, axis=1, keepdims=True) + 1e-06
    return (x - mu) / std

def pca_project(x, k=3):
    xc = x - x.mean(axis=0)
    _, _, Vt = np.linalg.svd(xc, full_matrices=False)
    return xc @ Vt[:k].T
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly in the shadows. Lily gently picked up the kitten and held it close to her heart to keep it warm. She carried it inside and showed her mother who smiled and said they could keep it.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding the animals he would go to the fields and work until the sun went down. His children would bring him lunch and sit with him under the big oak tree nearby.', 'Deep in the forest there was a small house where a family of bears lived together. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the woods nearby. One day the baby bear followed a butterfly deep into the forest and got lost alone. He sat down and began to cry because he could not find his way back home again.', 'There was once a brave young knight who lived in a castle near the mountains high. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go and face the dragon and bring peace to the kingdom. He rode for three days through dark forests and over high mountains to find the dragon.', 'A small girl named Sophie loved books more than anything else in the whole wide world. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her their stories directly. She learned about faraway lands and ancient kingdoms and creatures no one had ever seen.', 'The little village sat quietly at the edge of a great forest full of ancient trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest. Children would run through the market eating apples and drinking warm spiced cider. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight came. The old grandmother would sit by the fire and tell stories of the village long ago.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him. The first night Tommy shone the light and saw only his toys and books and nothing scary. His father explained that darkness was just the absence of light and nothing more than that. Tommy started to feel braver and soon he could sleep without the flashlight beside him.', 'The ocean was vast and blue and stretched as far as the eye could possibly see. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water. One night a terrible storm came and blew his boat far off course into unknown waters. When morning came he saw an island he had never seen before on any of his old maps. He went ashore and found the island was full of strange and beautiful plants and birds.', 'High up in the mountains there was a small school where children came from far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way. Some children learned by reading and some by drawing and some by building things with hands. She gave each child the kind of lesson that matched the way their mind worked best. At the end of every year her students could all read and write and solve hard problems.', 'The little robot sat in the corner of the workshop waiting to be fixed by someone kind. Its creator had built it with love and given it the ability to learn new things each day. The robot could sort the tools and clean the floor and even make a simple pot of tea. But one day it fell and broke its left arm and could no longer do its work properly. A young engineer found it and carefully repaired the arm using spare parts from the shelf. The robot was so grateful that it worked twice as hard and learned even faster than before.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake and ready. They all ate breakfast together and laughed and talked about the fun day ahead.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished and it had a rope ladder and a little window. They sat inside it that first evening and felt like kings of their own small world.']
print(f'\nCollecting activations from {len(long_texts)} long texts...')
store = {'h': {l: [] for l in range(n_layers + 1)}, 'gelu': {l: [] for l in range(n_layers)}, 'attn': {l: [] for l in range(n_layers)}, 'lnf': [], 'logits': [], 'correct': []}
cur = {k: [] for k in ['h0', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'hf', 'g0', 'g1', 'g2', 'g3', 'g4', 'g5', 'g6', 'g7', 'a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'lnf']}
hooks = []
for li in range(n_layers):

    def make_h(l):

        def hook(m, inp, out):
            cur[f'h{l}'].append(inp[0].detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].register_forward_hook(make_h(li)))

def hook_lnf_in(m, inp, out):
    cur['hf'].append(inp[0].detach().float()[0].numpy().copy())
    cur['lnf'].append(out.detach().float()[0].numpy().copy())
hooks.append(model.transformer.ln_f.register_forward_hook(hook_lnf_in))
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur[f'g{l}'].append(out.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
for li in range(n_layers):

    def make_a(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur[f'a{l}'].append(o.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_a(li)))
all_store = {k: [] for k in cur.keys()}
correct_store = []
with torch.no_grad():
    for text in long_texts:
        for k in cur:
            cur[k].clear()
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        out = model(**toks)
        ids = toks['input_ids'][0].numpy()
        L = len(ids)
        logits = out.logits[0].detach().float().numpy()
        for t in range(L - 1):
            for k in cur:
                if cur[k] and cur[k][0].shape[0] > t:
                    all_store[k].append(cur[k][0][t].copy())
            correct_store.append(int(ids[t + 1]))
for h in hooks:
    h.remove()
arrays = {}
for k in cur:
    if all_store[k]:
        arrays[k] = np.array(all_store[k], dtype=np.float32)
COR = correct_store
N = len(COR)
print(f'Total aligned tokens: {N}')
TARGET = arrays['lnf']
print(f'Target (ln_f output): {TARGET.shape}')
print(f"\n{'=' * 70}")
print(f'  DEEP NATURAL SPACE SCAN')
print(f'  Target: ln_f output (D={D}) = answer space')
print(f'  Testing every layer, every transformation')
print(f"{'=' * 70}")
results = []

def test(name, X, target=TARGET):
    if X is None or len(X) == 0:
        return
    if not np.all(np.isfinite(X)):
        return
    r2_tr, r2_te = fit_and_r2(X, target)
    results.append({'name': name, 'r2_tr': r2_tr, 'r2_te': r2_te, 'dim': X.shape[1] if X.ndim > 1 else 1})
    marker = '✓✓ NATURAL' if r2_te > 0.999 else '✓ STRONG' if r2_te > 0.95 else '~ GOOD' if r2_te > 0.8 else '· PARTIAL' if r2_te > 0.5 else '  LOW'
    print(f'  {name:<35} dim={(X.shape[1] if X.ndim > 1 else 1):<6} R²_te={r2_te:.4f}  {marker}')
print(f'\n  GROUP A — Raw h at each layer:')
for li in range(n_layers):
    k = f'h{li}'
    if k in arrays:
        test(f'h_{li} (raw)', arrays[k])
test('h_final (raw)', arrays.get('hf'))
print(f'\n  GROUP B — RMS normalized h at each layer:')
for li in range(n_layers):
    k = f'h{li}'
    if k in arrays:
        test(f'h_{li}/RMS', rms_norm(arrays[k]))
test('h_final/RMS', rms_norm(arrays['hf']) if 'hf' in arrays else None)
print(f'\n  GROUP C — Layer normalized h at each layer:')
for li in range(n_layers):
    k = f'h{li}'
    if k in arrays:
        test(f'LayerNorm(h_{li})', layer_norm(arrays[k]))
print(f'\n  GROUP D — Gelu output (natural space of FFN):')
for li in range(n_layers):
    k = f'g{li}'
    if k in arrays:
        test(f'gelu_{li}', arrays[k])
print(f'\n  GROUP E — Attention output at each layer:')
for li in range(n_layers):
    k = f'a{li}'
    if k in arrays:
        test(f'attn_{li}', arrays[k])
print(f'\n  GROUP F — PCA projection (top-3 dims) of h:')
for li in range(n_layers):
    k = f'h{li}'
    if k in arrays and len(arrays[k]) > 10:
        proj = pca_project(arrays[k], k=3)
        test(f'PCA3(h_{li})', proj)
print(f'\n  GROUP G — Combinations:')
if 'h2' in arrays and 'h3' in arrays and ('h4' in arrays):
    mid = np.concatenate([arrays['h2'], arrays['h3'], arrays['h4']], axis=1)
    test('h_2+h_3+h_4 concat', mid)
if 'g2' in arrays and 'g3' in arrays:
    gmid = np.concatenate([arrays['g2'], arrays['g3']], axis=1)
    test('gelu_2+gelu_3 concat', gmid)
if 'hf' in arrays and 'g7' in arrays:
    hg = np.concatenate([arrays['hf'], arrays['g7']], axis=1)
    test('h_final+gelu_7', hg)
for li in [2, 3, 4, 5]:
    k = f'h{li}'
    if k in arrays:
        rn = rms_norm(arrays[k])
        ln = layer_norm(arrays[k])
        combo = np.concatenate([rn, ln], axis=1)
        test(f'RMS+LN(h_{li})', combo)
print(f'\n  GROUP H — Crystal chain: gelu_l → gelu_l+1:')
for li in range(n_layers - 1):
    ka = f'g{li}'
    kb = f'g{li + 1}'
    if ka in arrays and kb in arrays:
        r2_tr, r2_te = fit_and_r2(arrays[ka], arrays[kb])
        marker = '✓✓ PERFECT' if r2_te > 0.999 else '✓ STRONG' if r2_te > 0.95 else '~ GOOD' if r2_te > 0.8 else '· PARTIAL'
        print(f'  gelu_{li} → gelu_{li + 1:<20} R²_te={r2_te:.4f}  {marker}')
print(f'\n  GROUP I — Depth law: R² of h_l → target vs layer:')
print(f'  (Shows where natural space emerges)')
for li in range(n_layers):
    k = f'h{li}'
    if k in arrays:
        _, r2_te = fit_and_r2(arrays[k], TARGET)
        bar = '█' * int(max(0, r2_te) * 40)
        print(f'  Layer {li}: {r2_te:.4f}  {bar}')
_, r2_f = fit_and_r2(arrays.get('hf', np.zeros((1, 1))), TARGET)
print(f"  Final:   {r2_f:.4f}  {'█' * int(max(0, r2_f) * 40)}")
print(f"\n{'=' * 70}")
print(f'  SCAN SUMMARY — TOP RESULTS')
print(f"{'=' * 70}")
valid = [(r['name'], r['r2_te'], r['dim']) for r in results if np.isfinite(r['r2_te'])]
valid.sort(key=lambda x: x[1], reverse=True)
print(f'\n  Top 15 natural space candidates:')
print(f"  {'Transformation':<35} {'dim':<8} {'R² test'}")
print(f"  {'─' * 55}")
for name, rv, dim in valid[:15]:
    marker = '✓✓ NATURAL' if rv > 0.999 else '✓ STRONG' if rv > 0.95 else '~ GOOD' if rv > 0.8 else ''
    print(f'  {name:<35} {dim:<8} {rv:.4f}  {marker}')
best_name, best_r2, best_dim = valid[0] if valid else ('none', 0, 0)
print(f'\n  BEST: {best_name}  R²={best_r2:.4f}  dim={best_dim}')
if best_r2 > 0.999:
    print(f'\n  ✓✓ NATURAL SPACE OF FULL MODEL FOUND.')
    print(f'  {best_name} = natural space.')
    print(f'  Linear map to answer space. R²=1.000.')
elif best_r2 > 0.95:
    print(f'\n  ✓ STRONG CANDIDATE FOUND.')
    print(f'  {best_name} is close to natural space.')
    print(f'  Small nonlinear component remains.')
else:
    print(f'\n  Natural space not yet found.')
    print(f'  Best R²={best_r2:.4f}.')
    print(f'  Need deeper transformation or combination.')
print(f'\n  WHAT R² PATTERN TELLS US:\n\n  If R² rises monotonically layer 0→7:\n    Natural space builds across ALL layers.\n    No single crystallization point.\n    Depth itself = the transformation.\n\n  If R² jumps at specific layer (e.g. layer 3):\n    That layer = crystallization point.\n    You were right: 2-5 layers deep.\n    Before = raw. After = natural space.\n\n  If gelu layers beat h layers consistently:\n    FFN natural space = closer to full model natural space.\n    Gelu = universal crystallization at every layer.\n\n  If combination beats single layer:\n    Natural space = multi-layer phenomenon.\n    Cannot reduce to one layer.\n    Need all layers together.\n\n  Crystal chain R²:\n    If gelu_l → gelu_l+1 = high R²:\n      Crystal resonance is real.\n      Crystals communicate directly.\n      Skip h. Work in crystal space only.\n')
print('=' * 70 + '\n')
