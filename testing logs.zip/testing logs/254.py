import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL v8 — PLS NATURAL COORDINATES')
print('  Axes point TOWARD target. Every layer searches its own.')
print("  'Every star need search for plotting.' — Manish")
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\nout loud and ground twice as much flour that week to make up for\nthe time that had been lost the little rabbit who lived at the\nedge of the meadow had three sisters and one brother every evening\nthey sat together at the entrance to their burrow and watched the\nsun go down over the hills the youngest rabbit always asked why\ndoes the sun go down and the oldest rabbit always said so that\nthe stars can come out and find their way home this made the\nyoungest rabbit very happy and she went to sleep thinking about\nall the stars making their long journey across the dark sky\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also very\ncurious which sometimes got him into trouble one spring morning\nriku went exploring while his mother was sleeping he found a path\nhe had never followed before and followed it until he reached a\nfarm with a red barn and a vegetable garden behind a low fence\nthe garden was full of green things and the smell of fresh earth\nriku squeezed under the fence and walked between the rows of\nvegetables sniffing everything but the farmer saw him from the\nwindow and came out shouting riku ran as fast as he could back\nunder the fence and all the way home where he lay panting under\na bush his mother found him there and said the farmer had worked\nvery hard to grow those vegetables riku should be more careful\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet agreement between them she found a door hidden behind\na tall waterfall deep in the hills behind the door was a small\nroom with a round window and inside the room there was a wooden\ntable with a candle and a book the book had no title but when\nshe opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when\nshe finally looked up the candle had burned low and the light\noutside had turned to gold she closed the book carefully and\nwalked back through the door and did not tell anyone what she\nhad found but every time she passed that hill she smiled quietly\nthe small lighthouse on the eastern cliff had been dark for many\nyears until one autumn a young woman came to the town and asked\nif she could tend the light the people were pleased and gave her\nthe keys and she climbed the long stairs to the lamp room and\ncleaned the great lens and filled it with oil that night the\nlight shone out across the water for the first time in years\n'.strip()
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VS = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Vocab={VS}  Tokens={len(tokens)}')
D = 48
FFN_D = 96
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 3
SEQ_LEN = 24
LAM = 0.01
CLIP = 1.5
LR = 0.12
K_PLS = 24
print(f'  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}  K_PLS={K_PLS}')
rng = np.random.RandomState(0)
WTE = rng.randn(VS, D).astype(np.float64)
for i in range(VS):
    WTE[i] /= np.linalg.norm(WTE[i]) + 1e-08
WTE *= 0.5
WPE = rng.randn(SEQ_LEN + 2, D).astype(np.float64) * 0.04

def ortho(n, m, scale=0.07):
    A = rng.randn(max(n, m), max(n, m))
    Q, _ = np.linalg.qr(A)
    return Q[:n, :m].astype(np.float64) * scale

def init():
    w = {}
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1g{s}'] = np.ones(D)
        w[f'ln1b{s}'] = np.zeros(D)
        w[f'ln2g{s}'] = np.ones(D)
        w[f'ln2b{s}'] = np.zeros(D)
        w[f'Wq{s}'] = ortho(D, D)
        w[f'Wk{s}'] = ortho(D, D)
        w[f'Wv{s}'] = np.zeros((D, D))
        w[f'Wo{s}'] = np.zeros((D, D))
        w[f'bo{s}'] = np.zeros(D)
        w[f'W1{s}'] = ortho(FFN_D, D, 0.01)
        w[f'b1{s}'] = np.zeros(FFN_D)
        w[f'W2{s}'] = np.zeros((D, FFN_D))
        w[f'b2{s}'] = np.zeros(D)
        w[f'P_x{s}'] = np.eye(D, K_PLS)
        w[f'P_y{s}'] = np.eye(D, K_PLS)
    w['lfg'] = np.ones(D)
    w['lfb'] = np.zeros(D)
    return w

def lnorm(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def ridge(X, Y, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    try:
        W = np.linalg.solve(A, Xb.T @ Y)
    except:
        W, _, _, _ = np.linalg.lstsq(Xb, Y, rcond=None)
    return np.clip(W, -CLIP, CLIP)

def layer_fwd(x, li, w):
    T = len(x)
    s = str(li)
    h = np.array([lnorm(x[i], w[f'ln1g{s}'], w[f'ln1b{s}']) for i in range(T)])
    Q = h @ w[f'Wq{s}'].T
    K = h @ w[f'Wk{s}'].T
    V = h @ w[f'Wv{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    ctx = np.stack([probs[hd] @ Vh[hd] for hd in range(N_HEADS)], 1).reshape(T, D)
    xa = x + ctx @ w[f'Wo{s}'].T + w[f'bo{s}']
    xn = xa.copy()
    for t in range(T):
        h2 = lnorm(xa[t], w[f'ln2g{s}'], w[f'ln2b{s}'])
        xn[t] = xa[t] + gelu(h2 @ w[f'W1{s}'].T + w[f'b1{s}']) @ w[f'W2{s}'].T + w[f'b2{s}']
    return (xn, ctx, xa, h, probs)

def full_fwd(ids, w):
    T = len(ids)
    x = (WTE[ids] + WPE[:T]).copy()
    for li in range(N_LAYERS):
        x, _, _, _, _ = layer_fwd(x, li, w)
    xf = np.array([lnorm(x[t], w['lfg'], w['lfb']) for t in range(T)])
    return xf @ WTE.T

def calc_ppl(w, n=400):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        try:
            logits = full_fwd(ids, w)
            if not np.all(np.isfinite(logits[-1])):
                continue
            lg = logits[-1] - logits[-1].max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return 999.0
    return math.exp(min(nll / tok, 500))

def pls_axes(X, Y, K):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Xc = X - X.mean(0)
    Yc = Y - Y.mean(0)
    P_x = np.zeros((X.shape[1], K))
    P_y = np.zeros((Y.shape[1], K))
    Xr = Xc.copy()
    Yr = Yc.copy()
    for k in range(K):
        if np.linalg.norm(Xr) < 1e-08 or np.linalg.norm(Yr) < 1e-08:
            break
        M = Xr.T @ Yr
        try:
            U, s, Vt = np.linalg.svd(M, full_matrices=False)
            w_k = U[:, 0]
            c_k = Vt[0, :]
        except:
            break
        t_k = Xr @ w_k
        t_norm = np.dot(t_k, t_k)
        if t_norm < 1e-10:
            break
        u_k = Yr @ c_k
        p_k = Xr.T @ t_k / t_norm
        q_k = Yr.T @ t_k / t_norm
        Xr = Xr - np.outer(t_k, p_k)
        Yr = Yr - np.outer(t_k, q_k)
        P_x[:, k] = w_k
        P_y[:, k] = c_k
    for k in range(K):
        n = np.linalg.norm(P_x[:, k])
        if n > 1e-08:
            P_x[:, k] /= n
        n = np.linalg.norm(P_y[:, k])
        if n > 1e-08:
            P_y[:, k] /= n
    return (P_x, P_y)

def collect_frozen(w, idxs):
    data = {li: {'x_in': [], 'ctx': [], 'xa': [], 'wln1': [], 'h2': [], 'gl': [], 'residual': []} for li in range(N_LAYERS)}
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
        for li in range(N_LAYERS):
            x_in = x[-1].copy()
            if not np.all(np.isfinite(x_in)):
                break
            residual = WTE[nxt] - x_in
            if np.linalg.norm(residual) < 1e-08:
                break
            xn, ctx, xa, h_ln1, probs = layer_fwd(x, li, w)
            ctx_l = ctx[-1]
            xa_l = xa[-1]
            if not np.all(np.isfinite(ctx_l + xa_l)):
                break
            s = str(li)
            h2 = lnorm(xa_l, w[f'ln2g{s}'], w[f'ln2b{s}'])
            gl = gelu(h2 @ w[f'W1{s}'].T + w[f'b1{s}'])
            if not np.all(np.isfinite(gl)):
                break
            pla = probs[:, -1, :].mean(0)
            wln1 = pla @ h_ln1
            data[li]['x_in'].append(x_in)
            data[li]['ctx'].append(ctx_l)
            data[li]['xa'].append(xa_l)
            data[li]['wln1'].append(wln1)
            data[li]['h2'].append(h2)
            data[li]['gl'].append(gl)
            data[li]['residual'].append(residual)
            x = xn
    for li in range(N_LAYERS):
        for k in data[li]:
            data[li][k] = np.array(data[li][k], dtype=np.float64) if data[li][k] else np.zeros((0, D))
    return data

def discover_pls(w, data):
    for li in range(N_LAYERS):
        s = str(li)
        X = data[li]['x_in']
        Y = data[li]['residual']
        if len(X) < K_PLS + 5:
            continue
        try:
            Px, Py = pls_axes(X, Y, K_PLS)
            w[f'P_x{s}'] = 0.7 * Px + 0.3 * w[f'P_x{s}']
            w[f'P_y{s}'] = 0.7 * Py + 0.3 * w[f'P_y{s}']
            for k in range(K_PLS):
                n = np.linalg.norm(w[f'P_x{s}'][:, k])
                if n > 1e-08:
                    w[f'P_x{s}'][:, k] /= n
                n = np.linalg.norm(w[f'P_y{s}'][:, k])
                if n > 1e-08:
                    w[f'P_y{s}'][:, k] /= n
        except:
            pass
    return w

def solve_pls(li, w, data):
    s = str(li)
    N = len(data[li]['residual'])
    if N < 20:
        return w
    Px = w[f'P_x{s}']
    Py = w[f'P_y{s}']
    Residuals = data[li]['residual']
    X_ctx = data[li]['ctx']
    X_xa = data[li]['xa']
    X_wln1 = data[li]['wln1']
    X_h2 = data[li]['h2']
    X_gl = data[li]['gl']
    R_pls = Residuals @ Py
    R_att = R_pls * 0.5
    R_ffn = R_pls * 0.5
    X_wln1_pls = X_wln1 @ Px
    Wv_pls = ridge(X_wln1_pls, R_att, lam=LAM)
    Wv_new = Px @ Wv_pls[:-1] @ Py.T
    w[f'Wv{s}'] = np.clip((1 - LR) * w[f'Wv{s}'] + LR * Wv_new, -CLIP, CLIP)
    X_ctx_pls = X_ctx @ Px
    Wo_pls = ridge(X_ctx_pls, R_att, lam=LAM)
    Wo_new = Px @ Wo_pls[:-1] @ Py.T
    w[f'Wo{s}'] = np.clip((1 - LR) * w[f'Wo{s}'] + LR * Wo_new, -CLIP, CLIP)
    bo_new = Py @ Wo_pls[-1]
    w[f'bo{s}'] = np.clip((1 - LR) * w[f'bo{s}'] + LR * bo_new, -CLIP, CLIP)
    R_ffn_full = R_ffn @ Py.T
    W2_pls = ridge(X_gl, R_ffn_full, lam=LAM)
    w[f'W2{s}'] = np.clip((1 - LR) * w[f'W2{s}'] + LR * W2_pls[:-1].T, -CLIP, CLIP)
    w[f'b2{s}'] = np.clip((1 - LR) * w[f'b2{s}'] + LR * W2_pls[-1], -CLIP, CLIP)
    X_h2_pls = X_h2 @ Px
    Y_pre = R_ffn_full @ w[f'W2{s}']
    W1_pls = ridge(X_h2_pls, Y_pre, lam=LAM)
    W1_new = Px @ W1_pls[:-1]
    w[f'W1{s}'] = np.clip((1 - LR) * w[f'W1{s}'] + LR * W1_new.T, -CLIP, CLIP)
    w[f'b1{s}'] = np.clip((1 - LR) * w[f'b1{s}'] + LR * W1_pls[-1], -CLIP, CLIP)
    return w

def measure_residuals(w):
    idx = len(tokens) // 3
    ids = tokens[idx:idx + SEQ_LEN]
    nxt = tokens[idx + SEQ_LEN]
    x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
    norms = [np.linalg.norm(WTE[nxt] - x[-1])]
    for li in range(N_LAYERS):
        x, _, _, _, _ = layer_fwd(x, li, w)
        norms.append(np.linalg.norm(WTE[nxt] - x[-1]) if np.all(np.isfinite(x[-1])) else 999.0)
    return norms
w = init()
p0 = calc_ppl(w)
print(f'\n  Random ppl = {p0:.2f}  (vocab={VS})\n')
print(f'  PLS: axes that POINT TOWARD target, not toward variance.')
print(f'  Every layer searches its own plotting direction.\n')
BATCH = 400
ROUNDS = 50
PLS_INTERVAL = 3
best_ppl = p0
best_w = {k: v.copy() for k, v in w.items()}
hist = [p0]
t0 = time.time()
print(f"  {'Rnd':<5} {'PPL':>8} {'Best':>8}  {'Residuals':>40}  Note")
print(f"  {'─' * 75}")
for rnd in range(ROUNDS):
    idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
    data = collect_frozen(w, idxs)
    if rnd % PLS_INTERVAL == 0:
        w = discover_pls(w, data)
        note = '[PLS search]'
    else:
        note = ''
    for li in range(N_LAYERS):
        w = solve_pls(li, w, data)
    p = calc_ppl(w)
    hist.append(p)
    norms = measure_residuals(w)
    mark = ''
    if np.isfinite(p) and p < best_ppl:
        best_ppl = p
        best_w = {k: v.copy() for k, v in w.items()}
        mark = ' ★'
    arr = '↓' if p < hist[-2] else '↑'
    rstr = ' → '.join((f'{n:.3f}' for n in norms))
    print(f'  {rnd + 1:<5} {p:>8.2f} {best_ppl:>8.2f}  [{rstr}]  {arr}{mark} {note}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  FINAL')
print(f"{'=' * 70}\n")
print(f'  Start  : {p0:.2f}')
print(f'  Best   : {best_ppl:.2f}')
print(f'  Vocab  : {VS}')
print(f'  Ratio  : {best_ppl / VS:.4f}')
print(f'  Reduce : {(1 - best_ppl / p0) * 100:.1f}%\n')
nf = measure_residuals(w)
labels = ['embed'] + [f'L{i}' for i in range(N_LAYERS)]
print(f'  Layer residual reduction:')
all_shrink = True
for i in range(len(nf) - 1):
    red = nf[i] - nf[i + 1]
    pct = 100 * red / nf[i] if nf[i] > 0 else 0
    sign = '✓' if red > 0 else '✗'
    if red <= 0:
        all_shrink = False
    print(f'    {labels[i]}→{labels[i + 1]}: {nf[i]:.4f}→{nf[i + 1]:.4f}  {red:+.4f} ({pct:.1f}%)  {sign}')
if all_shrink:
    print(f'\n  ✓ ALL LAYERS REDUCING RESIDUAL — multi-layer cooperation proven.')
else:
    print(f'\n  ~ Some layers still not cooperating.')
print(f'\n  PLS axis alignment (cos similarity to mean residual):')
idx = len(tokens) // 3
ids = tokens[idx:idx + SEQ_LEN]
nxt = tokens[idx + SEQ_LEN]
x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
for li in range(N_LAYERS):
    s = str(li)
    resid = WTE[nxt] - x[-1]
    Py = w[f'P_y{s}']
    proj = Py @ Py.T @ resid
    coverage = np.linalg.norm(proj) / (np.linalg.norm(resid) + 1e-08)
    print(f'    Layer {li}: PLS captures {coverage * 100:.1f}% of residual direction')
    x, _, _, _, _ = layer_fwd(x, li, w)
print(f'\n  GENERATION:\n')
for gp in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    ids_g = [vocab[c] for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(130):
        lg = full_fwd(gen[-SEQ_LEN:], w)
        if not np.all(np.isfinite(lg[-1])):
            break
        gen.append(int(np.argmax(lg[-1])))
    out = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  '{gp}' → {out[len(gp):][:70]}")
print(f'\n  Time: {time.time() - t0:.0f}s')
print(f"\n{'=' * 70}")
if best_ppl < VS * 0.5:
    print(f'  ✓✓ ppl={best_ppl:.1f} — SEQUENCE LEARNING. All layers cooperate.')
    print(f'     W-KERNEL + PLS + RESIDUAL BOOSTING = complete algorithm.')
elif best_ppl < VS:
    print(f'  ✓  ppl={best_ppl:.1f} < vocab={VS} — text signal learned, no gradient.')
    print(f'     PLS axes pointed toward target. Universe law confirmed.')
else:
    print(f'  ~  Partial. PLS alignment % tells where to look next.')
print('=' * 70 + '\n')
