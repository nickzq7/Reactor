import os, json, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
D_TINY = 8
STEPS = 2000
LR = 0.003

def arith(step, n=60):
    return [i * step % VS for i in range(n)]

def countdown(step, n=60):
    return [(VS - 1 - i * step) % VS for i in range(n)]

def fib(a, b, n=60):
    s = [a % VS, b % VS]
    while len(s) < n:
        s.append((s[-1] + s[-2]) % VS)
    return s

def geo(base, n=60):
    s = [1]
    for _ in range(n - 1):
        s.append(s[-1] * base % VS)
    return s

def poly(fn, n=60):
    return [fn(i) % VS for i in range(n)]

def skip(step, offset, n=60):
    return [(offset + i * step) % VS for i in range(n)]
MODEL_PATTERNS = [[('a1', arith(1)), ('a2', arith(2)), ('a3', arith(3)), ('a4', arith(4)), ('a5', arith(5)), ('a6', arith(6)), ('a7', arith(7)), ('a8', arith(8))], [('a9', arith(9)), ('a10', arith(10)), ('a11', arith(11)), ('a12', arith(12)), ('a13', arith(13)), ('a14', arith(14)), ('a15', arith(15)), ('a16', arith(16))], [('a17', arith(17)), ('a18', arith(18)), ('a19', arith(19)), ('a20', arith(20)), ('a21', arith(21)), ('a22', arith(22)), ('a23', arith(23)), ('a24', arith(24))], [('d1', countdown(1)), ('d2', countdown(2)), ('d3', countdown(3)), ('d4', countdown(4)), ('d5', countdown(5)), ('d6', countdown(6)), ('d7', countdown(7)), ('d8', countdown(8))], [('f1', fib(1, 2)), ('f2', fib(3, 7)), ('f3', fib(5, 11)), ('f4', fib(2, 9)), ('f5', fib(7, 13)), ('f6', fib(4, 15)), ('f7', fib(6, 17)), ('f8', fib(8, 19))], [('g2', geo(2)), ('g3', geo(3)), ('g4', geo(4)), ('g5', geo(5)), ('g6', geo(6)), ('g7', geo(7)), ('g9', geo(9)), ('g11', geo(11))], [('sq0', poly(lambda i: i * i)), ('sq1', poly(lambda i: (i + 1) * (i + 1))), ('sq2', poly(lambda i: (i + 2) * (i + 2))), ('sq3', poly(lambda i: (i + 3) * (i + 3))), ('sq4', poly(lambda i: (i + 4) * (i + 4))), ('sq5', poly(lambda i: (i + 5) * (i + 5))), ('sq6', poly(lambda i: (i + 6) * (i + 6))), ('sq7', poly(lambda i: (i + 7) * (i + 7)))], [('s3o0', skip(3, 0)), ('s3o1', skip(3, 1)), ('s3o2', skip(3, 2)), ('s3o3', skip(3, 3)), ('s5o0', skip(5, 0)), ('s5o1', skip(5, 1)), ('s5o2', skip(5, 2)), ('s5o3', skip(5, 3))]]
ALL_PATTERNS = [p for mp in MODEL_PATTERNS for p in mp]

class Transformer(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, H, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, x):
        B, T = x.shape
        h = self.wte(x) + self.wpe(torch.arange(T, device=x.device))
        mask = torch.triu(torch.full((T, T), float('-inf'), device=x.device), diagonal=1)
        for ly in self.layers:
            n = ly['ln1'](h)
            a, _ = ly['attn'](n, n, n, attn_mask=mask, need_weights=False)
            h = h + a
            h = h + ly['ff'](ly['ln2'](h))
        return self.ln_f(h) @ self.wte.weight.T

def build_data(patterns):
    X, Y = ([], [])
    for _, seq in patterns:
        for i in range(len(seq) - K):
            X.append(seq[i:i + K])
            Y.append(seq[i + 1:i + K + 1])
    return (torch.tensor(X, dtype=torch.long), torch.tensor(Y, dtype=torch.long))

def score(model, patterns):
    model.eval()
    rows = []
    for name, seq in patterns:
        ctx = torch.tensor([seq[:K]], dtype=torch.long)
        truth = seq[K]
        with torch.no_grad():
            pred = int(model(ctx)[0, -1].argmax())
        rows.append((name, pred, truth, pred == truth))
    return rows
loss_fn = nn.CrossEntropyLoss()
print('=' * 60)
print('  PHASE 2 — MUTATION TRANSFER')
print(f'  8 donors (D={D}) → tiny model (D={D_TINY})')
print('=' * 60)
donors = []
for i in range(8):
    path = os.path.join(_dir, f'donor_{i:02d}.npz')
    assert os.path.exists(path), f'donor_{i:02d}.npz not found'
    data = np.load(path, allow_pickle=True)
    m = Transformer(D)
    m.load_state_dict({k: torch.tensor(data[k]) for k in data.files})
    m.eval()
    donors.append(m)
    sc = sum((ok for *_, ok in score(m, MODEL_PATTERNS[i])))
    print(f'  Donor {i + 1} loaded: {sc}/8')
print('\n  STEP 1: Computing tension (28 pairwise comparisons)...')

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]
wtes = [d.wte.weight.detach().numpy() for d in donors]
ref = wtes[0]
proj = [wte @ solve(wte, ref) for wte in wtes]
N = len(proj)
agreements = []
for i in range(N):
    for j in range(i + 1, N):
        ag = np.sum(proj[i] * proj[j], axis=0)
        agreements.append(ag)
agreements = np.array(agreements)
mean_ag = agreements.mean(0)
tension = agreements.std(0)
combined = mean_ag + tension
flip_dims = np.argsort(combined)[-6:]
print(f'  Tension per dim (top 6 → flip):')
print(f"  {'dim':>4}  {'mean_ag':>9}  {'tension':>9}  {'combined':>9}  {'flip':>6}")
for d in np.argsort(combined)[::-1][:8]:
    mark = '<-- FLIP' if d in flip_dims else ''
    print(f'  {d:>4}  {mean_ag[d]:>9.4f}  {tension[d]:>9.4f}  {combined[d]:>9.4f}  {mark}')
print(f'\n  STEP 2: Orthogonalize + compress to D={D_TINY}...')
WTE_mean = np.mean(proj, axis=0).copy()
WTE_mean[:, flip_dims] *= -1
U, s, Vt = np.linalg.svd(WTE_mean, full_matrices=False)
WTE_init = (U[:, :D_TINY] * s[:D_TINY]).astype(np.float32)
print(f'  Embedding compressed: ({VS},{D}) → ({VS},{D_TINY})')
print(f'  Flip dims: {sorted(flip_dims.tolist())}')
print(f'  Singular values kept: {s[:D_TINY].round(3)}')
print(f'\n  STEP 3: Training tiny model from mutated embedding...')
print(f'  It already speaks the invariant language of all 8 donors.')
print()
torch.manual_seed(42)
np.random.seed(42)
tiny = Transformer(D_TINY)
for nm, p in tiny.named_parameters():
    if p.dim() > 1:
        nn.init.xavier_uniform_(p)
    else:
        nn.init.zeros_(p)
with torch.no_grad():
    tiny.wte.weight.copy_(torch.tensor(WTE_init))
X_all, Y_all = build_data(ALL_PATTERNS)
opt = torch.optim.Adam(tiny.parameters(), lr=LR)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=STEPS, eta_min=1e-05)
best_total = 0
best_state = None
t0 = time.time()
for step in range(1, STEPS + 1):
    tiny.train()
    opt.zero_grad()
    loss_fn(tiny(X_all).view(-1, VS), Y_all.view(-1)).backward()
    nn.utils.clip_grad_norm_(tiny.parameters(), 1.0)
    opt.step()
    sched.step()
    if step % 200 == 0:
        tiny.eval()
        total = 0
        per_donor = []
        for patterns_i in MODEL_PATTERNS:
            sc = sum((ok for *_, ok in score(tiny, patterns_i)))
            total += sc
            per_donor.append(sc)
        if total > best_total:
            best_total = total
            best_state = {k: v.clone() for k, v in tiny.state_dict().items()}
        print(f'  step {step:>5}: {total}/64  {per_donor}', flush=True)
if best_state:
    tiny.load_state_dict(best_state)
print('\n' + '=' * 60)
print('  FINAL RESULTS')
print('=' * 60)
groups = ['arith 1-8', 'arith 9-16', 'arith 17-24', 'countdown', 'fibonacci', 'geometric', 'polynomial', 'skip+offset']
grand_total = 0
for mi, (patterns_i, g) in enumerate(zip(MODEL_PATTERNS, groups)):
    rows = score(tiny, patterns_i)
    sc = sum((ok for *_, ok in rows))
    grand_total += sc
    bar = '█' * sc + '░' * (8 - sc)
    print(f'  Donor {mi + 1}  {bar}  {sc}/8  ({g})')
    for name, pred, truth, ok in rows:
        print(f"    {('OK' if ok else '--')}  {name:<8} pred={pred:>2} truth={truth:>2}")
donor_params = sum((p.numel() for p in donors[0].parameters()))
tiny_params = sum((p.numel() for p in tiny.parameters()))
print(f'\n  Donor size:  {donor_params} params x 8 = {donor_params * 8} total\n  Tiny size:   {tiny_params} params\n  Compression: {donor_params * 8 // tiny_params}x smaller\n\n  Intelligence transferred: {grand_total}/64  ({grand_total / 64 * 100:.0f}%)\n  Time: {time.time() - t0:.1f}s\n')
print('=' * 60)
