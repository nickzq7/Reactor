import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — THE SEMANTIC WARP ENGINE')
print('  Bypassing all layers via Embedding -> GeLU Shortcut.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print('\n  [ Phase 1 ] Calibrating the Semantic Warp (Embedding -> Layer 7)...')
RAM_bits = []
RAM_tokens = []
EMBED_IN = []
GELU_L7_OUT = []

def hook_l7_pre(m, i, o):
    GELU_L7_OUT.append(o[:, -1, :].detach().cpu().numpy())
h = model.transformer.h[7].mlp.c_fc.register_forward_hook(hook_l7_pre)
seed_prompts = ['Once upon a time, a little girl named Lily', 'The brave knight took his sword and', 'Deep in the forest there was a', 'A small rabbit lived in a hole', 'The sun was very hot and the']
with torch.no_grad():
    for s in seed_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        for _ in range(25):
            emb = model.transformer.wte(ids[:, -1]) + model.transformer.wpe(torch.tensor([ids.size(1) - 1]))
            EMBED_IN.append(emb.detach().cpu().numpy())
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            bits = (GELU_L7_OUT[-1][0] > 0).astype(int)
            RAM_bits.append(bits)
            RAM_tokens.append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
h.remove()
RAM_bits = np.array(RAM_bits)
RAM_tokens = np.array(RAM_tokens)
X = np.concatenate(EMBED_IN, axis=0)
X_b = np.c_[X, np.ones(X.shape[0])]
Y = np.concatenate(GELU_L7_OUT, axis=0)
W_warp = np.linalg.lstsq(X_b, Y, rcond=None)[0]
print(f'  ✓ Semantic Warp Matrix extracted. (Samples={len(X)})')
print(f'  ✓ Semantic RAM Bank loaded with {len(RAM_tokens)} paths.')
print('  Extracting Native W-Matrices for Fallback Engine...')
W_layers = {}
with torch.no_grad():
    for l in range(n_layers):
        block = model.transformer.h[l]
        W_layers[l] = {'q': block.attn.attention.q_proj.weight.detach().numpy().T, 'k': block.attn.attention.k_proj.weight.detach().numpy().T, 'v': block.attn.attention.v_proj.weight.detach().numpy().T, 'o': block.attn.attention.out_proj.weight.detach().numpy().T, 'b_o': block.attn.attention.out_proj.bias.detach().numpy(), '1': block.mlp.c_fc.weight.detach().numpy().T, 'b_1': block.mlp.c_fc.bias.detach().numpy(), '2': block.mlp.c_proj.weight.detach().numpy().T, 'b_2': block.mlp.c_proj.bias.detach().numpy(), 'ln1_w': block.ln_1.weight.detach().numpy(), 'ln1_b': block.ln_1.bias.detach().numpy(), 'ln2_w': block.ln_2.weight.detach().numpy(), 'ln2_b': block.ln_2.bias.detach().numpy()}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_head_w = model.lm_head.weight.detach().numpy()

def layernorm_np(x, gamma, beta, eps=1e-05):
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (x - mean) / np.sqrt(var + 1e-05) * gamma + beta

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
test_prompt = 'The brave knight took his sword and'
np_ids = tokenizer.encode(test_prompt)
print('\n' + '─' * 70)
print(f'  [ Phase 2 ] SEMANTIC WARP GENERATION')
print(f'  Output: ', end='')
tokens_to_generate = 20
layers_skipped = 0
start_time = time.time()
for step in range(tokens_to_generate):
    curr_idx = np_ids[-1]
    pos_idx = len(np_ids) - 1
    emb = wte[curr_idx] + wpe[pos_idx]
    emb_b = np.append(emb, 1.0)
    warp_projection = emb_b @ W_warp
    warp_bits = (warp_projection > 0).astype(int)
    matches = np.sum(RAM_bits == warp_bits, axis=1)
    best_match = np.max(matches)
    if best_match == 256:
        best_idx = np.argmax(matches)
        next_id = int(RAM_tokens[best_idx])
        layers_skipped += n_layers
        print(tokenizer.decode([next_id]), end='', flush=True)
        np_ids.append(next_id)
        continue
    seq_len = len(np_ids)
    x = wte[np_ids] + wpe[np.arange(seq_len)]
    for l in range(n_layers):
        W = W_layers[l]
        ln1 = layernorm_np(x, W['ln1_w'], W['ln1_b'])
        q = ln1 @ W['q']
        k = ln1 @ W['k']
        v = ln1 @ W['v']
        q_heads = q.reshape(seq_len, 16, 4).transpose(1, 0, 2)
        k_heads = k.reshape(seq_len, 16, 4).transpose(1, 0, 2)
        v_heads = v.reshape(seq_len, 16, 4).transpose(1, 0, 2)
        att_out = []
        for h in range(16):
            scr = q_heads[h] @ k_heads[h].T
            msk = np.triu(np.full((seq_len, seq_len), -1000000000.0), 1)
            att_out.append(softmax_np(scr + msk) @ v_heads[h])
        concat = np.array(att_out).transpose(1, 0, 2).reshape(seq_len, D)
        x = x + (concat @ W['o'] + W['b_o'])
        ln2 = layernorm_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['1'] + W['b_1']
        x = x + (np.maximum(0, pre) @ W['2'] + W['b_2'])
    logits = layernorm_np(x[-1:], lnf_w, lnf_b) @ lm_head_w.T
    next_id = int(np.argmax(logits[0]))
    np_ids.append(next_id)
    print(tokenizer.decode([next_id]), end='', flush=True)
gen_time = time.time() - start_time
print('\n\n' + '=' * 70)
print(f'  Generation Time  : {gen_time:.4f} seconds')
print(f'  Total Layers Skipped : {layers_skipped}')
print(f'  Efficiency Gain      : {layers_skipped / (tokens_to_generate * n_layers) * 100:.1f}%')
print('=' * 70 + '\n')
