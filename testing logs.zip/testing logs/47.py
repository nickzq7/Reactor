import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_ID = 'roneneldan/TinyStories-1M'
GEN_TOKENS = 50
PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'In the forest there lived a', 'Tom and his friend went to the', 'The big red ball']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('=' * 65)
print('  LOAD MODEL')
print('=' * 65)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
model = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = model.config
NL = cfg.num_layers
H = cfg.hidden_size
NH = cfg.num_heads
HD = H // NH
VOCAB = cfg.vocab_size
W = {}
for li in range(NL):
    bl = model.transformer.h[li]
    at = bl.attn.attention
    W[li] = {'ln1_g': bl.ln_1.weight.detach().float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.detach().float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.detach().float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.detach().float().cpu().numpy(), 'W_q': at.q_proj.weight.detach().float().cpu().numpy(), 'W_k': at.k_proj.weight.detach().float().cpu().numpy(), 'W_v': at.v_proj.weight.detach().float().cpu().numpy(), 'W_o': at.out_proj.weight.detach().float().cpu().numpy(), 'b_o': at.out_proj.bias.detach().float().cpu().numpy(), 'W1': bl.mlp.c_fc.weight.detach().float().cpu().numpy(), 'b1': bl.mlp.c_fc.bias.detach().float().cpu().numpy(), 'W2': bl.mlp.c_proj.weight.detach().float().cpu().numpy(), 'b2': bl.mlp.c_proj.bias.detach().float().cpu().numpy()}
    try:
        W[li]['attn_type'] = cfg.attention_layers[li]
    except:
        W[li]['attn_type'] = 'global'
    try:
        W[li]['window'] = cfg.window_size
    except:
        W[li]['window'] = 256
Wte = model.transformer.wte.weight.detach().float().cpu().numpy()
Wpe = model.transformer.wpe.weight.detach().float().cpu().numpy()
lnf_g = model.transformer.ln_f.weight.detach().float().cpu().numpy()
lnf_b = model.transformer.ln_f.bias.detach().float().cpu().numpy()
Wlm = model.lm_head.weight.detach().float().cpu().numpy()
print(f'  Extracted {NL} layers. H={H} NH={NH} HD={HD} VOCAB={VOCAB}')

def ln(x, g, b):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (g * (x - mean) / np.sqrt(var + 1e-05) + b).astype(np.float32)

def gelu_np(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def crystal_layer(h, li, kv_cache=None):
    sl = h.shape[0]
    w = W[li]
    ln1 = ln(h, w['ln1_g'], w['ln1_b'])
    Q = (ln1 @ w['W_q'].T).astype(np.float32)
    K = (ln1 @ w['W_k'].T).astype(np.float32)
    V = (ln1 @ w['W_v'].T).astype(np.float32)
    if kv_cache is not None:
        K_full = np.concatenate([kv_cache['K'], K], axis=0)
        V_full = np.concatenate([kv_cache['V'], V], axis=0)
    else:
        K_full, V_full = (K, V)
    past_len = K_full.shape[0] - sl
    full_len = K_full.shape[0]
    head_ctxs = []
    for hh in range(NH):
        s, e = (hh * HD, hh * HD + HD)
        scores = (Q[:, s:e] @ K_full[:, s:e].T).astype(np.float32)
        mask = np.full((sl, full_len), -1000000000.0, dtype=np.float32)
        for i in range(sl):
            i_abs = past_len + i
            start = max(0, i_abs - w['window'] + 1) if w['attn_type'] == 'local' else 0
            mask[i, start:i_abs + 1] = 0.0
        probs = softmax_np(scores + mask)
        head_ctxs.append((probs @ V_full[:, s:e]).astype(np.float32))
    ctx = np.concatenate(head_ctxs, axis=-1).astype(np.float32)
    att_out = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
    h_mid = (h + att_out).astype(np.float32)
    ln2 = ln(h_mid, w['ln2_g'], w['ln2_b'])
    pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
    act = gelu_np(pre)
    ffn_out = (act @ w['W2'].T + w['b2']).astype(np.float32)
    return ((h_mid + ffn_out).astype(np.float32), K, V)

def crystal_forward(input_ids, kv_caches=None):
    ids = np.array(input_ids, dtype=np.int32)
    sl = len(ids)
    pos_start = 0 if kv_caches is None else kv_caches[0]['K'].shape[0]
    h = (Wte[ids] + Wpe[np.arange(pos_start, pos_start + sl)]).astype(np.float32)
    new_caches = []
    for li in range(NL):
        cache = kv_caches[li] if kv_caches else None
        h, K_new, V_new = crystal_layer(h, li, cache)
        if kv_caches:
            new_caches.append({'K': np.concatenate([kv_caches[li]['K'], K_new], 0), 'V': np.concatenate([kv_caches[li]['V'], V_new], 0)})
        else:
            new_caches.append({'K': K_new, 'V': V_new})
    h_final = ln(h, lnf_g, lnf_b)
    return ((h_final @ Wlm.T).astype(np.float32), new_caches)

def build_self_path_table():
    print('\n' + '=' * 65)
    print('  BUILDING SELF-PATH TABLE (Law 26)')
    print('=' * 65)
    t0 = time.perf_counter()
    h = (Wte + Wpe[0]).astype(np.float32)
    print(f'  Vocab tokens: {VOCAB}  Hidden: {H}')
    print(f'  Processing {NL} layers (FFN only, no attention)...')
    for li in range(NL):
        w = W[li]
        ln2 = ln(h, w['ln2_g'], w['ln2_b'])
        pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
        act = gelu_np(pre)
        ffn_out = (act @ w['W2'].T + w['b2']).astype(np.float32)
        h = (h + ffn_out).astype(np.float32)
        print(f'    Layer {li}: done  ||ffn_out||={np.linalg.norm(ffn_out, axis=-1).mean():.4f}')
    elapsed = time.perf_counter() - t0
    mem_mb = h.nbytes / 1000000.0
    print(f'\n  Self-path table: shape={h.shape}  size={mem_mb:.1f}MB  built in {elapsed:.2f}s')
    return h

def crystal_layer_fast(h, li, kv_cache, self_path_delta):
    sl = h.shape[0]
    w = W[li]
    ln1 = ln(h, w['ln1_g'], w['ln1_b'])
    Q = (ln1 @ w['W_q'].T).astype(np.float32)
    K = (ln1 @ w['W_k'].T).astype(np.float32)
    V = (ln1 @ w['W_v'].T).astype(np.float32)
    K_full = np.concatenate([kv_cache['K'], K], axis=0)
    V_full = np.concatenate([kv_cache['V'], V], axis=0)
    past_len = K_full.shape[0] - sl
    full_len = K_full.shape[0]
    head_ctxs = []
    for hh in range(NH):
        s, e = (hh * HD, hh * HD + HD)
        scores = (Q[:, s:e] @ K_full[:, s:e].T).astype(np.float32)
        mask = np.full((sl, full_len), -1000000000.0, dtype=np.float32)
        for i in range(sl):
            i_abs = past_len + i
            start = max(0, i_abs - w['window'] + 1) if w['attn_type'] == 'local' else 0
            mask[i, start:i_abs + 1] = 0.0
        probs = softmax_np(scores + mask)
        head_ctxs.append((probs @ V_full[:, s:e]).astype(np.float32))
    ctx = np.concatenate(head_ctxs, axis=-1).astype(np.float32)
    att_out = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
    h_mid = (h + att_out).astype(np.float32)
    h_out = (h_mid + self_path_delta).astype(np.float32)
    return (h_out, K, V)

def crystal_forward_fast(input_ids, kv_caches, self_path_table, token_ids_for_sp):
    ids = np.array(input_ids, dtype=np.int32)
    sp_ids = np.array(token_ids_for_sp, dtype=np.int32)
    sl = len(ids)
    pos_start = kv_caches[0]['K'].shape[0]
    h = (Wte[ids] + Wpe[np.arange(pos_start, pos_start + sl)]).astype(np.float32)
    sp_total = self_path_table[sp_ids]
    new_caches = []
    for li in range(NL):
        sp_delta = (sp_total / NL).astype(np.float32)
        cache = kv_caches[li]
        h, K_new, V_new = crystal_layer_fast(h, li, cache, sp_delta)
        new_caches.append({'K': np.concatenate([kv_caches[li]['K'], K_new], 0), 'V': np.concatenate([kv_caches[li]['V'], V_new], 0)})
    h_final = ln(h, lnf_g, lnf_b)
    return ((h_final @ Wlm.T).astype(np.float32), new_caches)

def generate_pytorch(prompt, n_tokens):
    ids = tok(prompt, return_tensors='pt')['input_ids'].to(device)
    t0 = time.perf_counter()
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=n_tokens, do_sample=False, use_cache=True, return_dict_in_generate=True, output_scores=True)
    elapsed = time.perf_counter() - t0
    return (out.sequences[0][ids.shape[1]:].cpu().tolist(), elapsed)

def generate_crystal_kv(prompt, n_tokens):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    t0 = time.perf_counter()
    logits, caches = crystal_forward(ids, kv_caches=None)
    next_id = int(np.argmax(logits[-1]))
    new_ids = [next_id]
    for _ in range(n_tokens - 1):
        logits, caches = crystal_forward([next_id], kv_caches=caches)
        next_id = int(np.argmax(logits[-1]))
        new_ids.append(next_id)
    return (new_ids, time.perf_counter() - t0)

def generate_fast(prompt, n_tokens, self_path_table):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    t0 = time.perf_counter()
    logits, caches = crystal_forward(ids, kv_caches=None)
    next_id = int(np.argmax(logits[-1]))
    new_ids = [next_id]
    for _ in range(n_tokens - 1):
        logits, caches = crystal_forward_fast([next_id], caches, self_path_table, [next_id])
        next_id = int(np.argmax(logits[-1]))
        new_ids.append(next_id)
    return (new_ids, time.perf_counter() - t0)
self_path_table = build_self_path_table()
print('\n' + '=' * 65)
print('  BENCHMARK: PyTorch vs Crystal+KV vs Crystal+KV+SelfPath')
print('=' * 65)
print(f'  Prompts: {len(PROMPTS)}  Tokens: {GEN_TOKENS} each\n')
_ = generate_pytorch(PROMPTS[0], 3)
_ = generate_crystal_kv(PROMPTS[0], 3)
_ = generate_fast(PROMPTS[0], 3, self_path_table)
results = []
for pi, prompt in enumerate(PROMPTS):
    print(f'  ── Prompt {pi + 1}: "{prompt[:45]}"')
    ids_pt, t_pt = generate_pytorch(prompt, GEN_TOKENS)
    ids_kv, t_kv = generate_crystal_kv(prompt, GEN_TOKENS)
    ids_fast, t_fast = generate_fast(prompt, GEN_TOKENS, self_path_table)
    ms_pt = t_pt / GEN_TOKENS * 1000
    ms_kv = t_kv / GEN_TOKENS * 1000
    ms_fast = t_fast / GEN_TOKENS * 1000
    match_kv = sum((a == b for a, b in zip(ids_pt, ids_kv)))
    match_fast = sum((a == b for a, b in zip(ids_pt, ids_fast)))
    txt_pt = tok.decode(ids_pt)
    txt_kv = tok.decode(ids_kv)
    txt_fast = tok.decode(ids_fast)
    print(f'    PyTorch      : {ms_pt:6.2f} ms/tok  {1000 / ms_pt:5.0f} tok/s')
    print(f'    Crystal+KV   : {ms_kv:6.2f} ms/tok  {1000 / ms_kv:5.0f} tok/s  x{ms_pt / ms_kv:.2f}  match={match_kv}/{GEN_TOKENS}')
    print(f'    +SelfPath    : {ms_fast:6.2f} ms/tok  {1000 / ms_fast:5.0f} tok/s  x{ms_pt / ms_fast:.2f}  match={match_fast}/{GEN_TOKENS}')
    print(f'\n    PT  : {repr(txt_pt[:70])}')
    print(f'    KV  : {repr(txt_kv[:70])}')
    print(f'    Fast: {repr(txt_fast[:70])}\n')
    results.append({'ms_pt': ms_pt, 'ms_kv': ms_kv, 'ms_fast': ms_fast, 'match_kv': match_kv, 'match_fast': match_fast})
print('=' * 65)
print('  SUMMARY')
print('=' * 65)
avg_pt = np.mean([r['ms_pt'] for r in results])
avg_kv = np.mean([r['ms_kv'] for r in results])
avg_fast = np.mean([r['ms_fast'] for r in results])
avg_mk = np.mean([r['match_kv'] for r in results])
avg_mf = np.mean([r['match_fast'] for r in results])
print(f"\n  {'Method':<22} {'ms/tok':>8}  {'tok/s':>8}  {'speedup':>9}  {'match':>8}")
print(f"  {'-' * 60}")
print(f"  {'PyTorch GPU+cache':<22} {avg_pt:8.2f}  {1000 / avg_pt:8.0f}  {'baseline':>9}  {'100%':>8}")
print(f"  {'Crystal+KV':<22} {avg_kv:8.2f}  {1000 / avg_kv:8.0f}  {avg_pt / avg_kv:>8.2f}x  {avg_mk / GEN_TOKENS * 100:>7.1f}%")
print(f"  {'Crystal+KV+SelfPath':<22} {avg_fast:8.2f}  {1000 / avg_fast:8.0f}  {avg_pt / avg_fast:>8.2f}x  {avg_mf / GEN_TOKENS * 100:>7.1f}%")
print(f'\n  LAW 26 ANALYSIS:\n  ─────────────────\n  Self-path table: {self_path_table.shape}  {self_path_table.nbytes / 1000000.0:.1f}MB\n  Built once, reused for all generation.\n\n  Match% < 100% for SelfPath = expected approximation cost.\n  The 76% self-path is NOT perfectly separable from attention —\n  FFN takes ln2(h + att_out) not ln2(h). Small coupling exists.\n\n  NEXT: store per-layer FFN deltas separately.\n  This gives exact self-path separation and should restore 100% match\n  while keeping the speed gain.\n\n  Current speedup stack:\n    KV cache alone  : {avg_pt / avg_kv:.2f}x\n    + SelfPath table: {avg_pt / avg_fast:.2f}x\n    Combined gain   : {avg_kv / avg_fast:.2f}x from self-path on top of KV\n')
