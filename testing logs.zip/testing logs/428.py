import numpy as np
import torch
import os
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
vocab = model.config.vocab_size
print(f'D={D}  Layers={n_layers}  Vocab={vocab}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_W(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at', 'The wind was cold', 'A little rabbit hopped', 'The brave knight rode', 'She woke up and', 'He could not find', 'The magic door opened', 'They walked together through', 'The small house had', 'A star fell from', 'He whispered to her']
print(f'\nGenerating {len(seeds) * 6} training texts...')
train_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(6):
            torch.manual_seed(i * 60 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=45, do_sample=True, temperature=0.8 + j * 0.04, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(train_texts)} texts.')
H0_list = []
HF_list = []

def hook_h0(m, inp, out):
    x = inp[0].detach().float()
    for t in range(x.shape[1]):
        H0_list.append(x[0, t].numpy().copy())

def hook_hf(m, inp, out):
    x = (out[0] if isinstance(out, tuple) else out).detach().float()
    for t in range(x.shape[1]):
        HF_list.append(x[0, t].numpy().copy())
h1 = model.transformer.h[0].register_forward_hook(hook_h0)
h2 = model.transformer.h[n_layers - 1].register_forward_hook(hook_hf)
print(f'Running {len(train_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(train_texts):
        if i % 40 == 0:
            print(f'  {i}/{len(train_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
h1.remove()
h2.remove()
H0 = np.array(H0_list, dtype=np.float32)
HF = np.array(HF_list, dtype=np.float32)
print(f'\nCollected: H0={H0.shape}  HF={HF.shape}')
print(f'Fitting W_kernel (h_0 → h_final)...')
n = len(H0)
s = int(n * 0.8)
W_kernel = fit_W(H0[:s], HF[:s])
Xb = np.c_[H0, np.ones(n, dtype=np.float32)]
r2_train = r2(Xb[:s] @ W_kernel, HF[:s])
r2_test = r2(Xb[s:] @ W_kernel, HF[s:])
print(f'  R² train: {r2_train:.6f}')
print(f'  R² test:  {r2_test:.6f}')
print(f'  W_kernel shape: {W_kernel.shape}  ({W_kernel.shape[0] * W_kernel.shape[1] * 4 / 1024:.1f} KB)')
kpath = 'w_kernel.npz'
np.savez(kpath, W_kernel=W_kernel, lm_head=model.lm_head.weight.detach().float().numpy(), wte=model.transformer.wte.weight.detach().float().numpy(), wpe=model.transformer.wpe.weight.detach().float().numpy(), ln_f_w=model.transformer.ln_f.weight.detach().float().numpy(), ln_f_b=model.transformer.ln_f.bias.detach().float().numpy())
size_kb = os.path.getsize(kpath) / 1024
model_params = sum((p.numel() for p in model.parameters()))
print(f'\n  Kernel saved: {kpath}')
print(f'  Kernel size:  {size_kb:.1f} KB')
print(f'  Model params: {model_params:,}  ({model_params * 4 / 1024:.0f} KB)')
print(f'  Size ratio:   {size_kb / (model_params * 4 / 1024) * 100:.1f}% of full model')
t0 = time.time()
K = np.load(kpath)
W_k = K['W_kernel']
lm_W = K['lm_head']
wte = K['wte']
wpe = K['wpe']
lnfw = K['ln_f_w']
lnfb = K['ln_f_b']
load_ms = (time.time() - t0) * 1000
print(f'  Kernel load:  {load_ms:.1f} ms  ← instant')

def ln_np(x, w, b, eps=1e-05):
    return (x - np.mean(x)) / (np.std(x) + eps) * w + b

def kernel_next(token_id, pos):
    h0 = wte[token_id] + wpe[min(pos, wpe.shape[0] - 1)]
    hf = np.append(h0, 1.0) @ W_k
    return ln_np(hf, lnfw, lnfb) @ lm_W.T

def gen_kernel(prompt, max_new=60):
    ids = tokenizer.encode(prompt)
    out = []
    for _ in range(max_new):
        logits = kernel_next(ids[-1], len(ids) - 1)
        tok = int(np.argmax(logits))
        out.append(tok)
        ids.append(tok)
        if tok == tokenizer.eos_token_id:
            break
    return out

def gen_normal(prompt, max_new=60):
    inp = tokenizer.encode(prompt, return_tensors='pt')
    out = []
    cur = inp.clone()
    with torch.no_grad():
        for _ in range(max_new):
            tok = int(torch.argmax(model(cur).logits[0, -1, :]).item())
            out.append(tok)
            cur = torch.cat([cur, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return out
prompts = ['Once upon a time there was a little girl who loved to', 'The little boy found a magic', 'She looked at the stars and', 'The dog ran into the forest and', 'One day a small rabbit']
print(f"\n{'=' * 70}")
print(f'  W KERNEL — GENERATION TEST')
print(f'  Normal:  8 layers + attention + FFN')
print(f'  Kernel:  embed → W_kernel → lm_head  (ONE matrix)')
print(f'  R² test: {r2_test:.6f}')
print(f"{'=' * 70}")
total_m = 0
total_n = 0
for prompt in prompts:
    nt = gen_normal(prompt)
    kt = gen_kernel(prompt)
    n = min(len(nt), len(kt))
    m = sum((1 for i in range(n) if nt[i] == kt[i]))
    total_m += m
    total_n += n
    acc = m / n if n > 0 else 0
    print(f'\n  PROMPT:  {prompt}')
    print(f'  NORMAL:  {tokenizer.decode(nt, skip_special_tokens=True)[:130]}')
    print(f'  KERNEL:  {tokenizer.decode(kt, skip_special_tokens=True)[:130]}')
    print(f'  Match:   {acc:.1%}  ({m}/{n})')
print(f"\n{'=' * 70}")
print(f'  OVERALL:      {total_m / total_n:.1%}  ({total_m}/{total_n})')
print(f'  R² kernel:    {r2_test:.4f}')
print(f'  Kernel size:  {size_kb:.1f} KB  (load: {load_ms:.1f} ms)')
print(f"{'=' * 70}")
print(f'\n  READING THE RESULT:\n\n  R² and match:\n    1.000 / 100%: kernel = exact replacement. 8 layers = 1 matrix.\n    0.9+ / 70%+:  strong. Context adds small correction. Near-kernel.\n    0.7+ / 30%+:  partial. Kernel captures base pattern.\n                  Attention context adds the rest.\n    <0.5  / <20%: h_0 alone not enough. Need context in kernel.\n\n  If kernel text is coherent but different from normal:\n    Kernel learned a valid language model.\n    Different from normal = no cross-token context.\n    This IS W-kernel behavior. Not failure.\n    Single-token kernel = context-free language model.\n\n  If kernel text repeats one token:\n    R² too low. Need more training data.\n    Or: need positional kernel (h_0 + pos → h_final).\n\n  KERNEL FILE:\n    w_kernel.npz = loads in milliseconds.\n    No model needed. No transformers. No torch.\n    Just numpy + one file.\n    This is what instant loading means.\n')
print('=' * 70 + '\n')
