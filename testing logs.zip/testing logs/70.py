import numpy as np
import torch
import torch.nn as nn
import time
from scipy import stats
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
DIM = 16
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(1000)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

def build_W(geo, out_dim, in_dim):
    if geo == 'flat':
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    elif geo == 'uniform':
        arr = np.linspace(-1, 1, out_dim).astype(np.float32)
    elif geo == 'triangular':
        arr = np.array([i * (i + 1) / 2 for i in range(1, out_dim + 1)], dtype=np.float32)
    elif geo == 'sqrt':
        arr = np.array([np.sqrt(i + 1) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'exp':
        arr = np.array([np.exp(i / out_dim) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'prime':
        arr = np.array(BEST_PRIMES[:out_dim], dtype=np.float32)
    elif geo == 'log':
        arr = np.array([np.log(i + 2) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'powers2':
        arr = np.array([2.0 ** i for i in range(out_dim)], dtype=np.float32)
    else:
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
    arr = arr / (np.max(np.abs(arr)) + 1e-08)
    W = np.zeros((out_dim, in_dim), dtype=np.float32)
    for col in range(in_dim):
        W[:, col] = arr * (col + 1) / in_dim
    return W
PIPELINE = ['uniform', 'triangular', 'sqrt', 'exp', 'prime', 'uniform']

def pipeline_geo(layer_idx):
    return PIPELINE[layer_idx % len(PIPELINE)]

class ResBlock(nn.Module):

    def __init__(self, dim, geo, layer_idx=0):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        with torch.no_grad():
            self.linear.weight.copy_(torch.tensor(build_W(geo, dim, dim)))
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class DeepNet(nn.Module):

    def __init__(self, n_hidden, geo_fn, use_residual=True, dim=DIM):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(SEQ_LEN, dim), nn.Tanh())
        with torch.no_grad():
            self.input_proj[0].weight.copy_(torch.tensor(build_W(geo_fn(0), dim, SEQ_LEN)))
        self.blocks = nn.ModuleList()
        for i in range(n_hidden):
            geo = geo_fn(i + 1)
            if use_residual:
                self.blocks.append(ResBlock(dim, geo, i))
            else:
                blk = nn.Sequential(nn.Linear(dim, dim), nn.Tanh())
                with torch.no_grad():
                    blk[0].weight.copy_(torch.tensor(build_W(geo, dim, dim)))
                self.blocks.append(blk)
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for blk in self.blocks:
            x = blk(x)
        return self.output(x)

def train(model, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-06)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN at ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model)
            print(f'    {label:<22} ep{ep:>5}  loss={best:>10.4f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 3000
N_HIDDEN = 48
print_sep('MODEL A — 50-layer FLAT PLAIN (baseline)')
np.random.seed(42)
m_A = DeepNet(N_HIDDEN, lambda i: 'flat', use_residual=False).to(device)
print(f'  Params: {sum((p.numel() for p in m_A.parameters())):,}')
l_A, log_A = train(m_A, EPOCHS, lr=0.001, label='A:flat-plain')
s_A = score(m_A)
print_sep('MODEL B — 50-layer FLAT + RESIDUAL')
np.random.seed(42)
m_B = DeepNet(N_HIDDEN, lambda i: 'flat', use_residual=True).to(device)
print(f'  Params: {sum((p.numel() for p in m_B.parameters())):,}')
l_B, log_B = train(m_B, EPOCHS, lr=0.001, label='B:flat-residual')
s_B = score(m_B)
print_sep('MODEL C — 50-layer PIPELINE PLAIN (no residual)')
np.random.seed(42)
m_C = DeepNet(N_HIDDEN, pipeline_geo, use_residual=False).to(device)
print(f'  Params: {sum((p.numel() for p in m_C.parameters())):,}')
l_C, log_C = train(m_C, EPOCHS, lr=0.001, label='C:pipe-plain')
s_C = score(m_C)
print_sep('MODEL D — 50-layer PIPELINE + RESIDUAL (main hypothesis)')
np.random.seed(42)
m_D = DeepNet(N_HIDDEN, pipeline_geo, use_residual=True).to(device)
print(f'  Params: {sum((p.numel() for p in m_D.parameters())):,}')
l_D, log_D = train(m_D, EPOCHS, lr=0.001, label='D:pipe-residual')
s_D = score(m_D)
print_sep('MODEL E — 10-layer FLAT (proven 20/20 reference)')
np.random.seed(42)
m_E = DeepNet(8, lambda i: 'flat', use_residual=False).to(device)
print(f'  Params: {sum((p.numel() for p in m_E.parameters())):,}')
l_E, log_E = train(m_E, EPOCHS, lr=0.001, label='E:10layer-flat')
s_E = score(m_E)
print_sep('MODEL F — 10-layer PIPELINE + RESIDUAL')
np.random.seed(42)
m_F = DeepNet(8, pipeline_geo, use_residual=True).to(device)
print(f'  Params: {sum((p.numel() for p in m_F.parameters())):,}')
l_F, log_F = train(m_F, EPOCHS, lr=0.001, label='F:10layer-pipe-res')
s_F = score(m_F)
print_sep('CONVERGENCE COMPARISON')
CHECKPTS = [500, 1000, 1500, 2000, 2500, 3000]
logs = {'A': log_A, 'B': log_B, 'C': log_C, 'D': log_D, 'E': log_E, 'F': log_F}
print(f"\n  {'Epoch':>6}  {'A:flat':>10}  {'B:flat+res':>12}  {'C:pipe':>10}  {'D:pipe+res':>12}  {'E:10flat':>10}  {'F:10pipe+res':>13}")
print(f"  {'─' * 80}")
for ep in CHECKPTS:
    row = ''
    for key in ['A', 'B', 'C', 'D', 'E', 'F']:
        v = logs[key][min(ep - 1, len(logs[key]) - 1)]
        row += f'  {v:>12.2f}'
    print(f'  {ep:>6}{row}')
print_sep('GRADIENT FLOW ANALYSIS')

def measure_grad_flow(model, label):
    model.train()
    loss_fn = nn.MSELoss()
    l = loss_fn(model(X_tr[:32]), Y_tr[:32])
    l.backward()
    grad_norms = []
    for name, p in model.named_parameters():
        if p.grad is not None and 'weight' in name:
            grad_norms.append((name, p.grad.norm().item()))
    n = len(grad_norms)
    samples = [0, n // 4, n // 2, 3 * n // 4, n - 1]
    print(f'\n  {label}:')
    print(f"  {'Position':<12}  {'Layer':<35}  {'Grad Norm':>12}")
    print(f"  {'─' * 62}")
    for i in samples:
        if i < len(grad_norms):
            name, gnorm = grad_norms[i]
            pos = ['FIRST', 'EARLY', 'MIDDLE', 'LATE', 'LAST'][samples.index(i)]
            alive = '✓ alive' if gnorm > 1e-06 else '✗ dead'
            print(f'  {pos:<12}  {name:<35}  {gnorm:>12.2e}  {alive}')
    total_alive = sum((1 for _, g in grad_norms if g > 1e-06))
    print(f'  Alive gradients: {total_alive}/{len(grad_norms)}')
    model.zero_grad()
    return grad_norms
measure_grad_flow(m_A, 'A: flat-plain-50')
measure_grad_flow(m_B, 'B: flat-residual-50')
measure_grad_flow(m_D, 'D: pipeline-residual-50')
print_sep('FINAL SCOREBOARD')
models = [('A: flat plain 50L', s_A, l_A, 'no residual, no geometry'), ('B: flat residual 50L', s_B, l_B, 'residual, no geometry'), ('C: pipeline plain 50L', s_C, l_C, 'no residual, geometry'), ('D: pipeline residual 50L', s_D, l_D, 'residual + geometry ← HYPOTHESIS'), ('E: flat plain 10L', s_E, l_E, 'proven ceiling'), ('F: pipeline residual 10L', s_F, l_F, 'residual + geometry shallow')]
models_sorted = sorted(models, key=lambda x: (-x[1], x[2]))
print(f"\n  {'Model':<30}  {'Score':>7}  {'Loss':>10}  Notes")
print(f"  {'─' * 72}")
for name, s, l, note in models_sorted:
    print(f'  {name:<30}  {s:>4}/{len(TESTS)}  {l:>10.4f}  {note}')
print(f'\n  KEY QUESTIONS ANSWERED:\n  1. Does residual alone fix 50-layer collapse?\n     B vs A: flat+residual vs flat-plain\n\n  2. Does pipeline alone fix 50-layer collapse?\n     C vs A: pipeline-plain vs flat-plain\n\n  3. Does residual+pipeline together win?\n     D vs B vs C: all three compared\n\n  4. Does residual help or hurt shallow nets?\n     F vs E: 10-layer with/without residual\n\n  5. Can 50-layer ever match 10-layer ceiling?\n     D vs E: deep+residual vs shallow-proven\n')
