import torch
import numpy as np
from collections import Counter, defaultdict
from transformers import AutoModelForCausalLM, AutoTokenizer
import math, re
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
print_sep('LOAD TinyStories-1M')
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
try:
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float32, use_safetensors=True)
except Exception:
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, torch_dtype=torch.float32)
model = model.to(device)
model.eval()
print(f'  Loaded: {sum((p.numel() for p in model.parameters())):,} params')

def generate(prompt, max_new=120, temperature=0.8):
    inputs = tokenizer(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_new, temperature=temperature, do_sample=True, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)
PROMPTS = ['Once upon a time', 'One day', 'There was a little', 'A small boy named', 'The girl wanted to', 'In the forest', 'Tom went to', 'She looked at', 'The dog ran', 'Once there was', 'A tiny cat', 'The children played', 'He found a', 'She was very', 'The old man', 'One morning', 'They went to', 'A little bird', 'The kind girl', 'Once a bunny'] * 5
print_sep('GENERATING 100 STORIES — RAW TOKEN SEQUENCES ONLY')
print(f'  No categories. No labels. Just tokens.\n')
all_sentences = []
all_token_seqs = []
for i, prompt in enumerate(PROMPTS):
    text = generate(prompt, max_new=100)
    sents = [s.strip() for s in re.split('(?<=[.!?])\\s+', text) if 4 < len(s.strip()) < 200]
    for sent in sents:
        tokens = tokenizer.encode(sent, add_special_tokens=False)
        if 3 <= len(tokens) <= 30:
            all_sentences.append(sent)
            all_token_seqs.append(tokens)
    if (i + 1) % 20 == 0:
        print(f'  Generated {i + 1}/100 stories... ({len(all_sentences)} sentences so far)')
print(f'\n  Total sentences: {len(all_sentences)}')
print(f'  Token sequences: {len(all_token_seqs)}')
print(f'\n  Sample raw sentences:')
for s in all_sentences[:5]:
    toks = tokenizer.encode(s, add_special_tokens=False)
    print(f"    '{s[:60]}' → {toks[:8]}...")
print_sep('DISCOVERY 1 — POSITIONAL ENTROPY')
print(f"\n  For each position in the sentence (0,1,2,3...):\n  What token appears there?\n  \n  High entropy = anything can appear = no law\n  Low entropy  = same token always appears = LAW\n  \n  We don't know what we'll find.\n  We just measure.\n")
MAX_POS = 12
pos_tokens = defaultdict(list)
for seq in all_token_seqs:
    for pos, tok in enumerate(seq[:MAX_POS]):
        pos_tokens[pos].append(tok)
print(f"  {'Pos':>4}  {'Entropy':>9}  {'Top token':>20}  {'Freq':>6}  Predictable?")
print(f"  {'─' * 60}")
pos_entropies = {}
for pos in range(MAX_POS):
    toks = pos_tokens[pos]
    if len(toks) < 10:
        continue
    counter = Counter(toks)
    total = len(toks)
    probs = [c / total for c in counter.values()]
    entropy = -sum((p * math.log2(p) for p in probs if p > 0))
    top_tok, top_count = counter.most_common(1)[0]
    top_word = tokenizer.decode([top_tok])
    top_freq = top_count / total
    pos_entropies[pos] = entropy
    predictable = 'YES ← LAW' if entropy < 3.0 else 'weak' if entropy < 5.0 else 'no'
    print(f'  {pos:>4}  {entropy:>9.3f}  {repr(top_word):>20}  {top_freq:>5.1%}  {predictable}')
sorted_pos = sorted(pos_entropies.items(), key=lambda x: x[1])
print(f'\n  Most predictable positions: {[p for p, _ in sorted_pos[:3]]}')
print(f'  Most random positions:      {[p for p, _ in sorted_pos[-3:]]}')
print_sep('DISCOVERY 2 — MUTUAL INFORMATION BETWEEN POSITIONS')
print(f'\n  For each pair of positions (i, j):\n  Does token at position i tell us about token at position j?\n  \n  High MI = strong link = compression opportunity = LAW\n  Low MI  = independent = no law between them\n  \n  Not asking: are these AGENT and ACTION?\n  Asking: are these positions statistically linked?\n  Data will tell us.\n')

def mutual_information(pos_a, pos_b, token_seqs, max_pos=MAX_POS):
    pairs = []
    for seq in token_seqs:
        if len(seq) > max(pos_a, pos_b):
            pairs.append((seq[pos_a], seq[pos_b]))
    if len(pairs) < 20:
        return 0.0
    total = len(pairs)
    p_a = Counter((p[0] for p in pairs))
    p_b = Counter((p[1] for p in pairs))
    p_ab = Counter(pairs)
    mi = 0.0
    for (a, b), count in p_ab.items():
        p_joint = count / total
        p_marg_a = p_a[a] / total
        p_marg_b = p_b[b] / total
        if p_joint > 0 and p_marg_a > 0 and (p_marg_b > 0):
            mi += p_joint * math.log2(p_joint / (p_marg_a * p_marg_b))
    return mi
print(f'  Computing MI for all position pairs (0-7)...\n')
mi_matrix = {}
for i in range(8):
    for j in range(i + 1, 8):
        mi = mutual_information(i, j, all_token_seqs)
        mi_matrix[i, j] = mi
sorted_mi = sorted(mi_matrix.items(), key=lambda x: -x[1])
print(f"  {'Positions':>12}  {'MI':>8}  Strength")
print(f"  {'─' * 45}")
for (i, j), mi in sorted_mi[:10]:
    strength = 'STRONG LAW' if mi > 2.0 else 'moderate' if mi > 1.0 else 'weak'
    print(f'  pos({i},{j}):      {mi:>8.4f}  {strength}')
print_sep('DISCOVERY 3 — TOKEN CLUSTERS BY POSITION BEHAVIOR')
print(f"""\n  Which tokens appear in the SAME positions as each other?\n  \n  If token A and token B both always appear at position 0:\n  They are interchangeable at position 0.\n  They belong to the same cluster.\n  \n  We don't call it "AGENT" or "SUBJECT."\n  We call it Cluster-0.\n  Data defines the cluster. Not us.\n""")
tok_pos_dist = defaultdict(lambda: np.zeros(MAX_POS))
tok_count = Counter()
for seq in all_token_seqs:
    for pos, tok in enumerate(seq[:MAX_POS]):
        tok_pos_dist[tok][pos] += 1
        tok_count[tok] += 1
for tok in tok_pos_dist:
    total = tok_count[tok]
    if total > 0:
        tok_pos_dist[tok] /= total
common_toks = [tok for tok, count in tok_count.items() if count >= 5]
print(f'  Common tokens (5+ occurrences): {len(common_toks)}')
clusters = defaultdict(list)
for tok in common_toks:
    dist = tok_pos_dist[tok]
    dom_pos = int(np.argmax(dist))
    clusters[dom_pos].append((tok, dist[dom_pos]))
print(f'\n  TOKEN CLUSTERS BY DOMINANT POSITION:')
print(f'  (These are natural groups — not AGENT/ACTION, just data)\n')
for pos in sorted(clusters.keys())[:6]:
    members = sorted(clusters[pos], key=lambda x: -x[1])[:8]
    words = [tokenizer.decode([t]) for t, _ in members]
    print(f'  Position-{pos} cluster ({len(clusters[pos])} tokens):')
    print(f'    {words}')
print_sep('DISCOVERY 4 — BIGRAM CONSTANCY (compressed atoms)')
print(f'\n  Which pairs of tokens ALWAYS appear together?\n  \n  In numbers: diff2=constant → law\n  In language: bigram=constant → compressed atom\n  \n  "once upon" always together → compressed unit\n  "upon a"   always together → compressed unit\n  \n  These are the actual compression units the mind found.\n  Not words. Not sentences. UNITS.\n  Whatever the data says they are.\n')
bigram_count = Counter()
unigram_count = Counter()
for seq in all_token_seqs:
    for i in range(len(seq) - 1):
        bigram_count[seq[i], seq[i + 1]] += 1
        unigram_count[seq[i]] += 1
    if seq:
        unigram_count[seq[-1]] += 1
total_tokens = sum(unigram_count.values())
pmi_scores = {}
for (a, b), count in bigram_count.items():
    if count < 3:
        continue
    p_ab = count / total_tokens
    p_a = unigram_count[a] / total_tokens
    p_b = unigram_count[b] / total_tokens
    if p_a > 0 and p_b > 0:
        pmi = math.log2(p_ab / (p_a * p_b))
        pmi_scores[a, b] = (pmi, count)
sorted_pmi = sorted(pmi_scores.items(), key=lambda x: -x[1][0])
print(f'\n  Top compressed units (high PMI = always together):\n')
print(f"  {'Bigram':<25}  {'PMI':>8}  {'Count':>6}  Status")
print(f"  {'─' * 55}")
shown = 0
for (a, b), (pmi, count) in sorted_pmi:
    if count < 5:
        continue
    word_a = tokenizer.decode([a])
    word_b = tokenizer.decode([b])
    unit = f"'{word_a}' + '{word_b}'"
    status = 'COMPRESSED UNIT' if pmi > 5 else 'strong link' if pmi > 3 else 'moderate'
    print(f'  {unit:<25}  {pmi:>8.3f}  {count:>6}  {status}')
    shown += 1
    if shown >= 15:
        break
print_sep('DISCOVERY 5 — SEQUENCE LENGTH PATTERN')
lengths = [len(seq) for seq in all_token_seqs]
length_counts = Counter(lengths)
mean_len = np.mean(lengths)
std_len = np.std(lengths)
med_len = np.median(lengths)
print(f'\n  Mean length:   {mean_len:.1f} tokens\n  Median length: {med_len:.1f} tokens\n  Std dev:       {std_len:.1f} tokens\n  \n  Distribution:\n')
for l in sorted(length_counts.keys()):
    count = length_counts[l]
    bar = '█' * (count // max(1, max(length_counts.values()) // 30))
    print(f'  {l:>4} tokens: {bar} ({count})')
print_sep('SYNTHESIS — WHAT THE DATA ACTUALLY SAYS')
low_entropy_pos = [p for p, e in pos_entropies.items() if e < 4.0]
strong_mi_pairs = [(i, j) for (i, j), mi in sorted_mi[:3]]
top_units = []
for (a, b), (pmi, count) in sorted_pmi:
    if count >= 5 and pmi > 3:
        wa = tokenizer.decode([a])
        wb = tokenizer.decode([b])
        top_units.append(f"'{wa}+{wb}'")
    if len(top_units) >= 5:
        break
print(f"""\n  WHAT THE DATA FOUND (no hardcoding):\n\n  1. Predictable positions: {low_entropy_pos}\n     These positions have low entropy.\n     Whatever appears there is constrained.\n     Data calls them predictable. We don't name them.\n\n  2. Linked position pairs: {strong_mi_pairs}\n     Tokens at these pairs always co-determine each other.\n     Data found this. We didn't predict it.\n\n  3. Compressed atoms: {top_units}\n     These bigrams always appear together.\n     These are the mind's actual units — not words.\n     Mind never stored "once" and "upon" separately.\n     Mind stored "once_upon" as one compressed unit.\n\n  4. Sentence length: mean={mean_len:.1f} ± {std_len:.1f} tokens\n     This is the natural "chunk size" of this domain.\n\n  WHAT THIS MEANS:\n\n  We found REAL laws — not ones we imposed.\n  The data told us what it is.\n  Not: sentences have AGENT ACTION PATIENT.\n  But: position 0 is predictable, positions (0,1) are linked,\n       certain bigrams are atomic units.\n\n  THIS is what the subconscious finds.\n  Not categories we invented.\n  Statistical regularities that actually exist.\n\n  NEXT:\n  These discovered laws → use as compression for student.\n  Not AGENT/ACTION template → POSITIONAL + BIGRAM laws.\n  Student trained to follow WHAT DATA SAYS is constant.\n  Not what we say is constant.\n  \n  This is genuine subconscious discovery.\n""")
