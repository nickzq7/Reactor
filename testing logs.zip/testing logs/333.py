import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (W-CHAIN DIAGNOSIS)')
print('  Implementing Contextual Bit-Chaining to eliminate Drift.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
HAMMING_THRESHOLD = 8
print('\n  [ Phase 1 ] Mapping W-Chains (Contextual Trajectories)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden', 'A clever fox hid in the bushes', 'The farmer planted seeds in the soil']
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_pre = {l: [] for l in range(n_layers)}

def hook_pre_gelu(l):

    def hook(m, i, o):
        store_pre[l].append(o[:, -1, :].detach().cpu().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.act.register_forward_hook(hook_pre_gelu(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        prev_bits_list = [None] * n_layers
        for _ in range(35):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                curr_bits = (store_pre[l].pop()[0] > 0).astype(int)
                if prev_bits_list[l] is not None:
                    chain = np.concatenate([prev_bits_list[l], curr_bits])
                    RAM_chains[l].append(chain)
                    RAM_sequences[l].append(next_id)
                prev_bits_list[l] = curr_bits
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    chains = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = []
    for i in range(len(tokens) - JUMP_LENGTH):
        seqs.append(tokens[i:i + JUMP_LENGTH])
    RAM_chains[l] = chains[:len(seqs)]
    RAM_sequences[l] = np.array(seqs)
print(f'  ✓ Saturated {len(RAM_sequences[0])} W-Chains.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 60
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] DIAGNOSTIC RACE: CHAIN VERIFICATION')
print('─' * 75)
bit_history = {l: None for l in range(n_layers)}
current_bits_live = {l: None for l in range(n_layers)}

def get_live_hook(l):

    def hook(m, i, o):
        current_bits_live[l] = (o[:, -1, :].detach().cpu().numpy() > 0).astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_live_hook(l)) for l in range(n_layers)]
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen_hub = 0
print(f'  Prompt: {test_prompt}\n')
with torch.no_grad():
    while total_gen_hub < tokens_to_gen:
        out = model(hub_ids)
        truth_id = torch.argmax(out.logits[0, -1, :]).item()
        truth_word = tokenizer.decode([truth_id])
        jump_found = False
        if all((v is not None for v in bit_history.values())):
            for l in range(3, n_layers):
                current_chain = np.concatenate([bit_history[l], current_bits_live[l]])
                mismatches = 512 - np.sum(RAM_chains[l] == current_chain, axis=1)
                best_match_idx = np.argmin(mismatches)
                dist = mismatches[best_match_idx]
                if dist <= HAMMING_THRESHOLD:
                    speculative_seq = RAM_sequences[l][best_match_idx]
                    pred_id = int(speculative_seq[0])
                    if pred_id == truth_id:
                        print(f"  [✓ CHAIN JUMP L{l} Dist {dist}]: '{tokenizer.decode(speculative_seq).strip()}'")
                        jump_tensor = torch.tensor(np.array([speculative_seq]))
                        hub_ids = torch.cat([hub_ids, jump_tensor], dim=1)
                        for layer in range(n_layers):
                            bit_history[layer] = None
                        total_gen_hub += JUMP_LENGTH
                        jump_found = True
                    else:
                        print(f"  [⚠ CHAIN DRIFT L{l} Dist {dist}]: Hub suggested '{tokenizer.decode([pred_id]).strip()}' but Truth was '{truth_word.strip()}'")
                    break
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            print(f'  [Standard Step]: {truth_word.strip()}')
            for l in range(n_layers):
                bit_history[l] = current_bits_live[l]
            total_gen_hub += 1
for h in live_hooks:
    h.remove()
print('\n' + '=' * 75)
print('  W-CHAIN CONCLUSION')
print('=' * 75)
print('\n  The "Garden vs. Forest" bug is caused by semantic collisions.\n  By chaining [Bits(t-1) + Bits(t)], we create a contextual \n  fingerprint that is 2x more unique. \n  \n  If Drift is gone: W-Chains are the missing architectural link.\n  If Drift remains: We need longer chains or deeper layer ensemble.\n')
print('=' * 75 + '\n')
