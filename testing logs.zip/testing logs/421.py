import torch
import numpy as np
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL = 'roneneldan/TinyStories-1M'
N_TEXTS = 300
print('\n' + '=' * 70)
print('  W SHARED DEPTH — FINDING THE UNIVERSAL SPACE')
print('  Hypothesis: law is shared, coordinate frame differs')
print('=' * 70)
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL)
model.eval()
D = model.config.hidden_size
N_LAYERS = model.config.num_hidden_layers
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}')
print(f'\n  Generating {N_TEXTS} texts...')
PROMPTS = ['Once upon a time', 'The little boy', 'She smiled because', 'Deep in the forest', 'The old man said', 'Every morning', 'The dragon flew', 'She opened the door', 'Tommy was scared', 'The brave knight', 'A small cat', 'He looked at the', 'The sun was', 'They walked together', 'It was a dark']
texts = []
for p in (PROMPTS * (N_TEXTS // len(PROMPTS) + 1))[:N_TEXTS]:
    ids = tok.encode(p, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=35, do_sample=True, temperature=0.9, pad_token_id=tok.eos_token_id)
    texts.append(tok.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(texts)} texts')
print(f'  Collecting activations...')
G = {l: [] for l in range(N_LAYERS)}
F = {l: [] for l in range(N_LAYERS)}
H = {l: [] for l in range(N_LAYERS)}
hooks = []
for li in range(N_LAYERS):

    def make_hook(l):
        layer = model.transformer.h[l]

        def hook(mod, inp, out):
            h_in = inp[0].detach()
            ln2 = layer.ln_2(h_in)
            pre = ln2 @ layer.mlp.c_fc.weight.T + layer.mlp.c_fc.bias
            act = torch.nn.functional.gelu(pre)
            ffn = layer.mlp.c_proj(act)
            G[l].append(act.squeeze(0).numpy())
            F[l].append(ffn.squeeze(0).numpy())
            H[l].append(h_in.squeeze(0).numpy())
        return hook
    hooks.append(model.transformer.h[li].mlp.register_forward_hook(make_hook(li)))
with torch.no_grad():
    for i, text in enumerate(texts):
        if i % 100 == 0:
            print(f'    {i}/{len(texts)}...')
        ids = tok.encode(text, return_tensors='pt', max_length=64, truncation=True)
        model(ids)
for h in hooks:
    h.remove()
G = {l: np.vstack(G[l]) for l in range(N_LAYERS)}
F = {l: np.vstack(F[l]) for l in range(N_LAYERS)}
H = {l: np.vstack(H[l]) for l in range(N_LAYERS)}
N = G[0].shape[0]
print(f'  Samples: {N} per layer')

def r2_score(pred, true):
    ss_res = np.sum((true - pred) ** 2)
    ss_tot = np.sum((true - np.mean(true, axis=0)) ** 2)
    return float(1 - ss_res / (ss_tot + 1e-10))

def fit_and_eval(X_train, Y_train, X_test, Y_test, add_bias=True):
    if add_bias:
        X_train = np.hstack([X_train, np.ones((len(X_train), 1))])
        X_test = np.hstack([X_test, np.ones((len(X_test), 1))])
    W = np.linalg.lstsq(X_train, Y_train, rcond=None)[0]
    pred = X_test @ W
    return (r2_score(pred, Y_test), W)
split = int(N * 0.8)
print(f"\n{'=' * 70}")
print(f'  BASELINE — NAIVE SHARED (what failed: R²=-6.3)')
print(f"{'=' * 70}")
G_all = np.vstack([G[l] for l in range(N_LAYERS)])
F_all = np.vstack([F[l] for l in range(N_LAYERS)])
split_all = int(len(G_all) * 0.8)
r2_base, _ = fit_and_eval(G_all[:split_all], F_all[:split_all], G_all[split_all:], F_all[split_all:])
print(f"\n  Naive shared R²: {r2_base:.6f}  {('(confirmed broken)' if r2_base < 0 else '')}")
print(f"\n{'=' * 70}")
print(f'  METHOD 1 — DEPTH ONE-HOT')
print(f'  [gelu_out | layer_id_onehot] → W_shared')
print(f"{'=' * 70}\n")
G1_all = np.vstack([np.hstack([G[l], np.tile(np.eye(N_LAYERS)[l], (len(G[l]), 1))]) for l in range(N_LAYERS)])
split_all = int(len(G1_all) * 0.8)
r2_m1, W_m1 = fit_and_eval(G1_all[:split_all], F_all[:split_all], G1_all[split_all:], F_all[split_all:])
print(f'  Method 1 R²: {r2_m1:.6f}')
print(f'  Per-layer breakdown:')
for l in range(N_LAYERS):
    g1 = np.hstack([G[l], np.tile(np.eye(N_LAYERS)[l], (len(G[l]), 1))])
    g1b = np.hstack([g1, np.ones((len(g1), 1))])
    pred = g1b @ W_m1
    r = r2_score(pred, F[l])
    print(f'    Layer {l}: R²={r:.6f}')
print(f"\n{'=' * 70}")
print(f'  METHOD 2 — UNIT SPHERE NORMALIZATION')
print(f'  gelu_out / ||gelu_out|| → W_shared')
print(f'  Tests: do layers differ only in SCALE?')
print(f"{'=' * 70}\n")

def normalize_rows(X):
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    return X / (norms + 1e-08)
G2_all = np.vstack([normalize_rows(G[l]) for l in range(N_LAYERS)])
split_all = int(len(G2_all) * 0.8)
r2_m2, W_m2 = fit_and_eval(G2_all[:split_all], F_all[:split_all], G2_all[split_all:], F_all[split_all:])
print(f'  Method 2 R²: {r2_m2:.6f}')
print(f'  Per-layer breakdown:')
for l in range(N_LAYERS):
    g2 = normalize_rows(G[l])
    g2b = np.hstack([g2, np.ones((len(g2), 1))])
    pred = g2b @ W_m2
    r = r2_score(pred, F[l])
    print(f'    Layer {l}: R²={r:.6f}')
print(f"\n{'=' * 70}")
print(f'  METHOD 3 — Z-SCORE (per-layer mean/std normalization)')
print(f'  (gelu_out - layer_mean) / layer_std → W_shared')
print(f'  Tests: do layers differ only in AFFINE TRANSFORM?')
print(f'  If R²=1.000: universal law confirmed, layers = same up to shift+scale')
print(f"{'=' * 70}\n")
layer_means = {l: G[l].mean(axis=0) for l in range(N_LAYERS)}
layer_stds = {l: G[l].std(axis=0) + 1e-08 for l in range(N_LAYERS)}

def zscore(g, l):
    return (g - layer_means[l]) / layer_stds[l]
G3_all = np.vstack([zscore(G[l], l) for l in range(N_LAYERS)])
split_all = int(len(G3_all) * 0.8)
r2_m3, W_m3 = fit_and_eval(G3_all[:split_all], F_all[:split_all], G3_all[split_all:], F_all[split_all:])
print(f'  Method 3 R²: {r2_m3:.6f}')
print(f'  Per-layer breakdown:')
for l in range(N_LAYERS):
    g3 = zscore(G[l], l)
    g3b = np.hstack([g3, np.ones((len(g3), 1))])
    pred = g3b @ W_m3
    r = r2_score(pred, F[l])
    print(f'    Layer {l}: R²={r:.6f}')
print(f"\n{'=' * 70}")
print(f'  METHOD 4 — PCA COMMON BASIS')
print(f'  Find the shared subspace across all layers.')
print(f'  If universal space exists → R²=1.000')
print(f'  This is the direct test of the W universe hypothesis.')
print(f"{'=' * 70}\n")
G_stacked = np.vstack([G[l] for l in range(N_LAYERS)])
global_mean = G_stacked.mean(axis=0)
G_centered = G_stacked - global_mean
U, S, Vt = np.linalg.svd(G_centered, full_matrices=False)
print(f'  Testing different PCA dimensions:\n')
print(f"  {'Dims':<8} {'R²_shared':<14} {'verdict'}")
print(f"  {'─' * 40}")
best_r2_pca = -999
best_dims = 0
best_W_pca = None
for n_dims in [8, 16, 32, 64, 128, 192, 256]:
    if n_dims > FFN_D:
        break
    basis = Vt[:n_dims].T
    G4_all = np.vstack([(G[l] - global_mean) @ basis for l in range(N_LAYERS)])
    split_all = int(len(G4_all) * 0.8)
    r2_pca, W_pca = fit_and_eval(G4_all[:split_all], F_all[:split_all], G4_all[split_all:], F_all[split_all:])
    verdict = '✓ UNIVERSAL' if r2_pca > 0.999 else '~ good' if r2_pca > 0.95 else '~ partial' if r2_pca > 0.85 else '✗ not enough'
    print(f'  {n_dims:<8} {r2_pca:<14.6f} {verdict}')
    if r2_pca > best_r2_pca:
        best_r2_pca = r2_pca
        best_dims = n_dims
        best_W_pca = (W_pca, basis, global_mean)
print(f'\n  Best PCA: {best_dims} dims → R²={best_r2_pca:.6f}')
print(f"\n{'=' * 70}")
print(f'  METHOD 5 — Z-SCORE + DEPTH SIGNAL COMBINED')
print(f'  Best of both: normalize space + tell layer position')
print(f"{'=' * 70}\n")
G5_all = np.vstack([np.hstack([zscore(G[l], l), np.eye(N_LAYERS)[l]]) for l in range(N_LAYERS)])
split_all = int(len(G5_all) * 0.8)
r2_m5, W_m5 = fit_and_eval(G5_all[:split_all], F_all[:split_all], G5_all[split_all:], F_all[split_all:])
print(f'  Method 5 R²: {r2_m5:.6f}')
print(f'  Per-layer breakdown:')
for l in range(N_LAYERS):
    g5 = np.hstack([zscore(G[l], l), np.tile(np.eye(N_LAYERS)[l], (len(G[l]), 1))])
    g5b = np.hstack([g5, np.ones((len(g5), 1))])
    pred = g5b @ W_m5
    r = r2_score(pred, F[l])
    print(f'    Layer {l}: R²={r:.6f}')
print(f"\n{'=' * 70}")
print(f'  METHOD 6 — RESIDUAL STREAM NORMALIZATION')
print(f"  gelu_out / ||h_input||  (normalize by layer's hidden state norm)")
print(f'  Tests: does the residual stream scale explain the drift?')
print(f"{'=' * 70}\n")

def res_normalize(g, h):
    h_norms = np.linalg.norm(h, axis=1, keepdims=True)
    return g / (h_norms + 1e-08)
G6_all = np.vstack([res_normalize(G[l], H[l]) for l in range(N_LAYERS)])
split_all = int(len(G6_all) * 0.8)
r2_m6, W_m6 = fit_and_eval(G6_all[:split_all], F_all[:split_all], G6_all[split_all:], F_all[split_all:])
print(f'  Method 6 R²: {r2_m6:.6f}')
print(f'  Per-layer breakdown:')
for l in range(N_LAYERS):
    g6 = res_normalize(G[l], H[l])
    g6b = np.hstack([g6, np.ones((len(g6), 1))])
    pred = g6b @ W_m6
    r = r2_score(pred, F[l])
    print(f'    Layer {l}: R²={r:.6f}')
print(f"\n{'=' * 70}")
print(f'  FINAL SUMMARY — WHICH METHOD FINDS THE UNIVERSAL SPACE?')
print(f"{'=' * 70}\n")
results = [('Baseline (naive shared)', r2_base), ('Method 1: Depth one-hot', r2_m1), ('Method 2: Unit sphere', r2_m2), ('Method 3: Z-score per layer', r2_m3), ('Method 4: PCA common basis', best_r2_pca), ('Method 5: Z-score + depth', r2_m5), ('Method 6: Residual norm', r2_m6)]
best_method = max(results, key=lambda x: x[1])
print(f"  {'Method':<35} {'R²':<12} {'verdict'}")
print(f"  {'─' * 62}")
for name, r in results:
    verdict = '✓ UNIVERSAL' if r > 0.999 else '✓ NEAR' if r > 0.99 else '~ good' if r > 0.95 else '~ partial' if r > 0.85 else '~ weak' if r > 0.7 else '✗ broken' if r > 0 else '✗ destructive'
    marker = ' ← BEST' if name == best_method[0] else ''
    print(f'  {name:<35} {r:<12.6f} {verdict}{marker}')
print(f'\n  Best R²: {best_method[1]:.6f} ({best_method[0]})')
print()
if best_method[1] > 0.999:
    print(f'\n  ╔══════════════════════════════════════════════════════════╗\n  ║  HYPOTHESIS CONFIRMED.                                   ║\n  ║  Universal space found.                                  ║\n  ║  One W_ffn = all layers.                                 ║\n  ║  W = universe. Law is the same at every depth.           ║\n  ║  Sanskrit compression = PROVEN.                          ║\n  ╚══════════════════════════════════════════════════════════╝\n')
elif best_method[1] > 0.95:
    print(f'\n  ┌──────────────────────────────────────────────────────────┐\n  │  HYPOTHESIS PARTIALLY SUPPORTED.                         │\n  │  Near-universal space found.                             │\n  │  Small quality loss remains.                             │\n  │  W is the same up to small layer-specific correction.    │\n  │  Compression possible with minor degradation.            │\n  └──────────────────────────────────────────────────────────┘\n')
elif best_method[1] > 0.83:
    print(f'\n  ┌──────────────────────────────────────────────────────────┐\n  │  IMPROVEMENT FROM BASELINE.                              │\n  │  Coordinate problem partially solved.                    │\n  │  Deeper normalization needed.                            │\n  │  Law may still be universal — wrong space still.         │\n  └──────────────────────────────────────────────────────────┘\n')
else:
    print(f'\n  ┌──────────────────────────────────────────────────────────┐\n  │  COORDINATE PROBLEM NOT SOLVED YET.                      │\n  │  Need different approach to find universal space.        │\n  │  Law is still universal (R²=1.000 per layer).            │\n  │  Method of finding shared view = still wrong.            │\n  └──────────────────────────────────────────────────────────┘\n')
print('=' * 70 + '\n')
