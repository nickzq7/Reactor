import numpy as np, math, time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL WORD v4 — GENERALIZATION TEST')
print('  Train/test split. True generalization measurement.')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do\nthere was once a boy named tom who lived by the sea every day\nhe walked along the shore and looked for shells and smooth stones\nhis grandmother had taught him that the sea always brings gifts\nto those who are patient one morning he found a small glass bottle\nwith a piece of paper rolled inside the paper had a map drawn on it\nin careful lines the map showed a path through the hills behind the town\ntom put the bottle in his coat and walked toward the hills the path\nwas steep but he followed every turn the map showed until he came to a\nlarge flat rock with a view of the whole valley below he sat on the rock\nand looked out at the sea far below he could see the tiny boats of the\nfishermen and the white foam of the waves that was the gift the sea had\nsent him not gold or treasure but the most beautiful view he had ever seen\nhe went home and told his grandmother and she smiled and said that she\nhad found the same bottle when she was young and had hidden it again\nfor someone else to find the old dog sat by the fire every evening\nwhile the family ate their dinner he had been with them for twelve years\nand knew all their voices and all their moods when the children were\nloud he wagged his tail slowly and when the house was quiet he slept\ndeeply one cold winter the oldest child went away to school far from home\nthe dog waited by the door each evening but the child did not come back\nafter many weeks a letter arrived and the mother read it at the table\nthe dog lifted his head and listened to her voice even though he could\nnot understand the words he knew from her voice that everything was well\nand he put his head back down on his paws and closed his eyes the woman\nwho kept the bookshop on the corner had read every book in her shop\nat least twice customers came from far away to ask her what to read next\nshe never recommended the same book to two people because she believed\nthat every reader needs a different story at different times of their life\none day a young man came in and said he wanted a book that would change\nhis life she thought for a long time walking slowly between the shelves\ntouching the spines of the books then she took down a small thin book\nwith a plain cover and handed it to him he looked at it and said it seemed\ntoo simple she said that the simplest things are often the hardest to learn\nhe bought it and came back three weeks later and said she had been right'.strip()
words_raw = TEXT.replace('\n', ' ').split()
word_vocab = sorted(set(words_raw))
w2i = {w: i for i, w in enumerate(word_vocab)}
i2w = {i: w for w, i in w2i.items()}
VS_w = len(word_vocab)
word_toks = [w2i[w] for w in words_raw]
N_w = len(word_toks)
split = int(0.8 * N_w)
train_toks = word_toks[:split]
test_toks = word_toks[split:]
print(f'\n  Word vocab={VS_w}  Total={N_w}  Train={len(train_toks)}  Test={len(test_toks)}')
D = 28
WIN = 4
cooc = np.zeros((VS_w, VS_w), dtype=np.float32)
for i, w in enumerate(train_toks):
    for j in range(max(0, i - WIN), min(len(train_toks), i + WIN + 1)):
        if i != j:
            cooc[w, train_toks[j]] += 1.0 / abs(i - j)
total = cooc.sum()
rs = cooc.sum(1, keepdims=True)
cs = cooc.sum(0, keepdims=True)
with np.errstate(divide='ignore', invalid='ignore'):
    pmi = np.log2(cooc * total / (rs * cs + 1e-10) + 1e-10)
ppmi = np.maximum(pmi, 0)
U, S, Vt = np.linalg.svd(ppmi, full_matrices=False)
WTE_svd = (U[:, :D] * np.sqrt(S[:D])).astype(np.float64)
norms = np.linalg.norm(WTE_svd, axis=1, keepdims=True) + 1e-08
WTE_n = WTE_svd / norms
SCALE = 4.0
WTE_out = WTE_n * SCALE
K = 4
DECAY = 0.5
L = 3
decay_w = np.array([DECAY ** j for j in range(K)], dtype=np.float64)
decay_w /= decay_w.sum()

def make_XY(toks):
    M = len(toks) - K
    X = np.zeros((M, D), dtype=np.float64)
    for i in range(K, len(toks)):
        for j in range(K):
            X[i - K] += decay_w[j] * WTE_n[toks[i - 1 - j]]
    return (X, np.array(toks[K:]))
X_tr, y_tr = make_XY(train_toks)
X_te, y_te = make_XY(test_toks)
T_tr = WTE_out[y_tr]
D_q = D * (D + 1) // 2
print(f'  D={D}  D_quad={D_q}  Train N/D={len(X_tr) / D_q:.2f}x')
tri_i, tri_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_s(Ph, R, lam=1e-06):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    return np.linalg.solve(A, Ph.T @ R)

def fwd(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs

def eval_ppl_acc(X, y, Wl):
    x = fwd(X, Wl)[-1]
    lg = x @ WTE_out.T
    acc = 100 * np.mean(np.argmax(lg, 1) == y)
    step = max(1, len(y) // 500)
    nll = 0.0
    ne = 0
    for i in range(0, len(y), step):
        l = lg[i] - lg[i].max()
        l = l - np.log(np.sum(np.exp(l)))
        nll -= l[y[i]]
        ne += 1
    return (math.exp(min(nll / ne, 500)), acc)
W = [np.zeros((D_q, D)) for _ in range(L)]
pt0, at0 = eval_ppl_acc(X_tr, y_tr, W)
pte0, ate0 = eval_ppl_acc(X_te, y_te, W)
print(f'  Initial: train_ppl={pt0:.1f}  test_ppl={pte0:.1f}')
print(f"\n  {'Rnd':>4} {'L':>2} {'tr_ppl':>8} {'tr_acc':>8} {'te_ppl':>8} {'te_acc':>8}")
print(f"  {'─' * 55}")
best_tr = pt0
best_W = [w.copy() for w in W]
for rnd in range(10):
    imp = False
    for l in range(L):
        xs = fwd(X_tr, W)
        Wn = pinv_s(phi_b(xs[l]), T_tr - xs[l])
        Wt = [w.copy() for w in W]
        Wt[l] = Wn
        ptr, atr = eval_ppl_acc(X_tr, y_tr, Wt)
        pte, ate = eval_ppl_acc(X_te, y_te, Wt)
        mk = ' ★' if ptr < best_tr else ''
        print(f'  {rnd + 1:>4} {l:>2} {ptr:>8.2f} {atr:>7.1f}% {pte:>8.2f} {ate:>7.1f}%{mk}')
        if ptr < best_tr:
            best_tr = ptr
            W = Wt
            best_W = [w.copy() for w in Wt]
            imp = True
    if not imp:
        print('  Converged.')
        break
W = best_W
fptr, fatr = eval_ppl_acc(X_tr, y_tr, W)
fpte, fate = eval_ppl_acc(X_te, y_te, W)
print(f'\n  FINAL: train_ppl={fptr:.2f} acc={fatr:.1f}%  test_ppl={fpte:.2f} acc={fate:.1f}%')
print(f'  Generalization gap: {fpte - fptr:.2f} ppl')

def gen_w(prompt_words, n=20, temp=0.9, seed=42):
    np.random.seed(seed)
    ids = [w2i[w] for w in prompt_words if w in w2i]
    for _ in range(n):
        x = np.zeros(D, dtype=np.float64)
        recent = ids[-K:] if len(ids) >= K else [0] * (K - len(ids)) + ids
        for j in range(K):
            x += decay_w[j] * WTE_n[recent[-1 - j]]
        for W_ in W:
            x = x + phi(x) @ W_
        lg = x @ WTE_out.T
        if temp == 0:
            pred = int(np.argmax(lg))
        else:
            lg2 = (lg - lg.max()) / temp
            pr = np.exp(lg2)
            pr /= pr.sum()
            idx = np.argsort(-pr)
            cm = np.cumsum(pr[idx])
            cut = np.searchsorted(cm, 0.92) + 1
            nuc = idx[:max(1, cut)]
            pn = pr[nuc]
            pn /= pn.sum()
            pred = int(np.random.choice(nuc, p=pn))
        ids.append(pred)
    return ' '.join((i2w.get(t, '?') for t in ids))
print(f'\n  GENERATION (greedy):')
for sw in [['once', 'upon', 'a', 'time'], ['the', 'brave', 'knight'], ['deep', 'in', 'the', 'forest'], ['the', 'old', 'dog']]:
    print(f'  {gen_w(sw, n=15, temp=0)}')
print(f'\n  GENERATION (nucleus temp=0.9):')
for si, sw in enumerate([['once', 'upon', 'a', 'time'], ['the', 'brave', 'knight'], ['deep', 'in', 'the', 'forest'], ['the', 'old', 'dog']]):
    print(f'  {gen_w(sw, n=15, temp=0.9, seed=si * 11 + 3)}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  train_ppl={fptr:.2f}  test_ppl={fpte:.2f}  vocab={VS_w}')
print(f'\n  IF test_ppl << vocab={VS_w}: W-Kernel generalizes to new text.')
print(f'  IF test_ppl >> train_ppl: overfitting → need more text.')
print(f'  IF generation = new sentences: natural space found.')
print('=' * 65 + '\n')
