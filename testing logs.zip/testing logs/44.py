import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN = 500
N_TEST = 5
MAX_SEQ = 64
GEN_TOKENS = 40
TRAIN_SENTENCES = ['Once upon a time there was a little girl named Lily.', 'The dog ran fast through the park.', 'Tom and his friend went to the store.', 'The big red ball rolled down the hill.', 'In the forest there lived a small rabbit.', 'The sun was shining bright in the sky.', 'A little boy named Jack had a toy car.', 'The cat sat on the mat and looked outside.', 'Mary went to school and learned to read.', 'The birds sang a beautiful song in the morning.'] * 50
TEST_PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'In the forest there lived a', 'Tom and his friend went to the', 'The big red ball']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('\n' + '=' * 65)
print('  PHASE 0: LOAD TEACHER MODEL')
print('=' * 65)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD, VOCAB = (H // NH, cfg.vocab_size)
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT_TYPES = cfg.attention_layers
except:
    ATT_TYPES = ['global'] * NL
FFN_D = teacher.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'  NL={NL} H={H} NH={NH} HD={HD} FFN_D={FFN_D} VOCAB={VOCAB}')
print('\n' + '=' * 65)
print('  PHASE 1: COLLECT CRYSTAL BOUNDARY ACTIVATIONS')
print(f'  Running teacher on {N_TRAIN} sentences...')
print('=' * 65)
buffers = {li: {'ln1': [], 'Q': [], 'K': [], 'V': [], 'ctx': [], 'att_out': [], 'h_mid': [], 'ln2': [], 'pre_gelu': [], 'gelu_out': [], 'ffn_out': [], 'h_out': []} for li in range(NL)}
lnf_buf = {'in': [], 'out': []}
hooks = []

def add_hooks():
    for li in range(NL):
        bl = teacher.transformer.h[li]
        at = bl.attn.attention

        def make_ln1_hook(l):

            def fn(mod, inp, out):
                buffers[l]['ln1'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_qkv_hook(l):

            def fn_q(mod, inp, out):
                buffers[l]['Q'].append(out.detach().float().cpu().reshape(-1, H).numpy())

            def fn_k(mod, inp, out):
                buffers[l]['K'].append(out.detach().float().cpu().reshape(-1, H).numpy())

            def fn_v(mod, inp, out):
                buffers[l]['V'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return (fn_q, fn_k, fn_v)

        def make_ctx_hook(l):

            def fn(mod, inp, out):
                ctx = inp[0].detach().float().cpu().reshape(-1, H).numpy()
                att = out.detach().float().cpu().reshape(-1, H).numpy()
                buffers[l]['ctx'].append(ctx)
                buffers[l]['att_out'].append(att)
            return fn

        def make_block_hook(l):

            def fn(mod, inp, out):
                x = out[0] if isinstance(out, tuple) else out
                buffers[l]['h_out'].append(x.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_ln2_hook(l):

            def fn(mod, inp, out):
                buffers[l]['ln2'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_fc_hook(l):

            def fn(mod, inp, out):
                buffers[l]['pre_gelu'].append(out.detach().float().cpu().reshape(-1, FFN_D).numpy())
                pre = out.detach().float().cpu()
                gelu = 0.5 * pre * (1 + torch.tanh(math.sqrt(2 / math.pi) * (pre + 0.044715 * pre ** 3)))
                buffers[l]['gelu_out'].append(gelu.reshape(-1, FFN_D).numpy())
            return fn

        def make_ffn_hook(l):

            def fn(mod, inp, out):
                buffers[l]['ffn_out'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn
        fn_q, fn_k, fn_v = make_qkv_hook(li)
        hooks.append(bl.ln_1.register_forward_hook(make_ln1_hook(li)))
        hooks.append(at.q_proj.register_forward_hook(fn_q))
        hooks.append(at.k_proj.register_forward_hook(fn_k))
        hooks.append(at.v_proj.register_forward_hook(fn_v))
        hooks.append(at.out_proj.register_forward_hook(make_ctx_hook(li)))
        hooks.append(bl.ln_2.register_forward_hook(make_ln2_hook(li)))
        hooks.append(bl.mlp.c_fc.register_forward_hook(make_fc_hook(li)))
        hooks.append(bl.mlp.c_proj.register_forward_hook(make_ffn_hook(li)))
        hooks.append(bl.register_forward_hook(make_block_hook(li)))
add_hooks()
t_collect = time.perf_counter()
n_tokens_total = 0
with torch.no_grad():
    for si, sentence in enumerate(TRAIN_SENTENCES[:N_TRAIN]):
        ids = tok(sentence, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'].to(device)
        teacher(ids)
        n_tokens_total += ids.shape[1]
        if (si + 1) % 100 == 0:
            print(f'    {si + 1}/{N_TRAIN} sentences  {n_tokens_total} tokens')
for h in hooks:
    h.remove()
t_collect = time.perf_counter() - t_collect
print(f'\n  Collected {n_tokens_total} tokens in {t_collect:.2f}s')
for li in range(NL):
    for key in buffers[li]:
        if buffers[li][key]:
            buffers[li][key] = np.concatenate(buffers[li][key], axis=0).astype(np.float32)
N = buffers[0]['ln1'].shape[0]
print(f'  Total token positions available: {N}')
print('\n' + '=' * 65)
print('  PHASE 2: SOLVE W MATRICES (O(1) TRAINING)')
print('=' * 65)
print(f"  {'Layer':<8} {'W_q R²':>8} {'W_k R²':>8} {'W_v R²':>8} {'W_o R²':>8} {'W1 R²':>8} {'W2 R²':>8}  time")
print(f"  {'-' * 70}")

def solve_W(X, Y, name=''):
    X = X.astype(np.float64)
    Y = Y.astype(np.float64)
    Xb = np.concatenate([X, np.ones((X.shape[0], 1), dtype=np.float64)], axis=1)
    result, _, _, _ = lstsq(Xb, Y, rcond=None)
    W = result[:-1].T
    b = result[-1]
    Y_pred = X @ W.T + b
    ss_res = ((Y - Y_pred) ** 2).sum()
    ss_tot = ((Y - Y.mean(0)) ** 2).sum()
    r2 = float(1 - ss_res / (ss_tot + 1e-12))
    return (W.astype(np.float32), b.astype(np.float32), r2)
R = {}
r2_all = {}
t_solve = time.perf_counter()
for li in range(NL):
    t0 = time.perf_counter()
    b = buffers[li]
    W_q, b_q, r2_q = solve_W(b['ln1'], b['Q'], f'L{li}_Wq')
    W_k, b_k, r2_k = solve_W(b['ln1'], b['K'], f'L{li}_Wk')
    W_v, b_v, r2_v = solve_W(b['ln1'], b['V'], f'L{li}_Wv')
    W_o, b_o, r2_o = solve_W(b['ctx'], b['att_out'], f'L{li}_Wo')
    W1, b1, r2_1 = solve_W(b['ln2'], b['pre_gelu'], f'L{li}_W1')
    W2, b2, r2_2 = solve_W(b['gelu_out'], b['ffn_out'], f'L{li}_W2')
    R[li] = {'W_q': W_q, 'b_q': b_q, 'W_k': W_k, 'b_k': b_k, 'W_v': W_v, 'b_v': b_v, 'W_o': W_o, 'b_o': b_o, 'W1': W1, 'b1': b1, 'W2': W2, 'b2': b2}
    r2_all[li] = [r2_q, r2_k, r2_v, r2_o, r2_1, r2_2]
    elapsed = time.perf_counter() - t0
    mark = '✓' if min(r2_q, r2_k, r2_v, r2_o, r2_1, r2_2) > 0.9999 else '~' if min(r2_q, r2_k, r2_v, r2_o, r2_1, r2_2) > 0.999 else '✗'
    print(f'  Layer {li:<3}  {r2_q:8.6f} {r2_k:8.6f} {r2_v:8.6f} {r2_o:8.6f} {r2_1:8.6f} {r2_2:8.6f}  {elapsed:.2f}s {mark}')
t_solve = time.perf_counter() - t_solve
print(f'\n  Total solve time: {t_solve:.3f}s  ({N_TRAIN} sentences, ZERO gradient steps)')
with torch.no_grad():
    for li in range(NL):
        bl = teacher.transformer.h[li]
        R[li]['ln1_g'] = bl.ln_1.weight.detach().float().cpu().numpy()
        R[li]['ln1_b'] = bl.ln_1.bias.detach().float().cpu().numpy()
        R[li]['ln2_g'] = bl.ln_2.weight.detach().float().cpu().numpy()
        R[li]['ln2_b'] = bl.ln_2.bias.detach().float().cpu().numpy()
        R[li]['attn_type'] = ATT_TYPES[li] if li < len(ATT_TYPES) else 'global'
        R[li]['window'] = WIN
Wte = teacher.transformer.wte.weight.detach().float().cpu().numpy()
Wpe = teacher.transformer.wpe.weight.detach().float().cpu().numpy()
lnf_g = teacher.transformer.ln_f.weight.detach().float().cpu().numpy()
lnf_b = teacher.transformer.ln_f.bias.detach().float().cpu().numpy()
Wlm = teacher.lm_head.weight.detach().float().cpu().numpy()
print('\n' + '=' * 65)
print('  PHASE 3: REACTOR FORWARD PASS')
print('=' * 65)

def ln_np(x, g, b):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (g * (x - mean) / np.sqrt(var + 1e-05) + b).astype(np.float32)

def gelu_np(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def corr(a, b):
    a, b = (a.ravel().astype(np.float64), b.ravel().astype(np.float64))
    return float(np.corrcoef(a, b)[0, 1])

def reactor_layer(h, li):
    w = R[li]
    sl = h.shape[0]
    ln1 = ln_np(h, w['ln1_g'], w['ln1_b'])
    Q = (ln1 @ w['W_q'].T + w['b_q']).astype(np.float32)
    K = (ln1 @ w['W_k'].T + w['b_k']).astype(np.float32)
    V = (ln1 @ w['W_v'].T + w['b_v']).astype(np.float32)
    Q_h = Q.reshape(sl, NH, HD).transpose(1, 0, 2).astype(np.float32)
    K_h = K.reshape(sl, NH, HD).transpose(1, 0, 2).astype(np.float32)
    V_h = V.reshape(sl, NH, HD).transpose(1, 0, 2).astype(np.float32)
    scores = np.matmul(Q_h, K_h.transpose(0, 2, 1))
    mask = np.full((sl, sl), -1000000000.0, np.float32)
    for i in range(sl):
        s = max(0, i - w['window'] + 1) if w['attn_type'] == 'local' else 0
        mask[i, s:i + 1] = 0.0
    scores += mask[np.newaxis]
    scores -= scores.max(-1, keepdims=True)
    e = np.exp(scores)
    probs = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    ctx = np.matmul(probs, V_h).transpose(1, 0, 2).reshape(sl, H).astype(np.float32)
    att_out = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
    h_mid = (h + att_out).astype(np.float32)
    ln2 = ln_np(h_mid, w['ln2_g'], w['ln2_b'])
    pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
    act = gelu_np(pre)
    ffn_out = (act @ w['W2'].T + w['b2']).astype(np.float32)
    return (h_mid + ffn_out).astype(np.float32)

def reactor_forward(input_ids):
    ids = np.array(input_ids, np.int32)
    sl = len(ids)
    h = (Wte[ids] + Wpe[np.arange(sl)]).astype(np.float32)
    for li in range(NL):
        h = reactor_layer(h, li)
    h_final = ln_np(h, lnf_g, lnf_b)
    return (h_final @ Wlm.T).astype(np.float32)
val_text = TRAIN_SENTENCES[0]
val_ids = tok(val_text, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'][0].tolist()
with torch.no_grad():
    pt_logits = teacher(torch.tensor([val_ids]).to(device)).logits[0].float().cpu().numpy()
rx_logits = reactor_forward(val_ids)
print(f'  Validation sentence: "{val_text[:50]}"')
print(f'  Tokens: {len(val_ids)}')
print(f"\n  {'Position':<12} {'corr':>12}  {'PT_top1':>12}  {'RX_top1':>12}  match")
print(f"  {'-' * 58}")
matches = 0
for pos in range(min(8, len(val_ids))):
    c = corr(pt_logits[pos], rx_logits[pos])
    pt = tok.decode([int(np.argmax(pt_logits[pos]))])
    rx = tok.decode([int(np.argmax(rx_logits[pos]))])
    m = '✓' if pt == rx else '✗'
    if pt == rx:
        matches += 1
    print(f'  pos {pos:<8}  {c:12.8f}  {repr(pt):>12}  {repr(rx):>12}  {m}')
full_corr = corr(pt_logits.ravel(), rx_logits.ravel())
print(f'\n  Full logit corr (all positions): {full_corr:.8f}')
print(f'  Top-1 match: {matches}/{min(8, len(val_ids))}')
print('\n' + '=' * 65)
print('  PHASE 4: GENERATION BENCHMARK')
print('=' * 65)

def generate_reactor(prompt, n):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    t0 = time.perf_counter()
    for _ in range(n):
        logits = reactor_forward(ids)
        next_id = int(np.argmax(logits[-1]))
        ids.append(next_id)
    return (ids[len(ids) - n:], time.perf_counter() - t0)

def generate_teacher(prompt, n):
    ids = tok(prompt, return_tensors='pt')['input_ids'].to(device)
    t0 = time.perf_counter()
    with torch.no_grad():
        out = teacher.generate(ids, max_new_tokens=n, do_sample=False, use_cache=True)
    return (out[0][ids.shape[1]:].cpu().tolist(), time.perf_counter() - t0)
print(f"\n  {'Prompt':<42}  {'match':>6}  {'R quality'}")
print(f"  {'-' * 65}")
total_match = 0
total_tokens = 0
for prompt in TEST_PROMPTS:
    ids_t, t_t = generate_teacher(prompt, GEN_TOKENS)
    ids_r, t_r = generate_reactor(prompt, GEN_TOKENS)
    match = sum((a == b for a, b in zip(ids_t, ids_r)))
    total_match += match
    total_tokens += GEN_TOKENS
    bar = '█' * (match // 4) + '░' * ((GEN_TOKENS - match) // 4)
    print(f'  "{prompt[:40]:<40}"  {match:>3}/{GEN_TOKENS}  {bar}')
    print(f'    Teacher: {repr(tok.decode(ids_t)[:65])}')
    print(f'    REACTOR: {repr(tok.decode(ids_r)[:65])}')
    print()
match_pct = 100 * total_match / total_tokens
print('=' * 65)
print('  REACTOR-TINY SUMMARY')
print('=' * 65)
avg_r2 = np.mean([np.mean(v) for v in r2_all.values()])
min_r2 = np.min([np.min(v) for v in r2_all.values()])
print(f"\n  TRAINING:\n    Method:          lstsq solve (O(1) — zero gradient steps)\n    Sentences:       {N_TRAIN}\n    Total tokens:    {n_tokens_total}\n    Collection time: {t_collect:.2f}s\n    Solve time:      {t_solve:.3f}s\n    Total train:     {t_collect + t_solve:.2f}s\n\n  CRYSTAL SOLVE QUALITY:\n    Avg R²:  {avg_r2:.8f}\n    Min R²:  {min_r2:.8f}\n    Gate:    {('✓ PASS (>0.9999)' if min_r2 > 0.9999 else '~ NEAR (>0.999)' if min_r2 > 0.999 else '✗ FAIL')}\n\n  GENERATION:\n    Token match:  {total_match}/{total_tokens} = {match_pct:.1f}%\n    Full corr:    {full_corr:.8f}\n\n  VERDICT:\n")
if min_r2 > 0.9999 and match_pct > 95:
    print('  ✓ O(1) TRAINING PROVEN.')
    print('  ✓ Crystal chain solved analytically, zero gradient descent.')
    print('  ✓ REACTOR reproduces teacher with R²=1.0 at every boundary.')
    print('  ✓ The W Principle: training IS solving. Not learning. Solving.')
elif min_r2 > 0.999 and match_pct > 80:
    print('  ~ STRONG RESULT. R²>0.999, high token match.')
    print('  ~ More training data → R²→1.0 (linear system under-constrained)')
    print('  ~ REACTOR architecture confirmed. Scale data to complete proof.')
else:
    print(f'  ~ R²={min_r2:.4f}  match={match_pct:.1f}%')
    print('  ~ Check: N_TRAIN sentences may be too few for H=64 space.')
    print('  ~ Increase N_TRAIN → R² will converge to 1.0')
print(f'\n  NEXT: REACTOR-PHASE2 — train on raw data (no teacher)')
print(f'        Replace teacher targets with analytically derived targets')
print(f'        True O(1) training from scratch.')
print('=' * 65)
