import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
VS = 1001
D = 128
H = 8
NL = 4
K = 12
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, (a + b) % VS)
        s.append(b)
    return s

def gen_trib(n):
    a, b, c = (0, 1, 1)
    s = [0, 1, 1]
    while len(s) < n:
        a, b, c = (b, c, (a + b + c) % VS)
        s.append(c)
    return s[:n]

def gen_primes(n):
    P = []
    c = 2
    while len(P) < n:
        if all((c % p for p in P)):
            P.append(c % VS)
        c += 1
    return P

def gen_pow(base, n):
    v = 1
    s = []
    for _ in range(n):
        s.append(v % VS)
        v = v * base % VS
    return s
fib62 = gen_fib(62)
PATTERNS = [('counting', [i % VS for i in range(60)]), ('evens', [i * 2 % VS for i in range(60)]), ('odds', [(i * 2 + 1) % VS for i in range(60)]), ('threes', [i * 3 % VS for i in range(60)]), ('fives', [i * 5 % VS for i in range(60)]), ('tens', [i * 10 % VS for i in range(60)]), ('step7', [i * 7 % VS for i in range(60)]), ('countdown', [(100 - i) % VS for i in range(60)]), ('squares', [i * i % VS for i in range(60)]), ('powers2', gen_pow(2, 60)), ('powers3', gen_pow(3, 60)), ('fibonacci', gen_fib(60)), ('tribonacci', gen_trib(60)), ('primes', gen_primes(60)), ('alt_fib', [abs(fib62[i + 2] - fib62[i]) % VS for i in range(60)])]
TESTS = [(name, seq[:K], seq[K]) for name, seq in PATTERNS]

def build_tensors():
    Xs = []
    Ys = []
    for name, seq in PATTERNS:
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))
X, Y = build_tensors()
X, Y = (X.to(device), Y.to(device))
print(f'Device: {device}')

class BigModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def eval_model(model):
    model.eval()
    c = 0
    bar = []
    for name, ctx, truth in TESTS:
        ids = torch.tensor([ctx], dtype=torch.long).to(device)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        c += p == truth
        bar.append('█' if p == truth else '░')
    return (c, ''.join(bar))
model = BigModel().to(device)
params = sum((p.numel() for p in model.parameters()))
print(f'Big model params: {params:,}')
print(f'VS={VS}  D={D}  H={H}  NL={NL}  K={K}  patterns={len(PATTERNS)}')
opt = torch.optim.Adam(model.parameters(), lr=0.003)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=15000, eta_min=1e-05)
best_sc = 0
best_state = None
t0 = time.time()
for step in range(1, 15001):
    model.train()
    opt.zero_grad()
    loss = loss_fn(model(X).view(-1, VS), Y.view(-1))
    loss.backward()
    nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    opt.step()
    sched.step()
    if step == 1 or step % 500 == 0:
        sc, bar = eval_model(model)
        if sc > best_sc:
            best_sc = sc
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        print(f'  step {step:>6}: {sc}/15  {bar}  ({time.time() - t0:.0f}s)', flush=True)
        if sc == 15:
            break
if best_state:
    model.load_state_dict(best_state)
sc, bar = eval_model(model)
print(f'\nFinal: {sc}/15  {bar}')
for name, ctx, truth in TESTS:
    ids = torch.tensor([ctx], dtype=torch.long).to(device)
    with torch.no_grad():
        p = int(model(ids)[0, -1].argmax())
    print(f"  {('✓' if p == truth else '✗')} {name:>15}: pred={p:>4}  truth={truth:>4}")
np.savez(os.path.join(_dir, 'big_model_weights.npz'), **{k: v.detach().cpu().numpy() for k, v in model.state_dict().items()})
with open(os.path.join(_dir, 'big_model_meta.json'), 'w') as f:
    json.dump({'VS': VS, 'D': D, 'H': H, 'NL': NL, 'K': K, 'score': sc, 'tests': [{'name': n, 'ctx': c, 'truth': t} for n, c, t in TESTS]}, f, indent=2)
print(f'\nSaved: big_model_weights.npz + big_model_meta.json')
