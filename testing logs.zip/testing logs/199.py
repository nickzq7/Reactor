import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — DELTA TEST')
print('  Target = output - input (the correction).')
print('  This is what transformer block actually does.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'  Loaded. Layers={n_layers} D={D}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ R²=1.0' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<52} {mark}')
    return score
sentences = ['Once upon a time there was a little girl named Lily who loved flowers', 'She loved to play outside in the sunshine with her puppy Max', 'One day she saw a big shiny rock in the sky above her house', 'The dog ran to the park and saw a big friendly golden dog', 'A boy named Tom found a magic wand near the old oak tree', 'The princess looked out the window at the beautiful green garden', 'One day a small rabbit decided to hop through the deep forest', 'He climbed up the tall tree to see what was at the very top', 'She picked up the red flowers and smiled at her loving mother', 'The children played happily together in the warm and sunny yard', 'A kind fairy came to grant three wishes to the very poor farmer', 'The brave knight rode his horse into the dark and deep forest', 'She opened the door slowly and looked outside at the white snow', 'He found a little puppy sleeping near the old red wooden house', 'The sun rose slowly over the distant green and rolling hills today', 'A small fish swam in the clear blue calm lake all by itself', 'The baby bear found golden honey in the big hollow oak tree', 'She whispered a sweet secret to her very best friend at school', 'A clever fox tricked the big bad wolf and quickly ran far away', 'The little prince lived alone on a very tiny and small planet', 'Once there was a friendly dragon who wanted to make some friends', 'The old wise wizard taught the young curious boy how to use magic', 'A tiny seed grew slowly and carefully into a tall beautiful flower', 'The friendly giant woke up and smiled warmly at the whole village', 'She found a lost little kitten crying softly in the cold rain', 'The two good friends walked together through the enchanted green forest', 'A bright rainbow appeared in the blue sky after the long rain', 'The kind queen shared all her food with all the hungry poor people', 'A little yellow duck learned to swim in the warm sunny pond', 'The white snow fell softly and quietly on the sleeping little village', 'He closed his tired eyes and wished upon the very first bright star', 'The orange cat chased the butterfly through the green and sunny garden', 'A small wooden boat sailed slowly across the wide quiet blue lake', 'The children found a treasure map inside the old and dark chest', 'She drew a colorful picture of her happy and always smiling family', 'The bright moon shone clearly over the quiet and peaceful little town', 'A young brave boy climbed the tall cold mountain to see the world', 'The kind old woman gave warm fresh bread to all the hungry children', 'He discovered a hidden door behind the dusty and old wooden bookshelf', 'The baby elephant splashed and played happily in the warm muddy water', 'She sang a sweet lullaby to help the tired baby fall asleep', 'The brave little mouse found a piece of cheese in the dark pantry', 'A young girl named Emma loved to read books about faraway places', 'The old farmer woke up very early to feed all his animals', 'A baby elephant learned to use its trunk to pick up fruit', 'The wolf huffed and puffed but could not blow the house down', 'Three little bears came home to find someone had eaten their porridge', 'The frog jumped from lily pad to lily pad across the pond', 'A small butterfly emerged from its cocoon and spread its wings wide', 'The children built a big snowman in the yard after the storm', 'A wise old owl sat in the tree and watched the forest below', 'The kitten played with a ball of yarn all afternoon in the sun', 'A girl found a magic lamp and a genie appeared to grant wishes', 'The turtle and the rabbit decided to have a race through the woods', 'She watered her plants every morning before going to school each day', 'The train pulled into the station and many happy passengers got off', 'A boy built a small raft and sailed it down the gentle river', 'The lighthouse keeper watched over the ships sailing through the fog', 'A family of ducks waddled from the pond to the nearby grassy park', 'The baker made fresh warm bread every single morning for the village', 'A young wizard found a book of spells hidden in the old library']
CTX = 8
layer_idx = 0
print(f'\n  Collecting from {len(sentences)} sentences...')
print(f'  Target: correction = output - input')
X_list = []
Y_delta_list = []
Y_out_list = []
rule_list = []
block = model.transformer.h[layer_idx]
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=40, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            x_np = hs[layer_idx][0, start:start + CTX].numpy()
            y_np = hs[layer_idx + 1][0, start:start + CTX].numpy()
            delta = y_np - x_np
            X_list.append(x_np.flatten())
            Y_delta_list.append(delta.flatten())
            Y_out_list.append(y_np.flatten())
            x_t = hs[layer_idx][0, start:start + CTX]
            ln1 = block.ln_1(x_t).numpy()
            att = block.attn(x_t.unsqueeze(0))[0].squeeze(0).numpy()
            x2 = x_np + att
            ln2 = block.ln_2(torch.tensor(x2, dtype=torch.float32)).numpy()
            pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
            act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
            ffn = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).numpy()
            ind = (pre > 0).astype(float)
            rule_feats = np.concatenate([x_np.flatten(), ln1.flatten(), att.flatten(), ln2.flatten(), (pre * ind).flatten(), ffn.flatten()])
            rule_list.append(rule_feats)
N = len(X_list)
X = np.array(X_list)
Y_delta = np.array(Y_delta_list)
Y_out = np.array(Y_out_list)
X_rules = np.array(rule_list)
N_tr = int(N * 0.8)
print(f'  Samples: {N}  Train: {N_tr}  Test: {N - N_tr}')
print(f'  X shape: {X.shape}')
print(f'  Rule features: {X_rules.shape[1]}')
print(f'  Ratio samples/features: {N_tr}/{X_rules.shape[1]} = {N_tr / X_rules.shape[1]:.1f}x')
print('\n' + '─' * 62)
print('  TARGET: full output  (previous approach)')
print('─' * 62)
print()
test(X[:N_tr], Y_out[:N_tr], X[N_tr:], Y_out[N_tr:], 'raw x → full output')
test(X_rules[:N_tr], Y_out[:N_tr], X_rules[N_tr:], Y_out[N_tr:], 'rules → full output')
print('\n' + '─' * 62)
print('  TARGET: delta = output - input  (correction)')
print('  This is what block actually does.')
print('─' * 62)
print()
test(X[:N_tr], Y_delta[:N_tr], X[N_tr:], Y_delta[N_tr:], 'raw x → delta')
test(X_rules[:N_tr], Y_delta[:N_tr], X_rules[N_tr:], Y_delta[N_tr:], 'rules → delta')
print('\n' + '─' * 62)
print('  PROGRESSIVE ON DELTA')
print('  Which rule captures the correction?')
print('─' * 62)
print()

def get_up_to(X_rules, col_end):
    return X_rules[:, :col_end]
col_x = CTX * D
col_ln1 = col_x + CTX * D
col_att = col_ln1 + CTX * D
col_ln2 = col_att + CTX * D
col_relu = col_ln2 + CTX * (D * 4)
col_ffn = col_relu + CTX * D
levels = [(col_x, 'raw input only'), (col_ln1, '+ LayerNorm1'), (col_att, '+ Attention correction'), (col_ln2, '+ LayerNorm2'), (col_relu, '+ ReLU activated'), (col_ffn, '+ FFN correction')]
for col_end, label in levels:
    if col_end <= X_rules.shape[1]:
        Xp = X_rules[:, :col_end]
        test(Xp[:N_tr], Y_delta[:N_tr], Xp[N_tr:], Y_delta[N_tr:], label)
print('\n' + '=' * 62)
print('  HIDDEN LAW REVEALED')
print('=' * 62)
print("\n  Delta = what block adds to input.\n  This is the true transformation.\n  Not the full output (which is mostly input).\n\n  Progressive on delta shows:\n  Where R² grows most = dominant rule.\n  Where R² stalls    = hidden law still there.\n\n  Attention correction captures context mixing.\n  FFN correction captures feature transformation.\n  If R²=1.0: both rules complete.\n  If R²<1.0: interaction between them is hidden.\n\n  The interaction between attention and FFN\n  through the residual stream =\n  this may be the deepest hidden law.\n  Not in either operation alone.\n  In how they combine.\n  That combination = transformer's true secret.\n")
print('=' * 62 + '\n')
