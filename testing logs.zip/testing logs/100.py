import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN, N_TEST, MAX_SEQ = (500, 100, 64)
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={DEVICE}')
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(DEVICE).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD = H // NH
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
with torch.no_grad():
    Wte = teacher.transformer.wte.weight.float().cpu().numpy()
    Wpe = teacher.transformer.wpe.weight.float().cpu().numpy()
    lnf_g = teacher.transformer.ln_f.weight.float().cpu().numpy()
    lnf_b = teacher.transformer.ln_f.bias.float().cpu().numpy()
    Wlm = teacher.lm_head.weight.float().cpu().numpy()
    LN = []
    for li in range(NL):
        bl = teacher.transformer.h[li]
        LN.append({'ln1_g': bl.ln_1.weight.float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.float().cpu().numpy(), 'type': ATT[li] if li < len(ATT) else 'global'})
del teacher
torch.cuda.empty_cache()
VOCAB = Wlm.shape[0]
print(f'  NL={NL} H={H} NH={NH} HD={HD}  VOCAB={VOCAB}')

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (g * (x - m) / np.sqrt(v + eps) + b).astype(np.float32)

def gelu(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def solve(X, Y):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.concatenate([X64, np.ones((len(X64), 1))], 1)
    res, _, _, _ = lstsq(Xb, Y64, rcond=None)
    W = res[:-1].T.astype(np.float32)
    b = res[-1].astype(np.float32)
    Yp = X64 @ res[:-1] + res[-1]
    r2 = float(1 - ((Y64 - Yp) ** 2).sum() / (((Y64 - Y64.mean(0)) ** 2).sum() + 1e-12))
    return (W, b, r2)

def causal_attn(h, li, w):
    sl = h.shape[0]
    ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
    Q = (ln1_h @ w['Wq'].T + w['bq']).astype(np.float32)
    K = (ln1_h @ w['Wk'].T + w['bk']).astype(np.float32)
    V = (ln1_h @ w['Wv'].T + w['bv']).astype(np.float32)
    Q = Q.reshape(sl, NH, HD).transpose(1, 0, 2)
    K = K.reshape(sl, NH, HD).transpose(1, 0, 2)
    V = V.reshape(sl, NH, HD).transpose(1, 0, 2)
    scores = np.matmul(Q, K.transpose(0, 2, 1)).astype(np.float32)
    mask = np.full((sl, sl), -1000000000.0, np.float32)
    at = LN[li].get('type', 'global')
    for i in range(sl):
        start = max(0, i - WIN + 1) if at == 'local' else 0
        mask[i, start:i + 1] = 0.0
    scores += mask[np.newaxis]
    scores -= scores.max(-1, keepdims=True)
    e = np.exp(scores)
    weights_a = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    ctx = np.matmul(weights_a, V)
    ctx = ctx.transpose(1, 0, 2).reshape(sl, H).astype(np.float32)
    att_out = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
    return att_out

def forward_full(ids_list, weights):
    sl = len(ids_list)
    h = (Wte[np.array(ids_list)] + Wpe[np.arange(sl)]).astype(np.float32)
    for li, w in enumerate(weights):
        att = causal_attn(h, li, w)
        hm = (h + att).astype(np.float32)
        ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
        pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
        ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
        h = (hm + ffn).astype(np.float32)
    return (ln(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32)

def forward_fast(h0, weights):
    h = h0.copy()
    for li, w in enumerate(weights):
        ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
        att = (ln1_h @ w['Wo'].T + w['bo']).astype(np.float32)
        hm = (h + att).astype(np.float32)
        ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
        pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
        ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
        h = (hm + ffn).astype(np.float32)
    return (ln(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32)

def acc(logits, ids):
    return float((np.argmax(logits, -1) == ids).mean())
print(f'\n  Loading data...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
stories = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 300:
        stories.append(t)
    if len(stories) >= N_TRAIN + N_TEST:
        break

def build(story_list):
    h0, nxt = ([], [])
    for s in story_list:
        ids = tok(s, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'][0].tolist()
        if len(ids) < 2:
            continue
        for pos in range(len(ids) - 1):
            h0.append(Wte[ids[pos]] + Wpe[pos])
            nxt.append(ids[pos + 1])
    return (np.array(h0, np.float32), np.array(nxt, np.int32))
H0_tr, IDS_tr = build(stories[:N_TRAIN])
H0_te, IDS_te = build(stories[N_TRAIN:N_TRAIN + N_TEST])
HTGT_tr = Wlm[IDS_tr]
print(f'  Train: {len(IDS_tr)}  Test: {len(IDS_te)}')

def train_pass(h0, htgt, prev_W=None):
    if prev_W is not None:
        acts = [h0.copy()]
        h = h0.copy()
        for li, w in enumerate(prev_W):
            ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
            att = (ln1_h @ w['Wo'].T + w['bo']).astype(np.float32)
            hm = (h + att).astype(np.float32)
            ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
            pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
            ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
            h = (hm + ffn).astype(np.float32)
            acts.append(h.copy())
    else:
        acts = None
    weights = []
    h_cur = h0.copy()
    for li in range(NL):
        frac = (li + 1) / NL
        h_in = acts[li] if acts else h_cur
        h_tgt = ((1 - frac) * h0 + frac * htgt).astype(np.float32)
        ln1_h = ln(h_in, LN[li]['ln1_g'], LN[li]['ln1_b'])
        att_tgt = (h_tgt - h_in).astype(np.float32)
        Wo, bo, _ = solve(ln1_h, att_tgt)
        Wq, bq, _ = solve(ln1_h, ln1_h)
        Wk, bk, _ = solve(ln1_h, ln1_h)
        Wv, bv, _ = solve(ln1_h, ln1_h)
        att_out = (ln1_h @ Wo.T + bo).astype(np.float32)
        hm = (h_in + att_out).astype(np.float32)
        ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
        ffn_tgt = (h_tgt - hm).astype(np.float32)
        W1, b1, _ = solve(ln2_h, ln2_h)
        pre = (ln2_h @ W1.T + b1).astype(np.float32)
        W2, b2, _ = solve(gelu(pre), ffn_tgt)
        ffn_out = (gelu(pre) @ W2.T + b2).astype(np.float32)
        h_cur = (hm + ffn_out).astype(np.float32)
        weights.append(dict(Wq=Wq, bq=bq, Wk=Wk, bk=bk, Wv=Wv, bv=bv, Wo=Wo, bo=bo, W1=W1, b1=b1, W2=W2, b2=b2))
    return weights
print(f'\n  Training (2 passes, 0 gradients)...')
t0 = time.perf_counter()
W_p1 = train_pass(H0_tr, HTGT_tr)
W_p2 = train_pass(H0_tr, HTGT_tr, prev_W=W_p1)
t_train = time.perf_counter() - t0
acc_tr = acc(forward_fast(H0_tr, W_p2), IDS_tr)
acc_te = acc(forward_fast(H0_te, W_p2), IDS_te)
print(f'  Done in {t_train:.2f}s | Train: {acc_tr * 100:.2f}% | Test: {acc_te * 100:.2f}% | {acc_te / (1 / VOCAB):.0f}x random')

def gen_scratch(prompt, n=60):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    for _ in range(n):
        logits = forward_full(ids, W_p2)
        next_id = int(np.argmax(logits[-1]))
        ids.append(next_id)
        if next_id == tok.eos_token_id:
            break
    return tok.decode(ids[len(tok(prompt)['input_ids']):])

def gen_teacher(prompt, n=60):
    t = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(DEVICE).eval()
    inp = tok(prompt, return_tensors='pt').to(DEVICE)
    with torch.no_grad():
        out = t.generate(inp['input_ids'], max_new_tokens=n, do_sample=False, use_cache=True)
    del t
    torch.cuda.empty_cache()
    return tok.decode(out[0][inp['input_ids'].shape[1]:], skip_special_tokens=True)
PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'Tom wanted to play but', 'In the forest there lived a']
print('\n' + '=' * 60)
print('  GENERATION — FULL CAUSAL ATTENTION')
print('  Scratch (0 gradients) vs Teacher (gradient trained)')
print('=' * 60)
for p in PROMPTS:
    print(f'\n  Prompt  : "{p}"')
    t0 = time.perf_counter()
    scratch_out = gen_scratch(p, n=50)
    print(f'  Scratch : {scratch_out.strip()}')
    print(f'  [gen time: {time.perf_counter() - t0:.2f}s]')
print('\n  --- Teacher comparison (1 prompt) ---')
p = PROMPTS[0]
teacher_out = gen_teacher(p, n=50)
scratch_out = gen_scratch(p, n=50)
print(f'  Prompt  : "{p}"')
print(f'  Teacher : {teacher_out.strip()}')
print(f'  Scratch : {scratch_out.strip()}')
print('\n' + '=' * 60)
print(f'  FINAL: Train {acc_tr * 100:.2f}%  Test {acc_te * 100:.2f}%  {acc_te / (1 / VOCAB):.0f}x random  {t_train:.1f}s  0 gradients')
print('=' * 60)
