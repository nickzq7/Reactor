import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_primes(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s

def make_all_patterns():
    pats = {}
    for step in range(1, 25):
        pats[f'a{step}'] = ([i * step % VS for i in range(20)], 20 * step % VS)
    for start in range(25, 33):
        seq = [(start - i) % VS for i in range(20)]
        pats[f'd{start}'] = (seq, (start - 20) % VS)
    fib = gen_fib(40)
    for off in range(8):
        pats[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
    for r in [2, 3, 4, 5, 6, 7, 8, 9]:
        pats[f'g{r}'] = ([r ** i % VS for i in range(20)], r ** 20 % VS)
    for c in range(8):
        pats[f'sq{c}'] = ([(i + c) ** 2 % VS for i in range(20)], (20 + c) ** 2 % VS)
    for step in [3, 5]:
        for off in range(4):
            pats[f's{step}o{off}'] = ([(i * step + off) % VS for i in range(20)], (20 * step + off) % VS)
    return pats
ALL_PATS = make_all_patterns()
PAT_NAMES = list(ALL_PATS.keys())
N_DONORS = 8
DONOR_PATS = [PAT_NAMES[i * 8:(i + 1) * 8] for i in range(N_DONORS)]

class SeqT(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_npz_to_model(path):
    W = {k: v.astype(np.float32) for k, v in np.load(path).items()}
    m = SeqT().to(device)
    with torch.no_grad():
        m.wte.weight.copy_(torch.tensor(W['WTE']))
        m.wpe.weight.copy_(torch.tensor(W['WPE']))
        for l in range(NL):
            ip = torch.tensor(np.concatenate([W[f'WQ{l}'], W[f'WK{l}'], W[f'WV{l}']], 0))
            m.layers[l]['attn'].in_proj_weight.copy_(ip)
            m.layers[l]['attn'].in_proj_bias.zero_()
            m.layers[l]['attn'].out_proj.weight.copy_(torch.tensor(W[f'WO{l}']))
            m.layers[l]['attn'].out_proj.bias.zero_()
            m.layers[l]['ff'][0].weight.copy_(torch.tensor(W[f'W1{l}']))
            m.layers[l]['ff'][0].bias.copy_(torch.tensor(W[f'b1{l}']))
            m.layers[l]['ff'][2].weight.copy_(torch.tensor(W[f'W2{l}']))
            m.layers[l]['ff'][2].bias.copy_(torch.tensor(W[f'b2{l}']))
            m.layers[l]['ln1'].weight.copy_(torch.tensor(W[f'LN1g{l}']))
            m.layers[l]['ln1'].bias.copy_(torch.tensor(W[f'LN1b{l}']))
            m.layers[l]['ln2'].weight.copy_(torch.tensor(W[f'LN2g{l}']))
            m.layers[l]['ln2'].bias.copy_(torch.tensor(W[f'LN2b{l}']))
        m.ln_f.weight.copy_(torch.tensor(W['LNfg']))
        m.ln_f.bias.copy_(torch.tensor(W['LNfb']))
    return m

def get_wte(model):
    return model.wte.weight.detach().numpy().astype(np.float64)

def set_wte(model, wte_np):
    with torch.no_grad():
        model.wte.weight.copy_(torch.tensor(wte_np, dtype=torch.float32))

def eval_all(model):
    model.eval()
    per_donor = []
    for di in range(N_DONORS):
        sc = 0
        for pn in DONOR_PATS[di]:
            seq, truth = ALL_PATS[pn]
            ids = torch.tensor([seq[-K:]], dtype=torch.long)
            with torch.no_grad():
                p = int(model(ids)[0, -1].argmax())
            sc += p == truth
        per_donor.append(sc)
    return (sum(per_donor), per_donor)

def eval_wte_fast(wte_np, base_model):
    orig = get_wte(base_model).copy()
    set_wte(base_model, wte_np)
    total, per_donor = eval_all(base_model)
    set_wte(base_model, orig)
    return (total, per_donor)

def mutate(wte, rng, op=None):
    w = wte.copy()
    VS_, D_ = w.shape
    ops = ['sign_flip', 'scale_dims', 'cross_dims', 'dim_permute', 'subspace_rot', 'inject_axis', 'token_shift', 'noise_inject']
    if op is None:
        op = rng.choice(ops)
    if op == 'sign_flip':
        n = rng.randint(1, max(2, D_ // 3))
        dims = rng.choice(D_, n, replace=False)
        w[:, dims] *= -1
    elif op == 'scale_dims':
        n = rng.randint(1, max(2, D_ // 4))
        dims = rng.choice(D_, n, replace=False)
        scales = rng.uniform(0.3, 3.0, n)
        w[:, dims] *= scales
    elif op == 'cross_dims':
        d1, d2 = rng.choice(D_, 2, replace=False)
        alpha = rng.uniform(0.1, 0.9)
        c1 = alpha * w[:, d1] + (1 - alpha) * w[:, d2]
        c2 = (1 - alpha) * w[:, d1] + alpha * w[:, d2]
        w[:, d1] = c1
        w[:, d2] = c2
    elif op == 'dim_permute':
        n = rng.randint(2, max(3, D_ // 2))
        dims = rng.choice(D_, n, replace=False)
        perm = rng.permutation(n)
        w[:, dims] = w[:, dims[perm]]
    elif op == 'subspace_rot':
        n = rng.randint(2, max(3, D_ // 2))
        dims = rng.choice(D_, n, replace=False)
        angle = rng.uniform(0.1, math.pi)
        i, j = (dims[0], dims[1])
        c, s = (math.cos(angle), math.sin(angle))
        wi = w[:, i].copy()
        wj = w[:, j].copy()
        w[:, i] = c * wi - s * wj
        w[:, j] = s * wi + c * wj
    elif op == 'inject_axis':
        d = rng.randint(D_)
        direction = rng.randn(VS_)
        direction /= np.linalg.norm(direction) + 1e-08
        strength = rng.uniform(0.1, 1.0) * np.std(w)
        w[:, d] += strength * direction
    elif op == 'token_shift':
        n_tok = rng.randint(2, max(3, VS_ // 3))
        toks = rng.choice(VS_, n_tok, replace=False)
        shift = rng.randn(D_) * rng.uniform(0.05, 0.3) * np.std(w)
        w[toks] += shift
    elif op == 'noise_inject':
        strength = rng.uniform(0.01, 0.15) * np.std(w)
        w += rng.randn(*w.shape) * strength
    return (w, op)

def crossbreed(wte_list, rng):
    n = len(wte_list)
    child = np.zeros_like(wte_list[0])
    for d in range(child.shape[1]):
        parent = rng.randint(n)
        child[:, d] = wte_list[parent][:, d]
    n_flip = rng.randint(1, 4)
    flip_dims = rng.choice(child.shape[1], n_flip, replace=False)
    child[:, flip_dims] *= -1
    return child

def build_tensors():
    Xs = []
    Ys = []
    for pn in PAT_NAMES:
        seq, _ = ALL_PATS[pn]
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long, device=device), torch.tensor(Ys, dtype=torch.long, device=device))
ALL_X, ALL_Y = build_tensors()

def train_child(init_wte, steps=3000, lr=0.003, label='child', print_every=300):
    model = SeqT().to(device)
    set_wte(model, init_wte)
    for name, param in model.named_parameters():
        if 'wte' not in name:
            if param.dim() > 1:
                nn.init.xavier_uniform_(param)
            else:
                nn.init.zeros_(param)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=5e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, per = eval_all(model)
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  [{label}] step {step:>5}: {sc:>2}/64  {per}', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    return (best_s, model)
print('=' * 60)
print('  PHASE 2 — DEEP MUTATION SEARCH')
print('  Loading pre-trained donors...')
print('=' * 60)
donors = []
for di in range(N_DONORS):
    path = os.path.join(_dir, f'donor_{di:02d}.npz')
    m = load_npz_to_model(path)
    sc, per = eval_all(m)
    donors.append(m)
    print(f'  Donor {di + 1}/8  {sc}/8  {per}', flush=True)
donor_wtes = [get_wte(d) for d in donors]
base_model = donors[0]
N_MUTATIONS = 15000
N_GENERATIONS = 5
MIN_SCORE = 2
NICHE_SIZE = 5
rng = np.random.RandomState(42)
print(f"\n{'=' * 60}")
print(f'  MUTATION SEARCH: {N_MUTATIONS} mutations')
print(f'  Tracking niches per donor (8 niches × {NICHE_SIZE} survivors)')
print(f"{'=' * 60}")
niches = [[] for _ in range(N_DONORS)]
global_best = (0, None, None)
t0 = time.time()
for mi in range(N_MUTATIONS):
    r = rng.rand()
    if r < 0.6 or all((len(n) == 0 for n in niches)):
        base_wte = donor_wtes[rng.randint(N_DONORS)].copy()
    elif r < 0.9:
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        ni = rng.choice(nonempty)
        _, _, base_wte = niches[ni][rng.randint(len(niches[ni]))]
        base_wte = base_wte.copy()
    else:
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        if len(nonempty) >= 2:
            ni1, ni2 = rng.choice(nonempty, 2, replace=False)
            w1 = niches[ni1][rng.randint(len(niches[ni1]))][2]
            w2 = niches[ni2][rng.randint(len(niches[ni2]))][2]
            base_wte = crossbreed([w1, w2], rng)
        else:
            ni = nonempty[0]
            _, _, base_wte = niches[ni][rng.randint(len(niches[ni]))]
            base_wte = base_wte.copy()
    n_ops = 1 if rng.rand() < 0.7 else 2
    mut_wte = base_wte.copy()
    for _ in range(n_ops):
        mut_wte, op = mutate(mut_wte, rng)
    total, per_donor = eval_wte_fast(mut_wte, base_model)
    if total > global_best[0]:
        global_best = (total, per_donor[:], mut_wte.copy())
        print(f'  mut {mi:>6}  NEW GLOBAL BEST: {total}/64  {per_donor}', flush=True)
    for di in range(N_DONORS):
        if per_donor[di] >= MIN_SCORE:
            niches[di].append((per_donor[di], total, mut_wte.copy()))
            niches[di].sort(key=lambda x: (x[0], x[1]), reverse=True)
            niches[di] = niches[di][:NICHE_SIZE]
    if (mi + 1) % 1000 == 0:
        niche_counts = [len(n) for n in niches]
        elapsed = time.time() - t0
        remaining = elapsed / (mi + 1) * (N_MUTATIONS - mi - 1)
        print(f'  {mi + 1:>6}/{N_MUTATIONS}  best={global_best[0]}/64  niches={niche_counts}  {elapsed:.0f}s elapsed  ~{remaining:.0f}s left', flush=True)
print(f'\n  Search done. {time.time() - t0:.1f}s')
print(f'  Global best: {global_best[0]}/64  per_donor: {global_best[1]}')
print(f'  Niche sizes: {[len(n) for n in niches]}')
print(f"\n{'=' * 60}")
print(f'  MULTI-GENERATION CROSSBREEDING ({N_GENERATIONS} generations)')
print(f"{'=' * 60}")
all_survivors = []
for di, niche in enumerate(niches):
    for sc_d, sc_t, wte in niche:
        all_survivors.append((sc_t, sc_d, di, wte))
all_survivors.sort(reverse=True)
print(f'\n  Total survivors from niches: {len(all_survivors)}')
print(f'  Top 10:')
for i, (sc_t, sc_d, di, _) in enumerate(all_survivors[:10]):
    print(f'    {i + 1}. total={sc_t}/64  donor_{di + 1}={sc_d}/8')
best_gen_wte = global_best[2] if global_best[2] is not None else donor_wtes[0].copy()
best_gen_score = global_best[0]
for gen in range(N_GENERATIONS):
    print(f'\n  Generation {gen + 1}:')
    N_CHILDREN = 200
    children_scores = []
    for ci in range(N_CHILDREN):
        nonempty = [i for i, n in enumerate(niches) if len(n) > 0]
        n_parents = min(rng.randint(2, 5), len(nonempty))
        parent_niches = rng.choice(nonempty, n_parents, replace=False)
        parent_wtes = []
        for ni in parent_niches:
            _, _, wte = niches[ni][rng.randint(len(niches[ni]))]
            parent_wtes.append(wte)
        child_wte = crossbreed(parent_wtes, rng)
        if rng.rand() < 0.5:
            child_wte, _ = mutate(child_wte, rng)
        sc_t, per = eval_wte_fast(child_wte, base_model)
        children_scores.append((sc_t, per, child_wte))
        for di in range(N_DONORS):
            if per[di] >= MIN_SCORE:
                niches[di].append((per[di], sc_t, child_wte.copy()))
                niches[di].sort(key=lambda x: (x[0], x[1]), reverse=True)
                niches[di] = niches[di][:NICHE_SIZE]
        if sc_t > best_gen_score:
            best_gen_score = sc_t
            best_gen_wte = child_wte.copy()
            print(f'    child {ci}: NEW BEST {sc_t}/64  {per}', flush=True)
    children_scores.sort(reverse=True)
    top5 = children_scores[:5]
    print(f'    Top 5 children: {[s[0] for s in top5]}')
    print(f'    Best child: {top5[0][0]}/64  per_donor: {top5[0][1]}')
print(f"\n{'=' * 60}")
print(f'  TRAINING BEST CHILD')
print(f'  Init score: {best_gen_score}/64')
print(f'  3000 steps on all 64 patterns')
print(f"{'=' * 60}\n")
final_score, final_model = train_child(best_gen_wte, steps=3000, lr=0.003, label='best_child', print_every=300)
print(f"\n{'=' * 60}")
print(f'  FINAL RESULTS')
print(f"{'=' * 60}")
sc, per = eval_all(final_model)
print(f'\n  Final score: {sc}/64')
for di in range(N_DONORS):
    bar = ''.join(('█' if ALL_PATS[DONOR_PATS[di][pi]][1] == int(final_model(torch.tensor([ALL_PATS[DONOR_PATS[di][pi]][0][-K:]], dtype=torch.long))[0, -1].argmax()) else '░' for pi in range(8)))
    print(f'  Donor {di + 1}  {bar}  {per[di]}/8')
print(f'\n  WHAT WORKED:\n    Random mutation search found survivors in each niche.\n    Crossbreeding niche survivors produced a child with\n    knowledge from all 8 donors simultaneously.\n    Training reinforced the transferred structure.\n')
print('=' * 60)
