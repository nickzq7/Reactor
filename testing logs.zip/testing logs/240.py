import numpy as np
import math
import time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 60)
print('  W-KERNEL v12 FAST — ONE SHOT SOLVE')
print('=' * 60)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do\n'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
freq = Counter(toks)
iw_raw = {t: -math.log(freq[t] / N) for t in freq}
mn, mx = (min(iw_raw.values()), max(iw_raw.values()))
IW = {t: 0.5 + 0.5 * (iw_raw[t] - mn) / (mx - mn + 1e-08) for t in iw_raw}
K = 8
VS2 = VS
D_in = K * VS2
D_h = 64
LAM = 0.001
print(f'\n  Vocab={VS}  Tokens={N}  D_in={D_in}  D_h={D_h}')
print(f'  N/D_in={N // D_in}x — well determined\n')
print('  Building dataset...', end=' ', flush=True)
Xc = np.zeros((N - K, D_in), dtype=np.float32)
Yc = np.zeros((N - K, VS), dtype=np.float32)
Wt = np.zeros(N - K, dtype=np.float32)
for i in range(K, N):
    row = i - K
    for j in range(K):
        tok = toks[i - K + j]
        Xc[row, j * VS + tok] = 1.0
    Yc[row, toks[i]] = 1.0
    Wt[row] = IW.get(toks[i], 0.5)
print(f'done. Shape: X={Xc.shape} Y={Yc.shape}')
print('  Solving W0 (context → hidden)...', end=' ', flush=True)
t1 = time.time()
Xc64 = Xc.astype(np.float64)
Yh = np.zeros((N - K, D_h), dtype=np.float64)
Wt64 = Wt.astype(np.float64)
Xb = np.hstack([Xc64, np.ones((N - K, 1))])
Wd = np.diag(Wt64)
A = Xb.T @ Wd @ Xb + LAM * np.eye(D_in + 1)
B = Xb.T @ (Wd @ Yh)
A0 = Xb.T @ Wd @ Xb + LAM * np.eye(D_in + 1)
B0 = Xb.T @ (Wd @ Yc.astype(np.float64))
W0_direct = np.linalg.solve(A0, B0)
W0_w = W0_direct[:-1]
W0_b = W0_direct[-1]
print(f'done ({time.time() - t1:.1f}s)')
print('  Solving W1+W2 (hidden refinement)...', end=' ', flush=True)
t2 = time.time()
U, S, Vt = np.linalg.svd(Xc64, full_matrices=False)
W0_h = Vt[:D_h].T
b0_h = np.zeros(D_h)
H = np.tanh(Xc64 @ W0_h + b0_h)
Hb = np.hstack([H, np.ones((N - K, 1))])
A2 = Hb.T @ Wd @ Hb + LAM * np.eye(D_h + 1)
B2 = Hb.T @ (Wd @ Yc.astype(np.float64))
W2_sol = np.linalg.solve(A2, B2)
W2_w = W2_sol[:-1]
W2_b = W2_sol[-1]
print(f'done ({time.time() - t2:.1f}s)')

def ppl_direct(n=2000):
    nll = 0.0
    tok = 0
    step = max(1, (N - K) // n)
    for i in range(0, N - K, step):
        lg = Xc64[i] @ W0_w + W0_b
        if not np.all(np.isfinite(lg)):
            continue
        lg -= lg.max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[np.argmax(Yc[i])]
        tok += 1
    return math.exp(min(nll / tok, 500)) if tok > 0 else 999.0

def ppl_hidden(n=2000):
    nll = 0.0
    tok = 0
    step = max(1, (N - K) // n)
    for i in range(0, N - K, step):
        h = np.tanh(Xc64[i] @ W0_h + b0_h)
        lg = h @ W2_w + W2_b
        if not np.all(np.isfinite(lg)):
            continue
        lg -= lg.max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[np.argmax(Yc[i])]
        tok += 1
    return math.exp(min(nll / tok, 500)) if tok > 0 else 999.0
print(f'\n  Evaluating...', end=' ', flush=True)
p_direct = ppl_direct()
p_hidden = ppl_hidden()
print('done')
print(f'\n  Direct (1 layer):  ppl={p_direct:.2f}  ratio={p_direct / VS:.3f}')
print(f'  Hidden (2 layer):  ppl={p_hidden:.2f}  ratio={p_hidden / VS:.3f}')
print(f'  Vocab=28  (below = sequence learning confirmed)')

def gen_ctx(ids):
    ctx = np.zeros(D_in, dtype=np.float64)
    for j in range(K):
        if j < len(ids):
            tok = ids[-(K - j)]
            ctx[j * VS + tok] = 1.0
    return ctx

def sample(logits, temp=0.8, top_k=8):
    lg = logits - logits.max()
    lg = lg / temp
    if top_k < len(lg):
        thresh = np.sort(lg)[-top_k]
        lg[lg < thresh] = -1000000000.0
    p = np.exp(lg)
    p /= p.sum()
    return int(np.random.choice(VS, p=p))

def generate(prompt, n=120, temp=0.8, model='hidden'):
    np.random.seed(42)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        ctx = gen_ctx(ids)
        if model == 'hidden':
            h = np.tanh(ctx @ W0_h + b0_h)
            lg = h @ W2_w + W2_b
        else:
            lg = ctx @ W0_w + W0_b
        if not np.all(np.isfinite(lg)):
            break
        ids.append(sample(lg, temp=temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION (hidden model, temp=0.8):\n')
for prompt in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(prompt, temp=0.8)
    print(f"  '{prompt}'")
    print(f'    {out[len(prompt):][:70]}')
print(f'\n  GENERATION (temp=1.0):\n')
for prompt in ['once upon a time ', 'the brave knight ']:
    out = generate(prompt, temp=1.0)
    print(f"  '{prompt}'")
    print(f'    {out[len(prompt):][:70]}')
print(f'\n  BIGRAM CHECK (what sequences were learned):')
for prev in ['t', 'h', 'e', ' ', 'a', 'o', 'n']:
    if prev not in c2i:
        continue
    ctx = np.zeros(D_in, dtype=np.float64)
    ctx[(K - 1) * VS + c2i[prev]] = 1.0
    h = np.tanh(ctx @ W0_h + b0_h)
    lg = h @ W2_w + W2_b
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{prev}': {top3}")
gen_sp = generate('the ', n=300, temp=0.85)
space_pct = 100 * gen_sp[4:].count(' ') / len(gen_sp[4:])
cnt = Counter(gen_sp[4:])
top5 = [(c, f'{100 * cnt[c] // len(gen_sp[4:])}%') for c, _ in Counter(gen_sp[4:]).most_common(5)]
print(f'\n  Space% = {space_pct:.0f}%  (target ≈ 18%)')
print(f'  Top-5 chars: {top5}')
print(f'\n  Total time: {time.time() - t0:.1f}s')
print(f"\n{'=' * 60}")
print(f'  ppl={p_hidden:.2f}  ratio={p_hidden / VS:.3f}')
if p_hidden < VS:
    print(f'  ✓ Below vocab. Sequence learning confirmed.')
if space_pct > 12:
    print(f'  ✓ Space% = {space_pct:.0f}%. Words separating.')
print('=' * 60 + '\n')
