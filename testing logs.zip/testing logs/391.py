import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
n_heads = model.config.num_heads
head_dim = D // n_heads
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}  heads={n_heads}  head_dim={head_dim}')

def numerical_rank(S, tol_factors=[0.001, 0.0001, 1e-06, 1e-07, 1e-09]):
    results = {}
    for f in tol_factors:
        tol = f * S[0] if S[0] > 0 else f
        results[f] = int(np.sum(S > tol))
    return results
print(f"\n{'=' * 70}")
print(f'  TEST A — SINGULAR VALUE SPECTRA ALL WEIGHT MATRICES')
print(f'  Looking for HARD CUTOFF: S[k] = 0 exactly after rank k.')
print(f"{'=' * 70}\n")
all_weights = {}
for li in range(n_layers):
    all_weights[f'W_q_{li}'] = model.transformer.h[li].attn.attention.q_proj.weight.detach().float().numpy()
    all_weights[f'W_k_{li}'] = model.transformer.h[li].attn.attention.k_proj.weight.detach().float().numpy()
    all_weights[f'W_v_{li}'] = model.transformer.h[li].attn.attention.v_proj.weight.detach().float().numpy()
    all_weights[f'W_o_{li}'] = model.transformer.h[li].attn.attention.out_proj.weight.detach().float().numpy()
    all_weights[f'W1_{li}'] = model.transformer.h[li].mlp.c_fc.weight.detach().float().numpy()
    all_weights[f'W2_{li}'] = model.transformer.h[li].mlp.c_proj.weight.detach().float().numpy()
print(f"  {'Matrix':<12} {'Shape':<14} {'true_rank(1e-6)':<20} {'true_rank(1e-4)':<20} {'min_S':<14} {'max_S':<10}")
print(f"  {'─' * 85}")
type_ranks = {t: [] for t in ['W_q', 'W_k', 'W_v', 'W_o', 'W1', 'W2']}
for name, W in all_weights.items():
    mtype = name.rsplit('_', 1)[0]
    U, S, Vt = np.linalg.svd(W.astype(np.float64), full_matrices=False)
    ranks = numerical_rank(S)
    min_s = float(S[-1])
    max_s = float(S[0])
    type_ranks[mtype].append((S, W.shape, ranks))
    print(f'  {name:<12} {str(W.shape):<14} {ranks[1e-06]:<20} {ranks[0.0001]:<20} {min_s:<14.6f} {max_s:.4f}')
print(f"\n{'=' * 70}")
print(f'  TEST B — ARE MINIMUM SINGULAR VALUES EXACTLY ZERO?')
print(f'  S[-1] = 0.000000 → true rank deficiency.')
print(f'  S[-1] > 0 → full rank (no exact compression).')
print(f"{'=' * 70}\n")
print(f'  Matrix type summary (across 8 layers):')
print(f"  {'Type':<8} {'Mean_S_min':<16} {'Mean_S_max':<14} {'Mean_S_min/S_max':<20} {'Truly_zero?'}")
print(f"  {'─' * 65}")
for mtype, data in type_ranks.items():
    s_mins = [d[0][-1] for d in data]
    s_maxs = [d[0][0] for d in data]
    ratios = [s_mins[i] / (s_maxs[i] + 1e-10) for i in range(len(s_mins))]
    truly_zero = all((s < 1e-06 for s in s_mins))
    print(f"  {mtype:<8} {np.mean(s_mins):<16.6f} {np.mean(s_maxs):<14.4f} {np.mean(ratios):<20.6f} {('YES ✓✓' if truly_zero else 'no')}")
print(f"\n{'=' * 70}")
print(f'  TEST C — NORMALIZED SINGULAR VALUE SPECTRUM')
print(f'  S_norm = S / S[0]. How fast do they decay?')
print(f'  Hard cutoff at k: S_norm[k] ≈ 0. True rank = k.')
print(f'  Gradual decay: no hard cutoff. Approximately full rank.')
print(f"{'=' * 70}\n")
for mtype in ['W_o', 'W1', 'W2', 'W_q']:
    data = type_ranks[mtype]
    all_S = np.array([d[0] for d in data])
    S_mean = all_S.mean(0) / all_S.mean(0)[0]
    min_dim = all_S.shape[1]
    checkpoints = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 15, 19, 23, 31, min_dim - 1]
    checkpoints = [c for c in checkpoints if c < min_dim]
    print(f'  {mtype} (mean across layers, normalized to S[0]=1.0):')
    print(f'  ' + '  '.join([f'S[{c}]={S_mean[c]:.4f}' for c in checkpoints]))
    for tol in [0.1, 0.01, 0.001]:
        cutoff = int(np.searchsorted(-S_mean, -tol))
        print(f'    S < {tol}: first at index {cutoff} of {min_dim}' + (f'  → TRUE RANK = {cutoff}' if S_mean[cutoff - 1] > tol > S_mean[cutoff] else ''))
    print()
print(f"\n{'=' * 70}")
print(f'  TEST D — EXACT RECONSTRUCTION AT NUMERICAL RANK')
print(f'  Reconstruct W using only singular values > 1e-4 * S[0].')
print(f'  If W_recon = W exactly (max_err=0): compression is exact.')
print(f"{'=' * 70}\n")
print(f"  {'Matrix':<12} {'rank_used':<12} {'max_err':<16} {'rel_err':<14} {'Exact?'}")
print(f"  {'─' * 60}")
for name, W in all_weights.items():
    W_d = W.astype(np.float64)
    U, S, Vt = np.linalg.svd(W_d, full_matrices=False)
    tol = 0.0001 * S[0]
    k = int(np.sum(S > tol))
    W_recon = U[:, :k] @ np.diag(S[:k]) @ Vt[:k, :]
    me = float(np.max(np.abs(W_recon - W_d)))
    re = me / (float(np.max(np.abs(W_d))) + 1e-10)
    exact = me < 1e-05
    print(f"  {name:<12} {k:<12} {me:<16.8f} {re:<14.6f} {('✓✓ EXACT' if exact else '✗ approx')}")
print(f"\n{'=' * 70}")
print(f'  TEST E — DOES W_o RANK EXPLAIN ATTN OUTPUT RANK?')
print(f'  If rank(W_o) = k: attn_output always k-dimensional.')
print(f'  Compare: rank(W_o) vs eff_rank of attn_output (from TEST B).')
print(f"{'=' * 70}\n")
print(f'  Previously measured attn_output eff_rank_95% = 13-21 of D=64.')
print()
print(f'  W_o rank per layer:')
print(f"  {'Layer':<8} {'rank(1e-4)':<14} {'rank(1e-6)':<14} {'S[17]/S[0]':<14} {'S[20]/S[0]'}")
print(f"  {'─' * 55}")
for li in range(n_layers):
    W = all_weights[f'W_o_{li}'].astype(np.float64)
    U, S, Vt = np.linalg.svd(W, full_matrices=False)
    r4 = int(np.sum(S > 0.0001 * S[0]))
    r6 = int(np.sum(S > 1e-06 * S[0]))
    s17 = S[min(16, len(S) - 1)] / S[0]
    s20 = S[min(19, len(S) - 1)] / S[0]
    print(f'  {li:<8} {r4:<14} {r6:<14} {s17:<14.4f} {s20:.4f}')
print(f"\n{'=' * 70}")
print(f'  TEST F — HEAD-DIM CONSTRAINT')
print(f'  Each attention head: head_dim={head_dim}')
print(f'  n_heads={n_heads} heads × head_dim={head_dim} = D={D}')
print(f'  W_v maps D→D but head i operates in a 4-dim subspace.')
print(f'  W_o maps from 16 concatenated 4-dim heads.')
print(f'  Does head structure force rank?')
print(f"{'=' * 70}\n")
li = 0
W_o = all_weights['W_o_0'].astype(np.float64)
print(f'  W_o block structure (head contribution ranks):')
print(f"  {'Head':<8} {'Block shape':<16} {'rank(1e-4)':<14} {'rank(1e-6)'}")
print(f"  {'─' * 48}")
for head in range(n_heads):
    start = head * head_dim
    end = (head + 1) * head_dim
    block = W_o[:, start:end]
    U, S, Vt = np.linalg.svd(block, full_matrices=False)
    r4 = int(np.sum(S > 0.0001 * S[0]))
    r6 = int(np.sum(S > 1e-06 * S[0]))
    print(f'  {head:<8} {str(block.shape):<16} {r4:<14} {r6}')
print(f'\n  Key insight: each head block is D×head_dim = {D}×{head_dim}.')
print(f'  Max rank per block = head_dim = {head_dim}.')
print(f'  n_heads={n_heads} blocks × rank {head_dim} = max total rank {n_heads * head_dim}={D}.')
print(f'  But if each head block actually has rank < {head_dim}: W_o is low rank.')
print(f"\n{'=' * 70}")
print(f'  W LAW — THE WEIGHT RANK STRUCTURE')
print(f"{'=' * 70}")
print(f'\n  THREE POSSIBILITIES (what the tests will reveal):\n\n  CASE 1: S[-1] = 0 exactly for some weight matrices.\n    True rank deficiency. Matrices are EXACTLY low rank.\n    Compression = exact. Store U,S,V at true rank.\n    No error introduced. No residual accumulation.\n    IMPLICATION: Training created genuinely low-rank matrices.\n    Why? Because the TASK only requires low-rank operations.\n    The universe (W) contains only what is needed.\n    No redundancy. Exact minimal representation.\n\n  CASE 2: S[-1] > 0 but very small (gradual decay).\n    No exact rank cutoff. Full rank technically.\n    Compression = approximation only. Residual accumulates.\n    (This is what we saw before, which broke things.)\n\n  CASE 3: Head structure forces rank.\n    Each head: head_dim={head_dim}. \n    W_o per head block: rank ≤ {head_dim}.\n    Total attention output rank ≤ n_heads × {head_dim} = {D}.\n    But if head ranks < {head_dim}: W_o total rank < {D}.\n    This = structural law from architecture.\n    Not learned. Built in. Always.\n\n  THE W LAW PREDICTION:\n    W = the universe = contains exactly what is needed.\n    No more. No less.\n    If the task requires rank-k, gradient descent finds rank-k.\n    The weight matrices are exactly as complex as the task demands.\n    Measuring their true rank = measuring the complexity of language.\n')
print('=' * 70 + '\n')
