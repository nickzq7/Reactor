import os, json, math, time
import numpy as np
_dir = os.path.dirname(os.path.abspath(__file__))
WA = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'num_small_weights.npz')).items()}
WB = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'num_large_weights.npz')).items()}
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
DA = meta['DA']
HA = meta['HA']
NLA = meta['NLA']
KA = meta['KA']
DB = meta['DB']
HB = meta['HB']
NLB = meta['NLB']
KB = meta['KB']
tests = [(name, seq, truth) for name, seq, truth in meta['test_patterns']]

def ln(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=False):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def fwd(ids, Ww, D_, H_, NL_, K_):
    seq = np.array(ids)
    slen = len(seq)
    x = Ww['WTE'][seq] + Ww['WPE'][np.arange(slen)]
    for l in range(NL_):
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        ln1 = ln(x, Ww[f'LN1g{l}'], Ww[f'LN1b{l}'])
        Q = ln1 @ Ww[f'WQ{l}'].T
        Kk = ln1 @ Ww[f'WK{l}'].T
        V = ln1 @ Ww[f'WV{l}'].T
        hd = D_ // H_
        Qh = Q.reshape(slen, H_, hd).transpose(1, 0, 2)
        Kh = Kk.reshape(slen, H_, hd).transpose(1, 0, 2)
        Vh = V.reshape(slen, H_, hd).transpose(1, 0, 2)
        ctx = np.stack([softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H_)], 1).reshape(slen, -1)
        att = ctx @ Ww[f'WO{l}'].T
        hm = x + att
        ln2 = ln(hm, Ww[f'LN2g{l}'], Ww[f'LN2b{l}'])
        pre = ln2 @ Ww[f'W1{l}'].T + Ww[f'b1{l}']
        g = gelu(pre)
        ffn = g @ Ww[f'W2{l}'].T + Ww[f'b2{l}']
        x = hm + ffn
    hf = ln(x, Ww['LNfg'], Ww['LNfb'])
    return hf @ Ww['WTE'].T

def score_fast(wte_mut, ffn_resync=False):
    Wt = {k: v for k, v in WA.items()}
    Wt['WTE'] = wte_mut
    if ffn_resync:
        small_data = []
        for s in range(0, 25, 3):
            small_data.extend([i % VS for i in range(s, s + 30)])
        for l in range(NLA):
            ln2s = []
            pres = []
            gelus = []
            for i in range(len(small_data) - KA):
                ids = small_data[i:i + KA]
                seq = np.array(ids)
                slen = len(seq)
                x = Wt['WTE'][seq] + Wt['WPE'][np.arange(slen)]
                for ll in range(l + 1):
                    mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
                    ln1 = ln(x, Wt[f'LN1g{ll}'], Wt[f'LN1b{ll}'])
                    Q = ln1 @ Wt[f'WQ{ll}'].T
                    Kk = ln1 @ Wt[f'WK{ll}'].T
                    V = ln1 @ Wt[f'WV{ll}'].T
                    hd = DA // HA
                    Qh = Q.reshape(slen, HA, hd).transpose(1, 0, 2)
                    Kh = Kk.reshape(slen, HA, hd).transpose(1, 0, 2)
                    Vh = V.reshape(slen, HA, hd).transpose(1, 0, 2)
                    ctx = np.stack([softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(HA)], 1).reshape(slen, -1)
                    att = ctx @ Wt[f'WO{ll}'].T
                    hm = x + att
                    ln2 = ln(hm, Wt[f'LN2g{ll}'], Wt[f'LN2b{ll}'])
                    if ll == l:
                        ln2s.append(ln2)
                        pre = ln2 @ Wt[f'W1{l}'].T + Wt[f'b1{l}']
                        pres.append(pre)
                        gelus.append(gelu(pre))
                    else:
                        pre = ln2 @ Wt[f'W1{ll}'].T + Wt[f'b1{ll}']
                        x = hm + gelu(pre) @ Wt[f'W2{ll}'].T + Wt[f'b2{ll}']
            if ln2s:
                ln2a = np.concatenate(ln2s)
                prea = np.concatenate(pres)
                gelua = np.concatenate(gelus)
                W1s = solve(ln2a, prea, True)
                Wt[f'W1{l}'] = W1s[:-1].T
                Wt[f'b1{l}'] = W1s[-1]
                ffnt = gelua @ WA[f'W2{l}'].T + WA[f'b2{l}']
                W2s = solve(gelua, ffnt, True)
                Wt[f'W2{l}'] = W2s[:-1].T
                Wt[f'b2{l}'] = W2s[-1]
    correct = 0
    preds = []
    for name, seq, truth in tests:
        try:
            logits = fwd(seq[-KA:], Wt, DA, HA, NLA, KA)
            p = int(np.argmax(logits[-1]))
        except:
            p = -1
        preds.append(p)
        if p == truth:
            correct += 1
    return (correct, preds, Wt)
rng = np.random.default_rng(0)
WTE_A = WA['WTE'].copy()
WTE_B = WB['WTE'].copy()

def mut_random_rotation(wte, rng, strength=1.0):
    from scipy.stats import ortho_group
    Q = ortho_group.rvs(DA, random_state=int(rng.integers(1000000.0)))
    I = np.eye(DA)
    R = (1 - strength) * I + strength * Q
    U, _, Vt = np.linalg.svd(R)
    R_ortho = U @ Vt
    return wte @ R_ortho.T

def mut_subspace_rotation(wte, rng, dims=None, strength=1.0):
    from scipy.stats import ortho_group
    wte_new = wte.copy()
    if dims is None:
        k = int(rng.integers(2, DA))
        dims = list(rng.choice(DA, k, replace=False))
    k = len(dims)
    if k < 2:
        return wte_new
    Q = ortho_group.rvs(k, random_state=int(rng.integers(1000000.0)))
    wte_new[:, dims] = wte[:, dims] @ Q.T
    return wte_new

def mut_sign_flip(wte, rng):
    wte_new = wte.copy()
    mask = rng.random(DA) < 0.3
    wte_new[:, mask] *= -1
    return wte_new

def mut_dim_permute(wte, rng):
    perm = rng.permutation(DA)
    return wte[:, perm]

def mut_token_permute(wte, rng, group=None):
    wte_new = wte.copy()
    if group is None:
        k = int(rng.integers(2, min(8, VS)))
        group = list(rng.choice(VS, k, replace=False))
    idx = list(group)
    perm = rng.permutation(len(idx))
    wte_new[idx] = wte_new[[idx[p] for p in perm]]
    return wte_new

def mut_scale_dims(wte, rng):
    scales = rng.uniform(0.5, 2.0, DA)
    return wte * scales[None, :]

def mut_cross_dims(wte, rng):
    wte_new = wte.copy()
    n_swaps = int(rng.integers(1, DA // 2))
    dims = rng.permutation(DA)[:n_swaps * 2]
    for i in range(n_swaps):
        a, b = (dims[i * 2], dims[i * 2 + 1])
        wte_new[:, [a, b]] = wte_new[:, [b, a]]
    return wte_new

def mut_inject_pattern_axis(wte, rng, pattern_members, strength=None):
    wte_new = wte.copy()
    if strength is None:
        strength = float(rng.uniform(0.2, 2.0))
    dim = int(rng.integers(0, DA))
    others = [i for i in range(VS) if i not in pattern_members]
    for i in pattern_members:
        wte_new[i, dim] += strength
    for i in others:
        wte_new[i, dim] -= strength * len(pattern_members) / max(len(others), 1)
    return wte_new

def mut_crossover(wteA, wteB_proj, rng):
    wte_new = wteA.copy()
    mask = rng.random(VS) < rng.uniform(0.1, 0.9)
    wte_new[mask] = wteB_proj[mask]
    return wte_new

def mut_crossover_dims(wteA, wteB_proj, rng):
    wte_new = wteA.copy()
    mask = rng.random(DA) < rng.uniform(0.1, 0.9)
    wte_new[:, mask] = wteB_proj[:, mask]
    return wte_new

def mut_eigenspace_swap(wte, rng):
    U, s, Vt = np.linalg.svd(wte, full_matrices=False)
    perm = rng.permutation(len(s))
    return U[:, perm] * s[perm] @ Vt[perm]

def mut_noise(wte, rng, scale=None):
    if scale is None:
        scale = float(rng.uniform(0.05, 0.5))
    direction = rng.standard_normal(DA)
    direction /= np.linalg.norm(direction) + 1e-09
    noise = rng.standard_normal((VS,)) * scale
    return wte + np.outer(noise, direction)
P_B_to_A = solve(WTE_B, WTE_A)
WTE_B_proj = WTE_B @ P_B_to_A
patterns_dict = {'primes': [2, 3, 5, 7, 11, 13, 17, 19, 23, 29], 'evens': [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], 'odds': [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29], 'fibonacci': [1, 2, 3, 5, 8, 13, 21], 'threes': [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30]}
pattern_list = list(patterns_dict.values())
print('=' * 72)
print('  SURGERY V11 — EVOLUTIONARY MUTATION SEARCH')
print('  5000 random mutations of WTE_A, testing all 8 patterns')
print('  Not blend. Not project. MUTATION.')
print('=' * 72)
baseline_score, baseline_preds, _ = score_fast(WTE_A)
print(f'\n  Baseline: {baseline_score}/8  preds={baseline_preds}')
survivors = []
best_score_seen = baseline_score
N_MUTATIONS = 5000
print(f'\n  Running {N_MUTATIONS} mutations...')
print(f"  {'Mut#':>6}  {'Type':>22}  {'Score':>6}  {'Preds'}")
print(f"  {'─' * 70}")
t0 = time.time()
score_histogram = {i: 0 for i in range(9)}
for i in range(N_MUTATIONS):
    mut_type = int(rng.integers(0, 12))
    try:
        if mut_type == 0:
            wte_m = mut_random_rotation(WTE_A, rng, strength=float(rng.uniform(0.1, 1.0)))
            mname = 'full_rotation'
        elif mut_type == 1:
            k = int(rng.integers(2, DA))
            dims = list(rng.choice(DA, k, replace=False))
            wte_m = mut_subspace_rotation(WTE_A, rng, dims=dims)
            mname = f'subspace_rot_{k}d'
        elif mut_type == 2:
            wte_m = mut_sign_flip(WTE_A, rng)
            mname = 'sign_flip'
        elif mut_type == 3:
            wte_m = mut_dim_permute(WTE_A, rng)
            mname = 'dim_permute'
        elif mut_type == 4:
            p = pattern_list[int(rng.integers(0, len(pattern_list)))]
            wte_m = mut_token_permute(WTE_A, rng, group=p)
            mname = 'token_permute_pattern'
        elif mut_type == 5:
            wte_m = mut_scale_dims(WTE_A, rng)
            mname = 'scale_dims'
        elif mut_type == 6:
            wte_m = mut_cross_dims(WTE_A, rng)
            mname = 'cross_dims'
        elif mut_type == 7:
            p = pattern_list[int(rng.integers(0, len(pattern_list)))]
            wte_m = mut_inject_pattern_axis(WTE_A, rng, p)
            mname = 'inject_pattern_axis'
        elif mut_type == 8:
            wte_m = mut_crossover(WTE_A, WTE_B_proj, rng)
            mname = 'crossover_tokens'
        elif mut_type == 9:
            wte_m = mut_crossover_dims(WTE_A, WTE_B_proj, rng)
            mname = 'crossover_dims'
        elif mut_type == 10:
            wte_m = mut_eigenspace_swap(WTE_A, rng)
            mname = 'eigenspace_swap'
        else:
            wte_m = mut_noise(WTE_A, rng)
            mname = 'structured_noise'
    except Exception as e:
        continue
    s, preds, Wt = score_fast(wte_m, ffn_resync=False)
    score_histogram[s] += 1
    if s > baseline_score:
        survivors.append({'score': s, 'wte': wte_m.copy(), 'type': mname, 'preds': preds, 'idx': i})
        flag = ' *** SURVIVOR ***'
        print(f'  {i:>6}  {mname:>22}  {s:>3}/8   {preds}  {flag}')
        if s > best_score_seen:
            best_score_seen = s
    if i % 500 == 499:
        elapsed = time.time() - t0
        rate = (i + 1) / elapsed
        remaining = (N_MUTATIONS - i - 1) / rate
        print(f'  ... {i + 1}/{N_MUTATIONS}  survivors={len(survivors)}  best={best_score_seen}/8  {elapsed:.0f}s elapsed  ~{remaining:.0f}s remaining')
print(f'\n  Search complete. {time.time() - t0:.1f}s  {N_MUTATIONS} mutations tested')
print(f'\n  Score distribution:')
for s, count in sorted(score_histogram.items()):
    if count > 0:
        bar = '█' * min(count, 50)
        print(f'    {s}/8: {count:>5}  {bar}')
print(f'\n' + '=' * 72)
print(f'  SURVIVOR ANALYSIS')
print(f'  {len(survivors)} mutations scored > {baseline_score}/8')
print('=' * 72)
if survivors:
    survivors.sort(key=lambda x: x['score'], reverse=True)
    print(f'\n  Top survivors:')
    print(f"  {'Rank':>5} {'Score':>6} {'Type':>25}  {'Patterns correct'}")
    print(f"  {'─' * 70}")
    for rank, sv in enumerate(survivors[:20]):
        names = [tests[j][0] for j, p in enumerate(sv['preds']) if p == tests[j][2]]
        print(f"  {rank + 1:>5}  {sv['score']:>3}/8  {sv['type']:>25}  {names}")
    print(f'\n  Re-testing top 10 survivors WITH FFN re-sync:')
    print(f"  {'Rank':>5} {'Score_no_sync':>14} {'Score_with_sync':>16}  {'Patterns'}")
    print(f"  {'─' * 70}")
    best_synced_score = 0
    best_synced_Wt = None
    for rank, sv in enumerate(survivors[:10]):
        s2, preds2, Wt2 = score_fast(sv['wte'], ffn_resync=True)
        names = [tests[j][0] for j, p in enumerate(preds2) if p == tests[j][2]]
        print(f"  {rank + 1:>5}  {sv['score']:>6}/8       {s2:>8}/8        {names}")
        if s2 > best_synced_score:
            best_synced_score = s2
            best_synced_Wt = {k: v.copy() for k, v in Wt2.items()}
    if len(survivors) >= 2:
        print(f'\n  Crossbreeding top survivors ({min(len(survivors), 10)} parents)...')
        top_parents = survivors[:min(len(survivors), 10)]
        children_scores = []
        N_CHILDREN = 500
        for c in range(N_CHILDREN):
            p1 = top_parents[int(rng.integers(0, len(top_parents)))]
            p2 = top_parents[int(rng.integers(0, len(top_parents)))]
            wte_p1 = p1['wte']
            wte_p2 = p2['wte']
            child_type = int(rng.integers(0, 4))
            if child_type == 0:
                mask = rng.random(VS) < 0.5
                wte_c = wte_p1.copy()
                wte_c[mask] = wte_p2[mask]
            elif child_type == 1:
                mask = rng.random(DA) < 0.5
                wte_c = wte_p1.copy()
                wte_c[:, mask] = wte_p2[:, mask]
            elif child_type == 2:
                wte_c = (wte_p1 + wte_p2) / 2
            else:
                wte_c = mut_subspace_rotation(wte_p1, rng)
            if rng.random() < 0.3:
                wte_c = mut_noise(wte_c, rng, scale=float(rng.uniform(0.01, 0.1)))
            sc, predsc, Wtc = score_fast(wte_c, ffn_resync=False)
            children_scores.append(sc)
            if sc > best_score_seen:
                best_score_seen = sc
                survivors.append({'score': sc, 'wte': wte_c.copy(), 'type': f'child_{child_type}', 'preds': predsc, 'idx': N_MUTATIONS + c})
                names = [tests[j][0] for j, p in enumerate(predsc) if p == tests[j][2]]
                print(f'  CHILD SURVIVOR! score={sc}/8  {names}')
        print(f'\n  Children score distribution:')
        from collections import Counter
        ch_hist = Counter(children_scores)
        for s in sorted(ch_hist):
            print(f'    {s}/8: {ch_hist[s]}')
else:
    print(f'\n  No survivors found in {N_MUTATIONS} random mutations.')
    print(f'  This is itself a finding:')
    print(f'  FINDING — RANDOM MUTATION LAW:')
    print(f'    In {N_MUTATIONS} random structural mutations of WTE_A,')
    print(f'    zero mutations scored > {baseline_score}/8.')
    print(f'    Intelligence cannot be unlocked by random weight perturbation.')
    print(f'    The capability boundary is not a local maximum — it is structural.')
    print(f'    Post-hoc surgery without training is provably insufficient.')
    print(f'    The ONLY path to new capability is training-time information.')
print(f'\n' + '=' * 72)
print(f'  SURGERY V11 VERDICT')
print('=' * 72)
print(f"\n  Random mutations tested: {N_MUTATIONS}\n  Survivors (score > {baseline_score}/8): {len(survivors)}\n  Best score found: {best_score_seen}/8\n\n  SURGERY HISTORY\n    v3-v5:  fitted projection collapse\n    v4:     amplification barrier\n    v6:     logit backprojection rank collapse\n    v7:     untrained medium model\n    v8:     null/lmh/full blend — linear, fails\n    v9:     NGS cambium directions — still linear\n    v10:    embedding mutation — still linear blend\n    v11:    evolutionary search — {N_MUTATIONS} random mutations\n            {('→ FOUND WORKING MUTATIONS' if survivors else '→ NO SURVIVORS: STRUCTURAL LIMIT LAW CONFIRMED')}\n\n  WHAT WE NOW KNOW FOR CERTAIN:\n    1. Intelligence gap = embedding clustering (primes cluster in B, not A)\n    2. R²=1.0 bridge exists (B's structure fits in A's 16D space)\n    3. Linear combination cannot transfer capability (proven by v8-v10)\n    4. {('Random structural mutation CAN find new capability' if survivors else 'Random structural mutation CANNOT unlock new capability')}\n    {('5. Successful mutation type: ' + survivors[0]['type'] if survivors else '5. The capability is locked behind training-time information flow')}\n")
print('=' * 72 + '\n')
