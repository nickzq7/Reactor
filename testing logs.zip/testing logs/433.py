import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
vocab = model.config.vocab_size
print(f'D={D}  Layers={n_layers}  Vocab={vocab}')
laws = {}
for li in range(n_layers):
    b = model.transformer.h[li]
    laws[li] = {'W1': b.mlp.c_fc.weight.detach().float().numpy().T, 'b1': b.mlp.c_fc.bias.detach().float().numpy(), 'W2': b.mlp.c_proj.weight.detach().float().numpy().T, 'b2': b.mlp.c_proj.bias.detach().float().numpy(), 'ln1_w': b.ln_1.weight.detach().float().numpy(), 'ln1_b': b.ln_1.bias.detach().float().numpy(), 'ln2_w': b.ln_2.weight.detach().float().numpy(), 'ln2_b': b.ln_2.bias.detach().float().numpy()}
lm_W = model.lm_head.weight.detach().float().numpy()
ln_f_w = model.transformer.ln_f.weight.detach().float().numpy()
ln_f_b = model.transformer.ln_f.bias.detach().float().numpy()
emb_W = model.transformer.wte.weight.detach().float().numpy()
pos_W = model.transformer.wpe.weight.detach().float().numpy()
print(f'All W laws extracted.')

def gelu_np(x):
    return x * 0.5 * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))

def layernorm_np(x, w, b, eps=1e-05):
    mean = np.mean(x)
    std = np.std(x)
    return (x - mean) / (std + eps) * w + b

def w_transform_chain(token_id, pos, verbose=False):
    h = emb_W[token_id] + pos_W[pos]
    states = [h.copy()]
    for li in range(n_layers):
        L = laws[li]
        att_out = np.zeros_like(h)
        h = h + att_out
        h_ln2 = layernorm_np(h, L['ln2_w'], L['ln2_b'])
        natural_state = gelu_np(h_ln2 @ L['W1'] + L['b1'])
        ffn_out = natural_state @ L['W2'] + L['b2']
        h = h + ffn_out
        states.append(h.copy())
        if verbose:
            norm_h = np.linalg.norm(h)
            print(f'    Layer {li}: ||h||={norm_h:.3f}')
    h_final = layernorm_np(h, ln_f_w, ln_f_b)
    logits = h_final @ lm_W.T
    return (np.argmax(logits), logits, states)

def normal_generate(prompt, max_new=100):
    input_ids = tokenizer.encode(prompt, return_tensors='pt')
    tokens = []
    current = input_ids.clone()
    with torch.no_grad():
        for _ in range(max_new):
            out = model(current)
            tok = int(torch.argmax(out.logits[0, -1, :]).item())
            tokens.append(tok)
            current = torch.cat([current, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return tokens

def w_dsa_generate(prompt, max_new=100):
    input_ids = tokenizer.encode(prompt)
    tokens = []
    current_tok = input_ids[-1]
    pos = len(input_ids)
    for step in range(max_new):
        next_tok, logits, states = w_transform_chain(current_tok, pos)
        tokens.append(int(next_tok))
        current_tok = int(next_tok)
        pos += 1
        if int(next_tok) == tokenizer.eos_token_id:
            break
    return tokens
prompt = 'Once upon a time there was a little girl who loved to'
print(f"\nPrompt: '{prompt}'")
print(f'Generating 100 tokens — normal vs W-DSA chain...')
normal_toks = normal_generate(prompt, max_new=100)
wdsa_toks = w_dsa_generate(prompt, max_new=100)
n = min(len(normal_toks), len(wdsa_toks))
matches = [1 if normal_toks[i] == wdsa_toks[i] else 0 for i in range(n)]
accuracy = sum(matches) / n
print(f"\n{'=' * 70}")
print(f'  W-NATIVE DSA — TRANSFORMATION CHAIN TEST')
print(f"{'=' * 70}")
print(f'\n  TOKEN BY TOKEN (first 50):')
print(f"  {'#':<4} {'Normal':<22} {'W-DSA':<22} {'Match'}")
print(f"  {'─' * 55}")
for i in range(min(50, n)):
    nt = tokenizer.decode([normal_toks[i]])
    wt = tokenizer.decode([wdsa_toks[i]])
    m = '✓' if matches[i] else '✗'
    print(f'  {i:<4} {repr(nt):<22} {repr(wt):<22} {m}')
normal_text = tokenizer.decode(normal_toks, skip_special_tokens=True)
wdsa_text = tokenizer.decode(wdsa_toks, skip_special_tokens=True)
print(f'\n  ACCURACY: {accuracy:.1%}  ({sum(matches)}/{n} tokens match)')
print(f"\n{'=' * 70}")
print(f'  NORMAL:\n  {prompt} {normal_text}')
print(f'\n  W-DSA:\n  {prompt} {wdsa_text}')
print(f"\n{'=' * 70}")
print(f'\n  WHAT THIS REVEALS:\n\n  W-DSA chain uses FFN law only. No attention.\n  Each token processed independently.\n  h0 → W_chain → next token.\n\n  Attention = cross-token. Irreducible.\n  We skipped it intentionally.\n  This shows: what W-law alone contributes.\n\n  If W-DSA text is coherent but differs from normal:\n    FFN law generates valid language.\n    Attention adds context sensitivity.\n    W-DSA = context-free language generation.\n    Valid DSA operation. Different from normal. Not wrong.\n\n  If W-DSA text repeats or breaks:\n    Single-token W-chain not enough.\n    Need: accumulate context, THEN apply W-chain.\n    Next step = add context accumulation.\n\n  If accuracy > 20%:\n    W-transformation chain IS producing\n    same tokens as full model sometimes.\n    Law working. Not full model. But working.\n\n  KEY INSIGHT:\n    Old DSA: structure holds data still.\n    W-DSA: structure IS the movement.\n    h transforms. That transformation = the DSA.\n    We are measuring the transformation itself.\n')
print('=' * 70 + '\n')
