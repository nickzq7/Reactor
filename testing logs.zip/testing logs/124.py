import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
KA = meta['KA']
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def make_seq(step, length=40):
    return [i * step % VS for i in range(length)]

def make_fib_mod(seed, length=40):
    a, b = (seed % VS, (seed + 1) % VS)
    s = [a, b]
    while len(s) < length:
        a, b = (b, (a + b) % VS)
        s.append(b)
    return s
ALL_256 = []
for step in range(1, 29):
    ALL_256.append(('step_%d' % step, make_seq(step, 40)))
for seed in range(1, 13):
    ALL_256.append(('fib_%d' % seed, make_fib_mod(seed * 3, 40)))
for start in range(VS - 1, VS - 13, -1):
    ALL_256.append(('down_%d' % start, [(start - i * 2) % VS for i in range(40)]))
for base in range(2, 8):
    ALL_256.append(('pow_%d' % base, [base ** i % VS for i in range(40)]))
print(f'Total patterns: {len(ALL_256)}')
ALL_256 = ALL_256[:256]
MODEL_PATTERNS = [ALL_256[i * 8:(i + 1) * 8] for i in range(32)]

class SeqModel(nn.Module):

    def __init__(self, D, H, NL, K):
        super().__init__()
        self.D = D
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, K = ids.shape
        x = self.wte(ids) + self.wpe(torch.arange(K, device=ids.device).unsqueeze(0))
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def build_data(patterns, K):
    Xs, Ys = ([], [])
    for name, seq in patterns:
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))

def score_patterns(model, patterns, K):
    model.eval()
    correct = 0
    for name, seq in patterns:
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            logits = model(ids)
            pred = int(logits[0, -1].argmax())
        correct += pred == seq[min(len(seq) - 1, K)]
    return correct

def save_model(model, path):
    np.savez(path, **{k: v.detach().numpy() for k, v in model.state_dict().items()})

def load_model(D, H, NL, K, path):
    model = SeqModel(D, H, NL, K)
    data = np.load(path + '.npz', allow_pickle=True)
    sd = {k: torch.tensor(data[k]) for k in data.files}
    model.load_state_dict(sd)
    return model
print('=' * 60)
print('STEP 1 — TRAIN 32 DONOR MODELS (D=16, 8 patterns each)')
print('=' * 60)
D_DONOR = 16
H_DONOR = 2
NL_DONOR = 3
donor_paths = []
t0 = time.time()
for i in range(32):
    path = os.path.join(_dir, f'donor_{i:02d}')
    if os.path.exists(path + '.npz'):
        print(f'  Donor {i + 1:>2}/32: loaded from disk')
        donor_paths.append(path)
        continue
    patterns = MODEL_PATTERNS[i]
    torch.manual_seed(i)
    np.random.seed(i)
    model = SeqModel(D_DONOR, H_DONOR, NL_DONOR, KA)
    for nm, p in model.named_parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
        else:
            nn.init.zeros_(p)
    X, Y = build_data(patterns, KA)
    opt = torch.optim.Adam(model.parameters(), lr=0.005)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=600, eta_min=0.0001)
    best_sc = 0
    best_state = None
    for step in range(1, 601):
        model.train()
        opt.zero_grad()
        logits = model(X)
        loss_fn(logits.view(-1, VS), Y.view(-1)).backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 100 == 0:
            sc = score_patterns(model, patterns, KA)
            if sc > best_sc:
                best_sc = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
    if best_state:
        model.load_state_dict(best_state)
    sc = score_patterns(model, patterns, KA)
    save_model(model, path)
    donor_paths.append(path)
    print(f'  Donor {i + 1:>2}/32 (seed={i}): {sc}/8 patterns  {[n for n, _ in patterns[:3]]}...', flush=True)
print(f'  All donors trained/loaded. Time: {time.time() - t0:.1f}s')
print('\n' + '=' * 60)
print('STEP 2 — BUILD CONSENSUS: 32 DONORS VOTE ON EVERY INPUT')
print('=' * 60)
donors = []
for i, path in enumerate(donor_paths):
    m = load_model(D_DONOR, H_DONOR, NL_DONOR, KA, path)
    m.eval()
    donors.append(m)
print(f'  Loaded {len(donors)} donor models')
all_X = []
all_Y_hard = []
all_Y_soft = []
print('  Computing consensus over all 256 patterns...')
for model_idx, patterns in enumerate(MODEL_PATTERNS):
    donor = donors[model_idx]
    X, Y = build_data(patterns, KA)
    with torch.no_grad():
        expert_logits = donor(X)
        all_donor_logits = []
        for d in donors:
            dl = d(X)
            all_donor_logits.append(dl)
        consensus = torch.stack(all_donor_logits, dim=0).mean(0)
    all_X.append(X)
    all_Y_hard.append(Y)
    all_Y_soft.append(consensus.detach())
all_X = torch.cat(all_X, dim=0)
all_Y_hard = torch.cat(all_Y_hard, dim=0)
all_Y_soft = torch.cat(all_Y_soft, dim=0)
print(f'  Dataset: {len(all_X)} sequences, consensus from 32 donors')
print('\n' + '=' * 60)
print('STEP 3 — TRAIN TINY MODELS ON DONOR CONSENSUS')
print('  D=8, D=4, D=2 — each receives intelligence from 32 donors')
print('=' * 60)

def train_tiny(D, H, NL, label, steps=3000):
    torch.manual_seed(42)
    np.random.seed(42)
    model = SeqModel(D, H, NL, KA)
    for nm, p in model.named_parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
        else:
            nn.init.zeros_(p)
    opt = torch.optim.Adam(model.parameters(), lr=0.003)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    kl = nn.KLDivLoss(reduction='batchmean')
    T = 4.0
    best_total = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        idx = torch.randperm(len(all_X))[:256]
        xb = all_X[idx]
        yh = all_Y_hard[idx]
        ys = all_Y_soft[idx]
        logits = model(xb)
        hard = loss_fn(logits.view(-1, VS), yh.view(-1))
        soft = kl(torch.log_softmax(logits.view(-1, VS) / T, dim=-1), torch.softmax(ys.view(-1, VS) / T, dim=-1)) * T ** 2
        loss = 0.4 * hard + 0.6 * soft
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 300 == 0:
            model.eval()
            total_correct = 0
            total_patterns = 0
            for patterns in MODEL_PATTERNS:
                sc = score_patterns(model, patterns, KA)
                total_correct += sc
                total_patterns += len(patterns)
            pct = total_correct / total_patterns * 100
            if total_correct > best_total:
                best_total = total_correct
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  {label} step {step:>5}: {total_correct}/{total_patterns} patterns ({pct:.1f}%)', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    return (best_total, model)
results = {}
for D, H, NL in [(8, 2, 2), (4, 2, 3), (2, 2, 4)]:
    label = f'D={D}'
    print(f'\n  --- {label} receiving from 32 donors ---')
    best, model = train_tiny(D, H, NL, label, steps=3000)
    results[D] = (best, model)
    print(f'  {label} FINAL: {best}/256 patterns')
print('\n' + '=' * 60)
print('STEP 4 — HOW MUCH INTELLIGENCE TRANSFERRED?')
print('=' * 60)
print(f"\n  {'Model':>8}  {'Params':>8}  {'Known':>10}  {'%':>6}")
print(f"  {'─' * 40}")
donor_params = sum((p.numel() for p in donors[0].parameters()))
print(f"  {'Donor':>8}  {donor_params:>8}  {'8/8 each':>10}  {'100%':>6}")
for D in [8, 4, 2]:
    best, model = results[D]
    params = sum((p.numel() for p in model.parameters()))
    pct = best / 256 * 100
    print(f"  {'D=' + str(D):>8}  {params:>8}  {best:>7}/256  {pct:>5.1f}%")
print(f'\n  Pattern breakdown for best tiny model:')
best_D = max(results, key=lambda d: results[d][0])
best_model = results[best_D][1]
best_model.eval()
print(f'  Using D={best_D}\n')
print(f"  {'Model':>5}  {'Patterns':>50}  {'Score':>6}")
print(f"  {'─' * 65}")
for i, patterns in enumerate(MODEL_PATTERNS):
    sc = score_patterns(best_model, patterns, KA)
    names = [n for n, _ in patterns]
    print(f'  {i + 1:>5}  {str(names):>50}  {sc:>3}/8')
print(f'\n  VERDICT:\n  32 donors (D=16 each) trained on 256 different patterns.\n  Tiny model (D={best_D}) received knowledge from all 32 via consensus.\n  Result: {results[best_D][0]}/256 patterns transferred.\n  \n  Compression ratio: {donor_params} params → {sum((p.numel() for p in results[best_D][1].parameters()))} params\n  Intelligence retained: {results[best_D][0] / 256 * 100:.1f}%\n')
print('=' * 60)
