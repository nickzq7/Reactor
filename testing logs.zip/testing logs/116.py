import os, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
D_TINY = 8
STEPS = 3000
LR = 0.003
TEMP = 3.0
ALPHA = 0.5

def arith(step, n=60):
    return [i * step % VS for i in range(n)]

def countdown(s, n=60):
    return [(VS - 1 - i * s) % VS for i in range(n)]

def fib(a, b, n=60):
    s = [a % VS, b % VS]
    while len(s) < n:
        s.append((s[-1] + s[-2]) % VS)
    return s

def geo(base, n=60):
    s = [1]
    for _ in range(n - 1):
        s.append(s[-1] * base % VS)
    return s

def poly(fn, n=60):
    return [fn(i) % VS for i in range(n)]

def skip(step, off, n=60):
    return [(off + i * step) % VS for i in range(n)]
MODEL_PATTERNS = [[('a1', arith(1)), ('a2', arith(2)), ('a3', arith(3)), ('a4', arith(4)), ('a5', arith(5)), ('a6', arith(6)), ('a7', arith(7)), ('a8', arith(8))], [('a9', arith(9)), ('a10', arith(10)), ('a11', arith(11)), ('a12', arith(12)), ('a13', arith(13)), ('a14', arith(14)), ('a15', arith(15)), ('a16', arith(16))], [('a17', arith(17)), ('a18', arith(18)), ('a19', arith(19)), ('a20', arith(20)), ('a21', arith(21)), ('a22', arith(22)), ('a23', arith(23)), ('a24', arith(24))], [('d1', countdown(1)), ('d2', countdown(2)), ('d3', countdown(3)), ('d4', countdown(4)), ('d5', countdown(5)), ('d6', countdown(6)), ('d7', countdown(7)), ('d8', countdown(8))], [('f1', fib(1, 2)), ('f2', fib(3, 7)), ('f3', fib(5, 11)), ('f4', fib(2, 9)), ('f5', fib(7, 13)), ('f6', fib(4, 15)), ('f7', fib(6, 17)), ('f8', fib(8, 19))], [('g2', geo(2)), ('g3', geo(3)), ('g4', geo(4)), ('g5', geo(5)), ('g6', geo(6)), ('g7', geo(7)), ('g9', geo(9)), ('g11', geo(11))], [('sq0', poly(lambda i: i * i)), ('sq1', poly(lambda i: (i + 1) ** 2)), ('sq2', poly(lambda i: (i + 2) ** 2)), ('sq3', poly(lambda i: (i + 3) ** 2)), ('sq4', poly(lambda i: (i + 4) ** 2)), ('sq5', poly(lambda i: (i + 5) ** 2)), ('sq6', poly(lambda i: (i + 6) ** 2)), ('sq7', poly(lambda i: (i + 7) ** 2))], [('s3o0', skip(3, 0)), ('s3o1', skip(3, 1)), ('s3o2', skip(3, 2)), ('s3o3', skip(3, 3)), ('s5o0', skip(5, 0)), ('s5o1', skip(5, 1)), ('s5o2', skip(5, 2)), ('s5o3', skip(5, 3))]]
ALL_PATTERNS = [p for mp in MODEL_PATTERNS for p in mp]
GROUPS = ['arith1-8', 'arith9-16', 'arith17-24', 'countdown', 'fibonacci', 'geometric', 'polynomial', 'skip+offset']

class Transformer(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, H, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, x):
        B, T = x.shape
        h = self.wte(x) + self.wpe(torch.arange(T, device=x.device))
        mask = torch.triu(torch.full((T, T), float('-inf'), device=x.device), 1)
        for ly in self.layers:
            n = ly['ln1'](h)
            a, _ = ly['attn'](n, n, n, attn_mask=mask, need_weights=False)
            h = h + a
            h = h + ly['ff'](ly['ln2'](h))
        return self.ln_f(h) @ self.wte.weight.T

def build_data(patterns):
    X, Y = ([], [])
    for _, seq in patterns:
        for i in range(len(seq) - K):
            X.append(seq[i:i + K])
            Y.append(seq[i + 1:i + K + 1])
    return (torch.tensor(X, dtype=torch.long), torch.tensor(Y, dtype=torch.long))

def score_all(model):
    model.eval()
    per_group = []
    for pats in MODEL_PATTERNS:
        sc = 0
        for _, seq in pats:
            ctx = torch.tensor([seq[:K]], dtype=torch.long)
            with torch.no_grad():
                pred = int(model(ctx)[0, -1].argmax())
            sc += pred == seq[K]
        per_group.append(sc)
    return per_group

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def compress(WTE, D_target):
    U, s, _ = np.linalg.svd(WTE, full_matrices=False)
    return (U[:, :D_target] * s[:D_target]).astype(np.float32)

def v16_mutate(WA, WB, k=6):
    P = solve(WB, WA)
    Bp = WB @ P
    Wh = 0.5 * WA + 0.5 * Bp
    ag = np.sum(WA * Bp, axis=0)
    flip = np.argsort(ag)[-k:]
    Wh[:, flip] *= -1
    return Wh

def multi_donor_init(wtes, k=6):
    ref = wtes[0]
    parts = [ref]
    for wb in wtes[1:]:
        parts.append(v16_mutate(ref, wb, k))
    combined = np.mean(parts, axis=0)
    P2 = solve(combined, ref)
    pr = combined @ P2
    ag = np.sum(ref * pr, axis=0)
    combined[:, np.argsort(ag)[-k:]] *= -1
    return combined
print('=' * 60)
print('  PHASE 2 — REAL MUTATION TRANSFER')
print('  8 donors → D=8 child via knowledge distillation')
print(f'  Steps={STEPS}  T={TEMP}  α={ALPHA}')
print('=' * 60)
donors = []
donor_wtes = []
for i in range(8):
    path = os.path.join(_dir, f'donor_{i:02d}.npz')
    data = np.load(path, allow_pickle=True)
    m = Transformer(D)
    m.load_state_dict({k: torch.tensor(data[k]) for k in data.files})
    m.eval()
    donors.append(m)
    donor_wtes.append(m.wte.weight.detach().numpy())
print(f'  {len(donors)} donors loaded\n')
print('  Precomputing donor soft targets...')
X_all, Y_all = build_data(ALL_PATTERNS)
samples_per_pattern = len(ALL_PATTERNS[0][1]) - K
group_ids = []
for gi, pats in enumerate(MODEL_PATTERNS):
    for _ in pats:
        group_ids.extend([gi] * samples_per_pattern)
group_ids = torch.tensor(group_ids, dtype=torch.long)
with torch.no_grad():
    donor_soft = torch.zeros(len(X_all), K, VS)
    for gi, donor in enumerate(donors):
        mask_i = group_ids == gi
        Xi = X_all[mask_i]
        if len(Xi) == 0:
            continue
        out = donor(Xi)
        donor_soft[mask_i] = out
print(f'  Soft targets: {donor_soft.shape}  ✓\n')
WTE_init = multi_donor_init(donor_wtes, k=6)
WTE_init = compress(WTE_init, D_TINY)
torch.manual_seed(42)
np.random.seed(42)
child = Transformer(D_TINY)
for nm, p in child.named_parameters():
    if p.dim() > 1:
        nn.init.xavier_uniform_(p)
    else:
        nn.init.zeros_(p)
with torch.no_grad():
    child.wte.weight.copy_(torch.tensor(WTE_init))
ce_fn = nn.CrossEntropyLoss()
kl_fn = nn.KLDivLoss(reduction='batchmean')
opt = torch.optim.Adam(child.parameters(), lr=LR)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=STEPS, eta_min=5e-05)
best_score = 0
best_state = None
t0 = time.time()
print(f"  {'Step':>5}  {'Score':>5}  {'CE':>7}  {'KL':>7}  {'Loss':>8}  Per group")
print('  ' + '-' * 80)
for step in range(1, STEPS + 1):
    child.train()
    opt.zero_grad()
    logits = child(X_all)
    ce_loss = ce_fn(logits.reshape(-1, VS), Y_all.reshape(-1))
    child_lp = F.log_softmax(logits[:, -1, :] / TEMP, dim=-1)
    donor_p = F.softmax(donor_soft[:, -1, :] / TEMP, dim=-1)
    kl_loss = kl_fn(child_lp, donor_p) * TEMP ** 2
    loss = ALPHA * kl_loss + (1 - ALPHA) * ce_loss
    loss.backward()
    nn.utils.clip_grad_norm_(child.parameters(), 1.0)
    opt.step()
    sched.step()
    if step % 300 == 0 or step == STEPS:
        per_group = score_all(child)
        total = sum(per_group)
        if total > best_score:
            best_score = total
            best_state = {k: v.clone() for k, v in child.state_dict().items()}
        bars = ''.join((f'{s}' for s in per_group))
        print(f'  {step:>5}  {total:>5}/64  {ce_loss.item():>7.4f}  {kl_loss.item():>7.4f}  {loss.item():>8.4f}  [{bars}]')
if best_state:
    child.load_state_dict(best_state)
per_group = score_all(child)
grand_total = sum(per_group)
print('\n' + '=' * 60)
print('  FINAL RESULTS')
print('=' * 60)
for i, (sc, g) in enumerate(zip(per_group, GROUPS)):
    bar = '█' * sc + '░' * (8 - sc)
    print(f'  {bar}  {sc}/8  {g}')
donor_p = sum((p.numel() for p in donors[0].parameters()))
child_p = sum((p.numel() for p in child.parameters()))
print(f'\n  Donor params:  {donor_p} × 8 = {donor_p * 8:,}\n  Child params:  {child_p:,}\n  Compression:   {donor_p * 8 // child_p}× smaller\n\n  Intelligence transferred: {grand_total}/64  ({grand_total / 64 * 100:.0f}%)\n  Time: {time.time() - t0:.1f}s\n')
print('=' * 60)
