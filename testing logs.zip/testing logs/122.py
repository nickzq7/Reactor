import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
WA = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'num_small_weights.npz')).items()}
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
DA = meta['DA']
HA = meta['HA']
NLA = meta['NLA']
KA = meta['KA']
tests = [(name, seq, truth) for name, seq, truth in meta['test_patterns']]

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_primes(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s

def is_prime(n):
    if n < 2:
        return False
    return all((n % i != 0 for i in range(2, int(n ** 0.5) + 1)))
ALL_PATTERNS = {'counting': [i % VS for i in range(60)], 'evens': [i * 2 % VS for i in range(30)], 'odds': [(i * 2 + 1) % VS for i in range(30)], 'threes': [i * 3 % VS for i in range(20)], 'fours': [i * 4 % VS for i in range(15)], 'countdown': [(15 - i) % VS for i in range(40)], 'primes': gen_primes(30), 'fibonacci': gen_fib(30)}
UNSEEN = {'sixes': ([i * 6 % VS for i in range(8)], 7 * 6 % VS), 'sevens': ([i * 7 % VS for i in range(8)], 7 * 7 % VS), 'eights': ([i * 8 % VS for i in range(8)], 7 * 8 % VS), 'nines': ([i * 9 % VS for i in range(8)], 7 * 9 % VS), 'tens': ([i * 10 % VS for i in range(8)], 7 * 10 % VS), 'twelves': ([i * 12 % VS for i in range(8)], 7 * 12 % VS), 'fifteens': ([i * 15 % VS for i in range(8)], 7 * 15 % VS), 'step_-2': ([30, 28, 26, 24, 22, 20, 18, 16], 14), 'step_-4': ([28, 24, 20, 16, 12, 8, 4, 0], 27), 'step_-5': ([25, 20, 15, 10, 5, 0, 26, 21], 16)}

def build_tensors(K, dev, vs=None):
    vs_ = vs or VS
    Xs = []
    yn = []
    ys = []
    for name, data in ALL_PATTERNS.items():
        M = len(data) - K
        if M <= 0:
            continue
        for i in range(M):
            ctx = data[i:i + K]
            nxt = data[i + 1:i + K + 1]
            step_seq = [(data[j + 1] - data[j]) % vs_ for j in range(i, i + K)]
            Xs.append(ctx)
            yn.append(nxt)
            ys.append(step_seq)
    return (torch.tensor(Xs, dtype=torch.long, device=dev), torch.tensor(yn, dtype=torch.long, device=dev), torch.tensor(ys, dtype=torch.long, device=dev))
ALL_X, ALL_Y, ALL_S = build_tensors(KA, device)

def analyze_circle_full(wte2, label='', vs=None):
    N = vs or VS
    coords = wte2[:N].copy()
    center = coords.mean(0)
    centered = coords - center
    radii = np.linalg.norm(centered, axis=1)
    cq = 1 - radii.std() / radii.mean() if radii.mean() > 1e-09 else 0
    angles = np.arctan2(centered[:, 1], centered[:, 0])
    t_vals = np.arange(N, dtype=float)
    best_corr = -999
    best_dir = 1
    best_phase = 0
    for direction in [1, -1]:
        ideal = t_vals * (2 * math.pi / N) * direction
        for phase in np.linspace(-math.pi, math.pi, 360):
            pred = ideal + phase
            diffs = angles - pred
            diffs = np.arctan2(np.sin(diffs), np.cos(diffs))
            ss_r = np.sum(diffs ** 2)
            ss_t = np.sum((angles - np.arctan2(np.sin(angles).mean(), np.cos(angles).mean())) ** 2)
            r2 = 1 - ss_r / ss_t if ss_t > 1e-10 else 1.0
            if r2 > best_corr:
                best_corr = r2
                best_dir = direction
                best_phase = phase
    da = []
    ts = []
    for name, data in ALL_PATTERNS.items():
        for i in range(len(data) - 1):
            a, b = (data[i], data[i + 1])
            disp = centered[b] - centered[a]
            if np.linalg.norm(disp) < 1e-09:
                continue
            da.append(math.atan2(disp[1], disp[0]))
            ts.append((b - a) % N)
    da = np.array(da)
    ts = np.array(ts, dtype=float)
    Amat = np.c_[da, np.ones(len(da))]
    w = solve(Amat, ts)
    pred2 = Amat @ w
    ss_r2 = np.sum((ts - pred2) ** 2)
    ss_t2 = np.sum((ts - ts.mean()) ** 2)
    r2a = 1 - ss_r2 / ss_t2 if ss_t2 > 1e-10 else 1.0
    gc = 0
    geo_preds = {}
    for uname, (useq, utruth) in UNSEEN.items():
        pa = []
        for i in range(max(0, len(useq) - 4), len(useq) - 1):
            disp = centered[useq[i + 1]] - centered[useq[i]]
            if np.linalg.norm(disp) < 1e-09:
                continue
            pa.append(math.atan2(disp[1], disp[0]))
        if not pa:
            geo_preds[uname] = (None, utruth, False)
            continue
        ps = int(round(w[0] * np.mean(pa) + w[1])) % N
        pn = (useq[-1] + ps) % N
        ok = pn == utruth
        gc += ok
        geo_preds[uname] = (pn, utruth, ok)
    print(f'  [{label}]  circle={cq:.3f}  Z/nZ_R²={best_corr:.4f}  angReg_R²={r2a:.4f}  geo={gc}/{len(UNSEEN)}')
    return {'cq': cq, 'r2znz': best_corr, 'r2ang': r2a, 'gc': gc, 'angles': angles, 'center': center, 'w': w, 'geo_preds': geo_preds}

class SeqModel(nn.Module):

    def __init__(self, D, H, NL, K, vs=None):
        super().__init__()
        self.vs = vs or VS
        self.wte = nn.Embedding(self.vs, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)
        self.step_head = nn.Linear(D, self.vs, bias=False)

    def forward(self, ids):
        B, K = ids.shape
        x = self.wte(ids) + self.wpe(torch.arange(K, device=ids.device).unsqueeze(0))
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        h = self.ln_f(x)
        return (h @ self.wte.weight.T, self.step_head(h))

def score_m(m, K):
    m.eval()
    c = 0
    for nm, seq, truth in tests:
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            nl, _ = m(ids)
            p = int(nl[0, -1].argmax())
        c += p == truth
    return c

def score_u(m, K):
    m.eval()
    c = 0
    for un, (useq, ut) in UNSEEN.items():
        ids = torch.tensor([useq[-K:]], dtype=torch.long)
        with torch.no_grad():
            nl, _ = m(ids)
            p = int(nl[0, -1].argmax())
        c += p == ut
    return c

def circular_init(vs):
    wte = np.zeros((vs, 2), dtype=np.float32)
    for k in range(vs):
        angle = 2 * math.pi * k / vs
        wte[k] = [math.cos(angle), math.sin(angle)]
    return wte

def circular_reg_loss(wte_weight, vs, strength=0.1):
    k_vals = torch.arange(vs, dtype=torch.float32, device=wte_weight.device)
    ideal_angles = 2 * math.pi * k_vals / vs
    ideal_x = torch.cos(ideal_angles)
    ideal_y = torch.sin(ideal_angles)
    norms = torch.norm(wte_weight, dim=1, keepdim=True).clamp(min=1e-09)
    normalized = wte_weight / norms
    ideal = torch.stack([ideal_x, ideal_y], dim=1)
    return strength * torch.mean((normalized - ideal) ** 2)

def train_d2_exp(init_wte, label, max_steps=2000, sw=0.5, nr=4, circ_reg=0.0, freeze_after=None, vs=None):
    vs_ = vs or VS
    torch.manual_seed(42)
    np.random.seed(42)
    m = SeqModel(2, 2, 4, KA, vs=vs_).to(device)
    for nm, p in m.named_parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
        else:
            nn.init.zeros_(p)
    if init_wte is not None:
        with torch.no_grad():
            w = torch.tensor(init_wte, dtype=torch.float32)
            if w.shape == (vs_, 2):
                m.wte.weight.copy_(w)
    X, yn, ys = build_tensors(KA, device, vs=vs_)
    spc = max_steps // nr
    bs = 0
    bu = 0
    bsst = None
    bust = None
    gs = 0
    print(f'\n  Training {label} (circ_reg={circ_reg}, steps={max_steps})...')
    for restart in range(nr):
        opt = torch.optim.Adam(m.parameters(), lr=0.003 * 0.7 ** restart)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=spc, eta_min=1e-05 * 0.7 ** restart)
        for step in range(1, spc + 1):
            gs += 1
            if freeze_after and gs > freeze_after:
                m.wte.weight.requires_grad = False
            m.train()
            opt.zero_grad()
            nl, sl = m(X)
            loss = (1 - sw) * loss_fn(nl.view(-1, vs_), yn.view(-1)) + sw * loss_fn(sl.view(-1, vs_), ys.view(-1))
            if circ_reg > 0:
                loss += circular_reg_loss(m.wte.weight, vs_, strength=circ_reg)
            loss.backward()
            nn.utils.clip_grad_norm_(m.parameters(), 1.0)
            opt.step()
            sched.step()
            if gs % 200 == 0:
                m.eval()
                sc = score_m(m, KA)
                u = score_u(m, KA)
                if sc > bs:
                    bs = sc
                    bsst = {k: v.clone() for k, v in m.state_dict().items()}
                if u > bu:
                    bu = u
                    bust = {k: v.clone() for k, v in m.state_dict().items()}
                print(f'    {label} step {gs:>5} (r{restart + 1}): known={sc}/8 unseen={u}/{len(UNSEEN)}', flush=True)
    res = {}
    for key, state in [('best_known', bsst), ('best_unseen', bust)]:
        if state:
            m.load_state_dict(state)
            res[key] = m.wte.weight.detach().numpy().copy()
    return (bs, bu, res, m)

def train_parent(seed, steps=400):
    torch.manual_seed(seed)
    np.random.seed(seed)
    m = SeqModel(DA, HA, 3, KA).to(device)
    for nm, p in m.named_parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
        else:
            nn.init.zeros_(p)
    opt = torch.optim.Adam(m.parameters(), lr=0.005)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=0.0001)
    bs = 0
    bst = None
    for step in range(1, steps + 1):
        m.train()
        opt.zero_grad()
        nl, _ = m(ALL_X)
        loss_fn(nl.view(-1, VS), ALL_Y.view(-1)).backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 100 == 0:
            sc = score_m(m, KA)
            if sc > bs:
                bs = sc
                bst = {k: v.clone() for k, v in m.state_dict().items()}
    if bst:
        m.load_state_dict(bst)
    return (bs, m)

def tension_d2(parents):
    wtes = [m.wte.weight.detach().numpy() for m in parents]
    ref = wtes[0]
    proj = [w @ solve(w, ref) for w in wtes]
    N = len(proj)
    ags = []
    for i in range(N):
        for j in range(i + 1, N):
            ags.append(np.sum(proj[i] * proj[j], axis=0))
    ags = np.array(ags)
    comb = ags.mean(0) + ags.std(0)
    fd = np.argsort(comb)[-6:]
    WM = np.mean(proj, axis=0)
    WM[:, fd] *= -1
    U, s, Vt = np.linalg.svd(WM, full_matrices=False)
    return (U[:, :2] * s[:2]).astype(np.float32)
print('=' * 72)
print('  SURGERY V21 — FORCING Z/31Z: VALUE → ANGLE')
print('  Three experiments to make the circle ORDERED')
print('=' * 72)
t0 = time.time()
print('\n' + '=' * 72)
print('  EXP A — FORCED CIRCULAR INIT (perfect Z/31Z start)')
print('  Q: Does training MAINTAIN the circular order?')
print('  Or does backprop scramble it to gain accuracy?')
print('=' * 72)
wte_circle = circular_init(VS)
print(f'  Perfect Z/31Z init: token k at angle k×360/{VS}°')
print(f'  Token 0: ({wte_circle[0, 0]:.3f},{wte_circle[0, 1]:.3f}) = 0°')
print(f'  Token 8: ({wte_circle[8, 0]:.3f},{wte_circle[8, 1]:.3f}) = {360 * 8 / VS:.1f}°')
print(f'  Token 16: ({wte_circle[16, 0]:.3f},{wte_circle[16, 1]:.3f}) = {360 * 16 / VS:.1f}°')
print('\n  Before training:')
g_perfect = analyze_circle_full(wte_circle, 'Perfect Z/31Z init')
bs_a, bu_a, res_a, m_a = train_d2_exp(wte_circle, 'ExpA', max_steps=2000, sw=0.5, nr=4, circ_reg=0.0)
print(f'\n  ExpA result: known={bs_a}/8 unseen={bu_a}/{len(UNSEEN)}')
key_a = 'best_unseen' if 'best_unseen' in res_a else 'best_known' if 'best_known' in res_a else None
wte_a = res_a[key_a] if key_a else m_a.wte.weight.detach().numpy()
print('\n  After training:')
g_a = analyze_circle_full(wte_a, 'ExpA: after training (no reg)')
print('\n' + '=' * 72)
print('  EXP B — CIRCULAR REGULARIZATION (force Z/31Z ordering)')
print('  Loss = task_loss + λ×||embed_k - ideal_k||²')
print('  Testing λ=0.01, 0.1, 0.5')
print('=' * 72)
best_bu_b = 0
best_reg = 0
best_wte_b = None
for reg_strength in [0.01, 0.1, 0.5]:
    bs_b, bu_b, res_b, m_b = train_d2_exp(wte_circle, f'ExpB(λ={reg_strength})', max_steps=1500, sw=0.5, nr=3, circ_reg=reg_strength)
    print(f'  λ={reg_strength}: known={bs_b}/8 unseen={bu_b}/{len(UNSEEN)}')
    key_b = 'best_unseen' if 'best_unseen' in res_b else 'best_known' if 'best_known' in res_b else None
    if key_b:
        wte_b = res_b[key_b]
        g_b = analyze_circle_full(wte_b, f'ExpB λ={reg_strength}')
        if bu_b > best_bu_b or (bu_b == best_bu_b and g_b['r2znz'] > 0):
            best_bu_b = bu_b
            best_reg = reg_strength
            best_wte_b = wte_b
print('\n' + '=' * 72)
print('  EXP C — TENSION INIT + CIRCULAR REG (combine both)')
print('  Best init (32-parent tension) + circular ordering constraint')
print('=' * 72)
print('  Training 32 parents (400 steps each)...')
parents = []
for seed in range(32):
    _, m = train_parent(seed, steps=400)
    parents.append(m)
    if seed % 16 == 15:
        print(f'  Done {seed + 1}/32', flush=True)
wte_tension = tension_d2(parents)
print(f'  Tension init computed.')
print('\n  Without regularization:')
g_tension_raw = analyze_circle_full(wte_tension, 'Tension init (raw)')
bs_c1, bu_c1, res_c1, m_c1 = train_d2_exp(wte_tension, 'ExpC1(tension,no_reg)', max_steps=2000, sw=0.5, nr=4, circ_reg=0.0)
key_c1 = 'best_unseen' if 'best_unseen' in res_c1 else 'best_known' if 'best_known' in res_c1 else None
wte_c1 = res_c1[key_c1] if key_c1 else m_c1.wte.weight.detach().numpy()
g_c1 = analyze_circle_full(wte_c1, 'ExpC1: tension, no reg')
print(f'  ExpC1: known={bs_c1}/8 unseen={bu_c1}/{len(UNSEEN)}')
bs_c2, bu_c2, res_c2, m_c2 = train_d2_exp(wte_tension, 'ExpC2(tension+reg)', max_steps=2000, sw=0.5, nr=4, circ_reg=0.1)
key_c2 = 'best_unseen' if 'best_unseen' in res_c2 else 'best_known' if 'best_known' in res_c2 else None
wte_c2 = res_c2[key_c2] if key_c2 else m_c2.wte.weight.detach().numpy()
g_c2 = analyze_circle_full(wte_c2, 'ExpC2: tension + reg(0.1)')
print(f'  ExpC2: known={bs_c2}/8 unseen={bu_c2}/{len(UNSEEN)}')
print('\n' + '=' * 72)
print('  RESULTS SUMMARY')
print('=' * 72)
print(f"\n  {'Experiment':>30}  {'circle':>7}  {'Z/nZ R²':>8}  {'angReg':>7}  {'geo/10':>7}  {'known':>6}  {'unseen':>7}")
print(f"  {'─' * 80}")
rows = [('V19 D=2 (baseline)', 0.762, 0.992, 0.0, 0, '?', '1'), ('V20 D=2 (32-parent)', 0.698, 0.9916, 0.0028, 0, '1', '1'), ('A: perfect init, no reg', g_a['cq'], g_a['r2znz'], g_a['r2ang'], g_a['gc'], str(bs_a), str(bu_a)), (f'B: best λ={best_reg}', 0, 0, 0, best_bu_b, '?', str(best_bu_b)), ('C1: tension, no reg', g_c1['cq'], g_c1['r2znz'], g_c1['r2ang'], g_c1['gc'], str(bs_c1), str(bu_c1)), ('C2: tension + reg(0.1)', g_c2['cq'], g_c2['r2znz'], g_c2['r2ang'], g_c2['gc'], str(bs_c2), str(bu_c2))]
for row in rows:
    nm, cq, r2z, r2a, gc, k, u = row
    print(f'  {nm:>30}  {cq:>7.3f}  {r2z:>8.4f}  {r2a:>7.4f}  {gc:>7}  {k:>6}  {u:>7}')
print('\n' + '=' * 72)
print('  THE FUNDAMENTAL QUESTION')
print('=' * 72)
print(f'\n  Does the circle need to be ORDERED to be useful?\n  \n  V19/V20: circle found (R²≈0.99), order scrambled, angular_R²≈0\n    → Evens and primes still cluster → structure without ordering\n    → But arithmetic steps not predictable from geometry alone\n    \n  ExpA: started with perfect ordering, training may scramble it\n    → If Z/nZ_R² stays high AND angReg_R² rises: ORDER IS LEARNED\n    → If Z/nZ_R² drops: model prefers scrambled (better for task)\n    \n  The REAL FINDING from V20:\n  \n  FINDING 46 (CORRECTED) — S¹ vs Z/31Z:\n    The model found S¹ (circle as manifold), not Z/31Z (cyclic group).\n    All 31 tokens equally spaced on a circle — optimal packing in 2D.\n    But NOT in numerical order — the group action is missing.\n    \n  FINDING 49 — THE PACKING LAW:\n    In D=2, n tokens self-organize into a regular n-gon (polygon).\n    This is the optimal solution to: "place n distinct vectors in 2D."\n    This is NOT the same as Z/nZ. It is a geometric accident\n    that the optimal packing happens to be the same shape as Z/nZ.\n    The shape is correct. The meaning is different.\n    \n  FINDING 50 — ARITHMETIC PROPERTIES WITHOUT ORDERING:\n    Even/odd separation and prime clustering exist on the scrambled circle.\n    The model knows WHICH tokens are even. It does not know THAT evens\n    form a regular 2-element subgroup of Z/31Z.\n    The property is known without the structure being known.\n    This is like knowing that cats are mammals without knowing\n    the Linnaean taxonomy.\n    \n  TOTAL TIME: {time.time() - t0:.1f}s\n')
print('=' * 72 + '\n')
