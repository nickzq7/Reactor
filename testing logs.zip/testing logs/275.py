import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — SEMANTIC RAM v3')
print('  Full float cosine matching on pre-GeLU vector')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={n_layers}')
LW = {}
with torch.no_grad():
    for l in range(n_layers):
        blk = model.transformer.h[l]
        att = blk.attn.attention
        LW[l] = {'Wq': att.q_proj.weight.detach().numpy(), 'Wk': att.k_proj.weight.detach().numpy(), 'Wv': att.v_proj.weight.detach().numpy(), 'Wo': att.out_proj.weight.detach().numpy(), 'bo': att.out_proj.bias.detach().numpy(), 'W1': blk.mlp.c_fc.weight.detach().numpy(), 'b1': blk.mlp.c_fc.bias.detach().numpy(), 'W2': blk.mlp.c_proj.weight.detach().numpy(), 'b2': blk.mlp.c_proj.bias.detach().numpy(), 'ln1_w': blk.ln_1.weight.detach().numpy(), 'ln1_b': blk.ln_1.bias.detach().numpy(), 'ln2_w': blk.ln_2.weight.detach().numpy(), 'ln2_b': blk.ln_2.bias.detach().numpy()}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu_new(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def forward_full(token_ids):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
    for l in range(n_layers):
        W = LW[l]
        ln1 = ln_np(x, W['ln1_w'], W['ln1_b'])
        Q = ln1 @ W['Wq'].T
        K = ln1 @ W['Wk'].T
        V = ln1 @ W['Wv'].T
        Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        heads = []
        for h in range(n_heads):
            sc = Qh[h] @ Kh[h].T
            heads.append(softmax_np(sc + mask) @ Vh[h])
        concat = np.stack(heads, 1).reshape(seq_len, D)
        att_out = concat @ W['Wo'].T + W['bo']
        x = x + att_out
        ln2 = ln_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['W1'].T + W['b1']
        g = gelu_new(pre)
        ffn_out = g @ W['W2'].T + W['b2']
        if l == n_layers - 1:
            pre_last = pre[-1]
            gelu_last = g[-1]
            x_before_lnf = (x + ffn_out)[-1]
            x = x + ffn_out
            h_f = ln_np(x, lnf_w, lnf_b)
            logits = (h_f[-1:] @ lm_w.T)[0]
            true_next = int(np.argmax(logits))
            return (pre_last, gelu_last, x_before_lnf, true_next)
        else:
            x = x + ffn_out

def cosine_sim(a, b_matrix):
    a_norm = a / (np.linalg.norm(a) + 1e-08)
    b_norm = b_matrix / (np.linalg.norm(b_matrix, axis=1, keepdims=True) + 1e-08)
    return b_norm @ a_norm
print(f"\n{'=' * 66}")
print(f'  BUILDING RAM — SET A (25 prompts × 20 tokens)')
print(f"{'=' * 66}\n")
SET_A = ['Once upon a time', 'The little girl smiled', 'A brave knight rode', 'Deep in the forest', 'The old woman said', 'Every morning the bird', 'She opened the door', 'The dragon flew over', 'A tiny seed grew', 'The children laughed and', 'He wished upon a star', 'The magic spell worked', 'Her mother called her name', 'The sun was very bright', 'They walked together slowly', 'A rainbow appeared after', 'The dog found a bone', 'Once there was a king', 'The baby bear said', 'A yellow duck swam', 'The snow fell softly', 'He ran very fast', 'The cat sat on', 'She drew a picture', 'The wind blew hard']
RAM_pre = []
RAM_gelu = []
RAM_h = []
RAM_tok = []
for prompt in SET_A:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for _ in range(20):
        pre, gelu, h, true_next = forward_full(ids)
        RAM_pre.append(pre)
        RAM_gelu.append(gelu)
        RAM_h.append(h)
        RAM_tok.append(true_next)
        ids.append(true_next)
RAM_pre = np.array(RAM_pre, dtype=np.float32)
RAM_gelu = np.array(RAM_gelu, dtype=np.float32)
RAM_h = np.array(RAM_h, dtype=np.float32)
RAM_tok = np.array(RAM_tok, dtype=np.int32)
print(f'  RAM: {len(RAM_pre)} entries')
print(f'  Unique tokens: {len(np.unique(RAM_tok))}')
print(f"\n{'=' * 66}")
print(f'  PHASE 2 — THREE MATCHING METHODS ON SET B')
print(f'  Method A: cosine similarity on pre-GeLU floats')
print(f'  Method B: cosine similarity on post-GeLU floats')
print(f'  Method C: cosine similarity on hidden state h')
print(f"{'=' * 66}\n")
SET_B = ['The princess looked at', 'In a land far away', 'The wizard learned that', 'A small fish swam', 'The farmer planted seeds', 'Her eyes were blue', 'The train arrived at', 'A monkey climbed the']
results = {'A': {'correct': 0, 'total': 0}, 'B': {'correct': 0, 'total': 0}, 'C': {'correct': 0, 'total': 0}}
print(f"  {'Step':<5} {'True':<14} {'A:pre':<14} {'B:gelu':<14} {'C:h':<14}")
print(f"  {'─' * 60}")
for prompt in SET_B[:4]:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    print(f'\n  Prompt: {prompt}')
    for step in range(10):
        pre, gelu, h, true_next = forward_full(ids)
        sim_A = cosine_sim(pre, RAM_pre)
        tok_A = int(RAM_tok[np.argmax(sim_A)])
        sim_B = cosine_sim(gelu, RAM_gelu)
        tok_B = int(RAM_tok[np.argmax(sim_B)])
        sim_C = cosine_sim(h, RAM_h)
        tok_C = int(RAM_tok[np.argmax(sim_C)])

        def dec(t):
            return repr(tokenizer.decode([t]))[:12]
        mA = '✓' if tok_A == true_next else '✗'
        mB = '✓' if tok_B == true_next else '✗'
        mC = '✓' if tok_C == true_next else '✗'
        print(f'  {step + 1:<5} {dec(true_next):<14} {dec(tok_A)}{mA:<11} {dec(tok_B)}{mB:<11} {dec(tok_C)}{mC:<11}')
        ids.append(true_next)
print(f'\n  Full statistics (all 8 prompts × 15 tokens):\n')
for prompt in SET_B:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for _ in range(15):
        pre, gelu, h, true_next = forward_full(ids)
        tok_A = int(RAM_tok[np.argmax(cosine_sim(pre, RAM_pre))])
        tok_B = int(RAM_tok[np.argmax(cosine_sim(gelu, RAM_gelu))])
        tok_C = int(RAM_tok[np.argmax(cosine_sim(h, RAM_h))])
        for key, tok in [('A', tok_A), ('B', tok_B), ('C', tok_C)]:
            results[key]['total'] += 1
            if tok == true_next:
                results[key]['correct'] += 1
        ids.append(true_next)
total = results['A']['total']
for key, name in [('A', 'pre-GeLU cosine'), ('B', 'post-GeLU cosine'), ('C', 'hidden-h cosine')]:
    r = results[key]
    acc = 100 * r['correct'] / r['total']
    print(f"  {name:<25}: {r['correct']}/{total} = {acc:.1f}%")
print(f"\n{'=' * 66}")
print(f'  PHASE 3 — DIRECT SHORTCUT TEST')
print(f'  Can pre-GeLU float bypass W2 + LNF + lm_head entirely?')
print(f'  Test: learn linear W_shortcut such that')
print(f'        pre[-1] @ W_shortcut = same argmax as full model')
print(f"{'=' * 66}\n")
pre_all = []
logit_all = []
for prompt in SET_A[:10]:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for _ in range(15):
        pre, gelu, h, true_next = forward_full(ids)
        seq_len = len(ids)
        x = (wte[ids] + wpe[np.arange(seq_len)]).astype(np.float32)
        mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
        for l in range(n_layers):
            W = LW[l]
            ln1 = ln_np(x, W['ln1_w'], W['ln1_b'])
            Q = ln1 @ W['Wq'].T
            K = ln1 @ W['Wk'].T
            V = ln1 @ W['Wv'].T
            Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
            Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
            Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
            heads = [softmax_np(Qh[hh] @ Kh[hh].T + mask) @ Vh[hh] for hh in range(n_heads)]
            x = x + np.stack(heads, 1).reshape(seq_len, D) @ W['Wo'].T + W['bo']
            g = gelu_new(ln_np(x, W['ln2_w'], W['ln2_b']) @ W['W1'].T + W['b1'])
            x = x + g @ W['W2'].T + W['b2']
        h_f = ln_np(x, lnf_w, lnf_b)
        logits = (h_f[-1:] @ lm_w.T)[0]
        pre_all.append(pre)
        logit_all.append(logits)
        ids.append(int(np.argmax(logits)))
pre_all = np.array(pre_all, dtype=np.float32)
logit_all = np.array(logit_all, dtype=np.float32)
print(f'  Fitting linear probe: pre_gelu → h_final...')
h_finals = []
for prompt in SET_A[:10]:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for _ in range(15):
        pre, gelu, h, true_next = forward_full(ids)
        h_finals.append(h)
        ids.append(true_next)
h_finals = np.array(h_finals, dtype=np.float32)
X = pre_all
Y = h_finals
M = np.linalg.lstsq(X, Y, rcond=None)[0]
pred_h = X @ M
ss_res = np.sum((Y - pred_h) ** 2)
ss_tot = np.sum((Y - Y.mean(0)) ** 2)
r2 = 1 - ss_res / ss_tot
print(f'  R² (pre_gelu → h_final):  {r2:.6f}')
shortcut_correct = 0
shortcut_total = 0
for prompt in SET_B:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for _ in range(15):
        pre, gelu, h, true_next = forward_full(ids)
        h_approx = pre @ M
        h_approx = ln_np(h_approx[np.newaxis], lnf_w, lnf_b)[0]
        logits_sc = h_approx @ lm_w.T
        tok_sc = int(np.argmax(logits_sc))
        shortcut_correct += tok_sc == true_next
        shortcut_total += 1
        ids.append(true_next)
sc_acc = 100 * shortcut_correct / shortcut_total
print(f'  Shortcut accuracy (pre→h→lm): {shortcut_correct}/{shortcut_total} = {sc_acc:.1f}%')
print(f"\n{'=' * 66}")
print(f'  FINAL SUMMARY')
print(f"{'=' * 66}\n")
best_method = max([('A', 'pre-GeLU cosine'), ('B', 'post-GeLU cosine'), ('C', 'hidden-h cosine')], key=lambda x: results[x[0]]['correct'])
best_acc = 100 * results[best_method[0]]['correct'] / results[best_method[0]]['total']
print(f"\n  RAM MATCHING RESULTS:\n    pre-GeLU cosine:    {100 * results['A']['correct'] / total:.1f}%\n    post-GeLU cosine:   {100 * results['B']['correct'] / total:.1f}%\n    hidden-h cosine:    {100 * results['C']['correct'] / total:.1f}%\n    Best method:        {best_method[1]} = {best_acc:.1f}%\n\n  LINEAR SHORTCUT:\n    pre_gelu → h_final R²: {r2:.6f}\n    Shortcut token accuracy: {sc_acc:.1f}%\n\n  INTERPRETATION:\n\n  If best cosine match > 90%:\n    Semantic address space confirmed.\n    Float vector at that layer = token address.\n    W2 + lm_head = unnecessary translation ceremony.\n    Replace with cosine lookup. Zero IO. Zero quality loss.\n\n  If linear shortcut R² > 0.99:\n    pre-GeLU floats contain enough information\n    to reconstruct h_final linearly.\n    Meaning: W2 + LNF are linear transformations\n    of information already present in pre-GeLU.\n    They add no new information.\n    W law: the crystal already decided. Rest = translation.\n\n  If R² < 0.99:\n    GeLU activation (the crystal) changes the space.\n    Pre-GeLU ≠ post-GeLU in information content.\n    The nonlinearity is essential.\n    Address lives AFTER GeLU, not before.\n    Repeat test with post-GeLU (RAM_gelu).\n")
print('=' * 66 + '\n')
