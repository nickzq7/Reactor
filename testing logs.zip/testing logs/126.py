import numpy as np
import math
import json

def load_weights(repo_id):
    from huggingface_hub import hf_hub_download
    try:
        from safetensors.numpy import load_file as st_load
        path = hf_hub_download(repo_id=repo_id, filename='model.safetensors')
        raw = st_load(path)
        return {k: v.astype(np.float64) for k, v in raw.items()}
    except Exception:
        pass
    import torch
    path = hf_hub_download(repo_id=repo_id, filename='pytorch_model.bin')
    try:
        state = torch.load(path, map_location='cpu', weights_only=True)
    except TypeError:
        state = torch.load(path, map_location='cpu')
    result = {k: v.detach().float().numpy().astype(np.float64) for k, v in state.items()}
    del state
    return result

def load_config(repo_id):
    from huggingface_hub import hf_hub_download
    path = hf_hub_download(repo_id=repo_id, filename='config.json')
    with open(path) as f:
        return json.load(f)

def load_tokenizer_vocab(repo_id):
    from huggingface_hub import hf_hub_download
    vocab_path = hf_hub_download(repo_id=repo_id, filename='vocab.json')
    merges_path = hf_hub_download(repo_id=repo_id, filename='merges.txt')
    with open(vocab_path, encoding='utf-8') as f:
        vocab = json.load(f)
    with open(merges_path, encoding='utf-8') as f:
        merges = f.read().splitlines()
    return (vocab, merges)

def parse_att_layers(cfg, NL):
    att = cfg.get('attention_layers', None)
    if att and isinstance(att, list) and (len(att) == NL) and isinstance(att[0], str):
        return [str(x) for x in att]
    att_types = cfg.get('attention_types', None)
    if att_types:
        flat = []
        for entry in att_types:
            types, count = (entry[0], int(entry[1]))
            for _ in range(count):
                flat.extend(types)
        if len(flat) >= NL:
            return [str(x) for x in flat[:NL]]
    return ['global'] * NL

def extract_layers(W, NL):
    wte = W['transformer.wte.weight']
    wpe = W['transformer.wpe.weight']
    lfg = W['transformer.ln_f.weight']
    lfb = W['transformer.ln_f.bias']
    lmh = W.get('lm_head.weight', wte)
    layers = []
    for l in range(NL):
        pfx = f'transformer.h.{l}'
        a = f'{pfx}.attn.attention'
        m = f'{pfx}.mlp'
        layers.append({'WQ': W[f'{a}.q_proj.weight'], 'WK': W[f'{a}.k_proj.weight'], 'WV': W[f'{a}.v_proj.weight'], 'WO': W[f'{a}.out_proj.weight'], 'bO': W[f'{a}.out_proj.bias'], 'W1': W[f'{m}.c_fc.weight'], 'b1': W[f'{m}.c_fc.bias'], 'W2': W[f'{m}.c_proj.weight'], 'b2': W[f'{m}.c_proj.bias'], 'LN1g': W[f'{pfx}.ln_1.weight'], 'LN1b': W[f'{pfx}.ln_1.bias'], 'LN2g': W[f'{pfx}.ln_2.weight'], 'LN2b': W[f'{pfx}.ln_2.bias']})
    return (wte, wpe, lfg, lfb, lmh, layers)

class BPETokenizer:

    def __init__(self, vocab, merges):
        self.encoder = vocab
        self.decoder = {v: k for k, v in vocab.items()}
        self.bpe_ranks = {}
        for i, line in enumerate(merges):
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) == 2:
                self.bpe_ranks[parts[0], parts[1]] = i
        self.byte_encoder = self._build_byte_encoder()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}

    @staticmethod
    def _build_byte_encoder():
        bs = list(range(ord('!'), ord('~') + 1)) + list(range(ord('¡'), ord('¬') + 1)) + list(range(ord('®'), ord('ÿ') + 1))
        cs = bs[:]
        n = 0
        for b in range(256):
            if b not in bs:
                bs.append(b)
                cs.append(256 + n)
                n += 1
        return {b: chr(c) for b, c in zip(bs, cs)}

    def _bpe(self, token):
        word = tuple((self.byte_encoder[b] for b in token.encode('utf-8')))
        if len(word) <= 1:
            return word
        pairs = {(word[i], word[i + 1]) for i in range(len(word) - 1)}
        while True:
            bigram = min(pairs, key=lambda p: self.bpe_ranks.get(p, float('inf')))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                except ValueError:
                    new_word.extend(word[i:])
                    break
                new_word.extend(word[i:j])
                if j < len(word) - 1 and word[j + 1] == second:
                    new_word.append(first + second)
                    i = j + 2
                else:
                    new_word.append(word[j])
                    i = j + 1
            word = tuple(new_word)
            if len(word) == 1:
                break
            pairs = {(word[i], word[i + 1]) for i in range(len(word) - 1)}
        return word

    def encode(self, text):
        import re
        pattern = "'s|'t|'re|'ve|'m|'ll|'d| ?\\w+| ?\\d+| ?[^\\s\\w\\d]+|\\s+(?!\\S)|\\s+"
        ids = []
        for token in re.findall(pattern, text):
            for bt in self._bpe(token):
                if bt in self.encoder:
                    ids.append(self.encoder[bt])
        return ids

    def decode(self, ids):
        text = ''.join((self.decoder.get(i, '') for i in ids))
        return bytearray([self.byte_decoder[c] for c in text if c in self.byte_decoder]).decode('utf-8', errors='replace')

def ln_op(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2.0 / math.pi)
    return 0.5 * x * (1.0 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=False):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    W, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)
    return W

def r2(pred, true):
    p = np.asarray(pred).ravel()
    t = np.asarray(true).ravel()
    sv = np.var(t)
    return float(1.0 - np.mean((p - t) ** 2) / sv) if sv > 1e-12 else 1.0

def causal_mask(n):
    return np.triu(np.full((n, n), -1000000000.0), k=1)

def local_mask(n, w):
    m = causal_mask(n)
    for i in range(n):
        for j in range(max(0, i - w)):
            m[i, j] = -1000000000.0
    return m

def get_mask(slen, at, win):
    return local_mask(slen, int(win)) if str(at).strip() == 'local' else causal_mask(slen)

def fwd(seq, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win):
    slen = len(seq)
    x = wte[seq] + wpe[np.arange(slen)]
    for l, lw in enumerate(layers):
        at = att_types[l] if l < len(att_types) else 'global'
        ln1 = ln_op(x, lw['LN1g'], lw['LN1b'])
        Q = ln1 @ lw['WQ'].T
        K_ = ln1 @ lw['WK'].T
        V = ln1 @ lw['WV'].T
        hd_ = Q.shape[-1] // H
        Qh = Q.reshape(slen, H, hd_).transpose(1, 0, 2)
        Kh = K_.reshape(slen, H, hd_).transpose(1, 0, 2)
        Vh = V.reshape(slen, H, hd_).transpose(1, 0, 2)
        mk = get_mask(slen, at, win)
        heads = [softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H)]
        ctx = np.stack(heads, axis=1).reshape(slen, -1)
        att = ctx @ lw['WO'].T + lw['bO']
        hm = x + att
        ln2 = ln_op(hm, lw['LN2g'], lw['LN2b'])
        pre = ln2 @ lw['W1'].T + lw['b1']
        g = gelu(pre)
        ffn = g @ lw['W2'].T + lw['b2']
        x = hm + ffn
    return ln_op(x, lfg, lfb) @ lmh.T

def collect(seqs, wte, wpe, layers, H, att_types, win, NL_):
    keys = ['ln1', 'Q', 'K', 'V', 'ctx', 'att', 'hm', 'ln2', 'pre', 'gelu', 'ffn']
    store = {l: {k: [] for k in keys} for l in range(NL_)}
    for seq in seqs:
        slen = len(seq)
        x = wte[seq] + wpe[np.arange(slen)]
        for l, lw in enumerate(layers):
            at = att_types[l] if l < len(att_types) else 'global'
            ln1 = ln_op(x, lw['LN1g'], lw['LN1b'])
            store[l]['ln1'].append(ln1)
            Q = ln1 @ lw['WQ'].T
            K_ = ln1 @ lw['WK'].T
            V = ln1 @ lw['WV'].T
            store[l]['Q'].append(Q)
            store[l]['K'].append(K_)
            store[l]['V'].append(V)
            hd_ = Q.shape[-1] // H
            Qh = Q.reshape(slen, H, hd_).transpose(1, 0, 2)
            Kh = K_.reshape(slen, H, hd_).transpose(1, 0, 2)
            Vh = V.reshape(slen, H, hd_).transpose(1, 0, 2)
            mk = get_mask(slen, at, win)
            heads = [softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H)]
            ctx = np.stack(heads, axis=1).reshape(slen, -1)
            att = ctx @ lw['WO'].T + lw['bO']
            store[l]['ctx'].append(ctx)
            store[l]['att'].append(att)
            hm = x + att
            store[l]['hm'].append(hm)
            ln2 = ln_op(hm, lw['LN2g'], lw['LN2b'])
            store[l]['ln2'].append(ln2)
            pre = ln2 @ lw['W1'].T + lw['b1']
            store[l]['pre'].append(pre)
            g = gelu(pre)
            store[l]['gelu'].append(g)
            ffn = g @ lw['W2'].T + lw['b2']
            store[l]['ffn'].append(ffn)
            x = hm + ffn
    for l in range(NL_):
        for k in store[l]:
            store[l][k] = np.concatenate(store[l][k], 0).astype(np.float64)
    return store

def recompute_coherent_ctx(seqs, wte, wpe, LA_orig, Wq, Wk, Wv, target_l, H, att_types, win):
    all_ctx = []
    for seq in seqs:
        slen = len(seq)
        x = wte[seq] + wpe[np.arange(slen)]
        for l, lw in enumerate(LA_orig):
            at = att_types[l] if l < len(att_types) else 'global'
            ln1 = ln_op(x, lw['LN1g'], lw['LN1b'])
            if l == target_l:
                Q = ln1 @ Wq
                K_ = ln1 @ Wk
                V = ln1 @ Wv
                hd_ = Q.shape[-1] // H
                Qh = Q.reshape(slen, H, hd_).transpose(1, 0, 2)
                Kh = K_.reshape(slen, H, hd_).transpose(1, 0, 2)
                Vh = V.reshape(slen, H, hd_).transpose(1, 0, 2)
                mk = get_mask(slen, at, win)
                heads = [softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H)]
                all_ctx.append(np.stack(heads, axis=1).reshape(slen, -1))
                break
            else:
                Q = ln1 @ lw['WQ'].T
                K_ = ln1 @ lw['WK'].T
                V = ln1 @ lw['WV'].T
                hd_ = Q.shape[-1] // H
                Qh = Q.reshape(slen, H, hd_).transpose(1, 0, 2)
                Kh = K_.reshape(slen, H, hd_).transpose(1, 0, 2)
                Vh = V.reshape(slen, H, hd_).transpose(1, 0, 2)
                mk = get_mask(slen, at, win)
                heads = [softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H)]
                ctx = np.stack(heads, axis=1).reshape(slen, -1)
                att = ctx @ lw['WO'].T + lw['bO']
                hm = x + att
                ln2 = ln_op(hm, lw['LN2g'], lw['LN2b'])
                pre = ln2 @ lw['W1'].T + lw['b1']
                g = gelu(pre)
                ffn = g @ lw['W2'].T + lw['b2']
                x = hm + ffn
    return np.concatenate(all_ctx, 0).astype(np.float64)
print('\n' + '=' * 72)
print('  SURGERY V4 — ORACLE-BASED INTELLIGENCE TRANSFER')
print('  TinyStories-1M (D=64) ← TinyStories-8M (D=256)')
print("  B's actual weights used as oracle for A's new weights")
print('=' * 72)
print('\n  Loading configs...')
cfgA = load_config('roneneldan/TinyStories-1M')
cfgB = load_config('roneneldan/TinyStories-8M')
DA = cfgA['hidden_size']
DB = cfgB['hidden_size']
HA = cfgA.get('num_heads', cfgA.get('num_attention_heads'))
HB = cfgB.get('num_heads', cfgB.get('num_attention_heads'))
NL = cfgA.get('num_layers', cfgA.get('n_layer'))
hdA = DA // HA
hdB = DB // HB
FFNA = cfgA.get('intermediate_size') or DA * 4
FFNB = cfgB.get('intermediate_size') or DB * 4
att_A = parse_att_layers(cfgA, NL)
win_A = int(cfgA.get('window_size', 256) if not isinstance(cfgA.get('window_size', 256), list) else cfgA['window_size'][0])
att_B = parse_att_layers(cfgB, NL)
win_B = int(cfgB.get('window_size', 256) if not isinstance(cfgB.get('window_size', 256), list) else cfgB['window_size'][0])
print(f'  Model A — 1M:  D={DA} H={HA} hd={hdA} FFN={FFNA} layers={NL}')
print(f'  Model B — 8M:  D={DB} H={HB} hd={hdB} FFN={FFNB} layers={NL}')
print(f'  att pattern:   {att_A}')
print('\n  Loading weights...')
WA_raw = load_weights('roneneldan/TinyStories-1M')
wteA, wpeA, lfgA, lfbA, lmhA, LA = extract_layers(WA_raw, NL)
del WA_raw
WB_raw = load_weights('roneneldan/TinyStories-8M')
wteB, wpeB, lfgB, lfbB, lmhB, LB = extract_layers(WB_raw, NL)
del WB_raw
print('\n  Loading tokenizer...')
tokA = BPETokenizer(*load_tokenizer_vocab('roneneldan/TinyStories-1M'))
tokB = BPETokenizer(*load_tokenizer_vocab('roneneldan/TinyStories-8M'))
PROMPTS = ['Once upon a time there was a little girl named Lily', 'The brave knight walked into the dark forest and', 'A small rabbit found a carrot in the garden and', 'The old wizard opened his magic book and said', 'One morning the children woke up and decided to', 'A friendly dragon lived near the village and', 'The little puppy was playing in the park when', 'A kind farmer had a beautiful horse named Star', 'The princess looked out of her window and saw', 'Two brothers went fishing by the river and found', 'The baby bear asked his mother why the sky', 'A little girl named Emma had a magic pencil that', 'Once upon a time there was a kind old woman', 'The little dog wagged his tail and ran to', 'One rainy day the cat found a warm dry place']
print('\n  Collecting activations...')
seqsA = [tokA.encode(t)[:24] for t in PROMPTS if len(tokA.encode(t)) >= 4]
seqsB = [tokB.encode(t)[:24] for t in PROMPTS if len(tokB.encode(t)) >= 4]
sA = collect(seqsA, wteA, wpeA, LA, HA, att_A, win_A, NL)
sB = collect(seqsB, wteB, wpeB, LB, HB, att_B, win_B, NL)
NA = len(sA[0]['ln1'])
NB = len(sB[0]['ln1'])
print(f'  A: {NA} samples (D={DA})   B: {NB} samples (D={DB})')
print('\n' + '=' * 72)
print('  LAW VERIFICATION — BOTH MODELS')
print('=' * 72)

def verify(store, name):
    print(f'\n  {name}')
    print(f"  {'L':<4} {'WQ':>8} {'WO':>8} {'W1':>8} {'GeLU':>8} {'W2':>8}")
    ok_all = True
    for l in range(NL):
        s = store[l]
        n = len(s['ln1'])
        rq = r2(s['ln1'] @ solve(s['ln1'], s['Q']), s['Q'])
        ro = r2(s['ctx'] @ solve(s['ctx'], s['att']), s['att'])
        rw1 = r2(np.c_[s['ln2'], np.ones(n)] @ solve(s['ln2'], s['pre'], True), s['pre'])
        pns = np.c_[s['pre'], s['pre'] ** 2]
        rg = r2(pns @ solve(pns, s['gelu']), s['gelu'])
        rw2 = r2(np.c_[s['gelu'], np.ones(n)] @ solve(s['gelu'], s['ffn'], True), s['ffn'])
        ok = all((v > 0.999 for v in [rq, ro, rw1, rg, rw2]))
        ok_all &= ok
        print(f"  L{l:<3} {rq:>8.4f} {ro:>8.4f} {rw1:>8.4f} {rg:>8.4f} {rw2:>8.4f}  {('✓' if ok else '✗')}")
    print(f"  → {('ALL PASS ✓' if ok_all else 'FAIL ✗')}")
verify(sA, 'TinyStories-1M (A)')
verify(sB, 'TinyStories-8M (B)')
print('\n' + '=' * 72)
print('  ORACLE SURGERY V4')
print('=' * 72)
print("\n  FFN Oracle:\n    A→B expand: P_A2B = solve(ln2_A, ln2_B)   [64→256, underdetermined]\n    Oracle run: pre  = (ln2_A @ P_A2B) @ W1_B.T + b1_B\n                gelu = gelu(pre)\n                ffn  = gelu @ W2_B.T + b2_B    [uses B's actual weights]\n    B→A project: ffn_target = ffn @ P_B2A      [compress back to 64-dim]\n    Solve: W1_new, W2_new from ln2_A → ffn_target (coherent 2-pass)\n\n  ATT Oracle:\n    A→B expand:  P_A2B_ln1 = solve(ln1_A, ln1_B)\n    Oracle run:  Q_B = (ln1_A @ P_A2B) @ WQ_B.T, same for K,V\n                 run per-head attention in B-space (H=16, hd=16)\n                 att_B = ctx_B @ WO_B.T + bO_B   [uses B's actual weights]\n    B→A project: att_target = att_B @ P_B2A_att\n    Solve: coherent WQ/WK/WV/WO from ln1_A, ctx_A_coherent → targets\n")
print(f"  {'L':<4} {'A2B_ln2':>9} {'A2B_ln1':>9} | {'FFN_tgt':>9} {'ATT_tgt':>9} | {'WQ':>7} {'W1':>7} {'WO_c':>7} {'W2_c':>7}")
print(f"  {'─' * 76}")
surgery = {}
for l in range(NL):
    aA = sA[l]
    aB = sB[l]
    ns = min(len(aA['ln1']), len(aB['ln1']))
    ln1A = aA['ln1'][:ns]
    ln2A = aA['ln2'][:ns]
    ln1B = aB['ln1'][:ns]
    ln2B = aB['ln2'][:ns]
    P_A2B_ln2 = solve(ln2A, ln2B)
    P_A2B_ln1 = solve(ln1A, ln1B)
    r_a2b_ln2 = r2(ln2A @ P_A2B_ln2, ln2B)
    r_a2b_ln1 = r2(ln1A @ P_A2B_ln1, ln1B)
    P_B2A_ffn = solve(aB['ffn'][:ns], aA['ffn'][:ns])
    P_B2A_att = solve(aB['att'][:ns], aA['att'][:ns])
    ln2_B_approx = ln2A @ P_A2B_ln2
    pre_oracle = ln2_B_approx @ LB[l]['W1'].T + LB[l]['b1']
    gelu_oracle = gelu(pre_oracle)
    ffn_oracle = gelu_oracle @ LB[l]['W2'].T + LB[l]['b2']
    ffn_target = ffn_oracle @ P_B2A_ffn
    r_ffn_tgt = r2(ffn_target, aA['ffn'][:ns])
    P_B2A_pre = solve(aB['pre'][:ns], aA['pre'][:ns])
    pre_target = pre_oracle @ P_B2A_pre
    W1s = solve(ln2A, pre_target, True)
    W1_map = W1s[:-1]
    b1_new = W1s[-1]
    pre_coh = ln2A @ W1_map + b1_new
    gelu_coh = gelu(pre_coh)
    W2s = solve(gelu_coh, ffn_target, True)
    rw1 = r2(np.c_[ln2A, np.ones(ns)] @ W1s, pre_target)
    rw2 = r2(np.c_[gelu_coh, np.ones(ns)] @ W2s, ffn_target)
    ln1_B_approx = ln1A @ P_A2B_ln1
    att_oracle_list = []
    idx = 0
    for seq in seqsA:
        slen = len(seq[:24])
        ln1_B_seq = ln1_B_approx[idx:idx + slen]
        Q_B = ln1_B_seq @ LB[l]['WQ'].T
        K_B = ln1_B_seq @ LB[l]['WK'].T
        V_B = ln1_B_seq @ LB[l]['WV'].T
        Qh = Q_B.reshape(slen, HB, hdB).transpose(1, 0, 2)
        Kh = K_B.reshape(slen, HB, hdB).transpose(1, 0, 2)
        Vh = V_B.reshape(slen, HB, hdB).transpose(1, 0, 2)
        at = att_B[l] if l < len(att_B) else 'global'
        mk = get_mask(slen, at, win_B)
        heads = [softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(HB)]
        ctx_B = np.stack(heads, axis=1).reshape(slen, -1)
        att_B_seq = ctx_B @ LB[l]['WO'].T + LB[l]['bO']
        att_oracle_list.append(att_B_seq)
        idx += slen
    att_oracle = np.concatenate(att_oracle_list, 0)
    att_target = att_oracle @ P_B2A_att
    r_att_tgt = r2(att_target, aA['att'][:ns])
    P_B2A_Q = solve(aB['Q'][:ns], aA['Q'][:ns])
    P_B2A_K = solve(aB['K'][:ns], aA['K'][:ns])
    P_B2A_V = solve(aB['V'][:ns], aA['V'][:ns])
    Q_target = ln1A @ P_A2B_ln1 @ LB[l]['WQ'].T @ P_B2A_Q
    K_target = ln1A @ P_A2B_ln1 @ LB[l]['WK'].T @ P_B2A_K
    V_target = ln1A @ P_A2B_ln1 @ LB[l]['WV'].T @ P_B2A_V
    Wq = solve(ln1A, Q_target)
    Wk = solve(ln1A, K_target)
    Wv = solve(ln1A, V_target)
    rq = r2(ln1A @ Wq, Q_target)
    ctx_coh = recompute_coherent_ctx(seqsA, wteA, wpeA, LA, Wq, Wk, Wv, l, HA, att_A, win_A)[:ns]
    Wos = solve(ctx_coh, att_target, True)
    ro = r2(np.c_[ctx_coh, np.ones(ns)] @ Wos, att_target)
    print(f'  L{l:<3} {r_a2b_ln2:>9.4f} {r_a2b_ln1:>9.4f} | {r_ffn_tgt:>9.4f} {r_att_tgt:>9.4f} | {rq:>7.4f} {rw1:>7.4f} {ro:>7.4f} {rw2:>7.4f}')
    surgery[l] = {'WQ': Wq.T, 'WK': Wk.T, 'WV': Wv.T, 'WO': Wos[:-1].T, 'bO': Wos[-1], 'W1': W1_map.T, 'b1': b1_new, 'W2': W2s[:-1].T, 'b2': W2s[-1]}

def build(mode):
    layers = []
    for l in range(NL):
        lw = {k: v.copy() for k, v in LA[l].items()}
        sw = surgery[l]
        if mode in ('ATT', 'ALL'):
            lw['WQ'] = sw['WQ']
            lw['WK'] = sw['WK']
            lw['WV'] = sw['WV']
            lw['WO'] = sw['WO']
            lw['bO'] = sw['bO']
        if mode in ('FFN', 'ALL'):
            lw['W1'] = sw['W1']
            lw['b1'] = sw['b1']
            lw['W2'] = sw['W2']
            lw['b2'] = sw['b2']
        layers.append(lw)
    return layers
LA_ATT = build('ATT')
LA_FFN = build('FFN')
LA_ALL = build('ALL')

def ppl(layers, wte, wpe, lfg, lfb, lmh, tok, H, att_types, win, texts):
    total = 0.0
    cnt = 0
    for text in texts:
        ids = tok.encode(text)[:30]
        if len(ids) < 2:
            continue
        logits = fwd(ids, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win)
        for i in range(len(ids) - 1):
            row = logits[i]
            logz = row.max() + np.log(np.sum(np.exp(row - row.max())))
            total += -(row[ids[i + 1]] - logz)
            cnt += 1
    return float(np.exp(total / cnt)) if cnt > 0 else 999.0
EVAL = ['Once upon a time a kind old woman lived alone', 'The little dog wagged his tail and ran to', 'A brave girl climbed to the top of the hill', 'The children laughed and played all day in the', 'A tiny bird sang a sweet song in the morning', 'The friendly giant helped the villagers carry heavy logs', 'One rainy day the cat found a warm dry spot', 'The baby elephant splashed happily in the cool river', 'A wise owl sat on a branch and watched', 'The little boy gave his friend a red balloon']
print('\n  Computing perplexity...')
pp_A = ppl(LA, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)
pp_B = ppl(LB, wteB, wpeB, lfgB, lfbB, lmhB, tokB, HB, att_B, win_B, EVAL)
pp_ATT = ppl(LA_ATT, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)
pp_FFN = ppl(LA_FFN, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)
pp_ALL = ppl(LA_ALL, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)

def gap_pct(v, b, t):
    return 100.0 * (b - v) / (b - t + 1e-09)

def bar(v, lo, hi, w=28):
    f = max(0.0, min(1.0, (hi - v) / (hi - lo + 1e-09)))
    n = int(f * w)
    return '█' * n + '░' * (w - n)
print(f"\n  {'Model':<30} {'PPL':>8}   {'Gap':>8}   Progress")
print(f"  {'─' * 76}")
print(f"  {'8M target':<30} {pp_B:>8.1f}   {'TARGET':>8}")
print(f"  {'─' * 76}")
for name, pp, base in [('1M original', pp_A, None), ('1M+8M ATT v4', pp_ATT, pp_A), ('1M+8M FFN v4', pp_FFN, pp_A), ('1M+8M ALL v4', pp_ALL, pp_A)]:
    if base is None:
        print(f"  {name:<30} {pp:>8.1f}   {'baseline':>8}   {bar(pp, pp_B, pp_A)}")
    else:
        print(f'  {name:<30} {pp:>8.1f}   {gap_pct(pp, pp_A, pp_B):>7.1f}%   {bar(pp, pp_B, pp_A)}')
print('\n' + '=' * 72)
print('  GENERATION COMPARISON')
print('=' * 72)

def gen(layers, wte, wpe, lfg, lfb, lmh, tok, H, att_types, win, prompt, n=50):
    ids = tok.encode(prompt)
    for _ in range(n):
        seq = ids[-64:]
        logits = fwd(seq, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win)
        ids.append(int(np.argmax(logits[-1])))
    return tok.decode(ids)
CLIP = 110
for prompt in ['Once upon a time a little girl named', 'The brave knight saw a dragon and', 'A small rabbit was lost in the forest']:
    print(f'\n  Prompt: "{prompt}"')
    print(f"  {'─' * 66}")
    p = len(prompt)
    t1 = gen(LA, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    t8 = gen(LB, wteB, wpeB, lfgB, lfbB, lmhB, tokB, HB, att_B, win_B, prompt)
    tF = gen(LA_FFN, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    tA = gen(LA_ATT, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    tX = gen(LA_ALL, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    print(f'  [1M orig]:      {t1[p:p + CLIP]}')
    print(f'  [8M orig]:      {t8[p:p + CLIP]}')
    print(f'  [1M+8M FFN v4]: {tF[p:p + CLIP]}')
    print(f'  [1M+8M ATT v4]: {tA[p:p + CLIP]}')
    print(f'  [1M+8M ALL v4]: {tX[p:p + CLIP]}')
print('\n' + '=' * 72)
print('  SURGERY V4 VERDICT')
print('=' * 72)
print(f"\n  BASELINES\n    1M original:    ppl = {pp_A:.1f}\n    8M target:      ppl = {pp_B:.1f}\n    Gap:            {pp_A - pp_B:.1f} ppl units\n\n  V4 RESULTS (oracle transfer)\n    1M+8M ATT v4:  ppl = {pp_ATT:.1f}   ({gap_pct(pp_ATT, pp_A, pp_B):.1f}% gap closed)  {('✓ IMPROVED' if pp_ATT < pp_A else '✗ degraded')}\n    1M+8M FFN v4:  ppl = {pp_FFN:.1f}   ({gap_pct(pp_FFN, pp_A, pp_B):.1f}% gap closed)  {('✓ IMPROVED' if pp_FFN < pp_A else '✗ degraded')}\n    1M+8M ALL v4:  ppl = {pp_ALL:.1f}   ({gap_pct(pp_ALL, pp_A, pp_B):.1f}% gap closed)  {('✓ IMPROVED' if pp_ALL < pp_A else '✗ degraded')}\n\n  V3 REFERENCE (wrong direction)\n    1M+8M ATT v3:  ppl = 45.2   (0% — no change)\n    1M+8M FFN v3:  ppl = 75.2   (-166% — degraded)\n\n  KEY ORACLE METRICS (from surgery table):\n    A→B expansion R² tells quality of expansion (underdetermined 64→256)\n    ffn_target R² vs A's original ffn — how different is the oracle target?\n    If ffn_target R² = 1.0 → oracle = A's own output (no gain possible)\n    If ffn_target R² < 0.99 → oracle brings genuinely new signal\n\n  LAW 46: same family, same data = W1_B/W2_B compatible with A's space ✓\n")
print('=' * 72 + '\n')
