import os, time
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTNeoConfig
from datasets import load_dataset
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
KERNEL_CONFIG = GPTNeoConfig(vocab_size=50257, hidden_size=32, num_layers=2, attention_types=[[['global'], 2]], num_heads=2, intermediate_size=128, max_position_embeddings=128, window_size=128, resid_pdrop=0.0, embed_pdrop=0.0, attention_dropout=0.0)
kernel = AutoModelForCausalLM.from_config(KERNEL_CONFIG).to(device)
tok = AutoTokenizer.from_pretrained('gpt2')
tok.pad_token = tok.eos_token
p = sum((x.numel() for x in kernel.parameters()))
print(f'Params: {p:,}')
print('Loading TinyStories...')
raw = load_dataset('roneneldan/TinyStories', split='train')
texts = raw['text'][:5000]
print(f'Loaded {len(texts)} stories')

class SD(Dataset):

    def __init__(self, texts):
        self.data = []
        for t in texts:
            enc = tok(t, truncation=True, max_length=64, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
loader = DataLoader(SD(texts), batch_size=64, shuffle=True)
print(f'Steps per epoch: {len(loader)}')
opt = torch.optim.AdamW(kernel.parameters(), lr=0.0003)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=20, eta_min=1e-05)
best_score = -1
best_model = None
best_opt = None
WATCH = 'Once upon a time'

def gen(prompt):
    kernel.eval()
    ids = tok(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = kernel.generate(ids, max_new_tokens=40, do_sample=False, repetition_penalty=1.1, pad_token_id=tok.eos_token_id)
    return tok.decode(out[0], skip_special_tokens=True)

def quality(text):
    words = text.lower().split()
    if len(words) < 3:
        return 0.0
    alpha = sum((1 for w in words if w.isalpha()))
    if alpha < 2:
        return 0.0
    good = ['the', 'and', 'was', 'he', 'she', 'once', 'little', 'said', 'went', 'happy']
    gc = sum((1 for w in good if w in words))
    uniq = len(set(words)) / max(len(words), 1)
    alpha_ratio = alpha / len(words)
    return round(uniq * 0.3 + min(gc / 5, 1.0) * 0.4 + alpha_ratio * 0.3, 3)
print(f"\n{'Ep':>3}  {'Loss':>7}  {'Q':>5}  {'Time':>5}  Status")
print('─' * 45)
for ep in range(1, 21):
    kernel.train()
    total = 0
    t0 = time.time()
    for batch in loader:
        batch = batch.to(device)
        opt.zero_grad()
        loss = kernel(batch, labels=batch).loss
        loss.backward()
        nn.utils.clip_grad_norm_(kernel.parameters(), 1.0)
        opt.step()
        total += loss.item()
    sched.step()
    avg = total / len(loader)
    sec = time.time() - t0
    out = gen(WATCH)
    q = quality(out)
    if q > best_score:
        best_score = q
        best_model = {k: v.clone().cpu() for k, v in kernel.state_dict().items()}
        best_opt = {k: v if not isinstance(v, torch.Tensor) else v.clone() for k, v in opt.state_dict().items()}
        status = f'BEST {q:.3f} ✓'
    else:
        kernel.load_state_dict({k: v.to(device) for k, v in best_model.items()})
        opt.load_state_dict(best_opt)
        status = f'ROLLED BACK (best={best_score:.3f})'
    print(f'{ep:>3}  {avg:>7.4f}  {q:>5.3f}  {sec:>4.1f}s  {status}')
    print(f'     → {out[len(WATCH):][:80]}\n')
print(f'\nBest score: {best_score:.3f}')
kernel.load_state_dict(best_model)
_dir = os.path.dirname(os.path.abspath(__file__))
kernel.save_pretrained(os.path.join(_dir, 'tiny1m_stories'))
print('Saved.')
