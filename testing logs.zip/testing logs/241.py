import numpy as np
import math
import time
from collections import Counter, defaultdict
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v13 — DIRECT PROBABILITY KERNEL')
print('  W[context] = P(next|context). Exact. Instant.')
print('=' * 65)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do\n'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
print(f'\n  Vocab={VS}  Tokens={N}')
MAX_K = 6
print(f'\n  Building W-Kernel tables K=1..{MAX_K}...', end=' ', flush=True)
tables = {}
for K in range(1, MAX_K + 1):
    tables[K] = defaultdict(lambda: np.zeros(VS))
    for i in range(K, N):
        ctx = tuple(toks[i - K:i])
        tables[K][ctx][toks[i]] += 1
unigram = np.zeros(VS)
for t in toks:
    unigram[t] += 1
unigram_p = (unigram + 0.5) / (unigram + 0.5).sum()
SMOOTH = 0.1
kernel = {}
for K in range(1, MAX_K + 1):
    kernel[K] = {}
    for ctx, counts in tables[K].items():
        total = counts.sum()
        if total > 0:
            kernel[K][ctx] = (counts + SMOOTH) / (total + SMOOTH * VS)
print(f'done')
print(f'  Contexts seen: ' + ' | '.join((f'K={k}:{len(kernel[k])}' for k in range(1, MAX_K + 1))))
BACKOFF_THRESHOLD = 3

def predict(history):
    for K in range(MAX_K, 0, -1):
        if len(history) < K:
            continue
        ctx = tuple(history[-K:])
        if ctx in kernel[K]:
            count = tables[K][ctx].sum()
            if count >= BACKOFF_THRESHOLD:
                return kernel[K][ctx]
    return unigram_p
print(f'\n  Evaluating (leave-one-out)...', end=' ', flush=True)
nll = 0.0
n_eval = 0
for i in range(MAX_K, N):
    p = predict(toks[max(0, i - MAX_K):i])
    prob = max(p[toks[i]], 1e-10)
    nll += -math.log(prob)
    n_eval += 1
ppl_train = math.exp(nll / n_eval)
split = int(N * 0.8)
tables_train = {}
for K in range(1, MAX_K + 1):
    tables_train[K] = defaultdict(lambda: np.zeros(VS))
    for i in range(K, split):
        ctx = tuple(toks[i - K:i])
        tables_train[K][ctx][toks[i]] += 1
kernel_train = {}
for K in range(1, MAX_K + 1):
    kernel_train[K] = {}
    for ctx, counts in tables_train[K].items():
        total = counts.sum()
        if total > 0:
            kernel_train[K][ctx] = (counts + SMOOTH) / (total + SMOOTH * VS)

def predict_train(history):
    for K in range(MAX_K, 0, -1):
        if len(history) < K:
            continue
        ctx = tuple(history[-K:])
        if ctx in kernel_train[K]:
            if tables_train[K][ctx].sum() >= BACKOFF_THRESHOLD:
                return kernel_train[K][ctx]
    return unigram_p
nll_test = 0.0
n_test = 0
for i in range(split, N):
    p = predict_train(toks[max(0, i - MAX_K):i])
    prob = max(p[toks[i]], 1e-10)
    nll_test += -math.log(prob)
    n_test += 1
ppl_test = math.exp(nll_test / n_test)
print('done')
print(f'\n  Train ppl (full corpus): {ppl_train:.2f}')
print(f'  Test  ppl (held-out 20%): {ppl_test:.2f}  ratio={ppl_test / VS:.3f}')
print(f'  Vocab=28  Random=28  Unigram≈{math.exp(sum((-math.log(max(unigram_p[t], 1e-10)) for t in toks)) / N):.2f}')
print(f'\n  BIGRAM CHECK — W-Kernel K=1:')
for prev in ['t', 'h', 'e', ' ', 'a', 'o', 'n', 'd']:
    if prev not in c2i:
        continue
    ctx = (c2i[prev],)
    if ctx in kernel[1]:
        p = kernel[1][ctx]
        top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
        count = int(tables[1][ctx].sum())
        print(f"  after '{prev}' (n={count:4d}): {top3}")
print(f'\n  TRIGRAM CHECK — W-Kernel K=2:')
for bigram in ['th', 'he', 'in', 'on', 'an', 're']:
    ctx = tuple((c2i[c] for c in bigram if c in c2i))
    if len(ctx) == 2 and ctx in kernel[2]:
        p = kernel[2][ctx]
        top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
        count = int(tables[2][ctx].sum())
        print(f"  after '{bigram}' (n={count:3d}): {top3}")

def sample(p, temp=0.8, top_k=8):
    lg = np.log(np.maximum(p, 1e-10)) / temp
    if top_k < len(lg):
        thresh = np.sort(lg)[-top_k]
        lg[lg < thresh] = -10000000000.0
    pr = np.exp(lg - lg.max())
    pr /= pr.sum()
    return int(np.random.choice(VS, p=pr))

def generate(prompt, n=150, temp=0.8, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        p = predict(ids)
        ids.append(sample(p, temp=temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION:\n')
for temp in [0.8, 1.0]:
    print(f'  Temperature={temp}:')
    for prompt in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
        out = generate(prompt, temp=temp)
        print(f"  '{prompt}'")
        print(f'    {out[len(prompt):][:70]}')
    print()
gen_sp = generate('the ', n=400, temp=0.85)
space_pct = 100 * gen_sp[4:].count(' ') / len(gen_sp[4:])
cnt = Counter(gen_sp[4:])
top5 = [(c, f'{100 * cnt[c] // len(gen_sp[4:])}%') for c, _ in cnt.most_common(5)]
print(f'  Space% = {space_pct:.0f}%  (target ≈ 18%)')
print(f'  Top-5: {top5}')
print(f'  Sample: {gen_sp[4:84]}')
print(f'\n  Time: {time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  ppl(test)={ppl_test:.2f}  vocab={VS}  ratio={ppl_test / VS:.3f}')
if ppl_test < VS:
    print(f'  ✓ Sequence learning confirmed.')
    print(f"  ✓ Bigrams sharp (check 'after t: h=XX%' above)")
print(f'\n  W-KERNEL ALGORITHM (v13):')
print(f'  W[context] = P(next | context) — direct count.')
print(f'  Backoff: K=6 → K=5 → ... → K=1 → unigram.')
print(f'  No ridge. No bias corruption. No gradient.')
print(f'  Exact closed-form probability kernel.')
print('=' * 65 + '\n')
