import os, math
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
VS = 31
DA = 16
HA = 2
NLA = 2
KA = 6
DB = 64
HB = 4
NLB = 4
KB = 8
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()
tests = [('counting', [3, 4, 5, 6, 7, 8], 9), ('evens', [0, 2, 4, 6, 8, 10], 12), ('odds', [1, 3, 5, 7, 9, 11], 13), ('primes', [2, 3, 5, 7, 11, 13], 17), ('fibonacci', [2, 3, 5, 8, 13, 21], 3), ('threes', [0, 3, 6, 9, 12, 15], 18), ('fours', [0, 4, 8, 12, 16, 20], 24), ('countdown', [15, 14, 13, 12, 11, 10], 9)]
WA = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'num_small_weights.npz')).items()}
WB = {k: v.astype(np.float64) for k, v in np.load(os.path.join(_dir, 'num_large_weights.npz')).items()}

class ModelA(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, DA)
        self.wpe = nn.Embedding(KA, DA)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(DA), 'attn': nn.MultiheadAttention(DA, HA, batch_first=True), 'ln2': nn.LayerNorm(DA), 'ff': nn.Sequential(nn.Linear(DA, DA * 4), nn.GELU(), nn.Linear(DA * 4, DA))}) for _ in range(NLA)])
        self.ln_f = nn.LayerNorm(DA)

    def forward(self, ids):
        B, K = ids.shape
        pos = torch.arange(K, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def eval_model(model):
    model.eval()
    c = 0
    bar = []
    for name, seq, truth in tests:
        ids = torch.tensor([seq[-KA:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        c += p == truth
        bar.append('█' if p == truth else '░')
    return (c, ''.join(bar))

def gen_seqs():

    def primes_list(n):
        P = [2]
        i = 3
        while len(P) < n:
            if all((i % p for p in P)):
                P.append(i)
            i += 2
        return P
    fib = [1, 1]
    while len(fib) < 40:
        fib.append((fib[-1] + fib[-2]) % VS)
    seqs = {'counting': [i % VS for i in range(50)], 'evens': [i * 2 % VS for i in range(25)], 'odds': [(i * 2 + 1) % VS for i in range(25)], 'primes': [p % VS for p in primes_list(30)], 'fibonacci': fib, 'threes': [i * 3 % VS for i in range(17)], 'fours': [i * 4 % VS for i in range(13)], 'countdown': [(20 - i) % VS for i in range(40)]}
    Xs = []
    Ys = []
    for name, seq in seqs.items():
        for i in range(len(seq) - KA):
            Xs.append(seq[i:i + KA])
            Ys.append(seq[i + 1:i + KA + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))
ALL_X, ALL_Y = gen_seqs()

def train_and_checkpoint(init_wte, seed, steps=400):
    torch.manual_seed(seed)
    model = ModelA().to(device)
    for name, param in model.named_parameters():
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.zeros_(param)
    with torch.no_grad():
        model.wte.weight.copy_(torch.tensor(init_wte, dtype=torch.float32))
    opt = torch.optim.Adam(model.parameters(), lr=0.003)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    best_sc = 0
    best_step = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 10 == 0:
            sc, _ = eval_model(model)
            if sc > best_sc:
                best_sc = sc
                best_step = step
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            if best_sc == 8:
                break
    if best_state:
        model.load_state_dict(best_state)
    sc, bar = eval_model(model)
    return (sc, bar, best_step)

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def v16_formula(WTE_A, WTE_B, k):
    P = solve(WTE_B, WTE_A)
    WTE_B_proj = WTE_B @ P
    WTE_h = 0.5 * WTE_A + 0.5 * WTE_B_proj
    agree_d = np.sum(WTE_A * WTE_B_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    WTE_child = WTE_h.copy()
    WTE_child[:, flip_dims] *= -1
    return (WTE_child, flip_dims, agree_d)
print('=' * 65)
print('  SURGERY V16 — THE PROVEN LAW, RELIABILITY TEST')
print('  V14 found: wte_half+sign → 8/8, child > both parents')
print('  V15 found: flip TOP-k highest agree dims (not lowest)')
print('  V16 proves: is this a reliable law? 10/10?')
print('=' * 65)
WTE_A = WA['WTE']
WTE_B = WB['WTE']
P = solve(WTE_B, WTE_A)
WTE_B_proj = WTE_B @ P
agree_d = np.sum(WTE_A * WTE_B_proj, axis=0)
print(f'\n  Agreement per dim (all positive = all constructive):')
print(f'  {agree_d.round(3)}')
print(f'  min={agree_d.min():.3f}  max={agree_d.max():.3f}  all>0: {np.all(agree_d > 0)}')
top3 = np.argsort(agree_d)[-3:]
print(f'\n  Top-3 highest agreement dims: {top3.tolist()}')
print(f"  (V14 winner flipped: [4, 8, 15] — let's verify these match)")
SEEDS = list(range(10))
results = {}
print(f"\n{'─' * 65}")
print(f'  BASELINE — random D=16 init (no formula)')
print(f"{'─' * 65}")
rng = np.random.RandomState(0)
WTE_rand = rng.randn(VS, DA) * 0.02
baseline_scores = []
for seed in SEEDS:
    sc, bar, step = train_and_checkpoint(WTE_rand, seed)
    baseline_scores.append(sc)
    print(f'  seed {seed}: {sc}/8  {bar}  best@step{step}', flush=True)
results['Baseline (random)'] = baseline_scores
print(f"\n{'─' * 65}")
print(f'  PURE B PROJECTED (no flip)')
print(f"{'─' * 65}")
WTE_B16 = WTE_B_proj.copy()
pb_scores = []
for seed in SEEDS:
    sc, bar, step = train_and_checkpoint(WTE_B16, seed)
    pb_scores.append(sc)
    print(f'  seed {seed}: {sc}/8  {bar}  best@step{step}', flush=True)
results['Pure B projected'] = pb_scores
print(f"\n{'─' * 65}")
print(f'  HALF BLEND — 0.5A + 0.5B (no flip)')
print(f"{'─' * 65}")
WTE_half = 0.5 * WTE_A + 0.5 * WTE_B_proj
half_scores = []
for seed in SEEDS:
    sc, bar, step = train_and_checkpoint(WTE_half, seed)
    half_scores.append(sc)
    print(f'  seed {seed}: {sc}/8  {bar}  best@step{step}', flush=True)
results['Half blend (no flip)'] = half_scores
for k in [1, 2, 3, 4, 5, 6]:
    print(f"\n{'─' * 65}")
    print(f'  V16 k={k}  (flip top-{k} highest agreement dims)')
    WTE_v16, flip_dims, _ = v16_formula(WTE_A, WTE_B, k)
    print(f'  flip_dims: {flip_dims.tolist()}')
    print(f"{'─' * 65}")
    k_scores = []
    for seed in SEEDS:
        sc, bar, step = train_and_checkpoint(WTE_v16, seed)
        k_scores.append(sc)
        print(f'  seed {seed}: {sc}/8  {bar}  best@step{step}', flush=True)
    results[f'V16 k={k}'] = k_scores
print(f"\n{'=' * 65}")
print(f'  FINAL RELIABILITY TABLE (10 seeds each)')
print(f"{'=' * 65}")
print(f"\n  {'Method':>28}  8/8  7/8  6/8  mean  scores")
print(f"  {'─' * 62}")
for method, scores in results.items():
    s8 = sum((s == 8 for s in scores))
    s7 = sum((s >= 7 for s in scores))
    s6 = sum((s >= 6 for s in scores))
    mean = np.mean(scores)
    bar_scores = ''.join((str(s) for s in scores))
    print(f'  {method:>28}  {s8:>3}  {s7:>3}  {s6:>3}  {mean:.1f}  {bar_scores}')
best_method = max(results.items(), key=lambda x: (sum((s == 8 for s in x[1])), np.mean(x[1])))
print(f'\n  BEST METHOD: {best_method[0]}')
print(f'  8/8 count: {sum((s == 8 for s in best_method[1]))}/10')
print(f'  Mean score: {np.mean(best_method[1]):.2f}/8')
print(f'\n  THE LAW (V16):')
print(f'    P       = solve(WTE_B, WTE_A)')
print(f'    WTE_h   = 0.5*WTE_A + 0.5*WTE_B@P')
print(f'    agree_d = sum_i(WTE_A[i,d] * WTE_B_proj[i,d])')
print(f'    flip top-k dims by HIGHEST agree_d')
print(f'    train child + save best checkpoint')
print(f'\n  Parent A: 1/8  Parent B: 6/8  Child: {max((max(v) for v in results.values()))}/8')
print(f"\n  Is this a law? {('YES — 8/8 reached reliably' if sum((s == 8 for s in best_method[1])) >= 7 else 'PARTIAL — needs more investigation')}")
print('=' * 65)
