import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'EleutherAI/pythia-160m'
print(f'Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_hidden_layers
print(f'D={D} Heads={n_heads} Head_dim={head_dim} Layers={n_layers}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2(X, Y, split=0.8):
    n = len(X)
    s = int(n * split)
    Xf = X.astype(np.float32)
    Yf = Y.astype(np.float32)
    Xb = np.c_[Xf, np.ones(n, np.float32)]
    W = np.linalg.lstsq(Xb[:s], Yf[:s], rcond=None)[0]
    return r2(Xb[s:] @ W, Yf[s:])
starts = ['Once upon a time', 'The scientist looked at', 'In a distant future', 'The old library held many', 'A young programmer wrote', 'The mountain path led to', 'She opened the envelope and', 'The experiment failed because', 'He remembered the day when', 'The city never sleeps but', 'A child asked why the', 'The last star dimmed slowly', 'The river flowed through the', 'A dog sat quietly near', 'She found the key inside', 'The storm was coming fast']
print(f'Generating texts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.8, 1.0]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=25, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(all_texts)} texts.')
test_layers = [0, 2, 5, 8, 11]
print(f"\n{'=' * 70}")
print(f'  PYTHIA-160M LAW FINDER — OBSERVE NOT REPLICATE')
print(f"{'=' * 70}")
print(f"\n  {'Layer':<6} {'x→concat':<12} {'ln1→concat':<13} {'x→att':<12} {'gelu→ffn':<12} {'x→delta'}")
print(f"  {'─' * 65}")
for layer_idx in test_layers:
    block = model.gpt_neox.layers[layer_idx]
    cap = {}

    def h_concat(mod, inp, out):
        cap['concat'] = inp[0].detach().float()

    def h_att(mod, inp, out):
        cap['att'] = out[0].detach().float()

    def h_gelu(mod, inp, out):
        cap['gelu'] = out.detach().float()

    def h_ffn(mod, inp, out):
        cap['ffn'] = out.detach().float()
    hk = [block.attention.dense.register_forward_hook(h_concat), block.attention.dense.register_forward_hook(h_att), block.mlp.act.register_forward_hook(h_gelu), block.mlp.dense_4h_to_h.register_forward_hook(h_ffn)]
    X = []
    LN1 = []
    CONCAT = []
    ATT = []
    GELU = []
    FFN = []
    DELTA = []
    with torch.no_grad():
        for text in all_texts:
            toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
            L = toks['input_ids'].shape[1]
            if L < 4:
                continue
            out_m = model(**toks, output_hidden_states=True)
            hs = out_m.hidden_states
            x_np = hs[layer_idx][0].detach().float().numpy()
            x1_np = hs[layer_idx + 1][0].detach().float().numpy()
            delta_np = x1_np - x_np
            ln1_np = block.input_layernorm(hs[layer_idx][0]).detach().float().numpy()
            concat_np = cap['concat'][0].numpy()
            att_np = cap['att'][0].numpy()
            gelu_np = cap['gelu'][0].numpy()
            ffn_np = cap['ffn'][0].numpy()
            for t in range(L):
                X.append(x_np[t])
                LN1.append(ln1_np[t])
                CONCAT.append(concat_np[t])
                ATT.append(att_np[t])
                GELU.append(gelu_np[t])
                FFN.append(ffn_np[t])
                DELTA.append(delta_np[t])
    for hk_ in hk:
        hk_.remove()
    X = np.array(X)
    LN1 = np.array(LN1)
    CONCAT = np.array(CONCAT)
    ATT = np.array(ATT)
    GELU = np.array(GELU)
    FFN = np.array(FFN)
    DELTA = np.array(DELTA)
    r_xc = fit_r2(X, CONCAT)
    r_lc = fit_r2(LN1, CONCAT)
    r_xa = fit_r2(X, ATT)
    r_gf = fit_r2(GELU, FFN)
    r_xd = fit_r2(X, DELTA)

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {layer_idx:<6} {f(r_xc):<12} {f(r_lc):<13} {f(r_xa):<12} {f(r_gf):<12} {f(r_xd)}')
print(f"\n{'=' * 70}")
print('\n  WHAT EACH COLUMN MEANS:\n\n  x→concat:\n    Can raw input x predict what model feeds into Wo?\n    If 1.0: x is the natural space for attention.\n    If low:  need transformed x (ln1, etc.)\n\n  ln1→concat:\n    Can layernorm(x) predict concat?\n    If better than x→concat:\n      LayerNorm is part of natural space.\n      ln1(x) is the correct input feature.\n\n  x→att:\n    Can x predict full attention output directly?\n    Skips the per-head decomposition entirely.\n    If 1.0: attention is just a linear map from x.\n\n  gelu→ffn:\n    FFN law from TinyStories. Does it hold here?\n    Expected 1.0 at token level.\n\n  x→delta:\n    Can x predict full block transformation?\n    If 1.0: entire block is linear in x.\n    This is the kernel question.\n\n  READING THE RESULTS:\n    High x→att means: attention = linear map.\n    High ln1→concat means: natural space = ln1(x).\n    High gelu→ffn means: FFN law universal.\n    High x→delta means: block is linear in x.\n')
print('=' * 70 + '\n')
