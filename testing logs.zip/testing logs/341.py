import subprocess, sys, time, random

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import Counter, defaultdict
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (LSH FUZZY HASH)')
print('  Combining O(1) Speed with Fuzzy Logic via Random Projections.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
JUMP_LENGTH = 3
UNIVERSAL_QUORUM = n_layers // 2 + 1
NUM_PROJECTIONS = 8
BITS_PER_PROJ = 16
SIG_SIZE = 4 * D
print(f'  Architecture: {n_layers} Layers | {D} Key-Dim | {SIG_SIZE}-bit Atlas Window')
PROJECTION_INDICES = [random.sample(range(SIG_SIZE), BITS_PER_PROJ) for _ in range(NUM_PROJECTIONS)]

def get_lsh_keys(bit_vector):
    keys = []
    for indices in PROJECTION_INDICES:
        key = tuple(bit_vector[indices].tolist())
        keys.append(key)
    return keys
print('\n  [ Phase 1 ] Building LSH Atlas (Random Projections)...')
set_a_prompts = ['Once upon a time, a little girl named Lucy', 'The brave knight took his sword', 'He was so happy that he found', 'She wanted to climb the tree', 'One day she was playing in the park', 'It was a big scary noise', 'Lucy was scared and ran back', "Don't worry Lucy I will help", 'Lucy and her mom went to the tree', 'She said thank you mommy', 'There was a big shiny object on the ground', 'The butterfly flew over the garden']
RAM_LSH = {l: [defaultdict(list) for _ in range(NUM_PROJECTIONS)] for l in range(n_layers)}
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_key = {l: [] for l in range(n_layers)}

def hook_key(l):

    def hook(m, i, o):
        store_key[l].append((o[:, -1, :] > 0).detach().cpu().numpy().astype(int))
    return hook
hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(hook_key(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        window_history = {l: [] for l in range(n_layers)}
        for _ in range(40):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                k_bits = store_key[l].pop()[0]
                window_history[l].append(k_bits)
                if len(window_history[l]) > 4:
                    window_history[l].pop(0)
                if len(window_history[l]) == 4:
                    atlas_sig = np.concatenate(window_history[l])
                    idx = len(RAM_sequences[l])
                    RAM_chains[l].append(atlas_sig)
                    RAM_sequences[l].append(next_id)
                    for proj_id, h_key in enumerate(get_lsh_keys(atlas_sig)):
                        RAM_LSH[l][proj_id][h_key].append(idx)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM_chains[l] = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = [tuple(tokens[i:i + JUMP_LENGTH].tolist()) for i in range(len(tokens) - JUMP_LENGTH)]
    RAM_sequences[l] = seqs
print(f'  ✓ Saturated {len(RAM_sequences[0])} paths into LSH projection tables.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 60
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] THE RACE: BASELINE vs. LSH ATLAS')
print('─' * 75)
print('  Generating Baseline Truth...')
baseline_ids = tokenizer.encode(test_prompt, return_tensors='pt')
with torch.no_grad():
    for _ in range(tokens_to_gen):
        out = model(baseline_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        baseline_ids = torch.cat([baseline_ids, torch.tensor([[next_id]])], dim=1)
baseline_text = tokenizer.decode(baseline_ids[0])
print('  Executing LSH Engine (Fuzzy + O(1))...')
atlas_history = {l: [] for l in range(n_layers)}
live_key = {l: None for l in range(n_layers)}

def get_key_hook(l):

    def hook(m, i, o):
        live_key[l] = (o[:, -1, :] > 0).detach().cpu().numpy().astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(get_key_hook(l)) for l in range(n_layers)]
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen = 0
jumps_done = 0
start_time = time.time()
with torch.no_grad():
    while total_gen < tokens_to_gen:
        out = model(hub_ids)
        probs = torch.nn.functional.softmax(out.logits[0, -1, :], dim=-1)
        top_probs, top_indices = torch.topk(probs, 2)
        confidence_margin = top_probs[0].item() - top_probs[1].item()
        truth_id = top_indices[0].item()
        for l in range(n_layers):
            atlas_history[l].append(live_key[l])
            if len(atlas_history[l]) > 4:
                atlas_history[l].pop(0)
        jump_found = False
        if confidence_margin > 0.4 and len(atlas_history[0]) == 4:
            votes = []
            for l in range(n_layers):
                current_sig = np.concatenate(atlas_history[l])
                candidate_indices = set()
                for proj_id, h_key in enumerate(get_lsh_keys(current_sig)):
                    if h_key in RAM_LSH[l][proj_id]:
                        candidate_indices.update(RAM_LSH[l][proj_id][h_key])
                if not candidate_indices:
                    continue
                candidates = RAM_chains[l][list(candidate_indices)]
                mismatches = SIG_SIZE - np.sum(candidates == current_sig, axis=1)
                best_match_local_idx = np.argmin(mismatches)
                if mismatches[best_match_local_idx] <= SIG_SIZE * 0.1:
                    global_idx = list(candidate_indices)[best_match_local_idx]
                    if global_idx < len(RAM_sequences[l]):
                        votes.append(RAM_sequences[l][global_idx])
            if votes:
                vote_counts = Counter(votes)
                top_sequence, count = vote_counts.most_common(1)[0]
                if count >= UNIVERSAL_QUORUM and top_sequence[0] == truth_id:
                    hub_ids = torch.cat([hub_ids, torch.tensor([list(top_sequence)])], dim=1)
                    print(f'\x1b[92m{tokenizer.decode(list(top_sequence))}\x1b[0m', end='', flush=True)
                    for layer in range(n_layers):
                        atlas_history[layer] = []
                    total_gen += JUMP_LENGTH
                    jumps_done += 1
                    jump_found = True
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            print(tokenizer.decode([truth_id]), end='', flush=True)
            total_gen += 1
for h in live_hooks:
    h.remove()
hub_time = time.time() - start_time
hub_text = tokenizer.decode(hub_ids[0])
print('\n' + '=' * 75)
print('  LSH ENDURANCE VERDICT')
print('=' * 75)
print(f'  Execution Time   : {hub_time:.4f}s')
print(f'  Successful Jumps : {jumps_done}')
b_words, h_words = (baseline_text.split(), hub_text.split())
matches = sum((1 for a, b in zip(b_words, h_words) if a == b))
match_pct = matches / len(b_words) * 100 if b_words else 0
print(f'  Word Match Score : {matches} / {len(b_words)} ({match_pct:.1f}%)')
print('\n  LSH PHYSICS:')
print('  Fixed the IndexError by dynamically calculating SIG_SIZE.')
print('  The engine now correctly maps the 64-dim Keys into the')
print('  256-bit Atlas window for the TinyStories-1M model.')
print('=' * 75 + '\n')
