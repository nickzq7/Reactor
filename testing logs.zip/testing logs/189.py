import numpy as np
print('\n' + '=' * 62)
print('  W — ATTENTION RULE FINDER')
print('  89% already linear. Find rule for 11%.')
print('  Natural space of matrix multiplication.')
print('=' * 62)
np.random.seed(42)
N = 3000
N_tr = 2400
D = 8
L = 4

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ RULE FOUND' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<52} {mark}')
    return score

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
Wq = np.random.randn(D, D) * 0.3
Wk = np.random.randn(D, D) * 0.3
Wv = np.random.randn(D, D) * 0.3
X_seqs = np.random.randn(N, L, D)
att_all = np.zeros((N, L, L))
V_all = np.zeros((N, L, D))
out_all = np.zeros((N, L, D))
for i in range(N):
    x = X_seqs[i]
    Q = x @ Wq
    K = x @ Wk
    V = x @ Wv
    scr = Q @ K.T / np.sqrt(D)
    msk = np.triu(np.full((L, L), -1000000000.0), 1)
    att = softmax(scr + msk)
    att_all[i] = att
    V_all[i] = V
    out_all[i] = att @ V
X_flat = X_seqs.reshape(N, L * D)
att_flat = att_all.reshape(N, L * L)
V_flat = V_all.reshape(N, L * D)
Y_flat = out_all.reshape(N, L * D)
print('\n' + '─' * 62)
print('  PART 1 — ISOLATE THE MIXING OPERATION')
print('  Given att (known) and V (known): find out = att @ V')
print('  What is the rule for matrix multiplication?')
print('─' * 62)
print()
test(X_flat[:N_tr], Y_flat[:N_tr], X_flat[N_tr:], Y_flat[N_tr:], 'raw x')
test(V_flat[:N_tr], Y_flat[:N_tr], V_flat[N_tr:], Y_flat[N_tr:], 'V alone (linear part)')
test(np.column_stack([att_flat, V_flat])[:N_tr], Y_flat[:N_tr], np.column_stack([att_flat, V_flat])[N_tr:], Y_flat[N_tr:], 'att + V (concatenated)')
outer = np.einsum('nts,nsd->ntsd', att_all, V_all).reshape(N, L * L * D)
test(outer[:N_tr], Y_flat[:N_tr], outer[N_tr:], Y_flat[N_tr:], 'att[t,s]*V[s,d] outer product (correct)')
test(Y_flat[:N_tr], Y_flat[:N_tr], Y_flat[N_tr:], Y_flat[N_tr:], 'out itself (trivial)')
print('\n' + '─' * 62)
print('  PART 2 — FIND RULE WITHOUT KNOWING att EXPLICITLY')
print('  W must derive att from x itself.')
print('  What features of x capture the mixing?')
print('─' * 62)
print()
Q_all = np.einsum('nld,de->nle', X_seqs, Wq).reshape(N, L * D)
K_all = np.einsum('nld,de->nle', X_seqs, Wk).reshape(N, L * D)
test(np.column_stack([Q_all, K_all, V_flat])[:N_tr], Y_flat[:N_tr], np.column_stack([Q_all, K_all, V_flat])[N_tr:], Y_flat[N_tr:], 'Q + K + V (all linear projections)')
qk_scores = np.einsum('nld,nmd->nlm', X_seqs @ Wq, X_seqs @ Wk).reshape(N, L * L) / np.sqrt(D)
test(np.column_stack([qk_scores, V_flat])[:N_tr], Y_flat[:N_tr], np.column_stack([qk_scores, V_flat])[N_tr:], Y_flat[N_tr:], 'QK scores + V')
test(np.column_stack([att_flat, V_flat])[:N_tr], Y_flat[:N_tr], np.column_stack([att_flat, V_flat])[N_tr:], Y_flat[N_tr:], 'softmax(QK) + V')
test(outer[:N_tr], Y_flat[:N_tr], outer[N_tr:], Y_flat[N_tr:], 'softmax(QK)[t,s] * V[s,d]  [outer product]')
print('\n' + '─' * 62)
print('  PART 3 — PURE MATRIX MULTIPLY RULE')
print('  f(A,B) = A@B.  What is its natural space?')
print('  Test with random A,B (no attention structure)')
print('─' * 62)
print()
A = softmax(np.random.randn(N, L, L))
B = np.random.randn(N, L, D)
C = np.einsum('nij,njk->nik', A, B)
A_flat = A.reshape(N, L * L)
B_flat = B.reshape(N, L * D)
C_flat = C.reshape(N, L * D)
test(np.column_stack([A_flat, B_flat])[:N_tr], C_flat[:N_tr], np.column_stack([A_flat, B_flat])[N_tr:], C_flat[N_tr:], 'A + B (concatenated)')
outer2 = np.einsum('nij,njk->nijk', A, B).reshape(N, L * L * D)
test(outer2[:N_tr], C_flat[:N_tr], outer2[N_tr:], C_flat[N_tr:], 'A[i,j]*B[j,k] outer product [matmul rule]')
print('\n' + '=' * 62)
print('  WHAT RESULTS SHOW')
print('=' * 62)
print('\n  Attention = two operations:\n    V   = x @ Wv              (linear — trivial)\n    out = softmax(QK) @ V     (matrix multiply)\n\n  Matrix multiply rule:\n    f(A,B) = A@B\n    Natural space = A[i,j]*B[j,k] for all i,j,k\n    This is the outer product space.\n    If R²=1.0 → rule confirmed.\n    If not → attention mixing has deeper structure.\n\n  Key observation:\n    Softmax, Relu, LayerNorm all had clean rules.\n    Attention mixing may be different.\n    May require recursive rule application.\n    Softmax rule applied to QK space.\n    Then outer product rule applied to result.\n    Rules compose — like the universe.\n    Each law applies in its own domain.\n    Together they make the whole.\n')
print('=' * 62 + '\n')
