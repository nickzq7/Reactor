import numpy as np
import torch
import torch.nn as nn
import time
import itertools
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def make_data(n=3000):
    X, Y = ([], [])
    for i in range(1, n):
        x = i / n
        X.append(x)
        Y.append(np.sin(x * 2 * np.pi) * 0.5 + 0.5)
        X.append(x)
        Y.append(x ** 2)
        X.append(x)
        Y.append(x * (1 - x))
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32).unsqueeze(1)
    Yt = torch.tensor([a[1] for a in arr], dtype=torch.float32).unsqueeze(1)
    return (Xt, Yt)
X, Y = make_data()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Data: {len(X)} samples')

class Net(nn.Module):

    def __init__(self, dim, numbers=None):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(1, dim), nn.Tanh(), nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, 1))
        if numbers is not None:
            self._init_from_numbers(numbers)

    def _init_from_numbers(self, numbers):
        arr = np.array(numbers, dtype=np.float32)
        mx = np.max(np.abs(arr))
        if mx > 0:
            arr = arr / mx
        W = torch.tensor(arr, dtype=torch.float32).unsqueeze(1)
        with torch.no_grad():
            self.net[0].weight.copy_(W)

    def forward(self, x):
        return self.net(x)

def train(model, epochs=500, lr=0.01):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    best = 9999.0
    for ep in range(epochs):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        opt.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
    return best
print(f"\n{'=' * 65}")
print('  BASELINE: 256-dim flat')
print(f"{'=' * 65}")
baseline_model = Net(256).to(device)
BASELINE = train(baseline_model, epochs=500)
print(f'  256-dim flat loss: {BASELINE:.6f}')

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(500)
DIM = 16

def combinations_to_try():
    combos = []
    for start in range(0, 30):
        nums = ALL_PRIMES[start:start + DIM]
        if len(nums) == DIM:
            combos.append((f'first16_from_p{ALL_PRIMES[start]}', nums))
    for step in range(1, 8):
        nums = ALL_PRIMES[::step][:DIM]
        if len(nums) == DIM:
            combos.append((f'every_{step}th_prime', nums))
    gaps = [ALL_PRIMES[i + 1] - ALL_PRIMES[i] for i in range(len(ALL_PRIMES) - 1)]
    combos.append(('prime_gaps_16', gaps[:DIM]))
    combos.append(('prime_squares', [p ** 2 for p in ALL_PRIMES[:DIM]]))
    combos.append(('prime_sqrts', [p ** 0.5 for p in ALL_PRIMES[:DIM]]))
    combos.append(('prime_logs', [np.log(p) for p in ALL_PRIMES[:DIM]]))
    twins = []
    for i in range(len(ALL_PRIMES) - 1):
        if ALL_PRIMES[i + 1] - ALL_PRIMES[i] == 2:
            twins.append(ALL_PRIMES[i])
            twins.append(ALL_PRIMES[i + 1])
    twins = list(dict.fromkeys(twins))
    if len(twins) >= DIM:
        combos.append(('twin_primes', twins[:DIM]))
    fibs = [1, 1]
    while len(fibs) < DIM:
        fibs.append(fibs[-1] + fibs[-2])
    combos.append(('fibonacci', fibs[:DIM]))
    pf = []
    for i in range(DIM // 2):
        pf.append(ALL_PRIMES[i])
        pf.append(fibs[i])
    combos.append(('prime+fib_interleaved', pf[:DIM]))
    mod6 = [p % 6 for p in ALL_PRIMES[:DIM * 3]]
    combos.append(('prime_mod6', mod6[:DIM]))
    mod7 = [p % 7 for p in ALL_PRIMES[:DIM * 3]]
    combos.append(('prime_mod7', mod7[:DIM]))
    diffs = [p - 2 for p in ALL_PRIMES[:DIM]]
    combos.append(('prime_diffs_from2', diffs))
    cum = [0]
    for i in range(len(ALL_PRIMES) - 1):
        cum.append(cum[-1] + (ALL_PRIMES[i + 1] - ALL_PRIMES[i]))
    combos.append(('cumulative_gaps', cum[:DIM]))
    np.random.seed(0)
    for trial in range(1000):
        np.random.seed(trial * 7 + 13)
        idx = np.random.choice(len(ALL_PRIMES), DIM, replace=False)
        nums = [ALL_PRIMES[i] for i in sorted(idx)]
        combos.append((f'random_subset_{trial}', nums))
    for start in range(5):
        for step in range(1, 10):
            nums = [ALL_PRIMES[start + i * step] for i in range(DIM) if start + i * step < len(ALL_PRIMES)]
            if len(nums) == DIM:
                combos.append((f'arith_prog_s{start}_d{step}', nums))
    combos.append(('powers_of_2', [2 ** i for i in range(DIM)]))
    for scale in [1, 2, 3, 5, 7]:
        nums = [ALL_PRIMES[i % 8] * scale for i in range(DIM)]
        combos.append((f'small8_primes_x{scale}', nums))
    return combos
all_combos = combinations_to_try()
print(f"\n{'=' * 65}")
print(f'  PRIME COMBINATION SEARCH')
print(f'  Total combinations to try: {len(all_combos)}')
print(f'  Baseline to beat: {BASELINE:.6f}')
print(f"{'=' * 65}\n")
results = []
beaten = 0
t0 = time.time()
TOTAL = len(all_combos)
for i, (name, numbers) in enumerate(all_combos):
    if len(numbers) != DIM:
        continue
    m = Net(DIM, numbers=numbers).to(device)
    loss = train(m, epochs=500, lr=0.01)
    results.append((loss, name, numbers))
    if loss < BASELINE:
        beaten += 1
    if (i + 1) % 100 == 0:
        results.sort(key=lambda x: x[0])
        elapsed = time.time() - t0
        eta = elapsed / (i + 1) * (TOTAL - i - 1)
        print(f'  [{i + 1:>4}/{TOTAL}]  beaten={beaten}  best={results[0][0]:.6f}  baseline={BASELINE:.6f}  eta={eta:.0f}s')
results.sort(key=lambda x: x[0])
print(f"\n{'=' * 65}")
print(f'  FINAL RESULTS')
print(f"{'=' * 65}")
print(f'  256-dim flat      : {BASELINE:.6f}')
print(f'  Combinations tried: {TOTAL}')
print(f'  Beat baseline     : {beaten}')
print(f'\n  TOP 10 PRIME COMBINATIONS:')
print(f"  {'#':>3}  {'Loss':>10}  {'Gap':>10}  Name")
print(f"  {'─' * 60}")
for i, (loss, name, numbers) in enumerate(results[:10]):
    tag = ' ✓' if loss < BASELINE else ''
    gap = BASELINE - loss
    print(f'  {i + 1:>3}  {loss:>10.6f}  {gap:>+10.6f}  {name}{tag}')
    print(f"       Numbers: {numbers[:8]}{('...' if len(numbers) > 8 else '')}")
if results:
    best_loss, best_name, best_numbers = results[0]
    print(f"\n{'=' * 65}")
    print(f'  WINNER: {best_name}')
    print(f'  Numbers: {best_numbers}')
    print(f'  Loss: {best_loss:.6f}  (baseline={BASELINE:.6f})')
    gap = BASELINE - best_loss
    if gap > 0:
        print(f'  Beat baseline by: {gap:.6f}')
        print(f'\n  ✓ FOUND MOST POWERFUL PRIME GEOMETRY')
        print(f'  These {DIM} numbers encode the fundamental structure')
    print(f'\n  Total time: {time.time() - t0:.1f}s')
