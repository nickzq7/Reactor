import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W-NATIVE SEMANTIC RAM (DEEP DIAGNOSTIC)')
print('  Measuring GeLU Overlap at Layer 7 (Abstract Meaning).')
print('=' * 62)
print('\n  Loading TinyStories-1M...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
vocab_size = model.config.vocab_size
TARGET_LAYER = model.config.num_layers - 1
print(f'  Extracting Deep Semantic GeLU Gates from Layer {TARGET_LAYER}...')
store = {}

def hook_pre_gelu(m, i, o):
    store['pre'] = o.detach().cpu().numpy()
h = model.transformer.h[TARGET_LAYER].mlp.c_fc.register_forward_hook(hook_pre_gelu)
batch_size = 2000
all_bits = []
with torch.no_grad():
    for start in range(0, vocab_size, batch_size):
        end = min(start + batch_size, vocab_size)
        ids = torch.arange(start, end).unsqueeze(1)
        model(ids)
        pre_gelu = store['pre'].squeeze(1)
        bits = (pre_gelu > 0).astype(int)
        all_bits.append(bits)
h.remove()
binary_space = np.concatenate(all_bits, axis=0)
print(f'  Successfully extracted {vocab_size} deep memory addresses.')
print('\n' + '─' * 62)
print('  DEEP SEMANTIC BIT-OVERLAP TEST')
print('─' * 62)
test_words = ['king', 'boy', 'dog', 'happy', 'house']

def find_bitwise_neighbors(target_word, top_k=8):
    token_id = tokenizer.encode(target_word)[0]
    target_bits = binary_space[token_id]
    matches = np.sum(binary_space == target_bits, axis=1)
    best_indices = np.argsort(matches)[::-1]
    neighbors = []
    seen = set([target_word.lower().strip()])
    for idx in best_indices:
        word = tokenizer.decode([idx]).strip()
        if not word.isalpha() or len(word) < 2:
            continue
        word_lower = word.lower()
        if word_lower not in seen and target_word.lower() not in word_lower:
            overlap_count = matches[idx]
            overlap_pct = overlap_count / 256.0 * 100
            neighbors.append((word, overlap_count, overlap_pct))
            seen.add(word_lower)
        if len(neighbors) >= top_k:
            break
    return neighbors
for target in test_words:
    print(f"  Target: '{target}'")
    neighbors = find_bitwise_neighbors(target)
    for word, count, pct in neighbors:
        print(f'    -> {word:<10} | Shared Gates: {count}/256 ({pct:.1f}%)')
    print()
print('=' * 62)
print("\n  DIAGNOSTIC CONCLUSION:\n  By moving to Layer 7, we bypass spelling/syntax and read \n  the true abstract concepts. \n  \n  Does 'king' finally cluster with related deep concepts?\n")
print('=' * 62 + '\n')
