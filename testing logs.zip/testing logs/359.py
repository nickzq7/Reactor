import numpy as np
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64)
    true = np.array(true, dtype=np.float64)
    if true.ndim == 1:
        true = true.reshape(-1, 1)
    if pred.ndim == 1:
        pred = pred.reshape(-1, 1)
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 1e-10 else 1.0

def fit_W(X, Y):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.c_[X64, np.ones(len(X64))]
    W = np.linalg.lstsq(Xb, Y64, rcond=None)[0]
    return W.astype(np.float32)
prompts = ['Once upon a time there was a little girl who loved to', 'Once upon a time there was a small boy who liked to', 'Once upon a time there was a young rabbit who wanted to', 'The dog ran into the dark forest and found a', 'She looked at the stars and felt very', 'The mathematics teacher asked the students to', 'He picked up the heavy stone and threw it', 'A small bird flew over the big river and', 'The old man walked slowly to the market and', 'She opened the door and saw a beautiful', 'The children played in the garden until the', 'Once upon a time there was a tiny mouse who', 'In the deep forest there lived a wise old', 'The princess looked out the window and saw a', 'He ran as fast as he could to reach the', 'The mother called out to her child who was', 'A young fox played near the river every', 'The baby smiled at the colorful toy and', 'She found a small box under the old', 'The brave knight rode through the dark']
h7_buf = []
lnf_buf = []
correct_toks = []
hooks = []

def hook_h7(m, inp, out):
    x = inp[0].detach().float()
    h7_buf.append(x[0, -1].numpy().copy())

def hook_lnf(m, inp, out):
    x = out.detach().float()
    lnf_buf.append(x[0, -1].numpy().copy())
hooks.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_h7))
hooks.append(model.transformer.ln_f.register_forward_hook(hook_lnf))
print(f'\nCollecting attractor states from {len(prompts)} prompts...')
with torch.no_grad():
    for prompt in prompts:
        toks = tokenizer(prompt, return_tensors='pt', max_length=64, truncation=True)
        out = model(**toks)
        next_tok = int(torch.argmax(out.logits[0, -1, :]).item())
        correct_toks.append(next_tok)
for h in hooks:
    h.remove()
H7 = np.array(h7_buf, dtype=np.float32)
LNF = np.array(lnf_buf, dtype=np.float32)
print(f'Attractor states: {H7.shape}')
print(f'ln_f outputs:     {LNF.shape}')
print(f"\n{'=' * 60}")
print(f'  TEST 2.1 — ln_f decompression law')
print(f'  h7 (attractor) → ln_f_out = linear? R²=?')
print(f"{'=' * 60}")
n = len(H7)
s = int(n * 0.8)
W_lnf = fit_W(H7[:s], LNF[:s])
Xb = np.c_[H7, np.ones(n)]
r2_lnf_train = r2(Xb[:s] @ W_lnf, LNF[:s])
r2_lnf_test = r2(Xb[s:] @ W_lnf, LNF[s:])
print(f'\n  h7 → ln_f_out R² train: {r2_lnf_train:.6f}')
print(f'  h7 → ln_f_out R² test:  {r2_lnf_test:.6f}')
marker = '✓ LINEAR LAW' if r2_lnf_test > 0.999 else '~ NEAR' if r2_lnf_test > 0.95 else '? PARTIAL'
print(f'  {marker}')
h7_std = np.std(H7)
lnf_std = np.std(LNF)
print(f'\n  h7 std:    {h7_std:.4f}')
print(f'  ln_f std:  {lnf_std:.4f}')
print(f'  Expansion: {lnf_std / h7_std:.4f}x')
print(f"  {('DECOMPRESSES (expands)' if lnf_std > h7_std else 'COMPRESSES further')}")
print(f"\n{'=' * 60}")
print(f'  TEST 2.2 — Attractor → answer direct')
print(f'  Can h7 predict correct token without ln_f?')
print(f"{'=' * 60}")
lm_weight = model.lm_head.weight.detach().float().numpy()
ln_f_w = model.transformer.ln_f.weight.detach().float().numpy()
ln_f_b = model.transformer.ln_f.bias.detach().float().numpy()

def layernorm_np(x, w, b, eps=1e-05):
    mu = np.mean(x)
    std = np.std(x) + eps
    return (x - mu) / std * w + b
correct = 0
correct_skip = 0
N_test = len(H7)
for i in range(N_test):
    lnf_out = layernorm_np(H7[i], ln_f_w, ln_f_b)
    logits = lnf_out @ lm_weight.T
    pred_norm = int(np.argmax(logits))
    logits_skip = H7[i] @ lm_weight.T
    pred_skip = int(np.argmax(logits_skip))
    if pred_norm == correct_toks[i]:
        correct += 1
    if pred_skip == correct_toks[i]:
        correct_skip += 1
print(f'\n  Normal (h7→ln_f→lm_head):    {correct}/{N_test} = {correct / N_test:.1%}')
print(f'  Skip   (h7→lm_head directly): {correct_skip}/{N_test} = {correct_skip / N_test:.1%}')
print(f"\n  {('ln_f is essential (large gap)' if correct - correct_skip > 3 else 'ln_f adds small correction' if correct > correct_skip else 'ln_f makes no difference')}")
top5_norm = 0
top5_skip = 0
for i in range(N_test):
    lnf_out = layernorm_np(H7[i], ln_f_w, ln_f_b)
    top5_n = np.argsort(lnf_out @ lm_weight.T)[-5:]
    top5_s = np.argsort(H7[i] @ lm_weight.T)[-5:]
    if correct_toks[i] in top5_n:
        top5_norm += 1
    if correct_toks[i] in top5_s:
        top5_skip += 1
print(f'\n  Top-5 normal: {top5_norm}/{N_test} = {top5_norm / N_test:.1%}')
print(f'  Top-5 skip:   {top5_skip}/{N_test} = {top5_skip / N_test:.1%}')
print(f'\n  Sample predictions:')
print(f"  {'Prompt[:30]':<32} {'Correct':<15} {'Normal':<15} {'Skip ln_f'}")
print(f"  {'─' * 75}")
for i in range(min(8, N_test)):
    c_tok = tokenizer.decode([correct_toks[i]])
    lnf_out = layernorm_np(H7[i], ln_f_w, ln_f_b)
    n_tok = tokenizer.decode([int(np.argmax(lnf_out @ lm_weight.T))])
    s_tok = tokenizer.decode([int(np.argmax(H7[i] @ lm_weight.T))])
    p_str = prompts[i][:30]
    print(f'  {p_str:<32} {repr(c_tok):<15} {repr(n_tok):<15} {repr(s_tok)}')
print(f"\n{'=' * 60}")
print(f'  TEST 2.3 — Attractor stability')
print(f'  Same prompt × 5 runs = same h7?')
print(f"{'=' * 60}")
stability_prompt = 'Once upon a time there was a little girl who loved to'
h7_runs = []
hook2 = []

def hook_h7_stab(m, inp, out):
    x = inp[0].detach().float()
    h7_runs.append(x[0, -1].numpy().copy())
hook2.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_h7_stab))
with torch.no_grad():
    for run in range(5):
        toks = tokenizer(stability_prompt, return_tensors='pt')
        model(**toks)
for h in hook2:
    h.remove()
H_runs = np.array(h7_runs)
run_std = float(np.mean(np.std(H_runs, axis=0)))
run_mean = float(np.mean(np.linalg.norm(H_runs, axis=1)))
print(f'\n  h7 across 5 runs of same prompt:')
print(f'  Mean norm:  {run_mean:.6f}')
print(f'  Std:        {run_std:.8f}')
print(f"  Stability:  {('PERFECT ATTRACTOR (zero variance)' if run_std < 1e-06 else 'STABLE' if run_std < 0.001 else 'UNSTABLE')}")
print(f"\n{'=' * 60}")
print(f'  TEST 2.4 — Attractor dimension (PCA)')
print(f'  64-dim h. How many dims hold 99% of variance?')
print(f'  Low = attractor is small subspace = efficient coordinate.')
print(f"{'=' * 60}")
h7_pca = []
hook3 = []

def hook_h7_pca(m, inp, out):
    x = inp[0].detach().float()
    for t in range(x.shape[1]):
        h7_pca.append(x[0, t].numpy().copy())
hook3.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_h7_pca))
extra_prompts = prompts + ['The sun rose over the mountain and', 'She whispered to her friend that', 'The little cat sat on the warm', 'He could not find his favorite', 'The wind blew the leaves across', 'A butterfly landed on the flower and', 'The teacher smiled at the young', 'He woke up early in the morning']
with torch.no_grad():
    for p in extra_prompts:
        toks = tokenizer(p, return_tensors='pt', max_length=32, truncation=True)
        model(**toks)
for h in hook3:
    h.remove()
H_pca = np.array(h7_pca, dtype=np.float32)
print(f'\n  PCA on {H_pca.shape[0]} attractor samples...')
H_centered = H_pca - H_pca.mean(axis=0)
U, S, Vt = np.linalg.svd(H_centered, full_matrices=False)
variance_explained = S ** 2 / (S ** 2).sum()
cumvar = np.cumsum(variance_explained)
dims_90 = int(np.searchsorted(cumvar, 0.9)) + 1
dims_95 = int(np.searchsorted(cumvar, 0.95)) + 1
dims_99 = int(np.searchsorted(cumvar, 0.99)) + 1
dims_999 = int(np.searchsorted(cumvar, 0.999)) + 1
print(f'\n  Dims for 90%  variance: {dims_90}/{D}')
print(f'  Dims for 95%  variance: {dims_95}/{D}')
print(f'  Dims for 99%  variance: {dims_99}/{D}')
print(f'  Dims for 99.9% variance:{dims_999}/{D}')
print(f'\n  Top 10 singular values (variance explained):')
for i in range(min(10, len(S))):
    bar = '█' * int(variance_explained[i] * 100)
    print(f'  dim {i + 1:2d}: {variance_explained[i]:.4f}  {bar}')
print(f'\n  Attractor intrinsic dimension: ~{dims_99} of {D} total')
compression = D / dims_99
print(f'  Compression vs full space: {compression:.1f}x')
print(f"  {('SMALL ATTRACTOR: high compression' if compression > 3 else 'MODERATE ATTRACTOR' if compression > 1.5 else 'LARGE ATTRACTOR: low compression')}")
print(f"\n{'=' * 60}")
print(f'  TEST 2 COMPLETE SUMMARY')
print(f"{'=' * 60}")
print(f'\n  HIDDEN LAW 1 — ATTENTION ATTRACTOR:\n\n  Entropy convergence:    CONFIRMED ✓  (-0.0135/layer)\n  h std convergence:      CONFIRMED ✓  (-0.007857/layer)\n  Distance convergence:   CONFIRMED ✓  (-0.1198/layer)\n  Semantic clustering:    CONFIRMED ✓  (ratio=0.45)\n\n  ln_f law:               R²={r2_lnf_test:.4f}\n  Attractor→answer:       {correct}/{N_test} = {correct / N_test:.1%}\n  Attractor stability:    std={run_std:.2e}\n  Attractor dimension:    ~{dims_99}/{D} dims for 99% variance\n\n  PICTURE:\n    Layers 0→7:  compress input toward attractor.\n    ln_f:        decompress attractor → answer space.\n    lm_head:     read answer from answer space.\n\n    Attractor = the pivot point.\n    Input space → compress → attractor → expand → answer space.\n    Like: many roads → one tunnel → many exits.\n    Tunnel = attractor. Roads = inputs. Exits = answers.\n\n  IF ATTRACTOR DIMENSION IS SMALL (< 20 dims):\n    Answer space = low dimensional.\n    High dimensional model = finding low-dim answer.\n    Hyper law: answer lives in small subspace always.\n    Implication: only that subspace needs compute.\n    Rest = overhead. Can be removed.\n    That = real compression. Not weight sharing.\n')
print('=' * 60 + '\n')
