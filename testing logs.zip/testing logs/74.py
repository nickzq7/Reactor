import numpy as np, math, time
print('\n' + '=' * 60)
print('  W-KERNEL — NUMBER SEQUENCE TEST')
print('  Task: [n-K..n-1] → n  (mod 100)')
print('=' * 60)
N_seq = 2000
VS = 100
toks = np.array([i % VS for i in range(N_seq)])
K = 4
D = 8
M = N_seq - K
y = toks[K:]
print(f'\n  Sequence length={N_seq}, Vocab={VS}, K={K}')
print(f'  Sample: {toks[:12].tolist()} ...')

def calc_acc(logits, y):
    return 100 * np.mean(np.argmax(logits, 1) == y)

def calc_ppl(logits, y):
    nll = 0.0
    for i in range(len(y)):
        lg = logits[i] - logits[i].max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[y[i]]
    return math.exp(min(nll / len(y), 500))

def pinv_solve(X, Y):
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    thresh = S[0] * 1e-10
    mask = S > thresh
    Si = np.where(mask, 1.0 / np.where(mask, S, 1.0), 0.0)
    return Vt.T @ np.diag(Si) @ U.T @ Y
print(f"\n{'─' * 60}")
print(f'  TEST 1: LINEAR KERNEL, ONE-HOT INPUT')
print(f'  x = concat(one_hot(t-K)...one_hot(t-1))  ({K * VS}d)')
print(f'  W* = pinv(X) @ Y_onehot')
print(f"{'─' * 60}")
X_oh = np.zeros((M, K * VS), dtype=np.float64)
for i in range(K, N_seq):
    for j in range(K):
        X_oh[i - K, j * VS + toks[i - K + j]] = 1.0
Y_oh = np.eye(VS)[y]
W1 = pinv_solve(X_oh, Y_oh)
logits1 = X_oh @ W1
acc1 = calc_acc(logits1, y)
ppl1 = calc_ppl(logits1, y)
print(f'  Train acc={acc1:.1f}%  ppl={ppl1:.2f}')
print(f"  after [3,4,5]: top3={[(i, f'{100 * p:.0f}%') for i, p in sorted(enumerate((lambda lg: np.exp(lg - lg.max()) / np.exp(lg - lg.max()).sum())(logits1[5 - K])), key=lambda x: -x[1])[:3]]}")
print(f"\n{'─' * 60}")
print(f'  TEST 2: QUADRATIC KERNEL, ONE-HOT INPUT (small K)')
print(f'  K=1 only (K=4 would be 100*4=400d → quad=80200d too big)')
print(f'  x = one_hot(t-1)  (100d)')
print(f'  φ(x) = x_i*x_j upper triangle  ({VS * (VS + 1) // 2}d)')
print(f"{'─' * 60}")
K2 = 1
X_oh1 = np.zeros((N_seq - K2, VS), dtype=np.float64)
for i in range(K2, N_seq):
    X_oh1[i - K2, toks[i - K2]] = 1.0
y2 = toks[K2:]
tri_i, tri_j = np.triu_indices(VS)
Phi2 = X_oh1[:, tri_i] * X_oh1[:, tri_j]
Y_oh2 = np.eye(VS)[y2]
print(f'  Phi2 shape: {Phi2.shape}  (one-hot quadratic: sparse)')
W2 = pinv_solve(Phi2, Y_oh2)
logits2 = Phi2 @ W2
acc2 = calc_acc(logits2, y2)
ppl2 = calc_ppl(logits2, y2)
print(f'  K=1 Train acc={acc2:.1f}%  ppl={ppl2:.2f}')
print(f"\n{'─' * 60}")
print(f'  TEST 3: DENSE EMBEDDING + RESIDUAL STREAM')
print(f'  WTE: (VS, D={D}) learned from sequence structure')
print(f'  x = mean(WTE[t-K..t-1])')
print(f'  x_new = x + phi(x)@W  (quadratic, {D * (D + 1) // 2}d features)')
print(f'  logits = x_final @ WTE.T')
print(f"{'─' * 60}")
angles = np.array([2 * math.pi * i / VS for i in range(VS)])
WTE = np.zeros((VS, D))
for d in range(D // 2):
    freq = d + 1
    WTE[:, 2 * d] = np.cos(freq * angles)
    WTE[:, 2 * d + 1] = np.sin(freq * angles)
WTE = WTE / (np.linalg.norm(WTE, axis=1, keepdims=True) + 1e-08)
print(f'  WTE: circular encoding (cos/sin) — natural for mod-100 sequence')
print(f'  WTE[5]@WTE[6]={WTE[5] @ WTE[6]:.3f}  (adjacent, should be high)')
print(f'  WTE[0]@WTE[50]={WTE[0] @ WTE[50]:.3f} (opposite, should be low/neg)')
X3 = np.zeros((M, D), dtype=np.float64)
for i in range(K, N_seq):
    X3[i - K] = WTE[toks[i - K:i]].mean(0)
T3 = WTE[y]
tri_d_i, tri_d_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_d_i] * X[:, tri_d_j]
D_quad_d = D * (D + 1) // 2
L = 3
W_layers = [np.zeros((D_quad_d, D)) for _ in range(L)]

def forward(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs

def ppl_acc(Wl):
    xs = forward(X3, Wl)
    x = xs[-1]
    logits = x @ WTE.T
    return (calc_ppl(logits, y), calc_acc(logits, y))
p0, a0 = ppl_acc(W_layers)
print(f'\n  Initial: ppl={p0:.2f}  acc={a0:.1f}%')
print(f"  {'Rnd':>3} {'L':>2} {'ppl':>8} {'acc':>7}  res_before→after")
best_ppl = p0
best_W = [w.copy() for w in W_layers]
for rnd in range(8):
    improved = False
    for l in range(L):
        xs = forward(X3, W_layers)
        x_l = xs[l]
        R = T3 - x_l
        rb = np.mean(np.linalg.norm(R, axis=1))
        Phi = phi_b(x_l)
        Wn = pinv_solve(Phi, R)
        ra = np.mean(np.linalg.norm(R - Phi @ Wn, axis=1))
        Wt = [w.copy() for w in W_layers]
        Wt[l] = Wn
        pn, an = ppl_acc(Wt)
        mk = '★' if pn < best_ppl else ' '
        print(f'  {rnd + 1:>3} {l:>2} {pn:>8.2f} {an:>6.1f}%  {rb:.4f}→{ra:.4f} {mk}')
        if pn < best_ppl:
            best_ppl = pn
            W_layers = Wt
            best_W = [w.copy() for w in Wt]
            improved = True
    if not improved:
        print(f'  Rnd {rnd + 1}: converged.')
        break
W_layers = best_W
fp, fa = ppl_acc(W_layers)
print(f'\n  FINAL: ppl={fp:.2f}  acc={fa:.1f}%  vocab={VS}')

def predict_next(ctx):
    ids = [int(x) % VS for x in ctx]
    x = WTE[ids].mean(0).copy()
    for W in W_layers:
        ph = x[tri_d_i] * x[tri_d_j]
        x = x + ph @ W
    lg = x @ WTE.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    return (int(np.argmax(p)), p[int(np.argmax(p))])
print(f'\n  SEQUENCE PREDICTION:')
for ctx in [[3, 4, 5], [10, 11, 12], [97, 98, 99], [0, 1, 2], [50, 51, 52]]:
    pred, conf = predict_next(ctx)
    true = (ctx[-1] + 1) % VS
    mark = '✓' if pred == true else '✗'
    print(f'  {ctx} → pred={pred} ({100 * conf:.0f}%)  true={true}  {mark}')
print(f"\n{'=' * 60}")
print(f'  SUMMARY:')
print(f'  T1 Linear one-hot:    acc={acc1:.1f}%  ppl={ppl1:.2f}')
print(f'  T2 Quad one-hot K=1:  acc={acc2:.1f}%  ppl={ppl2:.2f}')
print(f'  T3 Dense+residual:    acc={fa:.1f}%  ppl={fp:.2f}')
print(f'\n  If T1=100%: linear kernel solves this (sequence too easy)')
print(f'  If T3>T1:   residual stream adds value')
print(f'  If T3<50%:  context mean destroys signal')
print('=' * 60 + '\n')
