import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — UNIFIED BITWISE ENGINE')
print('  Optimized Bit-Matching (Zero Unpack Overhead)')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
cfg = model.config
D = cfg.hidden_size
n_heads = cfg.num_attention_heads
head_dim = D // n_heads
n_layers = cfg.num_layers
print('  Extracting Native W-Matrices...')
W_layers = {}
with torch.no_grad():
    for l in range(n_layers):
        block = model.transformer.h[l]
        W_layers[l] = {'q': block.attn.attention.q_proj.weight.detach().numpy().T, 'k': block.attn.attention.k_proj.weight.detach().numpy().T, 'v': block.attn.attention.v_proj.weight.detach().numpy().T, 'o': block.attn.attention.out_proj.weight.detach().numpy().T, 'b_o': block.attn.attention.out_proj.bias.detach().numpy(), '1': block.mlp.c_fc.weight.detach().numpy().T, 'b_1': block.mlp.c_fc.bias.detach().numpy(), '2': block.mlp.c_proj.weight.detach().numpy().T, 'b_2': block.mlp.c_proj.bias.detach().numpy(), 'ln1_w': block.ln_1.weight.detach().numpy(), 'ln1_b': block.ln_1.bias.detach().numpy(), 'ln2_w': block.ln_2.weight.detach().numpy(), 'ln2_b': block.ln_2.bias.detach().numpy()}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_head_w = model.lm_head.weight.detach().numpy()
print('\n  [ Phase 1 ] Seeding 32-Byte RAM Bank...')
RAM_bytes = {l: [] for l in range(n_layers)}
RAM_tokens = {l: [] for l in range(n_layers)}
store_pre = {l: [] for l in range(n_layers)}

def get_hook(l):

    def hook(m, i, o):
        store_pre[l].append(o[:, -1, :].detach().cpu().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_hook(l)) for l in range(n_layers)]
seed_prompts = ['Once upon a time, a little girl named Lily', 'The brave knight took his sword and']
with torch.no_grad():
    for s in seed_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        for _ in range(15):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                binary_array = (store_pre[l].pop()[0] > 0).astype(np.uint8)
                RAM_bytes[l].append(np.packbits(binary_array))
                RAM_tokens[l].append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM_bytes[l] = np.array(RAM_bytes[l], dtype=np.uint8)
    RAM_tokens[l] = np.array(RAM_tokens[l])

def gelu_np(x):
    x = x.astype(np.float32)
    return 0.5 * x * (1.0 + np.tanh(np.float32(math.sqrt(2.0 / math.pi)) * (x + np.float32(0.044715) * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def layernorm_np(x, gamma, beta, eps=1e-05):
    x = x.astype(np.float32)
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (x - mean) / np.sqrt(var + np.float32(eps)) * gamma + beta
test_prompt = 'The brave knight took his sword and'
np_ids = tokenizer.encode(test_prompt)
print('\n' + '─' * 70)
print(f'  [ Phase 2 ] BITWISE GENERATION RUN')
print('  Output: ', end='')
tokens_to_generate = 15
layers_amputated = 0
start_time = time.time()
for step in range(tokens_to_generate):
    seq_len = len(np_ids)
    x = wte[np_ids] + wpe[np.arange(seq_len)]
    x = x.astype(np.float32)
    exited_early = False
    for l in range(n_layers):
        W = W_layers[l]
        ln1 = layernorm_np(x, W['ln1_w'], W['ln1_b'])
        q = ln1 @ W['q']
        k = ln1 @ W['k']
        v = ln1 @ W['v']
        q_heads = q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        k_heads = k.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        v_heads = v.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        att_h_list = []
        for h_id in range(n_heads):
            scr = q_heads[h_id] @ k_heads[h_id].T
            msk = np.triu(np.full((seq_len, seq_len), -1000000000.0, dtype=np.float32), 1)
            att_w = softmax_np(scr + msk)
            att_h_list.append(att_w @ v_heads[h_id])
        concat_h = np.array(att_h_list).transpose(1, 0, 2).reshape(seq_len, D)
        x = x + (concat_h @ W['o'] + W['b_o'])
        ln2 = layernorm_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['1'] + W['b_1']
        packed_current = np.packbits((pre[-1] > 0).astype(np.uint8))
        matches = np.all(RAM_bytes[l] == packed_current, axis=1)
        if np.any(matches):
            best_idx = np.argmax(matches)
            next_id = int(RAM_tokens[l][best_idx])
            layers_amputated += n_layers - 1 - l
            exited_early = True
            break
        x = x + (gelu_np(pre) @ W['2'] + W['b_2'])
    if not exited_early:
        logits = layernorm_np(x[-1:], lnf_w, lnf_b) @ lm_head_w.T
        next_id = int(np.argmax(logits[0]))
    np_ids.append(next_id)
    print(tokenizer.decode([next_id]), end='', flush=True)
gen_time = time.time() - start_time
print('\n\n' + '=' * 70)
print(f'  Generation Time  : {gen_time:.4f} seconds')
print(f'  Layers Amputated : {layers_amputated} layers skipped')
print('=' * 70 + '\n')
