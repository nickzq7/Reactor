import numpy as np
import math
import time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v14 — REAL MATRIX, EXACT SOLVE, LLM FORWARD')
print('  x @ W → logits. W solved in one step. No gradient.')
print('=' * 65)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do\n'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
K = 4
D_h = 64
EPS = 1e-08
print(f'\n  Vocab={VS}  Tokens={N}  K={K}  D_h={D_h}')
print(f'  D_in={K * VS}  N/D_in={N // (K * VS)}x')

def exact_solve(X, Y, eps=EPS):
    A = X.T @ X + eps * np.eye(X.shape[1])
    B = X.T @ Y
    return np.linalg.solve(A, B)
print(f'\n  Building dataset...', end=' ', flush=True)
X_all = np.zeros((N - K, K * VS), dtype=np.float32)
Y_all = np.zeros((N - K, VS), dtype=np.float32)
for i in range(K, N):
    for j in range(K):
        X_all[i - K, j * VS + toks[i - K + j]] = 1.0
    Y_all[i - K, toks[i]] = 1.0
X = X_all.astype(np.float64)
Y = Y_all.astype(np.float64)
print(f'done  X={X.shape}')
print(f'  Solving W0 (context→hidden)...', end=' ', flush=True)
t1 = time.time()
W0 = exact_solve(X, np.tanh(X @ np.linalg.solve(X.T @ X + EPS * np.eye(K * VS), X.T @ Y)))
W_direct = exact_solve(X, Y)
rng = np.random.RandomState(0)
W0_init = rng.randn(K * VS, D_h).astype(np.float64) * 0.01
H0 = np.tanh(X @ W0_init)
W2 = exact_solve(H0, Y)
W2_pinv = W2.T @ np.linalg.solve(W2 @ W2.T + EPS * np.eye(D_h), np.eye(D_h))
Y_h0 = Y @ W2_pinv
W0 = exact_solve(X, Y_h0)
H0 = np.tanh(X @ W0)
print(f'done ({time.time() - t1:.2f}s)')
print(f'  Solving W1 (hidden→hidden)...', end=' ', flush=True)
W1_init = np.eye(D_h, dtype=np.float64) * 0.1
H1 = np.tanh(H0 @ W1_init)
W2_from_H1 = exact_solve(H1, Y)
W1_pinv = W1_init.T @ np.linalg.solve(W1_init @ W1_init.T + EPS * np.eye(D_h), np.eye(D_h))
Y_h1 = Y @ np.linalg.solve(W2_from_H1.T @ W2_from_H1 + EPS * np.eye(D_h), W2_from_H1.T).T
W1 = exact_solve(H0, Y_h1)
H1 = np.tanh(H0 @ W1)
print(f'done')
print(f'  Solving W2 (hidden→logits)...', end=' ', flush=True)
W2 = exact_solve(H1, Y)
print(f'done')

def forward(x_flat):
    h0 = np.tanh(x_flat @ W0)
    h1 = np.tanh(h0 @ W1)
    return h1 @ W2

def embed(ids):
    x = np.zeros(K * VS, dtype=np.float64)
    context = ids[-K:] if len(ids) >= K else [0] * (K - len(ids)) + ids
    for j, tok in enumerate(context[-K:]):
        x[j * VS + tok] = 1.0
    return x
print(f'\n  Evaluating...', end=' ', flush=True)
nll = 0.0
n_e = 0
step = max(1, (N - K) // 1000)
for i in range(0, N - K, step):
    lg = forward(X[i])
    if not np.all(np.isfinite(lg)):
        continue
    lg -= lg.max()
    lp = lg - np.log(np.sum(np.exp(lg)))
    nll += -lp[np.argmax(Y[i])]
    n_e += 1
ppl = math.exp(min(nll / n_e, 500)) if n_e > 0 else 999.0
print(f'done')
nll2 = 0.0
n2 = 0
for i in range(0, N - K, step):
    lg = X[i] @ W_direct
    if not np.all(np.isfinite(lg)):
        continue
    lg -= lg.max()
    lp = lg - np.log(np.sum(np.exp(lg)))
    nll2 += -lp[np.argmax(Y[i])]
    n2 += 1
ppl_direct = math.exp(min(nll2 / n2, 500)) if n2 > 0 else 999.0
print(f'\n  1-layer W_direct:    ppl={ppl_direct:.2f}  ratio={ppl_direct / VS:.3f}')
print(f'  3-layer W0,W1,W2:    ppl={ppl:.2f}  ratio={ppl / VS:.3f}')
print(f'  Vocab={VS}  (below = sequence learning)')
print(f'\n  BIGRAM CHECK — W-Kernel forward pass:')
print(f'  forward(one-hot(last K chars)) → logits → P(next)')
for prev in ['t', 'h', 'e', ' ', 'a', 'n']:
    if prev not in c2i:
        continue
    ids_test = [c2i[prev]]
    x = embed(ids_test)
    lg = forward(x)
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{prev}': {top3}")
print(f'\n  BIGRAM CHECK — W_direct (1-layer exact):')
for prev in ['t', 'h', 'e', ' ', 'a', 'n']:
    if prev not in c2i:
        continue
    x = np.zeros(K * VS, dtype=np.float64)
    x[(K - 1) * VS + c2i[prev]] = 1.0
    lg = x @ W_direct
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{prev}': {top3}")

def sample(lg, temp=0.8, top_k=8):
    lg = lg - lg.max()
    lg = lg / temp
    if top_k < len(lg):
        thresh = np.sort(lg)[-top_k]
        lg[lg < thresh] = -10000000000.0
    p = np.exp(lg)
    p /= p.sum()
    return int(np.random.choice(VS, p=p))

def generate(prompt, n=150, temp=0.8, use_direct=False, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        x = embed(ids)
        lg = x @ W_direct if use_direct else forward(x)
        if not np.all(np.isfinite(lg)):
            break
        ids.append(sample(lg, temp=temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION (W_direct 1-layer, temp=0.8):\n')
for prompt in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(prompt, temp=0.8, use_direct=True)
    print(f"  '{prompt}'")
    print(f'    {out[len(prompt):][:70]}')
print(f'\n  GENERATION (3-layer W0,W1,W2, temp=0.8):\n')
for prompt in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(prompt, temp=0.8, use_direct=False)
    print(f"  '{prompt}'")
    print(f'    {out[len(prompt):][:70]}')
gen_sp = generate('the ', n=300, temp=0.85, use_direct=True)
space_pct = 100 * gen_sp[4:].count(' ') / len(gen_sp[4:])
cnt = Counter(gen_sp[4:])
top5 = [(c, f'{100 * cnt[c] // len(gen_sp[4:])}%') for c, _ in cnt.most_common(5)]
print(f'\n  Space% = {space_pct:.0f}%  (≈18% = real text rhythm)')
print(f'  Top-5: {top5}')
print(f'  Sample: {gen_sp[4:84]}')
print(f'\n  Time: {time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  W_direct ppl={ppl_direct:.2f}  3-layer ppl={ppl:.2f}  vocab={VS}')
print(f'\n  FORWARD PASS:')
print(f'    x = concat(one-hot(t-{K})...one-hot(t-1))  [{K * VS}d]')
print(f'    h0 = tanh(x  @ W0)   W0: ({K * VS},{D_h})')
print(f'    h1 = tanh(h0 @ W1)   W1: ({D_h},{D_h})')
print(f'    out = h1 @ W2        W2: ({D_h},{VS})')
print(f'  All W solved in one step: W* = (X^T X)^{{-1}} X^T Y')
print(f'  Same structure as LLM. Different how W obtained.')
print('=' * 65 + '\n')
