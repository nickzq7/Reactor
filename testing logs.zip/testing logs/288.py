import numpy as np, json
print('\n' + '=' * 65)
print('  W-HASH STEP 2 — GEOMETRIC FINGERPRINT')
print('=' * 65)
data = np.load('tiny_transformer_weights.npz')
W = {k: data[k] for k in data.files}
with open('tiny_transformer_meta.json') as f:
    meta = json.load(f)
VS = meta['VS']
D = meta['D']
H = meta['H']
NL = meta['NL']
K = meta['K']
vocab = meta['vocab']
w2i = meta['w2i']
i2w = {int(k): v for k, v in meta['i2w'].items()}
toks = [w2i[w] for w in meta['text'].split()]
print(f'\n  Loaded: VS={VS} D={D} H={H} NL={NL} K={K}')
print(f'  Keys: {list(W.keys())}')

def sv_signature(M, top_k=8):
    U, S, Vt = np.linalg.svd(M, full_matrices=False)
    S_norm = S / S.sum() if S.sum() > 0 else S
    entropy = -np.sum(S_norm * np.log(S_norm + 1e-10))
    eff_rank = int(np.exp(entropy))
    cond = S[0] / (S[-1] + 1e-10)
    return {'sv': S[:top_k].round(4).tolist(), 'sv_full': S.round(4).tolist(), 'rank': int(np.sum(S > 0.001)), 'eff_rank': eff_rank, 'cond': round(float(cond), 2), 'frob': round(float(np.linalg.norm(M, 'fro')), 4), 'entropy': round(float(entropy), 4), 'shape': list(M.shape)}

def angle_between(A, B):
    a = A.flatten()
    b = B.flatten()
    return round(float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-10)), 4)

def head_diversity(W_in, D, H):
    dh = D // H
    heads = [W_in[h * dh:(h + 1) * dh, :] for h in range(H)]
    sims = []
    for i in range(H):
        for j in range(i + 1, H):
            sims.append(angle_between(heads[i], heads[j]))
    return round(float(np.mean(sims)), 4) if sims else 0.0
HASH = {}
print(f"\n{'─' * 65}")
print(f'  EMBEDDING HASH')
print(f"{'─' * 65}")
h = sv_signature(W['WTE'])
HASH['WTE'] = h
print(f"  WTE ({VS}×{D}): rank={h['rank']}/{min(VS, D)}  eff_rank={h['eff_rank']}")
print(f"    sv_top8={h['sv']}")
print(f"    frob={h['frob']}  cond={h['cond']}  entropy={h['entropy']}")
h = sv_signature(W['WPE'])
HASH['WPE'] = h
print(f"  WPE ({K}×{D}):  rank={h['rank']}/{min(K, D)}  eff_rank={h['eff_rank']}")
print(f"    sv_top4={h['sv'][:4]}  frob={h['frob']}")
for lyr in range(NL):
    print(f"\n{'─' * 65}")
    print(f'  LAYER {lyr} HASH')
    print(f"{'─' * 65}")
    for name in ['WQ', 'WK', 'WV', 'WO']:
        key = f'{name}{lyr}'
        h = sv_signature(W[key])
        HASH[key] = h
        print(f"  {key} ({D}×{D}): rank={h['rank']}  eff_rank={h['eff_rank']}  cond={h['cond']}")
        print(f"    sv={h['sv'][:6]}  frob={h['frob']}")
    qk_align = angle_between(W[f'WQ{lyr}'], W[f'WK{lyr}'])
    qv_align = angle_between(W[f'WQ{lyr}'], W[f'WV{lyr}'])
    HASH[f'QK_align{lyr}'] = qk_align
    HASH[f'QV_align{lyr}'] = qv_align
    print(f'\n  ATT{lyr} alignment: QK={qk_align}  QV={qv_align}')
    print(f'    (0=orthogonal, 1=identical, -1=opposite)')
    hd_q = head_diversity(W[f'WQ{lyr}'], D, H)
    hd_k = head_diversity(W[f'WK{lyr}'], D, H)
    hd_v = head_diversity(W[f'WV{lyr}'], D, H)
    HASH[f'head_div_Q{lyr}'] = hd_q
    HASH[f'head_div_K{lyr}'] = hd_k
    HASH[f'head_div_V{lyr}'] = hd_v
    print(f'  Head diversity: Q={hd_q}  K={hd_k}  V={hd_v}')
    print(f'    (1=heads identical, 0=heads orthogonal → want low = diverse heads)')
    h1 = sv_signature(W[f'W1{lyr}'])
    h2 = sv_signature(W[f'W2{lyr}'])
    HASH[f'W1{lyr}'] = h1
    HASH[f'W2{lyr}'] = h2
    print(f"\n  FFN{lyr} W1 ({W[f'W1{lyr}'].shape}): rank={h1['rank']}  eff_rank={h1['eff_rank']}  cond={h1['cond']}")
    print(f"    sv={h1['sv'][:6]}  frob={h1['frob']}")
    print(f"  FFN{lyr} W2 ({W[f'W2{lyr}'].shape}): rank={h2['rank']}  eff_rank={h2['eff_rank']}  cond={h2['cond']}")
    print(f"    sv={h2['sv'][:6]}  frob={h2['frob']}")
    W1W2 = W[f'W2{lyr}'] @ W[f'W1{lyr}']
    h12 = sv_signature(W1W2)
    HASH[f'W1W2{lyr}'] = h12
    print(f"  FFN{lyr} W2@W1 (effective {D}×{D}): rank={h12['rank']}  eff_rank={h12['eff_rank']}")
    print(f"    sv={h12['sv'][:6]}  frob={h12['frob']}")
    print(f"    → This is the FFN's net linear kernel. Compare to W-Kernel W_l.")
print(f"\n{'─' * 65}")
print(f'  RESIDUAL STREAM ANALYSIS')
print(f"{'─' * 65}")

def ln_np(x, g, b, eps=1e-05):
    mu = x.mean(-1, keepdims=True)
    v = x.var(-1, keepdims=True)
    return g * (x - mu) / np.sqrt(v + eps) + b

def gelu_np(x):
    return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def forward_np(ids):
    x = W['WTE'][ids] + W['WPE']
    states = {'input': x.copy()}
    for lyr in range(NL):
        xn = ln_np(x, W[f'LN1g{lyr}'], W[f'LN1b{lyr}'])
        Q = (xn @ W[f'WQ{lyr}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
        Km = (xn @ W[f'WK{lyr}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
        V = (xn @ W[f'WV{lyr}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
        sc = Q @ Km.transpose(0, 2, 1) / np.sqrt(D // H)
        mask = np.triu(np.full((K, K), -1000000000.0), k=1)
        a = softmax_np(sc + mask)
        out = (a @ V).transpose(1, 0, 2).reshape(K, D) @ W[f'WO{lyr}'].T
        x_post_att = x + out
        states[f'post_att{lyr}'] = x_post_att.copy()
        xn = ln_np(x_post_att, W[f'LN2g{lyr}'], W[f'LN2b{lyr}'])
        ffn_out = gelu_np(xn @ W[f'W1{lyr}'].T + W[f'b1{lyr}']) @ W[f'W2{lyr}'].T + W[f'b2{lyr}']
        x = x_post_att + ffn_out
        states[f'post_ffn{lyr}'] = x.copy()
        states[f'att_contrib{lyr}'] = np.linalg.norm(out, 'fro')
        states[f'ffn_contrib{lyr}'] = np.linalg.norm(ffn_out, 'fro')
    return states
M_tr = len(toks) - K
X_ids = np.array([toks[i:i + K] for i in range(M_tr)])
att_contribs = [[] for _ in range(NL)]
ffn_contribs = [[] for _ in range(NL)]
x_norms = [[] for _ in range(NL + 1)]
for i in range(M_tr):
    st = forward_np(X_ids[i])
    for lyr in range(NL):
        att_contribs[lyr].append(st[f'att_contrib{lyr}'])
        ffn_contribs[lyr].append(st[f'ffn_contrib{lyr}'])
for lyr in range(NL):
    a = np.mean(att_contribs[lyr])
    f = np.mean(ffn_contribs[lyr])
    ratio = f / (a + 1e-10)
    HASH[f'att_contrib{lyr}'] = round(float(a), 4)
    HASH[f'ffn_contrib{lyr}'] = round(float(f), 4)
    HASH[f'ffn_att_ratio{lyr}'] = round(float(ratio), 4)
    print(f'  Layer {lyr}: ATT={a:.4f}  FFN={f:.4f}  FFN/ATT={ratio:.3f}')
    print(f"    {('FFN dominates' if ratio > 1 else 'ATT dominates')}")
print(f"\n{'─' * 65}")
print(f'  ATTENTION PATTERN (averaged over all samples)')
print(f"{'─' * 65}")
for lyr in range(NL):
    attn_patterns = []
    for i in range(M_tr):
        ids = X_ids[i]
        x = W['WTE'][ids] + W['WPE']
        for ll in range(lyr):
            xn = ln_np(x, W[f'LN1g{ll}'], W[f'LN1b{ll}'])
            Q = (xn @ W[f'WQ{ll}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
            Km = (xn @ W[f'WK{ll}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
            V = (xn @ W[f'WV{ll}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
            sc = Q @ Km.transpose(0, 2, 1) / np.sqrt(D // H)
            mask = np.triu(np.full((K, K), -1000000000.0), k=1)
            a = softmax_np(sc + mask)
            x = x + (a @ V).transpose(1, 0, 2).reshape(K, D) @ W[f'WO{ll}'].T
            xn2 = ln_np(x, W[f'LN2g{ll}'], W[f'LN2b{ll}'])
            x = x + gelu_np(xn2 @ W[f'W1{ll}'].T + W[f'b1{ll}']) @ W[f'W2{ll}'].T + W[f'b2{ll}']
        xn = ln_np(x, W[f'LN1g{lyr}'], W[f'LN1b{lyr}'])
        Q = (xn @ W[f'WQ{lyr}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
        Km = (xn @ W[f'WK{lyr}'].T).reshape(K, H, D // H).transpose(1, 0, 2)
        sc = Q @ Km.transpose(0, 2, 1) / np.sqrt(D // H)
        mask = np.triu(np.full((K, K), -1000000000.0), k=1)
        a = softmax_np(sc + mask)
        attn_patterns.append(a)
    avg_attn = np.mean(attn_patterns, 0)
    HASH[f'attn_pattern{lyr}'] = avg_attn.round(4).tolist()
    print(f'\n  Layer {lyr} avg attention (H={H} heads, K={K} positions):')
    for h in range(H):
        print(f'  Head {h}:')
        for row in range(K):
            vals = [f'{avg_attn[h, row, c]:.2f}' for c in range(K)]
            print(f"    pos{row} attends: [{', '.join(vals)}]")
print(f"\n{'─' * 65}")
print(f'  COMPACT W-HASH STRING')
print(f"{'─' * 65}")

def compact_sv(sv, n=4):
    return ','.join((f'{x:.2f}' for x in sv[:n]))
lines = []
lines.append(f"WTE:sv=[{compact_sv(HASH['WTE']['sv'])}] rank={HASH['WTE']['rank']} frob={HASH['WTE']['frob']}")
lines.append(f"WPE:sv=[{compact_sv(HASH['WPE']['sv'])}] rank={HASH['WPE']['rank']}")
for lyr in range(NL):
    lines.append(f"L{lyr}.ATT: QK_align={HASH[f'QK_align{lyr}']} head_div_Q={HASH[f'head_div_Q{lyr}']}")
    lines.append(f"L{lyr}.WQ: sv=[{compact_sv(HASH[f'WQ{lyr}']['sv'])}] rank={HASH[f'WQ{lyr}']['rank']} cond={HASH[f'WQ{lyr}']['cond']}")
    lines.append(f"L{lyr}.WK: sv=[{compact_sv(HASH[f'WK{lyr}']['sv'])}] rank={HASH[f'WK{lyr}']['rank']}")
    lines.append(f"L{lyr}.FFN: W1W2_sv=[{compact_sv(HASH[f'W1W2{lyr}']['sv'])}] rank={HASH[f'W1W2{lyr}']['rank']}")
    lines.append(f"L{lyr}.CONTRIB: ATT={HASH[f'att_contrib{lyr}']} FFN={HASH[f'ffn_contrib{lyr}']} ratio={HASH[f'ffn_att_ratio{lyr}']}")
hash_str = '\n'.join(lines)
print(f'\n{hash_str}')
with open('w_hash.json', 'w') as f:
    json.dump(HASH, f, indent=2)
with open('w_hash_compact.txt', 'w') as f:
    f.write(hash_str)
print(f'\n  Saved: w_hash.json  (full hash)')
print(f'  Saved: w_hash_compact.txt  (readable string)')
print(f"\n{'=' * 65}")
print(f'  STEP 2 COMPLETE.')
print(f'  This is the geometric fingerprint of the trained model.')
print(f'  Next: STEP 3 — Build W-Kernel, compute same hash, find diff.')
print('=' * 65 + '\n')
