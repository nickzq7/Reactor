import subprocess, sys

def ensure(p):
    try:
        __import__(p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
ensure('accelerate')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — 3B SCALE TEST (CLEAN)')
print('  Pythia-2.8B: same laws or new hidden laws?')
print('=' * 62)
MODEL_NAME = 'EleutherAI/pythia-2.8b'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_hidden_layers
print(f'  D={D}  Heads={n_heads}  Head_dim={head_dim}  Layers={n_layers}')
b0 = model.gpt_neox.layers[0]
print(f'\n  Block attributes: {[n for n, _ in b0.named_children()]}')
print(f'  MLP attributes:   {[n for n, _ in b0.mlp.named_children()]}')
print(f'  ATT attributes:   {[n for n, _ in b0.attention.named_children()]}')

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2_np(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2_tok(X, Y):
    n = len(X)
    s = int(n * 0.8)
    Xf = X.astype(np.float32)
    Yf = Y.astype(np.float32)
    Xb = np.c_[Xf, np.ones(n, dtype=np.float32)]
    W = np.linalg.lstsq(Xb[:s], Yf[:s], rcond=None)[0]
    pred = Xb[s:] @ W
    return r2_np(pred, Yf[s:])
CTX = 8
starts = ['Once upon a time', 'The scientist looked', 'In a distant future', 'The old library held', 'A young programmer', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed slowly', 'A dog sat quietly', 'She found the key', 'The storm was coming']
print(f'\n  Generating {len(starts) * 2} texts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.8, 1.0]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=25, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} texts.')
test_layers = [0, 4, 8, 15, 23, 31]
print(f'\n  Testing layers: {test_layers}')
results = {}
with torch.no_grad():
    for layer_idx in test_layers:
        print(f'  Layer {layer_idx}...', end=' ', flush=True)
        block = model.gpt_neox.layers[layer_idx]
        X_tok = []
        D_tok = []
        PH_tok = []
        FA_tok = []
        FO_tok = []
        for text in all_texts:
            toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
            L = toks['input_ids'].shape[1]
            if L < CTX:
                continue
            out_m = model(**toks, output_hidden_states=True)
            hs = out_m.hidden_states
            captured = {}

            def hook_act(mod, inp, out):
                captured['act'] = out.detach()

            def hook_ffn(mod, inp, out):
                captured['ffn'] = out.detach()

            def hook_att(mod, inp, out):
                captured['att'] = out[0].detach()
            h1 = block.mlp.act.register_forward_hook(hook_act)
            h2 = block.mlp.dense_4h_to_h.register_forward_hook(hook_ffn)
            h3 = block.attention.dense.register_forward_hook(hook_att)
            for start in range(L - CTX + 1):
                x16 = hs[layer_idx][0, start:start + CTX]
                pos_ids = torch.arange(start, start + CTX, dtype=torch.long).unsqueeze(0)
                block_out16 = block(hidden_states=x16.unsqueeze(0), position_ids=pos_ids)[0].squeeze(0)
                delta_np = (block_out16 - x16).float().numpy()
                act_np = captured['act'].squeeze(0).float().numpy()
                ffn_np = captured['ffn'].squeeze(0).float().numpy()
                att_np = captured['att'].squeeze(0).float().numpy()
                qkv_w = block.attention.query_key_value.weight.float().numpy()
                qkv_b = block.attention.query_key_value.bias
                bq = qkv_b[:D].float().numpy() if qkv_b is not None else 0
                bk = qkv_b[D:2 * D].float().numpy() if qkv_b is not None else 0
                bv = qkv_b[2 * D:].float().numpy() if qkv_b is not None else 0
                ln1_np = block.input_layernorm(x16).float().numpy()
                Q = ln1_np @ qkv_w[:D, :].T + bq
                K = ln1_np @ qkv_w[D:2 * D, :].T + bk
                V = ln1_np @ qkv_w[2 * D:, :].T + bv
                ph_feats = []
                for h in range(n_heads):
                    sh = h * head_dim
                    eh = sh + head_dim
                    Qh = Q[:, sh:eh]
                    Kh = K[:, sh:eh]
                    Vh = V[:, sh:eh]
                    scr = Qh @ Kh.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    ph_feats.append(softmax_np(scr + msk) @ Vh)
                concat = np.concatenate(ph_feats, axis=1)
                x_np = x16.float().numpy()
                for t in range(CTX):
                    X_tok.append(x_np[t])
                    D_tok.append(delta_np[t])
                    PH_tok.append(concat[t])
                    FA_tok.append(act_np[t])
                    FO_tok.append(ffn_np[t])
            h1.remove()
            h2.remove()
            h3.remove()
        N = len(X_tok)
        if N < 100:
            print(f'too few ({N}), skip')
            continue
        X = np.array(X_tok, dtype=np.float32)
        DE = np.array(D_tok, dtype=np.float32)
        PH = np.array(PH_tok, dtype=np.float32)
        FA = np.array(FA_tok, dtype=np.float32)
        FO = np.array(FO_tok, dtype=np.float32)
        r_xd = fit_r2_tok(X, DE)
        r_ph = fit_r2_tok(PH, DE)
        r_ffn = fit_r2_tok(FA, FO)
        results[layer_idx] = dict(x_delta=r_xd, per_head=r_ph, ffn=r_ffn, N=N)
        print(f'N={N}  x→Δ={r_xd:.4f}  per_head={r_ph:.4f}  ffn={r_ffn:.4f}')
print('\n' + '=' * 62)
print('  RESULTS — Pythia-2.8B (D=2560, head_dim=80, 32 layers)')
print('=' * 62)
print(f"\n  {'Layer':<7} {'x→delta':<12} {'per_head→Δ':<13} {'ffn_gelu':<12} {'N'}")
print('  ' + '─' * 52)
for l in test_layers:
    if l not in results:
        print(f'  {l:<7} SKIPPED')
        continue
    r = results[l]

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f"  {l:<7} {f(r['x_delta']):<12} {f(r['per_head']):<13} {f(r['ffn']):<12} {r['N']}")
print(f'\n  COMPARISON:\n  TinyStories-1M  D=64   head_dim=4   8 layers\n    x→delta:  0.986→0.815 (layer 0→7)\n    per_head: 0.993+ all layers\n    ffn:      1.000 (token-level)\n    ATT floor: ~1% (head_dim=4 numerical limit)\n\n  Pythia-2.8B     D=2560 head_dim=80  32 layers\n    Results above.\n\n  KEY QUESTIONS ANSWERED:\n  1. per_head stays 0.99+?\n     YES → law universal across scale.\n     NO  → new hidden law at depth.\n\n  2. ffn stays 1.000?\n     YES → GeLU rule universal.\n     NO  → activation changed. Find new rule.\n\n  3. ATT gap smaller than 1%?\n     YES → head_dim was the floor. Confirmed.\n     NO  → structural cause. New finding.\n\n  4. x→delta drops faster at layer 31 than TinyStories layer 7?\n     Expected YES. 32 layers = 4x more rotations.\n     If YES → depth pattern confirmed.\n     If NO  → 3B compresses same info in each layer.\n')
print('=' * 62 + '\n')
