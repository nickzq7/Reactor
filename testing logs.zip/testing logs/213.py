import subprocess, sys, os

def ensure(package, import_name=None):
    name = import_name or package
    try:
        __import__(name)
        print(f'  {package:<22} OK')
    except ImportError:
        print(f'  {package:<22} installing...', end='', flush=True)
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', package, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print(' done')
print('\n' + '=' * 62)
print('  W KERNEL — REAL PRETRAINED MODEL')
print('  roneneldan/TinyStories-1M')
print('=' * 62)
print('\n  Checking dependencies...')
ensure('torch')
ensure('transformers')
ensure('numpy')
ensure('huggingface_hub', 'huggingface_hub')
import numpy as np, time, torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '-' * 62)
print('  DOWNLOADING MODEL')
print('  roneneldan/TinyStories-1M  (~5MB)')
print('  EleutherAI/gpt-neo-125M tokenizer (~2MB)')
print('  First run: downloads. Second run: instant.')
print('-' * 62)
MODEL_ID = 'roneneldan/TinyStories-1M'
TOK_ID = 'EleutherAI/gpt-neo-125M'
print()
try:
    print(f'  Loading tokenizer from {TOK_ID}...')
    tokenizer = AutoTokenizer.from_pretrained(TOK_ID)
    print(f'  Loading model from {MODEL_ID}...')
    model = AutoModelForCausalLM.from_pretrained(MODEL_ID)
except Exception as e:
    print(f'\n  ERROR: {e}')
    print('  Check internet connection and try again.')
    sys.exit(1)
model.eval()
total_params = sum((p.numel() for p in model.parameters()))
total_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
n_layers = model.config.num_layers
hidden_dim = model.config.hidden_size
vocab_size = model.config.vocab_size
print(f'\n  Model ready.')
print(f'  Parameters  : {total_params:,}')
print(f'  Memory      : {total_mem / 1024 / 1024:.1f} MB')
print(f'  Layers      : {n_layers}')
print(f'  Hidden dim  : {hidden_dim}')
print(f'  Vocabulary  : {vocab_size:,}')
print('\n' + '-' * 62)
print('  ORIGINAL MODEL — real text generation')
print('-' * 62)
for prompt in ['Once upon a time there was', 'The little dog ran to', 'A girl named Emma found']:
    inp = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(inp, max_length=40, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    text = tokenizer.decode(out[0], skip_special_tokens=True)
    print(f'\n  [{prompt}]')
    print(f'  {text}')
print('\n' + '-' * 62)
print('  COLLECTING HIDDEN STATES')
print('  H_in  = state BEFORE all transformer layers')
print('  H_out = state AFTER  all transformer layers')
print('-' * 62)
sentences = ['once upon a time there was a little girl named lily', 'the dog ran fast through the green field near home', 'a boy found a red ball near the big river today', 'the cat sat on the warm mat beside the fire', 'she picked flowers and smiled at her mother warmly', 'he walked slowly down the quiet road in the rain', 'the bird flew high above the tall trees at dawn', 'a small fish swam in the clear blue lake alone', 'the children played happily together in the sunny yard', 'the old man sat quietly under the big oak tree', 'she opened the door and looked outside at the snow', 'he found a little puppy sleeping near the old house', 'the sun rose slowly over the distant green hills today', 'a rabbit jumped quickly and hid deep in the bushes', 'the little boy cried and ran fast to his mother', 'she baked warm cookies for all the happy children', 'the moon shone bright and clear over the quiet town', 'a dragon lived deep inside the cold and dark cave', 'the princess waited alone in the tall grey stone tower', 'he climbed the tall tree to find his lost kite', 'the wind blew cold and strong across the open field', 'a tiny mouse found a piece of cheese near the wall', 'the farmer woke up early and went to feed animals', 'she drew a colorful picture of her family and house', 'the train moved slowly through the high snowy mountains', 'a baby elephant splashed and played in the muddy water', 'the kind teacher read a long story to the students', 'he closed his eyes and wished upon the first star', 'the snow fell softly and quietly on the sleeping village', 'a kind old woman gave warm bread to hungry children', 'the puppy wagged its tail happily and barked very loud', 'she sang a sweet lullaby to help the baby sleep', 'the brave knight rode his horse into the dark forest', 'a young fox carefully learned to hunt from his mother', 'the flowers bloomed bright and beautiful in the spring sun', 'he discovered a hidden door behind the old bookshelf', 'the butterfly landed gently on a beautiful red rose', 'a little girl lost her way deep in the big woods', 'the friendly giant woke up and smiled at the village', 'she found a shiny magic stone beside the old stone well', 'the little cat chased the butterfly through the green garden', 'a brave boy climbed the mountain to see the whole world', 'the friendly witch made a magic potion in her cottage', 'a small boat sailed across the wide and quiet blue lake', 'the baby bear found honey in the hollow old oak tree', 'she whispered a secret to her best friend in school', 'the rainbow appeared after the long and heavy rain fell', 'a clever fox tricked the big wolf and ran away fast', 'the little prince lived alone on a very small planet', 'a kind fairy granted three wishes to the poor farmer']
print(f'\n  Processing {len(sentences)} sentences...')
H_inputs, H_outputs, tok_labels, tok_logits = ([], [], [], [])
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=32, truncation=True)
        ids = tokens['input_ids']
        if ids.shape[1] < 4:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        seq = ids.shape[1]
        lg = out.logits[0].numpy()
        for pos in range(1, seq - 1):
            H_inputs.append(hs[0][0, pos].numpy())
            H_outputs.append(hs[-1][0, pos].numpy())
            tok_logits.append(lg[pos])
            tok_labels.append(ids[0, pos + 1].item())
H_in = np.array(H_inputs)
H_out = np.array(H_outputs)
L_all = np.array(tok_logits)
Y_all = np.array(tok_labels)
N_tr = int(len(H_in) * 0.75)
Hi_tr = H_in[:N_tr]
Hi_te = H_in[N_tr:]
Ho_tr = H_out[:N_tr]
Ho_te = H_out[N_tr:]
L_tr = L_all[:N_tr]
L_te = L_all[N_tr:]
Y_tr = Y_all[:N_tr]
Y_te = Y_all[N_tr:]
print(f'  Collected: {len(H_in)} positions')
print(f'  Train: {N_tr}   Test: {len(Hi_te)}')
orig_top1 = np.mean(np.argmax(L_te, axis=1) == Y_te)
orig_top5 = np.mean([Y_te[i] in np.argsort(L_te[i])[-5:] for i in range(len(Y_te))])
print(f'\n  Original quality — Top-1: {orig_top1 * 100:.1f}%  Top-5: {orig_top5 * 100:.1f}%')
print('\n' + '=' * 62)
print(f'  W KERNEL — replace {n_layers} layers with ONE K')
print('=' * 62)
lm_head = model.lm_head.weight.detach().numpy()

def h2l(h):
    return h @ lm_head.T

def top1(l, y):
    return np.mean(np.argmax(l, axis=1) == y)

def top5(l, y):
    return np.mean([y[i] in np.argsort(l[i])[-5:] for i in range(len(y))])

def rbf(A, B, s):
    A2 = np.sum(A ** 2, axis=1, keepdims=True)
    B2 = np.sum(B ** 2, axis=1, keepdims=True)
    return np.exp(-np.maximum(A2 + B2.T - 2 * (A @ B.T), 0) / (2 * s ** 2))

def sigma(X):
    idx = np.random.choice(len(X), min(200, len(X)), replace=False)
    Xs = X[idx]
    D = np.sqrt(np.maximum(np.sum(Xs ** 2, axis=1, keepdims=True) + np.sum(Xs ** 2, axis=1) - 2 * Xs @ Xs.T, 0))
    v = D[D > 0]
    return max(float(np.median(v)), 0.01) if len(v) else 1.0

def essential(X, n):
    n = min(n, len(X))
    sel = []
    sel.append(int(np.argmin(np.sum((X - X.mean(0)) ** 2, axis=1))))
    md = np.full(len(X), np.inf)
    for _ in range(n - 1):
        d = np.sum((X - X[sel[-1]]) ** 2, axis=1)
        md = np.minimum(md, d)
        nx = int(np.argmax(md))
        sel.append(nx)
        md[nx] = 0
    return np.array(sel)
sig = sigma(Hi_tr)
print('\n  Method A — Linear kernel (H_in⁺ @ H_out)')
K = np.linalg.lstsq(Hi_tr, Ho_tr, rcond=None)[0]
lA = h2l(Hi_te @ K)
t1A = top1(lA, Y_te)
t5A = top5(lA, Y_te)
mA = K.size * 4
print(f'  Top-1: {t1A * 100:.1f}%  Top-5: {t5A * 100:.1f}%  Memory: {mA / 1024 / 1024:.3f}MB  Gap: {abs(t1A - orig_top1) * 100:.1f}%')
print(f'\n  Method B — Essential RBF kernel')
print(f"  {'Pts':>6} {'Top1':>7} {'Top5':>7} {'Mem MB':>9} {'Gap':>7} {'OK?':>6}")
print(f"  {'-' * 46}")
best = None
for n in [10, 20, 30, 50, 75, 100, 150, 200, 250, 300]:
    if n >= N_tr:
        break
    idx = essential(Hi_tr, n)
    Hs = Hi_tr[idx]
    Hos = Ho_tr[idx]
    Ktt = rbf(Hs, Hs, sig) + 0.001 * np.eye(n)
    alp = np.linalg.solve(Ktt, Hos)
    Hp = rbf(Hi_te, Hs, sig) @ alp
    lB = h2l(Hp)
    t1 = top1(lB, Y_te)
    t5 = top5(lB, Y_te)
    mem = (Hs.size + alp.size) * 4
    gap = abs(t1 - orig_top1) * 100
    ok = t1 >= orig_top1 * 0.8
    if ok and best is None:
        best = (n, t1, t5, mem)
    ok_str = 'YES' if ok else 'NO '
    print(f'  {n:>6} {t1 * 100:>6.1f}% {t5 * 100:>6.1f}% {mem / 1024 / 1024:>8.3f} {gap:>6.1f}% {ok_str:>6}')
print('\n' + '=' * 62)
print('  FINAL RESULT + 70B PROJECTION')
print('=' * 62)
print(f"\n  {'Method':<26} {'Top1':>7} {'Top5':>7} {'Memory':>9} {'Reduction':>10}")
print(f"  {'-' * 62}")
print(f"  {'Original (' + str(n_layers) + ' layers)':<26} {orig_top1 * 100:>6.1f}% {orig_top5 * 100:>6.1f}% {total_mem / 1024 / 1024:>7.1f}MB {'baseline':>10}")
print(f"  {'Linear kernel':<26} {t1A * 100:>6.1f}% {t5A * 100:>6.1f}% {mA / 1024 / 1024:>7.3f}MB {total_mem / mA:>9.0f}x")
if best:
    bn, bt1, bt5, bm = best
    print(f"  {'Essential RBF (' + str(bn) + ' pts)':<26} {bt1 * 100:>6.1f}% {bt5 * 100:>6.1f}% {bm / 1024 / 1024:>7.3f}MB {total_mem / bm:>9.0f}x")
E70 = 8192
V70 = 32000
mem70 = 140 * 1024
lin70 = E70 * E70 * 4 / 1024 / 1024
if best:
    sc = hidden_dim / E70
    p70 = max(10, int(best[0] / sc))
    e70 = (p70 * E70 + p70 * V70) * 4 / 1024 / 1024
else:
    p70 = 0
    e70 = 0
gap_lin = abs(t1A - orig_top1) * 100
print(f"\n  70B NUMBERS:\n  ─────────────────────────────────────────────────\n  Original 70B memory      : ~140,000 MB\n  W linear kernel          : {lin70:.0f} MB\n  W essential kernel (est) : ~{e70:.0f} MB\n\n  Fits in 6GB GPU:\n    Linear   : {('YES' if lin70 < 6000 else 'NO')} ({lin70:.0f}MB)\n    Essential: {('YES' if e70 < 6000 else 'NO')} (~{e70:.0f}MB)\n\n  Quality gap at this scale: {gap_lin:.1f}% (linear)\n  {('→ Gap < 5%  : W kernel works. Path to 70B is clear.' if gap_lin < 5 else '→ Gap 5-20% : Partial. Extraction needs refinement.' if gap_lin < 20 else '→ Gap > 20% : Need better extraction method.')}\n  ─────────────────────────────────────────────────\n")
print('=' * 62 + '\n')
