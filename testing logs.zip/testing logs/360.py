import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 1e-10 else 1.0

def fit_W(X, Y):
    X64 = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(X64, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)
sentence_pairs = [('The cat sat on the mat and looked around.', 'The feline rested upon the rug and gazed about.', 'cat/feline'), ('The little girl ran to her mother crying.', 'The small child rushed toward her mom sobbing.', 'girl/child'), ('He was very happy when he found the toy.', 'He felt extremely glad after discovering the plaything.', 'happy/glad'), ('The dog barked loudly at the stranger.', 'The puppy howled fiercely at the visitor.', 'dog/puppy'), ('She opened the door and walked inside.', 'She pushed the gate and stepped through.', 'door/gate'), ('The old man sat under the big tree.', 'The elderly gentleman rested beneath the large oak.', 'old man/elderly'), ('It was a dark and stormy night outside.', 'The evening was gloomy with heavy rain falling.', 'dark night/gloomy evening'), ('The children played happily in the garden.', 'The kids enjoyed themselves joyfully in the yard.', 'children/kids')]
different_sentences = ['The cat sat on the mat and looked around.', 'He was very happy when he found the toy.', 'The old man sat under the big tree.', 'She opened the door and walked inside.', 'The mathematics of numbers is complex.', 'Stars shine brightly in the dark sky.', 'Water flows downhill toward the ocean.', 'The recipe calls for two cups of flour.']
training_texts = ['Once upon a time there was a little girl who loved to play in the garden.', 'The small boy ran to his mother and showed her the butterfly he had found.', 'She looked at the stars and felt very happy and peaceful inside.', 'The dog barked loudly when the stranger came to the door.', 'He picked up the heavy stone and threw it into the deep river.', 'A small bird flew over the big tree and sang a beautiful song.', 'The old man walked slowly to the market to buy some fresh bread.', 'She found a small box under the old bed and opened it carefully.', 'The brave knight rode through the dark forest on his white horse.', 'The princess looked out the window and saw a beautiful rainbow.', 'Once upon a time there was a tiny mouse who lived in a big house.', 'The children played in the garden until the sun went down slowly.', 'He could not find his favorite toy anywhere in the whole house.', 'The mother called out to her child who was playing near the pond.', 'A young fox played near the river every morning before breakfast.', 'The teacher smiled at the young student who answered correctly.', 'He woke up early in the morning and saw the sun rising beautifully.', 'The wind blew the leaves across the quiet empty street outside.', 'She whispered to her friend that she had found something special.', 'The baby smiled at the colorful toy and clapped her tiny hands.', 'Once there was a dragon who lived in a cave on top of a mountain.', 'The little rabbit hopped through the meadow looking for carrots.', 'She opened her eyes and saw that it was already morning outside.', 'The kind farmer gave food to all the hungry animals every day.', 'He walked through the forest and heard the birds singing above.', 'The young girl learned to read and write at her school every day.', 'A big fish jumped out of the water and fell back with a splash.', 'The sun was very hot and the children stayed inside to keep cool.', 'She made a beautiful picture and gave it to her grandmother.', 'The little dog followed the boy everywhere he went all day long.']
print(f'\nCollecting h7 and ln_f across ALL tokens in training texts...')
h7_all = []
lnf_all = []
correct_all = []
hooks = []

def hook_h7(m, inp, out):
    x = inp[0].detach().float()
    for t in range(x.shape[1]):
        h7_all.append(x[0, t].numpy().copy())

def hook_lnf(m, inp, out):
    x = out.detach().float()
    for t in range(x.shape[1]):
        lnf_all.append(x[0, t].numpy().copy())
hooks.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_h7))
hooks.append(model.transformer.ln_f.register_forward_hook(hook_lnf))
lm_weight = model.lm_head.weight.detach().float().numpy()
ln_f_w = model.transformer.ln_f.weight.detach().float().numpy()
ln_f_b = model.transformer.ln_f.bias.detach().float().numpy()
with torch.no_grad():
    for text in training_texts:
        toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        out = model(**toks)
        ids = toks['input_ids'][0]
        logits = out.logits[0]
        for t in range(len(ids) - 1):
            correct_all.append(int(ids[t + 1].item()))
for h in hooks:
    h.remove()
H7_all = np.array(h7_all, dtype=np.float32)
LNF_all = np.array(lnf_all, dtype=np.float32)
n_correct = len(correct_all)
n_h7 = len(H7_all)
h7_aligned = []
lnf_aligned = []
correct_aligned = []
h7_aligned = []
lnf_aligned = []
correct_aligned = []
hooks3 = []
cur_h7 = []
cur_lnf = []

def hook_h7c(m, inp, out):
    x = inp[0].detach().float()
    cur_h7.append(x[0].numpy().copy())

def hook_lnfc(m, inp, out):
    x = out.detach().float()
    cur_lnf.append(x[0].numpy().copy())
hooks3.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_h7c))
hooks3.append(model.transformer.ln_f.register_forward_hook(hook_lnfc))
with torch.no_grad():
    for text in training_texts:
        cur_h7.clear()
        cur_lnf.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        model(**toks)
        ids = toks['input_ids'][0].numpy()
        L = len(ids)
        h7s = cur_h7[0]
        lnfs = cur_lnf[0]
        for t in range(L - 1):
            h7_aligned.append(h7s[t])
            lnf_aligned.append(lnfs[t])
            correct_aligned.append(int(ids[t + 1]))
for h in hooks3:
    h.remove()
H7 = np.array(h7_aligned, dtype=np.float32)
LNF = np.array(lnf_aligned, dtype=np.float32)
COR = correct_aligned
print(f'Aligned: H7={H7.shape}  LNF={LNF.shape}  Correct={len(COR)}')
print(f"\n{'=' * 60}")
print(f'  TEST 1 — ln_f decompression law (full text)')
print(f'  {len(H7)} tokens. Was 20 before. Now real.')
print(f"{'=' * 60}")
n = len(H7)
s = int(n * 0.8)
W_lnf = fit_W(H7[:s], LNF[:s])
Xb = np.c_[H7.astype(np.float64), np.ones(n)]
r2_tr = r2(Xb[:s] @ W_lnf, LNF[:s])
r2_te = r2(Xb[s:] @ W_lnf, LNF[s:])
print(f'\n  h7 → ln_f_out R² train: {r2_tr:.6f}')
print(f'  h7 → ln_f_out R² test:  {r2_te:.6f}')
marker = '✓ LAW CONFIRMED' if r2_te > 0.999 else '~ STRONG' if r2_te > 0.95 else 'PARTIAL' if r2_te > 0.5 else '✗ NOT LINEAR'
print(f'  {marker}')
h7_std = float(np.std(H7))
lnf_std = float(np.std(LNF))
print(f'\n  h7 std:    {h7_std:.4f}')
print(f'  ln_f std:  {lnf_std:.4f}')
print(f'  Expansion: {lnf_std / h7_std:.1f}x')
print(f"\n{'=' * 60}")
print(f'  TEST 2 — Prediction accuracy (full text)')
print(f'  {len(H7)} tokens')
print(f"{'=' * 60}")

def layernorm_np(x, w, b, eps=1e-05):
    mu = np.mean(x)
    std = np.std(x) + eps
    return (x - mu) / std * w + b
correct_norm = 0
correct_skip = 0
top5_norm = 0
top5_skip = 0
for i in range(len(H7)):
    lnf_out = layernorm_np(H7[i], ln_f_w, ln_f_b)
    logits_n = lnf_out @ lm_weight.T
    logits_s = H7[i] @ lm_weight.T
    pred_n = int(np.argmax(logits_n))
    pred_s = int(np.argmax(logits_s))
    if pred_n == COR[i]:
        correct_norm += 1
    if pred_s == COR[i]:
        correct_skip += 1
    top5_n = np.argsort(logits_n)[-5:]
    top5_s = np.argsort(logits_s)[-5:]
    if COR[i] in top5_n:
        top5_norm += 1
    if COR[i] in top5_s:
        top5_skip += 1
N = len(H7)
print(f'\n  Normal (h7→ln_f→lm_head):    {correct_norm}/{N} = {correct_norm / N:.1%}')
print(f'  Skip   (h7→lm_head directly): {correct_skip}/{N} = {correct_skip / N:.1%}')
print(f'  Top-5 normal: {top5_norm}/{N} = {top5_norm / N:.1%}')
print(f'  Top-5 skip:   {top5_skip}/{N} = {top5_skip / N:.1%}')
print(f"\n{'=' * 60}")
print(f'  TEST 3 — Same meaning, different words')
print(f'  Do sentence pairs reach same attractor region?')
print(f"{'=' * 60}")
h7_pairs = []
hooks4 = []
pair_h7_last = []

def hook_pair(m, inp, out):
    x = inp[0].detach().float()
    pair_h7_last.append(x[0, -1].numpy().copy())
hooks4.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_pair))
with torch.no_grad():
    for sA, sB, label in sentence_pairs:
        pair_h7_last.clear()
        tA = tokenizer(sA, return_tensors='pt', max_length=32, truncation=True)
        model(**tA)
        hA = pair_h7_last[0].copy()
        pair_h7_last.clear()
        tB = tokenizer(sB, return_tensors='pt', max_length=32, truncation=True)
        model(**tB)
        hB = pair_h7_last[0].copy()
        h7_pairs.append((hA, hB, label))
diff_h7 = []
with torch.no_grad():
    for s in different_sentences:
        pair_h7_last.clear()
        toks = tokenizer(s, return_tensors='pt', max_length=32, truncation=True)
        model(**toks)
        diff_h7.append(pair_h7_last[0].copy())
for h in hooks4:
    h.remove()
print(f"\n  {'Pair':<20} {'Same-meaning dist':<22} {'vs random dist':<18} {'Closer?'}")
print(f"  {'─' * 70}")
same_dists = []
rand_dists_all = []
for i, (hA, hB, label) in enumerate(h7_pairs):
    same_dist = float(np.linalg.norm(hA - hB))
    rand_dists = []
    for j in range(len(diff_h7)):
        for k in range(j + 1, len(diff_h7)):
            rand_dists.append(float(np.linalg.norm(diff_h7[j] - diff_h7[k])))
    mean_rand = float(np.mean(rand_dists))
    same_dists.append(same_dist)
    rand_dists_all.append(mean_rand)
    closer = '✓ CLOSER' if same_dist < mean_rand * 0.8 else '~ slight' if same_dist < mean_rand else '✗ NOT closer'
    print(f'  {label:<20} {same_dist:<22.4f} {mean_rand:<18.4f} {closer}')
mean_same = float(np.mean(same_dists))
mean_rand = float(np.mean(rand_dists_all))
print(f'\n  Mean same-meaning distance:  {mean_same:.4f}')
print(f'  Mean random distance:        {mean_rand:.4f}')
print(f'  Ratio:                       {mean_same / mean_rand:.4f}')
if mean_same < mean_rand * 0.7:
    print(f'\n  SEMANTIC ATTRACTOR CONFIRMED:')
    print(f'  Same meaning → closer in attractor space.')
    print(f'  Attractor = meaning coordinate. Not word coordinate.')
elif mean_same < mean_rand:
    print(f'\n  WEAK SEMANTIC ATTRACTOR: slight clustering.')
else:
    print(f'\n  NO SEMANTIC ATTRACTOR at sentence level.')
print(f"\n{'=' * 60}")
print(f'  TEST 4 — Core dimensions (PCA on {len(H7)} tokens)')
print(f"{'=' * 60}")
H7_c = H7 - H7.mean(axis=0)
U, S, Vt = np.linalg.svd(H7_c, full_matrices=False)
var_exp = S ** 2 / (S ** 2).sum()
cumvar = np.cumsum(var_exp)
dims_90 = int(np.searchsorted(cumvar, 0.9)) + 1
dims_95 = int(np.searchsorted(cumvar, 0.95)) + 1
dims_99 = int(np.searchsorted(cumvar, 0.99)) + 1
print(f'\n  Dims for 90%  variance: {dims_90}/{D}')
print(f'  Dims for 95%  variance: {dims_95}/{D}')
print(f'  Dims for 99%  variance: {dims_99}/{D}')
print(f'\n  Top 10 dims:')
for i in range(min(10, len(S))):
    bar = '█' * int(var_exp[i] * 200)
    print(f'  dim {i + 1:2d}: {var_exp[i]:.4f}  {bar}')
H7_f = H7[:n // 2] - H7[:n // 2].mean(axis=0)
H7_s = H7[n // 2:] - H7[n // 2:].mean(axis=0)
_, _, Vt1 = np.linalg.svd(H7_f, full_matrices=False)
_, _, Vt2 = np.linalg.svd(H7_s, full_matrices=False)
top_k = 5
cos_sims = []
for k in range(top_k):
    cos = abs(float(np.dot(Vt1[k], Vt2[k])))
    cos_sims.append(cos)
    print(f"  Core dim {k + 1} stability: {cos:.4f}  {('✓ stable' if cos > 0.9 else '~ partial' if cos > 0.7 else '✗ unstable')}")
print(f'\n  Mean core stability: {np.mean(cos_sims):.4f}')
print(f"  {('STABLE CORE DIMENSIONS CONFIRMED' if np.mean(cos_sims) > 0.9 else 'PARTIAL STABILITY' if np.mean(cos_sims) > 0.7 else 'UNSTABLE CORE')}")
print(f"\n{'=' * 60}")
print(f'  TEST 2 FULL TEXT SUMMARY')
print(f"{'=' * 60}")
print(f"\n  ln_f law R² (full text):   {r2_te:.4f}  ({len(H7)} tokens)\n  Prediction accuracy:        {correct_norm / N:.1%} (h7→ln_f→lm_head)\n  Same-meaning ratio:         {mean_same / mean_rand:.4f}\n  Attractor dimension:        {dims_99}/{D} dims (99% variance)\n  Core dim stability:         {np.mean(cos_sims):.4f}\n\n  WHAT THIS TELLS US:\n\n  ln_f R²:\n    1.000 = decompression is linear law. Proven.\n    <0.99 = decompression needs more than linear.\n    Gap from 0.37 (20 samples) to ? (full text).\n    More samples = true number revealed.\n\n  Prediction accuracy:\n    Higher than 10% = attractor contains more answer info.\n    Same as 10% = attractor alone not enough. ln_f essential.\n\n  Same-meaning ratio < 0.7:\n    Attractor = meaning. Words don't matter.\n    Different words, same concept = same region.\n    This IS a semantic coordinate system.\n\n  Core dimensions:\n    Stable across text = real axes. Not noise.\n    Those axes = the coordinate system of meaning.\n    How many = how many dimensions meaning needs.\n")
print('=' * 60 + '\n')
