import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import Counter
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (TRIPLE-LOCK CONSENSUS)')
print('  Executing Multi-Layer Voting Logic to Kill Semantic Drift.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
HAMMING_THRESHOLD = 12
CONSENSUS_QUORUM = 3
print('\n  [ Phase 1 ] Mapping Multi-Layer Trajectories (Deep Saturation)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden']
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_pre = {l: [] for l in range(n_layers)}

def hook_pre_gelu(l):

    def hook(m, i, o):
        store_pre[l].append(o[:, -1, :].detach().cpu().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.act.register_forward_hook(hook_pre_gelu(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        prev_bits = [None] * n_layers
        for _ in range(35):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                curr_bits = (store_pre[l].pop()[0] > 0).astype(int)
                if prev_bits[l] is not None:
                    chain = np.concatenate([prev_bits[l], curr_bits])
                    RAM_chains[l].append(chain)
                    RAM_sequences[l].append(next_id)
                prev_bits[l] = curr_bits
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    chains = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = []
    for i in range(len(tokens) - JUMP_LENGTH):
        seqs.append(tuple(tokens[i:i + JUMP_LENGTH].tolist()))
    RAM_chains[l] = chains[:len(seqs)]
    RAM_sequences[l] = seqs
print(f'  ✓ Mapped trajectories across {n_layers} layers.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 60
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] GENERATION: TRIPLE-LOCK CONSENSUS')
print('─' * 75)
bit_history = {l: None for l in range(n_layers)}
live_bits = {l: None for l in range(n_layers)}

def get_live_hook(l):

    def hook(m, i, o):
        live_bits[l] = (o[:, -1, :].detach().cpu().numpy() > 0).astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_live_hook(l)) for l in range(n_layers)]
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen = 0
print(f'  Prompt: {test_prompt}\n')
with torch.no_grad():
    while total_gen < tokens_to_gen:
        out = model(hub_ids)
        truth_id = torch.argmax(out.logits[0, -1, :]).item()
        votes = []
        if all((v is not None for v in bit_history.values())):
            for l in range(n_layers):
                current_chain = np.concatenate([bit_history[l], live_bits[l]])
                mismatches = 512 - np.sum(RAM_chains[l] == current_chain, axis=1)
                best_idx = np.argmin(mismatches)
                if mismatches[best_idx] <= HAMMING_THRESHOLD:
                    votes.append(RAM_sequences[l][best_idx])
        consensus_found = False
        if votes:
            vote_counts = Counter(votes)
            top_sequence, count = vote_counts.most_common(1)[0]
            if count >= CONSENSUS_QUORUM:
                jump_text = tokenizer.decode(list(top_sequence))
                print(f"  [✓ CONSENSUS JUMP ({count} Layers)]: '{jump_text.strip()}'")
                jump_tensor = torch.tensor([list(top_sequence)])
                hub_ids = torch.cat([hub_ids, jump_tensor], dim=1)
                for layer in range(n_layers):
                    bit_history[layer] = None
                total_gen += JUMP_LENGTH
                consensus_found = True
        if not consensus_found:
            word = tokenizer.decode([truth_id])
            print(f'  [Standard]: {word.strip()}')
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            for l in range(n_layers):
                bit_history[l] = live_bits[l]
            total_gen += 1
for h in live_hooks:
    h.remove()
print('\n' + '=' * 75)
print('  DEEP LOGIC VERDICT')
print('=' * 75)
print('\n  The "Triple-Lock" consensus ensures that speculation is not \n  based on a single noisy layer, but on the alignment of the \n  entire neural stack. \n  \n  If the model still drifts: We must increase the quorum or \n  incorporate Attention Head patterns into the Consensus key.\n')
print('=' * 75 + '\n')
