import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import Counter
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (1K TOKEN TEST)')
print('  Testing Long-Form Stability & Adaptive Consensus.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
UNIVERSAL_QUORUM = n_layers // 2 + 1
print('\n  [ Phase 1 ] Building W-Atlas (Massive Saturation for 1K Test)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a blue dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden', 'A clever fox hid in the bushes', 'The farmer planted seeds in the soil', 'A little mouse found a piece of cheese', 'The wizard used a magic wand']
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_key = {l: [] for l in range(n_layers)}

def hook_key(l):

    def hook(m, i, o):
        store_key[l].append((o[:, -1, :] > 0).detach().cpu().numpy().astype(int))
    return hook
hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(hook_key(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        window_history = {l: [] for l in range(n_layers)}
        for _ in range(45):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                k_bits = store_key[l].pop()[0]
                window_history[l].append(k_bits)
                if len(window_history[l]) > 4:
                    window_history[l].pop(0)
                if len(window_history[l]) == 4:
                    RAM_chains[l].append(np.concatenate(window_history[l]))
                    RAM_sequences[l].append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM_chains[l] = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = [tuple(tokens[i:i + JUMP_LENGTH].tolist()) for i in range(len(tokens) - JUMP_LENGTH)]
    RAM_chains[l], RAM_sequences[l] = (RAM_chains[l][:len(seqs)], seqs)
print(f'  ✓ Saturated {len(RAM_sequences[0])} W-Atlas Chains.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 1000
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] THE RACE: BASELINE vs. ADAPTIVE ATLAS (1,000 TOKENS)')
print('─' * 75)
print(f'  Generating Baseline Truth (1,000 Tokens)...')
baseline_ids = tokenizer.encode(test_prompt, return_tensors='pt')
start_time = time.time()
with torch.no_grad():
    for i in range(tokens_to_gen):
        out = model(baseline_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        baseline_ids = torch.cat([baseline_ids, torch.tensor([[next_id]])], dim=1)
        if (i + 1) % 200 == 0:
            print(f'    ... {i + 1} tokens reached')
normal_time = time.time() - start_time
baseline_text = tokenizer.decode(baseline_ids[0])
print(f'\n  Executing Adaptive Engine (1,000 Tokens)...')
atlas_history = {l: [] for l in range(n_layers)}
live_key = {l: None for l in range(n_layers)}

def get_key_hook(l):

    def hook(m, i, o):
        live_key[l] = (o[:, -1, :] > 0).detach().cpu().numpy().astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(get_key_hook(l)) for l in range(n_layers)]
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen = 0
jumps_done = 0
start_time = time.time()
with torch.no_grad():
    while total_gen < tokens_to_gen:
        out = model(hub_ids)
        probs = torch.nn.functional.softmax(out.logits[0, -1, :], dim=-1)
        top_probs, top_indices = torch.topk(probs, 2)
        confidence_margin = top_probs[0].item() - top_probs[1].item()
        truth_id = top_indices[0].item()
        for l in range(n_layers):
            atlas_history[l].append(live_key[l])
            if len(atlas_history[l]) > 4:
                atlas_history[l].pop(0)
        jump_found = False
        if confidence_margin > 0.5 and len(atlas_history[0]) == 4:
            votes = []
            for l in range(n_layers):
                current_atlas = np.concatenate(atlas_history[l])
                mismatches = 1024 - np.sum(RAM_chains[l] == current_atlas, axis=1)
                best_idx = np.argmin(mismatches)
                if mismatches[best_idx] <= 20:
                    votes.append(RAM_sequences[l][best_idx])
            if votes:
                vote_counts = Counter(votes)
                top_sequence, count = vote_counts.most_common(1)[0]
                if count >= UNIVERSAL_QUORUM and top_sequence[0] == truth_id:
                    hub_ids = torch.cat([hub_ids, torch.tensor([list(top_sequence)])], dim=1)
                    for layer in range(n_layers):
                        atlas_history[layer] = []
                    total_gen += JUMP_LENGTH
                    jumps_done += 1
                    jump_found = True
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            total_gen += 1
        if total_gen % 200 == 0:
            print(f'    ... {total_gen} tokens reached (Jumps: {jumps_done})')
for h in live_hooks:
    h.remove()
hub_time = time.time() - start_time
hub_text = tokenizer.decode(hub_ids[0])
print('\n' + '=' * 75)
print('  1,000 TOKEN ENDURANCE VERDICT')
print('=' * 75)
print(f'  Standard Time    : {normal_time:.4f}s')
print(f'  W-Hub Time       : {hub_time:.4f}s')
print(f'  Successful Jumps : {jumps_done}')
b_words = baseline_text.split()
h_words = hub_text.split()
matches = 0
for i in range(min(len(b_words), len(h_words))):
    if b_words[i] == h_words[i]:
        matches += 1
match_pct = matches / len(b_words) * 100
print(f'  Word Match Score : {matches} / {len(b_words)} ({match_pct:.1f}%)')
print('\n  ANALYSIS:')
if match_pct > 95:
    print('  FLAWLESS STABILITY. The Adaptive Atlas maintained')
    print('  perfect semantic alignment over the entire 1k sequence.')
else:
    print(f'  DRIFT DETECTED. Compound error caused {100 - match_pct:.1f}% divergence.')
    print('  Check if the divergence happens during a looping sequence.')
print('\n' + '─' * 75)
print(f'  PREVIEW (First 200 chars):')
print(f'  {hub_text[:200]}...')
print('=' * 75 + '\n')
