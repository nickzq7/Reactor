import os, time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTNeoConfig
from datasets import load_dataset
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
CFG = dict(vocab_size=50257, hidden_size=64, num_layers=4, attention_types=[[['global'], 4]], num_heads=4, intermediate_size=256, max_position_embeddings=128, window_size=128, resid_pdrop=0.0, embed_pdrop=0.0, attention_dropout=0.0)
tok = AutoTokenizer.from_pretrained('gpt2')
tok.pad_token = tok.eos_token

def make_model():
    return AutoModelForCausalLM.from_config(GPTNeoConfig(**CFG)).to(device)
print('Loading TinyStories from cache...')
raw = load_dataset('roneneldan/TinyStories', split='train')
texts = raw['text'][:5000]
print(f'Loaded {len(texts)} stories')

class SD(Dataset):

    def __init__(self, texts):
        self.data = []
        for t in texts:
            enc = tok(t, truncation=True, max_length=64, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
loader = DataLoader(SD(texts), batch_size=64, shuffle=True)
PROMPTS = ['Once upon a time there was a little', 'The dog ran to', 'She was happy because', 'One day a small boy found', 'The rabbit hopped into the']

def gen(model, prompt, max_new=40):
    model.eval()
    ids = tok(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.3, pad_token_id=tok.eos_token_id)
    return tok.decode(out[0], skip_special_tokens=True)

def score_and_show(model, label):
    model.eval()
    print(f"\n{'=' * 65}\n  {label}\n{'=' * 65}")
    total = 0
    for p in PROMPTS:
        out = gen(model, p)
        ids = tok(out, return_tensors='pt', truncation=True, max_length=64).input_ids.to(device)
        with torch.no_grad():
            loss = model(ids, labels=ids).loss.item()
        total += loss
        cont = out[len(p):].strip().replace('\n', ' ')[:65]
        print(f'  P: {p}')
        print(f'  O: {cont}  [{loss:.3f}]\n')
    avg = total / len(PROMPTS)
    print(f'  AVG LOSS: {avg:.4f}  (lower = better)')
    return avg

def train(model, epochs=30, lr=0.0003, label=''):
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-05)
    best_loss = 9999
    best_model = None
    best_opt = None
    print(f'\n  Training {label}  ({epochs} epochs)')
    print(f"  {'Ep':>3}  {'Loss':>8}  {'Time':>5}  Status")
    print(f"  {'─' * 40}")
    for ep in range(1, epochs + 1):
        model.train()
        total = 0
        t0 = time.time()
        for batch in loader:
            batch = batch.to(device)
            opt.zero_grad()
            loss = model(batch, labels=batch).loss
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += loss.item()
        sched.step()
        avg = total / len(loader)
        sec = time.time() - t0
        if avg < best_loss:
            best_loss = avg
            best_model = {k: v.clone().cpu() for k, v in model.state_dict().items()}
            best_opt = {k: v.clone() if isinstance(v, torch.Tensor) else v for k, v in opt.state_dict().items()}
            tag = f'BEST {best_loss:.4f} ✓'
        else:
            model.load_state_dict({k: v.to(device) for k, v in best_model.items()})
            opt.load_state_dict(best_opt)
            tag = f'rolled back (best={best_loss:.4f})'
        print(f'  {ep:>3}  {avg:>8.4f}  {sec:>4.1f}s  {tag}')
    model.load_state_dict(best_model)
    return model
print(f"\n{'=' * 65}")
print('  STEP 1 — BUILD + TRAIN 1M TEACHER')
print(f"{'=' * 65}")
teacher = make_model()
print(f'  Teacher params: {sum((p.numel() for p in teacher.parameters())):,}')
teacher = train(teacher, epochs=30, lr=0.0003, label='TEACHER')
score_teacher = score_and_show(teacher, 'TEACHER (trained 1M)')
print(f"\n{'=' * 65}")
print('  STEP 2 — RAW KERNEL (same size, random weights)')
print(f"{'=' * 65}")
kernel = make_model()
print(f'  Kernel params: {sum((p.numel() for p in kernel.parameters())):,}')
score_raw = score_and_show(kernel, 'RAW KERNEL (before V16)')
print(f"\n{'=' * 65}")
print('  STEP 3 — V16 TRANSFER (teacher → raw kernel)')
print(f"{'=' * 65}")
WTE_T = teacher.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
WTE_K = kernel.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
VS = min(WTE_T.shape[0], WTE_K.shape[0])
P = np.linalg.lstsq(WTE_T[:VS], WTE_K[:VS], rcond=None)[0]
proj = WTE_T[:VS] @ P
blend = 0.5 * WTE_K[:VS] + 0.5 * proj
agree = np.sum(WTE_K[:VS] * proj, axis=0)
flips = np.argsort(agree)[-3:]
blend[:, flips] *= -1
with torch.no_grad():
    kernel.transformer.wte.weight[:VS].copy_(torch.tensor(blend, dtype=torch.float32).to(device))
print(f'  Agreement range: {agree.min():.3f} → {agree.max():.3f}')
print(f'  Flipped dims: {flips.tolist()}')
print('  ✓ V16 injected')
kernel.transformer.wte.weight.requires_grad_(False)
print(f"\n{'=' * 65}")
print('  STEP 4 — TRAIN KERNEL (WTE frozen)')
print(f"{'=' * 65}")
kernel = train(kernel, epochs=30, lr=0.0005, label='KERNEL after V16')
score_kernel = score_and_show(kernel, 'TRAINED KERNEL (after V16)')
print(f"\n{'=' * 65}")
print('  FINAL COMPARISON  (lower loss = better)')
print(f"{'=' * 65}")
print(f'  Raw kernel (random weights)     : {score_raw:.4f}')
print(f'  Teacher (trained 1M)            : {score_teacher:.4f}')
print(f'  Kernel after V16 + training     : {score_kernel:.4f}')
print(f'  Gap teacher vs kernel           : {score_kernel - score_teacher:.4f}')
print(f"{'=' * 65}")
_dir = os.path.dirname(os.path.abspath(__file__))
teacher.save_pretrained(os.path.join(_dir, '1m_teacher'))
kernel.save_pretrained(os.path.join(_dir, '1m_kernel_v16'))
print('Saved.')
