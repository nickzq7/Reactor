import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
n_heads = model.config.num_heads
head_dim = D // n_heads
print(f'D={D}  Layers={n_layers}  Heads={n_heads}  HeadDim={head_dim}')

def r2_score(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def test_linear(X, Y, name, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        print(f'  {name:<55} NaN/Inf')
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X, np.ones(len(X))]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except Exception as e:
        print(f'  {name:<55} FAILED: {e}')
        return (float('nan'), float('nan'))
    r2_tr = r2_score(Xb[:s] @ W, Y[:s])
    r2_te = r2_score(Xb[s:] @ W, Y[s:])
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<55} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
    return (r2_tr, r2_te)

def layernorm_np(x, eps=1e-05):
    mu = np.mean(x, axis=1, keepdims=True)
    std = np.std(x, axis=1, keepdims=True) + eps
    return (x - mu) / std
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly in the shadows. Lily gently picked up the kitten and held it close to her heart to keep it warm. She carried it inside and showed her mother who smiled and said they could keep it.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding the animals he would go to the fields and work until the sun went down. His children would bring him lunch and sit with him under the big oak tree nearby.', 'Deep in the forest there was a small house where a family of bears lived together. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the woods nearby. One day the baby bear followed a butterfly deep into the forest and got lost alone. He sat down and began to cry because he could not find his way back home again.', 'There was once a brave young knight who lived in a castle near the mountains high. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go and face the dragon and bring peace to the kingdom. He rode for three days through dark forests and over high mountains to find the dragon.', 'A small girl named Sophie loved books more than anything else in the whole wide world. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her their stories directly. She learned about faraway lands and ancient kingdoms and creatures no one had ever seen.', 'The little village sat quietly at the edge of a great forest full of ancient trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest. Children would run through the market eating apples and drinking warm spiced cider. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight came. The old grandmother would sit by the fire and tell stories of the village long ago.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him. The first night Tommy shone the light and saw only his toys and books and nothing scary. His father explained that darkness was just the absence of light and nothing more than that. Tommy started to feel braver and soon he could sleep without the flashlight beside him.', 'The ocean was vast and blue and stretched as far as the eye could possibly see. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water. One night a terrible storm came and blew his boat far off course into unknown waters. When morning came he saw an island he had never seen before on any of his old maps. He went ashore and found the island was full of strange and beautiful plants and birds.', 'High up in the mountains there was a small school where children came from far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way. Some children learned by reading and some by drawing and some by building things with hands. She gave each child the kind of lesson that matched the way their mind worked best. At the end of every year her students could all read and write and solve hard problems.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake and ready. They all ate breakfast together and laughed and talked about the fun day ahead.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished and it had a rope ladder and a little window. They sat inside it that first evening and felt like kings of their own small world.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the path and picked it up carefully. The stone glowed with a soft blue light that pulsed slowly like a heartbeat in her paw. She brought it home and placed it in her burrow where it lit up the whole space warmly. Every night she would fall asleep looking at the gentle blue glow above her.']
store = {'h_final': [], 'lnf_out': []}
for li in range(n_layers):
    store[f'ln2_out_{li}'] = []
    store[f'ffn_in_{li}'] = []
    store[f'gelu_out_{li}'] = []
    store[f'ffn_out_{li}'] = []
    store[f'ln1_out_{li}'] = []
    store[f'attn_out_{li}'] = []
    store[f'softmax_out_{li}'] = []
hooks = []
cur = {k: [] for k in store}

def hook_lnf(m, inp, out):
    cur['h_final'].append(inp[0].detach().float()[0].numpy().copy())
    cur['lnf_out'].append(out.detach().float()[0].numpy().copy())
hooks.append(model.transformer.ln_f.register_forward_hook(hook_lnf))
for li in range(n_layers):

    def make_w1(l):

        def hook(m, inp, out):
            cur[f'ffn_in_{l}'].append(out.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].mlp.c_fc.register_forward_hook(make_w1(li)))
for li in range(n_layers):

    def make_gelu(l):

        def hook(m, inp, out):
            cur[f'gelu_out_{l}'].append(out.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_gelu(li)))
for li in range(n_layers):

    def make_ffn(l):

        def hook(m, inp, out):
            cur[f'ffn_out_{l}'].append(out.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].mlp.register_forward_hook(make_ffn(li)))
for li in range(n_layers):

    def make_ln2(l):

        def hook(m, inp, out):
            cur[f'ln2_out_{l}'].append(out.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ln2(li)))
for li in range(n_layers):

    def make_ln1(l):

        def hook(m, inp, out):
            cur[f'ln1_out_{l}'].append(out.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].ln_1.register_forward_hook(make_ln1(li)))
for li in range(n_layers):

    def make_attn(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur[f'attn_out_{l}'].append(o.detach().float()[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_attn(li)))
for li in range(n_layers):

    def make_softmax(l):

        def hook(m, inp, out):
            pass
        return hook
for li in range(n_layers):

    def make_wo_in(l):

        def hook(m, inp, out):
            x = inp[0].detach().float()[0]
            cur[f'softmax_out_{l}'].append(x.numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].attn.attention.out_proj.register_forward_hook(make_wo_in(li)))
print(f'\nCollecting activations...')
all_store = {k: [] for k in store}
with torch.no_grad():
    for text in long_texts:
        for k in cur:
            cur[k].clear()
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        L = toks['input_ids'].shape[1]
        for k in cur:
            if cur[k]:
                arr = cur[k][0]
                for t in range(L):
                    all_store[k].append(arr[t].copy())
for h in hooks:
    h.remove()
S = {}
for k in all_store:
    if all_store[k]:
        S[k] = np.array(all_store[k], dtype=np.float32)
N = len(S.get('h_final', []))
print(f'Total tokens: {N}')
lnf_w = model.transformer.ln_f.weight.detach().float().numpy()
lnf_b = model.transformer.ln_f.bias.detach().float().numpy()
print(f"\n{'=' * 75}")
print(f'  THREE FIXES — R²=1.000 required')
print(f'  N={N} tokens')
print(f"{'=' * 75}")
print(f'\n  FIX 1 — ln_f: correct LayerNorm (not RMSNorm)')
print(f'  GPT-Neo uses LayerNorm = (h-mean)/std * W + b')
print(f"  {'─' * 65}")
h_f = S['h_final']
lnf_out = S['lnf_out']
h_normalized = layernorm_np(h_f)
h_scaled = h_normalized * lnf_w[None, :]
h_biased = h_scaled + lnf_b[None, :]
test_linear(h_normalized, lnf_out, '  (h-mean)/std → lnf_out')
test_linear(h_scaled, lnf_out, '  (h-mean)/std * W → lnf_out')
test_linear(h_biased, lnf_out, '  (h-mean)/std * W + b → lnf_out (EXACT)')
diff = h_biased - lnf_out
max_err = float(np.max(np.abs(diff)))
mean_err = float(np.mean(np.abs(diff)))
print(f'\n  Direct error check:')
print(f'  max_err  = {max_err:.2e}')
print(f'  mean_err = {mean_err:.2e}')
print(f"  {('✓✓ EXACT MATCH' if max_err < 0.0001 else '~ NEAR' if max_err < 0.001 else '? GAP')}")
print(f'\n  FIX 2 — W1 alone: ln2_out → ffn_in (before gelu)')
print(f'  W1 is a matrix. Linear. Must be R²=1.000.')
print(f"  {'─' * 65}")
for li in range(n_layers):
    k_in = f'ln2_out_{li}'
    k_out = f'ffn_in_{li}'
    if k_in in S and k_out in S:
        test_linear(S[k_in], S[k_out], f'  W1 layer {li}: ln2_out → ffn_in')
print(f'\n  FIX 3 — Softmax crystallization')
print(f'  softmax_out (context vectors) → attn_out via W_o')
print(f'  If R²=1.000: softmax = attention crystallization point.')
print(f'  Parallel to gelu in FFN.')
print(f"  {'─' * 65}")
for li in range(n_layers):
    k_soft = f'softmax_out_{li}'
    k_attn = f'attn_out_{li}'
    if k_soft in S and k_attn in S:
        test_linear(S[k_soft], S[k_attn], f'  softmax_out_{li} → attn_out (W_o)')
print(f'\n  Confirm: ln1_out → softmax_out (nonlinear, softmax inside)')
for li in range(n_layers):
    k_ln1 = f'ln1_out_{li}'
    k_soft = f'softmax_out_{li}'
    if k_ln1 in S and k_soft in S:
        test_linear(S[k_ln1], S[k_soft], f'  ln1_out_{li} → softmax_out (nonlinear?)')
print(f"\n{'=' * 75}")
print(f'  COMPLETE EXACT CHAIN SUMMARY')
print(f"{'=' * 75}")
print(f'\n  IF ALL R²=1.000:\n\n  FULL EXACT CHAIN:\n    h_in\n      ↓ (h-mean)/std         = LN1    R²=1.000 ✓ (proven prev)\n      ↓ * W_ln1 + b          = linear R²=1.000 ✓ (proven prev)\n      ↓ Q@K^T/sqrt(d)        = linear (QKV projection)\n      ↓ softmax              = CRYSTALLIZATION (nonlinear)\n      ↓ softmax_out @ V      = context vectors\n      ↓ @ W_o                = linear R²=1.000 ← FIX 3\n      ↓ + h_in               = residual (exact, proven)\n    h_post_attn\n      ↓ (h-mean)/std         = LN2    R²=1.000 ✓ (proven prev)\n      ↓ * W_ln2 + b          = linear R²=1.000 ✓ (proven prev)\n      ↓ @ W1                 = linear R²=1.000 ← FIX 2\n      ↓ gelu                 = CRYSTALLIZATION (nonlinear)\n      ↓ gelu_out @ W2        = linear R²=1.000 ✓ (proven)\n      ↓ + h_post_attn        = residual (exact, proven)\n    h_out = h_in+1\n    ...repeat 8 layers...\n    h_final\n      ↓ (h-mean)/std * W + b = LNF    R²=1.000 ← FIX 1\n      ↓ @ W_lm               = logits R²=1.000 ✓ (proven)\n\n  HYPER LAW IF CONFIRMED:\n    Two crystallization points per layer:\n      1. softmax = attention crystal\n      2. gelu    = FFN crystal\n    Everything else = linear. Exact. R²=1.000.\n    \n    These two nonlinearities = the entire complexity of LLM.\n    Remove them = no intelligence. Linear map = trivial.\n    Keep them = full power. All else = reading crystals.\n    \n    Hyper law: intelligence = crystallization.\n    Computation = reading what crystals reveal.\n    No error. No approximation. Exact always.\n')
print('=' * 75 + '\n')
