import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL v4 — PARABOLIC LIFT AT ALL SCALES')
print('  Testing self-similarity of Manish Principle.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
VOCAB = model.config.vocab_size

def r2(A, Y):
    A = np.array(A, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    Ab = np.hstack([A, np.ones((len(A), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, Y, rcond=None)
    Yp = Ab @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0

def fmt(v):
    if v > 0.9999:
        return f'{v:.6f} ✓ EXACT'
    if v > 0.999:
        return f'{v:.6f} ~'
    if v > 0.99:
        return f'{v:.6f} !'
    return f'{v:.6f} ✗'
PROMPTS = ['Once upon a time a little girl named Lily', 'Deep in the forest there lived a dragon', 'A small dog ran across the green field', 'The brave knight rode into the dark cave', 'She opened the door and smiled at her friend', 'Every morning the birds sang in the tall tree', 'He found a golden key under the old bridge', 'The children played and laughed in the garden', 'Far away there lived a kind old wizard', 'A tiny mouse found some cheese in the barn', 'The princess wore a crown and sat on the throne', 'A rainbow appeared in the sky after the rain', 'The farmer planted seeds in the rich dark soil', 'She read a book about dragons and magic spells', 'The river flowed gently through the green valley', 'A butterfly landed softly on the red flower', 'The ship sailed across the deep blue ocean', 'The moon rose high above the sleeping town', 'A bear found honey in a hollow tree trunk', 'The wind carried the leaves high into the air', 'Once there was a boy who loved to explore', 'The cat sat by the warm fire and purred', 'He climbed the tall mountain and saw the sky', 'She sang a song that made everyone smile', 'A fox ran through the forest looking for food', 'The old man told stories to the young children', 'A baby bird fell from its nest in the oak', 'The cook made a soup that smelled wonderful', 'He drew a picture of his house and garden', 'The queen walked through the market with grace', 'Once a young prince found a magic mirror', 'The stars shone bright above the sleeping child', 'A little fish swam in the clear blue pond', 'The baker made fresh bread every single morning', 'She found a map that led to buried treasure', 'The little rabbit hopped through the meadow', 'Once a young boy found a magic stone', 'The old lighthouse stood by the stormy sea', 'A girl named Emma loved to paint pictures', 'The dragon breathed fire and the village ran', 'A kind witch lived in the old apple orchard', 'The tiny boat sailed far across the great lake', 'He whispered a secret into the old oak tree', 'The clever fox outsmarted the hungry wolf again', 'A magic carpet flew high above the golden city', 'The snow fell softly on the sleeping village', 'She found a door hidden behind the waterfall', 'The little prince asked why the stars were bright', 'A dragon egg hatched under the full blue moon', 'The shepherd counted stars until he fell asleep']
SEQ_LEN = 8
N_STEPS = 50
print(f'\n  SEQ_LEN={SEQ_LEN}, D={D}')
print(f'  Parabolic input dim = 2×SEQ_LEN×D = {2 * SEQ_LEN * D}')
print(f'  Need N >> {2 * SEQ_LEN * D} = {4 * SEQ_LEN * D} for reliable R²')
print(f'  Collecting {len(PROMPTS)}×{N_STEPS} = {len(PROMPTS) * N_STEPS} sequences...')
all_H = []
all_logits = []
with torch.no_grad():
    for prompt in PROMPTS:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        for step in range(N_STEPS):
            ids_use = ids[-SEQ_LEN:]
            t_ids = torch.tensor([ids_use])
            outs = model(t_ids, output_hidden_states=True)
            H_seq = np.stack([h.squeeze(0).numpy() for h in outs.hidden_states], axis=0)
            all_H.append(H_seq)
            all_logits.append(outs.logits.squeeze(0)[-1].numpy())
            out2 = model(t_ids)
            ids.append(torch.argmax(out2.logits[0, -1, :]).item())
N = len(all_H)
all_H = np.array(all_H, dtype=np.float32)
LOGITS = np.array(all_logits, dtype=np.float32)
print(f'  N={N}  (need >> {4 * SEQ_LEN * D}={4 * SEQ_LEN * D})\n')

def phi(layer_idx):
    H = all_H[:, layer_idx, :, :].reshape(N, SEQ_LEN * D).astype(np.float64)
    return np.hstack([H, H ** 2])

def phi_last(layer_idx):
    h = all_H[:, layer_idx, -1, :].astype(np.float64)
    return np.hstack([h, h ** 2])
print(f"{'=' * 70}")
print(f'  TEST 1: PARABOLIC LIFT — ALL LAYERS')
print(f'  (H_seq, H_seq²) → h[last] at layer+1')
print(f'  Confirmed 1.000 at L0 in v3. Test all layers now.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'raw seq':>12} {'+ parabolic':>14} {'verdict'}")
print(f"  {'─' * 50}")
for li in range(n_layers):
    H_out_last = all_H[:, li + 1, -1, :].astype(np.float64)
    H_raw = all_H[:, li, :, :].reshape(N, SEQ_LEN * D).astype(np.float64)
    r2_raw = r2(H_raw, H_out_last)
    Phi = phi(li)
    r2_para = r2(Phi, H_out_last)
    v = '✓ EXACT' if r2_para > 0.9999 else '~' if r2_para > 0.999 else ''
    print(f'  L{li:<7} {fmt(r2_raw):>12} {r2_para:.6f} {v}')
print(f"\n{'=' * 70}")
print(f'  TEST 2: MODEL LEVEL — LAYER 0 → FINAL')
print(f'  (H_layer0, H_layer0²) → H_final')
print(f'  If 1.000: entire model = linear in parabolic space.')
print(f"{'=' * 70}\n")
Phi_0 = phi(0)
H_final = all_H[:, -1, -1, :].astype(np.float64)
H_final_full = all_H[:, -1, :, :].reshape(N, SEQ_LEN * D).astype(np.float64)
r2_0_final_last = r2(Phi_0, H_final)
r2_0_final_full = r2(Phi_0, H_final_full)
print(f'  (H_seq_L0, H_seq_L0²) → h_final[last]:  R²={fmt(r2_0_final_last)}')
print(f'  (H_seq_L0, H_seq_L0²) → H_final[all]:   R²={fmt(r2_0_final_full)}')
Phi_0_last = phi_last(0)
r2_last_final = r2(Phi_0_last, H_final)
print(f'  (h_last_L0, h_last_L0²) → h_final[last]: R²={fmt(r2_last_final)}')
print(f"\n{'=' * 70}")
print(f'  TEST 3: FULL MODEL → LOGITS')
print(f'  (H_seq_L0, H_seq_L0²) → logits')
print(f'  If 1.000: training = one matrix inversion. O(1).')
print(f"{'=' * 70}\n")
r2_0_logits = r2(Phi_0, LOGITS.astype(np.float64))
print(f'  (H_seq_L0, H_seq_L0²) → logits: R²={fmt(r2_0_logits)}')
Phi_b = np.hstack([Phi_0, np.ones((N, 1))])
W_fit, _, _, _ = np.linalg.lstsq(Phi_b, LOGITS.astype(np.float64), rcond=None)
logits_pred = Phi_b @ W_fit
token_true = np.argmax(LOGITS, axis=1)
token_pred = np.argmax(logits_pred, axis=1)
acc = np.mean(token_true == token_pred)
print(f'  Top-token accuracy (Phi_0 → logits): {acc * 100:.1f}%')
print(f"\n{'=' * 70}")
print(f'  TEST 4: STEP-BY-STEP PARABOLIC CHAIN')
print(f'  Each layer: (H_i, H_i²) → H_i+1')
print(f'  If each step = 1.000: chain = perfect.')
print(f'  This is the W-Kernel architecture.')
print(f"{'=' * 70}\n")
print(f'  Step        R² with parabolic lift    verdict')
print(f"  {'─' * 48}")
chain_r2s = []
for li in range(n_layers):
    Phi_i = phi(li)
    H_next = all_H[:, li + 1, :, :].reshape(N, SEQ_LEN * D).astype(np.float64)
    score = r2(Phi_i, H_next)
    chain_r2s.append(score)
    v = '✓ EXACT' if score > 0.9999 else '~' if score > 0.999 else '!'
    print(f'  L{li}→L{li + 1}     {fmt(score)}    {v}')
print(f"\n{'=' * 70}")
print(f'  SUMMARY — MANISH PRINCIPLE SELF-SIMILARITY')
print(f"{'=' * 70}\n")
print(f'\n  SCALE          INPUT SPACE              R²         STATUS\n  ──────────────────────────────────────────────────────────\n  Neuron (GeLU)  (x, x²)                 1.000000   PROVEN ✓\n  Layer          (H_seq, H_seq²)→h_last  see above\n  Model          (H_L0, H_L0²)→h_final  see above\n  Full model     (H_L0, H_L0²)→logits   see above\n\n  PATTERN:\n    Natural coordinate = (tensor, tensor²) at every scale.\n    Parabolic lift = universal natural space of W.\n    \n  IF ALL R² = 1.000:\n    W-Kernel = train any transformer in one step.\n    Φ(X) = (X, X²) where X = layer 0 hidden states.\n    W = (ΦᵀΦ)⁻¹Φᵀ Y   ← one matrix inversion.\n    No epochs. No learning rate. No gradient descent.\n    \n  W PRINCIPLE:\n    W = one unit.\n    Its natural coordinate = (W, W²).\n    Parabolic = the geometry of W itself.\n    Same law. Every scale. No exceptions.\n    \n  MANISH PRINCIPLE:\n    Find the natural space.\n    In that space: everything is linear.\n    Everything is knowable.\n    Everything is W.\n')
print('=' * 70 + '\n')
