import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
NORM = 1000.0
SEQ_LEN = 4
N_QUBITS = SEQ_LEN
DIM_H = 2 ** N_QUBITS
print(f'Qubits: {N_QUBITS}')
print(f'Hilbert space: {DIM_H} dimensions')
print(f'Each state = {DIM_H} complex numbers existing simultaneously')

def Rx(theta):
    c = torch.cos(theta / 2)
    s = torch.sin(theta / 2)
    real = torch.stack([torch.stack([c, torch.zeros_like(c)], dim=-1), torch.stack([torch.zeros_like(c), c], dim=-1)], dim=-2)
    imag = torch.stack([torch.stack([torch.zeros_like(s), -s], dim=-1), torch.stack([-s, torch.zeros_like(s)], dim=-1)], dim=-2)
    return (real, imag)

def Ry(theta):
    c = torch.cos(theta / 2)
    s = torch.sin(theta / 2)
    real = torch.stack([torch.stack([c, -s], dim=-1), torch.stack([s, c], dim=-1)], dim=-2)
    imag = torch.zeros_like(real)
    return (real, imag)

def Rz(theta):
    c = torch.cos(theta / 2)
    s = torch.sin(theta / 2)
    zero = torch.zeros_like(c)
    real = torch.stack([torch.stack([c, zero], dim=-1), torch.stack([zero, c], dim=-1)], dim=-2)
    imag = torch.stack([torch.stack([-s, zero], dim=-1), torch.stack([zero, s], dim=-1)], dim=-2)
    return (real, imag)

def apply_single_qubit_gate(state_r, state_i, gate_r, gate_i, qubit, n_qubits):
    batch = state_r.shape[0]
    dim = 2 ** n_qubits
    half = dim // 2
    new_r = state_r.clone()
    new_i = state_i.clone()
    step = 2 ** qubit
    for i in range(0, dim, 2 * step):
        for j in range(i, i + step):
            idx0 = j
            idx1 = j + step
            a_r, a_i = (state_r[:, idx0], state_i[:, idx0])
            b_r, b_i = (state_r[:, idx1], state_i[:, idx1])
            g00r, g00i = (gate_r[:, 0, 0], gate_i[:, 0, 0])
            g01r, g01i = (gate_r[:, 0, 1], gate_i[:, 0, 1])
            g10r, g10i = (gate_r[:, 1, 0], gate_i[:, 1, 0])
            g11r, g11i = (gate_r[:, 1, 1], gate_i[:, 1, 1])
            new_r[:, idx0] = g00r * a_r - g00i * a_i + (g01r * b_r - g01i * b_i)
            new_i[:, idx0] = g00r * a_i + g00i * a_r + (g01r * b_i + g01i * b_r)
            new_r[:, idx1] = g10r * a_r - g10i * a_i + (g11r * b_r - g11i * b_i)
            new_i[:, idx1] = g10r * a_i + g10i * a_r + (g11r * b_i + g11i * b_r)
    return (new_r, new_i)

def apply_cnot(state_r, state_i, control, target, n_qubits):
    dim = 2 ** n_qubits
    new_r = state_r.clone()
    new_i = state_i.clone()
    for i in range(dim):
        if i >> control & 1:
            j = i ^ 1 << target
            if j > i:
                new_r[:, i], new_r[:, j] = (state_r[:, j].clone(), state_r[:, i].clone())
                new_i[:, i], new_i[:, j] = (state_i[:, j].clone(), state_i[:, i].clone())
    return (new_r, new_i)

class QuantumLayer(nn.Module):

    def __init__(self, n_qubits):
        super().__init__()
        self.n_qubits = n_qubits
        self.theta_x = nn.Parameter(torch.randn(n_qubits) * 0.1)
        self.theta_y = nn.Parameter(torch.randn(n_qubits) * 0.1)
        self.theta_z = nn.Parameter(torch.randn(n_qubits) * 0.1)

    def forward(self, state_r, state_i):
        batch = state_r.shape[0]
        for q in range(self.n_qubits):
            theta_x = self.theta_x[q].expand(batch)
            theta_y = self.theta_y[q].expand(batch)
            theta_z = self.theta_z[q].expand(batch)
            gr, gi = Rx(theta_x)
            state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
            gr, gi = Ry(theta_y)
            state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
            gr, gi = Rz(theta_z)
            state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
        for q in range(self.n_qubits - 1):
            state_r, state_i = apply_cnot(state_r, state_i, q, q + 1, self.n_qubits)
        return (state_r, state_i)

class QuantumCircuit(nn.Module):

    def __init__(self, n_qubits, n_layers, seq_len=SEQ_LEN):
        super().__init__()
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.dim_h = 2 ** n_qubits
        self.encoder = nn.Linear(seq_len, n_qubits * 3)
        self.q_layers = nn.ModuleList([QuantumLayer(n_qubits) for _ in range(n_layers)])
        self.measure = nn.Linear(self.dim_h, 1)

    def forward(self, x):
        batch = x.shape[0]
        state_r = torch.zeros(batch, self.dim_h, device=x.device)
        state_i = torch.zeros(batch, self.dim_h, device=x.device)
        state_r[:, 0] = 1.0
        angles = self.encoder(x)
        angles = angles.view(batch, self.n_qubits, 3)
        for q in range(self.n_qubits):
            theta_x = angles[:, q, 0]
            theta_y = angles[:, q, 1]
            theta_z = angles[:, q, 2]
            gr, gi = Rx(theta_x)
            state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
            gr, gi = Ry(theta_y)
            state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
            gr, gi = Rz(theta_z)
            state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
        for q in range(self.n_qubits - 1):
            state_r, state_i = apply_cnot(state_r, state_i, q, q + 1, self.n_qubits)
        for layer in self.q_layers:
            state_r, state_i = layer(state_r, state_i)
        probabilities = state_r ** 2 + state_i ** 2
        return self.measure(probabilities)

    def state_analysis(self, x):
        batch = x.shape[0]
        state_r = torch.zeros(batch, self.dim_h, device=x.device)
        state_i = torch.zeros(batch, self.dim_h, device=x.device)
        state_r[:, 0] = 1.0
        angles = self.encoder(x).view(batch, self.n_qubits, 3)
        for q in range(self.n_qubits):
            for gate_fn, idx in [(Rx, 0), (Ry, 1), (Rz, 2)]:
                gr, gi = gate_fn(angles[:, q, idx])
                state_r, state_i = apply_single_qubit_gate(state_r, state_i, gr, gi, q, self.n_qubits)
        for q in range(self.n_qubits - 1):
            state_r, state_i = apply_cnot(state_r, state_i, q, q + 1, self.n_qubits)
        states = []
        for layer in self.q_layers:
            state_r, state_i = layer(state_r, state_i)
            probs = (state_r ** 2 + state_i ** 2)[0]
            n_active = (probs > 0.01).sum().item()
            entropy = -(probs * torch.log(probs + 1e-10)).sum().item()
            max_prob = probs.max().item()
            states.append({'n_active': n_active, 'entropy': entropy, 'max_prob': max_prob, 'norm': probs.sum().item()})
        return states

class FlatResBlock(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.l = nn.Linear(d, d)
        self.a = nn.Tanh()

    def forward(self, x):
        return self.a(self.l(x)) + x

class FlatNet(nn.Module):

    def __init__(self, dim, nb, sl=SEQ_LEN):
        super().__init__()
        self.p = nn.Sequential(nn.Linear(sl, dim), nn.Tanh())
        self.b = nn.ModuleList([FlatResBlock(dim) for _ in range(nb)])
        self.o = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.p(x)
        for b in self.b:
            x = b(x)
        return self.o(x)

class ComplexResBlock(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.wr = nn.Linear(d, d)
        self.wi = nn.Linear(d, d, bias=False)
        nn.init.normal_(self.wi.weight, std=0.01)
        self.b = nn.Parameter(torch.zeros(d) - 1.0)

    def forward(self, xr, xi):
        yr = self.wr(xr) - self.wi(xi)
        yi = self.wr(xi) + self.wi(xr)
        m = torch.sqrt(yr ** 2 + yi ** 2 + 1e-08)
        g = F.relu(m + self.b) / m
        return (xr + yr * g, xi + yi * g)

class ComplexNet(nn.Module):

    def __init__(self, dim, nb, sl=SEQ_LEN):
        super().__init__()
        self.ir = nn.Linear(sl, dim)
        self.ii = nn.Linear(sl, dim)
        nn.init.normal_(self.ii.weight, std=0.01)
        self.b = nn.ModuleList([ComplexResBlock(dim) for _ in range(nb)])
        self.o = nn.Linear(dim, 1)

    def forward(self, x):
        xr = torch.tanh(self.ir(x))
        xi = torch.tanh(self.ii(x))
        for b in self.b:
            xr, xi = b(xr, xi)
        return self.o(torch.sqrt(xr ** 2 + xi ** 2 + 1e-08))

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05
X, Y = gen_sequences()
sp = int(len(X) * 0.8)
X_tr, Y_tr = (X[:sp].to(device), Y[:sp].to(device))
X_te, Y_te = (X[sp:].to(device), Y[sp:].to(device))
print(f'Sequences: {len(X)}')

def train(model, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model)
            print(f'    {label:<26} ep{ep:>5}  loss={best:>12.6f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 3000
configs = [('Flat dim=16 b=10', FlatNet(16, 10)), ('Flat dim=16 b=74', FlatNet(16, 74)), ('Complex dim=16 b=10', ComplexNet(16, 10)), ('Quantum 4q layers=2', QuantumCircuit(N_QUBITS, 2)), ('Quantum 4q layers=4', QuantumCircuit(N_QUBITS, 4)), ('Quantum 4q layers=8', QuantumCircuit(N_QUBITS, 8)), ('Quantum 4q layers=16', QuantumCircuit(N_QUBITS, 16))]
print_sep('TRUE QUANTUM CIRCUIT vs CLASSICAL')
print(f'  Quantum Hilbert space: {DIM_H} dimensions from {N_QUBITS} qubits')
print(f'  All quantum ops: UNITARY (zero information loss)')
print(f'  Entanglement: CNOT (non-separable joint state)')
print(f'  Interference: complex amplitudes cancel/amplify\n')
results = []
for label, model in configs:
    model = model.to(device)
    params = sum((p.numel() for p in model.parameters()))
    print(f'\n  ── {label} (params={params:,}) ──')
    np.random.seed(42)
    loss, log = train(model, EPOCHS, lr=0.001, label=label)
    s = score(model)
    results.append((label, params, loss, s, model, log))
print_sep('QUANTUM STATE ANALYSIS — Interference in action')
best_q = min([r for r in results if 'Quantum' in r[0] and r[3] > 0], key=lambda x: x[2], default=None)
if best_q:
    print(f'\n  Analyzing: {best_q[0]}')
    print(f"  {'Layer':>6}  {'Active dims':>12}  {'Entropy':>10}  {'Max prob':>10}  {'Norm':>8}")
    print(f"  {'─' * 55}")
    best_q[4].eval()
    with torch.no_grad():
        xt = torch.tensor([[v / NORM for v in TESTS[0][0]]], dtype=torch.float32).to(device)
        states = best_q[4].state_analysis(xt)
        for i, st in enumerate(states):
            print(f"  {i + 1:>6}  {st['n_active']:>12}  {st['entropy']:>10.4f}  {st['max_prob']:>10.4f}  {st['norm']:>8.4f}")
print_sep('FINAL SCOREBOARD')
results_s = sorted(results, key=lambda x: (-x[3], x[2]))
print(f"\n  {'Model':<26}  {'Params':>8}  {'Score':>7}  {'Loss':>14}  Type")
print(f"  {'─' * 72}")
for rank, (label, params, loss, s, _, _) in enumerate(results_s):
    if 'Quantum' in label:
        typ = 'QUANTUM'
    elif 'Complex' in label:
        typ = 'complex'
    else:
        typ = 'flat'
    mark = ' ← WINNER' if rank == 0 else ''
    print(f'  {label:<26}  {params:>8,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {typ}{mark}')
print_sep('WHAT THE QUANTUM RESULT MEANS')
best_flat_r = min([r for r in results if 'Flat' in r[0]], key=lambda x: x[2])
best_q_r = min([r for r in results if 'Quantum' in r[0]], key=lambda x: x[2])
print(f'\n  Classical flat best: loss={best_flat_r[2]:.6f} params={best_flat_r[1]:,}\n  Quantum circuit best: loss={best_q_r[2]:.6f} params={best_q_r[1]:,}\n\n  TRUE QUANTUM PROPERTIES PRESENT:\n  ✓ Unitary gates only — zero information destroyed\n  ✓ CNOT entanglement — non-separable joint state\n  ✓ Complex amplitudes — constructive+destructive interference\n  ✓ Born rule measurement — collapse happens ONCE\n  ✓ 4 qubits = 16D Hilbert space simultaneously\n\n  If quantum wins:\n    Interference cancels wrong answers naturally\n    No training needed to learn what to cancel\n    The STRUCTURE does the computation\n    This is the natural space of intelligence\n\n  If quantum needs more layers:\n    More interference cycles = more cancellation\n    Like more reflections in an interferometer\n    Signal gets cleaner with each layer\n    \n  Next step if promising:\n    8 qubits = 256D Hilbert space\n    More expressive, same structural principle\n    Test: does scaling qubits unlock more power?\n')
