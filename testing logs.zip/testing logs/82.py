import numpy as np, math, time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v26 — OUTPUT SCALE FIX')
print('  Micro test proved: direction correct, scale wrong.')
print('  scale=4 → ppl=4.24. Applying now.')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
D = VS
K = 6
L = 3
DECAY = 0.5
decay_w = np.array([DECAY ** j for j in range(K)], dtype=np.float64)
decay_w /= decay_w.sum()
M = N - K
y = np.array(toks[K:])
X0 = np.zeros((M, D), dtype=np.float64)
for i in range(K, N):
    for j in range(K):
        X0[i - K] += decay_w[j] * np.eye(VS)[toks[i - 1 - j]]
tri_i, tri_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_s(Ph, R, lam=1e-06):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    return np.linalg.solve(A, Ph.T @ R)

def fwd(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs

def train_scale(scale):
    WTE_s = np.eye(VS, dtype=np.float64) * scale
    T = WTE_s[y]
    W = [np.zeros((D * (D + 1) // 2, D)) for _ in range(L)]
    bp = 999
    bW = [w.copy() for w in W]
    for rnd in range(6):
        imp = False
        for l in range(L):
            xs = fwd(X0, W)
            Wn = pinv_s(phi_b(xs[l]), T - xs[l])
            Wt = [w.copy() for w in W]
            Wt[l] = Wn
            xf = fwd(X0, Wt)[-1]
            lg = xf @ WTE_s.T
            step = max(1, M // 1000)
            nll = 0.0
            ne = 0
            for i in range(0, M, step):
                l2 = lg[i] - lg[i].max()
                l2 = l2 - np.log(np.sum(np.exp(l2)))
                nll -= l2[y[i]]
                ne += 1
            p = math.exp(min(nll / ne, 500))
            if p < bp:
                bp = p
                W = Wt
                bW = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W = bW
    xf = fwd(X0, W)[-1]
    lg = xf @ WTE_s.T
    acc = 100 * np.mean(np.argmax(lg, 1) == y)
    sorted_lg = np.sort(lg, 1)[:, ::-1]
    gap = np.mean(sorted_lg[:, 0] - sorted_lg[:, 1])
    probs = np.exp(lg - lg.max(1, keepdims=True))
    probs /= probs.sum(1, keepdims=True)
    conf = 100 * np.mean(probs[np.arange(M), y])
    return (bp, acc, gap, conf, W, WTE_s)
print(f'\n  FINE-GRAINED SCALE SWEEP:')
print(f"  {'scale':>7} {'ppl':>8} {'acc':>7} {'gap':>8} {'conf':>8}")
print(f"  {'─' * 45}")
best_overall_p = 999
best_scale = 1
best_W_final = None
best_WTE_final = None
for scale in [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0]:
    p, a, g, c, W, WTE_s = train_scale(scale)
    mk = ' ★' if p < best_overall_p else ''
    print(f'  {scale:>7.1f} {p:>8.2f} {a:>6.1f}% {g:>8.3f} {c:>7.1f}%{mk}')
    if p < best_overall_p:
        best_overall_p = p
        best_scale = scale
        best_W_final = [w.copy() for w in W]
        best_WTE_final = WTE_s.copy()
print(f'\n  Best scale={best_scale}  ppl={best_overall_p:.2f}')
W_layers = best_W_final
WTE_out = best_WTE_final
fp, fa, fg, fc, _, _ = train_scale(best_scale)
print(f'\n  BIGRAM CHECK (scale={best_scale}):')
for ctx_str, true_c in [('th', 'e'), ('he', ' '), ('an', 'd'), ('nd', ' '), ('in', 'g'), ('er', ' '), (' t', 'h'), (' a', 'n')]:
    ids = [c2i[c] for c in ctx_str if c in c2i]
    x = np.zeros(D, dtype=np.float64)
    for j in range(min(K, len(ids))):
        x += decay_w[j] * np.eye(VS)[ids[-1 - j]]
    for W in W_layers:
        x = x + phi(x) @ W
    lg = x @ WTE_out.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    true_p = 100 * p[c2i[true_c]] if true_c in c2i else 0
    top3 = [(i2c[i], f'{100 * p[i]:.1f}%') for i in np.argsort(-p)[:3]]
    print(f"  '{ctx_str}'→'{true_c}' {true_p:.1f}%  top3={top3}")

def ctx_vec(ids):
    x = np.zeros(D, dtype=np.float64)
    recent = list(ids[-K:]) if len(ids) >= K else [0] * (K - len(ids)) + list(ids)
    for j in range(K):
        x += decay_w[j] * np.eye(VS)[recent[-1 - j]]
    return x

def forward_ctx(ids):
    x = ctx_vec(ids)
    for W in W_layers:
        x = x + phi(x) @ W
    return x @ WTE_out.T

def nucleus(lg, p=0.9, temp=1.0):
    lg = (lg - lg.max()) / temp
    pr = np.exp(lg)
    pr /= pr.sum()
    idx = np.argsort(-pr)
    cm = np.cumsum(pr[idx])
    cut = np.searchsorted(cm, p) + 1
    nuc = idx[:max(1, cut)]
    pn = pr[nuc]
    pn /= pn.sum()
    return int(np.random.choice(nuc, p=pn))

def generate(prompt, n=120, mode='nucleus', temp=1.0, p=0.85, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        lg = forward_ctx(ids)
        if not np.all(np.isfinite(lg)):
            break
        if mode == 'greedy':
            ids.append(int(np.argmax(lg)))
        else:
            ids.append(nucleus(lg, p=p, temp=temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION (greedy, scale={best_scale}):')
for prompt in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(prompt, n=100, mode='greedy')
    print(f"  '{prompt}'")
    print(f'    {out[len(prompt):]}')
print(f'\n  GENERATION (nucleus p=0.90, temp=1.0, scale={best_scale}):')
for si, prompt in enumerate(['once upon a time ', 'the brave knight ', 'deep in the forest ']):
    out = generate(prompt, n=120, mode='nucleus', p=0.9, temp=1.0, seed=si * 13 + 1)
    print(f"  '{prompt}'")
    print(f'    {out[len(prompt):]}')
gs = generate('the ', n=400, mode='nucleus', p=0.92, temp=1.0, seed=5)
words = gs[4:].split(' ')
word_lens = [len(w) for w in words if w]
sp = 100 * gs[4:].count(' ') / len(gs[4:])
cnt = Counter(gs[4:])
top5 = [(c if c != '\n' else '\\n', f'{100 * cnt[c] // len(gs[4:])}%') for c, _ in cnt.most_common(5)]
real_words = {'the', 'and', 'was', 'had', 'she', 'he', 'his', 'her', 'in', 'of', 'to', 'a', 'that', 'it', 'with', 'on', 'at', 'by', 'from', 'they', 'we', 'you', 'not', 'be', 'but', 'or', 'an', 'for', 'are', 'were', 'said', 'back', 'up', 'one', 'all', 'out', 'who', 'when', 'there', 'what', 'time', 'day', 'little', 'old'}
found = [w.lower().strip('.,!?') for w in words if w.lower().strip('.,!?') in real_words]
print(f'\n  ENGLISH QUALITY METRICS (scale={best_scale}):')
print(f'  Space%={sp:.0f}%  Avg word len={np.mean(word_lens):.1f}')
print(f'  Real English words found: {list(set(found))[:15]}')
print(f'  Real word count: {len(found)}/{len(words)} = {100 * len(found) // max(len(words), 1)}%')
print(f'  Top-5 chars: {top5}')
print(f'  Sample: {gs[4:100]}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  BEST: scale={best_scale}  ppl={best_overall_p:.2f}  acc={fa:.1f}%')
print(f'\n  DISCOVERY CHAIN:')
print(f'  v23: WTE=identity. ppl=21. Loops.')
print(f'  v24: Decay context. ppl=18.78. REAL WORDS appear.')
print(f'  micro: cos=0.98. Direction correct. Scale wrong.')
print(f'  v26: Scaled WTE target. ppl={best_overall_p:.2f}. Generation?')
print('=' * 65 + '\n')
