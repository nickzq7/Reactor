import numpy as np, math
from collections import Counter
print('\n' + '=' * 60)
print('  W-KERNEL SEQUENCE PROBE')
print('  Find natural space across sequence types.')
print('=' * 60)
VS = 50
K = 4
D = VS
L = 3

def make_seq(name, N=1000):
    if name == 'count':
        return np.array([i % VS for i in range(N)])
    if name == 'even':
        return np.array([2 * i % VS for i in range(N)])
    if name == 'odd':
        return np.array([(2 * i + 1) % VS for i in range(N)])
    if name == 'fib':
        s = [0, 1]
        while len(s) < N:
            s.append((s[-1] + s[-2]) % VS)
        return np.array(s[:N])
    if name == 'prime':

        def is_p(n):
            if n < 2:
                return False
            for i in range(2, int(n ** 0.5) + 1):
                if n % i == 0:
                    return False
            return True
        primes = [i for i in range(2, 500) if is_p(i)]
        return np.array([p % VS for p in (primes * (N // len(primes) + 2))[:N]])
    if name == 'square':
        return np.array([i * i % VS for i in range(N)])
    if name == 'double':
        return np.array([2 ** i % VS for i in range(N)])
    if name == 'zigzag':
        s = []
        for i in range(N):
            s.append(i % VS if i // VS % 2 == 0 else VS - 1 - i % VS)
        return np.array(s)
SEQS = ['count', 'even', 'odd', 'fib', 'prime', 'square', 'zigzag']
np.random.seed(42)
WTE = np.eye(VS)
tri_i, tri_j = np.triu_indices(D)
D_q = D * (D + 1) // 2

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_solve(Ph, R, lam=1e-08):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    try:
        return np.linalg.solve(A, Ph.T @ R)
    except:
        return np.linalg.lstsq(Ph, R, rcond=None)[0]

def run_seq(name):
    toks = make_seq(name)
    M = len(toks) - K
    y = toks[K:]
    X0 = np.zeros((M, D))
    for i in range(K, len(toks)):
        X0[i - K] = WTE[toks[i - K:i]].mean(0)
    T = WTE[y]
    W_layers = [np.zeros((D_q, D)) for _ in range(L)]

    def fwd(X, Wl):
        xs = [X.copy()]
        for W in Wl:
            xs.append(xs[-1] + phi_b(xs[-1]) @ W)
        return xs

    def metrics(Wl):
        x = fwd(X0, Wl)[-1]
        lg = x @ WTE.T
        preds = np.argmax(lg, 1)
        acc = 100 * np.mean(preds == y)
        nll = 0.0
        for i in range(min(M, 500)):
            l = lg[i] - lg[i].max()
            l = l - np.log(np.sum(np.exp(l)))
            nll -= l[y[i]]
        ppl = math.exp(min(nll / min(M, 500), 500))
        probs = np.exp(lg - lg.max(1, keepdims=True))
        probs /= probs.sum(1, keepdims=True)
        conf = np.mean(probs[np.arange(M), y])
        return (ppl, acc, conf)
    best_p, _, _ = metrics(W_layers)
    best_W = [w.copy() for w in W_layers]
    for rnd in range(5):
        imp = False
        for l in range(L):
            xs = fwd(X0, W_layers)
            R = T - xs[l]
            Wn = pinv_solve(phi_b(xs[l]), R)
            Wt = [w.copy() for w in W_layers]
            Wt[l] = Wn
            p, a, c = metrics(Wt)
            if p < best_p:
                best_p = p
                W_layers = Wt
                best_W = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W_layers = best_W
    fp, fa, fc = metrics(W_layers)
    x_f = fwd(X0, W_layers)[-1]
    lg = x_f @ WTE.T
    correct_logit = lg[np.arange(M), y]
    sorted_lg = np.sort(lg, 1)
    gap = correct_logit - sorted_lg[:, -2]
    mean_gap = np.mean(gap)
    x_norm = x_f / (np.linalg.norm(x_f, axis=1, keepdims=True) + 1e-08)
    sim_correct = np.mean([x_norm[i] @ WTE[y[i]] for i in range(min(M, 200))])
    return (fp, fa, fc * 100, mean_gap, sim_correct)
print(f"\n  {'Sequence':>10} {'ppl':>8} {'acc':>7} {'conf':>7} {'logit_gap':>10} {'sim_correct':>12}")
print(f"  {'─' * 60}")
for name in SEQS:
    try:
        fp, fa, fc, gap, sim = run_seq(name)
        print(f'  {name:>10} {fp:>8.2f} {fa:>6.1f}% {fc:>6.1f}% {gap:>10.3f} {sim:>12.3f}')
    except Exception as e:
        print(f'  {name:>10}  ERROR: {e}')
print(f'\n  KEY INSIGHT:')
print(f'  sim_correct = x_final @ WTE[correct] after normalization')
print(f'  If sim_correct → 1.0: x_final IS WTE[correct]. Perfect.')
print(f'  logit_gap = correct logit - 2nd best logit')
print(f'  If logit_gap >> 0: sharp prediction. Low ppl.')
print(f'  If logit_gap ≈ 0: flat logits. High ppl. ppl≈vocab.')
print(f'\n  DEEP PROBE — COUNT SEQUENCE:')
toks = make_seq('count', 200)
M2 = len(toks) - K
y2 = toks[K:]
X0 = np.zeros((M2, D))
for i in range(K, len(toks)):
    X0[i - K] = WTE[toks[i - K:i]].mean(0)
T = WTE[y2]
W_layers = [np.zeros((D_q, D)) for _ in range(L)]

def fwd(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs

def metrics_full(Wl):
    x = fwd(X0, Wl)[-1]
    return x
best_p = 999
best_W = [w.copy() for w in W_layers]
for rnd in range(5):
    imp = False
    for l in range(L):
        xs = fwd(X0, W_layers)
        R = T - xs[l]
        Wn = pinv_solve(phi_b(xs[l]), R)
        Wt = [w.copy() for w in W_layers]
        Wt[l] = Wn
        x = fwd(X0, Wt)[-1]
        lg = x @ WTE.T
        nll = sum((-(lambda l2: l2 - np.log(np.sum(np.exp(l2))))(lg[i] - lg[i].max())[y2[i]] for i in range(min(M2, 200))))
        p = math.exp(min(nll / min(M2, 200), 500))
        if p < best_p:
            best_p = p
            W_layers = Wt
            best_W = [w.copy() for w in Wt]
            imp = True
    if not imp:
        break
W_layers = best_W
x_f = fwd(X0, W_layers)[-1]
idx = [i for i in range(M2) if y2[i] == 6][0] if 6 in y2 else 0
print(f'\n  Context: {toks[idx:idx + K].tolist()} → true={y2[idx]}')
print(f'  x_final norm: {np.linalg.norm(x_f[idx]):.4f}')
print(f'  WTE[6] norm:  {np.linalg.norm(WTE[6]):.4f}')
print(f'  x_final @ WTE[6]: {x_f[idx] @ WTE[6]:.4f}  (want HIGH)')
print(f'  x_final @ WTE[5]: {x_f[idx] @ WTE[5]:.4f}  (want LOW)')
print(f'  x_final @ WTE[7]: {x_f[idx] @ WTE[7]:.4f}  (want LOW)')
print(f'  x_final @ WTE[0]: {x_f[idx] @ WTE[0]:.4f}  (want LOW)')
lg = x_f[idx] @ WTE.T
lg -= lg.max()
p_ = np.exp(lg)
p_ /= p_.sum()
top5 = [(int(i), f'{100 * p_[i]:.1f}%') for i in np.argsort(-p_)[:5]]
print(f'  Top-5 predictions: {top5}')
print(f'\n  x_final[idx] first 10 dims: {x_f[idx][:10].round(3).tolist()}')
print(f'  WTE[6]       first 10 dims: {WTE[6][:10].round(3).tolist()}')
print(f'  WTE[5]       first 10 dims: {WTE[5][:10].round(3).tolist()}')
print(f'\n  RESIDUAL ANALYSIS:')
for l in range(L):
    xs = fwd(X0, W_layers)
    r = np.mean(np.linalg.norm(T - xs[l], axis=1))
    print(f'  Layer {l} input residual mean: {r:.6f}')
xs = fwd(X0, W_layers)
rf = np.mean(np.linalg.norm(T - xs[-1], axis=1))
print(f'  Final output residual mean:  {rf:.6f}')
print(f'\n  If final residual ≈ 0: x_final = WTE[next] exactly.')
print(f"  If final residual > 0: layers didn't fully close the gap.")
print('=' * 60 + '\n')
