import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer
import copy
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}')

def r2(a, b):
    a = np.array(a, dtype=np.float64).flatten()
    b = np.array(b, dtype=np.float64).flatten()
    ss = np.sum((a - b) ** 2)
    st = np.sum((b - b.mean()) ** 2)
    return float(1 - ss / st) if st > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    ss_res = np.sum((Xb[s:] @ W - Y[s:]) ** 2)
    ss_tot = np.sum((Y[s:] - Y[s:].mean(0, keepdims=True)) ** 2)
    return (float(r2(Xb[:s] @ W, Y[:s])), float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0)
texts = ['Once upon a time there was a little girl named', 'The farmer woke up early and fed all his', 'Deep in the forest a family of bears lived', 'The brave knight rode his white horse toward the', 'Sophie loved books more than anything else in', 'The village held a harvest festival every autumn', 'Tommy was afraid of the dark and could not', 'Marco sailed across the vast blue ocean every', 'The mountains were cold and the children learned', 'She smiled because today was her birthday', 'Two friends shared every secret since their', 'A rabbit lived under the roots of the old', 'The grandmother welcomed every lost traveler', 'Sam found a puppy hiding under the old', 'The dragon had never spoken before the', 'In the ocean a fish dreamed of the world', 'The clock had been silent for twenty years before', 'A small seed grew slowly into a mighty', 'The painter stared at the blank canvas before', 'Every evening the grandfather told his grandchildren']
print(f'\nCollecting hidden states all layers...')
h_store = {li: [] for li in range(n_layers + 1)}
logits_store = []
correct_tokens = []
cur_h = {li: None for li in range(n_layers + 1)}
hooks = []

def make_emb(l):

    def h(m, i, o):
        cur_h[0] = o.detach().float()[0].numpy().copy()
    return h
hooks.append(model.transformer.wte.register_forward_hook(make_emb(0)))
for li in range(n_layers):

    def make_hl(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur_h[l + 1] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].register_forward_hook(make_hl(li)))
with torch.no_grad():
    for text in texts:
        for li in range(n_layers + 1):
            cur_h[li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=32, truncation=True)
        L = toks['input_ids'].shape[1]
        out = model(**toks)
        logits = out.logits[0, -1, :].numpy()
        correct_tok = int(np.argmax(logits))
        logits_store.append(logits)
        correct_tokens.append(correct_tok)
        for li in range(n_layers + 1):
            if cur_h[li] is not None:
                h_store[li].append(cur_h[li][-1].copy())
for h in hooks:
    h.remove()
H = {li: np.array(h_store[li], dtype=np.float64) for li in range(n_layers + 1) if h_store[li]}
LOGITS = np.array(logits_store, dtype=np.float64)
N = len(H[0])
print(f'  Sequences: {N}')
print(f"\n{'=' * 70}")
print(f'  TEST A — h_l → final_logits: R² per layer')
print(f'  Does early h predict final output?')
print(f'  h_0=embedding. h_8=after all layers.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'Description':<25} {'R²_te':<12} {'Status'}")
print(f"  {'─' * 55}")
for li in range(n_layers + 1):
    if li not in H:
        continue
    _, r2_te = fit_r2(H[li], LOGITS)
    desc = 'embedding(+pos)' if li == 0 else f'after layer {li - 1}'
    status = '✓✓' if r2_te > 0.999 else '✓' if r2_te > 0.99 else '~' if r2_te > 0.9 else '·' if r2_te > 0.5 else '✗'
    print(f'  {li:<8} {desc:<25} {r2_te:<12.6f} {status}')
print(f"\n{'=' * 70}")
print(f'  TEST B — h_l → h_final (last layer output)')
print(f'  Smooth rise = coordinate change only.')
print(f'  Jump at layer l = information created at l.')
print(f"{'=' * 70}\n")
h_final = H[n_layers]
print(f"  {'From layer':<12} {'R²_te':<12} {'Status'}")
print(f"  {'─' * 35}")
for li in range(n_layers + 1):
    if li not in H:
        continue
    if li == n_layers:
        print(f"  {li:<12} {'1.000000':<12} SELF")
        continue
    _, r2_te = fit_r2(H[li], h_final)
    status = '✓✓ EXACT' if r2_te > 0.999 else '✓ NEAR' if r2_te > 0.99 else '~ STRONG' if r2_te > 0.9 else '· PARTIAL' if r2_te > 0.5 else '✗ LOW'
    print(f'  {li:<12} {r2_te:<12.6f} {status}')
print(f"\n{'=' * 70}")
print(f'  TEST C — CORRECT TOKEN PROBABILITY AT EACH LAYER')
print(f'  Apply LNF + lm_head to h_l directly.')
print(f'  P(correct_token | h_l) = ?')
print(f'  If high at l=0: answer in embedding. Layers = reveal.')
print(f"{'=' * 70}\n")
LNF = model.transformer.ln_f
lmhead = model.lm_head
print(f"  {'Layer':<8} {'Mean_P(correct)':<20} {'Mean_rank(correct)':<22} {'Top1_accuracy'}")
print(f"  {'─' * 65}")
for li in range(n_layers + 1):
    if li not in H or len(H[li]) == 0:
        continue
    probs_correct = []
    ranks_correct = []
    top1_correct = []
    with torch.no_grad():
        for idx in range(N):
            h_t = torch.tensor(H[li][idx], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
            lnf_out = LNF(h_t)
            logits_t = lmhead(lnf_out)[0, 0, :].numpy()
            probs = F.softmax(torch.tensor(logits_t), dim=-1).numpy()
            correct_tok = correct_tokens[idx]
            p_correct = float(probs[correct_tok])
            rank = int(np.sum(logits_t > logits_t[correct_tok]))
            top1 = int(np.argmax(logits_t) == correct_tok)
            probs_correct.append(p_correct)
            ranks_correct.append(rank)
            top1_correct.append(top1)
    mean_p = np.mean(probs_correct)
    mean_r = np.mean(ranks_correct)
    acc = np.mean(top1_correct)
    print(f'  {li:<8} {mean_p:<20.6f} {mean_r:<22.2f} {acc:.3f}')
print(f"\n{'=' * 70}")
print(f'  TEST D — LAYER REMOVAL: which layers change the answer?')
print(f'  Skip each layer individually.')
print(f'  Count: how often does top-1 prediction change?')
print(f'  Change% = 0%: layer = pure refinement. Skippable.')
print(f'  Change% > 0%: layer = information. Cannot skip.')
print(f"{'=' * 70}\n")
baseline_preds = []
with torch.no_grad():
    for text in texts:
        toks = tokenizer(text, return_tensors='pt', max_length=32, truncation=True)
        out = model(**toks)
        pred = int(out.logits[0, -1, :].argmax())
        baseline_preds.append(pred)
print(f"  {'Layer':<8} {'Type':<10} {'Change%':<12} {'Skippable?'}")
print(f"  {'─' * 45}")
for skip_li in range(n_layers):
    model_skip = copy.deepcopy(model)
    model_skip.eval()
    original_forward = model_skip.transformer.h[skip_li].forward

    def make_identity(orig_forward):

        def identity_forward(hidden_states, *args, **kwargs):
            if isinstance(hidden_states, tuple):
                hidden_states = hidden_states[0]
            outputs = orig_forward(hidden_states, *args, **kwargs)
            if isinstance(outputs, tuple):
                return (hidden_states,) + outputs[1:]
            return hidden_states
        return identity_forward
    model_skip.transformer.h[skip_li].forward = make_identity(original_forward)
    changed = 0
    with torch.no_grad():
        for idx, text in enumerate(texts):
            toks = tokenizer(text, return_tensors='pt', max_length=32, truncation=True)
            out = model_skip(**toks)
            pred = int(out.logits[0, -1, :].argmax())
            if pred != baseline_preds[idx]:
                changed += 1
    change_pct = changed / len(texts) * 100
    att_type = model.transformer.h[skip_li].attn.attention_type
    skippable = 'YES ✓' if change_pct == 0 else f'NO  ({change_pct:.0f}% changed)'
    print(f'  {skip_li:<8} {att_type:<10} {change_pct:<12.1f} {skippable}')
    del model_skip
print(f"\n{'=' * 70}")
print(f'  TEST E — MINIMUM LAYER SUBSET')
print(f'  Find minimum set of layers for same top-1.')
print(f'  Greedy: add layers one by one by importance.')
print(f"{'=' * 70}\n")
print(f'  Testing: how many layers needed for 100% match?')
print(f"  {'Layers used':<15} {'Top1 match%':<15}")
print(f"  {'─' * 30}")
for k in range(1, n_layers + 1):

    class PartialModel(torch.nn.Module):

        def __init__(self, base, k):
            super().__init__()
            self.base = base
            self.k = k

        def forward(self, input_ids):
            h = self.base.transformer.wte(input_ids)
            pos = torch.arange(input_ids.shape[1]).unsqueeze(0)
            h = h + self.base.transformer.wpe(pos)
            for li in range(self.k):
                out = self.base.transformer.h[li](h)
                h = out[0] if isinstance(out, tuple) else out
            h = self.base.transformer.ln_f(h)
            return self.base.lm_head(h)
    pm = PartialModel(model, k)
    match = 0
    with torch.no_grad():
        for idx, text in enumerate(texts):
            toks = tokenizer(text, return_tensors='pt', max_length=32, truncation=True)
            out = pm(toks['input_ids'])
            pred = int(out[0, -1, :].argmax())
            if pred == baseline_preds[idx]:
                match += 1
    match_pct = match / len(texts) * 100
    print(f"  {f'first {k}':<15} {match_pct:<15.1f}")
print(f"\n{'=' * 70}")
print(f'  W LAW — INFORMATION CONSERVATION RESULTS')
print(f"{'=' * 70}")
print(f'\n  KEY QUESTION: Is the answer in h_0 already?\n  \n  TEST A: h_l → logits R² per layer.\n    If h_0 → logits = high R²: answer in embedding.\n    If only h_8 → logits = high: layers compute answer.\n    \n  TEST C: P(correct | h_l) at each layer.\n    The decisive test: does probability of correct\n    token INCREASE monotonically with depth?\n    Or does it start high and layers just refine?\n    \n  TEST D: Which layers actually change the answer?\n    If most layers = skippable:\n      Run only essential layers.\n      Skip the rest. EXACT same output.\n      Not approximation. Exact.\n      \n  TEST E: How many layers needed?\n    Minimum k for 100% match = true compute cost.\n    k << n_layers: massive speedup available. Exact.\n    \n  THIS IS THE REAL 70B ON LAPTOP PATH:\n    Not compressing weights.\n    Not approximating activations.\n    Finding which layers are NECESSARY.\n    Running only those. Skipping the rest.\n    Output = exactly same. W law: deterministic. Exact.\n')
print('=' * 70 + '\n')
