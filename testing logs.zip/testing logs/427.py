import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import time, math, copy
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForCausalLM
DEVICE = 'cpu'
BATCH = 8
LR = 0.0001
EPOCHS = 3
N_TEXTS = 300
MAX_LEN = 96
KL_FLOOR = 0.05
LOSS_PAT = 4
print(f'\nW-LAW IMPOSSIBILITY — FIXED')
print(f'Init: pretrained  LR={LR}  KL_floor={KL_FLOOR}')
print(f'\nLoading pretrained TinyStories-1M...')
tokenizer = AutoTokenizer.from_pretrained('roneneldan/TinyStories-1M')
base = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
base.eval()
D = base.config.hidden_size
N_LAYERS = base.config.num_layers
FFN_DIM = D * 4
VOCAB = base.config.vocab_size
MAX_POS = base.config.max_position_embeddings
print(f'D={D}  FFN_dim={FFN_DIM}  Layers={N_LAYERS}')
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at', 'The wind was cold', 'A little rabbit hopped', 'The brave knight rode', 'She woke up and', 'He could not find', 'The magic door opened', 'They walked together through']
print(f'Generating {N_TEXTS} training texts...')
train_texts = []
with torch.no_grad():
    i = 0
    while len(train_texts) < N_TEXTS:
        s = seeds[i % len(seeds)]
        torch.manual_seed(i)
        inp = tokenizer.encode(s, return_tensors='pt')
        out = base.generate(inp, max_new_tokens=50, do_sample=True, temperature=0.85, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
        train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
        i += 1
print(f'Generated {len(train_texts)} texts.')
all_ids = []
for t in train_texts:
    ids = tokenizer.encode(t, max_length=MAX_LEN, truncation=True)
    if len(ids) > 8:
        all_ids.append(torch.tensor(ids, dtype=torch.long))

class DS(Dataset):

    def __init__(self, x):
        self.x = x

    def __len__(self):
        return len(self.x)

    def __getitem__(self, i):
        return self.x[i]

def collate(b):
    L = max((x.shape[0] for x in b))
    out = torch.zeros(len(b), L, dtype=torch.long)
    for i, x in enumerate(b):
        out[i, :x.shape[0]] = x
    return out
loader = DataLoader(DS(all_ids), batch_size=BATCH, shuffle=True, collate_fn=collate)
print(f'Dataset: {len(all_ids)} sequences')
print(f'\nFitting shared W_ffn on pretrained activations...')
GELU_all = []
FFN_all = []
hooks = []
for li in range(N_LAYERS):
    b = base.transformer.h[li]

    def make(l):

        def hg(m, inp, out):
            for t in range(out.shape[1]):
                GELU_all.append(out[0, t].detach().float().numpy().copy())

        def hf(m, inp, out):
            for t in range(out.shape[1]):
                FFN_all.append(out[0, t].detach().float().numpy().copy())
        return (hg, hf)
    hg, hf = make(li)
    hooks += [b.mlp.act.register_forward_hook(hg), b.mlp.c_proj.register_forward_hook(hf)]
with torch.no_grad():
    for text in train_texts[:200]:
        ids = tokenizer(text, return_tensors='pt', max_length=MAX_LEN, truncation=True)
        base(**ids)
for h in hooks:
    h.remove()
G = np.array(GELU_all, np.float32)
F = np.array(FFN_all, np.float32)
Xb = np.c_[G.astype(np.float64), np.ones(len(G))]
W_shared = np.linalg.lstsq(Xb, F.astype(np.float64), rcond=None)[0].astype(np.float32)
pred = (Xb @ W_shared).astype(np.float32)
ss_res = np.mean((pred - F) ** 2)
ss_tot = np.var(F)
r2_init = float(1 - ss_res / ss_tot)
print(f'  Shared W_ffn R²: {r2_init:.6f}  shape={W_shared.shape}')
GELU_IN_all = []
hooks2 = []
for li in range(N_LAYERS):

    def make2(l):

        def hgi(m, inp, out):
            for t in range(inp[0].shape[1]):
                GELU_IN_all.append(inp[0][0, t].detach().float().numpy().copy())
        return hgi
    h = base.transformer.h[li].mlp.act.register_forward_hook(make2(li))
    hooks2.append(h)
with torch.no_grad():
    for text in train_texts[:100]:
        ids = tokenizer(text, return_tensors='pt', max_length=MAX_LEN, truncation=True)
        base(**ids)
for h in hooks2:
    h.remove()
GI = np.array(GELU_IN_all, np.float32)
NATURAL_MEAN = GI.mean(axis=0)
NATURAL_STD = GI.std(axis=0) + 1e-06
print(f'  Natural gelu input distribution captured: {GI.shape}')
del base

class WlawFFN(nn.Module):

    def __init__(self, orig_mlp, W_mat):
        super().__init__()
        self.c_fc = orig_mlp.c_fc
        self.act = orig_mlp.act
        self.W_ffn = nn.Parameter(torch.tensor(W_mat), requires_grad=False)
        self.active = True
        self.c_proj = orig_mlp.c_proj
        self._last_gelu_in = None

    def forward(self, x):
        gelu_in = self.c_fc(x)
        self._last_gelu_in = gelu_in.detach()
        gate = self.act(gelu_in)
        if self.active:
            B, L, fd = gate.shape
            gf = gate.float().reshape(B * L, fd)
            gb = torch.cat([gf, torch.ones(B * L, 1)], dim=1)
            out = (gb @ self.W_ffn).reshape(B, L, -1).to(x.dtype)
            return out
        else:
            return self.c_proj(gate)
print(f'\nBuilding patched models from pretrained weights...')

def build_model():
    m = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
    shared_ffn = None
    ffn_modules = []
    for li in range(N_LAYERS):
        orig = m.transformer.h[li].mlp
        if shared_ffn is None:
            ffn_mod = WlawFFN(orig, W_shared)
            shared_ffn = ffn_mod
        else:
            ffn_mod = WlawFFN(orig, W_shared)
            ffn_mod.W_ffn = shared_ffn.W_ffn
        m.transformer.h[li].mlp = ffn_mod
        ffn_modules.append(ffn_mod)
    return (m, shared_ffn, ffn_modules)
model_A, _, ffns_A = build_model()
model_B, _, ffns_B = build_model()

def attn_params(m):
    wffn_ids = {id(f.W_ffn) for f in m.transformer.h if hasattr(m.transformer.h[0].mlp, 'W_ffn')}
    excluded = set()
    for li in range(N_LAYERS):
        excluded.add(id(m.transformer.h[li].mlp.W_ffn))
    return [p for p in m.parameters() if id(p) not in excluded]
crit = nn.CrossEntropyLoss(ignore_index=0)

def generate(m, prompt, max_new=80):
    m.eval()
    ids = tokenizer.encode(prompt, return_tensors='pt')
    out = []
    with torch.no_grad():
        for _ in range(max_new):
            if ids.shape[1] >= MAX_POS:
                break
            tok = int(torch.argmax(m(ids).logits[0, -1, :]).item())
            out.append(tok)
            ids = torch.cat([ids, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return tokenizer.decode(out, skip_special_tokens=True)

def kl_from_natural(ffn_modules):
    gis = []
    for f in ffn_modules:
        if f._last_gelu_in is not None:
            gi = f._last_gelu_in.float()
            B, L, fd = gi.shape
            gis.append(gi.reshape(B * L, fd))
    if not gis:
        return 0.0
    gi_all = torch.cat(gis, dim=0).numpy()
    curr_mean = gi_all.mean(axis=0)
    curr_std = gi_all.std(axis=0) + 1e-06
    kl = np.sum(np.log(NATURAL_STD / curr_std) + (curr_std ** 2 + (curr_mean - NATURAL_MEAN) ** 2) / (2 * NATURAL_STD ** 2) - 0.5) / len(NATURAL_MEAN)
    return float(kl)
print(f"\n{'=' * 60}")
print(f'RUN A: Pretrained + W-law FFN. No impossibility check.')
print(f"{'=' * 60}")
opt_A = optim.AdamW(attn_params(model_A), lr=LR, weight_decay=0.01)
stats_A = {'steps': 0, 'loss_hist': [], 'kl_hist': []}
t_A = time.time()
for epoch in range(EPOCHS):
    model_A.train()
    ep_loss = 0
    kl_sum = 0
    for step, batch in enumerate(loader):
        if batch.shape[1] < 2:
            continue
        out = model_A(batch[:, :-1])
        loss = crit(out.logits.reshape(-1, VOCAB), batch[:, 1:].reshape(-1))
        opt_A.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(attn_params(model_A), 1.0)
        opt_A.step()
        stats_A['steps'] += 1
        ep_loss += loss.item()
        kl = kl_from_natural(ffns_A)
        kl_sum += kl
        if step % 30 == 0:
            print(f'  A E{epoch + 1} s{step:3d} loss={loss.item():.4f} kl={kl:.4f}', flush=True)
    stats_A['loss_hist'].append(ep_loss / max(1, step + 1))
    stats_A['kl_hist'].append(kl_sum / max(1, step + 1))
    print(f'  A Epoch{epoch + 1}: loss={ep_loss / max(1, step + 1):.4f} avg_kl={kl_sum / max(1, step + 1):.4f}')
time_A = time.time() - t_A
print(f"\n{'=' * 60}")
print(f'RUN B: Pretrained + W-law FFN + Impossibility checks.')
print(f'  CHECK 1: KL guard — scale gradient if KL > {KL_FLOOR}')
print(f'  CHECK 2: Loss patience — skip after {LOSS_PAT} bad steps')
print(f"{'=' * 60}")
opt_B = optim.AdamW(attn_params(model_B), lr=LR, weight_decay=0.01)
stats_B = {'steps': 0, 'skipped': 0, 'projected': 0, 'loss_hist': [], 'kl_hist': []}
best_loss_B = float('inf')
bad_streak = 0
best_state_B = copy.deepcopy(model_B.state_dict())
t_B = time.time()
for epoch in range(EPOCHS):
    model_B.train()
    ep_loss = 0
    ep_steps = 0
    kl_sum = 0
    for step, batch in enumerate(loader):
        if batch.shape[1] < 2:
            continue
        out = model_B(batch[:, :-1])
        loss = crit(out.logits.reshape(-1, VOCAB), batch[:, 1:].reshape(-1))
        if loss.item() > best_loss_B * 1.2 and step > 5:
            bad_streak += 1
            if bad_streak >= LOSS_PAT:
                model_B.load_state_dict(best_state_B)
                opt_B = optim.AdamW(attn_params(model_B), lr=LR * 0.5, weight_decay=0.01)
                bad_streak = 0
                stats_B['skipped'] += 1
                if step % 30 == 0:
                    print(f'  B IMPOSSIBLE skip at s{step}', flush=True)
                continue
        else:
            bad_streak = 0
            if loss.item() < best_loss_B:
                best_loss_B = loss.item()
                best_state_B = copy.deepcopy(model_B.state_dict())
        opt_B.zero_grad()
        loss.backward()
        kl_now = kl_from_natural(ffns_B)
        if kl_now > KL_FLOOR:
            kl_scale = KL_FLOOR / (kl_now + 1e-08)
            for p in attn_params(model_B):
                if p.grad is not None:
                    p.grad.mul_(kl_scale)
            stats_B['projected'] += 1
        torch.nn.utils.clip_grad_norm_(attn_params(model_B), 1.0)
        opt_B.step()
        stats_B['steps'] += 1
        ep_loss += loss.item()
        ep_steps += 1
        kl_sum += kl_now
        if step % 30 == 0:
            print(f"  B E{epoch + 1} s{step:3d} loss={loss.item():.4f} kl={kl_now:.4f} proj={stats_B['projected']} skip={stats_B['skipped']}", flush=True)
    stats_B['loss_hist'].append(ep_loss / max(1, ep_steps))
    stats_B['kl_hist'].append(kl_sum / max(1, ep_steps))
    print(f"  B Epoch{epoch + 1}: loss={ep_loss / max(1, ep_steps):.4f} avg_kl={kl_sum / max(1, ep_steps):.4f} projected={stats_B['projected']} skipped={stats_B['skipped']}")
time_B = time.time() - t_B
prompts = ['Once upon a time there was a little girl who loved to', 'The little boy found a magic', 'She looked at the stars and', 'One day a small rabbit']
print(f"\n{'=' * 70}")
print(f'  FINAL COMPARISON')
print(f"{'=' * 70}")
print(f'\n  TRAINING METRICS:')
print(f"  {'Metric':<30} {'Run A (baseline)':<25} {'Run B (impossible)'}")
print(f"  {'─' * 70}")
print(f"  {'Time (seconds)':<30} {time_A:<25.1f} {time_B:.1f}")
print(f"  {'Total steps':<30} {stats_A['steps']:<25} {stats_B['steps']}")
print(f"  {'Impossible skips':<30} {'0':<25} {stats_B['skipped']}")
print(f"  {'KL projections':<30} {'0':<25} {stats_B['projected']}")
print(f"  {'Final loss':<30} {stats_A['loss_hist'][-1]:<25.4f} {stats_B['loss_hist'][-1]:.4f}")
print(f"  {'Avg KL (epoch 1)':<30} {stats_A['kl_hist'][0]:<25.4f} {stats_B['kl_hist'][0]:.4f}")
print(f"  {'Avg KL (final)':<30} {stats_A['kl_hist'][-1]:<25.4f} {stats_B['kl_hist'][-1]:.4f}")
speedup = time_A / time_B if time_B > 0 else 0
loss_diff = stats_A['loss_hist'][-1] - stats_B['loss_hist'][-1]
print(f"  {'Speedup B vs A':<30} {'—':<25} {speedup:.2f}x")
print(f"  {'Loss diff (A-B)':<30} {'—':<25} {loss_diff:+.4f}")
print(f'\n  GENERATION:')
for p in prompts:
    ga = generate(model_A, p)
    gb = generate(model_B, p)
    print(f'\n  PROMPT: {p}')
    print(f'  A: {ga[:120]}')
    print(f'  B: {gb[:120]}')
print(f"\n{'=' * 70}")
print(f'\n  WHAT EACH NUMBER MEANS:\n\n  KL divergence:\n    = how far gelu inputs drifted from natural distribution.\n    Low KL (near 0): attention preserving natural space. Good.\n    High KL (>0.05): attention breaking natural space. Impossible.\n\n  KL projections (Run B):\n    = number of steps where gradient was scaled down.\n    = number of impossible directions caught and avoided.\n    Each projection = one wasted step saved.\n\n  If B avg_kl < A avg_kl:\n    Impossibility check IS keeping model in natural space.\n    B stays closer to law manifold. Check works.\n\n  If B final loss < A final loss:\n    Staying in natural space = better convergence.\n    Impossible directions were genuinely harmful.\n\n  If B final loss > A final loss:\n    KL floor too tight. Removing too many directions.\n    Adjust KL_FLOOR higher and retest.\n\n  KL floor tuning:\n    KL_FLOOR=0.01: very strict. Many projections. Might over-constrain.\n    KL_FLOOR=0.05: moderate. Balance.\n    KL_FLOOR=0.20: loose. Few projections. Near baseline.\n    Real value = found by testing. That is what we are doing.\n')
print('=' * 70 + '\n')
