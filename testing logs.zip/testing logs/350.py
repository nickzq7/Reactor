import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 75)
print('  W — LAYER-BY-LAYER O(1) TRAINING (SEQUENTIAL UNCOUPLING)')
print('  Defeating the Collinearity Illusion at Layer 7.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
print('\n  [ Phase 1 ] Extracting Physical States & Exact Crystals...')
prompts = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon lived', 'A small dog ran across the green field', 'When the sun came up in the morning the birds', 'She smiled and said to her mother I love', 'The brave knight took his shiny sword and', 'A little boy found a magic wand inside', 'High up in the clouds there was a', 'The cat jumped over the fence and saw', 'A wise old owl sat in the tree']
all_softmax_cryst = {l: [] for l in range(n_layers)}
all_attn_delta = {l: [] for l in range(n_layers)}
all_gelu_cryst = {l: [] for l in range(n_layers)}
all_ffn_delta = {l: [] for l in range(n_layers)}
extraction_flags = {'is_extracting': False}

def get_attn_proj_hook(l):

    def hook(m, i, o):
        if extraction_flags['is_extracting']:
            all_softmax_cryst[l].append(i[0].squeeze(0).detach().cpu().float().numpy())
            all_attn_delta[l].append(o.squeeze(0).detach().cpu().float().numpy())
    return hook

def get_ffn_proj_hook(l):

    def hook(m, i, o):
        if extraction_flags['is_extracting']:
            all_gelu_cryst[l].append(i[0].squeeze(0).detach().cpu().float().numpy())
            all_ffn_delta[l].append(o.squeeze(0).detach().cpu().float().numpy())
    return hook
hooks = []
for l in range(n_layers):
    hooks.append(model.transformer.h[l].attn.attention.out_proj.register_forward_hook(get_attn_proj_hook(l)))
    hooks.append(model.transformer.h[l].mlp.c_proj.register_forward_hook(get_ffn_proj_hook(l)))
with torch.no_grad():
    for s in prompts:
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(hash(s) % 10000 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out_gen = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            seq_ids = out_gen[0]
            extraction_flags['is_extracting'] = True
            model(seq_ids.unsqueeze(0))
            extraction_flags['is_extracting'] = False
for h in hooks:
    h.remove()
for l in range(n_layers):
    all_softmax_cryst[l] = np.concatenate(all_softmax_cryst[l], axis=0).astype(np.float64)
    all_attn_delta[l] = np.concatenate(all_attn_delta[l], axis=0).astype(np.float64)
    all_gelu_cryst[l] = np.concatenate(all_gelu_cryst[l], axis=0).astype(np.float64)
    all_ffn_delta[l] = np.concatenate(all_ffn_delta[l], axis=0).astype(np.float64)
N_samples = len(all_softmax_cryst[0])
print(f'  ✓ Extracted {N_samples} tokens across all layers.')
print('\n  [ Phase 2 ] Solving W_layer matrices (Simultaneous vs Sequential)...')

def r2_score_func(Y_true, Y_pred):
    ss_res = np.sum((Y_true - Y_pred) ** 2)
    ss_tot = np.sum((Y_true - np.mean(Y_true, axis=0)) ** 2)
    return 1 - ss_res / ss_tot
print('\n' + '=' * 75)
print(f"  {'Layer':<8} | {'Simultaneous R² (Collinear)':<30} | {'Sequential R² (Uncoupled)'}")
print('=' * 75)
for l in range(n_layers):
    Softmax_Cryst = all_softmax_cryst[l]
    Attn_Delta = all_attn_delta[l]
    GeLU_Cryst = all_gelu_cryst[l]
    FFN_Delta = all_ffn_delta[l]
    Y_delta_total = Attn_Delta + FFN_Delta
    Phi_Simul = np.hstack([Softmax_Cryst, GeLU_Cryst, np.ones((N_samples, 1))])
    W_simul = np.linalg.lstsq(Phi_Simul, Y_delta_total, rcond=None)[0]
    Y_pred_simul = Phi_Simul @ W_simul
    r2_simul = r2_score_func(Y_delta_total, Y_pred_simul)
    Phi_Attn = np.hstack([Softmax_Cryst, np.ones((N_samples, 1))])
    W_attn = np.linalg.lstsq(Phi_Attn, Attn_Delta, rcond=None)[0]
    Phi_FFN = np.hstack([GeLU_Cryst, np.ones((N_samples, 1))])
    W_ffn = np.linalg.lstsq(Phi_FFN, FFN_Delta, rcond=None)[0]
    Y_pred_seq = Phi_Attn @ W_attn + Phi_FFN @ W_ffn
    r2_seq = r2_score_func(Y_delta_total, Y_pred_seq)
    mark = '✓ PERFECT' if r2_seq > 0.99999 else '✗ FAILED'
    print(f'  Layer {l:<2} | {r2_simul:<30.6f} | {r2_seq:<18.6f} {mark}')
print('=' * 75)
print('\n  THE PHYSICS DIAGNOSIS:')
print('  When you combine [Softmax, GeLU] into a single matrix inversion,')
print('  you trigger COLLINEARITY. At deep layers, Attention and FFN communicate')
print('  so perfectly that their mathematical spaces overlap. The solver panics.')
print('  THE FIX: Sequential Uncoupling. We train W_att and W_ffn exactly')
print('  as Nature structured them: one after the other. Collinearity vanishes.')
print('  The math snaps back to absolute 1.000000 perfection.')
print('=' * 75 + '\n')
