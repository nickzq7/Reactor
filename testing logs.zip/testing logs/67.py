import numpy as np
import torch
import torch.nn as nn
import time
from scipy import stats
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
DIM = 16
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(1000)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

def build_W(geo, out_dim, in_dim):
    if geo == 'flat':
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    elif geo == 'uniform':
        arr = np.linspace(-1, 1, out_dim).astype(np.float32)
    elif geo == 'triangular':
        arr = np.array([i * (i + 1) / 2 for i in range(1, out_dim + 1)], dtype=np.float32)
    elif geo == 'sqrt':
        arr = np.array([np.sqrt(i + 1) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'exp':
        arr = np.array([np.exp(i / out_dim) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'prime':
        arr = np.array(BEST_PRIMES[:out_dim], dtype=np.float32)
    elif geo == 'fibonacci':
        f = [1, 1]
        while len(f) < out_dim:
            f.append(f[-1] + f[-2])
        arr = np.array(f[:out_dim], dtype=np.float32)
    elif geo == 'log':
        arr = np.array([np.log(i + 2) for i in range(out_dim)], dtype=np.float32)
    elif geo == 'powers2':
        arr = np.array([2.0 ** i for i in range(out_dim)], dtype=np.float32)
    else:
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
    arr = arr / (np.max(np.abs(arr)) + 1e-08)
    W = np.zeros((out_dim, in_dim), dtype=np.float32)
    for col in range(in_dim):
        W[:, col] = arr * (col + 1) / in_dim
    return W

def build_net(geo_list, dim=DIM):
    layers = []
    in_d = SEQ_LEN
    for geo in geo_list:
        lin = nn.Linear(in_d, dim)
        with torch.no_grad():
            lin.weight.copy_(torch.tensor(build_W(geo, dim, in_d)))
        layers += [lin, nn.Tanh()]
        in_d = dim
    layers.append(nn.Linear(dim, 1))

    class Net(nn.Module):

        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(*layers)

        def forward(self, x):
            return self.net(x)
    return Net()

def train(model, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-06)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN at ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model)
            print(f'    {label}  ep{ep:>5}  loss={best:.4f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, true_next in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - true_next) / NORM <= TOL:
                c += 1
    return c

def score_at_epochs(log, checkpoints):
    return {ep: log[min(ep - 1, len(log) - 1)] for ep in checkpoints}

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
N_LAYERS = 50
PIPELINE_CYCLE = ['uniform', 'triangular', 'sqrt', 'exp', 'prime', 'uniform']

def make_pipeline(n_layers):
    return [PIPELINE_CYCLE[i % len(PIPELINE_CYCLE)] for i in range(n_layers)]
pipeline_50 = make_pipeline(N_LAYERS)
print(f'\n  Pipeline cycle: {PIPELINE_CYCLE}')
print(f'  50-layer pipeline: {pipeline_50[:12]}... (repeating)')
print_sep('EXP 1 — 50-LAYER: PIPELINE vs FLAT')
EPOCHS = 3000
CHECKPTS = [500, 1000, 1500, 2000, 2500, 3000]
print(f'\n  Training 50-layer FLAT...')
np.random.seed(42)
m_flat = build_net(['flat'] * N_LAYERS).to(device)
print(f'  Params: {sum((p.numel() for p in m_flat.parameters())):,}')
l_flat, log_flat = train(m_flat, epochs=EPOCHS, lr=0.001, label='FLAT-50')
s_flat = score(m_flat)
print(f'\n  Training 50-layer PIPELINE...')
np.random.seed(42)
m_pipe = build_net(pipeline_50).to(device)
print(f'  Params: {sum((p.numel() for p in m_pipe.parameters())):,}')
l_pipe, log_pipe = train(m_pipe, epochs=EPOCHS, lr=0.001, label='PIPE-50')
s_pipe = score(m_pipe)
print(f'\n  RESULT:')
print(f"  {'Model':<20}  {'Loss':>10}  {'Score':>8}")
print(f"  {'─' * 42}")
print(f"  {'FLAT-50':<20}  {l_flat:>10.4f}  {s_flat:>5}/{len(TESTS)}")
print(f"  {'PIPELINE-50':<20}  {l_pipe:>10.4f}  {s_pipe:>5}/{len(TESTS)}")
print_sep('EXP 2 — CONVERGENCE SPEED')
print(f'\n  Loss at each checkpoint:')
print(f"  {'Epoch':>8}  {'Flat-50':>12}  {'Pipeline-50':>14}  Winner")
print(f"  {'─' * 50}")
for ep in CHECKPTS:
    lf = log_flat[min(ep - 1, len(log_flat) - 1)]
    lp = log_pipe[min(ep - 1, len(log_pipe) - 1)]
    winner = 'PIPELINE' if lp < lf else 'FLAT' if lf < lp else 'TIE'
    print(f'  {ep:>8}  {lf:>12.4f}  {lp:>14.4f}  {winner}')
print_sep('EXP 3 — PIPELINE VARIANTS at 50 LAYERS')
variants = [('all flat', ['flat'] * N_LAYERS), ('discovered cycle\n     uniform→tri→sqrt→exp→prime→uniform', make_pipeline(N_LAYERS)), ('uniform throughout', ['uniform'] * N_LAYERS), ('prime throughout', ['prime'] * N_LAYERS), ('flat→prime→uniform (3-phase)', ['flat'] * (N_LAYERS // 3) + ['prime'] * (N_LAYERS // 3) + ['uniform'] * (N_LAYERS - 2 * (N_LAYERS // 3))), ('gradient: flat→uniform→prime', ['flat'] * 17 + ['uniform'] * 17 + ['prime'] * 16), ('alternating flat+uniform', (['flat', 'uniform'] * 25)[:N_LAYERS])]
var_results = []
QUICK_EPOCHS = 1500
for label, geos in variants:
    assert len(geos) == N_LAYERS, f'{label}: {len(geos)} layers'
    np.random.seed(42)
    m = build_net(geos).to(device)
    l, _ = train(m, epochs=QUICK_EPOCHS, lr=0.001, label=label[:20])
    s = score(m)
    var_results.append((s, l, label))
    del m
    torch.cuda.empty_cache()
var_results.sort(key=lambda x: (-x[0], x[1]))
print(f'\n  50-LAYER VARIANTS (trained {QUICK_EPOCHS} epochs):')
print(f"  {'#':>3}  {'Score':>7}  {'Loss':>10}  Variant")
print(f"  {'─' * 65}")
for rank, (s, l, label) in enumerate(var_results):
    short_label = label.split('\n')[0]
    print(f'  {rank + 1:>3}  {s:>4}/{len(TESTS)}  {l:>10.4f}  {short_label}')
print_sep('EXP 4 — WHAT GEOMETRY DOES 50-LAYER FLAT DISCOVER?')
np.random.seed(42)
m_analyze = build_net(['flat'] * N_LAYERS).to(device)
train(m_analyze, epochs=2000, lr=0.001, label='analyze')
linears = [mod for mod in m_analyze.net if isinstance(mod, nn.Linear)]
print(f'\n  Sampling geometry at layers 1,10,20,30,40,50:')
REFS = {'uniform': np.linspace(0, 1, DIM), 'triangular': np.array([i * (i + 1) / 2 for i in range(1, DIM + 1)], dtype=np.float64), 'sqrt': np.array([np.sqrt(i + 1) for i in range(DIM)], dtype=np.float64), 'exp': np.array([np.exp(i / DIM) for i in range(DIM)], dtype=np.float64), 'prime': np.array(BEST_PRIMES[:DIM], dtype=np.float64), 'log': np.array([np.log(i + 2) for i in range(DIM)], dtype=np.float64), 'fibonacci': None, 'powers2': np.array([2.0 ** i for i in range(DIM)], dtype=np.float64)}
fibs = [1, 1]
while len(fibs) < DIM:
    fibs.append(fibs[-1] + fibs[-2])
REFS['fibonacci'] = np.array(fibs[:DIM], dtype=np.float64)
for k in REFS:
    REFS[k] = (REFS[k] - REFS[k].min()) / (REFS[k].max() - REFS[k].min() + 1e-08)
sample_layers = [0, 9, 19, 29, 39, 49]
print(f"\n  {'Layer':>8}  {'Best Match':<16}  {'r':>8}  {'2nd Match':<16}  {'r':>8}")
print(f"  {'─' * 65}")
for li in sample_layers:
    if li >= len(linears) - 1:
        continue
    W = linears[li].weight.detach().cpu().numpy()
    norms = np.sort(np.linalg.norm(W, axis=1))
    sig = (norms - norms.min()) / (norms.max() - norms.min() + 1e-08)
    sims = {}
    for name, ref in REFS.items():
        if len(ref) == len(sig):
            r, _ = stats.pearsonr(sig, ref)
            sims[name] = r
    ranked = sorted(sims.items(), key=lambda x: -abs(x[1]))
    print(f'  {li + 1:>8}  {ranked[0][0]:<16}  {ranked[0][1]:>+8.4f}  {ranked[1][0]:<16}  {ranked[1][1]:>+8.4f}')
print_sep('FINAL SUMMARY — 50-LAYER FINDINGS')
print(f"\n  PIPELINE vs FLAT at 50 layers:\n    FLAT-50     : {s_flat}/{len(TESTS)}  loss={l_flat:.4f}\n    PIPELINE-50 : {s_pipe}/{len(TESTS)}  loss={l_pipe:.4f}\n    {('PIPELINE WINS' if s_pipe >= s_flat else 'FLAT WINS' if s_flat > s_pipe else 'TIE')}\n\n  BEST VARIANT:\n    {var_results[0][2].split(chr(10))[0]}\n    Score: {var_results[0][0]}/{len(TESTS)}  Loss: {var_results[0][1]:.4f}\n\n  KEY INSIGHT AT 50 LAYERS:\n    10 layers → flat self-discovers geometry\n    50 layers → geometry discovery happens earlier\n                or does not converge at all?\n    Pipeline pre-imposed → does it help at depth 50?\n    The answer above reveals:\n    Whether intelligence scales with depth\n    or plateaus at a certain depth.\n\n  This maps to:\n    Shallow child brain → needs structure\n    Deep adult brain    → finds structure\n    Very deep (50L)     → structure or chaos?\n")
