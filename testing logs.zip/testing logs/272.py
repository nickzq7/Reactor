import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — NATURAL SPACE OF GeLU AND SOFTMAX')
print('  Nothing is nonlinear. Find the right coordinates.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
blk = model.transformer.h[0]
att = blk.attn.attention
Wq = att.q_proj.weight.detach().numpy()
Wk = att.k_proj.weight.detach().numpy()
Wv = att.v_proj.weight.detach().numpy()
Wo = att.out_proj.weight.detach().numpy()
bo = att.out_proj.bias.detach().numpy()
W1 = blk.mlp.c_fc.weight.detach().numpy()
b1 = blk.mlp.c_fc.bias.detach().numpy()
W2 = blk.mlp.c_proj.weight.detach().numpy()
b2 = blk.mlp.c_proj.bias.detach().numpy()
ln1_w = blk.ln_1.weight.detach().numpy()
ln1_b = blk.ln_1.bias.detach().numpy()
ln2_w = blk.ln_2.weight.detach().numpy()
ln2_b = blk.ln_2.bias.detach().numpy()

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu_np(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2(A, Y):
    Ab = np.hstack([A, np.ones((len(A), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, Y, rcond=None)
    Yp = Ab @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    return float(1 - ss_res / ss_tot)

def r2_report(name, A, Y, N, D_in):
    score = r2(A, Y)
    status = '= 1.000 EXACT' if score > 0.9999 else '≈ 1.000 near' if score > 0.999 else '> 0.99' if score > 0.99 else '> 0.95' if score > 0.95 else 'PARTIAL' if score > 0.5 else 'LOW'
    reliable = '✓' if N > D_in * 5 else '⚠ N too small'
    print(f'  {name:<40} R²={score:.6f}  {status}  {reliable}')
    return score
print(f'\n  Collecting data (layer 0)...')
prompts = ['Once upon a time a little girl', 'The brave knight rode into battle', 'Deep in the forest there lived a', 'A small dog ran across the', 'The sun rose over the mountains and', 'She opened the old wooden door slowly', 'Every morning the bird would sing loudly', 'He found a golden key hidden inside', 'The children played in the garden all', 'Far away in a distant land there', 'A tiny mouse found some old cheese', 'The wizard waved his magic wand high', 'Once there was a kind old farmer', 'The princess wore a silver crown proudly', 'A rainbow appeared after the heavy rain', 'The farmer planted many seeds today', 'She read the old dusty book carefully', 'The river flowed through the green valley', 'A butterfly landed on the red flower', 'The ship sailed across the deep sea', 'The moon shone bright in the dark', 'A little cat sat on the warm', 'He ran as fast as he could', 'The trees swayed in the strong wind', 'She laughed and clapped her small hands']
SEQ_LEN = 12
pre_gelu_all = []
post_gelu_all = []
alpha_all = []
ffn_out_all = []
scores_all = []
log_probs_all = []
probs_all = []
context_all = []
with torch.no_grad():
    for prompt in prompts:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        x = (wte[ids] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
        ln2 = ln(x, ln2_w, ln2_b)
        pre = ln2 @ W1.T + b1
        post = gelu_np(pre)
        fout = post @ W2.T + b2
        safe_pre = pre[-1].copy()
        safe_post = post[-1].copy()
        alpha = np.where(np.abs(safe_pre) > 1e-06, safe_post / safe_pre, 0.0)
        pre_gelu_all.append(safe_pre)
        post_gelu_all.append(safe_post)
        alpha_all.append(alpha)
        ffn_out_all.append(fout[-1])
        ln1 = ln(x, ln1_w, ln1_b)
        Q = ln1 @ Wq.T
        K = ln1 @ Wk.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((SEQ_LEN, SEQ_LEN), float('-inf'), np.float32), 1)
        s = Qh[0, -1, :] @ Kh[0].T + mask[-1]
        p = softmax_np(s[np.newaxis])[0]
        lp = np.log(p + 1e-10)
        ctx = p @ Vh[0]
        scores_all.append(s)
        log_probs_all.append(lp)
        probs_all.append(p)
        context_all.append(ctx)
        for _ in range(20):
            out = model(torch.tensor([ids]))
            nxt = torch.argmax(out.logits[0, -1, :]).item()
            ids.append(nxt)
            ids_use = ids[-SEQ_LEN:]
            x = (wte[ids_use] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
            ln2 = ln(x, ln2_w, ln2_b)
            pre = ln2 @ W1.T + b1
            post = gelu_np(pre)
            fout = post @ W2.T + b2
            safe_pre = pre[-1].copy()
            safe_post = post[-1].copy()
            alpha = np.where(np.abs(safe_pre) > 1e-06, safe_post / safe_pre, 0.0)
            pre_gelu_all.append(safe_pre)
            post_gelu_all.append(safe_post)
            alpha_all.append(alpha)
            ffn_out_all.append(fout[-1])
            ln1 = ln(x, ln1_w, ln1_b)
            Q = ln1 @ Wq.T
            K = ln1 @ Wk.T
            V = ln1 @ Wv.T
            Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            Vh = V.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            s = Qh[0, -1, :] @ Kh[0].T + mask[-1]
            p = softmax_np(s[np.newaxis])[0]
            lp = np.log(p + 1e-10)
            ctx = p @ Vh[0]
            scores_all.append(s)
            log_probs_all.append(lp)
            probs_all.append(p)
            context_all.append(ctx)
PRE = np.array(pre_gelu_all, dtype=np.float32)
POST = np.array(post_gelu_all, dtype=np.float32)
ALPHA = np.array(alpha_all, dtype=np.float32)
FOUT = np.array(ffn_out_all, dtype=np.float32)
S = np.array(scores_all, dtype=np.float32)
LP = np.array(log_probs_all, dtype=np.float32)
P = np.array(probs_all, dtype=np.float32)
CTX = np.array(context_all, dtype=np.float32)
N = len(PRE)
print(f'  N={N} samples\n')
print(f"{'=' * 70}")
print(f'  GeLU NATURAL SPACE ANALYSIS')
print(f'  GeLU(x) = x * Φ(x).  Φ = activation ratio α.')
print(f'  In which space is GeLU = exact linear?')
print(f"{'=' * 70}\n")
print(f"  {'Space':<42} {'R²':>10}  {'N vs D'}")
print(f"  {'─' * 60}")
r2_report('pre → post (standard view)', PRE, POST, N, FFN_D)
r2_report('α alone → post', ALPHA, POST, N, FFN_D)
pre_times_alpha = PRE * ALPHA
r2_report('pre*α → post  (definitional)', pre_times_alpha, POST, N, FFN_D)
pre_alpha_joint = np.hstack([PRE, ALPHA])
r2_report('(pre, α) joint → post', pre_alpha_joint, POST, N, FFN_D * 2)
r2_report('post (gelu_out) → ffn_out  [KNOWN]', POST, FOUT, N, FFN_D)
r2_report('pre → ffn_out  (skip GeLU)', PRE, FOUT, N, FFN_D)
signed_sqrt_pre = np.sign(PRE) * np.sqrt(np.abs(PRE))
r2_report('sign(pre)*sqrt(|pre|) → post', signed_sqrt_pre, POST, N, FFN_D)
log_abs_pre = np.sign(PRE) * np.log(np.abs(PRE) + 1e-06)
r2_report('sign*log(|pre|) → post', log_abs_pre, POST, N, FFN_D)
cbrt_pre = np.sign(PRE) * np.abs(PRE) ** (1 / 3)
r2_report('cbrt(pre) → post', cbrt_pre, POST, N, FFN_D)
print(f"\n{'=' * 70}")
print(f'  SOFTMAX NATURAL SPACE ANALYSIS')
print(f'  p = softmax(s).  log(p_i)-log(p_j) = s_i-s_j (exact).')
print(f'  In which space is softmax = exact linear?')
print(f"{'=' * 70}\n")
print(f"  {'Space':<42} {'R²':>10}  {'N vs D'}")
print(f"  {'─' * 60}")
r2_report('scores s → probs p  (standard view)', S, P, N, SEQ_LEN)
r2_report('scores s → log(p)  [log space]', S, LP, N, SEQ_LEN)
r2_report('log(p) → p', LP, P, N, SEQ_LEN)
r2_report('log(p) → context[head0]', LP, CTX, N, SEQ_LEN)
r2_report('p (probs) → context[head0]  [KNOWN]', P, CTX, N, SEQ_LEN)
r2_report('scores s → context  (skip softmax)', S, CTX, N, SEQ_LEN)
print(f'\n  KEY INSIGHT:')
print(f'  s → log(p): if R²=1.000, then log-probability space')
print(f'  is the natural space of softmax.')
print(f'  softmax IS linear in log-probability coordinates.')
print(f"\n{'=' * 70}")
print(f'  UNIFIED W LAW — NATURAL SPACES')
print(f"{'=' * 70}\n")
print(f'\n  GeLU in standard space:  pre → post = nonlinear (R² < 1)\n  GeLU natural space:      ??? → post = 1.000\n    Candidate: α (ratio) coordinates\n    Candidate: log-magnitude of pre\n    \n  Softmax in standard space: s → p = nonlinear (R² < 1)\n  Softmax natural space:     s → log(p) = linear?\n    log(p_i) = s_i - logsumexp(s)\n    This IS linear in s. Subtract same constant from all.\n    Natural space = log-probability space.\n    \n  W PRINCIPLE:\n    Nothing is nonlinear.\n    Operations look nonlinear only in wrong coordinates.\n    Find correct coordinates: R²=1.000 everywhere.\n    \n    GeLU: needs its OWN natural coordinate (TBD from data)\n    Softmax: natural coordinate = log(p)\n    \n  If s → log(p) = R²=1.000:\n    Softmax is linear. Proven.\n    Crystal point was an illusion of wrong coordinates.\n    In log-prob space: softmax = linear projection.\n    W principle holds completely. No exceptions.\n')
print('=' * 70 + '\n')
