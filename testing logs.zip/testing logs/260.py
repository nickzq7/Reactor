import numpy as np
import torch
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL TRAINER v5 — REAL TINYSTORIES DATASET')
print('  Loading actual training data. N >> 21440 target.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model_ref = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model_ref.eval()
n_layers = model_ref.config.num_layers
n_heads = model_ref.config.num_attention_heads
D = model_ref.config.hidden_size
head_dim = D // n_heads
QUAD_DIM = D + D * (D + 1) // 2
TARGET_N = 12 * QUAD_DIM
print(f'\n  D={D}, QUAD_DIM={QUAD_DIM}')
print(f'  Target N = 12×{QUAD_DIM} = {TARGET_N}')
print(f'\n  Loading TinyStories dataset...')
try:
    from datasets import load_dataset
    ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
    USE_DATASET = True
    print(f'  ✓ Dataset loaded (streaming)')
except Exception as e:
    print(f'  Dataset load failed: {e}')
    print(f'  Falling back to local text generation.')
    USE_DATASET = False

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_np(x):
    x = x.astype(np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def quad_kernel(x):
    x = np.array(x, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(1, -1)
    N, d = x.shape
    i, j = np.triu_indices(d)
    return np.hstack([x, x[:, i] * x[:, j]])

def solve_ridge(Phi, Y, lam=1e-06):
    Phi = np.array(Phi, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Pb = np.hstack([Phi, np.ones((len(Phi), 1))])
    A = Pb.T @ Pb + lam * np.eye(Pb.shape[1])
    W = np.linalg.solve(A, Pb.T @ Y)
    Yp = Pb @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    r2 = float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0
    return (W, r2)
wte = model_ref.transformer.wte.weight.detach().numpy()
wpe = model_ref.transformer.wpe.weight.detach().numpy()
SEQ_WINDOW = 16
STRIDE = 3
print(f'\n  Collecting training data...')
print(f'  Window={SEQ_WINDOW}, Stride={STRIDE}')
print(f'  Processing stories until N={TARGET_N}...')
t0 = time.time()
data = {li: {'ln2': [], 'delta_ffn': [], 'context': [], 'delta_att': []} for li in range(n_layers)}
total_seqs = 0
story_count = 0

def process_story_ids(ids_full):
    global total_seqs
    if len(ids_full) < SEQ_WINDOW + 1:
        return
    for start in range(0, len(ids_full) - SEQ_WINDOW, STRIDE):
        if total_seqs >= TARGET_N:
            return
        ids_use = ids_full[start:start + SEQ_WINDOW]
        T = len(ids_use)
        x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
        with torch.no_grad():
            for li in range(n_layers):
                blk = model_ref.transformer.h[li]
                ln1w = blk.ln_1.weight.detach().numpy()
                ln1b = blk.ln_1.bias.detach().numpy()
                ln2w = blk.ln_2.weight.detach().numpy()
                ln2b = blk.ln_2.bias.detach().numpy()
                att = blk.attn.attention
                Wq = att.q_proj.weight.detach().numpy()
                Wk = att.k_proj.weight.detach().numpy()
                Wv = att.v_proj.weight.detach().numpy()
                Wo = att.out_proj.weight.detach().numpy()
                bo = att.out_proj.bias.detach().numpy()
                W1 = blk.mlp.c_fc.weight.detach().numpy()
                b1 = blk.mlp.c_fc.bias.detach().numpy()
                W2 = blk.mlp.c_proj.weight.detach().numpy()
                b2 = blk.mlp.c_proj.bias.detach().numpy()
                ln1 = np.array([ln_np(x[i:i + 1], ln1w, ln1b)[0] for i in range(T)])
                Q = ln1 @ Wq.T
                K = ln1 @ Wk.T
                V = ln1 @ Wv.T
                Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                mask = np.triu(np.full((T, T), float('-inf')), 1)
                probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
                heads = [probs[h] @ Vh[h] for h in range(n_heads)]
                context = np.stack(heads, 1).reshape(T, D)
                att_out = context @ Wo.T + bo
                x_att = x + att_out
                x_new = x_att.copy()
                for t in range(T):
                    ln2t = ln_np(x_att[t:t + 1], ln2w, ln2b)[0]
                    x_new[t] = x_att[t] + gelu_np(ln2t @ W1.T + b1) @ W2.T + b2
                ln2_last = ln_np(x_att[-1:], ln2w, ln2b)[0]
                data[li]['ln2'].append(ln2_last.copy())
                data[li]['delta_ffn'].append((x_new[-1] - x_att[-1]).copy())
                data[li]['context'].append(context[-1].copy())
                data[li]['delta_att'].append(att_out[-1].copy())
                x = x_new
        total_seqs += 1
if USE_DATASET:
    for item in ds:
        if total_seqs >= TARGET_N:
            break
        text = item['text'] if 'text' in item else str(item)
        ids = tokenizer.encode(text)
        process_story_ids(ids)
        story_count += 1
        if story_count % 50 == 0:
            elapsed = time.time() - t0
            rate = total_seqs / elapsed if elapsed > 0 else 0
            eta = (TARGET_N - total_seqs) / rate if rate > 0 else 0
            print(f'    stories={story_count}  seqs={total_seqs}/{TARGET_N}  {total_seqs / QUAD_DIM:.1f}x  ETA={eta:.0f}s')
else:
    print('  Using model self-generation as fallback...')
    SEED_PROMPTS = ['Once upon a time', 'There was a little', 'A small dog', 'Deep in the forest', 'The brave knight', 'She smiled and', 'One sunny day', 'A little girl named', 'Far away there', 'In a small village', 'The old wizard', 'A tiny mouse', 'The princess wore', 'A rainbow appeared', 'The river flowed', 'A butterfly landed', 'The ship sailed', 'The moon rose', 'A bear found', 'The wind carried', 'Once there was', 'The cat sat', 'He climbed the', 'She sang a', 'A fox ran', 'The old man', 'A baby bird', 'The cook made', 'He drew a', 'The queen walked']
    with torch.no_grad():
        seed_idx = 0
        while total_seqs < TARGET_N:
            prompt = SEED_PROMPTS[seed_idx % len(SEED_PROMPTS)]
            seed_idx += 1
            ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
            for _ in range(200):
                if len(ids) > 300:
                    break
                out = model_ref(torch.tensor([ids[-min(len(ids), 32):]]))
                ids.append(torch.argmax(out.logits[0, -1, :]).item())
            process_story_ids(ids)
            story_count += 1
            if story_count % 20 == 0:
                print(f'    stories={story_count}  seqs={total_seqs}/{TARGET_N}  {total_seqs / QUAD_DIM:.1f}x')
N = total_seqs
for li in range(n_layers):
    for k in data[li]:
        data[li][k] = np.array(data[li][k], dtype=np.float64)
elapsed = time.time() - t0
ratio = N / QUAD_DIM
print(f'\n  N={N}  stories={story_count}  time={elapsed:.0f}s')
print(f"  N/QUAD_DIM = {ratio:.1f}x  ({('✓ sufficient' if ratio >= 10 else f'partial ({ratio:.1f}x)')})")
print(f"\n{'=' * 70}")
print(f'  W-KERNEL SOLVE')
print(f"{'=' * 70}\n")
t_s = time.time()
solved = {}
print(f"  {'Layer':<8} {'FFN_R²':>12} {'ATT_R²':>12}  {'FFN_val_R²':>12}")
print(f"  {'─' * 50}")
for li in range(n_layers):
    ln2_all = data[li]['ln2']
    dffn_all = data[li]['delta_ffn']
    ctx_all = data[li]['context']
    datt_all = data[li]['delta_att']
    N_tr = int(0.9 * N)
    Phi_all = quad_kernel(ln2_all)
    Phi_tr = Phi_all[:N_tr]
    Phi_val = Phi_all[N_tr:]
    Y_tr = dffn_all[:N_tr]
    Y_val = dffn_all[N_tr:]
    W_ffn, r2_ffn = solve_ridge(Phi_all, dffn_all, lam=1e-06)
    W_att, r2_att = solve_ridge(ctx_all, datt_all, lam=1e-08)
    Pb_val = np.hstack([Phi_val, np.ones((len(Phi_val), 1))])
    Yp_val = Pb_val @ W_ffn
    ss_r = np.sum((Y_val - Yp_val) ** 2)
    ss_t = np.sum((Y_val - Y_val.mean(0)) ** 2)
    r2_val = float(1 - ss_r / ss_t) if ss_t > 1e-15 else 1.0
    solved[li] = {'W_ffn': W_ffn, 'W_att': W_att}
    vf = '✓' if r2_ffn > 0.9999 else '~'
    va = '✓' if r2_att > 0.9999 else '~'
    vv = '✓' if r2_val > 0.999 else '~' if r2_val > 0.99 else '!'
    print(f'  L{li:<7} {r2_ffn:.6f} {vf}  {r2_att:.6f} {va}  {r2_val:.6f} {vv}')
print(f'  Solve: {time.time() - t_s:.1f}s')

def wk_forward(ids_use, wk_ffn=True, wk_att=True):
    T = len(ids_use)
    x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
    for li in range(n_layers):
        blk = model_ref.transformer.h[li]
        ln1w = blk.ln_1.weight.detach().numpy()
        ln1b = blk.ln_1.bias.detach().numpy()
        ln2w = blk.ln_2.weight.detach().numpy()
        ln2b = blk.ln_2.bias.detach().numpy()
        att = blk.attn.attention
        Wq = att.q_proj.weight.detach().numpy()
        Wk_ = att.k_proj.weight.detach().numpy()
        Wv = att.v_proj.weight.detach().numpy()
        Wo = att.out_proj.weight.detach().numpy()
        bo = att.out_proj.bias.detach().numpy()
        W1 = blk.mlp.c_fc.weight.detach().numpy()
        b1 = blk.mlp.c_fc.bias.detach().numpy()
        W2 = blk.mlp.c_proj.weight.detach().numpy()
        b2 = blk.mlp.c_proj.bias.detach().numpy()
        W_ffn = solved[li]['W_ffn']
        W_att = solved[li]['W_att']
        ln1 = np.array([ln_np(x[i:i + 1], ln1w, ln1b)[0] for i in range(T)])
        Q = ln1 @ Wq.T
        K = ln1 @ Wk_.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads, 1).reshape(T, D)
        att_out = context @ Wo.T + bo
        x_att = x + att_out
        if wk_att:
            ctx_b = np.append(context[-1], 1.0)
            x_att[-1] = x[-1] + ctx_b @ W_att
        x_new = x_att.copy()
        for t in range(T):
            ln2t = ln_np(x_att[t:t + 1], ln2w, ln2b)[0]
            if t == T - 1 and wk_ffn:
                Pb = np.append(quad_kernel(ln2t.reshape(1, -1))[0], 1.0)
                x_new[t] = x_att[t] + Pb @ W_ffn
            else:
                x_new[t] = x_att[t] + gelu_np(ln2t @ W1.T + b1) @ W2.T + b2
        x = x_new
    lnfw = model_ref.transformer.ln_f.weight.detach().numpy()
    lnfb = model_ref.transformer.ln_f.bias.detach().numpy()
    lmw = model_ref.lm_head.weight.detach().numpy()
    return ln_np(x[-1:], lnfw, lnfb)[0] @ lmw.T
TEST_PROMPTS = ['The little fox found a shiny stone by the river', 'Once a kind farmer helped a lost baby deer', 'She climbed the tall tree and saw the whole village', 'A brave boy sailed across the dark stormy sea', 'The old wizard gave the child a glowing lantern', 'A rabbit and a turtle became the best of friends', 'The queen looked out her window at the falling snow', 'He woke up early and saw the first light of dawn', 'A small seed grew into the tallest tree in the land', 'The sleepy bear found a cave and curled up inside']
print(f"\n{'=' * 70}")
print(f'  EVALUATION')
print(f"{'=' * 70}\n")

def calc_ppl(prompts, label, mode='ref'):
    nll = 0.0
    tok = 0
    cor = 0
    with torch.no_grad():
        for prompt in prompts:
            ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
            if len(ids) < 3:
                continue
            for i in range(1, min(len(ids), 20)):
                ctx = ids[:i]
                true_next = ids[i]
                if mode == 'ref':
                    out = model_ref(torch.tensor([ctx]))
                    logits = out.logits[0, -1, :].numpy().astype(np.float64)
                else:
                    logits = wk_forward(ctx, wk_ffn='ffn' in mode or 'both' in mode, wk_att='att' in mode or 'both' in mode)
                lg = logits - logits.max()
                lp = lg - np.log(np.sum(np.exp(lg)))
                nll += -lp[true_next]
                tok += 1
                if int(np.argmax(logits)) == true_next:
                    cor += 1
    ppl = math.exp(nll / tok) if tok > 0 else float('inf')
    acc = cor / tok * 100 if tok > 0 else 0
    print(f'  {label:<35} ppl={ppl:>8.2f}  acc={acc:>5.1f}%')
    return ppl
ppl_r = calc_ppl(TEST_PROMPTS, 'Reference (gradient descent)', 'ref')
ppl_f = calc_ppl(TEST_PROMPTS, 'W-Kernel FFN only', 'wk_ffn')
ppl_a = calc_ppl(TEST_PROMPTS, 'W-Kernel ATT only', 'wk_att')
ppl_b = calc_ppl(TEST_PROMPTS, 'W-Kernel FFN+ATT', 'wk_both')
print(f'\n  FFN ratio:  {ppl_f / ppl_r:.6f}   (1.000 = perfect)')
print(f'  ATT ratio:  {ppl_a / ppl_r:.6f}   (1.000 = perfect)')
print(f'  Both ratio: {ppl_b / ppl_r:.6f}   (1.000 = perfect)')
ratio_verdict = ppl_b / ppl_r
if ratio_verdict < 1.01:
    v = '✓ O(1) TRAINING PROVEN'
elif ratio_verdict < 1.05:
    v = '~ VERY CLOSE — increase N further'
elif ratio_verdict < 1.15:
    v = '! CLOSING — more data needed'
else:
    v = '✗ UNDERDETERMINED — N too small'
print(f'\n  VERDICT: {v}  (N={N}, ratio={N / QUAD_DIM:.1f}x)')
print(f"\n{'=' * 70}")
print(f'  GENERATION (20 tokens)')
print(f"{'=' * 70}\n")
for prompt in ['Once upon a time a little', 'Deep in the forest lived a', 'The brave knight found a']:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    ir = ids[:]
    iw = ids[:]
    rt = []
    wt = []
    for _ in range(20):
        with torch.no_grad():
            nr = torch.argmax(model_ref(torch.tensor([ir])).logits[0, -1, :]).item()
        ir.append(nr)
        rt.append(nr)
        nw = int(np.argmax(wk_forward(iw, True, True)))
        iw.append(nw)
        wt.append(nw)
    print(f"  '{prompt}'")
    print(f'    REF: {tokenizer.decode(rt)}')
    print(f'    WK:  {tokenizer.decode(wt)}')
    print(f'    match: {sum((a == b for a, b in zip(rt, wt)))}/20\n')
print(f"{'=' * 70}")
print(f'  N={N}, N/QUAD_DIM={N / QUAD_DIM:.1f}x, total={time.time() - t0:.0f}s')
print(f'  Trend: v2(N=5670)=1.159 → v3(N=10100)=1.065 → v5(N={N})=?')
print(f"{'=' * 70}\n")
