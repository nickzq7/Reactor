import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
vocab = model.config.vocab_size
print(f'D={D}  Layers={n_layers}  Vocab={vocab}')
W1s = {}
b1s = {}
for li in range(n_layers):
    block = model.transformer.h[li]
    W1s[li] = block.mlp.c_fc.weight.detach().float().numpy().T
    b1s[li] = block.mlp.c_fc.bias.detach().float().numpy()
print(f'W1 extracted for all {n_layers} layers.')

def gelu_np(x):
    return x * 0.5 * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))

def natural_address(h, layer_idx):
    pre = h @ W1s[layer_idx] + b1s[layer_idx]
    return gelu_np(pre)
print(f'\nBuilding W-Index with layer-processed embeddings...')
print(f'Running all {vocab} tokens through layer 0...')
embeddings_raw = model.transformer.wte.weight.detach().float()
pos0 = model.transformer.wpe.weight[0].detach().float()
h0_all = embeddings_raw + pos0.unsqueeze(0)
block0 = model.transformer.h[0]
with torch.no_grad():
    h0_ln = block0.ln_1(h0_all.unsqueeze(1))
    h0_ln2 = block0.ln_2(h0_all.unsqueeze(1))
    h0_ln2_np = h0_ln2.squeeze(1).numpy()
print(f'Computing natural addresses (layer 0 post-norm)...')
W_addresses = np.zeros((vocab, W1s[0].shape[1]), dtype=np.float32)
for i in range(vocab):
    W_addresses[i] = natural_address(h0_ln2_np[i], layer_idx=0)
addr_norms = np.linalg.norm(W_addresses, axis=1, keepdims=True) + 1e-08
W_addresses_norm = W_addresses / addr_norms
print(f'W-Index ready. Address dim={W_addresses.shape[1]}')
captured = {}

def make_hook(name):

    def hook(mod, inp, out):
        if isinstance(out, tuple):
            captured[name] = out[0].detach().float()
        else:
            captured[name] = out.detach().float()
    return hook
hooks = []
for li in range(n_layers):
    hooks.append(model.transformer.h[li].register_forward_hook(make_hook(f'layer_{li}')))
hooks.append(model.transformer.ln_f.register_forward_hook(make_hook('ln_f')))

def w_index_predict(hidden_state_np, layer_idx=0):
    rms = np.sqrt(np.mean(hidden_state_np ** 2) + 1e-05)
    h_norm = hidden_state_np / rms
    addr = natural_address(h_norm, layer_idx=layer_idx)
    addr = addr / (np.linalg.norm(addr) + 1e-08)
    sims = W_addresses_norm @ addr
    return int(np.argmax(sims))

def generate_and_compare(prompt, max_new=100):
    input_ids = tokenizer.encode(prompt, return_tensors='pt')
    normal_tokens = []
    w_index_tokens = {li: [] for li in range(n_layers)}
    matches = {li: [] for li in range(n_layers)}
    current_ids = input_ids.clone()
    with torch.no_grad():
        for step in range(max_new):
            out = model(current_ids)
            logits = out.logits[0, -1, :]
            normal_tok = int(torch.argmax(logits).item())
            normal_tokens.append(normal_tok)
            for li in range(n_layers):
                h = captured[f'layer_{li}'][0, -1, :].numpy()
                w_tok = w_index_predict(h, layer_idx=li)
                w_index_tokens[li].append(w_tok)
                matches[li].append(1 if w_tok == normal_tok else 0)
            current_ids = torch.cat([current_ids, torch.tensor([[normal_tok]])], dim=1)
            if normal_tok == tokenizer.eos_token_id:
                break
    return (normal_tokens, w_index_tokens, matches)
prompt = 'Once upon a time there was a little girl who loved to'
print(f"\nGenerating 100 tokens from: '{prompt}'")
print(f'Testing W-Index at each of {n_layers} layers...')
normal_toks, w_toks, match_map = generate_and_compare(prompt, max_new=100)
for h in hooks:
    h.remove()
print(f"\n{'=' * 70}")
print(f'  W-INDEX GENERATION TEST')
print(f'  Prompt: {prompt}')
print(f"{'=' * 70}")
print(f'\n  Layer accuracy (W-Index matches normal generation):')
print(f"  {'Layer':<8} {'Accuracy':<12} {'Correct/100'}")
print(f"  {'─' * 35}")
best_layer = 0
best_acc = 0
for li in range(n_layers):
    n = len(match_map[li])
    acc = sum(match_map[li]) / n
    correct = sum(match_map[li])
    if acc > best_acc:
        best_acc = acc
        best_layer = li
    marker = ' ← BEST' if li == best_layer else ''
    print(f"  {li:<8} {acc:.1%}{('  ✓' if acc > 0.5 else ''):<5}{correct}/{n}{marker}")
print(f'\n  TOKEN BY TOKEN (best layer = {best_layer}):')
print(f"  {'#':<4} {'Normal':<20} {'W-Index':<20} {'Match'}")
print(f"  {'─' * 55}")
n_show = min(50, len(normal_toks))
for i in range(n_show):
    nt = tokenizer.decode([normal_toks[i]])
    wt = tokenizer.decode([w_toks[best_layer][i]])
    match = '✓' if match_map[best_layer][i] else '✗'
    print(f'  {i:<4} {repr(nt):<20} {repr(wt):<20} {match}')
normal_text = tokenizer.decode(normal_toks, skip_special_tokens=True)
best_w_text = tokenizer.decode(w_toks[best_layer], skip_special_tokens=True)
print(f"\n{'=' * 70}")
print(f'  NORMAL TEXT:\n  {prompt}{normal_text}')
print(f'\n  W-INDEX TEXT (layer {best_layer}):\n  {prompt}{best_w_text}')
print(f'\n  Best layer accuracy: {best_acc:.1%}')
print(f"{'=' * 70}")
print(f'\n  DIAGNOSIS:\n\n  If accuracy is low at layer 0:\n    Natural address at layer 0 = too early.\n    Not enough context processed yet.\n    Layer 0 W1 = low level features only.\n\n  If accuracy rises at deeper layers:\n    Deeper natural space = richer address.\n    Meaning builds through layers.\n    Best layer = where natural address = next token address.\n\n  If accuracy never exceeds 20%:\n    W-Index concept needs refinement.\n    Natural address ≠ next token address directly.\n    Need different DSA operation.\n    Still valid DSA — just different operation.\n\n  Gap between best layer and 100%:\n    That gap = what W-Index is missing.\n    Tells us exactly what to build next.\n')
print('=' * 70 + '\n')
