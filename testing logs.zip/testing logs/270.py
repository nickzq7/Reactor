import numpy as np
import torch
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — SEMANTIC RAM: REPLACE lm_HEAD')
print('  x_final = complete address. RAM replaces 50,257-way projection.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
VOCAB = model.config.vocab_size
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={n_layers}  Vocab={VOCAB}')
print(f'\n  lm_head size: {D}×{VOCAB}×4 bytes = {D * VOCAB * 4 / 1024:.1f} KB')
print(f'  On 7B: 4096×32000×4 = {4096 * 32000 * 4 / 1024 / 1024:.1f} MB')
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()
LW = {}
with torch.no_grad():
    for l in range(n_layers):
        blk = model.transformer.h[l]
        att = blk.attn.attention
        LW[l] = {'Wq': att.q_proj.weight.numpy(), 'Wk': att.k_proj.weight.numpy(), 'Wv': att.v_proj.weight.numpy(), 'Wo': att.out_proj.weight.numpy(), 'bo': att.out_proj.bias.numpy(), 'W1': blk.mlp.c_fc.weight.numpy(), 'b1': blk.mlp.c_fc.bias.numpy(), 'W2': blk.mlp.c_proj.weight.numpy(), 'b2': blk.mlp.c_proj.bias.numpy(), 'ln1_w': blk.ln_1.weight.numpy(), 'ln1_b': blk.ln_1.bias.numpy(), 'ln2_w': blk.ln_2.weight.numpy(), 'ln2_b': blk.ln_2.bias.numpy()}

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def run_all_layers(token_ids):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
    for l in range(n_layers):
        W = LW[l]
        ln1 = ln(x, W['ln1_w'], W['ln1_b'])
        Q = ln1 @ W['Wq'].T
        K = ln1 @ W['Wk'].T
        V = ln1 @ W['Wv'].T
        Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        heads = [softmax(Qh[h] @ Kh[h].T + mask) @ Vh[h] for h in range(n_heads)]
        x = x + np.stack(heads, 1).reshape(seq_len, D) @ W['Wo'].T + W['bo']
        pre = ln(x, W['ln2_w'], W['ln2_b']) @ W['W1'].T + W['b1']
        x = x + gelu(pre) @ W['W2'].T + W['b2']
    x_final = x[-1]
    h_f = ln(x, lnf_w, lnf_b)
    logits = (h_f[-1:] @ lm_w.T)[0]
    true_next = int(np.argmax(logits))
    return (x_final, true_next)

def cosine_sim_batch(v, M):
    v_n = v / (np.linalg.norm(v) + 1e-08)
    M_n = M / (np.linalg.norm(M, axis=1, keepdims=True) + 1e-08)
    return M_n @ v_n
print(f"\n{'=' * 70}")
print(f'  PHASE 1 — BUILD RAM (x_final after ALL layers)')
print(f"{'=' * 70}\n")
SET_A = ['Once upon a time, a little girl named Lily', 'Deep in the dark forest, a large dragon lived', 'A small dog ran across the green field', 'When the sun came up in the morning the birds', 'She smiled and said to her mother I love', 'The children played in the garden all day long', 'Every morning the little bird sang a sweet song', 'He found a treasure chest in the old dark cave', 'The princess looked out of her window and saw', 'A tiny mouse ran across the kitchen floor quietly', 'The old wizard cast a magic spell on the dragon', 'They walked through the dark cave together slowly', 'The baby bear found honey in the tall old tree', 'Far away in the mountains there lived a giant', 'A butterfly flew over the flowers in the meadow', 'The farmer woke up early and fed his animals well', 'She picked up the book and began to read slowly', 'The little boat sailed across the calm blue lake', 'A rainbow appeared in the sky after the rain fell', 'The friendly fox helped the rabbit find her way home', 'The cat jumped over the fence into the garden', 'A bright star shone in the dark night sky', 'The little boy ran to his mother and hugged her', 'She found a beautiful shell on the sandy beach', 'The wind blew the leaves off the tall oak tree']
x_finals_collected = []
tokens_collected = []
x_after_last = []

def hook_last(m, inp, out):
    x_after_last.append(out[0][0, -1, :].detach().numpy().copy())
h = model.transformer.h[n_layers - 1].register_forward_hook(hook_last)
with torch.no_grad():
    for prompt in SET_A:
        ids = tokenizer.encode(prompt, return_tensors='pt')
        for _ in range(30):
            out = model(ids)
            nxt = torch.argmax(out.logits[0, -1, :]).item()
            x_finals_collected.append(x_after_last.pop())
            tokens_collected.append(nxt)
            ids = torch.cat([ids, torch.tensor([[nxt]])], dim=1)
h.remove()
RAM_x = np.array(x_finals_collected, dtype=np.float32)
RAM_tokens = np.array(tokens_collected, dtype=np.int32)
print(f'  RAM: {len(RAM_x)} entries')
print(f'  Each key: {D} floats = {D * 4} bytes')
print(f'  Total RAM: {RAM_x.nbytes / 1024:.1f} KB  vs  lm_head: {lm_w.nbytes / 1024:.1f} KB')
print(f'  Unique tokens: {len(np.unique(RAM_tokens))}/{VOCAB}')
print(f"\n{'=' * 70}")
print(f'  PHASE 2 — GENERALIZATION TEST (SET B)')
print(f'  All 8 layers run. Only lm_head is replaced by RAM lookup.')
print(f"{'=' * 70}\n")
SET_B = ['The queen wore a golden crown and sat', 'A little fish swam in the clear blue pond', 'The farmer planted seeds in the dark soil', 'In a land far away there was a castle', 'Her eyes sparkled when she saw the present', 'The young boy climbed the tall oak tree', 'A white rabbit hopped through the green garden', 'The cook made a delicious soup for everyone']
N_GEN = 20
THRESHOLDS = [0.9999, 0.999, 0.998, 0.995, 0.99, 0.98, 0.97]
print(f"  {'Threshold':<12} {'RAM hits':<12} {'Acc%':<10} {'verdict'}")
print(f"  {'─' * 46}")
for thresh in THRESHOLDS:
    correct = 0
    total = 0
    hits = 0
    for prompt in SET_B:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        for step in range(N_GEN):
            x_final, true_next = run_all_layers(ids)
            sims = cosine_sim_batch(x_final, RAM_x)
            best_idx = int(np.argmax(sims))
            best_sim = float(sims[best_idx])
            if best_sim >= thresh:
                ram_next = int(RAM_tokens[best_idx])
                hits += 1
            else:
                ram_next = true_next
            correct += ram_next == true_next
            total += 1
            ids.append(true_next)
    acc = 100 * correct / total
    hit_pct = 100 * hits / total
    v = '✓ EXACT' if acc == 100 else '✓ GOOD' if acc >= 90 else '~ USABLE' if acc >= 70 else '✗ POOR'
    print(f'  {thresh:<12.4f} {hit_pct:<12.1f}% {acc:<10.1f}% {v}')
print(f"\n{'=' * 70}")
print(f'  PHASE 3 — COSINE SIMILARITY DISTRIBUTION')
print(f'  For SET B tokens: what is best cosine sim found in RAM?')
print(f'  This tells us if x_final states overlap across contexts.')
print(f"{'=' * 70}\n")
sims_correct = []
sims_wrong = []
best_sims_all = []
for prompt in SET_B[:3]:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    for step in range(15):
        x_final, true_next = run_all_layers(ids)
        sims = cosine_sim_batch(x_final, RAM_x)
        best_idx = int(np.argmax(sims))
        best_sim = float(sims[best_idx])
        ram_next = int(RAM_tokens[best_idx])
        best_sims_all.append(best_sim)
        if ram_next == true_next:
            sims_correct.append(best_sim)
        else:
            sims_wrong.append(best_sim)
        ids.append(true_next)
print(f'  Best cosine sim statistics (SET B vs RAM):\n')
print(f'  All tokens:      mean={np.mean(best_sims_all):.4f}  min={np.min(best_sims_all):.4f}  max={np.max(best_sims_all):.4f}')
if sims_correct:
    print(f'  When correct:    mean={np.mean(sims_correct):.4f}  min={np.min(sims_correct):.4f}  max={np.max(sims_correct):.4f}')
if sims_wrong:
    print(f'  When wrong:      mean={np.mean(sims_wrong):.4f}  min={np.min(sims_wrong):.4f}  max={np.max(sims_wrong):.4f}')
buckets = [0.9, 0.95, 0.97, 0.98, 0.99, 0.995, 0.999, 1.0]
print(f'\n  Cosine sim distribution:')
for i in range(len(buckets) - 1):
    lo, hi = (buckets[i], buckets[i + 1])
    count = sum((lo <= s < hi for s in best_sims_all))
    pct = 100 * count / len(best_sims_all)
    bar = '█' * int(pct / 2)
    print(f'  [{lo:.3f}-{hi:.3f}): {count:4d} ({pct:5.1f}%)  {bar}')
print(f"\n{'=' * 70}")
print(f'  PHASE 4 — TOKEN-BY-TOKEN VIEW (threshold=0.999)')
print(f"{'=' * 70}\n")
thresh = 0.999
for prompt in SET_B[:2]:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    print(f'  Prompt: {prompt}')
    print(f"  {'#':<4} {'True':<16} {'RAM':<16} {'Sim':<8} {'Match'}")
    print(f"  {'─' * 48}")
    for step in range(12):
        x_final, true_next = run_all_layers(ids)
        sims = cosine_sim_batch(x_final, RAM_x)
        best_idx = int(np.argmax(sims))
        best_sim = float(sims[best_idx])
        ram_next = int(RAM_tokens[best_idx])
        ids.append(true_next)
        ts = repr(tokenizer.decode([true_next]))[:14]
        rs = repr(tokenizer.decode([ram_next]))[:14]
        m = '✓' if ram_next == true_next else '✗'
        print(f'  {step + 1:<4} {ts:<16} {rs:<16} {best_sim:<8.4f} {m}')
    print()
print(f"\n{'=' * 70}")
print(f'  PHASE 5 — OPERATION COUNT')
print(f'  lm_head vs RAM lookup: how many multiplications?')
print(f"{'=' * 70}\n")
N = 100
lm_ops = N * D * VOCAB
ram_ops = N * D * len(RAM_x)
print(f'  lm_head multiplications: {N} × {D} × {VOCAB} = {lm_ops:,}')
print(f'  RAM lookup multiplications: {N} × {D} × {len(RAM_x)} = {ram_ops:,}')
print(f'  Reduction: {lm_ops / ram_ops:.1f}x fewer operations')
print(f'\n  On 7B model:')
D7, V7, RAM7 = (4096, 32000, 750)
print(f'  lm_head: {D7}×{V7} = {D7 * V7:,} ops/token  ({D7 * V7 * 4 / 1024 / 1024:.1f} MB)')
print(f'  RAM:     {D7}×{RAM7} = {D7 * RAM7:,} ops/token  ({D7 * RAM7 * 4 / 1024:.1f} KB)')
print(f'  Reduction: {D7 * V7 / (D7 * RAM7):.1f}x fewer operations')
print(f'  IO saved: {D7 * V7 * 4 / 1024 / 1024:.1f} MB → {D7 * RAM7 * 4 / 1024:.1f} KB per token')
print(f"\n{'=' * 70}")
print(f'  FINAL CONCLUSION')
print(f"{'=' * 70}\n")
print(f'\n  CORRECT APPROACH (this test):\n    Run ALL 8 layers. x_final = complete state.\n    Replace ONLY lm_head with RAM cosine lookup.\n    All computation = exact. No quality loss.\n    Only the final projection = replaced.\n\n  WHAT THE ACCURACY TELLS US:\n    If acc > 90%:\n      x_final IS a universal semantic address.\n      Different prompts with same meaning → same x_final.\n      RAM replaces lm_head exactly.\n      On 7B: 524MB lm_head → 3MB RAM. Per token.\n      \n    If acc < 90% at all thresholds:\n      x_final is context-specific.\n      RAM only works for repeated/similar queries.\n      Still valid as inference cache.\n      Still saves IO on repeated requests.\n\n  W LAW STATUS:\n    x_final → lm_head = exact linear (R²=1.000, proven).\n    lm_head = just reading what x_final already decided.\n    x_final = the token. lm_head = the translator.\n    Sanskrit: replace 50,257-word dictionary\n    with small set of known addresses.\n')
print('=' * 70 + '\n')
