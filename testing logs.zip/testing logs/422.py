import torch
import numpy as np
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL = 'roneneldan/TinyStories-1M'
N_TEXTS = 200
N_RUNS = 5
print('\n' + '=' * 70)
print('  W LAWS — COMPLETE TEST — TinyStories-1M')
print('=' * 70)
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL)
model.eval()
D = model.config.hidden_size
FFN_D = model.config.intermediate_size
N_LAYERS = model.config.num_hidden_layers
HEADS = model.config.num_attention_heads
HEAD_DIM = D // HEADS
print(f'\n  D={D}  FFN={FFN_D}  Layers={N_LAYERS}  Heads={HEADS}')
print(f'\n  Generating {N_TEXTS} texts for activation collection...')
SEED_PROMPTS = ['Once upon a time', 'The little boy', 'She smiled because', 'Deep in the forest', 'The old man said', 'Every morning', 'The dragon flew', 'She opened the door', 'Tommy was scared', 'The brave knight']
texts = []
for p in SEED_PROMPTS * (N_TEXTS // len(SEED_PROMPTS) + 1):
    ids = tok.encode(p, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=40, do_sample=True, temperature=0.9, pad_token_id=tok.eos_token_id)
    texts.append(tok.decode(out[0], skip_special_tokens=True))
    if len(texts) >= N_TEXTS:
        break
print(f'  Generated {len(texts)} texts')
print(f'\n  Collecting activations from {len(texts)} texts...')
gelu_acts = {l: [] for l in range(N_LAYERS)}
ffn_outs = {l: [] for l in range(N_LAYERS)}
h_inputs = {l: [] for l in range(N_LAYERS)}
hooks = []
layer_refs = {}
for li in range(N_LAYERS):
    layer = model.transformer.h[li]

    def make_hook(l):

        def forward_hook(mod, inp, out):
            h_in = inp[0].detach()
            ln2_out = layer.ln_2(h_in)
            pre = ln2_out @ model.transformer.h[l].mlp.c_fc.weight.T + model.transformer.h[l].mlp.c_fc.bias
            act = torch.nn.functional.gelu(pre)
            ffn = model.transformer.h[l].mlp.c_proj(act)
            T = h_in.shape[1]
            gelu_acts[l].append(act.squeeze(0).detach().numpy())
            ffn_outs[l].append(ffn.squeeze(0).detach().numpy())
            h_inputs[l].append(h_in.squeeze(0).detach().numpy())
        return forward_hook
    hooks.append(layer.mlp.register_forward_hook(make_hook(li)))
with torch.no_grad():
    for i, text in enumerate(texts):
        if i % 50 == 0:
            print(f'    {i}/{len(texts)}...')
        ids = tok.encode(text, return_tensors='pt', max_length=64, truncation=True)
        model(ids)
for h in hooks:
    h.remove()
G = {l: np.vstack(gelu_acts[l]) for l in range(N_LAYERS)}
F = {l: np.vstack(ffn_outs[l]) for l in range(N_LAYERS)}
N_samples = G[0].shape[0]
print(f'  Total samples: {N_samples} per layer')

def r2(y_pred, y_true):
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true, axis=0)) ** 2)
    return 1 - ss_res / (ss_tot + 1e-10)

def fit_w(X, Y, add_bias=True):
    if add_bias:
        X = np.hstack([X, np.ones((len(X), 1))])
    W = np.linalg.lstsq(X, Y, rcond=None)[0]
    return (W, X)
print(f"\n{'=' * 70}")
print(f'  TEST A — PER-LAYER W_ffn (expect R²=1.000 at every layer)')
print(f"{'=' * 70}\n")
W_ffn_layers = {}
r2_per_layer = []
split = int(N_samples * 0.8)
print(f"  {'Layer':<8} {'R²_train':<12} {'R²_test':<12} {'Law?'}")
print(f"  {'─' * 44}")
for l in range(N_LAYERS):
    G_train, G_test = (G[l][:split], G[l][split:])
    F_train, F_test = (F[l][:split], F[l][split:])
    W, G_train_b = fit_w(G_train, F_train)
    W_ffn_layers[l] = W
    pred_train = np.hstack([G_train, np.ones((len(G_train), 1))]) @ W
    pred_test = np.hstack([G_test, np.ones((len(G_test), 1))]) @ W
    r2_tr = r2(pred_train, F_train)
    r2_te = r2(pred_test, F_test)
    r2_per_layer.append(r2_te)
    law = '✓ 1.000' if r2_te > 0.999 else f'  {r2_te:.4f}'
    print(f'  {l:<8} {r2_tr:<12.6f} {r2_te:<12.6f} {law}')
print(f'\n  Min R² across layers: {min(r2_per_layer):.6f}')
print(f'  Max R² across layers: {max(r2_per_layer):.6f}')
print(f"  Law holds everywhere: {('✓ YES' if min(r2_per_layer) > 0.999 else '✗ NO')}")
print(f"\n{'=' * 70}")
print(f'  TEST B — SHARED W_ffn (one matrix for ALL {N_LAYERS} layers)')
print(f'  KEY QUESTION: can one rule replace all FFN blocks?')
print(f"{'=' * 70}\n")
G_all = np.vstack([G[l] for l in range(N_LAYERS)])
F_all = np.vstack([F[l] for l in range(N_LAYERS)])
split_all = int(len(G_all) * 0.8)
G_tr_all, G_te_all = (G_all[:split_all], G_all[split_all:])
F_tr_all, F_te_all = (F_all[:split_all], F_all[split_all:])
W_shared, G_tr_b = fit_w(G_tr_all, F_tr_all)
pred_tr = np.hstack([G_tr_all, np.ones((len(G_tr_all), 1))]) @ W_shared
pred_te = np.hstack([G_te_all, np.ones((len(G_te_all), 1))]) @ W_shared
r2_shared_tr = r2(pred_tr, F_tr_all)
r2_shared_te = r2(pred_te, F_te_all)
print(f'  Shared W_ffn R² train: {r2_shared_tr:.6f}')
print(f'  Shared W_ffn R² test:  {r2_shared_te:.6f}')
print()
print(f"  {'Layer':<8} {'R² (shared)':<14} {'vs per-layer':<12} {'gap'}")
print(f"  {'─' * 50}")
for l in range(N_LAYERS):
    pred_l = np.hstack([G[l], np.ones((len(G[l]), 1))]) @ W_shared
    r2_l = r2(pred_l, F[l])
    gap = r2_per_layer[l] - r2_l
    print(f'  {l:<8} {r2_l:<14.6f} {r2_per_layer[l]:<12.6f} -{gap:.4f}')
print(f'\n  Shared R²: {r2_shared_te:.4f}')
if r2_shared_te > 0.999:
    verdict = '✓ PERFECT — one matrix = all layers'
elif r2_shared_te > 0.95:
    verdict = '~ GOOD — usable with small quality loss'
elif r2_shared_te > 0.9:
    verdict = '~ PARTIAL — noticeable quality loss'
else:
    verdict = '✗ NOT ENOUGH — per-layer needed'
print(f'  Verdict: {verdict}')
print(f"\n{'=' * 70}")
print(f'  TEST C — ACTUAL COMPRESSION NUMBERS')
print(f"{'=' * 70}\n")
original_c_fc_params = D * FFN_D + FFN_D
original_c_proj_params = FFN_D * D + D
original_ffn_params = original_c_fc_params + original_c_proj_params
original_all_ffn = original_ffn_params * N_LAYERS
wffn_params = (FFN_D + 1) * D
wffn_per_layer = wffn_params
wffn_all_layers = wffn_params * N_LAYERS
wffn_shared = wffn_params
orig_bytes_all = original_all_ffn * 4
wffn_bytes_all = wffn_all_layers * 4
wffn_bytes_shr = wffn_shared * 4
print(f'  Original FFN per layer:')
print(f'    W1 (c_fc):   {D}×{FFN_D} + {FFN_D} = {original_c_fc_params:,} params = {original_c_fc_params * 4 / 1024:.1f}KB')
print(f'    W2 (c_proj): {FFN_D}×{D} + {D} = {original_c_proj_params:,} params = {original_c_proj_params * 4 / 1024:.1f}KB')
print(f'    Total FFN:   {original_ffn_params:,} params = {original_ffn_params * 4 / 1024:.1f}KB')
print(f'    All {N_LAYERS} layers: {original_all_ffn:,} params = {orig_bytes_all / 1024:.1f}KB')
print()
print(f'  W_ffn per layer:')
print(f'    W_ffn:       ({FFN_D}+1)×{D} = {wffn_params:,} params = {wffn_params * 4 / 1024:.1f}KB')
print(f'    Replaces:    W2 only (W1 still needed)')
print(f'    Saving:      c_proj bias ({D * 4} bytes) — tiny')
print()
print(f'  Shared W_ffn (ONE for all {N_LAYERS} layers):')
print(f'    W_shared:    {wffn_shared:,} params = {wffn_bytes_shr / 1024:.1f}KB')
print(f'    vs all W2:   {original_c_proj_params * N_LAYERS * 4 / 1024:.1f}KB')
compression_shared = original_c_proj_params * N_LAYERS / wffn_shared
print(f'    Compression: {compression_shared:.1f}x on W2 portion')
print(f"    If R²={r2_shared_te:.3f}: {('usable' if r2_shared_te > 0.95 else 'lossy')}")
print()
print(f'  HONEST COMPRESSION SUMMARY:')
print(f'    Per-layer W_ffn:    1.0x  (same size as W2)')
print(f'    Shared W_ffn:       {compression_shared:.1f}x  on W2 (R²={r2_shared_te:.4f})')
print(f'    W1 still required:  cannot compress (generates natural space)')
print(f'    Net compression:    {N_LAYERS}x on W2 if shared works = saves {original_c_proj_params * (N_LAYERS - 1) * 4 / 1024:.0f}KB on this model')
print(f"\n{'=' * 70}")
print(f'  TEST D — SPEED COMPARISON')
print(f'  Normal forward vs W_ffn forward vs Shared W_ffn forward')
print(f"{'=' * 70}\n")
device = next(model.parameters()).device

def forward_normal(ids):
    with torch.no_grad():
        return model(ids).logits[0, -1, :]
W_ffn_torch = {l: torch.tensor(W_ffn_layers[l], dtype=torch.float32) for l in range(N_LAYERS)}
W_shared_torch = torch.tensor(W_shared, dtype=torch.float32)

def forward_w_per_layer(ids):
    with torch.no_grad():
        h = model.transformer.wte(ids) + model.transformer.wpe(torch.arange(ids.shape[1]).unsqueeze(0))
        for l in range(N_LAYERS):
            layer = model.transformer.h[l]
            ln1_out = layer.ln_1(h)
            attn_out = layer.attn(ln1_out)[0]
            h = h + attn_out
            ln2_out = layer.ln_2(h)
            pre = ln2_out @ layer.mlp.c_fc.weight.T + layer.mlp.c_fc.bias
            act = torch.nn.functional.gelu(pre)
            act_b = torch.cat([act, torch.ones(*act.shape[:-1], 1)], dim=-1)
            ffn_out = act_b @ W_ffn_torch[l]
            h = h + ffn_out
        h = model.transformer.ln_f(h)
        return model.lm_head(h)[0, -1, :]

def forward_w_shared(ids):
    with torch.no_grad():
        h = model.transformer.wte(ids) + model.transformer.wpe(torch.arange(ids.shape[1]).unsqueeze(0))
        for l in range(N_LAYERS):
            layer = model.transformer.h[l]
            ln1_out = layer.ln_1(h)
            attn_out = layer.attn(ln1_out)[0]
            h = h + attn_out
            ln2_out = layer.ln_2(h)
            pre = ln2_out @ layer.mlp.c_fc.weight.T + layer.mlp.c_fc.bias
            act = torch.nn.functional.gelu(pre)
            act_b = torch.cat([act, torch.ones(*act.shape[:-1], 1)], dim=-1)
            ffn_out = act_b @ W_shared_torch
            h = h + ffn_out
        h = model.transformer.ln_f(h)
        return model.lm_head(h)[0, -1, :]
TEST_PROMPTS = ['Once upon a time', 'The brave knight', 'Deep in the forest', 'She opened the door', 'The old wizard cast', 'Tommy was afraid']
ids0 = tok.encode(TEST_PROMPTS[0], return_tensors='pt')
for _ in range(3):
    forward_normal(ids0)
    forward_w_per_layer(ids0)
    forward_w_shared(ids0)
times_normal, times_wffn, times_shared = ([], [], [])
print(f"  {'Prompt':<32} {'Normal':<12} {'W_ffn':<12} {'Shared':<12} {'Match_wffn'}")
print(f"  {'─' * 76}")
match_wffn = 0
match_shared = 0
total = 0
for prompt in TEST_PROMPTS:
    ids = tok.encode(prompt, return_tensors='pt')
    t_norm = []
    for _ in range(N_RUNS):
        t0 = time.perf_counter()
        out_norm = forward_normal(ids)
        t_norm.append((time.perf_counter() - t0) * 1000)
    t_wffn = []
    for _ in range(N_RUNS):
        t0 = time.perf_counter()
        out_wffn = forward_w_per_layer(ids)
        t_wffn.append((time.perf_counter() - t0) * 1000)
    t_shr = []
    for _ in range(N_RUNS):
        t0 = time.perf_counter()
        out_shr = forward_w_shared(ids)
        t_shr.append((time.perf_counter() - t0) * 1000)
    mn = np.mean(t_norm)
    mw = np.mean(t_wffn)
    ms = np.mean(t_shr)
    times_normal.append(mn)
    times_wffn.append(mw)
    times_shared.append(ms)
    top_norm = int(out_norm.argmax())
    top_wffn = int(out_wffn.argmax())
    top_shr = int(out_shr.argmax())
    m_wffn = '✓' if top_wffn == top_norm else '✗'
    m_shared = '✓' if top_shr == top_norm else '✗'
    if top_wffn == top_norm:
        match_wffn += 1
    if top_shr == top_norm:
        match_shared += 1
    total += 1
    print(f'  {prompt[:31]:<32} {mn:>6.1f}ms    {mw:>6.1f}ms    {ms:>6.1f}ms    {m_wffn}/{m_shared}')
mean_n = np.mean(times_normal)
mean_w = np.mean(times_wffn)
mean_s = np.mean(times_shared)
print(f'\n  Mean:                            {mean_n:>6.1f}ms    {mean_w:>6.1f}ms    {mean_s:>6.1f}ms')
print(f'  vs Normal:                          1.00x    {mean_n / mean_w:>5.2f}x    {mean_n / mean_s:>5.2f}x')
print(f'  Top-1 match with normal:           100%     {match_wffn * 100 // total}%          {match_shared * 100 // total}%')
print(f"\n{'=' * 70}")
print(f'  TEST E — GENERATION QUALITY')
print(f'  Normal vs W_ffn (per-layer) vs Shared W_ffn')
print(f"{'=' * 70}")
GEN_PROMPTS = ['Once upon a time there was a little girl', 'The brave knight rode his horse', 'Deep in the forest a family']
for prompt in GEN_PROMPTS:
    print(f'\n  PROMPT: "{prompt}"')
    ids = tok.encode(prompt, return_tensors='pt')
    gen_n = ids.clone()
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=20, do_sample=False, pad_token_id=tok.eos_token_id)
    text_n = tok.decode(out[0], skip_special_tokens=True)
    gen_w = ids.clone()
    for _ in range(20):
        logits = forward_w_per_layer(gen_w)
        nxt = int(logits.argmax())
        gen_w = torch.cat([gen_w, torch.tensor([[nxt]])], dim=1)
        if nxt == tok.eos_token_id:
            break
    text_w = tok.decode(gen_w[0], skip_special_tokens=True)
    gen_s = ids.clone()
    for _ in range(20):
        logits = forward_w_shared(gen_s)
        nxt = int(logits.argmax())
        gen_s = torch.cat([gen_s, torch.tensor([[nxt]])], dim=1)
        if nxt == tok.eos_token_id:
            break
    text_s = tok.decode(gen_s[0], skip_special_tokens=True)
    tok_n = tok.encode(text_n)
    tok_w = tok.encode(text_w)
    tok_s = tok.encode(text_s)
    match_len = min(len(tok_n), len(tok_w), len(tok_s))
    m_w = sum((a == b for a, b in zip(tok_n[:match_len], tok_w[:match_len])))
    m_s = sum((a == b for a, b in zip(tok_n[:match_len], tok_s[:match_len])))
    print(f'  Normal:  {text_n}')
    print(f'  W_ffn:   {text_w}  (match: {m_w * 100 // match_len}%)')
    print(f'  Shared:  {text_s}  (match: {m_s * 100 // match_len}%)')
print(f"\n{'=' * 70}")
print(f'  TEST F — FFN SILENCE (neurons below threshold)')
print(f'  Confirms: can we skip silent neurons?')
print(f"{'=' * 70}\n")
thresholds = [0.001, 0.01, 0.05, 0.1]
print(f"  {'Layer':<8}", end='')
for t in thresholds:
    print(f"  {'t=' + str(t):<12}", end='')
print()
print(f"  {'─' * 60}")
all_silence = {t: [] for t in thresholds}
for l in range(N_LAYERS):
    g = G[l]
    print(f'  {l:<8}', end='')
    for t in thresholds:
        W2 = model.transformer.h[l].mlp.c_proj.weight.detach().numpy()
        col_norms = np.linalg.norm(W2.T, axis=1)
        contrib = np.abs(g) * col_norms[None, :]
        silence = np.mean(contrib < t) * 100
        all_silence[t].append(silence)
        print(f'  {silence:>6.1f}%     ', end='')
    print()
print(f'\n  Mean silence:')
for t in thresholds:
    mean_s = np.mean(all_silence[t])
    io_save = mean_s
    print(f'    t={t}: {mean_s:.1f}% silent → skip {mean_s:.0f}% of W2 IO → {io_save:.0f}% IO saved on FFN')
print(f"\n{'=' * 70}")
print(f'  FINAL SUMMARY — ALL MEASUREMENTS')
print(f"{'=' * 70}")
print(f"\n  MODEL: TinyStories-1M  D={D}  FFN={FFN_D}  Layers={N_LAYERS}\n\n  A. LAW CONFIRMATION:\n     Per-layer W_ffn R²: {min(r2_per_layer):.4f} – {max(r2_per_layer):.4f}\n     Law holds: {('✓ YES at all layers' if min(r2_per_layer) > 0.999 else '~ partial')}\n\n  B. SHARED W_ffn:\n     R² = {r2_shared_te:.4f}\n     {verdict}\n     Compression on W2: {compression_shared:.0f}x  (if shared is accurate enough)\n\n  C. SPEED:\n     Normal:       {mean_n:.1f}ms/token\n     W_ffn:        {mean_w:.1f}ms/token  ({mean_n / mean_w:.2f}x)\n     Shared W_ffn: {mean_s:.1f}ms/token  ({mean_n / mean_s:.2f}x)\n\n  D. GENERATION MATCH:\n     W_ffn (per-layer) vs Normal:  {match_wffn * 100 // total}% top-1 match\n     Shared W_ffn vs Normal:       {match_shared * 100 // total}% top-1 match\n\n  E. SILENCE (FFN IO skip potential):\n     At t=0.01: {np.mean(all_silence[0.01]):.1f}% silent → skip {np.mean(all_silence[0.01]):.0f}% of FFN IO\n\n  PATH TO 7B:\n     Same laws. Same code. Run on Qwen2.5-7B.\n     Key number to confirm: shared W_ffn R² on 28 layers.\n     If R²>0.95 on 7B: compression is real at scale.\n")
print('=' * 70 + '\n')
