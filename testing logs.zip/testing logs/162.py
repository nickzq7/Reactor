import os, json
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
with open(os.path.join(_dir, 'big_model_meta.json')) as f:
    BM = json.load(f)
with open(os.path.join(_dir, 'small_model_meta.json')) as f:
    SM = json.load(f)
VS = BM['VS']
DB, HB, NLB, KB = (BM['D'], BM['H'], BM['NL'], BM['K'])
DS, HS, NLS, KS = (SM['D'], SM['H'], SM['NL'], SM['K'])
WB = {k: v for k, v in np.load(os.path.join(_dir, 'big_model_weights.npz')).items()}
WS_before = {k: v for k, v in np.load(os.path.join(_dir, 'small_model_weights.npz')).items()}
WS_after = {k: v for k, v in np.load(os.path.join(_dir, 'small_model_after_transfer.npz')).items()}

class Model(nn.Module):

    def __init__(self, d, h, nl, k):
        super().__init__()
        self.k = k
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(k, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, h, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(nl)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, ids):
        B, K = ids.shape
        pos = torch.arange(K, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_model(cls_d, cls_h, cls_nl, cls_k, weights):
    m = Model(cls_d, cls_h, cls_nl, cls_k).to(device)
    m.load_state_dict({k: torch.tensor(v) for k, v in weights.items()})
    m.eval()
    return m
big_model = load_model(DB, HB, NLB, KB, WB)
small_before = load_model(DS, HS, NLS, KS, WS_before)
small_after = load_model(DS, HS, NLS, KS, WS_after)

def generate(model, seed_seq, k, steps=30):
    seq = list(seed_seq[-k:])
    with torch.no_grad():
        for _ in range(steps):
            ids = torch.tensor([seq[-k:]], dtype=torch.long).to(device)
            next_tok = int(model(ids)[0, -1].argmax())
            seq.append(next_tok)
    return seq

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, (a + b) % VS)
        s.append(b)
    return s

def gen_trib(n):
    a, b, c = (0, 1, 1)
    s = [0, 1, 1]
    while len(s) < n:
        a, b, c = (b, c, (a + b + c) % VS)
        s.append(c)
    return s[:n]

def gen_primes(n):
    P = []
    c = 2
    while len(P) < n:
        if all((c % p for p in P)):
            P.append(c % VS)
        c += 1
    return P

def gen_pow(base, n):
    v = 1
    s = []
    for _ in range(n):
        s.append(v % VS)
        v = v * base % VS
    return s
fib62 = gen_fib(62)
PATTERNS = [('counting', [i % VS for i in range(80)]), ('evens', [i * 2 % VS for i in range(80)]), ('odds', [(i * 2 + 1) % VS for i in range(80)]), ('threes', [i * 3 % VS for i in range(80)]), ('fives', [i * 5 % VS for i in range(80)]), ('tens', [i * 10 % VS for i in range(80)]), ('step7', [i * 7 % VS for i in range(80)]), ('countdown', [(100 - i) % VS for i in range(80)]), ('squares', [i * i % VS for i in range(80)]), ('powers2', gen_pow(2, 80)), ('powers3', gen_pow(3, 80)), ('fibonacci', gen_fib(80)), ('tribonacci', gen_trib(80)), ('primes', gen_primes(80)), ('alt_fib', [abs(fib62[i + 2] - fib62[i]) % VS for i in range(60)] + [0] * 20)]
SEED_LEN = 6
GEN_STEPS = 20
SHOW = 12
print(f"\n{'=' * 80}")
print(f'  MODEL TEST — LONG SEQUENCE GENERATION')
print(f'  Seed: first {SEED_LEN} tokens  |  Generate: {GEN_STEPS} tokens')
print(f'  BIG=D{DB}/15pat   SMALL_BEFORE=D{DS}/1pat   SMALL_AFTER=D{DS}/V16transfer')
print(f"{'=' * 80}\n")
total_big = 0
total_before = 0
total_after = 0
for name, truth_seq in PATTERNS:
    seed = truth_seq[:SEED_LEN]
    truth = truth_seq[SEED_LEN:SEED_LEN + GEN_STEPS]
    gen_big = generate(big_model, seed, KB, GEN_STEPS)[SEED_LEN:]
    gen_before = generate(small_before, seed, KS, GEN_STEPS)[SEED_LEN:]
    gen_after = generate(small_after, seed, KS, GEN_STEPS)[SEED_LEN:]
    sc_big = sum((a == b for a, b in zip(gen_big, truth)))
    sc_before = sum((a == b for a, b in zip(gen_before, truth)))
    sc_after = sum((a == b for a, b in zip(gen_after, truth)))
    total_big += sc_big
    total_before += sc_before
    total_after += sc_after

    def fmt(seq):
        return '  '.join((f'{x:>4}' for x in seq[:SHOW]))

    def mark(seq):
        return ''.join(('█' if a == b else '░' for a, b in zip(seq[:SHOW], truth[:SHOW])))
    print(f'  ┌─ {name.upper()} ─────────────────────────────────────────────')
    print(f'  │  Seed          : {fmt(seed)}')
    print(f'  │  Truth         : {fmt(truth)}')
    print(f'  │  Big    {sc_big:>2}/{GEN_STEPS} {mark(gen_big)}')
    print(f'  │  Big output    : {fmt(gen_big)}')
    print(f'  │  Before {sc_before:>2}/{GEN_STEPS} {mark(gen_before)}')
    print(f'  │  Before output : {fmt(gen_before)}')
    print(f'  │  After  {sc_after:>2}/{GEN_STEPS} {mark(gen_after)}')
    print(f'  │  After output  : {fmt(gen_after)}')
    print(f"  └{'─' * 70}\n")
total_tokens = len(PATTERNS) * GEN_STEPS
print(f"{'=' * 80}")
print(f'  TOTAL SCORE (correct tokens out of {total_tokens})')
print(f'  Big model    : {total_big}/{total_tokens}  ({100 * total_big // total_tokens}%)')
print(f'  Small BEFORE : {total_before}/{total_tokens}  ({100 * total_before // total_tokens}%)')
print(f'  Small AFTER  : {total_after}/{total_tokens}  ({100 * total_after // total_tokens}%)')
print(f'  Transfer gain: +{total_after - total_before} tokens correct')
print(f"{'=' * 80}")
