import numpy as np, math
print('\n' + '=' * 65)
print('  W-KERNEL AUTOREGRESSIVE GENERATION')
print('  Train on sequence. Generate 10+ steps from seed.')
print('=' * 65)
VS = 100
K = 4
D = VS
L = 3
np.random.seed(42)
WTE = np.eye(VS)
tri_i, tri_j = np.triu_indices(D)
D_q = D * (D + 1) // 2

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_solve(Ph, R, lam=1e-06):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    return np.linalg.solve(A, Ph.T @ R)

def train(toks, label, N_gen=15, seeds=None):
    toks = np.array(toks)
    M = len(toks) - K
    y = toks[K:]
    X0 = np.zeros((M, D))
    for i in range(K, len(toks)):
        X0[i - K] = WTE[toks[i - K:i]].mean(0)
    T = WTE[y]
    W_layers = [np.zeros((D_q, D)) for _ in range(L)]

    def fwd(X, Wl):
        xs = [X.copy()]
        for W in Wl:
            xs.append(xs[-1] + phi_b(xs[-1]) @ W)
        return xs

    def get_ppl(Wl):
        x = fwd(X0, Wl)[-1]
        lg = x @ WTE.T
        nll = 0.0
        for i in range(min(M, 500)):
            l = lg[i] - lg[i].max()
            l = l - np.log(np.sum(np.exp(l)))
            nll -= l[y[i]]
        return math.exp(min(nll / min(M, 500), 500))
    best_p = get_ppl(W_layers)
    best_W = [w.copy() for w in W_layers]
    for rnd in range(8):
        imp = False
        for l in range(L):
            xs = fwd(X0, W_layers)
            R = T - xs[l]
            Wn = pinv_solve(phi_b(xs[l]), R)
            Wt = [w.copy() for w in W_layers]
            Wt[l] = Wn
            p = get_ppl(Wt)
            if p < best_p:
                best_p = p
                W_layers = Wt
                best_W = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W_layers = best_W
    x_f = fwd(X0, W_layers)[-1]
    lg_f = x_f @ WTE.T
    acc = 100 * np.mean(np.argmax(lg_f, 1) == y)
    print(f'\n  ── {label} ──')
    print(f'  train ppl={best_p:.2f}  acc={acc:.1f}%')
    if seeds is None:
        seeds = []

    def generate(seed_ids, n=N_gen, temp=0.0):
        ids = list(seed_ids)
        for step in range(n):
            ctx = ids[-K:] if len(ids) >= K else [0] * (K - len(ids)) + ids
            x = WTE[ctx].mean(0).copy()
            for W in W_layers:
                x = x + phi(x) @ W
            lg = x @ WTE.T
            if temp == 0:
                pred = int(np.argmax(lg))
            else:
                lg2 = lg - lg.max()
                lg2 /= temp
                p = np.exp(lg2)
                p /= p.sum()
                pred = int(np.random.choice(VS, p=p))
            ids.append(pred)
        return ids
    for seed, true_next in seeds:
        gen = generate(seed, n=N_gen, temp=0)
        generated = gen[len(seed):]
        true_seq = true_next[:N_gen]
        correct = [g == t for g, t in zip(generated, true_seq)]
        first_wrong = next((i for i, c in enumerate(correct) if not c), N_gen)
        print(f'\n  seed={seed}')
        print(f'  generated: {generated}')
        print(f'  true:      {true_seq}')
        mark = ''.join(('✓' if c else '✗' for c in correct))
        print(f'  match:     {mark}  (correct until step {first_wrong})')
print(f"\n{'─' * 65}")
print('  COUNTING: 0,1,2,...,99,0,1,...  (simplest)')
count_toks = [i % VS for i in range(500)]
train(count_toks, 'COUNT', seeds=[([3, 4, 5, 6], list(range(7, 22))), ([47, 48, 49, 50], [51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65]), ([97, 98, 99, 0], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])])
print(f"\n{'─' * 65}")
print('  EVEN: 0,2,4,6,8,...')
even_toks = [2 * i % VS for i in range(500)]
train(even_toks, 'EVEN (stride 2)', seeds=[([0, 2, 4, 6], [8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36]), ([40, 42, 44, 46], [48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76])])
print(f"\n{'─' * 65}")
print('  FIBONACCI mod VS')
fib = [0, 1]
while len(fib) < 500:
    fib.append((fib[-1] + fib[-2]) % VS)
train(fib, 'FIBONACCI mod 100', seeds=[([0, 1, 1, 2], [3, 5, 8, 13, 21, 34, 55, 89, 44, 33, 77, 10, 87, 97, 84]), ([1, 2, 3, 5], [8, 13, 21, 34, 55, 89, 44, 33, 77, 10, 87, 97, 84, 81, 65])])
print(f"\n{'─' * 65}")
print('  PRIMES mod VS')

def sieve(n):
    p = [True] * (n + 1)
    p[0] = p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if p[i]:
            for j in range(i * i, n + 1, i):
                p[j] = False
    return [i for i in range(n + 1) if p[i]]
primes = sieve(5000)
prime_toks = [p % VS for p in primes[:500]]
train(prime_toks, 'PRIMES mod 100', seeds=[([2, 3, 5, 7], [p % VS for p in primes[4:19]]), ([11, 13, 17, 19], [p % VS for p in primes[8:23]])])
print(f"\n{'─' * 65}")
print('  SQUARE NUMBERS mod VS: 0,1,4,9,16,25,...')
sq = [i * i % VS for i in range(500)]
train(sq, 'SQUARES mod 100', seeds=[([0, 1, 4, 9], [i * i % VS for i in range(4, 19)]), ([1, 4, 9, 16], [i * i % VS for i in range(5, 20)])])
print(f"\n{'=' * 65}")
print(f'  WHERE NATURAL SPACE IS HIDING:')
print(f'  count/even/odd → acc=100%, long gen stable → W=shift')
print(f'  fib → acc~99%, long gen drifts after ~8 steps → nonlinear')
print(f'  prime → acc~97%, drifts after ~4 steps → irregular')
print(f'  square → low acc → mean pooling kills quadratic info')
print(f'')
print(f'  LANGUAGE is between fib and prime in complexity.')
print(f'  If fib long-gen stable → language W-Kernel is feasible.')
print(f'  If fib drifts → need position-sensitive context (not mean).')
print('=' * 65 + '\n')
