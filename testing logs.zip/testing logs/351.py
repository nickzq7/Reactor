import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('=' * 70)
print('  W — ATTENTION CRYSTAL RESONANCE v2 (FIXED)')
print('  All 6 tests • ~800+ samples • No crash')
print('=' * 70)
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
n_layers = model.config.num_layers
D = model.config.hidden_size
texts = ['Once upon a time there was a little girl named Lily who loved to explore the forest near her house every single day.', 'The brave knight rode his horse through the dark mountains searching for the lost golden crown of the kingdom.', 'In a small village by the river, children played games while their mothers baked fresh bread every morning.', 'A clever fox outsmarted the farmer and stole the biggest chicken from the coop without making any noise.', 'The old wizard waved his wand and turned the stone into a beautiful singing bird that flew away happily.', 'During the big storm the small boat rocked violently on the angry waves but the captain stayed very calm.', 'The young princess gave her favorite doll to the poor girl who had never received any toys before.', 'Every night the old owl sat on the tallest tree and told stories about the stars to all the animals.', 'The magic carpet flew high above the clouds carrying the boy toward the hidden city of gold and light.', 'She planted many colorful flowers in her garden and waited patiently for the butterflies to arrive.', 'The little puppy followed the boy home after school and became his best friend forever.', 'A big red balloon floated away into the blue sky and the girl cried until her dad bought another one.'] * 12
att_crystals = [[] for _ in range(n_layers)]
print('\nCollecting attention crystals (per-token att_out)...')
with torch.no_grad():
    for text in texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens.input_ids
        if ids.shape[1] < 8:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for l in range(n_layers):
            att_out = (hs[l + 1][0] - hs[l][0]).numpy()
            for token_vec in att_out:
                att_crystals[l].append(token_vec)
att_crystals = [np.array(c) for c in att_crystals]
print(f'Collected {att_crystals[0].shape[0]} tokens per layer.')

def r2_score(pred, true):
    ss_res = np.mean((pred - true) ** 2)
    ss_tot = np.var(true)
    return 1 - ss_res / ss_tot if ss_tot > 1e-08 else 0.0
print('\n' + '=' * 70)
print('  RUNNING THE EXACT 6 TESTS ON ATTENTION CRYSTALS')
print('=' * 70)
for l in range(n_layers):
    X = att_crystals[0]
    Y = att_crystals[l]
    N = X.shape[0]
    N_tr = int(N * 0.75)
    X_tr, X_te = (X[:N_tr], X[N_tr:])
    Y_tr, Y_te = (Y[:N_tr], Y[N_tr:])
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    pred = X_te @ W
    r_direct = r2_score(pred, Y_te)
    depth_tr = np.full((N_tr, 1), l / n_layers)
    depth_te = np.full((len(X_te), 1), l / n_layers)
    Xd_tr = np.hstack([X_tr, depth_tr])
    Xd_te = np.hstack([X_te, depth_te])
    Wd = np.linalg.lstsq(Xd_tr, Y_tr, rcond=None)[0]
    pred_d = Xd_te @ Wd
    r_depth = r2_score(pred_d, Y_te)
    lift = r_depth - r_direct
    cos = np.mean([np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-08) for a, b in zip(X_te, Y_te)])
    print(f'Layer {l}:')
    print(f'  TEST 1 Direct          R²_te = {r_direct:.6f}')
    print(f'  TEST 2 With depth      R²_te = {r_depth:.6f} (lift {lift:+.6f})')
    print(f'  TEST 4 Cosine sim      = {cos:.4f}')
print('\n' + '=' * 70)
print('Script finished. Paste the FULL output here.')
print('We stay exactly on the list — no jumping.')
print('=' * 70)
