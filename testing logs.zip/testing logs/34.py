import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
import copy, math
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
print_sep('LOAD ORIGINAL TinyStories-1M')
MODEL = 'roneneldan/TinyStories-1M'
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
try:
    original = AutoModelForCausalLM.from_pretrained(MODEL, dtype=torch.float32, use_safetensors=True)
except:
    original = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.float32)
original = original.to(device)
original.eval()
n_layers = original.config.num_layers
hidden = original.config.hidden_size
print(f'  Params: {sum((p.numel() for p in original.parameters())):,}')
print(f'  Layers: {n_layers}  Hidden: {hidden}')
print_sep('EXTRACT W MATRICES — ALL 8 LAYERS')

def get_layer_weights(model, layer_idx):
    layer = model.transformer.h[layer_idx]
    return {'q': layer.attn.attention.q_proj.weight.detach().float(), 'k': layer.attn.attention.k_proj.weight.detach().float(), 'v': layer.attn.attention.v_proj.weight.detach().float(), 'o': layer.attn.attention.out_proj.weight.detach().float(), 'mlp_in': layer.mlp.c_fc.weight.detach().float(), 'mlp_out': layer.mlp.c_proj.weight.detach().float(), 'ln1_w': layer.ln_1.weight.detach().float(), 'ln1_b': layer.ln_1.bias.detach().float(), 'ln2_w': layer.ln_2.weight.detach().float(), 'ln2_b': layer.ln_2.bias.detach().float(), 'mlp_in_b': layer.mlp.c_fc.bias.detach().float(), 'mlp_out_b': layer.mlp.c_proj.bias.detach().float(), 'o_bias': layer.attn.attention.out_proj.bias.detach().float()}
all_layers = {i: get_layer_weights(original, i) for i in range(n_layers)}
print(f'  Extracted {n_layers} layers')
print(f"  Shapes: q={all_layers[0]['q'].shape} mlp_in={all_layers[0]['mlp_in'].shape}")
print_sep('COLLAPSE 8 LAYERS → 1 MATRIX (SVD)')
print(f'\n  Method:\n  Stack all 8 W matrices vertically: [W₀; W₁; ... W₇]\n  SVD of stacked matrix → finds principal directions\n  Take top-k singular vectors → ONE meta matrix\n  \n  This is the mathematical proof of Finding 62:\n  If 8 layers = 1 op × 8 directions,\n  then SVD of stacked matrices recovers that 1 operation.\n')

def collapse_layers_svd(matrices, out_dim):
    stacked = torch.cat(matrices, dim=0).cpu().numpy()
    U, S, Vt = np.linalg.svd(stacked, full_matrices=False)
    k = min(out_dim, len(S))
    U_k = U[:k, :]
    S_k = S[:k]
    Vt_k = Vt[:k, :]
    n = len(matrices)
    meta = Vt_k.T @ np.diag(S_k / n) @ Vt_k
    return (torch.from_numpy(meta).float(), S_k, U_k)
print(f'  Computing meta-Q (stacking {n_layers} Q matrices)...')
Q_matrices = [all_layers[i]['q'] for i in range(n_layers)]
meta_Q, S_q, _ = collapse_layers_svd(Q_matrices, hidden)
print(f'  meta_Q shape: {meta_Q.shape}  top-5 singular vals: {S_q[:5].round(3)}')
print(f'  Computing meta-K...')
K_matrices = [all_layers[i]['k'] for i in range(n_layers)]
meta_K, S_k_vals, _ = collapse_layers_svd(K_matrices, hidden)
print(f'  Computing meta-V...')
V_matrices = [all_layers[i]['v'] for i in range(n_layers)]
meta_V, S_v, _ = collapse_layers_svd(V_matrices, hidden)
print(f'  Computing meta-O...')
O_matrices = [all_layers[i]['o'] for i in range(n_layers)]
meta_O, S_o, _ = collapse_layers_svd(O_matrices, hidden)
print(f'  Computing meta-MLP_in/out (averaging — rectangular matrices)...')
meta_MLP_in = torch.stack([all_layers[i]['mlp_in'] for i in range(n_layers)]).mean(0)
meta_MLP_out = torch.stack([all_layers[i]['mlp_out'] for i in range(n_layers)]).mean(0)
print(f'  meta_MLP_in:  {meta_MLP_in.shape}  meta_MLP_out: {meta_MLP_out.shape}')

def avg_param(key):
    return torch.stack([all_layers[i][key] for i in range(n_layers)]).mean(0)
meta_ln1_w = avg_param('ln1_w')
meta_ln1_b = avg_param('ln1_b')
meta_ln2_w = avg_param('ln2_w')
meta_ln2_b = avg_param('ln2_b')
meta_mlpin_b = avg_param('mlp_in_b')
meta_mlpout_b = avg_param('mlp_out_b')
meta_o_bias = avg_param('o_bias')
print(f'\n  8 layers collapsed to 1 meta-layer.')
print(f'  meta_Q singular val entropy: {-(S_q / S_q.sum() * np.log(S_q / S_q.sum() + 1e-10)).sum():.4f}')
print_sep('BUILD META MODEL — 1 LAYER')

class MetaAttention(nn.Module):

    def __init__(self, hidden, n_heads, meta_q, meta_k, meta_v, meta_o, o_bias):
        super().__init__()
        self.hidden = hidden
        self.n_heads = n_heads
        self.head_dim = hidden // n_heads
        self.q_proj = nn.Linear(hidden, hidden, bias=False)
        self.k_proj = nn.Linear(hidden, hidden, bias=False)
        self.v_proj = nn.Linear(hidden, hidden, bias=False)
        self.out_proj = nn.Linear(hidden, hidden, bias=True)
        with torch.no_grad():
            self.q_proj.weight.copy_(meta_q)
            self.k_proj.weight.copy_(meta_k)
            self.v_proj.weight.copy_(meta_v)
            self.out_proj.weight.copy_(meta_o)
            self.out_proj.bias.copy_(o_bias)

    def forward(self, x):
        B, T, C = x.shape
        Q = self.q_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        K = self.k_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        V = self.v_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        scale = math.sqrt(self.head_dim)
        att = Q @ K.transpose(-2, -1) / scale
        mask = torch.tril(torch.ones(T, T, device=x.device)).bool()
        att = att.masked_fill(~mask, float('-inf'))
        att = F.softmax(att, dim=-1)
        out = (att @ V).transpose(1, 2).contiguous().view(B, T, C)
        return self.out_proj(out)

class MetaMLP(nn.Module):

    def __init__(self, meta_in, meta_out, in_bias, out_bias):
        super().__init__()
        hidden = meta_in.shape[1]
        mlp_dim = meta_in.shape[0]
        self.fc = nn.Linear(hidden, mlp_dim, bias=True)
        self.proj = nn.Linear(mlp_dim, hidden, bias=True)
        with torch.no_grad():
            self.fc.weight.copy_(meta_in)
            self.fc.bias.copy_(in_bias)
            self.proj.weight.copy_(meta_out)
            self.proj.bias.copy_(out_bias)

    def forward(self, x):
        return self.proj(F.gelu(self.fc(x)))

class MetaBlock(nn.Module):

    def __init__(self, hidden, n_heads, meta_q, meta_k, meta_v, meta_o, o_bias, meta_mlp_in, meta_mlp_out, mlp_in_b, mlp_out_b, ln1_w, ln1_b, ln2_w, ln2_b):
        super().__init__()
        self.ln1 = nn.LayerNorm(hidden)
        self.ln2 = nn.LayerNorm(hidden)
        self.attn = MetaAttention(hidden, n_heads, meta_q, meta_k, meta_v, meta_o, o_bias)
        self.mlp = MetaMLP(meta_mlp_in, meta_mlp_out, mlp_in_b, mlp_out_b)
        with torch.no_grad():
            self.ln1.weight.copy_(ln1_w)
            self.ln1.bias.copy_(ln1_b)
            self.ln2.weight.copy_(ln2_w)
            self.ln2.bias.copy_(ln2_b)

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x

class MetaModel(nn.Module):

    def __init__(self, original_model, meta_q, meta_k, meta_v, meta_o, o_bias, meta_mlp_in, meta_mlp_out, mlp_in_b, mlp_out_b, ln1_w, ln1_b, ln2_w, ln2_b):
        super().__init__()
        cfg = original_model.config
        hidden = cfg.hidden_size
        n_heads = cfg.num_heads
        vocab = cfg.vocab_size
        max_pos = cfg.max_position_embeddings
        self.wte = nn.Embedding(vocab, hidden)
        self.wpe = nn.Embedding(max_pos, hidden)
        with torch.no_grad():
            self.wte.weight.copy_(original_model.transformer.wte.weight)
            self.wpe.weight.copy_(original_model.transformer.wpe.weight)
        self.block = MetaBlock(hidden, n_heads, meta_q, meta_k, meta_v, meta_o, o_bias, meta_mlp_in, meta_mlp_out, mlp_in_b, mlp_out_b, ln1_w, ln1_b, ln2_w, ln2_b)
        self.ln_f = copy.deepcopy(original_model.transformer.ln_f)
        self.lm_head = nn.Linear(hidden, vocab, bias=False)
        with torch.no_grad():
            self.lm_head.weight.copy_(original_model.transformer.wte.weight)

    def forward(self, input_ids):
        B, T = input_ids.shape
        pos = torch.arange(T, device=input_ids.device)
        x = self.wte(input_ids) + self.wpe(pos)
        x = self.block(x)
        x = self.ln_f(x)
        return self.lm_head(x)

    @torch.no_grad()
    def generate(self, input_ids, max_new_tokens=50, temperature=0.7, do_sample=True):
        ids = input_ids.clone()
        for _ in range(max_new_tokens):
            logits = self.forward(ids)[:, -1, :]
            logits = logits / temperature
            if do_sample:
                probs = F.softmax(logits, dim=-1)
                next_t = torch.multinomial(probs, 1)
            else:
                next_t = logits.argmax(-1, keepdim=True)
            ids = torch.cat([ids, next_t], dim=1)
            if next_t.item() == tok.eos_token_id:
                break
        return ids
print(f'  Building meta model...')
meta_model = MetaModel(original, meta_Q.to(device), meta_K.to(device), meta_V.to(device), meta_O.to(device), meta_o_bias.to(device), meta_MLP_in.to(device), meta_MLP_out.to(device), meta_mlpin_b.to(device), meta_mlpout_b.to(device), meta_ln1_w.to(device), meta_ln1_b.to(device), meta_ln2_w.to(device), meta_ln2_b.to(device)).to(device)
meta_model.eval()
meta_params = sum((p.numel() for p in meta_model.parameters()))
orig_params = sum((p.numel() for p in original.parameters()))
print(f'  Original params: {orig_params:,}  (8 layers)')
print(f'  Meta params:     {meta_params:,}  (1 meta layer)')
print(f'  Reduction:       {orig_params / meta_params:.1f}x fewer params')
print_sep('GENERATE 50 TOKENS — ORIGINAL vs META')
PROMPTS = ['Once upon a time, there was a little girl named Lily.', 'One day, a small dog found a big bone in the garden.', 'Tom and his friend went to the forest to play.', 'The old man sat by the river and watched the fish.', 'She looked at the stars and made a wish.']

def generate_original(prompt, max_new=50, temp=0.7):
    inputs = tok(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        out = original.generate(**inputs, max_new_tokens=max_new, temperature=temp, do_sample=True, pad_token_id=tok.eos_token_id)
    return tok.decode(out[0], skip_special_tokens=True)

def generate_meta(prompt, max_new=50, temp=0.7):
    inputs = tok(prompt, return_tensors='pt').to(device)
    out = meta_model.generate(inputs['input_ids'], max_new_tokens=max_new, temperature=temp, do_sample=True)
    return tok.decode(out[0], skip_special_tokens=True)

def perplexity(model_fn, text):
    inputs = tok(text, return_tensors='pt').to(device)
    ids = inputs['input_ids']
    if ids.shape[1] < 2:
        return float('inf')
    with torch.no_grad():
        logits = model_fn(ids)
        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = ids[:, 1:].contiguous()
        loss = F.cross_entropy(shift_logits.view(-1, shift_logits.shape[-1]), shift_labels.view(-1))
    return math.exp(loss.item())

def meta_forward(ids):
    return meta_model(ids)

def orig_forward(ids):
    return original(ids).logits
print(f"\n  {'─' * 65}")
all_orig_ppl = []
all_meta_ppl = []
for i, prompt in enumerate(PROMPTS):
    print(f"\n  PROMPT {i + 1}: '{prompt}'")
    print(f"  {'─' * 65}")
    orig_text = generate_original(prompt, max_new=50)
    meta_text = generate_meta(prompt, max_new=50)
    orig_new = orig_text[len(prompt):]
    meta_new = meta_text[len(prompt):]
    orig_ppl = perplexity(orig_forward, orig_text)
    meta_ppl = perplexity(meta_forward, meta_text)
    all_orig_ppl.append(orig_ppl)
    all_meta_ppl.append(meta_ppl)
    print(f'\n  ORIGINAL (8 layers, {orig_params:,} params):')
    print(f'    {orig_new.strip()}')
    print(f'    perplexity={orig_ppl:.1f}')
    print(f'\n  META     (1 layer,  {meta_params:,} params):')
    print(f'    {meta_new.strip()}')
    print(f'    perplexity={meta_ppl:.1f}')
    orig_toks = set(orig_new.lower().split())
    meta_toks = set(meta_new.lower().split())
    if orig_toks | meta_toks:
        overlap = len(orig_toks & meta_toks) / len(orig_toks | meta_toks)
    else:
        overlap = 0
    print(f'    vocab overlap with original: {overlap:.1%}')
print_sep('RESULTS')
avg_orig_ppl = np.mean(all_orig_ppl)
avg_meta_ppl = np.mean(all_meta_ppl)
print(f'\n  PARAMETER COUNT:\n    Original (8 layers):  {orig_params:,}\n    Meta     (1 layer):   {meta_params:,}\n    Reduction:            {orig_params / meta_params:.1f}x\n\n  PERPLEXITY (lower = better, more confident):\n    Original avg: {avg_orig_ppl:.2f}\n    Meta avg:     {avg_meta_ppl:.2f}\n    Ratio:        {avg_meta_ppl / avg_orig_ppl:.2f}x\n    \n  WHAT THIS SHOWS:\n  \n  Finding 62 (proven/disproven):\n    If meta perplexity ≈ original perplexity:\n      ONE operation covers all 8 layers.\n      8 layers = redundant decomposition.\n      Calculate not compute is real.\n      \n    If meta perplexity >> original:\n      8 layers carry unique information.\n      Cannot collapse. Each layer essential.\n      Finding 62 needs revision.\n      \n  Either way — we learned something real.\n  Data says. We listen.\n  \n  The sv_entropy = 1.0000 constant across layers\n  is the deepest finding regardless:\n  Model applies same SHAPE of operation at every layer.\n  Same spread. Same effective rank. Same geometry.\n  One operation. Eight angles. One mind.\n')
