import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer
import math
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
n_heads = model.config.num_heads
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0
texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden.', 'The old farmer woke up before sunrise and walked out to feed all his animals carefully.', 'Deep in the forest a small family of bears lived together in a cozy warm hidden den.', 'The brave knight rode his white horse across the green fields toward the distant tall castle.', 'Sophie loved books more than anything and she read every single one in the library twice.', 'The village held a great harvest festival every autumn and everyone came to celebrate warmly.', 'Tommy was always afraid of the dark so his father gave him a small bright yellow flashlight.', 'The ocean stretched endlessly blue in all directions and Marco had sailed it many times before.', 'High in the cold mountains there was a small stone school where children learned every single day.', 'She opened her eyes slowly and smiled because today was her long awaited birthday morning.', 'The two old friends had known each other since childhood and shared every secret carefully.', 'A tiny rabbit lived beneath the roots of the ancient oak tree at the edge of the meadow.', 'The kind grandmother lived alone in her cottage and welcomed every lost traveler with warmth.', 'Young Sam found a wet shivering puppy hiding under the old wooden bridge near his house.', 'The little dragon had never spoken to anyone before the brave girl climbed up to meet her.', 'In the deep blue ocean a curious silver fish dreamed every day of seeing the world above.', 'The old grandfather clock had been silent for twenty years before the little girl finally fixed it.', 'A small acorn fell from the great oak and slowly over many years grew into a mighty tree.', 'The young painter stared at the blank white canvas for a long time before making her first stroke.', 'Every evening the old man sat by the fire and told his grandchildren wonderful adventure stories.', 'The princess looked out from her tall tower window at the green meadows stretching far below.', 'A brave young explorer set out on a long journey through the jungle to find the ancient temple.', 'Three children discovered a magical hidden door behind the waterfall near the edge of the forest.', 'The wise old owl sat in the oak tree and watched all the children playing in the sunny field.', 'A small wooden boat drifted slowly down the quiet river past the tall reeds and willow trees.']
print(f'\nCollecting activations for activation space analysis...')
stores = {k: {li: [] for li in range(n_layers)} for k in ['h', 'gelu_out', 'pre_gelu', 'ln2_out', 'ln1_out', 'softmax_out', 'attn_out']}
cur = {k: {li: None for li in range(n_layers)} for k in stores}
hooks = []
for li in range(n_layers):

    def make_h(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur['h'][l] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].register_forward_hook(make_h(li)))

    def make_g(l):

        def h(m, i, o):
            cur['gelu_out'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))

    def make_pg(l):

        def h(m, i, o):
            cur['pre_gelu'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].mlp.c_fc.register_forward_hook(make_pg(li)))

    def make_ln2(l):

        def h(m, i, o):
            cur['ln2_out'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ln2(li)))

    def make_ln1(l):

        def h(m, i, o):
            cur['ln1_out'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].ln_1.register_forward_hook(make_ln1(li)))

    def make_so(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            cur['softmax_out'][l] = inp.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].attn.attention.out_proj.register_forward_hook(make_so(li)))

    def make_ao(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur['attn_out'][l] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_ao(li)))
with torch.no_grad():
    for text in texts:
        for k in cur:
            for li in range(n_layers):
                cur[k][li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        L = toks['input_ids'].shape[1]
        model(**toks)
        for li in range(n_layers):
            for k in stores:
                if cur[k][li] is not None:
                    arr = cur[k][li]
                    for t in range(min(L, arr.shape[0])):
                        stores[k][li].append(arr[t].copy())
for h in hooks:
    h.remove()
S = {k: {li: np.array(stores[k][li], dtype=np.float32) for li in range(n_layers)} for k in stores}
N = len(S['h'][0])
print(f'  Tokens collected: {N}')
print(f"\n{'=' * 70}")
print(f'  APPROACH A — ACTIVATION PCA')
print(f'  What is the TRUE dimensionality of each activation?')
print(f'  If activations live in k-dim subspace of FFN_D-dim space:')
print(f'    Only k values needed. FFN_D-k = wasted.')
print(f"{'=' * 70}\n")

def activation_rank(A, threshold=0.99):
    A_c = A - A.mean(0, keepdims=True)
    U, S, Vt = np.linalg.svd(A_c, full_matrices=False)
    S2 = S ** 2
    cumvar = np.cumsum(S2) / S2.sum()
    k = int(np.searchsorted(cumvar, threshold)) + 1
    return (k, len(S), cumvar, S)
print(f'  Activation dimensionality (99% variance threshold):')
print(f"  {'Space':<20} {'Total_dim':<12} {'Eff_dim@99%':<14} {'Compression':<14} {'Top10_var%'}")
print(f"  {'─' * 70}")
act_dims = {}
for k_name, dim_total in [('gelu_out', FFN_D), ('ln2_out', D), ('ln1_out', D), ('softmax_out', D), ('h', D)]:
    A_all = np.concatenate([S[k_name][li] for li in range(n_layers)], axis=0)
    eff_k, total_k, cumvar, sv = activation_rank(A_all, 0.99)
    top10_var = cumvar[int(total_k * 0.1) - 1] if total_k >= 10 else cumvar[-1]
    compression = total_k / eff_k
    act_dims[k_name] = eff_k
    print(f'  {k_name:<20} {total_k:<12} {eff_k:<14} {compression:.1f}x           {top10_var:.3f}')
print(f'\n  Residual stream h — per layer:')
print(f"  {'Layer':<8} {'Eff_dim@99%':<14} {'Eff_dim@95%':<14} {'Eff_dim@90%'}")
print(f"  {'─' * 45}")
for li in range(n_layers):
    A = S['h'][li]
    k99, t, _, _ = activation_rank(A, 0.99)
    k95, _, _, _ = activation_rank(A, 0.95)
    k90, _, _, _ = activation_rank(A, 0.9)
    print(f'  {li:<8} {k99:<14} {k95:<14} {k90}')
print(f'\n  gelu_out — per layer (FFN_D={FFN_D}):')
print(f"  {'Layer':<8} {'Eff_dim@99%':<14} {'Compression':<14} {'Top5_var%'}")
print(f"  {'─' * 45}")
for li in range(n_layers):
    A = S['gelu_out'][li]
    k, t, cumvar, sv = activation_rank(A, 0.99)
    top5 = cumvar[int(t * 0.05) - 1] if t >= 20 else cumvar[-1]
    print(f'  {li:<8} {k:<14} {t / k:.1f}x           {top5:.3f}')
print(f"\n{'=' * 70}")
print(f'  APPROACH B — PROJECT ACTIVATIONS, VERIFY R²')
print(f'  Project gelu_out to k-dim PCA basis.')
print(f'  Verify: projected_gelu → ffn_out still = R²=1.000?')
print(f'  This = true W law compression.')
print(f"{'=' * 70}\n")

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    n = len(X)
    s = int(n * split)
    if s < 10:
        return (float('nan'), float('nan'))
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    pred = Xb[s:] @ W
    ss_res = np.sum((pred - Y[s:]) ** 2)
    ss_tot = np.sum((Y[s:] - Y[s:].mean(0, keepdims=True)) ** 2)
    return (float(1 - np.mean((Xb[:s] @ W - Y[:s]) ** 2) / np.mean((Y[:s] - Y[:s].mean(0)) ** 2)), float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0)
print(f'  Layer 0: gelu_out projected → ffn_out (W2 @ gelu)')
layer0 = model.transformer.h[0]
W2 = layer0.mlp.c_proj.weight.detach().float().numpy()
b2 = layer0.mlp.c_proj.bias.detach().float().numpy()
G = S['gelu_out'][0].astype(np.float64)
ffn_true = G @ W2.T + b2
G_c = G - G.mean(0)
U_g, Sv_g, Vt_g = np.linalg.svd(G_c, full_matrices=False)
k_values = [FFN_D, int(FFN_D * 0.75), int(FFN_D * 0.5), int(FFN_D * 0.25), int(FFN_D * 0.1), int(FFN_D * 0.05), 16, 8, 4]
print(f"\n  {'k_dim':<10} {'var_captured':<16} {'R²_te':<12} {'max_err':<14} {'Status'}")
print(f"  {'─' * 60}")
for k in sorted(set(k_values), reverse=True):
    if k < 1:
        continue
    basis_k = Vt_g[:k, :]
    G_proj = G @ basis_k.T
    G_recon = G_proj @ basis_k + G.mean(0)
    ffn_pred = G_recon @ W2.T + b2
    _, r2_te = fit_r2(G_proj, ffn_true)
    me = float(np.max(np.abs(ffn_pred - ffn_true)))
    sv2 = Sv_g ** 2
    var_cap = sv2[:k].sum() / sv2.sum()
    status = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {k:<10} {var_cap:.4f}          {r2_te:<12.6f} {me:<14.6f} {status}')
print(f"\n{'=' * 70}")
print(f'  APPROACH C — MINIMUM ACTIVATION DIM PER OPERATION')
print(f'  Find minimum k such that k-dim projection → target = R²=0.999')
print(f'  This = true information content of each activation.')
print(f"{'=' * 70}\n")
print(f"  {'Operation':<35} {'Full_dim':<10} {'Min_k@0.999':<14} {'Min_k@0.99':<13} {'Ratio'}")
print(f"  {'─' * 75}")

def find_min_k(X, Y, threshold=0.999):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    X_c = X - X.mean(0)
    U, S_, Vt = np.linalg.svd(X_c, full_matrices=False)
    total_dim = X.shape[1]
    for k in range(1, total_dim + 1):
        basis = Vt[:k, :]
        X_proj = X @ basis.T
        _, r2_te = fit_r2(X_proj, Y)
        if r2_te >= threshold:
            return (k, total_dim)
    return (total_dim, total_dim)
ops = [('gelu_out_0 → ffn_out_0', 'gelu_out', 0, 'h', 0, False), ('ln2_out_0 → pre_gelu_0', 'ln2_out', 0, 'pre_gelu', 0, False), ('ln1_out_0 → attn_out_0', 'ln1_out', 0, 'attn_out', 0, False), ('softmax_out_0 → attn_out_0', 'softmax_out', 0, 'attn_out', 0, False), ('h_0 → h_1', 'h', 0, 'h', 1, False), ('h_3 → h_4', 'h', 3, 'h', 4, False), ('h_7 output', 'h', 7, 'h', 7, True)]
for op_name, x_key, x_li, y_key, y_li, self_ref in ops:
    X = S[x_key][x_li].astype(np.float64)
    Y = S[y_key][y_li].astype(np.float64)
    if self_ref:
        Y = S['gelu_out'][y_li].astype(np.float64)
    k999, d = find_min_k(X, Y, 0.999)
    k990, _ = find_min_k(X, Y, 0.99)
    ratio = d / k999
    print(f'  {op_name:<35} {d:<10} {k999:<14} {k990:<13} {ratio:.1f}x')
print(f"\n{'=' * 70}")
print(f'  KEY INSIGHT — What W law compression actually means')
print(f"{'=' * 70}")
print(f'\n  v1 MISTAKE: Compress WEIGHT matrices via SVD.\n    W = U @ S @ V^T → keep top-k singular values.\n    BREAKS model. PPL explodes.\n    Reason: small per-matrix error × residual accumulation.\n\n  CORRECT READING of W law:\n    R²=1.000 means: activation X → Y is EXACT.\n    X lives in a subspace. Y reads that subspace exactly.\n    \n    The SUBSPACE of X = minimum information.\n    NOT the subspace of W.\n    \n    APPROACH A shows: effective dimensionality of activations.\n    gelu_out lives in k-dim subspace of FFN_D-dim space.\n    If k << FFN_D: can represent gelu_out with k numbers.\n    W2 still full-size. But input = k-dim. Computation = k-dim.\n    \n  APPROACH B verifies: projected gelu → ffn_out = R²=?\n    If R²=1.000 at small k: activation compression = lossless.\n    This is the correct compression. Not weight compression.\n\n  APPROACH C: minimum k per operation.\n    This = true information content.\n    Below this k: information loss.\n    At or above: lossless.\n    \n  FOR LAPTOP:\n    If gelu_out min_k = 32 (out of 256):\n      Store only 32 numbers per token per layer.\n      8x compression of FFN activations.\n      Operations still exact (W2 unchanged).\n      This = KV-cache compression + activation cache.\n      \n    If h min_k = 16 (out of 64):\n      Residual stream = 16-dim instead of 64-dim.\n      All operations projected to 16-dim.\n      4x memory reduction everywhere.\n      If R²=1.000 in projected space: zero quality loss.\n')
print('=' * 70 + '\n')
