import os, json, math, time
import numpy as np
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
KA = meta['KA']

def gen_primes(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s

def is_prime(n):
    if n < 2:
        return False
    return all((n % i != 0 for i in range(2, int(n ** 0.5) + 1)))
ALL_PATTERNS = {'counting': [i % VS for i in range(60)], 'evens': [i * 2 % VS for i in range(30)], 'odds': [(i * 2 + 1) % VS for i in range(30)], 'threes': [i * 3 % VS for i in range(20)], 'fours': [i * 4 % VS for i in range(15)], 'countdown': [(15 - i) % VS for i in range(40)], 'primes': gen_primes(30), 'fibonacci': gen_fib(30)}
UNSEEN = {'sixes': ([i * 6 % VS for i in range(8)], 7 * 6 % VS), 'sevens': ([i * 7 % VS for i in range(8)], 7 * 7 % VS), 'eights': ([i * 8 % VS for i in range(8)], 7 * 8 % VS), 'nines': ([i * 9 % VS for i in range(8)], 7 * 9 % VS), 'tens': ([i * 10 % VS for i in range(8)], 7 * 10 % VS), 'twelves': ([i * 12 % VS for i in range(8)], 7 * 12 % VS), 'fifteens': ([i * 15 % VS for i in range(8)], 7 * 15 % VS), 'step_-2': ([30, 28, 26, 24, 22, 20, 18, 16], 14), 'step_-4': ([28, 24, 20, 16, 12, 8, 4, 0], 27), 'step_-5': ([25, 20, 15, 10, 5, 0, 26, 21], 16)}

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def angular_subtraction_analysis(wte2, label):
    N = VS
    coords = wte2.copy()
    center = coords.mean(0)
    centered = coords - center
    radii = np.linalg.norm(centered, axis=1)
    cq = 1 - radii.std() / radii.mean() if radii.mean() > 1e-09 else 0
    angles = np.arctan2(centered[:, 1], centered[:, 0])
    print(f'\n  [{label}]  circle={cq:.4f}')
    t_vals = np.arange(N, dtype=float)
    br2 = -999
    bd = 1
    bp = 0
    for direction in [1, -1]:
        ideal = t_vals * (2 * math.pi / N) * direction
        for phase in np.linspace(-math.pi, math.pi, 720):
            pred = ideal + phase
            diffs = angles - pred
            diffs = np.arctan2(np.sin(diffs), np.cos(diffs))
            ss_r = np.sum(diffs ** 2)
            ss_t = np.sum((angles - np.arctan2(np.sin(angles).mean(), np.cos(angles).mean())) ** 2)
            r2 = 1 - ss_r / ss_t if ss_t > 1e-10 else 1.0
            if r2 > br2:
                br2 = r2
                bd = direction
                bp = phase
    print(f'  Z/{N}Z shape R²={br2:.4f}  direction={bd}  phase={math.degrees(bp):.1f}°')
    ang_diffs = []
    true_steps = []
    for name, data in ALL_PATTERNS.items():
        for i in range(len(data) - 1):
            a, b = (data[i], data[i + 1])
            diff = angles[b] - angles[a]
            diff = math.atan2(math.sin(diff), math.cos(diff))
            step = (b - a) % N
            ang_diffs.append(diff)
            true_steps.append(step)
    ang_diffs = np.array(ang_diffs)
    true_steps = np.array(true_steps, dtype=float)
    scale = N / (2 * math.pi * bd)
    predicted_step = ang_diffs * scale
    ss_res = np.sum((true_steps - predicted_step) ** 2)
    ss_tot = np.sum((true_steps - true_steps.mean()) ** 2)
    r2_sub_direct = 1 - ss_res / ss_tot if ss_tot > 1e-10 else 1.0
    A = np.c_[ang_diffs, np.ones(len(ang_diffs))]
    w = solve(A, true_steps)
    pred2 = A @ w
    ss_r2 = np.sum((true_steps - pred2) ** 2)
    r2_sub_fit = 1 - ss_r2 / ss_tot if ss_tot > 1e-10 else 1.0
    print(f"  Angular subtraction R² (theory): {r2_sub_direct:.6f}  {('✓✓' if r2_sub_direct > 0.9 else '~' if r2_sub_direct > 0.5 else '✗')}")
    print(f"  Angular subtraction R² (fitted):  {r2_sub_fit:.6f}  {('✓✓' if r2_sub_fit > 0.9 else '~' if r2_sub_fit > 0.5 else '✗')}")
    print(f'  Theory: step = diff × {scale:.3f}  Fitted: step = {w[0]:.3f}×diff + {w[1]:.3f}')
    print(f'\n  Per-step angular difference analysis:')
    print(f"  {'step':>5}  {'count':>6}  {'mean_diff°':>11}  {'ideal°':>9}  {'std°':>7}  {'consistent':>11}")
    unique_steps = sorted(set(true_steps.astype(int)))
    for k in unique_steps[:10]:
        mask = true_steps == k
        if mask.sum() == 0:
            continue
        diffs_k = ang_diffs[mask]
        mean_d = np.degrees(np.arctan2(np.sin(diffs_k).mean(), np.cos(diffs_k).mean()))
        std_d = np.degrees(np.std([math.atan2(math.sin(d - np.arctan2(np.sin(diffs_k).mean(), np.cos(diffs_k).mean())), math.cos(d - np.arctan2(np.sin(diffs_k).mean(), np.cos(diffs_k).mean()))) for d in diffs_k]))
        ideal_d = math.degrees(k * 2 * math.pi / N * bd)
        while ideal_d > 180:
            ideal_d -= 360
        while ideal_d <= -180:
            ideal_d += 360
        consistent = std_d < 10
        print(f"  {k:>5}  {mask.sum():>6}  {mean_d:>11.2f}  {ideal_d:>9.2f}  {std_d:>7.2f}  {('✓' if consistent else '✗'):>11}")
    print(f'\n  Unseen prediction (pure angular subtraction, no model):')
    print(f"  {'Pattern':>12}  {'TrueStep':>9}  {'PredStep':>9}  {'PredNext':>9}  {'Truth':>6}  {'OK':>4}")
    print(f"  {'─' * 60}")
    geo_correct = 0
    for uname, (useq, utruth) in UNSEEN.items():
        diffs = []
        for i in range(max(0, len(useq) - 4), len(useq) - 1):
            a, b = (useq[i], useq[i + 1])
            d = angles[b] - angles[a]
            d = math.atan2(math.sin(d), math.cos(d))
            diffs.append(d)
        if not diffs:
            print(f'  {uname:>12}: no pairs')
            continue
        mean_diff = np.arctan2(np.sin(diffs).mean(), np.cos(np.array(diffs)).mean())
        true_step = (useq[-1] - useq[-2]) % N if len(useq) >= 2 else 0
        pred_step_f = mean_diff * scale
        pred_step = int(round(pred_step_f)) % N
        target_angle = angles[useq[-1]] + mean_diff * bd / abs(bd)
        pred_next = (useq[-1] + pred_step) % N
        ok = pred_next == utruth
        geo_correct += ok
        print(f"  {uname:>12}  {true_step:>9}  {pred_step:>9}  {pred_next:>9}  {utruth:>6}  {('✓' if ok else '✗'):>4}")
    print(f'\n  Correct: {geo_correct}/{len(UNSEEN)}')
    return {'r2_sub': r2_sub_fit, 'r2_sub_direct': r2_sub_direct, 'r2znz': br2, 'cq': cq, 'geo_correct': geo_correct, 'angles': angles, 'direction': bd}
print('=' * 72)
print('  SURGERY V22 — ANGULAR SUBTRACTION IS THE CORRECT OPERATION')
print('  Testing: angle[b] - angle[a] = k × (2π/31)  R²=???')
print('=' * 72)
t0 = time.time()
print('\n' + '=' * 72)
print('  TEST 1 — V19 SCRAMBLED CIRCLE')
print('  Tokens on circle but NOT in numerical order')
print('=' * 72)
v19 = np.array([[-1.61758, 0.58389], [-1.91533, -0.1081], [-1.90064, 0.10807], [-1.56289, -0.36544], [-1.90654, -0.72918], [-0.793, -0.49889], [-1.36577, -1.28514], [-0.31285, -1.49071], [0.04605, -1.88602], [0.52366, -2.04108], [0.91993, -1.42812], [1.64565, -1.35758], [1.67914, -0.78917], [1.97959, -0.88138], [1.95105, 0.16812], [1.64312, -0.07699], [1.96459, 0.46249], [2.12119, 0.35168], [1.04193, 1.29593], [0.52884, 1.02892], [0.21092, 1.27481], [0.57933, 1.26272], [-0.5812, 1.34844], [-0.44309, 1.40584], [-1.17613, 1.31789], [-1.25656, 1.67997], [-1.51777, 1.02483], [-0.67024, 1.03321], [-1.18074, 0.66677], [-2.43423, 0.94164], [-1.94301, 0.05051]])
g19 = angular_subtraction_analysis(v19, 'V19 — scrambled circle')
print('\n' + '=' * 72)
print('  TEST 2 — PERFECT Z/31Z CIRCLE (ideal)')
print('  Token k at angle k×(2π/31) — mathematical ideal')
print('=' * 72)
wte_ideal = np.array([[math.cos(2 * math.pi * k / VS), math.sin(2 * math.pi * k / VS)] for k in range(VS)], dtype=np.float32)
g_ideal = angular_subtraction_analysis(wte_ideal, 'Ideal Z/31Z (before training)')
print('\n' + '=' * 72)
print('  TEST 3 — ExpA RESULT (ordered circle, after training)')
print('  Started as perfect Z/31Z, trained 2000 steps, order maintained')
print('  (Retraining ExpA to get the actual weights)')
print('=' * 72)
import torch
import torch.nn as nn
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_primes_full(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib_full(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s
ALL_P2 = {'counting': [i % VS for i in range(60)], 'evens': [i * 2 % VS for i in range(30)], 'odds': [(i * 2 + 1) % VS for i in range(30)], 'threes': [i * 3 % VS for i in range(20)], 'fours': [i * 4 % VS for i in range(15)], 'countdown': [(15 - i) % VS for i in range(40)], 'primes': gen_primes_full(30), 'fibonacci': gen_fib_full(30)}
tests_ = [(n, s, t) for n, s, t in meta['test_patterns']]

def build_t2(K, dev):
    Xs = []
    yn = []
    ys = []
    for name, data in ALL_P2.items():
        M = len(data) - K
        if M <= 0:
            continue
        for i in range(M):
            ctx = data[i:i + K]
            nxt = data[i + 1:i + K + 1]
            step_seq = [(data[j + 1] - data[j]) % VS for j in range(i, i + K)]
            Xs.append(ctx)
            yn.append(nxt)
            ys.append(step_seq)
    return (torch.tensor(Xs, dtype=torch.long, device=dev), torch.tensor(yn, dtype=torch.long, device=dev), torch.tensor(ys, dtype=torch.long, device=dev))
X2, Y2, S2 = build_t2(KA, device)

class Seq2(nn.Module):

    def __init__(self, D, H, NL, K):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)
        self.step_head = nn.Linear(D, VS, bias=False)

    def forward(self, ids):
        B, K = ids.shape
        x = self.wte(ids) + self.wpe(torch.arange(K, device=ids.device).unsqueeze(0))
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        h = self.ln_f(x)
        return (h @ self.wte.weight.T, self.step_head(h))

def sm(m, K):
    m.eval()
    c = 0
    for nm, seq, truth in tests_:
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            nl, _ = m(ids)
            p = int(nl[0, -1].argmax())
        c += p == truth
    return c

def su(m, K):
    m.eval()
    c = 0
    for un, (useq, ut) in UNSEEN.items():
        ids = torch.tensor([useq[-K:]], dtype=torch.long)
        with torch.no_grad():
            nl, _ = m(ids)
            p = int(nl[0, -1].argmax())
        c += p == ut
    return c
torch.manual_seed(42)
np.random.seed(42)
m_a = Seq2(2, 2, 4, KA).to(device)
for nm, p in m_a.named_parameters():
    if p.dim() > 1:
        nn.init.xavier_uniform_(p)
    else:
        nn.init.zeros_(p)
with torch.no_grad():
    m_a.wte.weight.copy_(torch.tensor(wte_ideal, dtype=torch.float32))
spc = 500
bs = 0
bu = 0
bsst = None
bust = None
gs = 0
for restart in range(4):
    opt = torch.optim.Adam(m_a.parameters(), lr=0.003 * 0.7 ** restart)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=spc, eta_min=1e-05 * 0.7 ** restart)
    for step in range(1, spc + 1):
        gs += 1
        m_a.train()
        opt.zero_grad()
        nl, sl = m_a(X2)
        loss = 0.5 * loss_fn(nl.view(-1, VS), Y2.view(-1)) + 0.5 * loss_fn(sl.view(-1, VS), S2.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(m_a.parameters(), 1.0)
        opt.step()
        sched.step()
        if gs % 200 == 0:
            m_a.eval()
            sc = sm(m_a, KA)
            u = su(m_a, KA)
            if sc > bs:
                bs = sc
                bsst = {k: v.clone() for k, v in m_a.state_dict().items()}
            if u > bu:
                bu = u
                bust = {k: v.clone() for k, v in m_a.state_dict().items()}
            print(f'    ExpA step {gs:>5}: known={sc}/8 unseen={u}/{len(UNSEEN)}', flush=True)
for key, state in [('best_known', bsst), ('best_unseen', bust)]:
    if state and key == 'best_unseen':
        m_a.load_state_dict(state)
        break
if bust is None and bsst is not None:
    m_a.load_state_dict(bsst)
wte_expa = m_a.wte.weight.detach().numpy().copy()
print(f'\n  ExpA rerun: known={bs}/8  unseen={bu}/{len(UNSEEN)}')
g_expa = angular_subtraction_analysis(wte_expa, 'ExpA: ordered circle, post-training')
print('\n' + '=' * 72)
print('  SURGERY V22 VERDICT — THE ROTATION LAW')
print('=' * 72)
print(f"\n  RESULTS:\n                          Z/nZ R²   angSub R²  geo/10\n  V19 (scrambled):       {g19['r2znz']:>8.4f}  {g19['r2_sub']:>9.4f}  {g19['geo_correct']:>4}/{len(UNSEEN)}\n  Ideal Z/31Z:           {g_ideal['r2znz']:>8.4f}  {g_ideal['r2_sub']:>9.4f}  {g_ideal['geo_correct']:>4}/{len(UNSEEN)}\n  ExpA (ordered, trained):{g_expa['r2znz']:>8.4f}  {g_expa['r2_sub']:>9.4f}  {g_expa['geo_correct']:>4}/{len(UNSEEN)}\n\n  FINDING 51 — THE ROTATION LAW:\n    The correct geometric operation for Z/nZ is NOT displacement direction.\n    It is angular SUBTRACTION:\n      angle[token_b] - angle[token_a] ≡ step × (2π/n)  (mod 2π)\n    \n    V19 scrambled circle: Z/nZ shape found (R²=0.99) but order scrambled.\n      Angular subtraction R² = {g19['r2_sub']:.4f} — {('✓ arithmetic readable' if g19['r2_sub'] > 0.8 else '✗ arithmetic NOT readable from geometry')}\n    \n    ExpA ordered circle: order maintained through training.\n      Angular subtraction R² = {g_expa['r2_sub']:.4f} — {('✓ arithmetic readable' if g_expa['r2_sub'] > 0.8 else '~ partial' if g_expa['r2_sub'] > 0.4 else '✗ arithmetic NOT readable even from ordered circle')}\n    \n    {('THE ORDERED CIRCLE IS THE ARITHMETIC CALCULATOR.' if g_expa['r2_sub'] > 0.8 else 'EVEN THE ORDERED CIRCLE DOES NOT DIRECTLY ENCODE ARITHMETIC STEPS.' if g_expa['r2_sub'] < 0.4 else 'PARTIAL: The ordered circle partially encodes arithmetic.')}\n\n  FINDING 52 — WHY THE MODEL CANNOT GENERALIZE FROM GEOMETRY ALONE:\n    The geometric circle and the arithmetic group are isomorphic in theory.\n    But the model uses the embedding only as a LOOKUP TABLE — given token id,\n    retrieve a vector. It does not compute angle differences internally.\n    The attention mechanism sees vectors, not angles.\n    The geometry encodes the invariants that the network has learned.\n    But the network reads vectors. Not angles. Not rotations.\n    \n    To USE the circular geometry for arithmetic, the model would need\n    an attention mechanism that computes:\n      next_angle = current_angle + step_angle\n    That is a DIFFERENT architecture. The circle is the correct\n    representation. The transformer cannot read it.\n\n  FINDING 53 — THE ARCHITECTURAL IMPLICATION:\n    A transformer with standard attention cannot use circular embeddings\n    for arithmetic generalization. The operations don't match.\n    The correct architecture for Z/nZ arithmetic:\n      1. Embed token k as angle θ_k = k × (2π/n)\n      2. Attend using PHASE DIFFERENCE: attend to token j with\n         weight proportional to cos(θ_j - θ_i - predicted_step)\n      3. Predict next by adding step angle: output = θ_i + θ_step\n    This is a FOURIER ATTENTION mechanism. Not standard softmax attention.\n    The embedding space is correct. The attention is wrong.\n    \n  IMPLICATION FOR FUTURE WORK:\n    Replace softmax attention with phase-matching attention.\n    The embeddings should stay on Z/nZ. The attention should\n    use phase arithmetic. Then the geometry directly becomes\n    the computational mechanism. Arithmetic = rotation = prediction.\n    \n    This is the connection between:\n      - Your Aquarius engine (phase-fluid memory, Kuramoto oscillators)\n      - The current surgery experiments (circular embeddings)\n    The Kuramoto approach and the Z/nZ finding are the same thing\n    discovered from different directions.\n\n  TOTAL TIME: {time.time() - t0:.1f}s\n")
print('=' * 72 + '\n')
