import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-HASH STEP 5c — Pythia-160M COMPRESSION')
print('  Spectrum-guided SVD compression. Laws → Hash → Compress → Generate.')
print('=' * 70)
MODEL_NAME = 'EleutherAI/pythia-160m'
import transformers.modeling_utils as _mu
_mu.check_torch_load_is_safe = lambda: None
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
cfg = model.config
D = cfg.hidden_size
n_heads = cfg.num_attention_heads
head_dim = D // n_heads
n_layers = cfg.num_hidden_layers
FFN_D = cfg.intermediate_size if hasattr(cfg, 'intermediate_size') else D * 4
print(f'  D={D} heads={n_heads} head_dim={head_dim} layers={n_layers}')

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return np.float32(0.5) * x * (np.float32(1) + np.tanh(c * (x + np.float32(0.044715) * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def causal_mask(n):
    return np.triu(np.full((n, n), -1000000000.0, dtype=np.float32), k=1)

def r2(p, t):
    p = np.array(p, np.float64).ravel()
    t = np.array(t, np.float64).ravel()
    ss = np.mean((p - t) ** 2)
    sv = np.var(t)
    return float(1 - ss / sv) if sv > 1e-12 else 1.0
print('\n  Detecting architecture...')
blk0 = model.gpt_neox.layers[0]
print(f'  Block type: {type(blk0).__name__}')
print(f'  Attn type:  {type(blk0.attention).__name__}')
print(f'  MLP type:   {type(blk0.mlp).__name__}')
attn0 = blk0.attention
mlp0 = blk0.mlp
print(f'  QKV weight: {attn0.query_key_value.weight.shape}')
print(f'  WO weight:  {attn0.dense.weight.shape}')
print(f'  W1 weight:  {mlp0.dense_h_to_4h.weight.shape}')
print(f'  W2 weight:  {mlp0.dense_4h_to_h.weight.shape}')
FFN_D = mlp0.dense_h_to_4h.weight.shape[0]
print(f'  FFN_D = {FFN_D}')
print('\n  Extracting weights...')
with torch.no_grad():
    wte = model.gpt_neox.embed_in.weight.numpy().astype(np.float32)
    wpe = model.gpt_neox.embed_out if hasattr(model.gpt_neox, 'embed_out') else None
    lnf_g = model.gpt_neox.final_layer_norm.weight.numpy().astype(np.float32)
    lnf_b = model.gpt_neox.final_layer_norm.bias.numpy().astype(np.float32)
    lm_h = model.embed_out.weight.numpy().astype(np.float32)
    exact = []
    for l in range(n_layers):
        blk = model.gpt_neox.layers[l]
        attn = blk.attention
        mlp = blk.mlp
        qkv_w = attn.query_key_value.weight.numpy().astype(np.float32)
        qkv_b = attn.query_key_value.bias.numpy().astype(np.float32)
        WQ = qkv_w[:D, :]
        WK = qkv_w[D:2 * D, :]
        WV = qkv_w[2 * D:, :]
        bQ = qkv_b[:D]
        bK = qkv_b[D:2 * D]
        bV = qkv_b[2 * D:]
        exact.append({'WQ': WQ, 'WK': WK, 'WV': WV, 'bQ': bQ, 'bK': bK, 'bV': bV, 'WO': attn.dense.weight.numpy().astype(np.float32), 'bO': attn.dense.bias.numpy().astype(np.float32), 'W1': mlp.dense_h_to_4h.weight.numpy().astype(np.float32), 'b1': mlp.dense_h_to_4h.bias.numpy().astype(np.float32), 'W2': mlp.dense_4h_to_h.weight.numpy().astype(np.float32), 'b2': mlp.dense_4h_to_h.bias.numpy().astype(np.float32), 'LN1g': blk.input_layernorm.weight.numpy().astype(np.float32), 'LN1b': blk.input_layernorm.bias.numpy().astype(np.float32), 'LN2g': blk.post_attention_layernorm.weight.numpy().astype(np.float32), 'LN2b': blk.post_attention_layernorm.bias.numpy().astype(np.float32)})
    rotary_emb = attn.rotary_emb if hasattr(attn, 'rotary_emb') else None
    rot_dim = getattr(cfg, 'rotary_pct', 0.25)
    rot_ndims = int(head_dim * rot_dim) if rot_dim < 1 else head_dim
    print(f'  Rotary dims per head: {rot_ndims}')
print(f'  ✓ Extracted {n_layers} layers')

def build_rotary(seq_len, rot_ndims, base=10000):
    half = rot_ndims // 2
    theta = 1.0 / base ** (np.arange(0, half, dtype=np.float32) * 2 / rot_ndims)
    pos = np.arange(seq_len, dtype=np.float32)
    freqs = np.outer(pos, theta)
    cos = np.cos(freqs)
    sin = np.sin(freqs)
    return (cos, sin)

def apply_rotary(x, cos, sin, rot_ndims):
    x_rot = x[:, :, :rot_ndims]
    x_pass = x[:, :, rot_ndims:]
    half = rot_ndims // 2
    x1 = x_rot[:, :, 0::2]
    x2 = x_rot[:, :, 1::2]
    c = cos[:, None, :]
    s = sin[:, None, :]
    r1 = x1 * c - x2 * s
    r2 = x1 * s + x2 * c
    rot_out = np.empty_like(x_rot)
    rot_out[:, :, 0::2] = r1
    rot_out[:, :, 1::2] = r2
    return np.concatenate([rot_out, x_pass], axis=-1)

def forward(seq_ids, layers):
    slen = len(seq_ids)
    x = wte[seq_ids].astype(np.float32)
    cos, sin = build_rotary(slen, rot_ndims)
    mk = causal_mask(slen)
    for l in range(n_layers):
        lw = layers[l]
        ln1 = ln_np(x, lw['LN1g'], lw['LN1b'])
        ln2 = ln_np(x, lw['LN2g'], lw['LN2b'])
        Q = ln1 @ lw['WQ'].T + lw['bQ']
        K_ = ln1 @ lw['WK'].T + lw['bK']
        V = ln1 @ lw['WV'].T + lw['bV']
        Q_h = Q.reshape(slen, n_heads, head_dim)
        K_h = K_.reshape(slen, n_heads, head_dim)
        V_h = V.reshape(slen, n_heads, head_dim)
        Q_h = apply_rotary(Q_h, cos, sin, rot_ndims)
        K_h = apply_rotary(K_h, cos, sin, rot_ndims)
        Q_h2 = Q_h.transpose(1, 0, 2)
        K_h2 = K_h.transpose(1, 0, 2)
        V_h2 = V_h.transpose(1, 0, 2)
        sc = 1.0 / math.sqrt(head_dim)
        heads = []
        for h in range(n_heads):
            p = softmax_np(Q_h2[h] @ K_h2[h].T * sc + mk)
            heads.append(p @ V_h2[h])
        ctx = np.stack(heads, axis=1).reshape(slen, D)
        att = ctx @ lw['WO'].T + lw['bO']
        pre = ln2 @ lw['W1'].T + lw['b1']
        gout = gelu(pre)
        fout = gout @ lw['W2'].T + lw['b2']
        x = x + att + fout
    lf = ln_np(x, lnf_g, lnf_b)
    return lf @ lm_h.T
print('\n  Verifying numpy engine vs PyTorch...')
PROMPT = 'The quick brown fox jumps over the lazy dog. Once upon a time'
inp = tokenizer.encode(PROMPT, return_tensors='pt')
with torch.no_grad():
    pt_logits = model(inp).logits[0].numpy()
np_logits = forward(inp[0].tolist(), exact)
pt_top = np.argsort(pt_logits[-1])[-5:][::-1]
np_top = np.argsort(np_logits[-1])[-5:][::-1]
pt_next = int(pt_top[0])
np_next = int(np_top[0])
print(f"  PyTorch next token: {pt_next} '{tokenizer.decode([pt_next])}'")
print(f"  Numpy   next token: {np_next} '{tokenizer.decode([np_next])}'")
print(f"  Match: {('✓' if pt_next == np_next else '✗ — check RoPE/arch')}")
print('\n' + '=' * 70)
print('  W-HASH SPECTRUM TEST')
print('  Peaked vs Flat — determines compression readiness')
print('=' * 70)
print(f"\n  {'Layer':<8} {'Matrix':<8} {'cumE@5':>8} {'cumE@10':>9} {'cumE@20':>9} {'cumE@50':>9} {'Shape':<16} {'Type'}")
print(f"  {'─' * 80}")
layer_compress_ranks = {}
for l in range(n_layers):
    lw = exact[l]
    for name, W in [('W1', lw['W1']), ('W2', lw['W2']), ('WQ', lw['WQ']), ('WO', lw['WO'])]:
        _, S, _ = np.linalg.svd(W.astype(np.float64), full_matrices=False)
        cumE = np.cumsum(S ** 2) / np.sum(S ** 2)
        e5 = cumE[min(4, len(cumE) - 1)]
        e10 = cumE[min(9, len(cumE) - 1)]
        e20 = cumE[min(19, len(cumE) - 1)]
        e50 = cumE[min(49, len(cumE) - 1)]
        r99 = int(np.searchsorted(cumE, 0.99)) + 1
        if e10 > 0.7:
            kind = 'PEAKED  ← compress aggressively'
        elif e10 > 0.4:
            kind = 'MODERATE ← compress lightly'
        elif e10 > 0.2:
            kind = 'MIXED    ← compress with caution'
        else:
            kind = 'FLAT     ← do not compress'
        if name in ('W1', 'W2') and l not in layer_compress_ranks:
            layer_compress_ranks[l] = {}
        if name == 'W1':
            layer_compress_ranks[l]['W1_r99'] = r99
        if name == 'W2':
            layer_compress_ranks[l]['W2_r99'] = r99
        print(f'  L{l:<7} {name:<8} {e5:>8.2f} {e10:>9.2f} {e20:>9.2f} {e50:>9.2f}  {str(W.shape):<16} {kind}')

def svd_compress(W, rank):
    U, S, Vt = np.linalg.svd(W.astype(np.float64), full_matrices=False)
    r = min(rank, len(S))
    return (U[:, :r] * S[:r] @ Vt[:r, :]).astype(np.float32)

def make_compressed(w1_rank, w2_rank, wq_rank=None, wo_rank=None):
    cl = []
    for l in range(n_layers):
        lw = exact[l]
        W1c = svd_compress(lw['W1'], w1_rank)
        W2c = svd_compress(lw['W2'], w2_rank)
        WQc = svd_compress(lw['WQ'], wq_rank) if wq_rank else lw['WQ']
        WKc = svd_compress(lw['WK'], wq_rank) if wq_rank else lw['WK']
        WVc = svd_compress(lw['WV'], wq_rank) if wq_rank else lw['WV']
        WOc = svd_compress(lw['WO'], wo_rank) if wo_rank else lw['WO']
        cl.append({**lw, 'W1': W1c, 'W2': W2c, 'WQ': WQc, 'WK': WKc, 'WV': WVc, 'WO': WOc})
    return cl
N_TOK = 300
PROMPT2 = 'Once upon a time, in a small village, there lived a little girl named Lily.'
inp2 = tokenizer.encode(PROMPT2, return_tensors='pt')
print(f'\n  Generating {N_TOK} tokens per config...')
pt_ids = inp2.clone()
with torch.no_grad():
    for _ in range(N_TOK):
        lg = model(pt_ids).logits
        nid = torch.argmax(lg[0, -1]).item()
        pt_ids = torch.cat([pt_ids, torch.tensor([[nid]])], dim=1)
pt_gen = pt_ids[0].tolist()[len(inp2[0]):]
np_ids = inp2[0].tolist()
for _ in range(N_TOK):
    lg = forward(np_ids, exact)
    np_ids.append(int(np.argmax(lg[-1])))
np_match = sum((a == b for a, b in zip(pt_gen, np_ids[len(inp2[0]):])))
print(f"  Numpy exact vs PyTorch: {np_match}/{N_TOK} match ({('✓' if np_match == N_TOK else f'~{np_match}')})")
print('\n' + '=' * 70)
print(f'  COMPRESSION RESULTS — {N_TOK} TOKENS')
print('=' * 70)
fr = min(FFN_D, D)
configs = [('Baseline (exact)', fr, fr, None, None), ('W1/W2 = 90% energy', int(fr * 0.7), int(fr * 0.7), None, None), ('W1/W2 = 50% rank', fr // 2, fr // 2, None, None), ('W1/W2 = 25% rank', fr // 4, fr // 4, None, None), ('FFN+QKV: W1/W2=50% QKV=50%', fr // 2, fr // 2, D // 2, None), ('FFN+QKV: W1/W2=50% QKV=25%', fr // 2, fr // 2, D // 4, None), ('ALL=25%', fr // 4, fr // 4, D // 4, D // 4)]
print(f"\n  {'Config':<40} {'Match%':>8} {'AvgLogP':>9} {'Quality'}")
print(f"  {'─' * 72}")
results = []
for cfg_name, w1r, w2r, wqr, wor in configs:
    cl = make_compressed(w1r, w2r, wqr, wor)
    gen_ids = inp2[0].tolist()
    for _ in range(N_TOK):
        lg = forward(gen_ids, cl)
        gen_ids.append(int(np.argmax(lg[-1])))
    gen_tok = gen_ids[len(inp2[0]):]
    matches = sum((a == b for a, b in zip(pt_gen, gen_tok)))
    tok_pct = 100 * matches / N_TOK
    with torch.no_grad():
        gt = torch.tensor([gen_ids])
        out = model(gt)
        lp = torch.nn.functional.log_softmax(out.logits[0], dim=-1)
        avg_lp = float(lp[len(inp2[0]) - 1:-1].gather(1, torch.tensor(gen_ids[len(inp2[0]):]).unsqueeze(1)).mean())
    quality = '✓ LOSSLESS' if tok_pct > 95 else '✓ EXCELLENT' if tok_pct > 80 else '~ GOOD' if tok_pct > 60 else '△ DEGRADED' if tok_pct > 30 else '✗ BROKEN'
    results.append({'name': cfg_name, 'tok_pct': tok_pct, 'avg_lp': avg_lp, 'text': tokenizer.decode(gen_ids), 'w1r': w1r, 'w2r': w2r})
    print(f'  {cfg_name:<40} {tok_pct:>7.0f}% {avg_lp:>9.3f}  {quality}')
print('\n' + '=' * 70)
print('  GENERATED TEXTS')
print('=' * 70)
print(f'\n  PYTORCH:\n  {tokenizer.decode(pt_ids[0].tolist())[:400]}\n')
for r in sorted(results, key=lambda x: x['tok_pct'], reverse=True)[:4]:
    print(f"  [{r['name']}] match={r['tok_pct']:.0f}%")
    print(f"  {r['text'][:350]}\n")
best = max(results[1:], key=lambda r: r['tok_pct'])
print('=' * 70)
print(f"\n  SPECTRUM LESSON:\n  TinyStories-1M W1 cumE@10 = 0.39  → FLAT → not compressible\n  Pythia-160M    W1 cumE@10 = ?     → check output above\n\n  If Pythia cumE@10 > 0.40 → compression works → proven for real models\n  If Pythia cumE@10 < 0.20 → need even larger model (1B+)\n\n  70B prediction: cumE@10 >> 0.60 (massive overparameterization)\n  → QKV + FFN both compress → 14GB on laptop → PROVEN\n\n  Best compression: {best['name']}\n  Match: {best['tok_pct']:.0f}%\n")
print('=' * 70 + '\n')
