import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math, time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
NORM = 1000.0
SEQ_LEN = 4

class AdaptiveComplexBlock(nn.Module):

    def __init__(self, dim, adapt_scale=0.1):
        super().__init__()
        self.dim = dim
        self.adapt_scale = adapt_scale
        self.W_real = nn.Linear(dim, dim, bias=True)
        self.W_imag = nn.Linear(dim, dim, bias=False)
        nn.init.normal_(self.W_imag.weight, std=0.01)
        self.u_real = nn.Parameter(torch.randn(dim) * 0.01)
        self.v_real = nn.Parameter(torch.randn(dim) * 0.01)
        self.u_imag = nn.Parameter(torch.randn(dim) * 0.01)
        self.v_imag = nn.Parameter(torch.randn(dim) * 0.01)
        self.act_bias = nn.Parameter(torch.zeros(dim) - 1.0)

    def forward(self, x_real, x_imag):
        batch = x_real.shape[0]
        magnitude = torch.sqrt(x_real ** 2 + x_imag ** 2 + 1e-08)
        phase = torch.atan2(x_imag, x_real)
        mag_signal = magnitude.mean(dim=-1, keepdim=True)
        phase_signal = phase.mean(dim=-1, keepdim=True)
        signal = mag_signal + phase_signal
        base_real = self.W_real(x_real) - self.W_imag(x_imag)
        u_dot_xr = (x_real * self.u_real).sum(-1, keepdim=True)
        u_dot_xi = (x_imag * self.u_imag).sum(-1, keepdim=True)
        adapt_real = self.adapt_scale * signal * (u_dot_xr * self.v_real - u_dot_xi * self.v_imag)
        base_imag = self.W_real(x_imag) + self.W_imag(x_real)
        adapt_imag = self.adapt_scale * signal * (u_dot_xr * self.v_imag + u_dot_xi * self.v_real)
        y_real = base_real + adapt_real
        y_imag = base_imag + adapt_imag
        mag = torch.sqrt(y_real ** 2 + y_imag ** 2 + 1e-08)
        gate = F.relu(mag + self.act_bias) / mag
        y_real, y_imag = (y_real * gate, y_imag * gate)
        return (x_real + y_real, x_imag + y_imag)

class AdaptiveComplexNet(nn.Module):

    def __init__(self, dim, n_blocks, adapt_scale=0.1, seq_len=SEQ_LEN):
        super().__init__()
        self.input_real = nn.Linear(seq_len, dim)
        self.input_imag = nn.Linear(seq_len, dim)
        nn.init.normal_(self.input_imag.weight, std=0.01)
        self.blocks = nn.ModuleList([AdaptiveComplexBlock(dim, adapt_scale) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        xr = torch.tanh(self.input_real(x))
        xi = torch.tanh(self.input_imag(x))
        for b in self.blocks:
            xr, xi = b(xr, xi)
        mag = torch.sqrt(xr ** 2 + xi ** 2 + 1e-08)
        return self.output(mag)

    def adaptation_analysis(self, x1, x2):
        diffs = []
        xr1 = torch.tanh(self.input_real(x1))
        xi1 = torch.tanh(self.input_imag(x1))
        xr2 = torch.tanh(self.input_real(x2))
        xi2 = torch.tanh(self.input_imag(x2))
        for blk in self.blocks:
            mag1 = torch.sqrt(xr1 ** 2 + xi1 ** 2 + 1e-08)
            phase1 = torch.atan2(xi1, xr1)
            sig1 = mag1.mean(-1, keepdim=True) + phase1.mean(-1, keepdim=True)
            mag2 = torch.sqrt(xr2 ** 2 + xi2 ** 2 + 1e-08)
            phase2 = torch.atan2(xi2, xr2)
            sig2 = mag2.mean(-1, keepdim=True) + phase2.mean(-1, keepdim=True)
            sig_diff = (sig1 - sig2).abs().mean().item()
            diffs.append(sig_diff)
            xr1, xi1 = blk(xr1, xi1)
            xr2, xi2 = blk(xr2, xi2)
        return diffs

class FrozenComplexBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.wr = nn.Linear(dim, dim)
        self.wi = nn.Linear(dim, dim, bias=False)
        nn.init.normal_(self.wi.weight, std=0.01)
        self.b = nn.Parameter(torch.zeros(dim) - 1.0)

    def forward(self, xr, xi):
        yr = self.wr(xr) - self.wi(xi)
        yi = self.wr(xi) + self.wi(xr)
        m = torch.sqrt(yr ** 2 + yi ** 2 + 1e-08)
        g = F.relu(m + self.b) / m
        return (xr + yr * g, xi + yi * g)

class FrozenComplexNet(nn.Module):

    def __init__(self, dim, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.ir = nn.Linear(seq_len, dim)
        self.ii = nn.Linear(seq_len, dim)
        nn.init.normal_(self.ii.weight, std=0.01)
        self.blocks = nn.ModuleList([FrozenComplexBlock(dim) for _ in range(n_blocks)])
        self.o = nn.Linear(dim, 1)

    def forward(self, x):
        xr = torch.tanh(self.ir(x))
        xi = torch.tanh(self.ii(x))
        for b in self.blocks:
            xr, xi = b(xr, xi)
        return self.o(torch.sqrt(xr ** 2 + xi ** 2 + 1e-08))

class FlatResBlock(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.l = nn.Linear(d, d)
        self.a = nn.Tanh()

    def forward(self, x):
        return self.a(self.l(x)) + x

class FlatNet(nn.Module):

    def __init__(self, dim, nb, sl=SEQ_LEN):
        super().__init__()
        self.p = nn.Sequential(nn.Linear(sl, dim), nn.Tanh())
        self.b = nn.ModuleList([FlatResBlock(dim) for _ in range(nb)])
        self.o = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.p(x)
        for b in self.b:
            x = b(x)
        return self.o(x)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05
X, Y = gen_sequences()
sp = int(len(X) * 0.8)
X_tr, Y_tr = (X[:sp].to(device), Y[:sp].to(device))
X_te, Y_te = (X[sp:].to(device), Y[sp:].to(device))
print(f'Sequences: {len(X)}')

def train(model, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    t0 = time.time()
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model)
            print(f'    {label:<28} ep{ep:>5}  loss={best:>12.6f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    elapsed = time.time() - t0
    return (best, log, elapsed)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 3000
configs = [('Flat dim=16 b=10', FlatNet(16, 10)), ('Flat dim=16 b=74', FlatNet(16, 74)), ('Complex frozen d=16 b=10', FrozenComplexNet(16, 10)), ('Complex frozen d=16 b=74', FrozenComplexNet(16, 74)), ('Complex adaptive d=16 b=10 s=0.1', AdaptiveComplexNet(16, 10, adapt_scale=0.1)), ('Complex adaptive d=16 b=74 s=0.1', AdaptiveComplexNet(16, 74, adapt_scale=0.1)), ('Complex adaptive d=16 b=10 s=0.3', AdaptiveComplexNet(16, 10, adapt_scale=0.3)), ('Complex adaptive d=8  b=10 s=0.1', AdaptiveComplexNet(8, 10, adapt_scale=0.1))]
print_sep('ADAPTIVE COMPLEX vs FROZEN COMPLEX vs FLAT')
print(f'  Key: adaptation = low-rank W shift per input')
print(f'  W_eff = W_base + scale * signal * outer(u,v)')
print(f'  Never frozen. Pure matmul. GPU speed.\n')
results = []
for label, model in configs:
    model = model.to(device)
    params = sum((p.numel() for p in model.parameters()))
    print(f'\n  ── {label} (params={params:,}) ──')
    np.random.seed(42)
    loss, log, elapsed = train(model, EPOCHS, lr=0.001, label=label[:28])
    s = score(model)
    results.append((label, params, loss, s, model, log, elapsed))
print_sep('ADAPTATION ANALYSIS — Does W actually change per input?')
best_adaptive = next((r for r in results if 'adaptive' in r[0] and r[3] > 15), None)
if best_adaptive:
    model_a = best_adaptive[4]
    model_a.eval()
    print(f'\n  Testing: {best_adaptive[0]}')
    print(f'  Two very different inputs:')
    print(f'    Input 1: squares    [1,4,9,16] → 25')
    print(f'    Input 2: geometric  [1,3,9,27] → 81')
    print(f'  If adaptation works: signal difference > 0 at each block\n')
    with torch.no_grad():
        x1 = torch.tensor([[1 / NORM, 4 / NORM, 9 / NORM, 16 / NORM]], dtype=torch.float32).to(device)
        x2 = torch.tensor([[1 / NORM, 3 / NORM, 9 / NORM, 27 / NORM]], dtype=torch.float32).to(device)
        diffs = model_a.adaptation_analysis(x1, x2)
    print(f"  {'Block':>6}  {'Signal diff':>14}  Adaptation active?")
    print(f"  {'─' * 40}")
    sample = list(range(0, len(diffs), max(1, len(diffs) // 8)))
    for i in sample:
        active = 'YES — W is different' if diffs[i] > 0.0001 else 'minimal'
        print(f'  {i + 1:>6}  {diffs[i]:>14.6f}  {active}')
    mean_diff = np.mean(diffs)
    print(f'\n  Mean signal diff across all blocks: {mean_diff:.6f}')
    print(f"  → Network {('IS' if mean_diff > 0.0001 else 'is NOT')} adapting weights per input")
print_sep('FINAL SCOREBOARD')
results.sort(key=lambda x: (-x[3], x[2]))
print(f"\n  {'Model':<32}  {'Params':>8}  {'Score':>7}  {'Loss':>14}  {'Time':>6}  Type")
print(f"  {'─' * 85}")
for rank, (label, params, loss, s, _, _, elapsed) in enumerate(results):
    if 'adaptive' in label:
        typ = 'ADAPTIVE'
    elif 'frozen' in label:
        typ = 'frozen complex'
    else:
        typ = 'flat'
    mark = ' ← WINNER' if rank == 0 else ''
    print(f'  {label:<32}  {params:>8,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {elapsed:>5.0f}s  {typ}{mark}')
print_sep('KEY INSIGHT')
best_flat_r = min([r for r in results if 'Flat' in r[0]], key=lambda x: x[2])
best_froz_r = min([r for r in results if 'frozen' in r[0]], key=lambda x: x[2])
best_adap_r = min([r for r in results if 'adaptive' in r[0]], key=lambda x: x[2])
print(f'\n  Flat (classical, frozen):\n    loss={best_flat_r[2]:.8f}  params={best_flat_r[1]:,}\n\n  Complex frozen (richer space, still frozen):\n    loss={best_froz_r[2]:.8f}  params={best_froz_r[1]:,}\n\n  Complex adaptive (richer space, NEVER frozen):\n    loss={best_adap_r[2]:.8f}  params={best_adap_r[1]:,}\n\n  THREE LEVELS:\n    Flat       = flat space + frozen    = baseline\n    Complex    = curved space + frozen  = better space\n    Adaptive   = curved space + alive   = space + time\n\n  ALIVE means:\n    At inference: each input shifts W slightly\n    Different input → different effective network\n    The network THINKS differently about each input\n    Not just retrieves — ADAPTS\n\n  If adaptive wins:\n    We found fast + intelligent together.\n    Same GPU speed. More intelligence.\n    This is the direction.\n')
