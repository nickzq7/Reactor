import numpy as np
import time
print('\n' + '=' * 62)
print('  W PRINCIPLE — GROUND ZERO')
print('  Simplest first. Grow carefully.')
print('  Each step confirmed before next.')
print('=' * 62)
results = {}
print('\n' + '─' * 62)
print('  STEP 1A — f(x,y) = x + y')
print('  Simplest function. Ground truth.')
print('─' * 62)
np.random.seed(42)
N = 1000
X_add = np.random.randn(N, 2)
Y_add = X_add[:, 0:1] + X_add[:, 1:2]
N_tr = 800
W_add = np.linalg.lstsq(X_add[:N_tr], Y_add[:N_tr], rcond=None)[0]
pred = X_add[N_tr:] @ W_add
err = np.mean((pred - Y_add[N_tr:]) ** 2)
r2 = 1 - err / np.var(Y_add[N_tr:])
print(f'\n  W shape  : {W_add.shape}')
print(f'  W values : {W_add.flatten().round(4)}')
print(f'  Expected : [1. 1.]  (f = x+y means W=[1,1])')
print(f'  R²       : {r2:.6f}')
print(f"  RESULT   : {('PERFECT' if r2 > 0.9999 else 'PARTIAL')}")
results['1a_add'] = r2
print('\n' + '─' * 62)
print('  STEP 1B — f(x,y) = x * y')
print('  Nonlinear. Testing linear W limit.')
print('─' * 62)
X_mul = np.random.randn(N, 2)
Y_mul = (X_mul[:, 0] * X_mul[:, 1]).reshape(-1, 1)
W_mul = np.linalg.lstsq(X_mul[:N_tr], Y_mul[:N_tr], rcond=None)[0]
pred = X_mul[N_tr:] @ W_mul
r2 = 1 - np.mean((pred - Y_mul[N_tr:]) ** 2) / np.var(Y_mul[N_tr:])
print(f'\n  R²     : {r2:.6f}')
print(f"  RESULT : {('PERFECT' if r2 > 0.999 else 'PARTIAL - nonlinearity confirmed')}")
print(f'  NOTE   : Linear W cannot capture multiplication exactly.')
print(f'           This is honest. This is what to expect for nonlinear f.')
results['1b_mul'] = r2
print('\n' + '─' * 62)
print('  STEP 1C — f(x,y) = x*y  WITH expansion')
print('  Add cross-term feature. Linear in new space.')
print('  This is how W handles known nonlinearity.')
print('─' * 62)

def expand(X):
    return np.column_stack([X, X[:, 0] * X[:, 1]])
X_exp = expand(X_mul)
W_exp = np.linalg.lstsq(X_exp[:N_tr], Y_mul[:N_tr], rcond=None)[0]
pred = X_exp[N_tr:] @ W_exp
r2 = 1 - np.mean((pred - Y_mul[N_tr:]) ** 2) / np.var(Y_mul[N_tr:])
print(f'\n  Expanded W shape : {W_exp.shape}')
print(f'  W values         : {W_exp.flatten().round(4)}')
print(f'  Expected         : [0, 0, 1]  (only x*y matters)')
print(f'  R²               : {r2:.6f}')
print(f"  RESULT           : {('PERFECT' if r2 > 0.9999 else 'PARTIAL')}")
results['1c_mul_exp'] = r2
print('\n' + '─' * 62)
print('  STEP 2A — SEQUENCE: running sum')
print('  f([x0,x1,x2,x3]) = cumsum([x0,x1,x2,x3])')
print('  Sequential. Positional. Cross-token dependency.')
print('─' * 62)
L = 4
X_seq = np.random.randn(N, L)
Y_seq = np.cumsum(X_seq, axis=1)
X_flat = X_seq.reshape(N, L)
Y_flat = Y_seq.reshape(N, L)
W_seq = np.linalg.lstsq(X_flat[:N_tr], Y_flat[:N_tr], rcond=None)[0]
pred = X_flat[N_tr:] @ W_seq
r2 = 1 - np.mean((pred - Y_flat[N_tr:]) ** 2) / np.var(Y_flat[N_tr:])
print(f'\n  W shape  : {W_seq.shape}')
print(f'  W matrix (should be lower triangular of 1s):')
print(np.round(W_seq, 2))
print(f'  R²       : {r2:.6f}')
print(f"  RESULT   : {('PERFECT' if r2 > 0.9999 else 'PARTIAL')}")
results['2a_cumsum'] = r2
print('\n' + '─' * 62)
print('  STEP 2B — SEQUENCE: max lookback')
print('  f([x0,x1,x2,x3]) = cummax (running maximum)')
print('  Requires comparison between tokens.')
print('  Attention does this. Can linear W?')
print('─' * 62)
Y_max = np.maximum.accumulate(X_seq, axis=1)
W_max = np.linalg.lstsq(X_flat[:N_tr], Y_max[:N_tr], rcond=None)[0]
pred = X_flat[N_tr:] @ W_max
r2 = 1 - np.mean((pred - Y_max[N_tr:]) ** 2) / np.var(Y_max[N_tr:])
print(f'\n  R²     : {r2:.6f}')
print(f"  RESULT : {('PERFECT' if r2 > 0.999 else 'PARTIAL — nonlinear op, linear W limited')}")
print(f'  NOTE   : cummax is nonlinear (max function).')
print(f'           Same reason attention needs nonlinearity.')
results['2b_cummax'] = r2
print('\n' + '─' * 62)
print('  STEP 3A — RULE-BASED LANGUAGE')
print('  5 words. 3 grammar rules. No neural network.')
print('  Can W capture grammar as ONE object?')
print('─' * 62)
words = ['the', 'cat', 'sat', 'on', 'mat']
W2I = {w: i for i, w in enumerate(words)}
I2W = {i: w for i, w in enumerate(words)}
V = len(words)
RULES = {'the': ['cat', 'mat'], 'cat': ['sat'], 'sat': ['on'], 'on': ['the'], 'mat': ['sat']}

def rule_next(word):
    return RULES.get(word, ['the'])[0]

def one_hot(i, size):
    v = np.zeros(size)
    v[i] = 1.0
    return v
CTX = 3
pairs = []
seq = ['the', 'cat', 'sat', 'on', 'the', 'mat', 'sat', 'on', 'the', 'cat', 'sat', 'on', 'the', 'mat', 'sat', 'on']
for i in range(len(seq) - CTX):
    x = np.concatenate([one_hot(W2I[seq[i + j]], V) for j in range(CTX)])
    y = one_hot(W2I[seq[i + CTX]], V)
    pairs.append((x, y))
for start in ['the', 'cat', 'sat', 'on', 'mat']:
    s = [start]
    for _ in range(20):
        s.append(rule_next(s[-1]))
    for i in range(len(s) - CTX):
        x = np.concatenate([one_hot(W2I[s[i + j]], V) for j in range(CTX)])
        y = one_hot(W2I[s[i + CTX]], V)
        pairs.append((x, y))
X_lang = np.array([p[0] for p in pairs])
Y_lang = np.array([p[1] for p in pairs])
n_tr = int(len(X_lang) * 0.8)
W_lang = np.linalg.lstsq(X_lang[:n_tr], Y_lang[:n_tr], rcond=None)[0]
pred = X_lang[n_tr:] @ W_lang
pred_idx = pred.argmax(axis=1)
true_idx = Y_lang[n_tr:].argmax(axis=1)
acc = np.mean(pred_idx == true_idx)
r2 = 1 - np.mean((pred - Y_lang[n_tr:]) ** 2) / np.var(Y_lang[n_tr:])
print(f'\n  Grammar rules: {RULES}')
print(f'  W shape : {W_lang.shape}')
print(f'  Accuracy: {acc * 100:.1f}%')
print(f'  R²      : {r2:.6f}')
print(f"  RESULT  : {('PERFECT' if acc > 0.99 else 'PARTIAL')}")
gen = ['the']
for _ in range(10):
    ctx = [W2I.get(gen[max(0, len(gen) - CTX + j)], 0) for j in range(CTX)]
    x = np.concatenate([one_hot(c, V) for c in ctx[-CTX:]])
    y = x @ W_lang
    gen.append(I2W[y.argmax()])
print(f"  W generates: {' '.join(gen)}")
print(f"  Rule generates: {' '.join(['the'] + [rule_next(w) for w in ['the', 'cat', 'sat', 'on', 'the', 'mat', 'sat', 'on', 'the', 'cat']])}")
results['3a_grammar'] = acc
print('\n' + '─' * 62)
print('  STEP 3B — GRAMMAR WITH AMBIGUITY')
print("  'the' → 'cat' OR 'mat'  (must choose by context)")
print('  This is where W needs context sensitivity.')
print('─' * 62)
CTX2 = 4
pairs2 = []
s1 = 'on the cat sat on the cat sat on the cat sat on the cat'.split()
s2 = 'mat the mat sat mat the mat sat mat the mat sat mat the'.split()
for s in [s1, s2]:
    ws = [W2I.get(w, 0) for w in s]
    for i in range(len(ws) - CTX2):
        x = np.concatenate([one_hot(ws[i + j], V) for j in range(CTX2)])
        y = one_hot(ws[i + CTX2], V)
        pairs2.append((x, y))
X2 = np.array([p[0] for p in pairs2])
Y2 = np.array([p[1] for p in pairs2])
n_tr2 = int(len(X2) * 0.8)
W_ctx = np.linalg.lstsq(X2[:n_tr2], Y2[:n_tr2], rcond=None)[0]
pred2 = X2[n_tr2:] @ W_ctx
acc2 = np.mean(pred2.argmax(1) == Y2[n_tr2:].argmax(1))
r2_2 = 1 - np.mean((pred2 - Y2[n_tr2:]) ** 2) / np.var(Y2[n_tr2:])
print(f'\n  Accuracy: {acc2 * 100:.1f}%')
print(f'  R²      : {r2_2:.6f}')
print(f"  RESULT  : {('PERFECT — W resolves ambiguity by context' if acc2 > 0.99 else 'PARTIAL — ambiguity not fully resolved')}")
results['3b_ambiguity'] = acc2
print('\n' + '=' * 62)
print('  COMPLETE MAP — WHERE W WORKS')
print('=' * 62)
print(f"\n  STEP 1A  f(x,y) = x+y          R²={results['1a_add']:.4f}   {('✓ PERFECT' if results['1a_add'] > 0.999 else '✗ PARTIAL')}\n  STEP 1B  f(x,y) = x*y          R²={results['1b_mul']:.4f}   {('✓ PERFECT' if results['1b_mul'] > 0.999 else '✗ NONLINEAR — W limited')}\n  STEP 1C  f(x,y) = x*y +expand  R²={results['1c_mul_exp']:.4f}   {('✓ PERFECT' if results['1c_mul_exp'] > 0.999 else '✗ PARTIAL')}\n  STEP 2A  cumsum sequence        R²={results['2a_cumsum']:.4f}   {('✓ PERFECT' if results['2a_cumsum'] > 0.999 else '✗ PARTIAL')}\n  STEP 2B  cummax sequence        R²={results['2b_cummax']:.4f}   {('✓ PERFECT' if results['2b_cummax'] > 0.999 else '✗ NONLINEAR')}\n  STEP 3A  grammar rules          Acc={results['3a_grammar'] * 100:.1f}%   {('✓ PERFECT' if results['3a_grammar'] > 0.99 else '✗ PARTIAL')}\n  STEP 3B  ambiguous grammar      Acc={results['3b_ambiguity'] * 100:.1f}%   {('✓ PERFECT' if results['3b_ambiguity'] > 0.99 else '✗ PARTIAL')}\n\n  PATTERN:\n  ──────────────────────────────────────────────────\n  W works perfectly on:\n    Linear functions         (addition, cumsum)\n    Grammar rules            (deterministic)\n    Context-dependent rules  (with enough context)\n\n  W fails on:\n    Pure nonlinear functions  (multiplication, cummax)\n    UNLESS we expand features (x*y added explicitly)\n\n  KEY FINDING:\n    W does not fail on COMPLEXITY.\n    W fails on NONLINEARITY without feature expansion.\n    If we know the nonlinearity — we can add it as feature.\n    Then W works perfectly again.\n\n  IMPLICATION FOR TRANSFORMER:\n    Transformer nonlinearity = tanh/relu + softmax(QK/sqrt(D))\n    These are KNOWN nonlinearities.\n    If we add them as features:\n    W should work perfectly on transformer too.\n    This is the next step.\n    Not jumping to transformer.\n    Adding one known nonlinearity at a time.\n    Until W captures transformer exactly.\n  ──────────────────────────────────────────────────\n")
print('=' * 62 + '\n')
