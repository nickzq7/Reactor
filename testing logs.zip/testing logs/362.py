import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 1e-10 else 1.0

def fit_W(X, Y):
    X64 = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(X64, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)

def layernorm_np(x, w, b, eps=1e-05):
    mu = np.mean(x)
    std = np.std(x) + eps
    return (x - mu) / std * w + b
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. \n    She would run through the flowers and chase the butterflies that flew around her. \n    One morning she found a tiny kitten hiding under the big rose bush near the fence. \n    The kitten was very small and scared and it was crying softly in the shadows. \n    Lily gently picked up the kitten and held it close to her heart to keep it warm. \n    She carried it inside and showed her mother who smiled and said they could keep it. \n    They gave the kitten some warm milk and it stopped crying and started to purr happily. \n    Lily named the kitten Snowball because it was white and fluffy like a ball of snow.', 'The old farmer woke up very early every morning before the sun had risen in the sky. \n    He would walk out to the barn and feed all the animals that lived there on his farm. \n    There were cows and horses and chickens and pigs all waiting for their breakfast. \n    The farmer talked to each animal as he gave them food and fresh water to drink. \n    After feeding the animals he would go to the fields and work until the sun went down. \n    His children would bring him lunch and sit with him under the big oak tree nearby. \n    They would eat together and talk about the crops and the weather and the seasons. \n    In the evening the whole family sat by the fire and told stories until bedtime.', 'Deep in the forest there was a small house where a family of bears lived together. \n    The father bear was very big and strong and he caught fish from the river each day. \n    The mother bear was kind and gentle and she made honey cakes for the whole family. \n    The baby bear was curious and always wandering off to explore the woods nearby. \n    One day the baby bear followed a butterfly deep into the forest and got lost alone. \n    He sat down and began to cry because he could not find his way back home again. \n    A wise old owl heard him crying and flew down from a tall tree to help him out. \n    The owl showed him the path home and the baby bear ran back to his waiting family.', 'There was once a brave young knight who lived in a castle near the mountains high. \n    He spent his days training with his sword and shield and riding his white horse fast. \n    One day the king called all the knights together and said a dragon had come to the land. \n    The dragon was burning the villages and scaring all the people who lived near the hills. \n    The young knight volunteered to go and face the dragon and bring peace to the kingdom. \n    He rode for three days through dark forests and over high mountains to find the dragon. \n    When he finally found the dragon he discovered it was not evil but only very lonely. \n    The knight became friends with the dragon and together they protected the kingdom well.', 'A small girl named Sophie loved books more than anything else in the whole wide world. \n    She had read every book in her house and every book in the school library twice over. \n    One day she discovered a tiny door in the back of her bookshelf behind the tall books. \n    She opened it and found a magical library that went on forever in every direction. \n    The books here were alive and they would talk to her and tell her their stories directly. \n    She learned about faraway lands and ancient kingdoms and creatures no one had ever seen. \n    Every night she would sneak through the tiny door and read until she fell asleep there. \n    In the morning she would wake up back in her bed with new knowledge filling her mind.', 'The little village sat quietly at the edge of a great forest full of ancient trees. \n    Every year in autumn the villagers would hold a big festival to celebrate the harvest. \n    Children would run through the market eating apples and drinking warm spiced cider. \n    The baker would make special bread shaped like animals and the children loved it so much. \n    Musicians played their instruments and everyone danced in the square until midnight came. \n    The old grandmother would sit by the fire and tell stories of the village long ago. \n    She remembered when there were no roads and the forest came right up to the first houses. \n    The children listened with wide eyes and promised to remember the stories forever after.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. \n    Every night he would pull his blanket over his head and imagine monsters in the shadows. \n    His father gave him a small flashlight and told him to shine it at whatever scared him. \n    The first night Tommy shone the light and saw only his toys and books and nothing scary. \n    His father explained that darkness was just the absence of light and nothing more than that. \n    Tommy started to feel braver and soon he could sleep without the flashlight beside him. \n    He realized that many things we fear are not real and only exist in our imagination. \n    From that day on Tommy was known as the bravest boy in his whole neighborhood street.', 'The ocean was vast and blue and stretched as far as the eye could possibly see. \n    A young sailor named Marco had sailed across it many times in his small wooden boat. \n    He knew every star in the night sky and used them to navigate across the open water. \n    One night a terrible storm came and blew his boat far off course into unknown waters. \n    When morning came he saw an island he had never seen before on any of his old maps. \n    He went ashore and found the island was full of strange and beautiful plants and birds. \n    The people who lived there were kind and taught him their language over many warm days. \n    He stayed for a whole season and then sailed home with new knowledge of the wider world.', 'The little robot sat in the corner of the workshop waiting to be fixed by someone kind. \n    Its creator had built it with love and given it the ability to learn new things each day. \n    The robot could sort the tools and clean the floor and even make a simple pot of tea. \n    But one day it fell and broke its left arm and could no longer do its work properly. \n    A young engineer found it and carefully repaired the arm using spare parts from the shelf. \n    The robot was so grateful that it worked twice as hard and learned even faster than before. \n    It began to help with more complex tasks and soon became the most useful robot around. \n    Everyone in the workshop loved the little robot and gave it a special name of its own.', 'High up in the mountains there was a small school where children came from far away. \n    The teacher was an old woman who had taught for fifty years in that same cold classroom. \n    She knew that each child was different and needed to learn in their own special way. \n    Some children learned by reading and some by drawing and some by building things with hands. \n    She gave each child the kind of lesson that matched the way their mind worked best. \n    At the end of every year her students could all read and write and solve hard problems. \n    Parents from the villages below would climb the mountain path just to meet this teacher. \n    She always said the secret was simply to listen carefully to every child every single day.']
long_pairs = [('Once there was a little girl who loved flowers and would pick them every morning bright.\n    She put them in vases all around her house to make it smell wonderful and look beautiful.\n    Her favorite flowers were the yellow ones that grew near the old wooden fence outside.\n    Every spring she would wait eagerly for them to bloom and fill the garden with color.', 'There was a young child who adored blossoms and would gather them each dawn with joy.\n    She placed them in pots throughout her home to make it fragrant and appear quite lovely.\n    Her most beloved petals were the golden ones that sprouted by the ancient timber boundary.\n    Each springtime she would wait excitedly for them to open and brighten the yard with hues.', 'flowers/blossoms'), ('The big dog ran through the park chasing the ball that his owner had thrown far away.\n    He jumped over the bench and splashed through the pond and kept running fast and hard.\n    When he finally caught the ball he brought it back proudly wagging his tail with joy.\n    His owner laughed and threw it again and the dog ran off happily into the sunny day.', 'The large hound sprinted across the grounds pursuing the sphere his master had hurled ahead.\n    He leaped over the seat and crashed through the water and continued racing with great speed.\n    When he eventually retrieved the orb he returned it proudly shaking his tail with delight.\n    His master chuckled and tossed it once more and the hound dashed away into the bright afternoon.', 'dog/hound')]
print(f'\nCollecting h7 and ln_f from {len(long_texts)} long texts...')
h7_aligned = []
lnf_aligned = []
correct_aligned = []
cur_h7 = []
cur_lnf = []
hooks = []

def hook_h7(m, inp, out):
    cur_h7.append(inp[0].detach().float()[0].numpy().copy())

def hook_lnf(m, inp, out):
    cur_lnf.append(out.detach().float()[0].numpy().copy())
hooks.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_h7))
hooks.append(model.transformer.ln_f.register_forward_hook(hook_lnf))
with torch.no_grad():
    for text in long_texts:
        cur_h7.clear()
        cur_lnf.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        ids = toks['input_ids'][0].numpy()
        L = len(ids)
        h7s = cur_h7[0]
        lnfs = cur_lnf[0]
        for t in range(L - 1):
            h7_aligned.append(h7s[t])
            lnf_aligned.append(lnfs[t])
            correct_aligned.append(int(ids[t + 1]))
for h in hooks:
    h.remove()
H7 = np.array(h7_aligned, dtype=np.float32)
LNF = np.array(lnf_aligned, dtype=np.float32)
COR = correct_aligned
print(f'Total tokens: {len(H7)}')
lm_weight = model.lm_head.weight.detach().float().numpy()
ln_f_w = model.transformer.ln_f.weight.detach().float().numpy()
ln_f_b = model.transformer.ln_f.bias.detach().float().numpy()
print(f"\n{'=' * 60}")
print(f'  TEST 1 — ln_f decompression law ({len(H7)} tokens)')
print(f"{'=' * 60}")
n = len(H7)
s = int(n * 0.8)
W_lnf = fit_W(H7[:s], LNF[:s])
Xb = np.c_[H7.astype(np.float64), np.ones(n)]
r2_tr = r2(Xb[:s] @ W_lnf, LNF[:s])
r2_te = r2(Xb[s:] @ W_lnf, LNF[s:])
print(f'\n  R² train: {r2_tr:.6f}')
print(f'  R² test:  {r2_te:.6f}')
marker = '✓ LAW CONFIRMED' if r2_te > 0.999 else '~ STRONG' if r2_te > 0.95 else 'PARTIAL'
print(f'  {marker}')
print(f'  h7 std:   {np.std(H7):.4f}  →  ln_f std: {np.std(LNF):.4f}  ({np.std(LNF) / np.std(H7):.1f}x expansion)')
print(f"\n{'=' * 60}")
print(f'  TEST 2 — Prediction accuracy ({len(H7)} tokens)')
print(f"{'=' * 60}")
correct_norm = 0
correct_skip = 0
top5_norm = 0
top5_skip = 0
N = len(H7)
for i in range(N):
    lnf_out = layernorm_np(H7[i], ln_f_w, ln_f_b)
    logits_n = lnf_out @ lm_weight.T
    logits_s = H7[i] @ lm_weight.T
    pred_n = int(np.argmax(logits_n))
    pred_s = int(np.argmax(logits_s))
    if pred_n == COR[i]:
        correct_norm += 1
    if pred_s == COR[i]:
        correct_skip += 1
    if COR[i] in np.argsort(logits_n)[-5:]:
        top5_norm += 1
    if COR[i] in np.argsort(logits_s)[-5:]:
        top5_skip += 1
print(f'\n  Normal (h7→ln_f→lm_head):     {correct_norm}/{N} = {correct_norm / N:.1%}')
print(f'  Skip   (h7→lm_head directly):  {correct_skip}/{N} = {correct_skip / N:.1%}')
print(f'  Top-5 normal:  {top5_norm}/{N} = {top5_norm / N:.1%}')
print(f'  Top-5 skip:    {top5_skip}/{N} = {top5_skip / N:.1%}')
print(f"\n{'=' * 60}")
print(f'  TEST 3 — Same meaning long sentences')
print(f'  Last token h7 = sentence attractor.')
print(f"{'=' * 60}")
pair_h7 = []
cur_pair = []
hooks2 = []

def hook_pair(m, inp, out):
    cur_pair.append(inp[0].detach().float()[0, -1].numpy().copy())
hooks2.append(model.transformer.h[n_layers - 1].register_forward_hook(hook_pair))
with torch.no_grad():
    for sA, sB, label in long_pairs:
        cur_pair.clear()
        tA = tokenizer(sA, return_tensors='pt', max_length=128, truncation=True)
        model(**tA)
        hA = cur_pair[0].copy()
        cur_pair.clear()
        tB = tokenizer(sB, return_tensors='pt', max_length=128, truncation=True)
        model(**tB)
        hB = cur_pair[0].copy()
        pair_h7.append((hA, hB, label))
rand_h7 = []
with torch.no_grad():
    for text in long_texts[:8]:
        cur_pair.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        rand_h7.append(cur_pair[0].copy())
for h in hooks2:
    h.remove()
rand_dists = []
for i in range(len(rand_h7)):
    for j in range(i + 1, len(rand_h7)):
        rand_dists.append(float(np.linalg.norm(rand_h7[i] - rand_h7[j])))
mean_rand = float(np.mean(rand_dists))
print(f"\n  {'Pair':<20} {'Same-meaning dist':<22} {'Random dist':<14} {'Closer?'}")
print(f"  {'─' * 65}")
same_dists = []
for hA, hB, label in pair_h7:
    d = float(np.linalg.norm(hA - hB))
    same_dists.append(d)
    closer = '✓ CLOSER' if d < mean_rand * 0.8 else '~ slight' if d < mean_rand else '✗ NO'
    print(f'  {label:<20} {d:<22.4f} {mean_rand:<14.4f} {closer}')
print(f'\n  Mean same-meaning: {np.mean(same_dists):.4f}')
print(f'  Mean random:       {mean_rand:.4f}')
print(f'  Ratio:             {np.mean(same_dists) / mean_rand:.4f}')
print(f"\n{'=' * 60}")
print(f'  TEST 4 — Core dimension stability (PCA on {len(H7)} tokens)')
print(f"{'=' * 60}")
H7c = H7 - H7.mean(axis=0)
U, S, Vt = np.linalg.svd(H7c, full_matrices=False)
var_exp = S ** 2 / (S ** 2).sum()
cumvar = np.cumsum(var_exp)
dims_90 = int(np.searchsorted(cumvar, 0.9)) + 1
dims_95 = int(np.searchsorted(cumvar, 0.95)) + 1
dims_99 = int(np.searchsorted(cumvar, 0.99)) + 1
print(f'\n  Dims 90% variance: {dims_90}/{D}')
print(f'  Dims 95% variance: {dims_95}/{D}')
print(f'  Dims 99% variance: {dims_99}/{D}')
print(f'\n  Top 10 dims:')
for i in range(min(10, len(S))):
    bar = '█' * int(var_exp[i] * 300)
    print(f'  dim {i + 1:2d}: {var_exp[i]:.4f}  {bar}')
third = n // 3
splits = [H7[:third], H7[third:2 * third], H7[2 * third:]]
Vts = []
for sp in splits:
    sc = sp - sp.mean(axis=0)
    _, _, vt = np.linalg.svd(sc, full_matrices=False)
    Vts.append(vt)
print(f'\n  Core dim stability (3 splits):')
top_k = 5
stabs = []
for k in range(top_k):
    c12 = abs(float(np.dot(Vts[0][k], Vts[1][k])))
    c13 = abs(float(np.dot(Vts[0][k], Vts[2][k])))
    c23 = abs(float(np.dot(Vts[1][k], Vts[2][k])))
    mean_c = (c12 + c13 + c23) / 3
    stabs.append(mean_c)
    print(f"  dim {k + 1}: {mean_c:.4f}  {('✓ stable' if mean_c > 0.9 else '~ partial' if mean_c > 0.7 else '✗ unstable')}")
print(f'\n  Mean stability top-5: {np.mean(stabs):.4f}')
print(f"\n{'=' * 60}")
print(f'  TEST 2 LONG TEXT — FINAL SUMMARY')
print(f"{'=' * 60}")
print(f'\n  Tokens tested:          {len(H7)}\n  ln_f R² (test):         {r2_te:.4f}\n  Prediction accuracy:    {correct_norm / N:.1%}\n  Same-meaning ratio:     {np.mean(same_dists) / mean_rand:.4f}\n  Attractor dim (99%):    {dims_99}/{D}\n  Core stability top-5:   {np.mean(stabs):.4f}\n\n  DECISION CRITERIA:\n\n  ln_f R² approaching 1.000?\n    YES (>0.99): ln_f decompression = law. Proven.\n    NO  (<0.95): nonlinear component in ln_f. Law partial.\n    Trend: 0.37(20) → 0.805(375) → ?(now)\n    Direction tells us if law converges.\n\n  Same-meaning ratio < 0.65?\n    Already confirmed at 0.647 with short sentences.\n    Long sentences = stronger test.\n    If still < 0.65: semantic attractor is robust.\n\n  Core stability > 0.90 for top 3 dims?\n    Top 3 dims stable = coordinate axes are real.\n    Those axes = semantic coordinate system.\n    Unstable = noise not signal.\n')
print('=' * 60 + '\n')
