import os, json, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
KA = meta['KA']
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def arithmetic(step, length=50):
    return [i * step % VS for i in range(length)]

def fibonacci_variant(a, b, length=50):
    seq = [a % VS, b % VS]
    while len(seq) < length:
        seq.append((seq[-1] + seq[-2]) % VS)
    return seq

def geometric(base, length=50):
    seq = []
    val = 1
    for _ in range(length):
        seq.append(val % VS)
        val = val * base % VS
    return seq

def interleaved(step1, step2, length=50):
    seq = []
    a, b = (0, step1 % VS)
    for i in range(length):
        seq.append(a if i % 2 == 0 else b)
        if i % 2 == 0:
            a = (a + step1) % VS
        else:
            b = (b + step2) % VS
    return seq
patterns = []
for s in range(1, 31):
    patterns.append((f'arith_{s}', arithmetic(s)))
for a in range(1, 11):
    for b in range(a + 1, a + 4):
        patterns.append((f'fib_{a}_{b}', fibonacci_variant(a, b)))
for base in range(2, 17):
    patterns.append((f'geo_{base}', geometric(base)))
for s in range(1, 16):
    patterns.append((f'down_{s}', arithmetic(VS - s)))
pairs = [(1, 2), (1, 3), (2, 3), (2, 4), (3, 5), (1, 4), (2, 5), (3, 4), (4, 5), (1, 5), (2, 6), (3, 6), (4, 6), (5, 6), (1, 6), (3, 7), (4, 7), (5, 7), (2, 7), (1, 7)]
for s1, s2 in pairs:
    patterns.append((f'inter_{s1}_{s2}', interleaved(s1, s2)))
for s in range(1, 11):
    patterns.append((f'off_{s}_a', [(VS // 2 + i * s) % VS for i in range(50)]))
    patterns.append((f'off_{s}_b', [(VS // 3 + i * s) % VS for i in range(50)]))
for s in range(1, 11):
    seq = []
    v = 0
    for i in range(50):
        seq.append(v)
        v = (v + s * (1 if i % 4 < 2 else -1)) % VS
    patterns.append((f'zig_{s}', seq))
    seq2 = []
    v = VS // 2
    for i in range(50):
        seq2.append(v)
        v = (v + s * (1 if i % 4 < 2 else -1)) % VS
    patterns.append((f'zag_{s}', seq2))
for c in range(1, 11):
    patterns.append((f'quad_{c}', [(i * i + c * i) % VS for i in range(50)]))
names = [n for n, _ in patterns]
assert len(names) == len(set(names)), 'Duplicate pattern names'
print(f'Total unique patterns generated: {len(patterns)}')
patterns = patterns[:256]
MODEL_PATTERNS = [patterns[i * 8:(i + 1) * 8] for i in range(32)]
D = 16
H = 2
NL = 3

class SeqModel(nn.Module):

    def __init__(self, D, H, NL, K):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)

    def forward(self, ids):
        B, K = ids.shape
        x = self.wte(ids) + self.wpe(torch.arange(K, device=ids.device).unsqueeze(0))
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def build_data(patterns, K):
    Xs, Ys = ([], [])
    for name, seq in patterns:
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))

def score(model, patterns, K):
    model.eval()
    correct = 0
    for name, seq in patterns:
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        correct += p == seq[min(len(seq) - 1, K)]
    return correct
print('=' * 60)
print('  PHASE 1 — TRAINING 32 DONOR MODELS')
print(f'  D={D}, H={H}, NL={NL}')
print(f'  Each model: 8 unique patterns, 600 steps')
print('=' * 60)
t0 = time.time()
donor_scores = []
for i in range(32):
    path = os.path.join(_dir, f'donor_{i:02d}.npz')
    if os.path.exists(path):
        donor_scores.append(None)
        print(f'  Donor {i + 1:>2}/32: already exists, skipping', flush=True)
        continue
    patterns_i = MODEL_PATTERNS[i]
    torch.manual_seed(i)
    np.random.seed(i)
    model = SeqModel(D, H, NL, KA)
    for nm, p in model.named_parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
        else:
            nn.init.zeros_(p)
    X, Y = build_data(patterns_i, KA)
    opt = torch.optim.Adam(model.parameters(), lr=0.005)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=600, eta_min=0.0001)
    best_sc = 0
    best_state = None
    for step in range(1, 601):
        model.train()
        opt.zero_grad()
        loss_fn(model(X).view(-1, VS), Y.view(-1)).backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 100 == 0:
            sc = score(model, patterns_i, KA)
            if sc > best_sc:
                best_sc = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
    if best_state:
        model.load_state_dict(best_state)
    sc = score(model, patterns_i, KA)
    np.savez(path, **{k: v.detach().numpy() for k, v in model.state_dict().items()})
    donor_scores.append(sc)
    pat_names = [n for n, _ in patterns_i]
    print(f'  Donor {i + 1:>2}/32: {sc}/8  {pat_names}', flush=True)
print('\n  Scoring loaded donors...')
all_scores = []
for i in range(32):
    path = os.path.join(_dir, f'donor_{i:02d}.npz')
    data = np.load(path, allow_pickle=True)
    m = SeqModel(D, H, NL, KA)
    m.load_state_dict({k: torch.tensor(data[k]) for k in data.files})
    sc = score(m, MODEL_PATTERNS[i], KA)
    all_scores.append(sc)
print('\n' + '=' * 60)
print('  RESULTS')
print('=' * 60)
print(f"\n  {'Donor':>6}  {'Score':>6}  {'Patterns'}")
print(f"  {'─' * 55}")
for i, sc in enumerate(all_scores):
    names = [n for n, _ in MODEL_PATTERNS[i]]
    print(f'  {i + 1:>6}  {sc:>4}/8  {names}')
print(f'\n  Total donors:    32')
print(f'  Perfect (8/8):   {sum((s == 8 for s in all_scores))}/32')
print(f'  Mean score:      {np.mean(all_scores):.2f}/8')
print(f'  Total patterns:  {sum(all_scores)}/256')
print(f'  Time: {time.time() - t0:.1f}s')
print(f'\n  All .npz files saved to: {_dir}')
print('=' * 60)
