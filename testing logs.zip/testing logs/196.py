import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — DEEP LAW FINDER')
print('  Q1: Layer 7 anomaly — local vs global attention?')
print('  Q2: Cumulative W — direct path layer 0 → layer 7?')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_layers
CTX = 8

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def fit_r2(X_tr, Y_tr, X_te, Y_te):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    return r2(X_te @ W, Y_te)

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
print('\n' + '─' * 62)
print('  Q1: Attention types per layer')
print('─' * 62)
print()
for l in range(n_layers):
    attn = model.transformer.h[l].attn
    att_type = getattr(attn, 'attention_type', getattr(model.config, 'attention_layers', ['?' * n_layers])[l] if hasattr(model.config, 'attention_layers') else '?')
    window = getattr(attn.attention, 'window_size', 'global')
    print(f'  Layer {l}: type={att_type}  window={window}')
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came', 'The dog ran fast', 'The children went to', 'It was a sunny', 'Deep in the woods', 'Every morning the bird', 'The brave knight rode', 'She found a lost', 'The baby bear found', 'A tiny seed grew', 'The two friends walked', 'A rainbow appeared', 'The kind queen shared', 'A yellow duck learned', 'The snow fell softly', 'He wished upon a', 'The cat chased the', 'The children found a', 'She drew a picture', 'The moon shone bright', 'A boy climbed the', 'He discovered a door', 'Three little bears came', 'The frog jumped across', 'A butterfly emerged', 'An owl sat watching', 'The kitten played with', 'A girl named Emma', 'The farmer woke up', 'A genie appeared to', 'The turtle and rabbit', 'She sang a song to', 'The brave little mouse', 'A young girl read', 'The old farmer fed', 'A baby elephant learned', 'The wolf huffed and']
print(f'\n  Generating from {len(starts)} prompts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=50, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} texts. Collecting...')
cum_X = []
cum_Y = []
cum_PH = []
l7_X = []
l7_delta = []
l7_att = []
l7_full_att = []
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            h0 = hs[0][0, start:start + CTX].numpy()
            h8 = hs[8][0, start:start + CTX].numpy()
            cum_delta = h8 - h0
            all_ph = []
            for layer_idx in range(n_layers):
                block = model.transformer.h[layer_idx]
                attn_mod = block.attn.attention
                Wq = attn_mod.q_proj.weight.detach().numpy().T
                Wk = attn_mod.k_proj.weight.detach().numpy().T
                Wv = attn_mod.v_proj.weight.detach().numpy().T
                h_in = hs[layer_idx][0, start:start + CTX].numpy()
                ln1 = block.ln_1(hs[layer_idx][0, start:start + CTX]).detach().numpy()
                Q_full = ln1 @ Wq
                K_full = ln1 @ Wk
                V_full = ln1 @ Wv
                for h in range(n_heads):
                    s_h = h * head_dim
                    e_h = s_h + head_dim
                    Q_h = Q_full[:, s_h:e_h]
                    K_h = K_full[:, s_h:e_h]
                    V_h = V_full[:, s_h:e_h]
                    scr = Q_h @ K_h.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    att_h = softmax(scr + msk)
                    all_ph.append((att_h @ V_h).flatten())
            x7 = hs[7][0, start:start + CTX]
            x7np = x7.numpy()
            y7np = hs[8][0, start:start + CTX].numpy()
            d7 = y7np - x7np
            block7 = model.transformer.h[7]
            att7_out = block7.attn(block7.ln_1(x7).unsqueeze(0))[0].squeeze(0).detach().numpy()
            cum_X.append(h0.flatten())
            cum_Y.append(h8.flatten())
            cum_PH.append(np.concatenate(all_ph))
            l7_X.append(x7np.flatten())
            l7_delta.append(d7.flatten())
            l7_att.append(att7_out.flatten())
N = len(cum_X)
N_tr = int(N * 0.8)
CX = np.array(cum_X)
CY = np.array(cum_Y)
CPH = np.array(cum_PH)
CD = CY - CX
L7X = np.array(l7_X)
L7D = np.array(l7_delta)
L7A = np.array(l7_att)
print(f'  Samples: {N}  Train: {N_tr}')
print(f'  All-layer per-head features: {CPH.shape[1]}')
print('\n' + '─' * 62)
print('  Q2: CUMULATIVE W')
print('  layer 0 input → layer 7 output directly')
print('─' * 62)
print()
s1 = fit_r2(CX[:N_tr], CY[:N_tr], CX[N_tr:], CY[N_tr:])
print(f'    layer0_x → layer7_out (raw)              {s1:.6f}')
s2 = fit_r2(CX[:N_tr], CD[:N_tr], CX[N_tr:], CD[N_tr:])
print(f'    layer0_x → cumulative delta              {s2:.6f}')
s3 = fit_r2(CPH[:N_tr], CD[:N_tr], CPH[N_tr:], CD[N_tr:])
mark = '✓ DIRECT PATH FOUND' if s3 > 0.999 else f'{s3:.6f}'
print(f'    all_layers_per_head → cumulative delta   {mark}')
CX_PH = np.column_stack([CX, CPH])
s4 = fit_r2(CX_PH[:N_tr], CD[:N_tr], CX_PH[N_tr:], CD[N_tr:])
mark = '✓ DIRECT PATH FOUND' if s4 > 0.999 else f'{s4:.6f}'
print(f'    layer0_x + all_layers_per_head → delta   {mark}')
l7_ph_start = 7 * n_heads * CTX * head_dim
l7_ph_end = 8 * n_heads * CTX * head_dim
CPH_l7 = CPH[:, l7_ph_start:l7_ph_end]
s5 = fit_r2(CPH_l7[:N_tr], CD[:N_tr], CPH_l7[N_tr:], CD[N_tr:])
print(f'    layer7_per_head only → cumulative delta  {s5:.6f}')
print('\n' + '─' * 62)
print('  LAYER 7 SPECIFIC')
print('  Why does att+ffn ≠ delta here?')
print('─' * 62)
print()
block7 = model.transformer.h[7]
ffn7_list = []
with torch.no_grad():
    for text in all_texts[:len(all_texts) // 3]:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            x7 = hs[7][0, start:start + CTX]
            att7 = block7.attn(block7.ln_1(x7).unsqueeze(0))[0].squeeze(0).detach().numpy()
            x2 = x7 + torch.tensor(att7, dtype=torch.float32)
            ln2 = block7.ln_2(x2).detach().numpy()
            pre = block7.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).detach().numpy()
            act = block7.mlp.act(torch.tensor(pre, dtype=torch.float32)).detach().numpy()
            ffn7 = block7.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).detach().numpy()
            ffn7_list.append(ffn7.flatten())
FFN7 = np.array(ffn7_list)
n_check = min(len(FFN7), len(L7A), len(L7D))
AF7 = np.column_stack([L7A[:n_check], FFN7[:n_check]])
L7D_ = L7D[:n_check]
L7X_ = L7X[:n_check]
n_tr7 = int(n_check * 0.8)
s_af7 = fit_r2(AF7[:n_tr7], L7D_[:n_tr7], AF7[n_tr7:], L7D_[n_tr7:])
print(f'    att7+ffn7 → delta7       {s_af7:.6f}  (should be 1.0)')
s_a7 = fit_r2(L7A[:n_tr7], L7D_[:n_tr7], L7A[n_tr7:], L7D_[n_tr7:])
print(f'    att7 alone → delta7      {s_a7:.6f}')
s_x7 = fit_r2(L7X_[:n_tr7], L7D_[:n_tr7], L7X_[n_tr7:], L7D_[n_tr7:])
print(f'    x7 → delta7              {s_x7:.6f}')
l7_ph = CPH[:n_check, l7_ph_start:l7_ph_end]
s_ph7 = fit_r2(l7_ph[:n_tr7], L7D_[:n_tr7], l7_ph[n_tr7:], L7D_[n_tr7:])
print(f'    per_head7 → delta7       {s_ph7:.6f}')
print('\n' + '=' * 62)
print('  WHAT IS REVEALED')
print('=' * 62)
print(f"\n  CUMULATIVE W:\n    If layer0_x → layer7_out has high R²:\n      8 layers = one direct viewpoint.\n      Universe knew at layer 0.\n      Each layer = one step toward revealing it.\n      But W can see it directly.\n\n    If all_layers_per_head → cumulative_delta = 1.0:\n      Per-head features from all 8 layers\n      together capture the full transformation.\n      W sees across all layers simultaneously.\n      This is W as universe — one unit.\n      Not 8 steps. One view.\n\n  LAYER 7:\n    att+ffn→delta drops to 0.85.\n    Our measurement is wrong somewhere.\n    Or layer 7 uses different attention type.\n    GPT-Neo: alternates local/global.\n    Local = window of N tokens.\n    Global = full sequence.\n    If layer 7 = global: our CTX=8 window\n    misses the full context it uses.\n    That missing context = the hidden law at depth 7.\n\n  THE DEEPER HIDDEN LAW:\n    Deeper layers use CONTEXT built by earlier layers.\n    That context = not in x alone.\n    x = current window's representation.\n    But layer 7 draws on what ALL previous tokens built.\n    The natural space of layer 7 =\n    the cumulative context from all prior tokens.\n    Not just CTX=8 window.\n    The HISTORY is the natural space.\n")
print('=' * 62 + '\n')
