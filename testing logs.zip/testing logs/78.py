import numpy as np, math, time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v22 — CONTEXT MEAN + LAYERED RESIDUALS')
print('  x = mean(WTE[t-K..t-1]). Each layer targets remaining gap.')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
D = 16
K = 6
L = 3
D_quad = D * (D + 1) // 2
print(f'\n  Vocab={VS} Tokens={N} D={D} K={K} L={L}')
print(f'  D_quad={D_quad}  N/D_quad={N // D_quad}x')
np.random.seed(42)
co = np.zeros((VS, VS))
for i in range(len(toks) - 1):
    co[toks[i], toks[i + 1]] += 1
U_e, S_e, _ = np.linalg.svd(co + 0.1)
WTE_raw = U_e[:, :D] * np.sqrt(S_e[:D])
WTE = (WTE_raw - WTE_raw.mean(0)) / (WTE_raw.std(0) + 1e-05)
tri_i, tri_j = np.triu_indices(D)

def phi(x):
    return x[tri_i] * x[tri_j]

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def pinv_solve(Phi, R):
    U, S, Vt = np.linalg.svd(Phi, full_matrices=False)
    thresh = S[0] * 1e-10
    mask = S > thresh
    Si = np.where(mask, 1.0 / np.where(mask, S, 1.0), 0.0)
    return Vt.T @ np.diag(Si) @ U.T @ R
print(f'  Building context states X0 (mean of K={K} prev tokens)...', end=' ')
M = N - K
X0 = np.zeros((M, D), dtype=np.float64)
for i in range(K, N):
    X0[i - K] = WTE[toks[i - K:i]].mean(0)
targets = np.array(toks[K:])
T = WTE[targets]
print(f'done  X0:{X0.shape}  T:{T.shape}')
W_layers = [np.zeros((D_quad, D)) for _ in range(L)]

def forward_batch(X, W_layers):
    xs = [X.copy()]
    for W in W_layers:
        Phi = phi_b(xs[-1])
        xs.append(xs[-1] + Phi @ W)
    return xs

def calc_ppl(xs_final):
    x = xs_final[-1]
    nll = 0.0
    ne = 0
    for i in range(M):
        lg = x[i] @ WTE.T
        lg -= lg.max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[targets[i]]
        ne += 1
    return math.exp(min(nll / ne, 500))
ppl0 = calc_ppl(forward_batch(X0, W_layers))
print(f'\n  Initial ppl={ppl0:.2f} (zero layers, x=context_mean)')
print(f'\n  Coordinate descent:')
print(f"  {'Rnd':>4} {'L':>3} {'ppl':>10}  res_before → res_after")
print(f"  {'─' * 50}")
best_ppl = ppl0
best_W = [w.copy() for w in W_layers]
for rnd in range(6):
    improved = False
    for l in range(L):
        xs = forward_batch(X0, W_layers)
        x_l = xs[l]
        R = T - x_l
        res_before = np.mean(np.linalg.norm(R, axis=1))
        Phi = phi_b(x_l)
        W_new = pinv_solve(Phi, R)
        res_after = np.mean(np.linalg.norm(R - Phi @ W_new, axis=1))
        W_try = [w.copy() for w in W_layers]
        W_try[l] = W_new
        xs_try = forward_batch(X0, W_try)
        ppl_new = calc_ppl(xs_try)
        mark = '★' if ppl_new < best_ppl else ' '
        print(f'  {rnd + 1:>4} {l:>3} {ppl_new:>10.2f}  {res_before:.4f} → {res_after:.4f} {mark}')
        if ppl_new < best_ppl:
            best_ppl = ppl_new
            W_layers = W_try
            best_W = [w.copy() for w in W_try]
            improved = True
    if not improved:
        print(f'  Round {rnd + 1}: converged.')
        break
W_layers = best_W
print(f'\n  Final ppl={best_ppl:.2f}  ratio={best_ppl / VS:.3f}')
xs = forward_batch(X0, W_layers)
print(f'\n  RESIDUAL ANALYSIS:')
for l in range(L):
    r0 = np.mean(np.linalg.norm(T - xs[l], axis=1))
    r1 = np.mean(np.linalg.norm(T - xs[l + 1], axis=1))
    print(f'  Layer {l}: {r0:.4f} → {r1:.4f}  (reduced {r0 - r1:.4f})')

def forward_ctx(ids):
    ctx = list(ids[-K:]) if len(ids) >= K else [0] * (K - len(ids)) + list(ids)
    x = WTE[ctx].mean(0).copy()
    for W in W_layers:
        x = x + phi(x) @ W
    return x @ WTE.T

def sample(lg, temp=0.8, top_k=10):
    lg = lg - lg.max()
    lg = lg / temp
    if top_k < len(lg):
        thresh = np.sort(lg)[-top_k]
        lg[lg < thresh] = -10000000000.0
    p = np.exp(lg)
    p /= p.sum()
    return int(np.random.choice(VS, p=p))

def generate(prompt, n=150, temp=0.8, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        lg = forward_ctx(ids)
        if not np.all(np.isfinite(lg)):
            break
        ids.append(sample(lg, temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  BIGRAM CHECK (last 1 char, K={K} context):')
for prev in ['t', 'h', 'e', ' ', 'a', 'n']:
    if prev not in c2i:
        continue
    lg = forward_ctx([c2i[prev]])
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{prev}': {top3}")
print(f'\n  TRIGRAM CHECK:')
for bg in ['th', 'he', 'in', 'an']:
    cs = [c2i[c] for c in bg if c in c2i]
    if len(cs) < 2:
        continue
    lg = forward_ctx(cs)
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{bg}': {top3}")
print(f'\n  GENERATION (temp=0.8):')
for p in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(p)
    print(f"  '{p}'")
    print(f'    {out[len(p):][:70]}')
gs = generate('the ', n=300, temp=0.9)
sp = 100 * gs[4:].count(' ') / len(gs[4:])
cnt = Counter(gs[4:])
top5 = [(c, f'{100 * cnt[c] // len(gs[4:])}%') for c, _ in cnt.most_common(5)]
print(f'\n  Space%={sp:.0f}%  Top-5:{top5}')
print(f'  Sample: {gs[4:80]}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  ppl={best_ppl:.2f}  ratio={best_ppl / VS:.3f}  vocab={VS}')
print(f'\n  WHAT CHANGED v21→v22:')
print(f'    x_0 = mean(WTE[t-K..t-1])  ← K-token context (breaks loops)')
print(f'    R_l = WTE[next] - x_l_current  ← remaining residual per layer')
print(f'    Each layer targets what previous layers left undone.')
print('=' * 65 + '\n')
