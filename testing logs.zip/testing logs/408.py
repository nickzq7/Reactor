import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'EleutherAI/pythia-160m'
print(f'Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
n_layers = model.config.num_hidden_layers
print(f'D={D} Heads={n_heads} Layers={n_layers}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2(X, Y, split=0.8):
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X.astype(np.float32), np.ones(n, np.float32)]
    W = np.linalg.lstsq(Xb[:s], Y[:s].astype(np.float32), rcond=None)[0]
    return r2(Xb[s:] @ W, Y[s:].astype(np.float32))
seeds = ['Once upon a time', 'The scientist looked', 'In a distant future', 'The old library held', 'A young programmer', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed through', 'A dog sat quietly', 'She found the key', 'The storm was coming', 'The teacher explained', 'A bird flew over', 'He picked up the phone', 'The car stopped suddenly']
print(f'Generating {len(seeds) * 5} texts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(5):
            torch.manual_seed(i * 50 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=0.8 + j * 0.05, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(all_texts)} texts.')
test_layers = [0, 2, 5, 8, 11]
store = {l: {'gelu': [], 'ffn': [], 'concat': [], 'att': []} for l in test_layers}
hooks = []
for li in test_layers:
    b = model.gpt_neox.layers[li]

    def make(l):

        def hg(m, i, o):
            store[l]['gelu'].append(o.detach().float().numpy())

        def hf(m, i, o):
            store[l]['ffn'].append(o.detach().float().numpy())

        def hc(m, i, o):
            store[l]['concat'].append(i[0].detach().float().numpy())

        def ha(m, i, o):
            store[l]['att'].append(o[0].detach().float().numpy())
        return (hg, hf, hc, ha)
    hg, hf, hc, ha = make(li)
    hooks += [b.mlp.act.register_forward_hook(hg), b.mlp.dense_4h_to_h.register_forward_hook(hf), b.attention.dense.register_forward_hook(hc), b.attention.dense.register_forward_hook(ha)]
print(f'Running {len(all_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(all_texts):
        if i % 20 == 0:
            print(f'  {i}/{len(all_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
print(f"\n{'=' * 65}")
print(f'  PYTHIA-160M LAWS')
print(f"{'=' * 65}")
print(f"  {'Layer':<6} {'gelu→ffn':<12} {'N':<8} {'ratio':<8} {'concat→att'}")
print(f"  {'─' * 55}")
for li in test_layers:
    s = store[li]
    G = np.concatenate(s['gelu']).astype(np.float32)
    F = np.concatenate(s['ffn']).astype(np.float32)
    C = np.concatenate(s['concat']).astype(np.float32)
    A = np.concatenate(s['att']).astype(np.float32)
    ratio = len(G) / G.shape[1]
    r_ffn = fit_r2(G, F)
    r_att = fit_r2(C, A)

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {li:<6} {f(r_ffn):<12} {len(G):<8} {ratio:<8.1f} {f(r_att)}')
print(f'\n  concat→att = Wo multiply. Always 1.000 if hooks correct.')
print(f'  gelu→ffn needs ratio>3 for 1.000. ratio=N/FFN_dim(3072).')
print(f"{'=' * 65}")
