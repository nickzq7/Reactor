import numpy as np, math
print('\n' + '=' * 55)
print('  W-KERNEL NUMBERS v2 — ORTHOGONAL WTE')
print('=' * 55)
N_seq = 2000
VS = 100
K = 4
D = 32
L = 3
toks = np.array([i % VS for i in range(N_seq)])
M = N_seq - K
y = toks[K:]
angles = np.array([2 * math.pi * i / VS for i in range(VS)])
WTE_cos = np.zeros((VS, D))
for d in range(D // 2):
    WTE_cos[:, 2 * d] = np.cos((d + 1) * angles)
    WTE_cos[:, 2 * d + 1] = np.sin((d + 1) * angles)
WTE_cos /= np.linalg.norm(WTE_cos, axis=1, keepdims=True) + 1e-08
np.random.seed(42)
R = np.random.randn(VS, D)
WTE_orth = R / np.linalg.norm(R, axis=1, keepdims=True)
print(f'\n  WTE similarity check (want low for non-adjacent):')
print(f'  cos/sin:  [5]@[6]={WTE_cos[5] @ WTE_cos[6]:.3f}  [0]@[50]={WTE_cos[0] @ WTE_cos[50]:.3f}')
print(f'  random:   [5]@[6]={WTE_orth[5] @ WTE_orth[6]:.3f}  [0]@[50]={WTE_orth[0] @ WTE_orth[50]:.3f}')
tri_i, tri_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]
D_q = D * (D + 1) // 2

def pinv_solve(Ph, R):
    U, S, Vt = np.linalg.svd(Ph, full_matrices=False)
    m = S > S[0] * 1e-10
    Si = np.where(m, 1.0 / np.where(m, S, 1.0), 0.0)
    return Vt.T @ np.diag(Si) @ U.T @ R

def run_test(WTE, label):
    X0 = np.zeros((M, D))
    for i in range(K, N_seq):
        X0[i - K] = WTE[toks[i - K:i]].mean(0)
    T = WTE[y]
    W_layers = [np.zeros((D_q, D)) for _ in range(L)]

    def fwd(X, Wl):
        xs = [X.copy()]
        for W in Wl:
            xs.append(xs[-1] + phi_b(xs[-1]) @ W)
        return xs

    def ppl_acc(Wl):
        x = fwd(X0, Wl)[-1]
        lg = x @ WTE.T
        preds = np.argmax(lg, 1)
        acc = 100 * np.mean(preds == y)
        nll = sum((-(lambda l: l - np.log(np.sum(np.exp(l))))(lg[i] - lg[i].max())[y[i]] for i in range(M)))
        return (math.exp(min(nll / M, 500)), acc)
    best_p, _ = ppl_acc(W_layers)
    best_W = [w.copy() for w in W_layers]
    for rnd in range(6):
        imp = False
        for l in range(L):
            xs = fwd(X0, W_layers)
            x_l = xs[l]
            R = T - x_l
            Wn = pinv_solve(phi_b(x_l), R)
            Wt = [w.copy() for w in W_layers]
            Wt[l] = Wn
            p, a = ppl_acc(Wt)
            if p < best_p:
                best_p = p
                W_layers = Wt
                best_W = [w.copy() for w in Wt]
                imp = True
        if not imp:
            break
    W_layers = best_W
    fp, fa = ppl_acc(W_layers)
    preds_str = []
    for ctx in [[3, 4, 5, 6], [97, 98, 99, 0]]:
        x = WTE[ctx].mean(0).copy()
        for W in W_layers:
            x = x + phi(x) @ W
        lg = x @ WTE.T
        lg -= lg.max()
        p = np.exp(lg)
        p /= p.sum()
        pred = int(np.argmax(p))
        conf = p[pred]
        true = (ctx[-1] + 1) % VS
        preds_str.append(f"  {ctx}→{pred}({100 * conf:.0f}%) true={true} {('✓' if pred == true else '✗')}")
    print(f'\n  [{label}]')
    print(f'  ppl={fp:.2f}  acc={fa:.1f}%  vocab={VS}')
    for s in preds_str:
        print(s)
    return (fp, fa)
p1, a1 = run_test(WTE_cos, 'circular cos/sin WTE (old)')
p2, a2 = run_test(WTE_orth, 'random orthogonal WTE (new)')
print(f"\n{'=' * 55}")
print(f'  COMPARISON:')
print(f'  cos/sin WTE:  ppl={p1:.2f}  acc={a1:.1f}%')
print(f'  random WTE:   ppl={p2:.2f}  acc={a2:.1f}%')
print(f'\n  If random WTE gives ppl<<cos WTE with same acc=100%:')
print(f'  → WTE orthogonality = the key missing ingredient.')
print(f'  → Apply to language: VS=28, D=28, QR-orthogonal WTE.')
print('=' * 55 + '\n')
