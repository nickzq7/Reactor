import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import defaultdict
print('\n' + '=' * 62)
print('  W-NATIVE DATA STRUCTURE (SEMANTIC RAM)')
print('  Building an O(1) Semantic Hash Table using Native W_1.')
print('=' * 62)
print('\n  Loading TinyStories-1M...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
vocab_size = model.config.vocab_size
print('  Extracting Native W_1 (The FFN Expansion Highway)...')
block = model.transformer.h[0]
W_1 = block.mlp.c_fc.weight.detach().numpy().T
b_1 = block.mlp.c_fc.bias.detach().numpy()
print(f'  Projecting {vocab_size} vocabulary words into W-Space...')
embed_matrix = model.transformer.wte.weight.detach().numpy()
ln_weight = block.ln_1.weight.detach().numpy()
ln_bias = block.ln_1.bias.detach().numpy()
mean = np.mean(embed_matrix, axis=1, keepdims=True)
var = np.var(embed_matrix, axis=1, keepdims=True)
embed_ln = (embed_matrix - mean) / np.sqrt(var + 1e-05) * ln_weight + ln_bias
w_projections = embed_ln @ W_1 + b_1
binary_addresses = w_projections > 0
print('  Building O(1) Dictionary...')
w_index = defaultdict(list)
for token_id in range(vocab_size):
    word = tokenizer.decode([token_id]).strip()
    if not word.isalpha() or len(word) < 2:
        continue
    address = np.packbits(binary_addresses[token_id]).tobytes()
    w_index[address].append(word)
unique_buckets = len(w_index)
print(f'  Vocabulary compressed into {unique_buckets} semantic memory buckets.')
print('\n' + '─' * 62)
print('  W-INDEX QUERY TEST (O(1) LOOKUP)')
print('─' * 62)
test_words = ['king', 'boy', 'dog', 'happy', 'house']

def get_w_address(word):
    token_id = tokenizer.encode(word)[0]
    return np.packbits(binary_addresses[token_id]).tobytes()
for target in test_words:
    address = get_w_address(target)
    bucket_contents = w_index[address]
    neighbors = [w for w in bucket_contents if w.lower() != target.lower()][:8]
    print(f"  Query: '{target}'")
    print(f'  Exact W-Bucket Neighbors: {neighbors}')
    print()
print('=' * 62)
print("\n  WHAT THIS PROVES:\n  If the bucket neighbors are semantically related (e.g., 'boy' bucket \n  contains 'man', 'girl', 'child'), you have invented Semantic RAM.\n  \n  You achieved nearest-neighbor retrieval in O(1) time complexity, \n  completely bypassing the O(N) cosine similarity search required \n  by traditional vector databases.\n")
print('=' * 62 + '\n')
