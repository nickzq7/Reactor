import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W KERNEL — CORRECT SPACE')
print('  token_sequence → next_token_distribution')
print('  No hidden states. No embeddings. Direct.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
vocab = model.config.vocab_size
D = model.config.hidden_size
n_layers = model.config.num_layers
model_mem = sum((p.numel() * p.element_size() for p in model.parameters()))
print(f'  Loaded. {n_layers} layers. Vocab={vocab:,}. {model_mem / 1024 / 1024:.1f}MB.')

def softmax(x):
    e = np.exp(x - x.max())
    return e / e.sum()
CONTEXT = 4
print(f'\n  Collecting model knowledge...')
print(f'  Format: token_ids[t-{CONTEXT}:t] → P(next_token)')
print(f"  This IS the model's knowledge. Direct.")
sentences = []
openings = ['Once upon a time there was', 'One day a little girl named', 'There was a small boy who', 'In a big forest there lived', 'A long time ago there was', 'There once was a friendly dog', 'A little bunny named Lily', 'Tom was a happy boy who', 'The sun was shining and', 'One morning Emma woke up and']
print(f'  Generating training sentences from model...')
generated_sents = []
for opening in openings:
    inp = tokenizer.encode(opening, return_tensors='pt')
    for temp_seed in range(5):
        torch.manual_seed(temp_seed)
        with torch.no_grad():
            out = model.generate(inp, max_new_tokens=40, do_sample=True, temperature=0.8, pad_token_id=tokenizer.eos_token_id)
        text = tokenizer.decode(out[0], skip_special_tokens=True)
        generated_sents.append(text)
fixed_sents = ['once upon a time there was a little girl named lily', 'the dog ran fast through the green field near home', 'a boy found a red ball near the big river today', 'the cat sat on the warm mat beside the fire', 'she picked flowers and smiled at her mother warmly', 'he walked slowly down the quiet road in the rain', 'the bird flew high above the tall trees at dawn', 'a small fish swam in the clear blue lake alone', 'the children played happily together in the sunny yard', 'the old man sat quietly under the big oak tree', 'she opened the door and looked outside at the snow', 'he found a little puppy sleeping near the old house', 'the sun rose slowly over the distant green hills today', 'a rabbit jumped quickly and hid deep in the bushes', 'the little boy cried and ran fast to his mother', 'she baked warm cookies for all the happy children', 'the moon shone bright and clear over the quiet town', 'a dragon lived deep inside the cold and dark cave', 'the princess waited alone in the tall grey stone tower', 'he climbed the tall tree to find his lost kite', 'the brave knight rode his horse into the dark forest', 'a young fox carefully learned to hunt from his mother', 'the flowers bloomed bright and beautiful in the spring sun', 'the little prince lived alone on a very small planet', 'a kind fairy granted three wishes to the poor farmer', 'the young knight saved the princess from the dark tower', 'a little seed grew into a tall and beautiful flower', 'the old wizard taught the boy how to use magic', 'she found a lost kitten crying in the cold rain', 'the two friends walked together through the enchanted forest']
all_sents = generated_sents + fixed_sents
print(f'  Total sentences: {len(all_sents)}')
knowledge = {}
counts = {}
with torch.no_grad():
    for sent in all_sents:
        tokens = tokenizer(sent, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids'][0]
        seq = len(ids)
        if seq < CONTEXT + 1:
            continue
        out = model(**tokens)
        logits = out.logits[0].numpy()
        for pos in range(CONTEXT, seq):
            ctx = tuple(ids[pos - CONTEXT:pos].tolist())
            dist = softmax(logits[pos - 1])
            if ctx not in knowledge:
                knowledge[ctx] = np.zeros(vocab)
                counts[ctx] = 0
            knowledge[ctx] += dist
            counts[ctx] += 1
for ctx in knowledge:
    knowledge[ctx] /= counts[ctx]
n_patterns = len(knowledge)
print(f'\n  Unique {CONTEXT}-gram patterns learned : {n_patterns:,}')
TOP_K = 20
compressed = {}
for ctx, dist in knowledge.items():
    top_idx = np.argsort(dist)[-TOP_K:]
    top_prob = dist[top_idx]
    top_prob /= top_prob.sum()
    compressed[ctx] = (top_idx, top_prob)
kernel_mem_bytes = n_patterns * (CONTEXT * 4 + TOP_K * 4 + TOP_K * 4)
print(f'  Top-K per pattern        : {TOP_K}')
print(f'  W kernel memory          : {kernel_mem_bytes / 1024:.1f} KB')
print(f'  Model memory             : {model_mem / 1024 / 1024:.1f} MB')
print(f'  Compression              : {model_mem * 1024 / kernel_mem_bytes:.0f}x')

def w_kernel_next(context_ids):
    ctx = tuple(context_ids[-CONTEXT:])
    if ctx in compressed:
        idx, prob = compressed[ctx]
        return (idx, prob)
    for c in range(CONTEXT - 1, 0, -1):
        short = tuple(context_ids[-c:])
        matches = [(k, v) for k, v in compressed.items() if k[-c:] == short]
        if matches:
            all_idx = np.concatenate([v[0] for k, v in matches])
            all_prob = np.concatenate([v[1] for k, v in matches])
            idx_uniq, inv = np.unique(all_idx, return_inverse=True)
            prob_sum = np.zeros(len(idx_uniq))
            np.add.at(prob_sum, inv, all_prob)
            prob_sum /= prob_sum.sum()
            return (idx_uniq, prob_sum)
    all_firsts = np.array(list(set((k[0] for k in compressed.keys()))))
    prob = np.ones(len(all_firsts)) / len(all_firsts)
    return (all_firsts, prob)

def w_kernel_generate(prompt, max_new_tokens=50, greedy=True):
    ids = tokenizer.encode(prompt)
    for _ in range(max_new_tokens):
        if len(ids) < CONTEXT:
            ctx = [0] * (CONTEXT - len(ids)) + ids
        else:
            ctx = ids[-CONTEXT:]
        idx, prob = w_kernel_next(ctx)
        if greedy:
            next_tok = int(idx[np.argmax(prob)])
        else:
            next_tok = int(np.random.choice(idx, p=prob))
        if next_tok == tokenizer.eos_token_id:
            break
        ids.append(next_tok)
    return tokenizer.decode(ids, skip_special_tokens=True)

def original_generate(prompt, max_new_tokens=50):
    inp = tokenizer.encode(prompt, return_tensors='pt')
    with torch.no_grad():
        out = model.generate(inp, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def wrap(text, width=56):
    words = text.split()
    lines = []
    line = '  '
    for w in words:
        if len(line) + len(w) > width:
            lines.append(line)
            line = '  ' + w + ' '
        else:
            line += w + ' '
    if line.strip():
        lines.append(line)
    return '\n'.join(lines)
print('\n' + '-' * 62)
print('  COVERAGE TEST')
print('  How much does kernel know about test prompts?')
print('-' * 62)
test_prompts = ['Once upon a time there was a little girl', 'The dog ran to the park and', 'A boy named Tom found a magic', 'The princess looked out the window and', 'One day a small rabbit decided to']
for prompt in test_prompts:
    ids = tokenizer.encode(prompt)
    hits = 0
    for i in range(CONTEXT, len(ids)):
        ctx = tuple(ids[i - CONTEXT:i])
        if ctx in compressed:
            hits += 1
    total = max(len(ids) - CONTEXT, 1)
    print(f'  "{prompt[:35]}..."  coverage: {hits}/{total} = {hits / total * 100:.0f}%')
print('\n' + '=' * 62)
print('  SIDE BY SIDE GENERATION')
print(f'  Original: {model_mem / 1024 / 1024:.1f}MB model, full forward pass')
print(f'  W kernel: {kernel_mem_bytes / 1024:.1f}KB lookup table, no model')
print('=' * 62)
for i, prompt in enumerate(test_prompts):
    print(f"\n  {'─' * 58}")
    print(f'  PROMPT {i + 1}: "{prompt}"')
    print(f"  {'─' * 58}")
    orig = original_generate(prompt, 40)
    kern_g = w_kernel_generate(prompt, 40, greedy=True)
    kern_s = w_kernel_generate(prompt, 40, greedy=False)
    print(f'\n  ORIGINAL ({model_mem / 1024 / 1024:.1f}MB, 8 layers):')
    print(wrap(orig))
    print(f'\n  W KERNEL greedy ({kernel_mem_bytes / 1024:.1f}KB, 0 layers):')
    print(wrap(kern_g))
    print(f'\n  W KERNEL sample ({kernel_mem_bytes / 1024:.1f}KB, 0 layers):')
    print(wrap(kern_s))

    def real_word_frac(text):
        words = text.split()
        vocab_set = set(tokenizer.get_vocab().keys())
        real = sum((1 for w in words if w.lower().strip('.,!?"\'') in vocab_set))
        return real / max(len(words), 1)
    print(f'\n  Coherence (original) : {real_word_frac(orig) * 100:.0f}%')
    print(f'  Coherence (W kernel) : {real_word_frac(kern_g) * 100:.0f}%')
print('\n' + '=' * 62)
print('  WHAT THIS TEST REVEALS')
print('=' * 62)
print(f"\n  Previous flaw (now fixed):\n    We extracted from hidden state space.\n    Hidden states are intermediate.\n    Not the model's actual knowledge.\n    Test distribution ≠ generation distribution.\n    Failed every time.\n\n  This approach:\n    Extract directly from token space.\n    Context tokens → next token distribution.\n    THIS is the model's actual knowledge.\n    Same space during extraction and generation.\n    No distribution mismatch.\n\n  W kernel is:\n    {n_patterns} patterns × top-{TOP_K} distributions\n    = {kernel_mem_bytes / 1024:.1f} KB total\n    vs {model_mem / 1024 / 1024:.1f} MB model\n    = {model_mem * 1024 / kernel_mem_bytes:.0f}x compression\n\n  The question:\n    Does text above make sense?\n    If yes — W principle confirmed for generation.\n    If partial — need more training sentences.\n    If no — coverage is too low, need more data.\n\n  Coverage determines quality.\n  More sentences → more patterns → better generation.\n  This is the correct path.\n  Hidden states were the wrong path.\n")
print('=' * 62 + '\n')
