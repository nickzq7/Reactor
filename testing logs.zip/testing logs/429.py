import numpy as np
import torch
import os
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
vocab = model.config.vocab_size
print(f'D={D}  Layers={n_layers}  Vocab={vocab}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_T(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    T = np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0]
    return T.astype(np.float32)
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at', 'The wind was cold', 'A little rabbit hopped', 'The brave knight rode', 'She woke up and', 'He could not find', 'The magic door opened', 'They walked together through', 'The small house had', 'A star fell from', 'He whispered to her']
print(f'\nGenerating {len(seeds) * 6} training texts...')
train_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(6):
            torch.manual_seed(i * 60 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=45, do_sample=True, temperature=0.8 + j * 0.04, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(train_texts)} texts.')
layer_inputs = {l: [] for l in range(n_layers)}

def make_input_hook(l):

    def hook(m, inp, out):
        x = inp[0].detach().float()
        for t in range(x.shape[1]):
            layer_inputs[l].append(x[0, t].numpy().copy())
    return hook
hooks = []
for li in range(n_layers):
    hooks.append(model.transformer.h[li].register_forward_hook(make_input_hook(li)))
final_inputs = []

def hook_final(m, inp, out):
    x = inp[0].detach().float()
    for t in range(x.shape[1]):
        final_inputs.append(x[0, t].numpy().copy())
hooks.append(model.transformer.ln_f.register_forward_hook(hook_final))
print(f'Running {len(train_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(train_texts):
        if i % 40 == 0:
            print(f'  {i}/{len(train_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
H_in = []
H_out = []
for l in range(n_layers):
    hl = np.array(layer_inputs[l], dtype=np.float32)
    if l < n_layers - 1:
        hl1 = np.array(layer_inputs[l + 1], dtype=np.float32)
    else:
        hl1 = np.array(final_inputs, dtype=np.float32)
    H_in.append(hl)
    H_out.append(hl1)
H_in = np.concatenate(H_in, axis=0)
H_out = np.concatenate(H_out, axis=0)
print(f'\nTransition pairs: {H_in.shape}  (8 × N_tokens)')
print(f'\nPer-layer R² (is T universal across layers?):')
print(f"  {'Layer':<8} {'N':<8} {'R² h_l→h_l+1'}")
print(f"  {'─' * 35}")
for l in range(n_layers):
    hl = np.array(layer_inputs[l], dtype=np.float32)
    if l < n_layers - 1:
        hl1 = np.array(layer_inputs[l + 1], dtype=np.float32)
    else:
        hl1 = np.array(final_inputs, dtype=np.float32)
    n = len(hl)
    s = int(n * 0.8)
    T_l = fit_T(hl[:s], hl1[:s])
    Xb = np.c_[hl, np.ones(n)]
    rv = r2(Xb[s:] @ T_l, hl1[s:])
    print(f'  {l:<8} {n:<8} {rv:.4f}')
print(f'\nFitting universal T on all {len(H_in)} transition pairs...')
n = len(H_in)
s = int(n * 0.8)
T_univ = fit_T(H_in[:s], H_out[:s])
Xb = np.c_[H_in, np.ones(n, dtype=np.float32)]
r2_train = r2(Xb[:s] @ T_univ, H_out[:s])
r2_test = r2(Xb[s:] @ T_univ, H_out[s:])
print(f'  Universal T R² train: {r2_train:.4f}')
print(f'  Universal T R² test:  {r2_test:.4f}')
print(f'  T shape: {T_univ.shape}')
tpath = 'w_kernel_T.npz'
np.savez(tpath, T=T_univ, lm_head=model.lm_head.weight.detach().float().numpy(), wte=model.transformer.wte.weight.detach().float().numpy(), wpe=model.transformer.wpe.weight.detach().float().numpy(), ln_f_w=model.transformer.ln_f.weight.detach().float().numpy(), ln_f_b=model.transformer.ln_f.bias.detach().float().numpy())
size_kb = os.path.getsize(tpath) / 1024
print(f'\n  T saved: {tpath} ({size_kb:.1f} KB)')
t0 = time.time()
K = np.load(tpath)
T = K['T']
lmW = K['lm_head']
wte = K['wte']
wpe = K['wpe']
lfw = K['ln_f_w']
lfb = K['ln_f_b']
print(f'  T load time: {(time.time() - t0) * 1000:.1f} ms')

def ln_np(x, w, b, eps=1e-05):
    return (x - np.mean(x)) / (np.std(x) + eps) * w + b

def apply_T(h):
    hb = np.append(h, 1.0).astype(np.float32)
    return hb @ T

def gen_T(prompt, max_new=60, n_steps=8):
    ids = tokenizer.encode(prompt)
    out = []
    for _ in range(max_new):
        tok = ids[-1]
        pos = len(ids) - 1
        h = wte[tok] + wpe[min(pos, wpe.shape[0] - 1)]
        for _ in range(n_steps):
            h = apply_T(h)
        logits = ln_np(h, lfw, lfb) @ lmW.T
        next_tok = int(np.argmax(logits))
        out.append(next_tok)
        ids.append(next_tok)
        if next_tok == tokenizer.eos_token_id:
            break
    return out

def gen_normal(prompt, max_new=60):
    inp = tokenizer.encode(prompt, return_tensors='pt')
    out = []
    cur = inp.clone()
    with torch.no_grad():
        for _ in range(max_new):
            tok = int(torch.argmax(model(cur).logits[0, -1, :]).item())
            out.append(tok)
            cur = torch.cat([cur, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return out
prompts = ['Once upon a time there was a little girl who loved to', 'The little boy found a magic', 'She looked at the stars and', 'The dog ran into the forest and', 'One day a small rabbit']
print(f"\n{'=' * 70}")
print(f'  W KERNEL B — RECURRENT T')
print(f'  One T applied N times = N-layer model')
print(f'  Universal T R²: {r2_test:.4f}')
print(f"{'=' * 70}")
for n_steps in [4, 8, 16]:
    total_m = 0
    total_n = 0
    print(f'\n  ── T applied {n_steps} times ──')
    for prompt in prompts:
        nt = gen_normal(prompt)
        tt = gen_T(prompt, n_steps=n_steps)
        n = min(len(nt), len(tt))
        m = sum((1 for i in range(n) if nt[i] == tt[i]))
        total_m += m
        total_n += n
    acc = total_m / total_n if total_n > 0 else 0
    print(f'  Match: {acc:.1%}  ({total_m}/{total_n})')
print(f'\n  ── FULL TEXT COMPARISON (T×8) ──')
for prompt in prompts[:3]:
    nt = gen_normal(prompt)
    tt = gen_T(prompt, n_steps=8)
    n = min(len(nt), len(tt))
    m = sum((1 for i in range(n) if nt[i] == tt[i]))
    print(f'\n  PROMPT:  {prompt}')
    print(f'  NORMAL:  {tokenizer.decode(nt, skip_special_tokens=True)[:120]}')
    print(f'  T×8:     {tokenizer.decode(tt, skip_special_tokens=True)[:120]}')
    print(f'  Match:   {m / n:.1%}  ({m}/{n})')
print(f"\n{'=' * 70}")
print(f'\n  READING THE RESULT:\n\n  Per-layer R²:\n    If similar across all layers (e.g. all ~0.7):\n      T is truly universal. Same transformation at every layer.\n      One T = the mathematical object all layers express.\n\n    If varies (e.g. 0.9 at layer 0, 0.3 at layer 6):\n      Layers are doing different things.\n      T is an approximation, not exact.\n      Need per-layer T or richer T.\n\n  Universal T R²:\n    High (>0.8): T captures the layer-to-layer law.\n    Medium (0.5-0.8): T captures base pattern.\n                      Attention context is the gap.\n    Low (<0.5): Layers are too different from each other.\n                T concept needs refinement.\n\n  Depth scaling (T×4 vs T×8 vs T×16):\n    If T×16 > T×8 > T×4 in coherence:\n      More steps = better. T is cumulative.\n      Real depth signal.\n\n    If T×8 ≈ T×4:\n      T converges fast. Depth beyond 4 adds little.\n      4-layer T model = 8-layer model quality.\n      That is a speedup.\n\n  IF T IS UNIVERSAL:\n    This is the one mathematical object.\n    All 8 layers = T^8.\n    Scale to 96 layers = T^96. No new parameters.\n    Train T on small model. Apply to any depth.\n    That is the kernel insight from your reference.\n')
print('=' * 70 + '\n')
