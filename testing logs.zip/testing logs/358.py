import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')
prompts_similar = ['Once upon a time there was a little girl', 'Once upon a time there was a small boy', 'Once upon a time there was a young child', 'Once upon a time there was a tiny rabbit', 'Once upon a time there was a little dog']
prompts_different = ['The mathematics of prime numbers is', 'She looked at the stars and felt', 'The dog ran into the dark forest', 'Once upon a time there was a little girl', 'He picked up the heavy stone and']
all_prompts = prompts_similar + prompts_different
layer_h = {l: [] for l in range(n_layers + 1)}
layer_attn = {l: [] for l in range(n_layers)}
hooks = []
for li in range(n_layers):

    def make_h(l):

        def hook(m, inp, out):
            x = inp[0].detach().float()
            layer_h[l].append(x[0].numpy().copy())
        return hook
    hooks.append(model.transformer.h[li].register_forward_hook(make_h(li)))

def hook_final(m, inp, out):
    x = inp[0].detach().float()
    layer_h[n_layers].append(x[0].numpy().copy())
hooks.append(model.transformer.ln_f.register_forward_hook(hook_final))
for li in range(n_layers):

    def make_attn(l):

        def hook(m, inp, out):
            pass
        return hook
print(f'\nRunning {len(all_prompts)} forward passes...')
prompt_last_h = {l: [] for l in range(n_layers + 1)}
with torch.no_grad():
    for prompt in all_prompts:
        for l in range(n_layers + 1):
            layer_h[l] = []
        toks = tokenizer(prompt, return_tensors='pt')
        out = model(**toks, output_attentions=True)
        for li in range(n_layers):
            if out.attentions is not None:
                attn = out.attentions[li].detach().float()
                layer_attn[li].append(attn[0].numpy().copy())
        for l in range(n_layers + 1):
            if layer_h[l]:
                h = layer_h[l][0]
                prompt_last_h[l].append(h[-1].copy())
for h in hooks:
    h.remove()
print(f"\n{'=' * 60}")
print(f'  ANALYSIS 1: Attention entropy per layer')
print(f'  High entropy = broad. Low entropy = sharp/focused.')
print(f"{'=' * 60}")

def entropy(attn_weights):
    eps = 1e-10
    ent = -np.sum(attn_weights * np.log(attn_weights + eps), axis=-1)
    return float(np.mean(ent))
print(f"\n  {'Layer':<8} {'Mean Entropy':<16} {'Convergence'}")
print(f"  {'─' * 40}")
entropies = []
for li in range(n_layers):
    if layer_attn[li]:
        ents = [entropy(a) for a in layer_attn[li]]
        mean_ent = float(np.mean(ents))
        entropies.append(mean_ent)
        if li > 0:
            arrow = '↓ sharper' if mean_ent < entropies[-2] else '↑ broader'
        else:
            arrow = ''
        print(f'  {li:<8} {mean_ent:<16.4f} {arrow}')
if len(entropies) > 1:
    trend = np.polyfit(range(len(entropies)), entropies, 1)[0]
    print(f'\n  Entropy trend: {trend:+.4f} per layer')
    print(f"  {('CONVERGING (sharpening)' if trend < -0.01 else 'STABLE' if abs(trend) < 0.01 else 'DIVERGING (broadening)')}")
print(f"\n{'=' * 60}")
print(f'  ANALYSIS 2: h_final attractor — do different prompts converge?')
print(f"{'=' * 60}")
print(f"\n  {'Layer':<8} {'Mean h norm':<16} {'Std across prompts':<20} {'Attractor?'}")
print(f"  {'─' * 55}")
norms_per_layer = []
stds_per_layer = []
for li in range(n_layers + 1):
    if prompt_last_h[li] and len(prompt_last_h[li]) >= 2:
        H = np.array(prompt_last_h[li])
        mean_norm = float(np.mean(np.linalg.norm(H, axis=1)))
        std_across = float(np.mean(np.std(H, axis=0)))
        norms_per_layer.append(mean_norm)
        stds_per_layer.append(std_across)
        label = 'LAYER_F' if li == n_layers else f'{li}'
        attractor_sign = '→ converging' if li > 0 and std_across < stds_per_layer[-2] else ''
        print(f'  {label:<8} {mean_norm:<16.4f} {std_across:<20.4f} {attractor_sign}')
if len(stds_per_layer) > 1:
    std_trend = np.polyfit(range(len(stds_per_layer)), stds_per_layer, 1)[0]
    print(f'\n  Std trend: {std_trend:+.6f} per layer')
    print(f"  {('ATTRACTOR CONFIRMED: h converges across layers' if std_trend < 0 else 'NO ATTRACTOR: h diverges or stays same')}")
print(f"\n{'=' * 60}")
print(f'  ANALYSIS 3: Distance between very different prompts')
print(f"  Prompt A: 'Once upon a time...' (story)")
print(f"  Prompt B: 'The mathematics of prime numbers...'")
print(f'  If distance shrinks: attractor pulling them together.')
print(f"{'=' * 60}")
idx_a = 0
idx_b = 5
print(f"\n  {'Layer':<8} {'Distance':<16} {'Direction'}")
print(f"  {'─' * 35}")
distances = []
for li in range(n_layers + 1):
    if len(prompt_last_h[li]) > idx_b:
        ha = prompt_last_h[li][idx_a]
        hb = prompt_last_h[li][idx_b]
        dist = float(np.linalg.norm(ha - hb))
        distances.append(dist)
        label = 'FINAL' if li == n_layers else f'{li}'
        direction = ''
        if len(distances) > 1:
            direction = '↓ closer' if dist < distances[-2] else '↑ farther'
        print(f'  {label:<8} {dist:<16.4f} {direction}')
if len(distances) > 1:
    dist_trend = np.polyfit(range(len(distances)), distances, 1)[0]
    print(f'\n  Distance trend: {dist_trend:+.4f} per layer')
    if dist_trend < -0.1:
        print(f'  ATTRACTOR CONFIRMED: different prompts converge.')
        print(f'  Model pulls toward answer coordinate regardless of input.')
    elif dist_trend > 0.1:
        print(f'  DIVERGING: model separates different inputs more per layer.')
        print(f'  Specialization not convergence.')
    else:
        print(f'  STABLE: distance maintained across layers.')
print(f"\n{'=' * 60}")
print(f'  ANALYSIS 4: Similar prompts vs different prompts')
print(f'  Similar = same story opening. Different = random topics.')
print(f'  If similar cluster tighter than different: semantic attractor.')
print(f"{'=' * 60}")
if prompt_last_h[n_layers] and len(prompt_last_h[n_layers]) >= len(all_prompts):
    H_final = np.array(prompt_last_h[n_layers])
    H_sim = H_final[:len(prompts_similar)]
    H_diff = H_final[len(prompts_similar):]

    def mean_pairwise_dist(H):
        dists = []
        for i in range(len(H)):
            for j in range(i + 1, len(H)):
                dists.append(np.linalg.norm(H[i] - H[j]))
        return float(np.mean(dists)) if dists else 0.0
    d_sim = mean_pairwise_dist(H_sim)
    d_diff = mean_pairwise_dist(H_diff)
    print(f'\n  Similar prompts mean distance:   {d_sim:.4f}')
    print(f'  Different prompts mean distance: {d_diff:.4f}')
    print(f'  Ratio (similar/different):       {d_sim / d_diff:.4f}')
    if d_sim < d_diff * 0.7:
        print(f'\n  SEMANTIC ATTRACTOR: similar prompts cluster tighter.')
        print(f'  Model learned semantic coordinate space.')
    elif d_sim < d_diff:
        print(f'\n  WEAK SEMANTIC ATTRACTOR: slight clustering.')
    else:
        print(f'\n  NO SEMANTIC ATTRACTOR: similar ≈ different in h_final.')
print(f"\n{'=' * 60}")
print(f'  HIDDEN LAW 1 SUMMARY')
print(f"{'=' * 60}")
print(f'\n  WHAT THIS MEANS:\n\n  Entropy trend (sharpening):\n    Attention focusing = model knows WHERE to look.\n    Early layers: gather context broadly.\n    Late layers:  locked onto answer location.\n    Attractor = the location attention locks onto.\n\n  h std trend (converging):\n    Different inputs → similar h_final.\n    Model pulls everything toward answer manifold.\n    Like CHIMERA: input varies, attractor stable.\n\n  Distance trend (shrinking):\n    Story prompt and math prompt end up closer.\n    Not because they are same meaning.\n    Because both converge to answer coordinate space.\n    Answer space = smaller than input space.\n\n  Semantic attractor:\n    Similar prompts cluster = model learned meaning.\n    Coordinate in h_final = semantic address.\n    Close addresses = similar meanings.\n    This IS the coordinate system from hyper law.\n')
print('=' * 60 + '\n')
