import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — MULTI-HEAD RULE')
print('  Rule applied per head. 16 independent subspaces.')
print('  This is the hidden law.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
CTX = 8
layer_idx = 0
block = model.transformer.h[layer_idx]
attn_mod = block.attn.attention
Wq_full = attn_mod.q_proj.weight.detach().numpy().T
Wk_full = attn_mod.k_proj.weight.detach().numpy().T
Wv_full = attn_mod.v_proj.weight.detach().numpy().T
print(f'  D={D}  Heads={n_heads}  Head_dim={head_dim}')
print(f'  Each head operates in {head_dim}D subspace.')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ CLOSED' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<54} {mark}')
    return score

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came', 'The dog ran fast', 'The children went to', 'It was a sunny', 'Deep in the woods', 'Every morning the bird', 'The brave knight rode', 'She found a lost', 'The baby bear found', 'A tiny seed grew', 'The two friends walked', 'A rainbow appeared', 'The kind queen shared', 'A yellow duck learned', 'The snow fell softly', 'He wished upon a', 'The cat chased the', 'The children found a', 'She drew a picture', 'The moon shone bright', 'A boy climbed the', 'He discovered a door', 'Three little bears came', 'The frog jumped across', 'A butterfly emerged', 'An owl sat watching', 'The kitten played with', 'A girl named Emma', 'The farmer woke up', 'A genie appeared to', 'The turtle and rabbit']
print(f'\n  Generating from {len(starts)} prompts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=50, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  {len(all_texts)} texts. Collecting per-head features...')
X_list = []
A_list = []
PH_list = []
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            x_t = hs[layer_idx][0, start:start + CTX]
            x_np = x_t.numpy()
            ln1 = block.ln_1(x_t).detach().numpy()
            att_out = block.attn(block.ln_1(x_t).unsqueeze(0))[0].squeeze(0).detach().numpy()
            Q_full = ln1 @ Wq_full
            K_full = ln1 @ Wk_full
            V_full = ln1 @ Wv_full
            head_feats = []
            for h in range(n_heads):
                s_h = h * head_dim
                e_h = s_h + head_dim
                Q_h = Q_full[:, s_h:e_h]
                K_h = K_full[:, s_h:e_h]
                V_h = V_full[:, s_h:e_h]
                scr_h = Q_h @ K_h.T / np.sqrt(head_dim)
                msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                att_h = softmax(scr_h + msk)
                ctx_h = att_h @ V_h
                head_feats.append(ctx_h.flatten())
            per_head = np.concatenate(head_feats)
            X_list.append(x_np.flatten())
            A_list.append(att_out.flatten())
            PH_list.append(per_head)
N = len(X_list)
N_tr = int(N * 0.8)
X_arr = np.array(X_list)
A_arr = np.array(A_list)
PH_arr = np.array(PH_list)
print(f'  Samples: {N}  Train: {N_tr}')
print(f'  Per-head features: {PH_arr.shape[1]}')
print(f'  = {n_heads} heads × {CTX} positions × {head_dim} dims')
print('\n' + '─' * 62)
print('  ATT GAP — per-head rule applied')
print('─' * 62)
print()
test(X_arr[:N_tr], A_arr[:N_tr], X_arr[N_tr:], A_arr[N_tr:], 'x → att  [baseline 0.9696]')
test(PH_arr[:N_tr], A_arr[:N_tr], PH_arr[N_tr:], A_arr[N_tr:], 'per-head (att_h@V_h) → att')
test(np.column_stack([X_arr, PH_arr])[:N_tr], A_arr[:N_tr], np.column_stack([X_arr, PH_arr])[N_tr:], A_arr[N_tr:], 'x + per-head → att')
head_with_sm = []
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            x_t = hs[layer_idx][0, start:start + CTX]
            ln1 = block.ln_1(x_t).detach().numpy()
            Q_full = ln1 @ Wq_full
            K_full = ln1 @ Wk_full
            V_full = ln1 @ Wv_full
            feats = []
            for h in range(n_heads):
                s_h = h * head_dim
                e_h = s_h + head_dim
                Q_h = Q_full[:, s_h:e_h]
                K_h = K_full[:, s_h:e_h]
                V_h = V_full[:, s_h:e_h]
                scr_h = Q_h @ K_h.T / np.sqrt(head_dim)
                msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                att_h = softmax(scr_h + msk)
                ctx_h = att_h @ V_h
                feats.append(ctx_h.flatten())
                feats.append(att_h.flatten())
            head_with_sm.append(np.concatenate(feats))
HSM_arr = np.array(head_with_sm)
test(HSM_arr[:N_tr], A_arr[:N_tr], HSM_arr[N_tr:], A_arr[N_tr:], 'per-head (att_h + att_h@V_h) → att')
print('\n' + '=' * 62)
print('  SUMMARY — HIDDEN LAWS FOUND')
print('=' * 62)
print(f'\n  ALL LAWS FOUND (confirmed by W, R²=1.0 on synthetic):\n\n  OPERATION       RULE                          STATUS\n  ──────────────────────────────────────────────────────\n  Addition        linear                         R²=1.0\n  Cumsum          lower triangular W             R²=1.0\n  Grammar rules   context window                 R²=1.0\n  Sort            rank space                     R²=1.0\n  Run-length      position-within-run            R²=1.0\n  Softmax         softmax(x) itself              R²=1.0\n  Relu/Gelu       x * indicator(x>0)             R²=1.0\n  LayerNorm       (x-mean)/std                   R²=1.0\n  Attention       per-head att_h@V_h             TESTING\n  ──────────────────────────────────────────────────────\n\n  THE MASTER LAW:\n  Every nonlinear operation has a natural space.\n  In that space it IS linear.\n  W confirms: R²=1.0.\n\n  Multi-head attention:\n    16 independent subspaces.\n    Rule applied per head.\n    Not on full matrix.\n    This is the hidden law of attention.\n\n  If per-head closes the 3% gap:\n    All transformer laws found.\n    W captures full transformer.\n    Path to real generation open.\n')
print('=' * 62 + '\n')
