import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN, N_TEST, MAX_SEQ = (500, 100, 64)
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={DEVICE}')
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(DEVICE).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD = H // NH
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
with torch.no_grad():
    Wte = teacher.transformer.wte.weight.float().cpu().numpy()
    Wpe = teacher.transformer.wpe.weight.float().cpu().numpy()
    lnf_g = teacher.transformer.ln_f.weight.float().cpu().numpy()
    lnf_b = teacher.transformer.ln_f.bias.float().cpu().numpy()
    Wlm = teacher.lm_head.weight.float().cpu().numpy()
    LN = []
    for li in range(NL):
        bl = teacher.transformer.h[li]
        LN.append({'ln1_g': bl.ln_1.weight.float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.float().cpu().numpy(), 'type': ATT[li] if li < len(ATT) else 'global'})
del teacher
torch.cuda.empty_cache()
VOCAB = Wlm.shape[0]
print(f'  NL={NL} H={H} NH={NH} HD={HD}  VOCAB={VOCAB}')

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (g * (x - m) / np.sqrt(v + eps) + b).astype(np.float32)

def gelu(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def softmax_rows(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def solve(X, Y):
    X64 = X.astype(np.float64)
    Y64 = Y.astype(np.float64)
    Xb = np.concatenate([X64, np.ones((len(X64), 1))], 1)
    res, _, _, _ = lstsq(Xb, Y64, rcond=None)
    W = res[:-1].T.astype(np.float32)
    b = res[-1].astype(np.float32)
    Yp = X64 @ res[:-1] + res[-1]
    r2 = float(1 - ((Y64 - Yp) ** 2).sum() / (((Y64 - Y64.mean(0)) ** 2).sum() + 1e-12))
    return (W, b, r2)

def self_attn_ctx(ln1_h):
    return ln1_h.astype(np.float32)

def causal_attn_gen(h, li, w):
    sl = h.shape[0]
    ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
    Q = ln1_h.reshape(sl, NH, HD).transpose(1, 0, 2)
    K = Q.copy()
    V = Q.copy()
    scores = np.matmul(Q, K.transpose(0, 2, 1)).astype(np.float32)
    mask = np.full((sl, sl), -1000000000.0, np.float32)
    atype = LN[li].get('type', 'global')
    for i in range(sl):
        start = max(0, i - WIN + 1) if atype == 'local' else 0
        mask[i, start:i + 1] = 0.0
    scores += mask[np.newaxis]
    scores -= scores.max(-1, keepdims=True)
    e = np.exp(scores)
    attn_w = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    ctx = np.matmul(attn_w, V)
    ctx = ctx.transpose(1, 0, 2).reshape(sl, H).astype(np.float32)
    att_out = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
    return att_out
print(f'\n  Loading data...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
stories = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 300:
        stories.append(t)
    if len(stories) >= N_TRAIN + N_TEST:
        break

def build(story_list):
    h0, nxt = ([], [])
    for s in story_list:
        ids = tok(s, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'][0].tolist()
        if len(ids) < 2:
            continue
        for pos in range(len(ids) - 1):
            h0.append(Wte[ids[pos]] + Wpe[pos])
            nxt.append(ids[pos + 1])
    return (np.array(h0, np.float32), np.array(nxt, np.int32))
H0_tr, IDS_tr = build(stories[:N_TRAIN])
H0_te, IDS_te = build(stories[N_TRAIN:N_TRAIN + N_TEST])
HTGT_tr = Wlm[IDS_tr]
print(f'  Train: {len(IDS_tr)}  Test: {len(IDS_te)}')

def train_pass(h0, htgt, prev_W=None):
    if prev_W is not None:
        acts = [h0.copy()]
        h = h0.copy()
        for li, w in enumerate(prev_W):
            ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
            ctx = self_attn_ctx(ln1_h)
            att = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
            hm = (h + att).astype(np.float32)
            ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
            pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
            ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
            h = (hm + ffn).astype(np.float32)
            acts.append(h.copy())
    else:
        acts = None
    print(f"  {'Layer':<6} {'frac':>6}  {'R²_Wo':>8} {'R²_W2':>8}  err")
    print(f"  {'-' * 46}")
    weights = []
    h_cur = h0.copy()
    for li in range(NL):
        frac = (li + 1) / NL
        h_in = acts[li] if acts else h_cur
        h_tgt = ((1 - frac) * h0 + frac * htgt).astype(np.float32)
        ln1_h = ln(h_in, LN[li]['ln1_g'], LN[li]['ln1_b'])
        ctx = self_attn_ctx(ln1_h)
        att_tgt = (h_tgt - h_in).astype(np.float32)
        Wo, bo, r2_o = solve(ctx, att_tgt)
        att_out = (ctx @ Wo.T + bo).astype(np.float32)
        hm = (h_in + att_out).astype(np.float32)
        ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
        ffn_tgt = (h_tgt - hm).astype(np.float32)
        W1, b1, _ = solve(ln2_h, ln2_h)
        pre = (ln2_h @ W1.T + b1).astype(np.float32)
        W2, b2, r2_2 = solve(gelu(pre), ffn_tgt)
        ffn_out = (gelu(pre) @ W2.T + b2).astype(np.float32)
        h_cur = (hm + ffn_out).astype(np.float32)
        err = float(np.abs(h_cur - h_tgt).mean())
        print(f'  {li:<6} {frac:6.3f}  {r2_o:8.4f} {r2_2:8.4f}  {err:.5f}')
        weights.append(dict(Wo=Wo, bo=bo, W1=W1, b1=b1, W2=W2, b2=b2))
    return weights

def forward_eval(h0, weights):
    h = h0.copy()
    for li, w in enumerate(weights):
        ln1_h = ln(h, LN[li]['ln1_g'], LN[li]['ln1_b'])
        ctx = self_attn_ctx(ln1_h)
        att = (ctx @ w['Wo'].T + w['bo']).astype(np.float32)
        hm = (h + att).astype(np.float32)
        ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
        pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
        ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
        h = (hm + ffn).astype(np.float32)
    return (ln(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32)

def acc(logits, ids):
    return float((np.argmax(logits, -1) == ids).mean())
print(f'\n  PASS 1')
t0 = time.perf_counter()
W_p1 = train_pass(H0_tr, HTGT_tr)
acc1 = acc(forward_eval(H0_te, W_p1), IDS_te)
print(f'  Test acc: {acc1 * 100:.3f}%  ({acc1 / (1 / VOCAB):.0f}x random)')
print(f'\n  PASS 2 (EM refinement)')
W_p2 = train_pass(H0_tr, HTGT_tr, prev_W=W_p1)
acc2 = acc(forward_eval(H0_te, W_p2), IDS_te)
t_total = time.perf_counter() - t0
print(f'  Test acc: {acc2 * 100:.3f}%  ({acc2 / (1 / VOCAB):.0f}x random)')
print(f'  Total time: {t_total:.1f}s  |  Gradient steps: 0')

def gen_scratch(prompt, n=60):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    for _ in range(n):
        sl = len(ids)
        h = (Wte[np.array(ids)] + Wpe[np.arange(sl)]).astype(np.float32)
        for li, w in enumerate(W_p2):
            att = causal_attn_gen(h, li, w)
            hm = (h + att).astype(np.float32)
            ln2_h = ln(hm, LN[li]['ln2_g'], LN[li]['ln2_b'])
            pre = (ln2_h @ w['W1'].T + w['b1']).astype(np.float32)
            ffn = (gelu(pre) @ w['W2'].T + w['b2']).astype(np.float32)
            h = (hm + ffn).astype(np.float32)
        logits = (ln(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32)
        next_id = int(np.argmax(logits[-1]))
        if next_id == tok.eos_token_id:
            break
        ids.append(next_id)
    prompt_len = len(tok(prompt)['input_ids'])
    return tok.decode(ids[prompt_len:], skip_special_tokens=True)

def gen_teacher(prompt, n=60):
    t = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(DEVICE).eval()
    inp = tok(prompt, return_tensors='pt').to(DEVICE)
    with torch.no_grad():
        out = t.generate(inp['input_ids'], max_new_tokens=n, do_sample=False, use_cache=True, pad_token_id=tok.eos_token_id)
    del t
    torch.cuda.empty_cache()
    return tok.decode(out[0][inp['input_ids'].shape[1]:], skip_special_tokens=True)
PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'Tom wanted to play but', 'In the forest there lived a']
print('\n' + '=' * 60)
print('  GENERATION — SCRATCH (0 gradients) vs TEACHER')
print('=' * 60)
for p in PROMPTS:
    s = gen_scratch(p, n=50)
    print(f'\n  Prompt  : "{p}"')
    print(f'  Scratch : {s.strip()}')
print('\n  --- Teacher comparison ---')
p = PROMPTS[0]
print(f'  Prompt  : "{p}"')
print(f'  Teacher : {gen_teacher(p, n=50).strip()}')
print(f'  Scratch : {gen_scratch(p, n=50).strip()}')
print(f'\n  FINAL: Test {acc2 * 100:.2f}%  |  {acc2 / (1 / VOCAB):.0f}x random  |  {t_total:.1f}s  |  0 gradients')
