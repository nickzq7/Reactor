import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — PURE NUMPY ENGINE v4.1')
print('  Direct weights. Zero lstsq error. Exact match.')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
cfg = model.config
D = cfg.hidden_size
n_heads = cfg.num_attention_heads
head_dim = D // n_heads
n_layers = cfg.num_layers
act_fn = cfg.activation_function
win_size = getattr(cfg, 'window_size', 256)
att_layers = getattr(cfg, 'attention_layers', ['global'] * n_layers)
print(f'  D={D}  heads={n_heads}  head_dim={head_dim}  layers={n_layers}')
print(f'  activation={act_fn}  window_size={win_size}')
print(f'  attention_layers={att_layers}')
print(f'\n  Extracting exact weights directly from model...')
W_layers = {}
with torch.no_grad():
    for l in range(n_layers):
        block = model.transformer.h[l]
        attn = block.attn.attention
        mlp = block.mlp
        W_q = attn.q_proj.weight.detach().numpy()
        W_k = attn.k_proj.weight.detach().numpy()
        W_v = attn.v_proj.weight.detach().numpy()
        W_o = attn.out_proj.weight.detach().numpy()
        b_o = attn.out_proj.bias.detach().numpy()
        W_1 = mlp.c_fc.weight.detach().numpy()
        b_1 = mlp.c_fc.bias.detach().numpy()
        W_2 = mlp.c_proj.weight.detach().numpy()
        b_2 = mlp.c_proj.bias.detach().numpy()
        ln1_w = block.ln_1.weight.detach().numpy()
        ln1_b = block.ln_1.bias.detach().numpy()
        ln2_w = block.ln_2.weight.detach().numpy()
        ln2_b = block.ln_2.bias.detach().numpy()
        W_layers[l] = {'Wq': W_q, 'Wk': W_k, 'Wv': W_v, 'Wo': W_o, 'bo': b_o, 'W1': W_1, 'b1': b_1, 'W2': W_2, 'b2': b_2, 'ln1_w': ln1_w, 'ln1_b': ln1_b, 'ln2_w': ln2_w, 'ln2_b': ln2_b, 'att_type': att_layers[l] if l < len(att_layers) else 'global'}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_head = model.lm_head.weight.detach().numpy()
print(f'  ✓ All {n_layers * 10} weight tensors extracted directly. Zero error.')

def layernorm_np(x, gamma, beta, eps=1e-05):
    x = x.astype(np.float32)
    mean = x.mean(axis=-1, keepdims=True)
    var = ((x - mean) ** 2).mean(axis=-1, keepdims=True)
    return (x - mean) / np.sqrt(var + np.float32(eps)) * gamma + beta

def gelu_new_np(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2.0 / math.pi))
    return np.float32(0.5) * x * (np.float32(1.0) + np.tanh(c * (x + np.float32(0.044715) * x * x * x)))

def gelu_np(x):
    from scipy.special import erf
    x = x.astype(np.float32)
    return (x * 0.5 * (1.0 + erf(x / math.sqrt(2)))).astype(np.float32)
activate = gelu_new_np if act_fn == 'gelu_new' else gelu_np

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)

def make_causal_mask(seq_len):
    return np.triu(np.full((seq_len, seq_len), -1000000000.0, dtype=np.float32), k=1)

def make_local_mask(seq_len, window):
    mask = make_causal_mask(seq_len)
    for i in range(seq_len):
        for j in range(max(0, i - window), i):
            pass
        for j in range(0, max(0, i - window)):
            mask[i, j] = -1000000000.0
    return mask

def numpy_forward(token_ids):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    for l in range(n_layers):
        W = W_layers[l]
        ln1 = layernorm_np(x, W['ln1_w'], W['ln1_b'])
        Q = ln1 @ W['Wq'].T
        K = ln1 @ W['Wk'].T
        V = ln1 @ W['Wv'].T
        Q_h = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        K_h = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        V_h = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        if W['att_type'] == 'local' and seq_len > win_size:
            mask = make_local_mask(seq_len, win_size)
        else:
            mask = make_causal_mask(seq_len)
        scale = np.float32(1.0 / math.sqrt(head_dim))
        head_outs = []
        for h in range(n_heads):
            scores = Q_h[h] @ K_h[h].T * scale
            scores = softmax_np(scores + mask)
            head_outs.append(scores @ V_h[h])
        concat = np.stack(head_outs, axis=1).reshape(seq_len, D)
        att_out = concat @ W['Wo'].T + W['bo']
        x = x + att_out
        ln2 = layernorm_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['W1'].T + W['b1']
        act = activate(pre)
        ffn_out = act @ W['W2'].T + W['b2']
        x = x + ffn_out
    h_f = layernorm_np(x[-1:], lnf_w, lnf_b)
    logits = h_f @ lm_head.T
    return logits[0]
prompt = 'Once upon a time, in a small village, there lived a boy named Jack.'
input_ids = tokenizer.encode(prompt, return_tensors='pt')
tokens_to_gen = 30
print('\n' + '─' * 66)
print(f'  GENERATING {tokens_to_gen} TOKENS (Greedy Argmax)')
print('─' * 66)
pt_ids = input_ids.clone()
with torch.no_grad():
    for _ in range(tokens_to_gen):
        logits = model(pt_ids).logits
        next_id = torch.argmax(logits[0, -1, :]).item()
        pt_ids = torch.cat([pt_ids, torch.tensor([[next_id]])], dim=1)
pt_text = tokenizer.decode(pt_ids[0])
print(f'\n  [ PYTORCH ENGINE ]:\n  {pt_text}\n')
np_ids = input_ids[0].tolist()
matches = 0
print(f'  [ PURE NUMPY ENGINE ] (token by token):')
print(f"  {'step':<6} {'PT token':<20} {'NP token':<20} {'match'}")
print(f"  {'─' * 58}")
pt_token_list = pt_ids[0].tolist()[len(np_ids):]
for step in range(tokens_to_gen):
    logits = numpy_forward(np_ids)
    next_id = int(np.argmax(logits))
    np_ids.append(next_id)
    pt_tok = tokenizer.decode([pt_token_list[step]])
    np_tok = tokenizer.decode([next_id])
    match = '✓' if next_id == pt_token_list[step] else '✗'
    if next_id == pt_token_list[step]:
        matches += 1
    print(f'  {step + 1:<6} {repr(pt_tok):<20} {repr(np_tok):<20} {match}')
np_text = tokenizer.decode(np_ids)
print(f'\n  [ PURE NUMPY ENGINE FULL TEXT ]:\n  {np_text}')
print(f'\n  Token match: {matches}/{tokens_to_gen} = {100 * matches / tokens_to_gen:.1f}%')
print('\n' + '=' * 66)
if matches == tokens_to_gen:
    print('  ✓ 100% MATCH. DEEP LEARNING ARCHITECTURE IS AN ILLUSION.')
    print('  ✓ The transformer = pure linear algebra + 2 crystal points.')
    print('  ✓ W PRINCIPLE FULLY PROVEN IN PURE NUMPY.')
else:
    print(f'  ✗ {tokens_to_gen - matches} tokens differ.')
    print(f'  First divergence at step: {next((i + 1 for i, (a, b) in enumerate(zip(pt_token_list, np_ids[len(input_ids[0]):])) if a != b))}')
    print('  Investigate: layernorm precision or attention mask.')
print('=' * 66 + '\n')
