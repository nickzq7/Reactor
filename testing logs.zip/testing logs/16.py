import torch
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
from scipy.optimize import curve_fit
import warnings
warnings.filterwarnings('ignore')
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
R2_GATE = 0.9999
ERR_GATE = 0.0001

def r2(yt, yp):
    yt = np.array(yt, dtype=float)
    yp = np.array(yp, dtype=float)
    ss_res = ((yt - yp) ** 2).sum()
    ss_tot = ((yt - yt.mean()) ** 2).sum()
    if ss_tot < 1e-15:
        return 1.0 if ss_res < 1e-15 else 0.0
    return float(1 - ss_res / ss_tot)

def merr(yt, yp):
    return float(np.max(np.abs(np.array(yt) - np.array(yp))))

def fit_all(y):
    y = np.array(y, dtype=float)
    xf = np.arange(len(y), dtype=float)
    best = (-1, 999, 'none', y, 'no fit')

    def try_it(name, pred_fn):
        nonlocal best
        try:
            pred = np.array(pred_fn(), dtype=float)
            rv = r2(y, pred)
            ev = merr(y, pred)
            if rv > best[0]:
                best = (rv, ev, name, pred, f'R²={rv:.6f} err={ev:.2e}')
        except:
            pass
    try_it('constant', lambda: np.full_like(y, y.mean()))
    c = np.polyfit(xf, y, 1)
    try_it('linear', lambda: np.polyval(c, xf))
    c2 = np.polyfit(xf, y, 2)
    try_it('quadratic', lambda: np.polyval(c2, xf))
    c3 = np.polyfit(xf, y, 3)
    try_it('cubic', lambda: np.polyval(c3, xf))
    if np.all(y > 1e-12):
        cg = np.polyfit(xf, np.log(y), 1)
        try_it('geometric', lambda: np.exp(cg[1]) * np.exp(cg[0] * xf))

    def fedec(n, A, k, C):
        return A * np.exp(-k * n) + C
    try:
        p0 = [float(y[0] - y[-1]), 0.5, float(y[-1])]
        po, _ = curve_fit(fedec, xf, y, p0=p0, maxfev=20000)
        try_it('exp_decay', lambda: fedec(xf, *po))
    except:
        pass

    def fgrow(n, A, k, C):
        return A * np.exp(k * n) + C
    try:
        p0g = [float(y[-1] - y[0]), 0.1, float(y[0])]
        pog, _ = curve_fit(fgrow, xf, y, p0=p0g, maxfev=20000)
        try_it('exp_growth', lambda: fgrow(xf, *pog))
    except:
        pass

    def fsin(n, A, w, phi, C):
        return A * np.sin(w * n + phi) + C
    try:
        A0 = (y.max() - y.min()) / 2
        C0 = y.mean()
        pos, _ = curve_fit(fsin, xf, y, p0=[A0, np.pi / 3, 0, C0], maxfev=30000)
        try_it('sinusoidal', lambda: fsin(xf, *pos))
    except:
        pass

    def fpow(n, A, p, C):
        return A * (n + 1) ** p + C
    try:
        pop, _ = curve_fit(fpow, xf, y, p0=[1, -0.5, 0], maxfev=20000)
        try_it('power', lambda: fpow(xf, *pop))
    except:
        pass
    if np.all(xf + 1 > 0):
        try:
            cl = np.polyfit(np.log(xf + 1), y, 1)
            try_it('log', lambda: cl[0] * np.log(xf + 1) + cl[1])
        except:
            pass
    rv, ev, nm, pr, ds = best
    if nm == 'constant':
        fs = f'C={y.mean():.6f}'
    elif nm == 'linear':
        fs = f'{c[0]:+.6f}*N+{c[1]:.6f}'
    elif nm == 'quadratic':
        fs = f'{c2[0]:+.6f}N²+{c2[1]:+.6f}N+{c2[2]:.6f}'
    elif nm == 'cubic':
        fs = f'cubic(N)'
    else:
        fs = nm
    return (rv, ev, nm, pr, fs)
print_sep('LOAD + HOOK (before AND after each layer)')
MODEL = 'roneneldan/TinyStories-1M'
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
try:
    model = AutoModelForCausalLM.from_pretrained(MODEL, dtype=torch.float32, use_safetensors=True)
except:
    model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.float32)
model = model.to(device)
model.eval()
n_layers = model.config.num_layers
hidden = model.config.hidden_size
print(f'  Layers={n_layers}  Hidden={hidden}')
HIGHWAY = list(range(1, 7))
n_hw = len(HIGHWAY)
before = {}
after = {}
hooks = []

def make_pre_hook(li):

    def fn(module, inp):
        x = inp[0] if isinstance(inp, tuple) else inp
        before[li] = x.detach().cpu()
    return fn

def make_post_hook(li):

    def fn(module, inp, out):
        x = out[0] if isinstance(out, tuple) else out
        after[li] = x.detach().cpu()
    return fn
for li in range(n_layers):
    h = model.transformer.h[li]
    hooks.append(h.register_forward_pre_hook(make_pre_hook(li)))
    hooks.append(h.register_forward_hook(make_post_hook(li)))
print(f'  Registered {len(hooks)} hooks (pre+post per layer)')
print_sep('CAPTURE RESIDUAL DELTAS')
SENTENCES = ['Once upon a time there was a little girl named Lily', 'One day the dog found a big bone in the garden', 'Tom and his friend went to the forest to play', 'The old man sat by the river and watched the fish', 'She looked at the stars and made a wish', 'The cat ran away when it heard a loud noise', 'Lily wanted to help but she did not know how', 'He was very happy when he found his toy', 'The children played together in the park all day', 'She picked up the flower and smelled it slowly', 'He said sorry and they became good friends again', 'The little dog was sad because it lost its bone', 'Once there was a kind old woman who lived alone', 'The boy smiled and ran to his mother quickly', 'She opened the box and found a little surprise', 'They laughed and played until the sun went down']
delta_sum = np.zeros((n_layers, hidden))
delta_sq = np.zeros((n_layers, hidden))
n_tokens_total = 0
per_tok_delta_mags = {li: [] for li in range(n_layers)}
for sent in SENTENCES:
    inputs = tok(sent, return_tensors='pt').to(device)
    ids = inputs['input_ids']
    before.clear()
    after.clear()
    with torch.no_grad():
        _ = model(**inputs)
    n_tok = ids.shape[1]
    for li in range(n_layers):
        b = before[li][0].numpy()
        a = after[li][0].numpy()
        d = a - b
        delta_sum[li] += np.abs(d).sum(axis=0)
        delta_sq[li] += (d ** 2).sum(axis=0)
        for ti in range(n_tok):
            per_tok_delta_mags[li].append(float(np.linalg.norm(d[ti])))
    n_tokens_total += n_tok
for h in hooks:
    h.remove()
delta_mean = delta_sum / n_tokens_total
delta_std = np.sqrt(np.maximum(delta_sq / n_tokens_total - delta_mean ** 2, 0))
print(f'  Sentences: {len(SENTENCES)}  Total tokens: {n_tokens_total}')
avg_delta_mag = np.array([np.mean(per_tok_delta_mags[li]) for li in range(n_layers)])
print(f'\n  Average |delta| magnitude per layer:')
print(f"  {'Layer':<8}", end='')
for li in range(n_layers):
    print(f'  L{li}', end='')
print()
print(f"  {'|delta|':<8}", end='')
for li in range(n_layers):
    print(f'  {avg_delta_mag[li]:.4f}', end='')
print()
print(f'\n  Highway (L1-L6) delta magnitudes:')
hw_delta_mags = avg_delta_mag[HIGHWAY]
for li, v in zip(HIGHWAY, hw_delta_mags):
    print(f'    L{li}: {v:.5f}')
print_sep('SEARCH 1 — PER-TOKEN DELTA MAGNITUDE (highway L1-L6)')
all_tok_hw_mags = []
for sent in SENTENCES:
    inputs = tok(sent, return_tensors='pt').to(device)
    ids = inputs['input_ids']
    before.clear()
    after.clear()
    break
n_per_sent = []
for sent in SENTENCES:
    ids = tok(sent, return_tensors='pt')['input_ids']
    n_per_sent.append(ids.shape[1])
idx = 0
found_mag = []
best_r2_mag = 0
for ti in range(n_tokens_total):
    y = np.array([per_tok_delta_mags[li][ti] for li in HIGHWAY])
    rv, ev, nm, pr, fs = fit_all(y)
    if rv > best_r2_mag:
        best_r2_mag = rv
    if rv >= R2_GATE and ev <= ERR_GATE:
        found_mag.append((ti, rv, ev, nm, fs, y, pr))
print(f'  Tokens: {n_tokens_total}  Found: {len(found_mag)}')
print(f'  Best R²: {best_r2_mag:.6f}')
if found_mag:
    print(f"\n  {'#':>4}  {'Formula':<14}  {'R²':>8}  {'Err':>10}  Formula")
    print(f"  {'─' * 70}")
    for ti, rv, ev, nm, fs, y, pr in found_mag[:15]:
        vals = ' '.join((f'{v:.5f}' for v in y))
        print(f'  {ti:>4}  {nm:<14}  {rv:.6f}  {ev:.2e}  {fs}')
        print(f'        [{vals}]')
rv_avg, ev_avg, nm_avg, pr_avg, fs_avg = fit_all(hw_delta_mags)
print(f'\n  Average delta magnitude formula:')
print(f'  {nm_avg}  R²={rv_avg:.6f}  err={ev_avg:.2e}  {fs_avg}')
print(f'  Values:    {hw_delta_mags.round(6)}')
if rv_avg >= R2_GATE and ev_avg <= ERR_GATE:
    print(f'  ← LAW FOUND')
    print(f'  Predicted: {pr_avg.round(6)}')
print_sep('SEARCH 2 — PER-DIMENSION DELTA (highway L1-L6)')
print(f'  For each of {hidden} dims: avg |delta| at each highway layer.')
found_dims = {}
dim_results = []
for d in range(hidden):
    y = delta_mean[HIGHWAY, d]
    rv, ev, nm, pr, fs = fit_all(y)
    dim_results.append((d, rv, ev, nm, pr, fs, y))
    if rv >= R2_GATE and ev <= ERR_GATE:
        found_dims[d] = (nm, rv, ev, fs, y, pr)
dim_results.sort(key=lambda x: -x[1])
print(f'\n  Dims with formula (R²≥0.9999): {len(found_dims)}')
if found_dims:
    print(f"\n  {'Dim':>4}  {'Formula':<14}  {'R²':>8}  {'Err':>10}  Formula string")
    print(f"  {'─' * 80}")
    for d, (nm, rv, ev, fs, y, pr) in sorted(found_dims.items(), key=lambda x: -x[1][1]):
        vals = ' '.join((f'{v:.5f}' for v in y))
        pred = ' '.join((f'{v:.5f}' for v in pr))
        print(f'  d{d:>3}  {nm:<14}  {rv:.6f}  {ev:.2e}  {fs}')
        print(f'       actual:    [{vals}]')
        print(f'       predicted: [{pred}]')
        print()
else:
    print(f'\n  Top-15 closest:')
    print(f"  {'Dim':>4}  {'Formula':<14}  {'R²':>8}  {'Err':>10}  Values")
    print(f"  {'─' * 80}")
    for d, rv, ev, nm, pr, fs, y in dim_results[:15]:
        vals = ' '.join((f'{v:.5f}' for v in y))
        print(f'  d{d:>3}  {nm:<14}  {rv:.6f}  {ev:.2e}  [{vals}]')
print_sep('D29 AND D30 — DELTA VS TOTAL (special analysis)')
for d in [29, 30, 21, 50, 45, 52, 0, 13]:
    delta_hw = delta_mean[HIGHWAY, d]
    rv_d, ev_d, nm_d, pr_d, fs_d = fit_all(delta_hw)
    vals_d = ' '.join((f'{v:.5f}' for v in delta_hw))
    print(f'  d{d:>2}  delta [{vals_d}]')
    print(f'       {nm_d}  R²={rv_d:.6f}  err={ev_d:.2e}  {fs_d}')
    if rv_d >= R2_GATE and ev_d <= ERR_GATE:
        print(f'       ← LAW FOUND ON DELTA')
    print()
print_sep('SEARCH 3 — DELTA DIRECTION ACROSS HIGHWAY')
print(f'  avg_delta_vector[li] = mean delta vector for highway layer li')
print(f'  Does direction rotate by constant angle?\n')
avg_delta_vec = np.zeros((n_hw, hidden))
for hi, li in enumerate(HIGHWAY):
    avg_delta_vec[hi] = delta_mean[li]
cos_hw = []
ang_hw = []
for hi in range(n_hw - 1):
    a = avg_delta_vec[hi]
    b = avg_delta_vec[hi + 1]
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na > 1e-10 and nb > 1e-10:
        cos = float(np.clip(np.dot(a, b) / (na * nb), -1, 1))
        ang = float(np.degrees(np.arccos(cos)))
        cos_hw.append(cos)
        ang_hw.append(ang)
        print(f'  L{HIGHWAY[hi]}→L{HIGHWAY[hi + 1]}: cos={cos:.4f}  angle={ang:.2f}°')
if ang_hw:
    rv_a, ev_a, nm_a, pr_a, fs_a = fit_all(np.array(ang_hw))
    print(f'\n  Best formula: {nm_a}  R²={rv_a:.6f}  err={ev_a:.2e}')
    if rv_a >= R2_GATE:
        print(f'  ← LAW: {fs_a}')
print_sep('SEARCH 4 — DELTA RATIO (second-order pattern)')
print(f"\n  From hybrid_mind_v2: constant second difference = formula.\n  Here: delta_ratio(N) = |delta_N| / |delta_(N-1)|\n  \n  If ratio is constant → geometric decay law.\n  Each layer adds exactly r times previous layer's addition.\n  This would be R²=1.0 constant.\n")
hw_mags = avg_delta_mag[HIGHWAY]
ratios = hw_mags[1:] / (hw_mags[:-1] + 1e-12)
print(f'  Highway |delta| magnitudes:')
print(f"  {[f'{v:.5f}' for v in hw_mags]}")
print(f'\n  Ratios delta_(N+1)/delta_N:')
for i, r in enumerate(ratios):
    print(f'  L{HIGHWAY[i]}→L{HIGHWAY[i + 1]}: {r:.6f}')
rv_r, ev_r, nm_r, pr_r, fs_r = fit_all(ratios)
print(f'\n  Formula on ratios: {nm_r}  R²={rv_r:.6f}  err={ev_r:.2e}')
if rv_r >= R2_GATE and ev_r <= ERR_GATE:
    print(f'  ← LAW: {fs_r}')
    print(f'  Mean ratio: {ratios.mean():.6f}')
    print(f'  Each layer adds {ratios.mean():.4f}x previous layer delta.')
const_rv = r2(ratios, [ratios.mean()] * len(ratios))
const_ev = merr(ratios, [ratios.mean()] * len(ratios))
print(f'\n  R²(constant ratio): {const_rv:.6f}  err={const_ev:.6f}')
if const_rv >= R2_GATE and const_ev <= ERR_GATE:
    print(f'  ← GEOMETRIC LAW: |delta_N| = {hw_mags[0]:.5f} * {ratios.mean():.6f}^N')
print_sep('SEARCH 5 — SIGNED DELTA (all 64 dims, highway)')
print(f'  Using signed delta_mean (not |delta|).')
print(f'  Some dims grow, some decay — sign reveals true formula.\n')
hooks2 = []
signed_delta_sum = np.zeros((n_layers, hidden))
n_tok2 = 0
for li in range(n_layers):
    h = model.transformer.h[li]
    hooks2.append(h.register_forward_pre_hook(make_pre_hook(li)))
    hooks2.append(h.register_forward_hook(make_post_hook(li)))
for sent in SENTENCES:
    inputs = tok(sent, return_tensors='pt').to(device)
    ids = inputs['input_ids']
    before.clear()
    after.clear()
    with torch.no_grad():
        _ = model(**inputs)
    nt = ids.shape[1]
    for li in range(n_layers):
        b = before[li][0].numpy()
        a = after[li][0].numpy()
        signed_delta_sum[li] += (a - b).sum(axis=0)
    n_tok2 += nt
for h in hooks2:
    h.remove()
signed_delta_mean = signed_delta_sum / n_tok2
found_signed = {}
signed_results = []
for d in range(hidden):
    y = signed_delta_mean[HIGHWAY, d]
    rv, ev, nm, pr, fs = fit_all(y)
    signed_results.append((d, rv, ev, nm, pr, fs, y))
    if rv >= R2_GATE and ev <= ERR_GATE:
        found_signed[d] = (nm, rv, ev, fs, y, pr)
signed_results.sort(key=lambda x: -x[1])
print(f'  Dims with signed delta formula (R²≥0.9999): {len(found_signed)}')
if found_signed:
    print(f"\n  {'Dim':>4}  {'Formula':<14}  {'R²':>8}  {'Err':>10}")
    print(f"  {'─' * 70}")
    for d, (nm, rv, ev, fs, y, pr) in sorted(found_signed.items(), key=lambda x: -x[1][1]):
        vals = ' '.join((f'{v:+.5f}' for v in y))
        pred = ' '.join((f'{v:+.5f}' for v in pr))
        print(f'  d{d:>3}  {nm:<14}  {rv:.6f}  {ev:.2e}  {fs}')
        print(f'       actual:    [{vals}]')
        print(f'       predicted: [{pred}]')
        print()
else:
    print(f'\n  Top-15 closest (signed delta):')
    print(f"  {'Dim':>4}  {'Formula':<14}  {'R²':>8}  {'Err':>10}  Signed values")
    print(f"  {'─' * 80}")
    for d, rv, ev, nm, pr, fs, y in signed_results[:15]:
        vals = ' '.join((f'{v:+.5f}' for v in y))
        print(f'  d{d:>3}  {nm:<14}  {rv:.6f}  {ev:.2e}  [{vals}]')
print_sep('FINAL REPORT')
all_found = found_mag or found_dims or found_signed or (rv_r >= R2_GATE and ev_r <= ERR_GATE) or (len(ang_hw) > 0 and rv_a >= R2_GATE)
print(f'  R² gate: {R2_GATE}   Err gate: {ERR_GATE}')
print(f'\n  RESULTS:')
print(f"  Per-token magnitude:       {('FOUND ' + str(len(found_mag)) if found_mag else 'none  ')}  (best R²={best_r2_mag:.6f})")
print(f"  Per-dim |delta|:           {('FOUND ' + str(len(found_dims)) + ' dims' if found_dims else 'none  ')}")
print(f"  Delta ratio (geometric):   {('FOUND R²=' + f'{const_rv:.6f}' if const_rv >= R2_GATE else f'none  (R²={const_rv:.6f})')}")
print(f"  Per-dim signed delta:      {('FOUND ' + str(len(found_signed)) + ' dims' if found_signed else 'none  ')}")
print(f"  Direction rotation:        {('FOUND' if len(ang_hw) > 0 and rv_a >= R2_GATE else f'none  (best R²={rv_a:.6f})')}")
if all_found:
    print(f'\n  LAW FOUND.\n  The delta — what each layer ADDS — follows formula.\n  \n  This is Finding 64 confirmed:\n  natural_features(delta_N) = the law lives in the addition.\n  \n  Model = Gate_in + Highway(formula) + Gate_out.\n  Highway = calculate not compute.\n')
else:
    print(f"\n  No formula at R²=0.9999 on delta either.\n  \n  Best candidates:\n    d29: {dim_results[0][1]:.6f}  (delta)\n    signed d_top: {signed_results[0][1]:.6f}\n    ratio: {const_rv:.6f}\n  \n  What the data says at this point:\n  \n  The transformer's processing is IRREDUCIBLY complex.\n  Not because it is random.\n  But because it is ADAPTIVE.\n  \n  Each layer's delta depends on the INPUT to that layer.\n  The input changes at every layer (residual stream grows).\n  So the delta changes too — not as formula of N,\n  but as response to the current state of the stream.\n  \n  The formula is NOT: delta_N = f(N)\n  The formula IS:     delta_N = f(stream_state_at_N)\n  \n  This is the correct question for next experiment:\n  Can we predict delta_N from the stream state ENTERING layer N?\n  \n  natural_features(stream_N) @ W_N = delta_N  with R²=0.9999\n  \n  THIS is the W Principle applied to activations.\n  Not time (N), but STATE.\n")
