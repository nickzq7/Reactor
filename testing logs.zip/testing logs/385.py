import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    if s < 10:
        return (float('nan'), float('nan'))
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    return (r2(Xb[:s] @ W, Y[:s]), r2(Xb[s:] @ W, Y[s:]))

def show(name, r2_tr, r2_te, width=60):
    if not np.isfinite(r2_te):
        print(f'  {name:<{width}} NaN')
        return
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<{width}} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')

def rms_norm(x):
    rms = np.sqrt(np.mean(x ** 2, axis=1, keepdims=True)) + 1e-08
    return x / rms

def std_norm(x):
    mu = np.mean(x, axis=1, keepdims=True)
    std = np.std(x, axis=1, keepdims=True) + 1e-08
    return (x - mu) / std

def unit_norm(x):
    nrm = np.linalg.norm(x, axis=1, keepdims=True) + 1e-08
    return x / nrm

def log_space(x):
    return np.sign(x) * np.log1p(np.abs(x))

def sqrt_space(x):
    return np.sign(x) * np.sqrt(np.abs(x))

def whiten(x):
    mu = x.mean(axis=0)
    xc = x - mu
    cov = xc.T @ xc / len(xc)
    vals, vecs = np.linalg.eigh(cov)
    vals = np.maximum(vals, 1e-08)
    W = vecs @ np.diag(1.0 / np.sqrt(vals)) @ vecs.T
    return xc @ W
TRANSFORMS = {'raw': lambda x: x, 'rms': rms_norm, 'std': std_norm, 'unit': unit_norm, 'log': log_space, 'sqrt': sqrt_space}
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly in the shadows. Lily gently picked up the kitten and held it close to her heart to keep it warm.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding the animals he would go to the fields and work until the sun went down.', 'Deep in the forest there was a small house where a family of bears lived together happily. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the woods nearby. One day the baby bear followed a butterfly deep into the forest and got lost alone.', 'There was once a brave young knight who lived in a castle near the mountains high above. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go and face the dragon and bring peace to the kingdom.', 'A small girl named Sophie loved books more than anything else in the whole wide world today. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her stories directly.', 'The little village sat quietly at the edge of a great forest full of ancient tall trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest time. Children would run through the market eating apples and drinking warm spiced cider joyfully. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight came.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him. The first night Tommy shone the light and saw only his toys and books and nothing scary. His father explained that darkness was just the absence of light and nothing more.', 'The ocean was vast and blue and stretched as far as the eye could possibly see each day. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water. One night a terrible storm came and blew his boat far off course into unknown waters far. When morning came he saw an island he had never seen before on any map.', 'High up in the mountains there was a small school where children came from very far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way. Some children learned by reading and some by drawing and some by building things with hands. She gave each child the kind of lesson that matched the way their mind worked.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished and it had a rope ladder and window.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the path and picked it up. The stone glowed with a soft blue light that pulsed slowly like a heartbeat in her paw. She brought it home and placed it in her burrow where it lit up warmly.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest. She spent her days tending her garden and feeding the birds that came to visit her daily. Every evening she would sit by the fire and read her old favorite books by the light. One day a lost child appeared at her door cold and hungry and very frightened alone. She welcomed the child inside and gave food and warmth and comfort without hesitation.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day. The puppy was wet and cold and very hungry and it looked up at him with big eyes. Sam picked up the puppy and carried it home carefully to show his mother right away. His mother smiled and said they could keep the puppy if Sam promised to care for it. Sam promised and from that day on the puppy followed him everywhere he went.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone before. Every day she would watch the village below and wish she could play with the children there. One day a brave girl climbed the mountain and sat down quietly beside the dragon alone. The dragon was surprised but did not fly away because the girl was kind and gentle. They talked for hours and from that day became the best of friends forever.', 'In the deep blue ocean there lived a curious fish who wanted to see the world above it. Every day she would swim to the surface and peek at the sky and the tall green trees. One morning she jumped very high and for a moment she could see everything around her. She saw hills and rivers and roads and tiny people walking far below in distance. From that day she knew the world was much bigger than her small blue ocean.', 'The old clock in the corner of the room had not worked for many many long quiet years. One rainy afternoon the little girl decided to try to fix it with her small toy tools. She turned the gears carefully and wound the spring slowly and tightened every loose screw. Suddenly with a soft click and a gentle whir the clock began to tick again steadily. The girl smiled proudly and her grandfather hugged her and said she was very clever indeed.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below. Rain fell gently on it for many days and the warm sun shone down on the earth always. Slowly a small green shoot appeared pushing up through the dark soil toward the bright light. It grew taller every day stretching upward until it became a sapling strong and straight. Years later it was a great tree itself with birds nesting in its leafy branches.', 'The young painter stood in front of the blank white canvas and did not know where to start. She dipped her brush in the bright blue paint and made one small careful stroke across it. Then she added yellow and red and slowly a beautiful sunrise began to appear before her. She painted clouds and birds and a river winding through green fields in the valley. When she finished she stepped back and saw it was the most beautiful thing she made.', 'Every evening the grandfather would sit in his old wooden chair and tell stories to the children. The children would gather around him and listen with wide open eyes in the warm firelight. His stories were always about adventures in faraway lands and magical creatures and brave young heroes. He remembered every detail perfectly and his voice rose and fell like music as he spoke. The children never wanted the stories to end and always begged for just one more tale.']
print(f'\nCollecting gelu activations...')
gelu_store = {li: [] for li in range(n_layers)}
cur_gelu = {li: None for li in range(n_layers)}
hooks = []
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur_gelu[l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
with torch.no_grad():
    for text in long_texts:
        for li in range(n_layers):
            cur_gelu[li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        L = toks['input_ids'].shape[1]
        for li in range(n_layers):
            if cur_gelu[li] is not None:
                for t in range(L):
                    gelu_store[li].append(cur_gelu[li][t].copy())
for h in hooks:
    h.remove()
G = {li: np.array(gelu_store[li], dtype=np.float32) for li in range(n_layers)}
N = len(G[0])
print(f'Tokens: {N}')
print(f"\n{'=' * 70}")
print(f'  SCAN A-F: Natural space of gelu transition')
print(f'  For each transform f: f(gelu_l) → f(gelu_l+1)')
print(f'  Find f where R²=1.000')
print(f"{'=' * 70}\n")
best_per_transform = {}
for tname, tfn in TRANSFORMS.items():
    print(f'\n  Transform: {tname}')
    print(f"  {'─' * 65}")
    r2s = []
    try:
        TG = {li: tfn(G[li].astype(np.float32)) for li in range(n_layers)}
        for li in range(n_layers - 1):
            if not np.all(np.isfinite(TG[li])) or not np.all(np.isfinite(TG[li + 1])):
                print(f'  layer {li}→{li + 1}: NaN/Inf')
                continue
            r2_tr, r2_te = fit_r2(TG[li], TG[li + 1])
            r2s.append(r2_te if np.isfinite(r2_te) else 0.0)
            show(f'  {tname}(gelu_{li}) → {tname}(gelu_{li + 1})', r2_tr, r2_te)
        if r2s:
            mean_r2 = float(np.mean(r2s))
            best_per_transform[tname] = mean_r2
            print(f'  Mean R²: {mean_r2:.4f}')
    except Exception as e:
        print(f'  FAILED: {e}')
print(f"\n{'=' * 70}")
print(f'  TEST E — Universal T: one matrix for ALL transitions')
print(f'  Find T: f(gelu_l) @ T = f(gelu_l+1) for ALL l')
print(f'  If found: gelu_l = T^l @ f(gelu_0). Skip all layers.')
print(f"{'=' * 70}\n")
for tname, tfn in TRANSFORMS.items():
    try:
        TG = {li: tfn(G[li].astype(np.float32)) for li in range(n_layers)}
        X_all = np.concatenate([TG[li] for li in range(n_layers - 1)], axis=0)
        Y_all = np.concatenate([TG[li + 1] for li in range(n_layers - 1)], axis=0)
        if not np.all(np.isfinite(X_all)) or not np.all(np.isfinite(Y_all)):
            print(f'  {tname}: NaN/Inf')
            continue
        n = len(X_all)
        s = int(n * 0.8)
        Xb = np.c_[X_all.astype(np.float64), np.ones(n)]
        W_univ = np.linalg.lstsq(Xb[:s], Y_all[:s].astype(np.float64), rcond=None)[0]
        pred = Xb[s:] @ W_univ
        r2_univ = r2(pred, Y_all[s:])
        T = W_univ[:-1]
        bias = W_univ[-1:]
        r2_power = []
        TG0_curr = TG[0].astype(np.float64).copy()
        for li in range(1, n_layers):
            TG0_curr = TG0_curr @ T + bias
            target = TG[li].astype(np.float64)
            rv = r2(TG0_curr, target)
            r2_power.append(rv)
        marker_u = '✓✓ EXACT' if r2_univ > 0.9999 else '✓  NEAR' if r2_univ > 0.999 else '~  STRONG' if r2_univ > 0.95 else '·  PARTIAL' if r2_univ > 0.5 else '✗  LOW'
        power_str = '  '.join([f'l{i + 1}:{v:.3f}' for i, v in enumerate(r2_power)])
        print(f'  Universal T [{tname}]: R²_univ={r2_univ:.4f} {marker_u}')
        print(f'    T^l power: {power_str}')
    except Exception as e:
        print(f'  {tname}: FAILED: {e}')
print(f"\n{'=' * 70}")
print(f'  TEST G — Best f: f(gelu_l) → f(gelu_l+1)')
print(f'  Test ALL combinations of input and output transforms')
print(f'  Find exact pair where R²=1.000')
print(f"{'=' * 70}\n")
print(f"  {'Input→Output':<35} {'mean R² chain'}")
print(f"  {'─' * 50}")
results_g = []
for tname_in, tfn_in in TRANSFORMS.items():
    for tname_out, tfn_out in TRANSFORMS.items():
        try:
            r2s = []
            for li in range(n_layers - 1):
                X = tfn_in(G[li].astype(np.float32))
                Y = tfn_out(G[li + 1].astype(np.float32))
                if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
                    continue
                _, rv = fit_r2(X, Y)
                if np.isfinite(rv):
                    r2s.append(rv)
            if r2s:
                mean_r = float(np.mean(r2s))
                results_g.append((tname_in, tname_out, mean_r))
        except:
            pass
results_g.sort(key=lambda x: x[2], reverse=True)
for tin, tout, mr in results_g[:12]:
    marker = '✓✓ EXACT' if mr > 0.9999 else '✓  NEAR' if mr > 0.999 else '~  STRONG' if mr > 0.95 else '·  PARTIAL' if mr > 0.5 else '✗  LOW'
    print(f"  {tin}(gelu_l) → {tout}(gelu_l+1){'':10} {mr:.6f}  {marker}")
print(f"\n{'=' * 70}")
print(f'  TEST H — Whitened space')
print(f'  Whiten each layer: zero mean, identity covariance.')
print(f'  In whitened space: is T universal and exact?')
print(f"{'=' * 70}\n")
WG = {}
for li in range(n_layers):
    try:
        WG[li] = whiten(G[li].astype(np.float64)).astype(np.float32)
    except Exception as e:
        print(f'  Whiten layer {li} failed: {e}')
if WG:
    print(f'  Per-step in whitened space:')
    r2s_w = []
    for li in range(n_layers - 1):
        if li not in WG or li + 1 not in WG:
            continue
        r2_tr, r2_te = fit_r2(WG[li], WG[li + 1])
        r2s_w.append(r2_te if np.isfinite(r2_te) else 0.0)
        show(f'  white(gelu_{li}) → white(gelu_{li + 1})', r2_tr, r2_te)
    if len(WG) == n_layers:
        X_w = np.concatenate([WG[li] for li in range(n_layers - 1)], axis=0)
        Y_w = np.concatenate([WG[li + 1] for li in range(n_layers - 1)], axis=0)
        n = len(X_w)
        s = int(n * 0.8)
        Xb = np.c_[X_w.astype(np.float64), np.ones(n)]
        try:
            W_w = np.linalg.lstsq(Xb[:s], Y_w[:s].astype(np.float64), rcond=None)[0]
            r2_w_univ = r2(Xb[s:] @ W_w, Y_w[s:].astype(np.float64))
            marker_w = '✓✓ EXACT' if r2_w_univ > 0.9999 else '✓  NEAR' if r2_w_univ > 0.999 else '~  STRONG' if r2_w_univ > 0.95 else '·  PARTIAL' if r2_w_univ > 0.5 else '✗  LOW'
            print(f'\n  Universal T in whitened space: R²={r2_w_univ:.6f}  {marker_w}')
            T_w = W_w[:-1]
            b_w = W_w[-1:]
            WG0_curr = WG[0].astype(np.float64).copy()
            print(f'  T^l power test:')
            for li in range(1, n_layers):
                WG0_curr = WG0_curr @ T_w + b_w
                target = WG[li].astype(np.float64)
                rv = r2(WG0_curr, target)
                print(f'    T^{li}: R²={rv:.4f}')
        except Exception as e:
            print(f'  Universal T whitened failed: {e}')
print(f"\n{'=' * 70}")
print(f'  NATURAL SPACE SCAN — SUMMARY')
print(f"{'=' * 70}")
print(f'\n  Best transforms found:\n')
if best_per_transform:
    for tname, mr in sorted(best_per_transform.items(), key=lambda x: x[1], reverse=True):
        print(f'  {tname:<15} mean chain R² = {mr:.4f}')
print(f'\n  WHAT TO LOOK FOR:\n\n  R²=1.000 anywhere:\n    Found natural space of gelu evolution.\n    T is universal. Fixed. Law confirmed.\n    gelu_l = T^l @ f(gelu_0).\n    Skip all middle layers. Direct computation.\n\n  Best transform pair from TEST G:\n    f_in(gelu_l) → f_out(gelu_l+1) = 1.000.\n    This f_in, f_out = natural space of evolution.\n    T in this space = universal matrix.\n    Apply T^l to f_in(gelu_0). Inverse f_out. Get gelu_l.\n\n  Universal T power test:\n    T^1: R²=? T^2: R²=? ... T^7: R²=?\n    If stable: T is a true evolution operator.\n    Error accumulation tells us how many layers we can skip.\n\n  Whitened space:\n    Removes scale differences between layers.\n    T in whitened space = pure rotation matrix.\n    Rotation matrix has eigenvalues on unit circle.\n    If T^l stays on unit circle: perfect resonance.\n    Eigenvalues of T tell us resonance frequency.\n')
print('=' * 70 + '\n')
