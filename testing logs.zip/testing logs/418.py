import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'HuggingFaceTB/SmolLM-135M'
print(f'\nLoading {MODEL_NAME}...')
print(f'(First run downloads ~270MB)')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
n_kv = getattr(model.config, 'num_key_value_heads', n_heads)
n_layers = model.config.num_hidden_layers
ffn_dim = model.config.intermediate_size
print(f'D={D}  Heads={n_heads}  KV_heads={n_kv}  Layers={n_layers}  FFN_dim={ffn_dim}')
b0 = model.model.layers[0]
print(f'\nBlock children:   {[n for n, _ in b0.named_children()]}')
print(f'MLP children:     {[n for n, _ in b0.mlp.named_children()]}')
print(f'ATT children:     {[n for n, _ in b0.self_attn.named_children()]}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_r2(X, Y, split=0.8):
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X.astype(np.float32), np.ones(n, np.float32)]
    W = np.linalg.lstsq(Xb[:s], Y[:s].astype(np.float32), rcond=None)[0]
    return r2(Xb[s:] @ W, Y[s:].astype(np.float32))
seeds = ['Once upon a time', 'The scientist looked at', 'In a distant future', 'The old library held', 'A young programmer wrote', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed', 'The river flowed through', 'A dog sat quietly', 'She found the key', 'The storm was coming', 'The teacher explained how', 'A bird flew over', 'He picked up the phone', 'The car stopped suddenly', 'Deep in the forest', 'The robot walked toward', 'After many years had', 'The question was simple', 'Nobody knew what had', 'The door opened slowly']
print(f'\nGenerating {len(seeds) * 5} texts...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(5):
            torch.manual_seed(i * 50 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=35, do_sample=True, temperature=0.8 + j * 0.05, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(all_texts)} texts.')
test_layers = [0, 2, 5, 9, 14]
n_layers_actual = len(model.model.layers)
test_layers = [l for l in test_layers if l < n_layers_actual]
print(f'Testing layers: {test_layers} (model has {n_layers_actual} layers)')
store = {l: {'gate_act': [], 'ffn_out': [], 'concat': [], 'att_out': [], 'x': [], 'delta': []} for l in test_layers}
hooks = []
for li in test_layers:
    b = model.model.layers[li]

    def make(l):

        def h_swiglu_in(m, inp, out):
            store[l]['gate_act'].append(inp[0].detach().float().numpy())

        def h_ffn_out(m, inp, out):
            store[l]['ffn_out'].append(out.detach().float().numpy())

        def h_concat(m, inp, out):
            store[l]['concat'].append(inp[0].detach().float().numpy())

        def h_att_out(m, inp, out):
            store[l]['att_out'].append(out[0].detach().float().numpy())
        return (h_swiglu_in, h_ffn_out, h_concat, h_att_out)
    hs, hf, hc, ha = make(li)
    hooks += [b.mlp.down_proj.register_forward_hook(hs), b.mlp.down_proj.register_forward_hook(hf), b.self_attn.o_proj.register_forward_hook(hc), b.self_attn.o_proj.register_forward_hook(ha)]
print(f'\nRunning {len(all_texts)} forward passes (all layers at once)...')
with torch.no_grad():
    for i, text in enumerate(all_texts):
        if i % 25 == 0:
            print(f'  {i}/{len(all_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        L = toks['input_ids'].shape[1]
        out_m = model(**toks, output_hidden_states=True)
        hs_all = out_m.hidden_states
        for li in test_layers:
            x_np = hs_all[li][0].detach().float().numpy()
            x1_np = hs_all[li + 1][0].detach().float().numpy()
            store[li]['x'].append(x_np)
            store[li]['delta'].append(x1_np - x_np)
for h in hooks:
    h.remove()
print(f"\n{'=' * 72}")
print(f'  SMOLLM-135M (Llama family) — LAW FINDER')
print(f'  SwiGLU + RMSNorm + RoPE + GQA')
print(f"{'=' * 72}")
print(f"\n  {'Layer':<6} {'swiglu→ffn':<13} {'concat→att':<13} {'x→delta':<12} {'N':<8} {'ratio'}")
print(f"  {'─' * 65}")
for li in test_layers:
    s = store[li]
    GA = np.concatenate(s['gate_act']).astype(np.float32)
    FO = np.concatenate(s['ffn_out']).astype(np.float32)
    C = np.concatenate(s['concat']).astype(np.float32)
    AO = np.concatenate(s['att_out']).astype(np.float32)
    X = np.concatenate(s['x']).astype(np.float32)
    DE = np.concatenate(s['delta']).astype(np.float32)
    N = len(GA)
    ratio = N / GA.shape[1]
    r_swi = fit_r2(GA, FO)
    r_att = fit_r2(C, AO)
    r_xd = fit_r2(X, DE)

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f'  {li:<6} {f(r_swi):<13} {f(r_att):<13} {f(r_xd):<12} {N:<8} {ratio:.1f}')
print(f"\n{'=' * 72}")
print(f'\n  WHAT EACH COLUMN REVEALS:\n\n  swiglu→ffn:\n    SwiGLU natural space = gate_activated (input to down_proj).\n    gate_activated = silu(gate_proj(x)) * up_proj(x)\n    If 1.000: same law as GeLU. Natural space = activated features.\n    Needs ratio > 3. FFN_dim={ffn_dim}.\n    Need N > {ffn_dim * 3} tokens.\n\n  concat→att:\n    Input to o_proj → att_out.\n    Always 1.000 if hook correct (just o_proj multiplication).\n    Confirms Llama attention follows same law.\n\n  x→delta:\n    Raw x → full block transformation.\n    If 1.000: entire block is linear in x. Kernel possible.\n    If low: sequential steps needed. W per layer.\n\n  EXPECTED:\n    swiglu→ffn = 1.000 (needs enough data)\n    concat→att = 1.000 (always — linear projection)\n    x→delta    = 0.7-0.9 (x alone not enough, need features)\n\n  IF swiglu→ffn = 1.000:\n    SwiGLU LAW CONFIRMED.\n    Natural space = gate_activated.\n    Same principle as GeLU. Different activation. Same law.\n    W universal across FFN variants.\n')
print('=' * 72 + '\n')
