import torch
import torch.nn.functional as F
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
from scipy.optimize import curve_fit
import math, warnings
warnings.filterwarnings('ignore')
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
R2_GATE = 0.9999
ERR_GATE = 0.0001

def r2(y_true, y_pred):
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    ss_res = ((y_true - y_pred) ** 2).sum()
    ss_tot = ((y_true - y_true.mean()) ** 2).sum()
    if ss_tot < 1e-15:
        return 1.0 if ss_res < 1e-15 else 0.0
    return float(1 - ss_res / ss_tot)

def max_err(y_true, y_pred):
    return float(np.max(np.abs(np.array(y_true) - np.array(y_pred))))
print_sep('LOAD MODEL')
MODEL = 'roneneldan/TinyStories-1M'
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
try:
    model = AutoModelForCausalLM.from_pretrained(MODEL, dtype=torch.float32, use_safetensors=True)
except:
    model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.float32)
model = model.to(device)
model.eval()
n_layers = model.config.num_layers
hidden = model.config.hidden_size
print(f'  Layers={n_layers}  Hidden={hidden}')
print_sep('HOOK EVERY LAYER')
layer_activations = {}
hooks = []

def make_hook(layer_idx):

    def hook_fn(module, input, output):
        if isinstance(output, tuple):
            hidden_state = output[0]
        else:
            hidden_state = output
        layer_activations[layer_idx] = hidden_state.detach().cpu()
    return hook_fn
for li in range(n_layers):
    h = model.transformer.h[li]
    hook = h.register_forward_hook(make_hook(li))
    hooks.append(hook)
print(f'  Registered {len(hooks)} hooks — one per layer')
print_sep('CAPTURE ACTIVATIONS — FORWARD PASS')
TEST_SENTENCES = ['Once upon a time there was a little girl named Lily', 'One day the dog found a big bone in the garden', 'Tom and his friend went to the forest to play', 'The old man sat by the river and watched the fish', 'She looked at the stars and made a wish', 'The cat ran away when it heard a loud noise', 'Lily wanted to help but she did not know how', 'He was very happy when he found his toy']
sentence_data = []
for sent in TEST_SENTENCES:
    inputs = tok(sent, return_tensors='pt').to(device)
    ids = inputs['input_ids']
    tokens = tok.convert_ids_to_tokens(ids[0].tolist())
    layer_activations.clear()
    with torch.no_grad():
        _ = model(**inputs)
    n_tokens = ids.shape[1]
    acts = np.zeros((n_tokens, n_layers, hidden))
    for li in range(n_layers):
        act = layer_activations[li][0].numpy()
        acts[:, li, :] = act
    sentence_data.append({'sentence': sent, 'tokens': tokens, 'acts': acts, 'n_tokens': n_tokens})
for h in hooks:
    h.remove()
print(f'  Captured activations for {len(TEST_SENTENCES)} sentences')
print(f"  Example sentence tokens: {sentence_data[0]['tokens'][:8]}")
print_sep('ACTIVATION MAGNITUDE — FORMULA SEARCH')
print(f'\n  For each token position, across all 8 layers:\n  measure ||activation_vector||  (L2 norm).\n  \n  Does magnitude follow R²=0.9999 formula?\n  If yes → model amplifies/dampens in predictable pattern.\n')
x = np.arange(n_layers, dtype=float)

def fit_all(y):
    y = np.array(y, dtype=float)
    xf = np.arange(len(y), dtype=float)
    candidates = []
    pred = np.full_like(y, y.mean())
    candidates.append((r2(y, pred), max_err(y, pred), 'constant', pred, f'C={y.mean():.4f}'))
    c = np.polyfit(xf, y, 1)
    pred = np.polyval(c, xf)
    candidates.append((r2(y, pred), max_err(y, pred), 'linear', pred, f'{c[0]:+.4f}*N+{c[1]:.4f}'))
    c = np.polyfit(xf, y, 2)
    pred = np.polyval(c, xf)
    candidates.append((r2(y, pred), max_err(y, pred), 'quadratic', pred, f'{c[0]:+.4f}N²+{c[1]:+.4f}N+{c[2]:.4f}'))
    if np.all(y > 0):
        try:
            c = np.polyfit(xf, np.log(y), 1)
            pred = np.exp(c[1]) * np.exp(c[0] * xf)
            candidates.append((r2(y, pred), max_err(y, pred), 'geometric', pred, f'{np.exp(c[1]):.4f}*{np.exp(c[0]):.6f}^N'))
        except:
            pass
    try:

        def fsin(n, A, w, phi, C):
            return A * np.sin(w * n + phi) + C
        A0 = (y.max() - y.min()) / 2
        C0 = y.mean()
        popt, _ = curve_fit(fsin, xf, y, p0=[A0, np.pi / 4, 0, C0], maxfev=10000)
        pred = fsin(xf, *popt)
        candidates.append((r2(y, pred), max_err(y, pred), 'sinusoidal', pred, f'{popt[0]:.4f}*sin({popt[1]:.4f}N+{popt[2]:.4f})+{popt[3]:.4f}'))
    except:
        pass
    try:

        def fedec(n, A, k, C):
            return A * np.exp(-k * n) + C
        popt, _ = curve_fit(fedec, xf, y, p0=[y[0] - y[-1], 0.1, y[-1]], maxfev=5000)
        pred = fedec(xf, *popt)
        candidates.append((r2(y, pred), max_err(y, pred), 'exp_decay', pred, f'{popt[0]:.4f}*exp(-{popt[1]:.4f}N)+{popt[2]:.4f}'))
    except:
        pass
    try:

        def fpow(n, A, p, C):
            return A * (n + 1) ** p + C
        popt, _ = curve_fit(fpow, xf, y, p0=[1, 0.5, 0], maxfev=5000)
        pred = fpow(xf, *popt)
        candidates.append((r2(y, pred), max_err(y, pred), 'power', pred, f'{popt[0]:.4f}*(N+1)^{popt[1]:.4f}+{popt[2]:.4f}'))
    except:
        pass
    candidates.sort(key=lambda c: -c[0])
    return candidates[0] if candidates else (0, 999, 'none', y, '')
all_magnitudes = []
found_formulas = []
for sd in sentence_data:
    acts = sd['acts']
    tokens = sd['tokens']
    for ti in range(sd['n_tokens']):
        mags = np.array([np.linalg.norm(acts[ti, li]) for li in range(n_layers)])
        all_magnitudes.append(mags)
        rv, ev, name, pred, desc = fit_all(mags)
        if rv >= R2_GATE and ev <= ERR_GATE:
            found_formulas.append({'sentence': sd['sentence'][:40], 'token': tokens[ti], 'formula': name, 'r2': rv, 'err': ev, 'desc': desc, 'actual': mags, 'pred': pred})
print(f'  Total token-positions analyzed: {len(all_magnitudes)}')
print(f'  Formulas found (R²≥0.9999, err≤1e-4): {len(found_formulas)}')
print()
if found_formulas:
    print(f"  {'Token':<12}  {'Formula':<14}  {'R²':>8}  {'MaxErr':>10}  Formula")
    print(f"  {'─' * 75}")
    for f in found_formulas[:20]:
        print(f"  {f['token']:<12}  {f['formula']:<14}  {f['r2']:.6f}  {f['err']:.2e}  {f['desc']}")
else:
    print(f'  No per-token magnitude formulas at R²=0.9999.')
avg_mags = np.mean(all_magnitudes, axis=0)
print(f'\n  Average magnitude per layer: {avg_mags.round(4)}')
rv, ev, name, pred, desc = fit_all(avg_mags)
print(f'  Best formula on average: {name}  R²={rv:.6f}  err={ev:.2e}')
if rv >= R2_GATE:
    print(f'  ← LAW FOUND: {desc}')
print_sep('ACTIVATION DIMENSION PATTERN — WHICH DIMS FIRE?')
print(f'\n  For each layer, across all tokens:\n  Which dimensions have highest average |activation|?\n  \n  If same dims fire at every layer → shared active subspace.\n  If completely different dims → each layer truly orthogonal.\n  \n  This is the dynamic version of the static W direction search.\n')
TOP_K = 16
avg_act_per_dim = np.zeros((n_layers, hidden))
n_total = 0
for sd in sentence_data:
    acts = sd['acts']
    avg_act_per_dim += np.abs(acts).mean(axis=0)
    n_total += 1
avg_act_per_dim /= n_total
layer_top_dims = {}
for li in range(n_layers):
    top = np.argsort(avg_act_per_dim[li])[::-1][:TOP_K]
    layer_top_dims[li] = set(top.tolist())
print(f'  Top-{TOP_K} active dimensions per layer:')
print(f"  {'Layer':<8}  {'Top dims (sorted by activation)':}")
print(f"  {'─' * 70}")
for li in range(n_layers):
    top = sorted(layer_top_dims[li], key=lambda d: -avg_act_per_dim[li][d])[:8]
    vals = [f'd{d}({avg_act_per_dim[li][d]:.2f})' for d in top]
    print(f"  Layer {li}:  {', '.join(vals)}")
print(f'\n  Pairwise overlap of top-{TOP_K} dims (fraction shared):')
print(f"  {'':6}", end='')
for li in range(n_layers):
    print(f'  L{li}', end='')
print()
for li in range(n_layers):
    print(f'  L{li}    ', end='')
    for lj in range(n_layers):
        overlap = len(layer_top_dims[li] & layer_top_dims[lj]) / TOP_K
        marker = f'{overlap:.2f}'
        print(f'  {marker}', end='')
    print()
all_active = layer_top_dims[0].copy()
for li in range(1, n_layers):
    all_active &= layer_top_dims[li]
any_active = layer_top_dims[0].copy()
for li in range(1, n_layers):
    any_active |= layer_top_dims[li]
print(f'\n  Dims active in ALL {n_layers} layers:  {sorted(all_active)} ({len(all_active)} dims)')
print(f'  Dims active in ANY layer:  {len(any_active)} dims')
print(f'  Consistency: {len(all_active) / TOP_K:.1%} of top-{TOP_K} shared by all layers')
print_sep('ACTIVATION DIRECTION — LAYER-TO-LAYER ROTATION')
print(f'\n  W matrices rotated ~87° each layer (nearly orthogonal).\n  Do ACTIVATIONS also rotate by constant angle?\n  \n  If yes → activation journey follows formula.\n  If random → each layer truly independent.\n')
avg_act_vec = np.zeros((n_layers, hidden))
count = 0
for sd in sentence_data:
    acts = sd['acts']
    avg_act_vec += acts.mean(axis=0)
    count += 1
avg_act_vec /= count
cos_sims = []
angles = []
for li in range(n_layers - 1):
    a = avg_act_vec[li]
    b = avg_act_vec[li + 1]
    cos = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-10))
    cos = np.clip(cos, -1, 1)
    angle = float(np.degrees(np.arccos(cos)))
    cos_sims.append(cos)
    angles.append(angle)
print(f'  Layer-to-layer cosine similarity:')
for i, (cs, ang) in enumerate(zip(cos_sims, angles)):
    print(f'  L{i}→L{i + 1}: cos={cs:.4f}  angle={ang:.2f}°')
angle_arr = np.array(angles)
rv_ang = r2(angle_arr, [angle_arr.mean()] * len(angle_arr))
ev_ang = max_err(angle_arr, [angle_arr.mean()] * len(angle_arr))
print(f'\n  R²(constant angle): {rv_ang:.6f}  max_err={ev_ang:.4f}°')
if rv_ang >= R2_GATE:
    print(f'  ← LAW: activation rotates {angle_arr.mean():.2f}° per layer')
else:
    print(f'  No constant rotation law at R²=0.9999')
    best_rv, best_ev, best_name, best_pred, best_desc = fit_all(angle_arr)
    print(f'  Best formula: {best_name}  R²={best_rv:.6f}  {best_desc}')
print_sep('PER-DIMENSION ACTIVATION — FORMULA PER DIM')
print(f'\n  For each of the 64 hidden dimensions:\n  Collect its activation value at each of 8 layers.\n  Averaged across all tokens and sentences.\n  \n  Does dim_d activation follow R²=0.9999 formula across layers?\n  \n  If yes for any dim → that dimension has a law.\n  That law = the formula governing that feature across depth.\n')
dim_formulas = {}
print(f"  {'Dim':>4}  {'Formula':<14}  {'R²':>8}  {'MaxErr':>10}  Values across layers")
print(f"  {'─' * 80}")
best_r2_ever = 0
best_dim = -1
for d in range(hidden):
    y = avg_act_per_dim[:, d]
    rv, ev, name, pred, desc = fit_all(y)
    if rv > best_r2_ever:
        best_r2_ever = rv
        best_dim = d
    if rv >= R2_GATE and ev <= ERR_GATE:
        dim_formulas[d] = (name, rv, ev, desc, y)
        vals = ' '.join((f'{v:.3f}' for v in y))
        print(f'  d{d:>3}  {name:<14}  {rv:.6f}  {ev:.2e}  [{vals}]')
if not dim_formulas:
    print(f'  No per-dimension formulas at R²=0.9999.')
    print(f'  Best R² found: {best_r2_ever:.6f}  (dim {best_dim})')
    y = avg_act_per_dim[:, best_dim]
    rv, ev, name, pred, desc = fit_all(y)
    vals = ' '.join((f'{v:.3f}' for v in y))
    print(f'  Best dim d{best_dim}: {name}  R²={rv:.6f}  [{vals}]')
    print(f'  Formula: {desc}')
print_sep('ATTENTION WEIGHTS — FORMULA ACROSS LAYERS')
print(f'\n  Capture actual attention weights during forward pass.\n  For each layer: what fraction of attention is on:\n    - current token (self)\n    - previous token\n    - first token\n    - last token\n  \n  Does attention distribution follow formula across layers?\n  This is the most direct measure of what model "thinks about"\n  at each depth.\n')
attn_weights_all = {}
attn_hooks = []

def make_attn_hook(li):

    def hook_fn(module, input, output):
        pass
    return hook_fn

def get_attention_pattern(sentence):
    inputs = tok(sentence, return_tensors='pt').to(device)
    with torch.no_grad():
        out = model(**inputs, output_attentions=True)
    return (out.attentions, inputs['input_ids'].shape[1])
test_sent = 'Once upon a time there was a little girl'
attns, seq_len = get_attention_pattern(test_sent)
print(f"  Sentence: '{test_sent}'")
print(f'  Tokens: {seq_len}')
print()
attn_entropies = []
attn_self_weights = []
attn_first_weights = []
for li in range(n_layers):
    A = attns[li][0].cpu().numpy()
    A_avg = A.mean(axis=0)
    ents = []
    for pos in range(seq_len):
        a = A_avg[pos, :pos + 1]
        if a.sum() > 0:
            a = a / a.sum()
            ent = float(-(a * np.log(a + 1e-12)).sum())
            ents.append(ent)
    avg_ent = np.mean(ents)
    attn_entropies.append(avg_ent)
    self_w = float(np.diag(A_avg).mean())
    attn_self_weights.append(self_w)
    first_w = float(A_avg[:, 0].mean())
    attn_first_weights.append(first_w)
print(f'  Attention entropy per layer (higher=more spread):')
vals = ' '.join((f'{v:.4f}' for v in attn_entropies))
print(f'  [{vals}]')
rv_ent, ev_ent, nm_ent, pr_ent, ds_ent = fit_all(np.array(attn_entropies))
print(f'  Best formula: {nm_ent}  R²={rv_ent:.6f}  err={ev_ent:.2e}')
if rv_ent >= R2_GATE:
    print(f'  ← LAW FOUND: {ds_ent}')
print(f'\n  Self-attention weight per layer:')
vals = ' '.join((f'{v:.4f}' for v in attn_self_weights))
print(f'  [{vals}]')
rv_s, ev_s, nm_s, pr_s, ds_s = fit_all(np.array(attn_self_weights))
print(f'  Best formula: {nm_s}  R²={rv_s:.6f}  err={ev_s:.2e}')
if rv_s >= R2_GATE:
    print(f'  ← LAW FOUND: {ds_s}')
print(f'\n  First-token attention per layer:')
vals = ' '.join((f'{v:.4f}' for v in attn_first_weights))
print(f'  [{vals}]')
rv_f, ev_f, nm_f, pr_f, ds_f = fit_all(np.array(attn_first_weights))
print(f'  Best formula: {nm_f}  R²={rv_f:.6f}  err={ev_f:.2e}')
if rv_f >= R2_GATE:
    print(f'  ← LAW FOUND: {ds_f}')
print_sep('FINAL REPORT — WHAT ACTIVATIONS SAY')
laws_found = []
if found_formulas:
    laws_found.append(f'Per-token magnitude: {len(found_formulas)} tokens')
if dim_formulas:
    laws_found.append(f'Per-dimension: {len(dim_formulas)} dims')
if rv_ang >= R2_GATE:
    laws_found.append(f'Rotation angle: {angle_arr.mean():.2f}° constant')
if rv_ent >= R2_GATE:
    laws_found.append(f'Attention entropy: {ds_ent}')
if rv_s >= R2_GATE:
    laws_found.append(f'Self-attention: {ds_s}')
if rv_f >= R2_GATE:
    laws_found.append(f'First-token attention: {ds_f}')
print(f'\n  R² GATE: {R2_GATE}  ERR GATE: {ERR_GATE}')
print(f'\n  Laws found at R²=0.9999:')
if laws_found:
    for law in laws_found:
        print(f'    ← {law}')
else:
    print(f'    None found at R²=0.9999')
print(f"\n  WHAT THIS MEANS:\n\n  Static analysis (W matrices):\n    - 0 shared directions across layers\n    - No depth formula for token coordinates\n    - sv_entropy approximately constant (±2%)\n\n  Dynamic analysis (activations):\n    - Magnitude: {('formula found' if found_formulas else 'no formula')}\n    - Dimensions: {('formula found in ' + str(len(dim_formulas)) + ' dims' if dim_formulas else 'no formula')}\n    - Rotation: {('law found' if rv_ang >= R2_GATE else 'no constant rotation')}\n    - Attention entropy: {('law found' if rv_ent >= R2_GATE else 'no formula')}\n    - Self-attention: {('law found' if rv_s >= R2_GATE else 'no formula')}\n    - First-token: {('law found' if rv_f >= R2_GATE else 'no formula')}\n\n  Shared active dimensions in ALL layers: {len(all_active)}/{TOP_K}\n  These are the DYNAMIC HIGHWAY — dims that always fire.\n  {('Dims: ' + str(sorted(all_active)) if all_active else 'No dims active in all layers.')}\n\n  The data speaks honestly.\n  Whatever was found is real.\n  Whatever was not found — the model has no formula there.\n  That is also a real finding.\n")
