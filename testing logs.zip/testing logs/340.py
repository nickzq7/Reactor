import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from collections import Counter
print('\n' + '=' * 75)
print('  W — SEMANTIC HUB ENGINE (1K TOKEN LIVE DUAL TEST)')
print('  Live Comparison: Baseline vs. W-Hub across 1,000 Tokens.')
print('=' * 75)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
JUMP_LENGTH = 3
UNIVERSAL_QUORUM = n_layers // 2 + 1
print('\n  [ Phase 1 ] Building W-Atlas (Massive Saturation)...')
set_a_prompts = ['Once upon a time, a little girl named Lily', 'The dragon lived in a cave', 'A dog and a cat were friends', 'The sun is very hot', 'The bird sings', 'The knight had a sword', 'A king sat on a throne', 'The forest was dark', 'A small rabbit hopped', 'The old man walked', 'A red car drove', 'The stars are bright', 'A fish swims', 'The giant was big', 'A teacher told a story', 'She wore a blue dress', 'The rain fell', 'A boy played with a ball', 'The moon is round', 'A flower grows', 'The water is cold', 'A horse runs fast', 'The book is old', 'A map shows the way', 'The cat likes milk', 'A baby sleeps', 'The wind blew through the trees', 'The apple was red and sweet', 'He found a shiny coin on the ground', 'The butterfly flew over the garden', 'A clever fox hid in the bushes', 'The farmer planted seeds in the soil', 'A little mouse found a piece of cheese', 'The wizard used a magic wand']
RAM_chains = {l: [] for l in range(n_layers)}
RAM_sequences = {l: [] for l in range(n_layers)}
store_key = {l: [] for l in range(n_layers)}

def hook_key(l):

    def hook(m, i, o):
        store_key[l].append((o[:, -1, :] > 0).detach().cpu().numpy().astype(int))
    return hook
hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(hook_key(l)) for l in range(n_layers)]
with torch.no_grad():
    for s in set_a_prompts:
        ids = tokenizer.encode(s, return_tensors='pt')
        window_history = {l: [] for l in range(n_layers)}
        for _ in range(45):
            out = model(ids)
            next_id = torch.argmax(out.logits[0, -1, :]).item()
            for l in range(n_layers):
                k_bits = store_key[l].pop()[0]
                window_history[l].append(k_bits)
                if len(window_history[l]) > 4:
                    window_history[l].pop(0)
                if len(window_history[l]) == 4:
                    RAM_chains[l].append(np.concatenate(window_history[l]))
                    RAM_sequences[l].append(next_id)
            ids = torch.cat([ids, torch.tensor([[next_id]])], dim=1)
for h in hooks:
    h.remove()
for l in range(n_layers):
    RAM_chains[l] = np.array(RAM_chains[l])
    tokens = np.array(RAM_sequences[l])
    seqs = [tuple(tokens[i:i + JUMP_LENGTH].tolist()) for i in range(len(tokens) - JUMP_LENGTH)]
    RAM_chains[l], RAM_sequences[l] = (RAM_chains[l][:len(seqs)], seqs)
print(f'  ✓ Saturated {len(RAM_sequences[0])} W-Atlas Chains.')
test_prompt = 'The brave knight took his sword and'
tokens_to_gen = 1000
print('\n' + '─' * 75)
print(f'  [ Phase 2 ] THE RACE: BASELINE vs. ADAPTIVE ATLAS (1,000 TOKENS)')
print('─' * 75)
print('\n' + '=' * 30 + ' BASELINE (NORMAL) START ' + '=' * 30)
print(f'Prompt: {test_prompt}', end=' ', flush=True)
baseline_ids = tokenizer.encode(test_prompt, return_tensors='pt')
start_time_base = time.time()
with torch.no_grad():
    for i in range(tokens_to_gen):
        out = model(baseline_ids)
        next_id = torch.argmax(out.logits[0, -1, :]).item()
        baseline_ids = torch.cat([baseline_ids, torch.tensor([[next_id]])], dim=1)
        word = tokenizer.decode([next_id])
        print(word, end='', flush=True)
normal_time = time.time() - start_time_base
baseline_text = tokenizer.decode(baseline_ids[0])
print('\n' + '=' * 31 + ' BASELINE (NORMAL) END ' + '=' * 31)
print('\n' + '=' * 30 + ' W-HUB ENGINE START ' + '=' * 30)
print(f'Prompt: {test_prompt}', end=' ', flush=True)
atlas_history = {l: [] for l in range(n_layers)}
live_key = {l: None for l in range(n_layers)}

def get_key_hook(l):

    def hook(m, i, o):
        live_key[l] = (o[:, -1, :] > 0).detach().cpu().numpy().astype(int)[0]
    return hook
live_hooks = [model.transformer.h[l].attn.attention.k_proj.register_forward_hook(get_key_hook(l)) for l in range(n_layers)]
hub_ids = tokenizer.encode(test_prompt, return_tensors='pt')
total_gen = 0
jumps_done = 0
start_time_hub = time.time()
with torch.no_grad():
    while total_gen < tokens_to_gen:
        out = model(hub_ids)
        probs = torch.nn.functional.softmax(out.logits[0, -1, :], dim=-1)
        top_probs, top_indices = torch.topk(probs, 2)
        confidence_margin = top_probs[0].item() - top_probs[1].item()
        truth_id = top_indices[0].item()
        for l in range(n_layers):
            atlas_history[l].append(live_key[l])
            if len(atlas_history[l]) > 4:
                atlas_history[l].pop(0)
        jump_found = False
        if confidence_margin > 0.35 and len(atlas_history[0]) == 4:
            votes = []
            for l in range(n_layers):
                current_atlas = np.concatenate(atlas_history[l])
                mismatches = 1024 - np.sum(RAM_chains[l] == current_atlas, axis=1)
                if len(mismatches) > 0:
                    best_idx = np.argmin(mismatches)
                    if mismatches[best_idx] <= 40:
                        votes.append(RAM_sequences[l][best_idx])
            if votes:
                vote_counts = Counter(votes)
                top_sequence, count = vote_counts.most_common(1)[0]
                if count >= UNIVERSAL_QUORUM and top_sequence[0] == truth_id:
                    jump_ids_list = list(top_sequence)
                    hub_ids = torch.cat([hub_ids, torch.tensor([jump_ids_list])], dim=1)
                    jump_text = tokenizer.decode(jump_ids_list)
                    print(f'\x1b[92m{jump_text}\x1b[0m', end='', flush=True)
                    for layer in range(n_layers):
                        atlas_history[layer] = []
                    total_gen += JUMP_LENGTH
                    jumps_done += 1
                    jump_found = True
        if not jump_found:
            hub_ids = torch.cat([hub_ids, torch.tensor([[truth_id]])], dim=1)
            word = tokenizer.decode([truth_id])
            print(word, end='', flush=True)
            total_gen += 1
for h in live_hooks:
    h.remove()
hub_time = time.time() - start_time_hub
hub_text = tokenizer.decode(hub_ids[0])
print('\n' + '=' * 31 + ' W-HUB ENGINE END ' + '=' * 31)
b_words = baseline_text.split()
h_words = hub_text.split()
matches = 0
for i in range(min(len(b_words), len(h_words))):
    if b_words[i] == h_words[i]:
        matches += 1
match_pct = matches / len(b_words) * 100
print('\n' + '=' * 75)
print(f'  ENDURANCE RESULTS:')
print(f'  Standard Time    : {normal_time:.4f}s')
print(f'  W-Hub Time       : {hub_time:.4f}s')
print(f'  Successful Jumps : {jumps_done}')
print(f'  Word Match Score : {matches} / {len(b_words)} ({match_pct:.1f}%)')
print('=' * 75 + '\n')
