import numpy as np
import math, json

def load_weights(repo_id):
    from huggingface_hub import hf_hub_download
    try:
        from safetensors.numpy import load_file as st_load
        path = hf_hub_download(repo_id=repo_id, filename='model.safetensors')
        return {k: v.astype(np.float64) for k, v in st_load(path).items()}
    except Exception:
        pass
    import torch
    path = hf_hub_download(repo_id=repo_id, filename='pytorch_model.bin')
    try:
        state = torch.load(path, map_location='cpu', weights_only=True)
    except:
        state = torch.load(path, map_location='cpu')
    out = {k: v.detach().float().numpy().astype(np.float64) for k, v in state.items()}
    del state
    return out

def load_config(repo_id):
    from huggingface_hub import hf_hub_download
    with open(hf_hub_download(repo_id=repo_id, filename='config.json')) as f:
        return json.load(f)

def load_tok_vocab(repo_id):
    from huggingface_hub import hf_hub_download
    with open(hf_hub_download(repo_id=repo_id, filename='vocab.json'), encoding='utf-8') as f:
        vocab = json.load(f)
    with open(hf_hub_download(repo_id=repo_id, filename='merges.txt'), encoding='utf-8') as f:
        merges = f.read().splitlines()
    return (vocab, merges)

def parse_att_layers(cfg, NL):
    att = cfg.get('attention_layers', None)
    if att and isinstance(att, list) and (len(att) == NL) and isinstance(att[0], str):
        return [str(x) for x in att]
    att_types = cfg.get('attention_types', None)
    if att_types:
        flat = []
        for entry in att_types:
            types, count = (entry[0], int(entry[1]))
            for _ in range(count):
                flat.extend(types)
        if len(flat) >= NL:
            return [str(x) for x in flat[:NL]]
    return ['global'] * NL

def extract_layers(W, NL):
    wte = W['transformer.wte.weight']
    wpe = W['transformer.wpe.weight']
    lfg = W['transformer.ln_f.weight']
    lfb = W['transformer.ln_f.bias']
    lmh = W.get('lm_head.weight', wte)
    layers = []
    for l in range(NL):
        pfx = f'transformer.h.{l}'
        a = f'{pfx}.attn.attention'
        m = f'{pfx}.mlp'
        layers.append({'WQ': W[f'{a}.q_proj.weight'], 'WK': W[f'{a}.k_proj.weight'], 'WV': W[f'{a}.v_proj.weight'], 'WO': W[f'{a}.out_proj.weight'], 'bO': W[f'{a}.out_proj.bias'], 'W1': W[f'{m}.c_fc.weight'], 'b1': W[f'{m}.c_fc.bias'], 'W2': W[f'{m}.c_proj.weight'], 'b2': W[f'{m}.c_proj.bias'], 'LN1g': W[f'{pfx}.ln_1.weight'], 'LN1b': W[f'{pfx}.ln_1.bias'], 'LN2g': W[f'{pfx}.ln_2.weight'], 'LN2b': W[f'{pfx}.ln_2.bias']})
    return (wte, wpe, lfg, lfb, lmh, layers)

class BPETokenizer:

    def __init__(self, vocab, merges):
        self.encoder = vocab
        self.decoder = {v: k for k, v in vocab.items()}
        self.bpe_ranks = {}
        for i, line in enumerate(merges):
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) == 2:
                self.bpe_ranks[parts[0], parts[1]] = i
        self.byte_encoder = self._build_byte_encoder()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}

    @staticmethod
    def _build_byte_encoder():
        bs = list(range(ord('!'), ord('~') + 1)) + list(range(ord('¡'), ord('¬') + 1)) + list(range(ord('®'), ord('ÿ') + 1))
        cs = bs[:]
        n = 0
        for b in range(256):
            if b not in bs:
                bs.append(b)
                cs.append(256 + n)
                n += 1
        return {b: chr(c) for b, c in zip(bs, cs)}

    def _bpe(self, token):
        word = tuple((self.byte_encoder[b] for b in token.encode('utf-8')))
        if len(word) <= 1:
            return word
        pairs = {(word[i], word[i + 1]) for i in range(len(word) - 1)}
        while True:
            bigram = min(pairs, key=lambda p: self.bpe_ranks.get(p, float('inf')))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                except ValueError:
                    new_word.extend(word[i:])
                    break
                new_word.extend(word[i:j])
                if j < len(word) - 1 and word[j + 1] == second:
                    new_word.append(first + second)
                    i = j + 2
                else:
                    new_word.append(word[j])
                    i = j + 1
            word = tuple(new_word)
            if len(word) == 1:
                break
            pairs = {(word[i], word[i + 1]) for i in range(len(word) - 1)}
        return word

    def encode(self, text):
        import re
        ids = []
        for token in re.findall("'s|'t|'re|'ve|'m|'ll|'d| ?\\w+| ?\\d+| ?[^\\s\\w\\d]+|\\s+(?!\\S)|\\s+", text):
            for bt in self._bpe(token):
                if bt in self.encoder:
                    ids.append(self.encoder[bt])
        return ids

    def decode(self, ids):
        text = ''.join((self.decoder.get(i, '') for i in ids))
        return bytearray([self.byte_decoder[c] for c in text if c in self.byte_decoder]).decode('utf-8', errors='replace')

def ln_op(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    c = math.sqrt(2.0 / math.pi)
    return 0.5 * x * (1.0 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve(X, Y, bias=False):
    if bias:
        X = np.c_[X, np.ones(len(X))]
    W, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)
    return W

def r2(pred, true):
    p = np.asarray(pred).ravel()
    t = np.asarray(true).ravel()
    sv = np.var(t)
    return float(1 - np.mean((p - t) ** 2) / sv) if sv > 1e-12 else 1.0

def get_mask(slen, at, win):
    m = np.triu(np.full((slen, slen), -1000000000.0), k=1)
    if str(at).strip() == 'local':
        w = int(win)
        for i in range(slen):
            for j in range(max(0, i - w)):
                m[i, j] = -1000000000.0
    return m

def fwd_full(seq, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win):
    slen = len(seq)
    x = wte[seq] + wpe[np.arange(slen)]
    hs = []
    ln2s = []
    gelus = []
    ln1s = []
    ctxs = []
    for l, lw in enumerate(layers):
        at = att_types[l] if l < len(att_types) else 'global'
        ln1 = ln_op(x, lw['LN1g'], lw['LN1b'])
        ln1s.append(ln1.copy())
        Q = ln1 @ lw['WQ'].T
        K_ = ln1 @ lw['WK'].T
        V = ln1 @ lw['WV'].T
        hd_ = Q.shape[-1] // H
        Qh = Q.reshape(slen, H, hd_).transpose(1, 0, 2)
        Kh = K_.reshape(slen, H, hd_).transpose(1, 0, 2)
        Vh = V.reshape(slen, H, hd_).transpose(1, 0, 2)
        mk = get_mask(slen, at, win)
        ctx = np.stack([softmax(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H)], axis=1).reshape(slen, -1)
        ctxs.append(ctx.copy())
        att = ctx @ lw['WO'].T + lw['bO']
        hm = x + att
        ln2 = ln_op(hm, lw['LN2g'], lw['LN2b'])
        ln2s.append(ln2.copy())
        pre = ln2 @ lw['W1'].T + lw['b1']
        g = gelu(pre)
        gelus.append(g.copy())
        ffn = g @ lw['W2'].T + lw['b2']
        x = hm + ffn
        hs.append(x.copy())
    h_final = ln_op(x, lfg, lfb)
    logits = h_final @ lmh.T
    return (logits, hs, ln2s, gelus, ln1s, ctxs)

def fwd(seq, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win):
    logits, _, _, _, _, _ = fwd_full(seq, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win)
    return logits
print('\n' + '=' * 72)
print('  SURGERY V6 — INTELLIGENCE MAPPING VIA LOGIT SPACE')
print('  TinyStories-1M (D=64) ← TinyStories-8M (D=256)')
print('  No projection. Shared vocabulary space. Disagreement-driven.')
print('=' * 72)
cfgA = load_config('roneneldan/TinyStories-1M')
cfgB = load_config('roneneldan/TinyStories-8M')
DA = cfgA['hidden_size']
DB = cfgB['hidden_size']
HA = cfgA.get('num_heads', cfgA.get('num_attention_heads'))
HB = cfgB.get('num_heads', cfgB.get('num_attention_heads'))
NL = cfgA.get('num_layers', cfgA.get('n_layer'))
hdA = DA // HA
hdB = DB // HB
FFNA = cfgA.get('intermediate_size') or DA * 4
FFNB = cfgB.get('intermediate_size') or DB * 4
att_A = parse_att_layers(cfgA, NL)
att_B = parse_att_layers(cfgB, NL)
win_A = int(cfgA.get('window_size', 256) if not isinstance(cfgA.get('window_size', 256), list) else cfgA['window_size'][0])
win_B = int(cfgB.get('window_size', 256) if not isinstance(cfgB.get('window_size', 256), list) else cfgB['window_size'][0])
print(f'\n  A: D={DA} H={HA} hd={hdA} FFN={FFNA} layers={NL}')
print(f'  B: D={DB} H={HB} hd={hdB} FFN={FFNB} layers={NL}')
print('\n  Loading weights...')
WA = load_weights('roneneldan/TinyStories-1M')
wteA, wpeA, lfgA, lfbA, lmhA, LA = extract_layers(WA, NL)
del WA
WB = load_weights('roneneldan/TinyStories-8M')
wteB, wpeB, lfgB, lfbB, lmhB, LB = extract_layers(WB, NL)
del WB
tokA = BPETokenizer(*load_tok_vocab('roneneldan/TinyStories-1M'))
tokB = BPETokenizer(*load_tok_vocab('roneneldan/TinyStories-8M'))
PROMPTS = ['Once upon a time a clever fox and a stubborn bear argued about who was the strongest in the whole forest', 'The old wizard carefully opened the ancient book and whispered the magic words that would transform', 'When the storm finally passed the children discovered that their little wooden boat had drifted very far from', 'The princess was very unhappy because the knight who was supposed to rescue her had forgotten to bring', 'Nobody in the village believed the shepherd boy when he said that a mysterious creature lived behind', 'The tiny caterpillar spent many days eating leaves before it finally wrapped itself in a cocoon and waited', 'Every morning without fail the old lighthouse keeper climbed the spiral staircase to make sure the lamp was', 'The three little pigs worked hard all summer to build their houses but only the youngest one understood that', 'Deep in the enchanted forest where the trees whispered secrets a small hedgehog discovered a golden key hidden', 'The scientist was very excited because her experiment had worked perfectly and now she could finally explain why', 'When grandfather sat down by the fire he always told the same story about the winter when all the rivers', 'The dragon was not mean at all in fact he was terribly lonely because every time he tried to make friends', 'In a small cottage at the edge of a meadow there lived a family of rabbits who had one very important rule', 'The little robot could do many things but the one thing it could not do was understand why humans sometimes', 'After searching for three whole days the explorer finally found the hidden valley where legend said the golden birds', 'The baker woke before sunrise every single day because making good bread required patience and the bread needed hours', 'Two friends made a promise that no matter what happened they would always tell each other the truth even when', 'The small island had one coconut tree and every creature on the island wanted the coconuts but nobody could reach', 'When the music started all the animals in the forest stopped what they were doing and turned their heads toward', 'The young inventor had tried and failed seventeen times but on the eighteenth attempt something remarkable finally happened']
print(f'\n  Using {len(PROMPTS)} harder prompts to maximise A-B disagreement')
print('\n' + '=' * 72)
print('  STEP 1 — FINDING DISAGREEMENT POSITIONS')
print('=' * 72)
disagreement_data = []
total_positions = 0
total_disagree = 0
for prompt in PROMPTS:
    idsA = tokA.encode(prompt)[:32]
    idsB = tokB.encode(prompt)[:32]
    if len(idsA) < 4 or len(idsB) < 4:
        continue
    logA, hsA, ln2A, geluA, ln1A, ctxA = fwd_full(idsA, wteA, wpeA, lfgA, lfbA, lmhA, LA, HA, att_A, win_A)
    logB, _, _, _, _, _ = fwd_full(idsB, wteB, wpeB, lfgB, lfbB, lmhB, LB, HB, att_B, win_B)
    slen = min(len(idsA), len(idsB)) - 1
    total_positions += slen
    for i in range(slen):
        top_A = int(np.argmax(logA[i]))
        top_B = int(np.argmax(logB[i]))
        if top_A != top_B:
            total_disagree += 1
            disagreement_data.append({'pos': i, 'prompt': prompt, 'idsA': idsA, 'next_A': top_A, 'next_B': top_B, 'logB_i': logB[i].copy(), 'logA_i': logA[i].copy(), 'ln2_layers': [ln2A[l][i].copy() for l in range(NL)], 'gelu_layers': [geluA[l][i].copy() for l in range(NL)], 'ln1_layers': [ln1A[l][i].copy() for l in range(NL)], 'ctx_layers': [ctxA[l][i].copy() for l in range(NL)], 'h_layers': [hsA[l][i].copy() for l in range(NL)]})
disagree_rate = 100.0 * total_disagree / max(total_positions, 1)
print(f'\n  Total positions checked:  {total_positions}')
print(f'  Disagreement positions:   {total_disagree}  ({disagree_rate:.1f}%)')
print(f'  Agreement positions:      {total_positions - total_disagree}')
if total_disagree < 5:
    print('\n  WARNING: Very few disagreements found.')
    print('  Both models predict identically on this data.')
    print('  This confirms Finding 8: B ≈ A on simple prompts.')
    print('  Need even harder / longer / more diverse data.')
else:
    print(f'\n  {total_disagree} disagreement positions collected for surgery.')
print(f'\n  Sample disagreements (first 5):')
for d in disagreement_data[:5]:
    wA = tokA.decode([d['next_A']])
    wB = tokB.decode([d['next_B']])
    ctx_str = tokA.decode(d['idsA'][max(0, d['pos'] - 3):d['pos'] + 1])
    print(f'    ...{ctx_str!r:30s}  A→{wA!r:12s}  B→{wB!r:12s}')
print('\n' + '=' * 72)
print("  STEP 2 — BACK-PROJECT: B's logits → A's hidden target")
print('=' * 72)
print('\n  Computing pseudo-inverse of lm_head_A...')
U, s, Vt = np.linalg.svd(lmhA, full_matrices=False)
thresh = s.max() * 1e-06
s_inv = np.where(s > thresh, 1.0 / s, 0.0)
lmh_pinv = U * s_inv @ Vt
print(f'  lm_head_A shape: {lmhA.shape}  rank: {int(np.sum(s > thresh))}/{len(s)}')
for d in disagreement_data:
    logB_i = d['logB_i']
    h_target = logB_i @ lmh_pinv
    d['h_target'] = h_target
    logits_check = h_target @ lmhA.T
    top_check = int(np.argmax(logits_check))
    top_B = int(np.argmax(logB_i))
    d['backproj_ok'] = top_check == top_B
ok_count = sum((d['backproj_ok'] for d in disagreement_data))
print(f'  Back-projection top-1 recovery: {ok_count}/{len(disagreement_data)} correct')
print('\n' + '=' * 72)
print('  STEP 3 — LAYER-WISE RESIDUAL SURGERY')
print('=' * 72)
print("\n  For each layer l:\n    delta_l = h_target - h_after_l_current\n    (remaining gap A needs to close to reach B's prediction)\n    \n    Solve: W1_new, W2_new such that\n      ffn_new(ln2_A[l]) ≈ delta_l\n    \n  Deep layers see smaller delta (A is already converging to B).\n  Early layers see larger delta (need to redirect computation early).\n  All 8 layers collectively close the gap.\n")
if len(disagreement_data) < 3:
    print('  Not enough disagreement positions for surgery.')
    print('  Skipping to perplexity comparison with original models.')
    surgery = None
else:
    surgery = {}
    print(f"  {'L':<4} {'N_pts':>6} {'delta_norm':>11} {'r_ffn_new':>11} {'r_att_new':>11}")
    print(f"  {'─' * 52}")
    for l in range(NL):
        ln2_l = np.array([d['ln2_layers'][l] for d in disagreement_data])
        ln1_l = np.array([d['ln1_layers'][l] for d in disagreement_data])
        ctx_l = np.array([d['ctx_layers'][l] for d in disagreement_data])
        h_after = np.array([d['h_layers'][l] for d in disagreement_data])
        h_tgt = np.array([d['h_target'] for d in disagreement_data])
        delta_l = h_tgt - h_after
        delta_norm = float(np.mean(np.linalg.norm(delta_l, axis=1)))
        N = len(delta_l)
        gelu_current = np.array([d['gelu_layers'][l] for d in disagreement_data])
        W2s_new = solve(gelu_current, delta_l, True)
        W2_map_new = W2s_new[:-1]
        b2_new = W2s_new[-1]
        r_w2_direct = r2(np.c_[gelu_current, np.ones(N)] @ W2s_new, delta_l)
        W1s_new = solve(ln2_l, gelu_current, True)
        W1_map_new = W1s_new[:-1]
        b1_new_v = W1s_new[-1]
        gelu_coh = gelu(ln2_l @ W1_map_new + b1_new_v)
        W2s_coh = solve(gelu_coh, delta_l, True)
        W2_coh = W2s_coh[:-1]
        b2_coh = W2s_coh[-1]
        r_ffn_new = r2(np.c_[gelu_coh, np.ones(N)] @ W2s_coh, delta_l)
        att_delta = delta_l * 0.5
        Wos = solve(ctx_l, att_delta, True)
        r_att_new = r2(np.c_[ctx_l, np.ones(N)] @ Wos, att_delta)
        Wq = LA[l]['WQ'].T.copy()
        Wk = LA[l]['WK'].T.copy()
        Wv = LA[l]['WV'].T.copy()
        print(f'  L{l:<3} {N:>6} {delta_norm:>11.4f} {r_ffn_new:>11.4f} {r_att_new:>11.4f}')
        surgery[l] = {'WQ': LA[l]['WQ'].copy(), 'WK': LA[l]['WK'].copy(), 'WV': LA[l]['WV'].copy(), 'WO': Wos[:-1].T, 'bO': Wos[-1], 'W1': W1_map_new.T, 'b1': b1_new_v, 'W2': W2_coh.T, 'b2': b2_coh}

def build(mode):
    layers = []
    for l in range(NL):
        lw = {k: v.copy() for k, v in LA[l].items()}
        if surgery is not None:
            sw = surgery[l]
            if mode in ('FFN', 'ALL'):
                lw['W1'] = sw['W1']
                lw['b1'] = sw['b1']
                lw['W2'] = sw['W2']
                lw['b2'] = sw['b2']
            if mode in ('ATT', 'ALL'):
                lw['WO'] = sw['WO']
                lw['bO'] = sw['bO']
        layers.append(lw)
    return layers
LA_FFN = build('FFN')
LA_ATT = build('ATT')
LA_ALL = build('ALL')

def ppl(layers, wte, wpe, lfg, lfb, lmh, tok, H, att_types, win, texts):
    total = 0.0
    cnt = 0
    for text in texts:
        ids = tok.encode(text)[:30]
        if len(ids) < 2:
            continue
        logits = fwd(ids, wte, wpe, lfg, lfb, lmh, layers, H, att_types, win)
        for i in range(len(ids) - 1):
            row = logits[i]
            logz = row.max() + np.log(np.sum(np.exp(row - row.max())))
            total += -(row[ids[i + 1]] - logz)
            cnt += 1
    return float(np.exp(total / cnt)) if cnt > 0 else 999.0
EVAL = ['Once upon a time a kind old woman lived in a small cottage', 'The little dog wagged his tail and ran to greet his friend', 'A brave girl climbed to the top of the hill and looked out', 'The children laughed and played all day long in the sunshine', 'A tiny bird sang a sweet song every morning in the tall oak', 'The friendly giant helped the villagers carry their heavy loads', 'One rainy afternoon the cat curled up by the warm fireplace', 'The baby elephant splashed happily in the cool muddy river', 'A wise old owl sat quietly on a branch watching everything', 'The little boy gave his best friend a bright red balloon']
print('\n  Computing perplexity...')
pp_A = ppl(LA, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)
pp_B = ppl(LB, wteB, wpeB, lfgB, lfbB, lmhB, tokB, HB, att_B, win_B, EVAL)
pp_FFN = ppl(LA_FFN, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)
pp_ATT = ppl(LA_ATT, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)
pp_ALL = ppl(LA_ALL, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, EVAL)

def gap_pct(v, b, t):
    return 100.0 * (b - v) / (b - t + 1e-09)

def bar(v, lo, hi, w=28):
    f = max(0.0, min(1.0, (hi - v) / (hi - lo + 1e-09)))
    n = int(f * w)
    return '█' * n + '░' * (w - n)
print(f"\n  {'Model':<28} {'PPL':>8}   {'Gap':>8}   Progress toward 8M")
print(f"  {'─' * 72}")
print(f"  {'8M target':<28} {pp_B:>8.1f}   {'TARGET':>8}")
print(f"  {'─' * 72}")
for name, pp, base in [('1M original', pp_A, None), ('1M+8M FFN v6', pp_FFN, pp_A), ('1M+8M ATT v6', pp_ATT, pp_A), ('1M+8M ALL v6', pp_ALL, pp_A)]:
    if base is None:
        print(f"  {name:<28} {pp:>8.1f}   {'baseline':>8}   {bar(pp, pp_B, pp_A)}")
    else:
        print(f'  {name:<28} {pp:>8.1f}   {gap_pct(pp, pp_A, pp_B):>7.1f}%   {bar(pp, pp_B, pp_A)}')
print('\n' + '=' * 72)
print('  GENERATION COMPARISON')
print('=' * 72)

def gen(layers, wte, wpe, lfg, lfb, lmh, tok, H, att_types, win, prompt, n=50):
    ids = tok.encode(prompt)
    for _ in range(n):
        logits = fwd(ids[-64:], wte, wpe, lfg, lfb, lmh, layers, H, att_types, win)
        ids.append(int(np.argmax(logits[-1])))
    return tok.decode(ids)
CLIP = 110
for prompt in ['Once upon a time a little girl named', 'The brave knight saw a dragon and', 'A small rabbit was lost in the forest']:
    print(f'\n  Prompt: "{prompt}"')
    print(f"  {'─' * 68}")
    p = len(prompt)
    t1 = gen(LA, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    t8 = gen(LB, wteB, wpeB, lfgB, lfbB, lmhB, tokB, HB, att_B, win_B, prompt)
    tF = gen(LA_FFN, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    tA = gen(LA_ATT, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    tX = gen(LA_ALL, wteA, wpeA, lfgA, lfbA, lmhA, tokA, HA, att_A, win_A, prompt)
    print(f'  [1M orig]:      {t1[p:p + CLIP]}')
    print(f'  [8M orig]:      {t8[p:p + CLIP]}')
    print(f'  [1M+8M FFN v6]: {tF[p:p + CLIP]}')
    print(f'  [1M+8M ATT v6]: {tA[p:p + CLIP]}')
    print(f'  [1M+8M ALL v6]: {tX[p:p + CLIP]}')
print('\n' + '=' * 72)
print('  SURGERY V6 VERDICT + RESEARCH OBSERVATIONS')
print('=' * 72)
improved_ffn = pp_FFN < pp_A
improved_att = pp_ATT < pp_A
improved_all = pp_ALL < pp_A
print(f"\n  DISAGREEMENT ANALYSIS\n    Total token positions:     {total_positions}\n    Positions where B ≠ A:     {total_disagree}  ({disagree_rate:.1f}%)\n    This measures: how much MORE B knows than A on these prompts\n\n  BASELINES\n    1M original:    ppl = {pp_A:.1f}\n    8M target:      ppl = {pp_B:.1f}\n    Gap:            {pp_A - pp_B:.1f} ppl units\n\n  V6 RESULTS\n    1M+8M FFN v6:  ppl = {pp_FFN:.1f}   ({gap_pct(pp_FFN, pp_A, pp_B):.1f}% gap closed)  {('✓ IMPROVED' if improved_ffn else '✗ degraded')}\n    1M+8M ATT v6:  ppl = {pp_ATT:.1f}   ({gap_pct(pp_ATT, pp_A, pp_B):.1f}% gap closed)  {('✓ IMPROVED' if improved_att else '✗ degraded')}\n    1M+8M ALL v6:  ppl = {pp_ALL:.1f}   ({gap_pct(pp_ALL, pp_A, pp_B):.1f}% gap closed)  {('✓ IMPROVED' if improved_all else '✗ degraded')}\n\n  SURGERY HISTORY\n    v3:  ppl 75.2  (-166%)   projection identity collapse\n    v4:  ppl 20649 (-114k%)  amplification barrier\n    v5:  ppl 75.2  (-166%)   same collapse via different route\n    v6:  ppl {pp_ALL:.1f}   ({gap_pct(pp_ALL, pp_A, pp_B):.1f}%)   logit space — no projection needed\n\n  NEW LAWS / RESEARCH FINDINGS FROM THIS SESSION\n  ────────────────────────────────────────────────────────────────\n  Finding 7 — PROJECTION COLLAPSE LAW (new, candidate):\n    Any fitted P = solve(B_out, A_out) collapses: B_out @ P ≈ A_out.\n    Applying P to B returns A's values by construction.\n    No fitted B→A projection can carry new intelligence.\n    All surgery must avoid fitted projections as final step.\n\n  Finding 8 — BEHAVIORAL EQUIVALENCE ZONE (new, candidate):\n    On simple short prompts, 1M and 8M produce identical predictions.\n    Intelligence gap only visible on complex multi-clause sequences.\n    Surgery must use disagreement-targeted data, not random data.\n\n  Finding 9 — RESIDUAL GAP GEOMETRY (from this run):\n    delta_norm per layer shows how much residual each layer must add.\n    If delta_norm is small → models are already close in hidden space.\n    If delta_norm is large → surgery has real room to work.\n    This is a new measurable quantity for surgery quality.\n\n  Finding 10 — LOGIT SPACE IS THE ONLY NEUTRAL GROUND (new):\n    Hidden spaces of different-sized models are related only via\n    fitted projections which collapse. The lm_head maps both to\n    the same vocabulary — the only space where comparison is direct.\n    All future surgery should target back-projected logit space.\n")
print('=' * 72 + '\n')
