import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  TEST 8 — THE EXACT CHAIN (LINEAR HIGHWAYS)')
print('  Proving the absolute linearity between crystals.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
eps = model.config.layer_norm_epsilon
store = {'lnf_in': [], 'lnf_out': [], 'w1_in': [], 'w1_out': [], 'wo_in': [], 'wo_out': []}

def hook_lnf(m, i, o):
    store['lnf_in'].append(i[0].detach().float().reshape(-1, i[0].shape[-1]).numpy())
    store['lnf_out'].append(o.detach().float().reshape(-1, o.shape[-1]).numpy())

def hook_w1(m, i, o):
    store['w1_in'].append(i[0].detach().float().reshape(-1, i[0].shape[-1]).numpy())
    store['w1_out'].append(o.detach().float().reshape(-1, o.shape[-1]).numpy())

def hook_wo(m, i, o):
    store['wo_in'].append(i[0].detach().float().reshape(-1, i[0].shape[-1]).numpy())
    store['wo_out'].append(o.detach().float().reshape(-1, o.shape[-1]).numpy())
h_lnf = model.transformer.ln_f.register_forward_hook(hook_lnf)
h_w1 = model.transformer.h[0].mlp.c_fc.register_forward_hook(hook_w1)
h_wo = model.transformer.h[0].attn.attention.out_proj.register_forward_hook(hook_wo)
starts = ['Once upon a time', 'The brave knight', 'In a dark cave', 'A little bird flew', 'The magic wand', 'Deep in the ocean']
print('  Generating data to map the highways...')
with torch.no_grad():
    for s in starts:
        inp = tokenizer.encode(s, return_tensors='pt')
        model.generate(inp, max_new_tokens=30, do_sample=True, temperature=0.8, pad_token_id=tokenizer.eos_token_id)
h_lnf.remove()
h_w1.remove()
h_wo.remove()

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 1e-10 else 1.0

def fit_eval(X, Y):
    N = len(X)
    N_tr = int(N * 0.8)
    Xb_tr = np.c_[X[:N_tr], np.ones(N_tr)]
    Xb_te = np.c_[X[N_tr:], np.ones(N - N_tr)]
    W = np.linalg.lstsq(Xb_tr, Y[:N_tr], rcond=None)[0]
    return r2(Xb_te @ W, Y[N_tr:])
print('\n' + '─' * 70)
print('  RESULTS: ARE THE HIGHWAYS PERFECTLY LINEAR?')
print('─' * 70)
X_lnf = np.concatenate(store['lnf_in'], axis=0)
Y_lnf = np.concatenate(store['lnf_out'], axis=0)
mean_lnf = np.mean(X_lnf, axis=-1, keepdims=True)
var_lnf = np.var(X_lnf, axis=-1, keepdims=True)
X_lnf_normed = (X_lnf - mean_lnf) / np.sqrt(var_lnf + eps)
r_lnf = fit_eval(X_lnf_normed, Y_lnf)

def f(v):
    return '✓ 1.000000 (EXACT)' if v > 0.99999 else f'{v:.6f}'
print(f'  Fix 1: LNF Natural Space  ((h-mean)/std) → lnf_out : {f(r_lnf)}')
X_w1 = np.concatenate(store['w1_in'], axis=0)
Y_w1 = np.concatenate(store['w1_out'], axis=0)
r_w1 = fit_eval(X_w1, Y_w1)
print(f'  Fix 2: FFN Highway        (ln2_out)      → ffn_in  : {f(r_w1)}')
X_wo = np.concatenate(store['wo_in'], axis=0)
Y_wo = np.concatenate(store['wo_out'], axis=0)
r_wo = fit_eval(X_wo, Y_wo)
print(f'  Fix 3: Attention Highway  (softmax @ V)  → att_out : {f(r_wo)}')
print('\n' + '=' * 70)
print('  HYPER LAW SUMMARY:\n  \n  If all three hit exactly 1.000000:\n    The Neural Network architecture is an illusion.\n    There are no "black boxes".\n    There are only two Crystallization Points (Softmax and GeLU).\n    Everything between them is pure, exact linear algebra.\n    \n    This is the ultimate proof that the Unified Kernel can \n    collapse the model without losing a single drop of intelligence.\n')
print('=' * 70 + '\n')
