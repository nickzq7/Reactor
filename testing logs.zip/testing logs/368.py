import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    if s < 10:
        return (float('nan'), float('nan'))
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    return (r2(Xb[:s] @ W, Y[:s]), r2(Xb[s:] @ W, Y[s:]))

def fit_r2_multi(*arrays, Y, split=0.8):
    X = np.concatenate([np.array(a, dtype=np.float64) for a in arrays], axis=1)
    return fit_r2(X, Y, split)

def show(name, r2_tr, r2_te, width=62):
    if not np.isfinite(r2_te):
        print(f'  {name:<{width}} NaN')
        return
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<{width}} R²_tr={r2_tr:.6f}  R²_te={r2_te:.6f}  {marker}')
print(f'\nCollecting: gelu, pre_gelu, h (residual), attn, h_after_attn...')
gelu_s = {li: [] for li in range(n_layers)}
pre_gelu_s = {li: [] for li in range(n_layers)}
h_after_ffn = {li: [] for li in range(n_layers)}
attn_s = {li: [] for li in range(n_layers)}
h_after_attn = {li: [] for li in range(n_layers)}
cur = {k: {li: None for li in range(n_layers)} for k in ['gelu', 'pre_gelu', 'h_layer', 'attn', 'h_attn']}
hooks = []
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur['gelu'][l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
for li in range(n_layers):

    def make_pg(l):

        def hook(m, inp, out):
            i = inp[0] if isinstance(inp, tuple) else inp
            cur['pre_gelu'][l] = i.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_pg(li)))
for h in hooks:
    h.remove()
hooks = []
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur['gelu'][l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
for li in range(n_layers):

    def make_pg(l):

        def hook(m, inp, out):
            cur['pre_gelu'][l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.c_fc.register_forward_hook(make_pg(li)))
for li in range(n_layers):

    def make_h(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur['h_layer'][l] = o.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].register_forward_hook(make_h(li)))
for li in range(n_layers):

    def make_a(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur['attn'][l] = o.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_a(li)))
for li in range(n_layers):

    def make_ha(l):

        def hook(m, inp, out):
            i = inp[0] if isinstance(inp, tuple) else inp
            cur['h_attn'][l] = i.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ha(li)))
for h in hooks:
    h.remove()
hooks = []
for li in range(n_layers):

    def make_g(l):

        def hook(m, inp, out):
            cur['gelu'][l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_g(li)))
for li in range(n_layers):

    def make_pg(l):

        def hook(m, inp, out):
            cur['pre_gelu'][l] = out.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].mlp.c_fc.register_forward_hook(make_pg(li)))
for li in range(n_layers):

    def make_h(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur['h_layer'][l] = o.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].register_forward_hook(make_h(li)))
for li in range(n_layers):

    def make_a(l):

        def hook(m, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            cur['attn'][l] = o.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_a(li)))
for li in range(n_layers):

    def make_ha(l):

        def hook(m, inp, out):
            i = inp[0] if isinstance(inp, tuple) else inp
            cur['h_attn'][l] = i.detach().float()[0].numpy().copy()
        return hook
    hooks.append(model.transformer.h[li].ln_2.register_forward_hook(make_ha(li)))
long_texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden every day. She would run through the flowers and chase the butterflies that flew around her. One morning she found a tiny kitten hiding under the big rose bush near the fence. The kitten was very small and scared and it was crying softly in the shadows. Lily gently picked up the kitten and held it close to her heart to keep it warm.', 'The old farmer woke up very early every morning before the sun had risen in the sky. He would walk out to the barn and feed all the animals that lived there on his farm. There were cows and horses and chickens and pigs all waiting for their breakfast. The farmer talked to each animal as he gave them food and fresh water to drink. After feeding the animals he would go to the fields and work until the sun went down.', 'Deep in the forest there was a small house where a family of bears lived together happily. The father bear was very big and strong and he caught fish from the river each day. The mother bear was kind and gentle and she made honey cakes for the whole family. The baby bear was curious and always wandering off to explore the woods nearby. One day the baby bear followed a butterfly deep into the forest and got lost alone.', 'There was once a brave young knight who lived in a castle near the mountains high above. He spent his days training with his sword and shield and riding his white horse fast. One day the king called all the knights together and said a dragon had come to the land. The dragon was burning the villages and scaring all the people who lived near the hills. The young knight volunteered to go and face the dragon and bring peace to the kingdom.', 'A small girl named Sophie loved books more than anything else in the whole wide world today. She had read every book in her house and every book in the school library twice over. One day she discovered a tiny door in the back of her bookshelf behind the tall books. She opened it and found a magical library that went on forever in every direction. The books here were alive and they would talk to her and tell her stories directly.', 'The little village sat quietly at the edge of a great forest full of ancient tall trees. Every year in autumn the villagers would hold a big festival to celebrate the harvest time. Children would run through the market eating apples and drinking warm spiced cider joyfully. The baker would make special bread shaped like animals and the children loved it so much. Musicians played their instruments and everyone danced in the square until midnight came.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night alone. Every night he would pull his blanket over his head and imagine monsters in the shadows. His father gave him a small flashlight and told him to shine it at whatever scared him. The first night Tommy shone the light and saw only his toys and books and nothing scary. His father explained that darkness was just the absence of light and nothing more.', 'The ocean was vast and blue and stretched as far as the eye could possibly see each day. A young sailor named Marco had sailed across it many times in his small wooden boat. He knew every star in the night sky and used them to navigate across the open water. One night a terrible storm came and blew his boat far off course into unknown waters far. When morning came he saw an island he had never seen before on any map.', 'High up in the mountains there was a small school where children came from very far away. The teacher was an old woman who had taught for fifty years in that same cold classroom. She knew that each child was different and needed to learn in their own special way. Some children learned by reading and some by drawing and some by building things with hands. She gave each child the kind of lesson that matched the way their mind worked.', 'She opened her eyes slowly and looked at the bright morning light coming through the window. The birds were singing outside and the smell of fresh bread came from the kitchen below. She stretched her arms and smiled because today was her birthday and she was very excited. Downstairs her family had prepared a big surprise with balloons and presents on the table. Her little brother ran up the stairs to wake her even though she was already awake.', 'The two friends had known each other since they were very small children in the same class. They had grown up together and shared all their secrets and dreams with each other always. One summer they decided to build a treehouse in the big oak at the bottom of the garden. They worked every day sawing wood and hammering nails and pulling ropes up into the tree. After two weeks the treehouse was finished and it had a rope ladder and window.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree. Every morning she would hop out to the meadow to find fresh grass and sweet clover to eat. One day she found a strange shiny stone lying in the path and picked it up. The stone glowed with a soft blue light that pulsed slowly like a heartbeat in her paw. She brought it home and placed it in her burrow where it lit up warmly.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest. She spent her days tending her garden and feeding the birds that came to visit her daily. Every evening she would sit by the fire and read her old favorite books by the light. One day a lost child appeared at her door cold and hungry and very frightened alone. She welcomed the child inside and gave food and warmth and comfort without hesitation.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day. The puppy was wet and cold and very hungry and it looked up at him with big eyes. Sam picked up the puppy and carried it home carefully to show his mother right away. His mother smiled and said they could keep the puppy if Sam promised to care for it. Sam promised and from that day on the puppy followed him everywhere he went.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone before. Every day she would watch the village below and wish she could play with the children there. One day a brave girl climbed the mountain and sat down quietly beside the dragon alone. The dragon was surprised but did not fly away because the girl was kind and gentle. They talked for hours and from that day became the best of friends forever.', 'In the deep blue ocean there lived a curious fish who wanted to see the world above it. Every day she would swim to the surface and peek at the sky and the tall green trees. One morning she jumped very high and for a moment she could see everything around her. She saw hills and rivers and roads and tiny people walking far below in distance. From that day she knew the world was much bigger than her small blue ocean.', 'The old clock in the corner of the room had not worked for many many long quiet years. One rainy afternoon the little girl decided to try to fix it with her small toy tools. She turned the gears carefully and wound the spring slowly and tightened every loose screw. Suddenly with a soft click and a gentle whir the clock began to tick again steadily. The girl smiled proudly and her grandfather hugged her and said she was very clever indeed.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below. Rain fell gently on it for many days and the warm sun shone down on the earth always. Slowly a small green shoot appeared pushing up through the dark soil toward the bright light. It grew taller every day stretching upward until it became a sapling strong and straight. Years later it was a great tree itself with birds nesting in its leafy branches.', 'The young painter stood in front of the blank white canvas and did not know where to start. She dipped her brush in the bright blue paint and made one small careful stroke across it. Then she added yellow and red and slowly a beautiful sunrise began to appear before her. She painted clouds and birds and a river winding through green fields in the valley. When she finished she stepped back and saw it was the most beautiful thing she made.', 'Every evening the grandfather would sit in his old wooden chair and tell stories to the children. The children would gather around him and listen with wide open eyes in the warm firelight. His stories were always about adventures in faraway lands and magical creatures and brave young heroes. He remembered every detail perfectly and his voice rose and fell like music as he spoke. The children never wanted the stories to end and always begged for just one more tale.']
with torch.no_grad():
    for text in long_texts:
        for k in cur:
            for li in range(n_layers):
                cur[k][li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=128, truncation=True)
        model(**toks)
        L = toks['input_ids'].shape[1]
        for li in range(n_layers):
            for k, store in [('gelu', gelu_s), ('pre_gelu', pre_gelu_s), ('h_layer', h_after_ffn), ('attn', attn_s), ('h_attn', h_after_attn)]:
                if cur[k][li] is not None:
                    for t in range(L):
                        store[li].append(cur[k][li][t].copy())
for h in hooks:
    h.remove()
G = {li: np.array(gelu_s[li], dtype=np.float32) for li in range(n_layers)}
PG = {li: np.array(pre_gelu_s[li], dtype=np.float32) for li in range(n_layers)}
H = {li: np.array(h_after_ffn[li], dtype=np.float32) for li in range(n_layers)}
A = {li: np.array(attn_s[li], dtype=np.float32) for li in range(n_layers)}
HA = {li: np.array(h_after_attn[li], dtype=np.float32) for li in range(n_layers)}
N = len(G[0])
print(f'Tokens: {N}')
print(f'Shapes — G:{G[0].shape} PG:{PG[0].shape} H:{H[0].shape} A:{A[0].shape} HA:{HA[0].shape}')
print(f"\n{'=' * 70}")
print(f'  TEST A — KEY: h_after_attn_{{l+1}} → pre_gelu_{{l+1}}')
print(f'  Path: h_after_attn → LN2 (R²=1.000) → W1 (R²=1.000) → pre_gelu')
print(f'  ALL LINEAR. R² MUST = 1.000.')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    r2_tr, r2_te = fit_r2(HA[li], PG[li])
    show(f'  h_after_attn_{li} → pre_gelu_{li}', r2_tr, r2_te)
print(f"\n{'=' * 70}")
print(f'  TEST B — h_after_attn_{{l+1}} → gelu_{{l+1}}')
print(f'  Path: h_after_attn → LN2 → W1 → PRE_GELU → gelu (crystal)')
print(f'  One crystal in path. Cannot be 1.000 for gelu.')
print(f'  But pre_gelu → gelu = crystal transform. Should be high.')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    r2_tr, r2_te = fit_r2(HA[li], G[li])
    show(f'  h_after_attn_{li} → gelu_{li}', r2_tr, r2_te)
print(f"\n{'=' * 70}")
print(f'  TEST C — h_l vs gelu_l as predictor of gelu_{{l+1}}')
print(f'  Does full residual stream beat gelu alone?')
print(f"{'=' * 70}\n")
print(f"  {'Chain':<35} {'gelu_l only':<16} {'h_l only':<16} {'[h_l,attn_{{l+1}}]'}")
print(f"  {'─' * 75}")
for li in range(n_layers - 1):
    _, r2_g = fit_r2(G[li], G[li + 1])
    _, r2_h = fit_r2(H[li], G[li + 1])
    _, r2_ha = fit_r2_multi(H[li], A[li + 1], Y=G[li + 1].astype(np.float64))
    marker = '✓✓ EXACT' if r2_ha > 0.9999 else '✓  NEAR' if r2_ha > 0.999 else '~  STRONG' if r2_ha > 0.95 else '·  PARTIAL' if r2_ha > 0.5 else '✗  LOW'
    print(f"  layer {li}→{li + 1}{'':25} {r2_g:.4f}          {r2_h:.4f}          {r2_ha:.4f}  {marker}")
print(f"\n{'=' * 70}")
print(f'  TEST D — pre_gelu natural space evolution')
print(f'  pre_gelu_l → pre_gelu_{{l+1}} directly')
print(f'  + with h bridge: [pre_gelu_l, h_after_attn_{{l+1}}] → pre_gelu_{{l+1}}')
print(f'  Second should be 1.000: h_after_attn contains all needed info.')
print(f"{'=' * 70}\n")
for li in range(n_layers - 1):
    _, r2_pg = fit_r2(PG[li], PG[li + 1])
    _, r2_ha_pg = fit_r2(HA[li + 1], PG[li + 1])
    _, r2_both = fit_r2_multi(PG[li], HA[li + 1], Y=PG[li + 1].astype(np.float64))
    print(f'  layer {li}→{li + 1}:')
    print(f'    pre_gelu_{li} → pre_gelu_{li + 1}:              R²={r2_pg:.4f}')
    print(f'    h_after_attn_{li + 1} → pre_gelu_{li + 1}:       R²={r2_ha_pg:.4f}  (should=1.000)')
    print(f'    [pre_gelu_{li}, h_attn_{li + 1}] → pre_gelu_{li + 1}: R²={r2_both:.4f}')
print(f"\n{'=' * 70}")
print(f'  TEST E — T_l matrix analysis')
print(f'  Compute T_l = transition matrix gelu_l → gelu_l+1')
print(f'  SVD: singular values, rank, condition number')
print(f'  How does T_l change with depth l?')
print(f"{'=' * 70}\n")
T_matrices = {}
for li in range(n_layers - 1):
    X = G[li].astype(np.float64)
    Y = G[li + 1].astype(np.float64)
    n = len(X)
    s = int(n * 0.8)
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
        T_matrices[li] = W[:-1]
    except:
        pass
print(f'  T_l singular value analysis:')
print(f"  {'Layer':<8} {'top-5 SV':<40} {'rank(>0.01)':<14} {'cond'}")
print(f"  {'─' * 75}")
sv_top = {}
for li, T in T_matrices.items():
    sv = np.linalg.svd(T, compute_uv=False)
    top5 = '  '.join([f'{v:.3f}' for v in sv[:5]])
    rank = int(np.sum(sv > 0.01 * sv[0]))
    cond = float(sv[0] / (sv[-1] + 1e-10))
    sv_top[li] = sv
    print(f'  {li:<8} {top5:<40} {rank:<14} {cond:.1f}')
print(f'\n  T_l similarity: cos(T_l, T_0) — does T_l resemble T_0?')
if 0 in T_matrices:
    T0_flat = T_matrices[0].flatten()
    T0_norm = T0_flat / (np.linalg.norm(T0_flat) + 1e-08)
    for li, T in T_matrices.items():
        Tl_flat = T.flatten()
        Tl_norm = Tl_flat / (np.linalg.norm(Tl_flat) + 1e-08)
        cos_sim = float(np.dot(T0_norm, Tl_norm))
        frob_ratio = float(np.linalg.norm(T - T_matrices[0], 'fro') / (np.linalg.norm(T_matrices[0], 'fro') + 1e-08))
        print(f'  T_{li} vs T_0: cos={cos_sim:.4f}  ||T_{li}-T_0||/||T_0||={frob_ratio:.4f}')
print(f"\n{'=' * 70}")
print(f'  TEST F — Eigenvalue evolution of T_l')
print(f'  Do eigenvalues of T_l rotate predictably with depth?')
print(f'  If |eig_l| constant and arg(eig_l) = l * theta: universal rotation law.')
print(f"{'=' * 70}\n")
for li, T in T_matrices.items():
    try:
        eigs = np.linalg.eigvals(T)
        mags = np.abs(eigs)
        args = np.angle(eigs)
        print(f'  T_{li}: |eig| mean={np.mean(mags):.4f} std={np.std(mags):.4f} max={np.max(mags):.4f} min={np.min(mags):.4f}')
        n_real = int(np.sum(np.abs(eigs.imag) < 0.01))
        n_complex = len(eigs) - n_real
        print(f"        real={n_real}  complex={n_complex}  top-3 |eig|: {' '.join([f'{v:.3f}' for v in sorted(mags)[-3:]])}")
    except Exception as e:
        print(f'  T_{li}: eigenvalue failed: {e}')
print(f"\n{'=' * 70}")
print(f'  TEST G — UNIVERSAL: h_after_attn → pre_gelu all layers combined')
print(f'  Same W maps h_after_attn → pre_gelu at EVERY layer?')
print(f'  If yes: one universal linear map across all layers.')
print(f"{'=' * 70}\n")
print(f'  Per-layer summary (from TEST A):')
for li in range(n_layers):
    r2_tr, r2_te = fit_r2(HA[li], PG[li])
    show(f'  h_after_attn_{li} → pre_gelu_{li}', r2_tr, r2_te, width=45)
print(f'\n  Universal fit (all layers stacked):')
HA_all = np.concatenate([HA[li] for li in range(n_layers)], axis=0)
PG_all = np.concatenate([PG[li] for li in range(n_layers)], axis=0)
r2_tr_u, r2_te_u = fit_r2(HA_all, PG_all)
show(f'  h_after_attn [all layers] → pre_gelu', r2_tr_u, r2_te_u, width=45)
print(f"\n{'=' * 70}")
print(f'  NATURAL SPACE — COMPLETE SUMMARY')
print(f"{'=' * 70}")
print(f'\n  THE CHAIN:\n  \n  h_after_attn → LN2 → W1 = pre_gelu  [ALL LINEAR R²=1.000]\n  pre_gelu → gelu                       [CRYSTAL — nonlinear]\n  gelu → W2 → residual                  [ALL LINEAR R²=1.000]\n  residual + attn_{l + 1}  = h_after_attn_{l + 1}  [linear sum]\n  \n  NATURAL SPACE OF EVOLUTION:\n    For linear part: h_after_attn → pre_gelu = R²=1.000. ✓\n    Cross-crystal: gelu_l → gelu_l+1 = 0.93 (wall = attention)\n    \n  IF h_after_attn → pre_gelu = 1.000:\n    CONFIRMED: h_after_attn = natural space.\n    Inter-crystal natural space = h_after_attn (not gelu).\n    Evolution law: h_after_attn_{l + 1} = h_l + attn_{l + 1}.\n    Then: LN2 @ W1 @ h_after_attn = pre_gelu. Exact.\n    Then: gelu(pre_gelu) = gelu_{l + 1}. Exact crystal.\n    \n  WHAT THIS MEANS:\n    Crystal resonance = exists in h_after_attn space.\n    Not in gelu space directly.\n    Attention adds to residual = the bridge between crystals.\n    Once attention is known: entire path = exact. R²=1.000.\n    \n  IMPLICATION FOR 70B ON LAPTOP:\n    If we can predict attn_{l + 1} from earlier layers:\n    Skip full attention computation.\n    Replace with predicted attn. Apply to residual.\n    Compute gelu exactly from that.\n    That = attention-free inference. The real shortcut.\n')
print('=' * 70 + '\n')
