import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
ensure('accelerate')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — 3B SCALE TEST')
print('  Pythia-2.8B: same laws or new hidden laws?')
print('=' * 62)
MODEL_NAME = 'EleutherAI/pythia-2.8b'
print(f'\n  Loading {MODEL_NAME}...')
print(f'  (First run downloads ~5.5GB. Be patient.)')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, torch_dtype=torch.float16, device_map='cpu')
model.eval()
D = model.config.hidden_size
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
n_layers = model.config.num_hidden_layers
print(f'\n  Model loaded.')
print(f'  D={D}  Heads={n_heads}  Head_dim={head_dim}  Layers={n_layers}')

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def fit_r2_tok(X, Y, split=0.8):
    n = len(X)
    s = int(n * split)
    Xb = np.c_[X, np.ones(n)].astype(np.float32)
    W = np.linalg.lstsq(Xb[:s], Y[:s].astype(np.float32), rcond=None)[0]
    pred = Xb[s:] @ W
    return r2(pred, Y[s:].astype(np.float32))
starts = ['Once upon a time', 'The scientist looked', 'In a distant future', 'The old library held', 'A young programmer', 'The mountain path led', 'She opened the envelope', 'The experiment failed', 'He remembered the day', 'The city never sleeps', 'A child asked why', 'The last star dimmed']
CTX = 8
print(f'\n  Generating data (small set — 3B is slower)...')
all_texts = []
with torch.no_grad():
    for i, s in enumerate(starts):
        for temp in [0.8, 1.0]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=30, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'  Generated {len(all_texts)} texts.')
test_layers = [0, 4, 8, 15, 23, 31]
print(f'\n  Testing layers: {test_layers}')
print(f'  (Spread across all 32 to map depth pattern)')
results = {}
with torch.no_grad():
    for layer_idx in test_layers:
        print(f'\n  Layer {layer_idx}...', end=' ', flush=True)
        block = model.model.layers[layer_idx]
        try:
            Wq = block.attention.query_key_value.weight.detach()
            qkv_w = block.attention.query_key_value.weight.detach().float().numpy()
            Wq_np = qkv_w[:D, :].T
            Wk_np = qkv_w[D:2 * D, :].T
            Wv_np = qkv_w[2 * D:3 * D, :].T
            Wo_np = block.attention.dense.weight.detach().float().numpy().T
            fused_qkv = True
        except AttributeError:
            Wq_np = block.self_attn.q_proj.weight.detach().float().numpy().T
            Wk_np = block.self_attn.k_proj.weight.detach().float().numpy().T
            Wv_np = block.self_attn.v_proj.weight.detach().float().numpy().T
            Wo_np = block.self_attn.o_proj.weight.detach().float().numpy().T
            fused_qkv = False
        X_list = []
        D_list = []
        PH_list = []
        FFN_list = []
        FOUT_list = []
        for text in all_texts:
            tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
            ids = tokens['input_ids']
            L = ids.shape[1]
            if L < CTX:
                continue
            out_m = model(**tokens, output_hidden_states=True)
            hs = out_m.hidden_states
            for start in range(L - CTX + 1):
                x_t = hs[layer_idx][0, start:start + CTX].float()
                x_np = x_t.numpy()
                try:
                    ln1 = block.input_layernorm(x_t).detach().float().numpy()
                except:
                    ln1 = block.ln_1(x_t).detach().float().numpy()
                Q = ln1 @ Wq_np
                K = ln1 @ Wk_np
                V = ln1 @ Wv_np
                head_feats = []
                for h in range(n_heads):
                    sh = h * head_dim
                    eh = sh + head_dim
                    Qh = Q[:, sh:eh]
                    Kh = K[:, sh:eh]
                    Vh = V[:, sh:eh]
                    scr = Qh @ Kh.T / np.sqrt(head_dim)
                    msk = np.triu(np.full((CTX, CTX), -1000000000.0), 1)
                    ah = softmax(scr + msk)
                    head_feats.append(ah @ Vh)
                concat = np.concatenate(head_feats, axis=1)
                try:
                    att_out = block.attention(x_t.unsqueeze(0), attention_mask=torch.ones(1, 1, CTX, CTX))[0].squeeze(0).detach().float().numpy()
                except:
                    att_out = block.attn(x_t.unsqueeze(0))[0].squeeze(0).detach().float().numpy()
                x2 = x_t + torch.tensor(att_out, dtype=torch.float32)
                try:
                    ln2 = block.post_attention_layernorm(x2).detach().float().numpy()
                except:
                    ln2 = block.ln_2(x2).detach().float().numpy()
                try:
                    pre = block.mlp.dense_h_to_4h(torch.tensor(ln2, dtype=torch.float32)).detach().numpy()
                    act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).detach().numpy()
                    ffn_out = block.mlp.dense_4h_to_h(torch.tensor(act, dtype=torch.float32)).detach().numpy()
                except:
                    pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).detach().numpy()
                    act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).detach().numpy()
                    ffn_out = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).detach().numpy()
                delta = att_out + ffn_out
                for t in range(CTX):
                    X_list.append(x_np[t])
                    D_list.append(delta[t])
                    PH_list.append(concat[t])
                    FFN_list.append(act[t])
                    FOUT_list.append(ffn_out[t])
        if len(X_list) < 100:
            print(f'too few samples ({len(X_list)}), skip')
            continue
        X = np.array(X_list)
        DEL = np.array(D_list)
        PH = np.array(PH_list)
        FFN = np.array(FFN_list)
        FO = np.array(FOUT_list)
        r_xd = fit_r2_tok(X, DEL)
        r_ph = fit_r2_tok(PH, DEL)
        r_att = fit_r2_tok(PH, DEL)
        r_ffn = fit_r2_tok(FFN, FO)
        results[layer_idx] = {'x_delta': r_xd, 'per_head': r_att, 'ffn': r_ffn, 'N': len(X_list)}
        print(f'N={len(X_list)} x→delta={r_xd:.4f} per_head→={r_att:.4f} ffn={r_ffn:.4f}')
print('\n' + '=' * 62)
print('  RESULTS — 3B SCALE')
print('  Same laws? Or new hidden laws?')
print('=' * 62)
print()
print(f"  {'Layer':<8} {'x→delta':<12} {'per_head':<12} {'ffn_gelu':<12} {'N'}")
print('  ' + '─' * 55)
for l in test_layers:
    if l not in results:
        print(f"  {l:<8} {'SKIPPED'}")
        continue
    r = results[l]

    def f(v):
        return '✓1.000' if v > 0.999 else f'{v:.4f}'
    print(f"  {l:<8} {f(r['x_delta']):<12} {f(r['per_head']):<12} {f(r['ffn']):<12} {r['N']}")
print()
print('  COMPARISON:')
print(f'  TinyStories-1M (D=64,  head_dim=4,  8 layers):')
print(f'    x→delta:  0.986 (layer 0) → 0.815 (layer 7)')
print(f'    per_head: 0.993+ all layers')
print(f'    ffn:      1.000 (token-level)')
print()
print(f'  Pythia-2.8B (D=2560, head_dim=80, 32 layers):')
for l in test_layers:
    if l in results:
        r = results[l]
        print(f"    Layer {l:>2}: x→delta={r['x_delta']:.4f}  per_head={r['per_head']:.4f}  ffn={r['ffn']:.4f}")
print()
print('=' * 62)
print('  WHAT IS REVEALED')
print('=' * 62)
print(f"\n  IF per_head stays 0.993+ at all tested layers:\n    Law is universal. Scale does not change it.\n    16 heads × 4D = 32 heads × 80D = same law.\n    W principle holds at 3B.\n\n  IF per_head drops at deep layers (15, 23, 31):\n    Deeper = new natural space needed.\n    Scale creates hidden law not present at 8 layers.\n    That IS the finding. New law at depth.\n\n  IF ffn drops from 1.000:\n    Pythia activation ≠ GeLU.\n    New natural space for FFN at 3B.\n    Find the rule. Then R²=1.000 again.\n\n  IF x→delta drops faster than TinyStories:\n    3B builds more structure per layer.\n    Each layer = more transformation.\n    32 rotations = deeper encoding.\n    Layer 31's natural space very far from layer 0.\n    This is expected. Not a law failure.\n    W still works per layer.\n")
print('=' * 62 + '\n')
