import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W-NATIVE SEMANTIC RAM (DIAGNOSTIC)')
print('  Measuring the Bitwise Overlap of GeLU Memory Gates.')
print('=' * 62)
print('\n  Loading TinyStories-1M...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
print('  Extracting Native Architecture (Layer 0)...')
vocab_size = model.config.vocab_size
wte = model.transformer.wte.weight.detach().numpy()
ln1_w = model.transformer.h[0].ln_1.weight.detach().numpy()
ln1_b = model.transformer.h[0].ln_1.bias.detach().numpy()
W_1 = model.transformer.h[0].mlp.c_fc.weight.detach().numpy().T
b_1 = model.transformer.h[0].mlp.c_fc.bias.detach().numpy()
print(f'  Projecting {vocab_size} words into 256-bit GeLU space...')
mean = wte.mean(axis=-1, keepdims=True)
var = ((wte - mean) ** 2).mean(axis=-1, keepdims=True)
embed_ln = (wte - mean) / np.sqrt(var + 1e-05) * ln1_w + ln1_b
pre_gelu = embed_ln @ W_1 + b_1
binary_space = (pre_gelu > 0).astype(int)
print('\n' + '─' * 62)
print('  SEMANTIC BIT-OVERLAP TEST')
print('─' * 62)
test_words = ['king', 'boy', 'dog', 'happy', 'house']

def find_bitwise_neighbors(target_word, top_k=8):
    token_id = tokenizer.encode(target_word)[0]
    target_bits = binary_space[token_id]
    matches = np.sum(binary_space == target_bits, axis=1)
    best_indices = np.argsort(matches)[::-1]
    neighbors = []
    seen = set([target_word.lower().strip()])
    for idx in best_indices:
        word = tokenizer.decode([idx]).strip()
        if not word.isalpha() or len(word) < 2:
            continue
        word_lower = word.lower()
        if word_lower not in seen and target_word.lower() not in word_lower:
            overlap_count = matches[idx]
            overlap_pct = overlap_count / 256.0 * 100
            neighbors.append((word, overlap_count, overlap_pct))
            seen.add(word_lower)
        if len(neighbors) >= top_k:
            break
    return neighbors
for target in test_words:
    print(f"  Target: '{target}'")
    neighbors = find_bitwise_neighbors(target)
    for word, count, pct in neighbors:
        print(f'    -> {word:<10} | Shared Gates: {count}/256 ({pct:.1f}%)')
    print()
print('=' * 62)
print('\n  DIAGNOSTIC CONCLUSION:\n  Look at the words sharing ~200+ gates. \n  Are they semantically related to the target?\n  \n  If yes, the LLM groups concepts by turning on the exact same\n  physical GeLU gates. A "Fuzzy Hash" (like Locality Sensitive Hashing) \n  will yield an O(1) Semantic Database!\n')
print('=' * 62 + '\n')
