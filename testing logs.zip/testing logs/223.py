import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — ATTENTION NATURAL SPACE')
print('  Finding the space where attention = exact linear.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
blk = model.transformer.h[0]
att = blk.attn.attention
Wq = att.q_proj.weight.detach().numpy()
Wk = att.k_proj.weight.detach().numpy()
Wv = att.v_proj.weight.detach().numpy()
Wo = att.out_proj.weight.detach().numpy()
bo = att.out_proj.bias.detach().numpy()
ln1_w = blk.ln_1.weight.detach().numpy()
ln1_b = blk.ln_1.bias.detach().numpy()

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def softmax(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2(A, Y):
    Ab = np.hstack([A, np.ones((len(A), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, Y, rcond=None)
    Yp = Ab @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    return float(1 - ss_res / ss_tot)
print(f'\n  Collecting data from many sequences...')
prompts = ['Once upon a time a little girl', 'The brave knight rode into', 'Deep in the forest there lived', 'A small dog ran across', 'The sun rose over the mountains', 'She opened the old wooden door', 'Every morning the bird would sing', 'He found a golden key inside', 'The children played in the garden', 'Far away in a distant land', 'A tiny mouse found some cheese', 'The wizard waved his magic wand', 'Once there was a kind old man', 'The princess wore a silver crown', 'A rainbow appeared after the rain', 'The farmer planted many seeds', 'She read the old dusty book', 'The river flowed through the valley', 'A butterfly landed on the flower', 'The ship sailed across the sea']
data = {'x_last': [], 'ln1_last': [], 'Q_last': [], 'K_mean': [], 'V_mean': [], 'Q_last_Kmean_Vmean': [], 'context_last': [], 'probs_last': [], 'att_out_last': [], 'context_h0_last': []}
SEQ_LEN = 10
with torch.no_grad():
    for prompt in prompts:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        x = (wte[ids] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
        ln1 = ln(x, ln1_w, ln1_b)
        Q = ln1 @ Wq.T
        K = ln1 @ Wk.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((SEQ_LEN, SEQ_LEN), float('-inf'), np.float32), 1)
        probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads_out = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads_out, 1).reshape(SEQ_LEN, D)
        att_out = context @ Wo.T + bo
        i = SEQ_LEN - 1
        data['x_last'].append(x[i])
        data['ln1_last'].append(ln1[i])
        data['Q_last'].append(Q[i])
        data['K_mean'].append(K.mean(0))
        data['V_mean'].append(V.mean(0))
        data['Q_last_Kmean_Vmean'].append(np.concatenate([Q[i], K.mean(0), V.mean(0)]))
        data['context_last'].append(context[i])
        data['att_out_last'].append(att_out[i])
        data['context_h0_last'].append(heads_out[0][i])
with torch.no_grad():
    for prompt in prompts:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        for _ in range(30):
            while len(ids) < SEQ_LEN:
                out = model(torch.tensor([ids]))
                ids.append(torch.argmax(out.logits[0, -1, :]).item())
            ids_use = ids[-SEQ_LEN:]
            x = (wte[ids_use] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
            ln1 = ln(x, ln1_w, ln1_b)
            Q = ln1 @ Wq.T
            K = ln1 @ Wk.T
            V = ln1 @ Wv.T
            Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            Vh = V.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            mask = np.triu(np.full((SEQ_LEN, SEQ_LEN), float('-inf'), np.float32), 1)
            probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
            heads_out = [probs[h] @ Vh[h] for h in range(n_heads)]
            context = np.stack(heads_out, 1).reshape(SEQ_LEN, D)
            att_out = context @ Wo.T + bo
            i = SEQ_LEN - 1
            data['x_last'].append(x[i])
            data['ln1_last'].append(ln1[i])
            data['Q_last'].append(Q[i])
            data['K_mean'].append(K.mean(0))
            data['V_mean'].append(V.mean(0))
            data['Q_last_Kmean_Vmean'].append(np.concatenate([Q[i], K.mean(0), V.mean(0)]))
            data['context_last'].append(context[i])
            data['att_out_last'].append(att_out[i])
            out2 = model(torch.tensor([ids_use]))
            ids.append(torch.argmax(out2.logits[0, -1, :]).item())
for k in data:
    data[k] = np.array(data[k], dtype=np.float32)
N = len(data['att_out_last'])
print(f'  Collected {N} samples  (D={D}, need N >> {D})')
print(f"\n{'=' * 70}")
print(f'  R² MEASUREMENTS — CANDIDATE NATURAL SPACES')
print(f'  Target: att_out at last token (generation step)')
print(f"{'=' * 70}\n")
Y = data['att_out_last']
candidates = [('x[i] alone', 'x_last', D), ('ln1(x)[i] alone', 'ln1_last', D), ('Q[i] alone', 'Q_last', D), ('K_mean across seq', 'K_mean', D), ('V_mean across seq', 'V_mean', D), ('Q[i]+K_mean+V_mean', 'Q_last_Kmean_Vmean', D * 3), ('context[i]=probs@V', 'context_last', D)]
print(f"  {'Space':<30} {'dim':<8} {'R²':<12} {'verdict'}")
print(f"  {'─' * 58}")
for name, key, dim in candidates:
    X_cand = data[key]
    if len(X_cand) == 0:
        continue
    score = r2(X_cand, Y)
    v = '= 1.000 EXACT' if score > 0.9999 else '≈ 1.000 near' if score > 0.999 else 'HIGH  > 0.99' if score > 0.99 else 'GOOD  > 0.95' if score > 0.95 else 'PARTIAL' if score > 0.5 else 'LOW (wrong space)'
    print(f'  {name:<30} {dim:<8} {score:<12.6f} {v}')
print(f"\n{'=' * 70}")
print(f'  DEEP TEST: FULL SEQUENCE AS NATURAL SPACE')
print(f'  att_out[i] depends on x[0..i], not just x[i].')
print(f'  Can ln1(x) full sequence → att_out[last] = 1.000?')
print(f"{'=' * 70}\n")
full_ln1_seq = []
full_att_out = []
with torch.no_grad():
    for prompt in prompts[:10]:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        x = (wte[ids] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
        ln1 = ln(x, ln1_w, ln1_b)
        Q = ln1 @ Wq.T
        K = ln1 @ Wk.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((SEQ_LEN, SEQ_LEN), float('-inf'), np.float32), 1)
        probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads_out = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads_out, 1).reshape(SEQ_LEN, D)
        att_out = context @ Wo.T + bo
        full_ln1_seq.append(ln1.flatten())
        full_att_out.append(att_out[-1])
full_ln1_seq = np.array(full_ln1_seq, dtype=np.float32)
full_att_out = np.array(full_att_out, dtype=np.float32)
N2 = len(full_ln1_seq)
dim2 = full_ln1_seq.shape[1]
print(f'  N={N2} samples, input dim={dim2} (SEQ_LEN×D = {SEQ_LEN}×{D})')
print(f'  WARNING: N={N2} < dim={dim2} → result unreliable if N < dim\n')
if N2 > dim2:
    score_full = r2(full_ln1_seq, full_att_out)
    print(f'  ln1(x) full sequence → att_out[last]: R²={score_full:.6f}')
else:
    print(f'  Not enough samples ({N2}) for reliable R² with dim={dim2}')
    print(f'  Result would be artificially high (overfitting).')
    print(f'  Need N >> {dim2} samples for honest measurement.')
print(f"\n{'=' * 70}")
print(f'  W LAW — ATTENTION NATURAL SPACE ANALYSIS')
print(f"{'=' * 70}\n")
print(f'\n  WHAT W LAW TELLS US ABOUT ATTENTION:\n\n  Attention = sequence mixing operation.\n  att_out[i] = f(x[0], x[1], ... x[i])\n  \n  ALL inputs are linear in ln1(x):\n    Q = ln1(x) @ Wq   R²=1.000\n    K = ln1(x) @ Wk   R²=1.000\n    V = ln1(x) @ Wv   R²=1.000\n    \n  ONE nonlinear step:\n    probs = softmax(Q @ K.T)   ← crystal point\n    \n  After crystal point: pure linear again:\n    context = probs @ V        (linear in probs given V)\n    att_out = context @ Wo     (linear in context)\n\n  NATURAL SPACE FOR ATTENTION:\n    Not x[i] alone (misses context)\n    Not Q[i] alone (misses K, V)\n    YES: (probs[i,:], V) together = natural space\n    YES: context[i] = probs@V = post-crystal = linear\n    \n  The crystal point = softmax(Q@K.T)\n  Before: nonlinear. After: linear.\n  Same law as FFN. Same W principle.\n  FFN crystal = GeLU. ATT crystal = Softmax@V.\n  \n  R² of context → att_out = 1.000 is NOT trivial:\n    It proves the crystal point is exactly there.\n    Everything before = nonlinear in x.\n    Everything after = linear in context.\n    The boundary is exact.\n')
print('=' * 70 + '\n')
