import numpy as np
import torch
import torch.nn as nn
import time
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
SEQ_LEN = 4
NORM = 1000.0
DIM = 16
N_HIDDEN = 74
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(1000)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

def prime_W(out_dim, in_dim):
    arr = np.array(BEST_PRIMES[:out_dim], dtype=np.float32)
    arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
    arr = arr / (np.max(np.abs(arr)) + 1e-08)
    W = np.zeros((out_dim, in_dim), dtype=np.float32)
    for col in range(in_dim):
        W[:, col] = arr * (col + 1) / in_dim
    return torch.tensor(W)

def flat_W(out_dim, in_dim):
    std = np.sqrt(2.0 / (in_dim + out_dim))
    return torch.tensor(np.random.randn(out_dim, in_dim).astype(np.float32) * std)

class FlatResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class PrimeResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        with torch.no_grad():
            self.linear.weight.copy_(prime_W(dim, dim))
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class PrimePlainBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        with torch.no_grad():
            self.linear.weight.copy_(prime_W(dim, dim))
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x))

class ModelA(nn.Module):

    def __init__(self):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(SEQ_LEN, DIM), nn.Tanh())
        self.blocks = nn.ModuleList([FlatResBlock(DIM) for _ in range(N_HIDDEN)])
        self.output = nn.Linear(DIM, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

class ModelB(nn.Module):

    def __init__(self):
        super().__init__()
        inp = nn.Linear(SEQ_LEN, DIM)
        with torch.no_grad():
            inp.weight.copy_(prime_W(DIM, SEQ_LEN))
        self.input_proj = nn.Sequential(inp, nn.Tanh())
        self.blocks = nn.ModuleList([FlatResBlock(DIM) for _ in range(N_HIDDEN)])
        self.output = nn.Linear(DIM, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

class ModelC(nn.Module):

    def __init__(self):
        super().__init__()
        half = DIM // 2
        inp1 = nn.Linear(SEQ_LEN, half)
        with torch.no_grad():
            inp1.weight.copy_(prime_W(half, SEQ_LEN))
        self.brain1_input = nn.Sequential(inp1, nn.Tanh())
        self.brain1_blocks = nn.ModuleList([FlatResBlock(half) for _ in range(N_HIDDEN)])
        self.brain2_input = nn.Sequential(nn.Linear(SEQ_LEN, half), nn.Tanh())
        self.brain2_blocks = nn.ModuleList([FlatResBlock(half) for _ in range(N_HIDDEN)])
        self.merge = nn.Linear(DIM, 1)

    def forward(self, x):
        x1 = self.brain1_input(x)
        for b in self.brain1_blocks:
            x1 = b(x1)
        x2 = self.brain2_input(x)
        for b in self.brain2_blocks:
            x2 = b(x2)
        return self.merge(torch.cat([x1, x2], dim=-1))

class ModelD(nn.Module):

    def __init__(self):
        super().__init__()
        inp = nn.Linear(SEQ_LEN, DIM)
        with torch.no_grad():
            inp.weight.copy_(prime_W(DIM, SEQ_LEN))
        self.input_proj = nn.Sequential(inp, nn.Tanh())
        n_prime = N_HIDDEN // 4
        n_flat = N_HIDDEN - n_prime
        self.prime_blocks = nn.ModuleList([PrimeResBlock(DIM) for _ in range(n_prime)])
        self.flat_blocks = nn.ModuleList([FlatResBlock(DIM) for _ in range(n_flat)])
        self.output = nn.Linear(DIM, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for b in self.prime_blocks:
            x = b(x)
        for b in self.flat_blocks:
            x = b(x)
        return self.output(x)

class ModelE(nn.Module):

    def __init__(self, prime_every=6):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(SEQ_LEN, DIM), nn.Tanh())
        self.blocks = nn.ModuleList()
        self.prime_every = prime_every
        for i in range(N_HIDDEN):
            if (i + 1) % prime_every == 0:
                self.blocks.append(PrimeResBlock(DIM))
            else:
                self.blocks.append(FlatResBlock(DIM))
        self.output = nn.Linear(DIM, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

class ModelF(nn.Module):

    def __init__(self):
        super().__init__()
        self.input_proj = nn.Sequential(nn.Linear(SEQ_LEN, DIM), nn.Tanh())
        self.blocks = nn.ModuleList()
        for i in range(N_HIDDEN):
            if i % 2 == 0:
                self.blocks.append(FlatResBlock(DIM))
            else:
                self.blocks.append(PrimeResBlock(DIM))
        self.output = nn.Linear(DIM, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

class ModelG(nn.Module):

    def __init__(self):
        super().__init__()
        inp = nn.Linear(SEQ_LEN, DIM)
        with torch.no_grad():
            inp.weight.copy_(prime_W(DIM, SEQ_LEN))
        self.input_proj = nn.Sequential(inp, nn.Tanh())
        self.blocks = nn.ModuleList()
        for _ in range(N_HIDDEN):
            blk = FlatResBlock(DIM)
            with torch.no_grad():
                blk.linear.weight.copy_(prime_W(DIM, DIM))
            self.blocks.append(blk)
        self.output = nn.Linear(DIM, 1)

    def forward(self, x):
        x = self.input_proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

def train(model, epochs=5000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 1000 == 0:
            s = score(model)
            print(f'    {label:<22} ep{ep:>5}  loss={best:>14.8f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 5000
BASELINE = 5.083e-05
models_cfg = [('A: flat+residual (baseline)', ModelA), ('B: prime-input → flat-res', ModelB), ('C: parallel dual brain', ModelC), ('D: prime early → flat late', ModelD), ('E: flat+res + prime highway/6', ModelE), ('F: alternating prime/flat', ModelF), ('G: prime-seed + flat-res', ModelG)]
print_sep('HYBRID MULTI-BRAIN — 75 layers, 5000 epochs')
print(f'  Baseline to beat: loss={BASELINE}  (flat+residual proven)')
print(f'  DIM={DIM}  N_HIDDEN={N_HIDDEN}\n')
results = []
logs = {}
for label, ModelClass in models_cfg:
    print(f'\n  ── {label} ──')
    np.random.seed(42)
    m = ModelClass().to(device)
    params = sum((p.numel() for p in m.parameters()))
    print(f'  Params: {params:,}')
    loss, log = train(m, EPOCHS, lr=0.001, label=label[:22])
    s = score(m)
    results.append((label, params, loss, s, log))
    logs[label] = log
    del m
    torch.cuda.empty_cache()
print_sep('CONVERGENCE TABLE')
CHECKPTS = [1000, 2000, 3000, 4000, 5000]
short_labels = ['A:flat-res', 'B:prime→flat', 'C:parallel', 'D:cascade', 'E:highway', 'F:altern', 'G:seed']
print(f"\n  {'Epoch':>6}", end='')
for sl in short_labels:
    print(f'  {sl:>13}', end='')
print()
print(f"  {'─' * 105}")
for ep in CHECKPTS:
    print(f'  {ep:>6}', end='')
    for label, _, _, _, log in results:
        v = log[min(ep - 1, len(log) - 1)]
        print(f'  {v:>13.6f}', end='')
    print()
print_sep('FINAL SCOREBOARD')
results_sorted = sorted(results, key=lambda x: (-x[3], x[2]))
print(f'\n  Baseline: loss={BASELINE:.8f}\n')
print(f"  {'#':>3}  {'Model':<32}  {'Params':>10}  {'Score':>7}  {'Loss':>14}  vs baseline")
print(f"  {'─' * 85}")
for rank, (label, params, loss, s, _) in enumerate(results_sorted):
    gain = BASELINE / (loss + 1e-12)
    arrow = '↑ BETTER' if loss < BASELINE else '↓ worse'
    marker = ' ← WINNER' if rank == 0 else ''
    print(f'  {rank + 1:>3}  {label:<32}  {params:>10,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {arrow} {gain:.1f}x{marker}')
print_sep('CONCLUSION — WHICH HYBRID WINS?')
winner = results_sorted[0]
print(f"\n  WINNER: {winner[0]}\n  Loss:   {winner[2]:.8f}\n  Score:  {winner[3]}/{len(TESTS)}\n  Params: {winner[1]:,}\n  vs baseline: {BASELINE / winner[2]:.1f}x {('BETTER' if winner[2] < BASELINE else 'worse')}\n\n  WHAT THIS TELLS US:\n  If prime+flat hybrid wins →\n    Two geometries working together > either alone\n    Intuition (prime) + Reasoning (flat) = superior intelligence\n    Like left brain + right brain\n\n  If flat alone still wins →\n    Prime geometry interferes with residual learning\n    Even as a seed, prime constrains natural discovery\n    Pure freedom = best for deep networks\n\n  If parallel brain wins →\n    Different perspectives processed simultaneously\n    then merged = richer representation\n    This is how biological brains work\n    Multiple cortical areas process in parallel\n")
