import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W — NATURAL SPACE (FIXED)')
print('  GeLU: N >> 1280. Softmax: mask removed.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
blk = model.transformer.h[0]
att = blk.attn.attention
Wq = att.q_proj.weight.detach().numpy()
Wk = att.k_proj.weight.detach().numpy()
Wv = att.v_proj.weight.detach().numpy()
Wo = att.out_proj.weight.detach().numpy()
bo = att.out_proj.bias.detach().numpy()
W1 = blk.mlp.c_fc.weight.detach().numpy()
b1 = blk.mlp.c_fc.bias.detach().numpy()
W2 = blk.mlp.c_proj.weight.detach().numpy()
b2 = blk.mlp.c_proj.bias.detach().numpy()
ln1_w = blk.ln_1.weight.detach().numpy()
ln1_b = blk.ln_1.bias.detach().numpy()
ln2_w = blk.ln_2.weight.detach().numpy()
ln2_b = blk.ln_2.bias.detach().numpy()

def ln(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu_np(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def r2(A, Y):
    Ab = np.hstack([A, np.ones((len(A), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, Y, rcond=None)
    Yp = Ab @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    return float(1 - ss_res / ss_tot)

def report(name, A, Y, min_n=None):
    N, d = (A.shape[0], A.shape[1] if A.ndim > 1 else 1)
    score = r2(A, Y)
    reliable = '✓' if min_n is None or N >= min_n else f'⚠ need {min_n}'
    v = '= 1.000 EXACT' if score > 0.9999 else '≈ 0.999' if score > 0.999 else '> 0.99' if score > 0.99 else '> 0.95' if score > 0.95 else 'PARTIAL' if score > 0.5 else 'LOW'
    print(f'  {name:<42} R²={score:.6f}  {v}  {reliable}')
    return score
print(f'\n  Collecting large dataset (targeting N > 2000)...')
prompts = ['Once upon a time a little girl', 'The brave knight rode into battle', 'Deep in the forest there lived a', 'A small dog ran across the', 'The sun rose over the mountains and', 'She opened the old wooden door slowly', 'Every morning the bird would sing', 'He found a golden key hidden inside', 'The children played in the garden', 'Far away in a distant land there', 'A tiny mouse found some old cheese', 'The wizard waved his magic wand', 'Once there was a kind old farmer', 'The princess wore a silver crown', 'A rainbow appeared after the heavy rain', 'The farmer planted many seeds today', 'She read the old dusty book carefully', 'The river flowed through the valley', 'A butterfly landed on the red flower', 'The ship sailed across the deep sea', 'The moon shone bright in the dark sky', 'A little cat sat on the warm mat', 'He ran as fast as he could go', 'The trees swayed in the strong wind', 'She laughed and clapped her small hands', 'The baby slept in the soft bed', 'A big fish jumped out of the lake', 'The old man walked along the road', 'She picked flowers in the green meadow', 'The cook stirred the hot soup slowly', 'A bird built a nest in the tree', 'The children sang a happy song', 'He climbed up the tall old ladder', 'The queen smiled at her people', 'A fox ran through the dark forest', 'The boat rocked on the blue waves', 'She drew a picture of her house', 'The stars shone bright in the sky', 'A bear found honey in the log', 'The wind carried the leaves away']
SEQ_LEN = 15
PRE_all = []
POST_all = []
S_visible = []
LP_visible = []
with torch.no_grad():
    for prompt in prompts:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        x = (wte[ids] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
        ln2 = ln(x, ln2_w, ln2_b)
        pre = ln2 @ W1.T + b1
        post = gelu_np(pre)
        PRE_all.append(pre)
        POST_all.append(post)
        ln1 = ln(x, ln1_w, ln1_b)
        Q = ln1 @ Wq.T
        K = ln1 @ Wk.T
        Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
        for i in range(1, SEQ_LEN):
            s_row = Qh[0, i, :] @ Kh[0, :i + 1].T
            p_row = softmax_np(s_row[np.newaxis])[0]
            lp_row = np.log(p_row + 1e-10)
            for j in range(len(s_row)):
                S_visible.append([s_row[j]])
                LP_visible.append([lp_row[j]])
        for _ in range(25):
            out = model(torch.tensor([ids]))
            nxt = torch.argmax(out.logits[0, -1, :]).item()
            ids.append(nxt)
            ids_use = ids[-SEQ_LEN:]
            x = (wte[ids_use] + wpe[np.arange(SEQ_LEN)]).astype(np.float32)
            ln2 = ln(x, ln2_w, ln2_b)
            pre = ln2 @ W1.T + b1
            post = gelu_np(pre)
            PRE_all.append(pre)
            POST_all.append(post)
            ln1 = ln(x, ln1_w, ln1_b)
            Q = ln1 @ Wq.T
            K = ln1 @ Wk.T
            Qh = Q.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            Kh = K.reshape(SEQ_LEN, n_heads, head_dim).transpose(1, 0, 2)
            for i in range(1, SEQ_LEN):
                s_row = Qh[0, i, :] @ Kh[0, :i + 1].T
                p_row = softmax_np(s_row[np.newaxis])[0]
                lp_row = np.log(p_row + 1e-10)
                for j in range(len(s_row)):
                    S_visible.append([s_row[j]])
                    LP_visible.append([lp_row[j]])
PRE = np.vstack(PRE_all).astype(np.float32)
POST = np.vstack(POST_all).astype(np.float32)
S_v = np.array(S_visible, dtype=np.float32)
LP_v = np.array(LP_visible, dtype=np.float32)
N_gelu = len(PRE)
N_soft = len(S_v)
print(f'  GeLU samples: {N_gelu}  (FFN_D={FFN_D}, need >> {5 * FFN_D})')
print(f'  Softmax pairs: {N_soft} (scalar, always reliable)\n')
print(f"{'=' * 70}")
print(f'  GeLU NATURAL SPACE  (N={N_gelu}, FFN_D={FFN_D})')
print(f'  Reliable when N >> {5 * FFN_D} = {5 * FFN_D}')
print(f"{'=' * 70}\n")
min_n_gelu = 5 * FFN_D
report('pre → post  (standard)', PRE, POST, min_n_gelu)
alpha = np.where(np.abs(PRE) > 1e-06, POST / PRE, 0.0)
report('α alone → post', alpha, POST, min_n_gelu)
report('pre*α → post  (definitional)', PRE * alpha, POST, min_n_gelu)
report('(pre, α) joint → post', np.hstack([PRE, alpha]), POST, min_n_gelu * 2)
signed_sq = PRE * np.abs(PRE)
report('pre * |pre|  (signed square) → post', signed_sq, POST, min_n_gelu)
cube = PRE ** 3
report('pre^3 → post', cube, POST, min_n_gelu)
poly3 = np.hstack([PRE, PRE ** 2, PRE ** 3])
report('(pre, pre², pre³) poly → post', poly3, POST, min_n_gelu * 3)
print(f'\n  NOTE: If pre → post = 1.000 when N is sufficient,')
print(f'  then GeLU IS linear in pre-activation space.')
print(f'  The nonlinearity was an illusion of insufficient data.')
print(f"\n{'=' * 70}")
print(f'  SOFTMAX NATURAL SPACE  (N={N_soft} scalar pairs)')
print(f'  Mask removed. Only visible (non-masked) positions.')
print(f"{'=' * 70}\n")
score_s_lp = r2(S_v, LP_v)
print(f'  s → log(p)  [no mask, scalar pairs]:')
print(f'    R² = {score_s_lp:.8f}')
if score_s_lp > 0.9999:
    print(f'    = 1.000 EXACT')
    print(f'    PROVEN: softmax is linear in log-probability space.')
    print(f'    log(p_i) = s_i - C  where C = logsumexp(s) = same for all i.')
    print(f'    One constant subtraction = linear operation.')
    print(f'    Softmax is NOT nonlinear. Wrong coordinates before.')
else:
    print(f'    Not 1.000 yet. Residual = {1 - score_s_lp:.6f}')
    print(f'    Reason: logsumexp(s) varies per query position.')
    print(f'    C is not the same for all samples in the dataset.')
    print(f'    Each query has different C → s → log(p) not globally linear.')
    print(f'    Need per-query normalization.')
print(f'\n  Per-query test: s → log(p) for single attention row:')
print(f"  {'Query pos':<12} {'R²':<12} {'verdict'}")
print(f"  {'─' * 35}")
ids_test = tokenizer.encode('Once upon a time there was', return_tensors='pt')[0].tolist()
while len(ids_test) < 12:
    out = model(torch.tensor([ids_test]))
    ids_test.append(torch.argmax(out.logits[0, -1, :]).item())
x_test = (wte[ids_test] + wpe[np.arange(len(ids_test))]).astype(np.float32)
ln1_t = ln(x_test, ln1_w, ln1_b)
Q_t = ln1_t @ Wq.T
K_t = ln1_t @ Wk.T
Qh_t = Q_t.reshape(len(ids_test), n_heads, head_dim).transpose(1, 0, 2)
Kh_t = K_t.reshape(len(ids_test), n_heads, head_dim).transpose(1, 0, 2)
for i in range(2, len(ids_test)):
    s_row = Qh_t[0, i, :] @ Kh_t[0, :i + 1].T
    p_row = softmax_np(s_row[np.newaxis])[0]
    lp_row = np.log(p_row + 1e-10)
    A = s_row.reshape(-1, 1)
    Y = lp_row.reshape(-1, 1)
    score = r2(A, Y)
    v = '= 1.000 EXACT' if score > 0.9999 else f'{score:.6f}'
    print(f'  i={i:<10} {v}')
print(f"\n{'=' * 70}")
print(f'  W LAW — WHAT THE DATA SAYS')
print(f"{'=' * 70}\n")
print(f'\n  SOFTMAX:\n    Per-query: s → log(p) = ?\n    If 1.000: softmax is linear within its own row.\n    C = logsumexp(s) is the ONLY "nonlinear" piece.\n    But C = a scalar. Subtracted from all positions.\n    That is: ONE number changes per query.\n    Store C → reconstruction is exact linear.\n    Natural space = (s, C) or equivalently log(p).\n\n  GeLU:\n    pre → post = ? at N >> 1280\n    α = activation ratio (smooth 0→1 gate)\n    If pre → post = 1.000: GeLU is linear in pre.\n    That would mean: the transformation is exact linear\n    in pre-activation coordinates.\n    W principle: everything linear in its natural space.\n    \n  W PRINCIPLE STATUS:\n    No operation is truly nonlinear.\n    Each operation has a natural space.\n    In that space: R² = 1.000.\n    We are finding those spaces one by one.\n')
print('=' * 70 + '\n')
