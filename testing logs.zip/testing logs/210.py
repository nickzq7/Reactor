import numpy as np
import time
print('\n' + '=' * 62)
print('  W NATURE TEST')
print('  Fixed object or self-shaping principle?')
print('  Complex algorithms. Find the curving point.')
print('=' * 62)
np.random.seed(42)
N = 3000
N_tr = 2400

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def acc(pred, true):
    if pred.ndim > 1:
        return np.mean(pred.argmax(1) == true.argmax(1))
    return np.mean(np.round(pred) == true)

def fixed_W(X_tr, Y_tr, X_te):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    return (X_te @ W, W)

def adaptive_W(X_tr, Y_tr, X_te, feature_fn):
    X_tr_exp = feature_fn(X_tr)
    X_te_exp = feature_fn(X_te)
    W = np.linalg.lstsq(X_tr_exp, Y_tr, rcond=None)[0]
    return (X_te_exp @ W, W)

def relu(x):
    return np.maximum(0, x)

def softmax_row(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
print('\n' + '─' * 62)
print('  P1 — SORT')
print('  f(x) = sorted(x)')
print('  Requires pairwise comparison. Nonlinear.')
print('─' * 62)
L1 = 6
X1 = np.random.randn(N, L1)
Y1 = np.sort(X1, axis=1)
pred_fix, W_fix = fixed_W(X1[:N_tr], Y1[:N_tr], X1[N_tr:])
r2_fix = r2(pred_fix, Y1[N_tr:])

def sort_features(X):
    N_b, L = X.shape
    feats = [X]
    for i in range(L):
        for j in range(L):
            if i != j:
                feats.append((X[:, i] - X[:, j]).reshape(-1, 1))
    ranks = np.argsort(np.argsort(X, axis=1), axis=1).astype(float)
    feats.append(ranks)
    return np.column_stack(feats)
pred_ada, _ = adaptive_W(X1[:N_tr], Y1[:N_tr], X1[N_tr:], sort_features)
r2_ada = r2(pred_ada, Y1[N_tr:])
print(f"\n  Fixed W   R² = {r2_fix:.6f}  {('✓' if r2_fix > 0.99 else '✗ curving point found')}")
print(f"  Adaptive W R² = {r2_ada:.6f}  {('✓ W shaped itself' if r2_ada > 0.99 else '✗ still limited')}")
print(f'  Gain from adaptation: {r2_ada - r2_fix:+.4f}')
print(f"  INSIGHT: {('Adaptive W shapes itself to path — sort revealed' if r2_ada > r2_fix + 0.1 else 'Both behave similarly here')}")
print('\n' + '─' * 62)
print('  P2 — FIBONACCI RECURRENCE')
print('  f(n) = f(n-1) + f(n-2)')
print('  History matters. State propagates.')
print('─' * 62)
L2 = 6
X2 = np.zeros((N, L2))
a_vals = np.random.uniform(0.3, 0.8, N)
b_vals = np.random.uniform(0.1, 0.5, N)
X2[:, 0] = np.random.randn(N) * 0.5
X2[:, 1] = np.random.randn(N) * 0.5
for t in range(2, L2):
    X2[:, t] = a_vals * X2[:, t - 1] + b_vals * X2[:, t - 2] + np.random.randn(N) * 0.01
Y2 = (a_vals * X2[:, L2 - 1] + b_vals * X2[:, L2 - 2]).reshape(-1, 1)
pred_fix, _ = fixed_W(X2[:N_tr], Y2[:N_tr], X2[N_tr:])
r2_fix = r2(pred_fix, Y2[N_tr:])

def fib_features(X):
    t1 = X[:, -1].reshape(-1, 1)
    t2 = X[:, -2].reshape(-1, 1)
    return np.column_stack([X, t1, t2, t1 * t2, t1 ** 2, t2 ** 2])
pred_ada, _ = adaptive_W(X2[:N_tr], Y2[:N_tr], X2[N_tr:], fib_features)
r2_ada = r2(pred_ada, Y2[N_tr:])
print(f'\n  Fixed W    R² = {r2_fix:.6f}')
print(f'  Adaptive W R² = {r2_ada:.6f}')
print(f'  Gain: {r2_ada - r2_fix:+.4f}')
print(f'  NOTE: Each row has different a,b recurrence.')
print(f'  W shapes to path means: W learns to READ a,b from history.')
print('\n' + '─' * 62)
print('  P3 — PALINDROME DETECTION')
print('  f(seq) = 1 if seq == reversed(seq)')
print('  Bidirectional comparison. Symmetry detection.')
print('─' * 62)
L3 = 6
seqs = np.random.randn(N, L3)
is_pal = np.zeros(N)
for i in range(0, N, 2):
    half = seqs[i, :L3 // 2]
    seqs[i] = np.concatenate([half, half[::-1]])
    is_pal[i] = 1.0
Y3 = is_pal.reshape(-1, 1)
pred_fix, _ = fixed_W(seqs[:N_tr], Y3[:N_tr], seqs[N_tr:])
acc_fix = np.mean((pred_fix > 0.5).astype(float) == Y3[N_tr:])

def pal_features(X):
    L = X.shape[1]
    feats = [X]
    for i in range(L // 2):
        j = L - 1 - i
        diff = (X[:, i] - X[:, j]).reshape(-1, 1)
        feats.append(diff)
        feats.append(np.abs(diff))
    sym = np.mean(np.abs(X - X[:, ::-1]), axis=1, keepdims=True)
    feats.append(sym)
    return np.column_stack(feats)
X3_exp_tr = pal_features(seqs[:N_tr])
X3_exp_te = pal_features(seqs[N_tr:])
W_ada = np.linalg.lstsq(X3_exp_tr, Y3[:N_tr], rcond=None)[0]
pred_ada = X3_exp_te @ W_ada
acc_ada = np.mean((pred_ada > 0.5).astype(float) == Y3[N_tr:])
print(f'\n  Fixed W    Acc = {acc_fix * 100:.1f}%')
print(f'  Adaptive W Acc = {acc_ada * 100:.1f}%')
print(f'  Gain: {(acc_ada - acc_fix) * 100:+.1f}%')
print(f'  Symmetry features = W sees mirror of each path.')
print('\n' + '─' * 62)
print('  P4 — RUN DETECTION')
print('  How many consecutive tokens are the same?')
print('  State machine behavior. Grouping.')
print('─' * 62)
L4 = 8
X4 = (np.random.rand(N, L4) > 0.4).astype(float)
Y4 = np.zeros((N, L4))
for i in range(N):
    run = 1
    for t in range(1, L4):
        if X4[i, t] == X4[i, t - 1]:
            run += 1
        else:
            run = 1
        Y4[i, t] = run
    Y4[i, 0] = 1
pred_fix, _ = fixed_W(X4[:N_tr], Y4[:N_tr], X4[N_tr:])
r2_fix = r2(pred_fix, Y4[N_tr:])

def run_features(X):
    feats = [X]
    for t in range(1, X.shape[1]):
        same = (X[:, t] == X[:, t - 1]).astype(float).reshape(-1, 1)
        feats.append(same)
    trans = np.column_stack([(X[:, t] == X[:, t - 1]).astype(float) for t in range(1, X.shape[1])])
    feats.append(np.cumsum(trans, axis=1))
    return np.column_stack(feats)
pred_ada, _ = adaptive_W(X4[:N_tr], Y4[:N_tr], X4[N_tr:], run_features)
r2_ada = r2(pred_ada, Y4[N_tr:])
print(f'\n  Fixed W    R² = {r2_fix:.6f}')
print(f'  Adaptive W R² = {r2_ada:.6f}')
print(f'  Gain: {r2_ada - r2_fix:+.4f}')
print('\n' + '─' * 62)
print('  P5 — BRACKET DEPTH (stack behavior)')
print('  f(seq) = nesting depth at each position')
print('  Memory of all prior tokens required.')
print('  Most complex. Where does W curve?')
print('─' * 62)
L5 = 10
X5 = np.zeros((N, L5))
Y5 = np.zeros((N, L5))
for i in range(N):
    depth = 0
    for t in range(L5):
        if depth == 0:
            tok = 1.0
        elif depth >= 4:
            tok = -1.0
        else:
            tok = 1.0 if np.random.rand() > 0.45 else -1.0
        depth += int(tok)
        depth = max(0, depth)
        X5[i, t] = tok
        Y5[i, t] = float(depth)
pred_fix, _ = fixed_W(X5[:N_tr], Y5[:N_tr], X5[N_tr:])
r2_fix = r2(pred_fix, Y5[N_tr:])

def bracket_features(X):
    cs = np.cumsum(X, axis=1)
    rm = np.maximum.accumulate(cs, axis=1)
    return np.column_stack([X, cs, rm])
pred_ada, _ = adaptive_W(X5[:N_tr], Y5[:N_tr], X5[N_tr:], bracket_features)
r2_ada = r2(pred_ada, Y5[N_tr:])
print(f'\n  Fixed W    R² = {r2_fix:.6f}')
print(f'  Adaptive W R² = {r2_ada:.6f}')
print(f'  Gain: {r2_ada - r2_fix:+.4f}')
print(f"  Cumsum = depth. W finds it {('PERFECTLY' if r2_ada > 0.999 else 'partially')}.")
print('\n' + '=' * 62)
print('  THE CURVING POINT — REVEALED')
print('=' * 62)
data = [('P1 Sort', r2_fix, r2_ada, 'pairwise comparison'), ('P2 Fibonacci', r2_fix, r2_ada, 'path-own recurrence'), ('P3 Palindrome', acc_fix, acc_ada, 'mirror symmetry'), ('P4 Run-length', r2_fix, r2_ada, 'transition detection'), ('P5 Brackets', r2_fix, r2_ada, 'cumsum = depth')]
print(f"\n  {'Program':<16} {'Fixed W':>9} {'Adaptive':>9} {'Gain':>7} {'What shapes W'}")
print(f"  {'-' * 65}")
for name, f, a, insight in data:
    gain = a - f
    mark = '← CURVE' if gain > 0.2 else ''
    print(f'  {name:<16} {f:>9.4f} {a:>9.4f} {gain:>+7.4f}  {mark}')
print(f"\n  ──────────────────────────────────────────────────────\n\n  WHAT THE RESULTS SHOW:\n\n  Fixed W = same road for every traveler.\n  Works when function is universal.\n  Fails when function depends on THIS path's nature.\n\n  Adaptive W = universe shaping to each path.\n  W is ONE principle.\n  Expression = what THIS input's path requires.\n\n  The curving point is:\n  Where the function needs to KNOW\n  something specific about THIS input\n  that no fixed matrix can know in advance.\n\n  Sort needs to know: how do THESE values compare?\n  Fibonacci needs to know: what is THIS sequence's a,b?\n  Palindrome needs to know: is THIS sequence symmetric?\n  Brackets needs to know: what is THIS sequence's depth?\n\n  In all cases:\n  The information is IN the input itself.\n  Adaptive W extracts it from the input's own path.\n  Then shapes its response accordingly.\n\n  This IS the universe principle:\n  Universe does not force path.\n  Universe reads the path's own nature.\n  Responds to what that path IS.\n  Not to what a fixed rule says.\n\n  W = one principle.\n  W(x) = base + what_x_reveals_about_itself.\n  This is adaptive W.\n  This is the true form of W.\n\n  NEXT:\n  Apply adaptive W to transformer.\n  Transformer input reveals its own structure.\n  Q, K, V are the input revealing itself.\n  Attention = input shaping W for itself.\n  W reads. Responds. Does not force.\n  This is already IN the transformer.\n  We just needed to see it this way.\n")
print('=' * 62 + '\n')
