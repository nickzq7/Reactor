import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL FROM SCRATCH — CHARACTER LEVEL')
print('  No pretrained model. Raw text only.')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\nand flowers and all the small creatures that lived among the leaves\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with his\niron glove at last he reached the edge of the forest and called out\nthe child answered from behind a large tree where she had been hiding\nthe knight lifted her onto his horse and wrapped his cloak around her\nto keep her warm they rode back to the village as the first stars\nappeared in the sky and the people came out to greet them with lights\nand warm bread and kind words the knight stayed the night and left in\nthe morning before anyone else was awake leaving only his footprints\nin the soft mud as a sign that he had been there and done what he came\nto do the little cloud named wisp floated over the green valley and\nwatched the people work in their fields below wisp was smaller than\nall the other clouds and sometimes felt that being small was not useful\nbut one very hot day when the sun was beating down on the fields wisp\ndrifted slowly in front of the sun and made a small cool shadow on the\nearth below a farmer looked up and smiled and wiped his forehead and\nwent back to work wisp felt very happy to have helped even in a small\nway and from that day on wisp always tried to find a place where a\nlittle bit of shade might make someone or something feel better\n'
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VOCAB_SIZE = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Text length  : {len(TEXT)} chars')
print(f'  Vocab size   : {VOCAB_SIZE} chars')
print(f'  Tokens       : {len(tokens)}')
D = 64
FFN_D = 128
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 2
SEQ_LEN = 16
LR_INIT = 0.01
print(f'\n  D={D}  FFN_D={FFN_D}  Heads={N_HEADS}  Layers={N_LAYERS}')
print(f'  SEQ_LEN={SEQ_LEN}')

def init_weights():
    w = {}
    w['wte'] = np.random.randn(VOCAB_SIZE, D).astype(np.float64) * 0.1
    w['wpe'] = np.random.randn(SEQ_LEN + 1, D).astype(np.float64) * 0.1
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1_g{s}'] = np.ones(D, dtype=np.float64)
        w[f'ln1_b{s}'] = np.zeros(D, dtype=np.float64)
        w[f'ln2_g{s}'] = np.ones(D, dtype=np.float64)
        w[f'ln2_b{s}'] = np.zeros(D, dtype=np.float64)
        w[f'Wq{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'Wk{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'Wv{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'Wo{s}'] = np.random.randn(D, D).astype(np.float64) * 0.02
        w[f'bo{s}'] = np.zeros(D, dtype=np.float64)
        w[f'W1{s}'] = np.random.randn(FFN_D, D).astype(np.float64) * 0.02
        w[f'b1{s}'] = np.zeros(FFN_D, dtype=np.float64)
        w[f'W2{s}'] = np.random.randn(D, FFN_D).astype(np.float64) * 0.02
        w[f'b2{s}'] = np.zeros(D, dtype=np.float64)
    w['lnf_g'] = np.ones(D, dtype=np.float64)
    w['lnf_b'] = np.zeros(D, dtype=np.float64)
    return w

def ln(x, g, b, eps=1e-05):
    x = np.array(x, dtype=np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    x = np.array(x, dtype=np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def forward_full(ids, w):
    T = len(ids)
    x = (w['wte'][ids] + w['wpe'][:T]).copy()
    states = [x.copy()]
    for li in range(N_LAYERS):
        s = str(li)
        ln1_out = np.array([ln(x[i], w[f'ln1_g{s}'], w[f'ln1_b{s}']) for i in range(T)])
        Q = ln1_out @ w[f'Wq{s}'].T
        K = ln1_out @ w[f'Wk{s}'].T
        V = ln1_out @ w[f'Wv{s}'].T
        Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
        Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
        Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
        context = np.stack([probs[h] @ Vh[h] for h in range(N_HEADS)], 1).reshape(T, D)
        att_out = context @ w[f'Wo{s}'].T + w[f'bo{s}']
        x_att = x + att_out
        x_new = x_att.copy()
        for t in range(T):
            ln2t = ln(x_att[t], w[f'ln2_g{s}'], w[f'ln2_b{s}'])
            pre = ln2t @ w[f'W1{s}'].T + w[f'b1{s}']
            x_new[t] = x_att[t] + gelu(pre) @ w[f'W2{s}'].T + w[f'b2{s}']
        x = x_new
        states.append(x.copy())
    x_final = np.array([ln(x[t], w['lnf_g'], w['lnf_b']) for t in range(T)])
    logits = x_final @ w['wte'].T
    return (logits, states, x)

def perplexity(w, n_samples=300):
    nll = 0.0
    tok = 0
    step = max(1, len(tokens) // n_samples)
    for start in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[start:start + SEQ_LEN]
        tgt = tokens[start + SEQ_LEN]
        logits, _, _ = forward_full(ids, w)
        lg = logits[-1] - logits[-1].max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[tgt]
        tok += 1
    return math.exp(nll / tok) if tok > 0 else float('inf')

def solve_ridge(X, Y, lam=0.0001):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    return np.linalg.solve(A, Xb.T @ Y)
print(f"\n{'=' * 70}")
print(f'  FROM-SCRATCH TRAINING — COORDINATE DESCENT')
print(f'  Target: text supervision only.')
print(f'  Each round: one matrix inversion per sub-layer.')
print(f"{'=' * 70}")
w = init_weights()
ppl_random = perplexity(w)
print(f'\n  Random init perplexity : {ppl_random:.2f}')
print(f'  Vocab size (ceiling)   : {VOCAB_SIZE:.2f}')
print(f'  Target                 : < {VOCAB_SIZE:.0f} = learned something\n')
N_ROUNDS = 20
BATCH = 400
print(f'  Rounds={N_ROUNDS}, Batch={BATCH} seqs per round')
print(f"\n  {'Round':<7} {'Perplexity':>12} {'vs Random':>10} {'time':>6}")
print(f"  {'─' * 40}")
t_total = time.time()
ppl_history = [ppl_random]
for rnd in range(N_ROUNDS):
    t_rnd = time.time()
    layer_data = {li: {'ln2': [], 'pre': [], 'gelu_out': [], 'delta_ffn': [], 'context': [], 'x_before_att': [], 'delta_att': [], 'x_att': []} for li in range(N_LAYERS)}
    indices = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
    for idx in indices:
        ids = tokens[idx:idx + SEQ_LEN]
        next_tok = tokens[idx + SEQ_LEN]
        _, states, x_last = forward_full(ids, w)
        target_hidden = w['wte'][next_tok].copy()
        x = (w['wte'][ids] + w['wpe'][:SEQ_LEN]).copy()
        current_target = target_hidden
        for li in range(N_LAYERS):
            s = str(li)
            ln1_out = np.array([ln(x[i], w[f'ln1_g{s}'], w[f'ln1_b{s}']) for i in range(SEQ_LEN)])
            Q = ln1_out @ w[f'Wq{s}'].T
            K = ln1_out @ w[f'Wk{s}'].T
            V = ln1_out @ w[f'Wv{s}'].T
            Qh = Q.reshape(SEQ_LEN, N_HEADS, HEAD_D).transpose(1, 0, 2)
            Kh = K.reshape(SEQ_LEN, N_HEADS, HEAD_D).transpose(1, 0, 2)
            Vh = V.reshape(SEQ_LEN, N_HEADS, HEAD_D).transpose(1, 0, 2)
            mask = np.triu(np.full((SEQ_LEN, SEQ_LEN), float('-inf')), 1)
            probs = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
            context = np.stack([probs[h] @ Vh[h] for h in range(N_HEADS)], 1).reshape(SEQ_LEN, D)
            att_out = context @ w[f'Wo{s}'].T + w[f'bo{s}']
            x_att = x + att_out
            ln2_last = ln(x_att[-1], w[f'ln2_g{s}'], w[f'ln2_b{s}'])
            pre_last = ln2_last @ w[f'W1{s}'].T + w[f'b1{s}']
            gelu_last = gelu(pre_last)
            ffn_out = gelu_last @ w[f'W2{s}'].T + w[f'b2{s}']
            x_new = x_att.copy()
            x_new[-1] = x_att[-1] + ffn_out
            target_x_new_last = current_target
            target_delta_ffn = target_x_new_last - x_att[-1]
            target_delta_att = target_x_new_last - x[-1] - ffn_out
            layer_data[li]['ln2'].append(ln2_last.copy())
            layer_data[li]['pre'].append(pre_last.copy())
            layer_data[li]['gelu_out'].append(gelu_last.copy())
            layer_data[li]['delta_ffn'].append(target_delta_ffn.copy())
            layer_data[li]['context'].append(context[-1].copy())
            layer_data[li]['delta_att'].append(target_delta_att.copy())
            x = x_new
            current_target = target_hidden
    for li in range(N_LAYERS):
        s = str(li)
        ld = layer_data[li]
        X_ln2 = np.array(ld['ln2'], dtype=np.float64)
        Y_pre = np.array(ld['pre'], dtype=np.float64)
        X_gelu = np.array(ld['gelu_out'], dtype=np.float64)
        Y_dffn = np.array(ld['delta_ffn'], dtype=np.float64)
        X_ctx = np.array(ld['context'], dtype=np.float64)
        Y_datt = np.array(ld['delta_att'], dtype=np.float64)
        W1_new = solve_ridge(X_ln2, Y_pre, lam=0.0001)
        w[f'W1{s}'] = W1_new[:-1].T
        w[f'b1{s}'] = W1_new[-1]
        W2_new = solve_ridge(X_gelu, Y_dffn, lam=0.0001)
        w[f'W2{s}'] = W2_new[:-1].T
        w[f'b2{s}'] = W2_new[-1]
        Wo_new = solve_ridge(X_ctx, Y_datt, lam=0.0001)
        w[f'Wo{s}'] = Wo_new[:-1].T
        w[f'bo{s}'] = Wo_new[-1]
    ppl = perplexity(w)
    ppl_history.append(ppl)
    dt = time.time() - t_rnd
    vs = ppl / ppl_random
    trend = '↓' if len(ppl_history) > 1 and ppl < ppl_history[-2] else '→'
    print(f'  {rnd + 1:<7} {ppl:>12.2f} {vs:>10.4f}   {dt:>4.0f}s  {trend}')
print(f"\n{'=' * 70}")
print(f'  FINAL EVALUATION')
print(f"{'=' * 70}\n")
print(f'  Random init    : {ppl_history[0]:.2f}')
print(f'  After training : {ppl_history[-1]:.2f}')
print(f'  Reduction      : {(1 - ppl_history[-1] / ppl_history[0]) * 100:.1f}%')
print(f'  Vocab ceiling  : {VOCAB_SIZE:.0f}')
print(f'\n  GENERATION TEST (from scratch, W-Kernel trained):\n')
gen_prompts = ['once upon a time', 'the brave knight', 'deep in the forest']
for gp in gen_prompts:
    ids_g = [vocab.get(c, 0) for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(80):
        logits, _, _ = forward_full(gen[-SEQ_LEN:], w)
        gen.append(int(np.argmax(logits[-1])))
    out_text = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  '{gp}'")
    print(f'    → {out_text[len(gp):][:80]}')
    print()
final_ppl = ppl_history[-1]
print(f"\n{'=' * 70}")
print(f'  VERDICT')
print(f"{'=' * 70}\n")
if final_ppl < VOCAB_SIZE * 0.5:
    v = f'✓ LEARNED FROM SCRATCH  (ppl={final_ppl:.1f} << random={ppl_history[0]:.1f})'
elif final_ppl < VOCAB_SIZE * 0.9:
    v = f'~ PARTIAL LEARNING       (ppl={final_ppl:.1f} < random={ppl_history[0]:.1f})'
else:
    v = f'! NOT YET LEARNING       (ppl={final_ppl:.1f} ≈ random={ppl_history[0]:.1f})'
print(f'  {v}\n')
print(f'  WHAT THIS PROVES:\n    If ppl < vocab_size:\n      W-Kernel coordinate descent learns from raw text.\n      No gradient descent. No backprop.\n      Each round = matrix inversion per sub-layer.\n      One step per sub-layer per round.\n      \n    Training signal: text only (wte[next_char]).\n    No pretrained model used anywhere.\n    This is FROM SCRATCH.\n    \n    Rounds to convergence: {len(ppl_history) - 1}\n    Each round: O(batch × N_layers) forward passes\n                + N_layers × 3 matrix inversions\n    Total: {time.time() - t_total:.0f}s\n')
print('=' * 70 + '\n')
