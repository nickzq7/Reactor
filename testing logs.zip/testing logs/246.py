import numpy as np, math, time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v17 — ONE-HOT + PSEUDOINVERSE')
print('  Clean condition. No ridge. Exact bigram/n-gram kernel.')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
print(f'\n  Vocab={VS} Tokens={N}\n')

def pinv_solve(X, Y):
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    thresh = S[0] * 1e-12
    mask = S > thresh
    S_inv = np.where(mask, 1.0 / np.where(mask, S, 1.0), 0.0)
    return Vt.T @ np.diag(S_inv) @ U.T @ Y

def eval_ppl(X, Y, W, n=1000):
    step = max(1, len(X) // n)
    nll = 0.0
    ne = 0
    for i in range(0, len(X), step):
        lg = X[i] @ W
        if not np.all(np.isfinite(lg)):
            continue
        lg -= lg.max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[np.argmax(Y[i])]
        ne += 1
    return math.exp(min(nll / ne, 500)) if ne > 0 else 999.0

def build_onehot(K):
    X = np.zeros((N - K, K * VS), dtype=np.float32)
    Y = np.zeros((N - K, VS), dtype=np.float32)
    for i in range(K, N):
        for j in range(K):
            X[i - K, j * VS + toks[i - K + j]] = 1.0
        Y[i - K, toks[i]] = 1.0
    return (X.astype(np.float64), Y.astype(np.float64))
print(f"  {'K':>3}  {'D_in':>6}  {'N/D':>6}  {'ppl':>8}  {'rank':>6}  after 't'")
print(f"  {'-' * 55}")
best_K = 1
best_ppl = 999.0
best_W = None
best_X = None
for K in [1, 2, 3, 4, 6, 8]:
    X, Y = build_onehot(K)
    W = pinv_solve(X, Y)
    p = eval_ppl(X, Y, W)
    _, S, _ = np.linalg.svd(X, full_matrices=False)
    rank = int(np.sum(S > S[0] * 1e-12))
    xq = np.zeros(K * VS, dtype=np.float64)
    xq[(K - 1) * VS + c2i['t']] = 1.0
    lg = xq @ W
    lg -= lg.max()
    pv = np.exp(lg)
    pv /= pv.sum()
    top2 = [(i2c[i], f'{100 * pv[i]:.0f}%') for i in np.argsort(-pv)[:2]]
    print(f'  K={K}  D={K * VS:>5}  N/D={N // (K * VS):>4}x  ppl={p:>7.2f}  rank={rank:>4}/{K * VS}  {top2}')
    if p < best_ppl:
        best_ppl = p
        best_K = K
        best_W = W.copy()
        best_X = X
print(f'\n  Best: K={best_K}  ppl={best_ppl:.2f}')
K = best_K
X, Y = build_onehot(K)
W = best_W
print(f'\n  BIGRAM CHECK (K={K}, last position only):')
for prev in ['t', 'h', 'e', ' ', 'a', 'n', 'd']:
    if prev not in c2i:
        continue
    x = np.zeros(K * VS, dtype=np.float64)
    x[(K - 1) * VS + c2i[prev]] = 1.0
    lg = x @ W
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{prev}': {top3}")
print(f'\n  W MATRIX ANALYSIS (last position rows = bigram table):')
print(f'  W[last_pos,c] = weight for char c predicting next')
if K == 1:
    for prev in ['t', 'h', ' ']:
        if prev not in c2i:
            continue
        row = W[c2i[prev]]
        row_p = np.exp(row - row.max())
        row_p /= row_p.sum()
        top3 = [(i2c[i], f'{100 * row_p[i]:.0f}%') for i in np.argsort(-row_p)[:3]]
        print(f"  W['{prev}',:] as probs: {top3}")

def sample(lg, temp=0.8, top_k=8):
    lg = lg - lg.max()
    lg = lg / temp
    if top_k < len(lg):
        thresh = np.sort(lg)[-top_k]
        lg[lg < thresh] = -10000000000.0
    p = np.exp(lg)
    p /= p.sum()
    return int(np.random.choice(VS, p=p))

def embed_oh(ids, K):
    x = np.zeros(K * VS, dtype=np.float64)
    ctx = list(ids[-K:]) if len(ids) >= K else [0] * (K - len(ids)) + list(ids)
    for j, tok in enumerate(ctx[-K:]):
        x[j * VS + tok] = 1.0
    return x

def generate(prompt, K, W, n=150, temp=0.8, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        lg = embed_oh(ids, K) @ W
        if not np.all(np.isfinite(lg)):
            break
        ids.append(sample(lg, temp=temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION (K={best_K}, temp=0.8):')
for p in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(p, best_K, best_W)
    print(f"  '{p}'")
    print(f'    {out[len(p):][:70]}')
gs = generate('the ', best_K, best_W, n=300, temp=0.85)
sp = 100 * gs[4:].count(' ') / len(gs[4:])
cnt = Counter(gs[4:])
top5 = [(c, f'{100 * cnt[c] // len(gs[4:])}%') for c, _ in cnt.most_common(5)]
print(f'\n  Space%={sp:.0f}%  Top-5:{top5}')
print(f'  Sample: {gs[4:80]}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  Best K={best_K}  ppl={best_ppl:.2f}  vocab={VS}')
print(f'\n  W-KERNEL (v17 = clean form):')
print(f'    x = one-hot(context K chars)  ({best_K * VS}d)')
print(f'    logits = x @ W*')
print(f'    W* = pinv(X) @ Y  — exact, no ridge')
print(f'  K=1: W*[c,:] = P(next|c) = bigram table. Exact.')
print(f'  K>1: W*[(j,c),:] = P(next|c at position j). N-gram.')
print('=' * 65 + '\n')
