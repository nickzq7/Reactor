import os, time
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTNeoConfig
from datasets import load_dataset
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
PROMPTS = ['Once upon a time there was a little', 'The dog ran to', 'She was happy because', 'One day a small boy found', 'The rabbit hopped into the']

def gen(model, tokenizer, prompt, max_new=40):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.3, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def score_model(model, tokenizer, label):
    print(f"\n{'=' * 60}")
    print(f'  {label}')
    print(f"{'=' * 60}")
    total_loss = 0
    model.eval()
    for p in PROMPTS:
        out = gen(model, tokenizer, p)
        continuation = out[len(p):].strip().replace('\n', ' ')
        ids = tokenizer(out, return_tensors='pt', truncation=True, max_length=64).input_ids.to(device)
        with torch.no_grad():
            loss = model(ids, labels=ids).loss.item()
        total_loss += loss
        print(f'  P: {p}')
        print(f'  O: {continuation[:70]}')
        print(f'  loss={loss:.4f}\n')
    avg = total_loss / len(PROMPTS)
    print(f'  AVG LOSS: {avg:.4f}  (lower = better story quality)')
    return avg
print('\nLoading TinyStories-33M (original)...')
tok_big = AutoTokenizer.from_pretrained('roneneldan/TinyStories-33M')
tok_big.pad_token = tok_big.eos_token
model_big = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-33M').to(device)
score_big = score_model(model_big, tok_big, 'TINYSTORIES-33M  (original pretrained)')
model_big.cpu()
del model_big
torch.cuda.empty_cache()
print('\nBuilding raw 1M kernel...')
tok_small = AutoTokenizer.from_pretrained('gpt2')
tok_small.pad_token = tok_small.eos_token
kernel = AutoModelForCausalLM.from_config(GPTNeoConfig(vocab_size=50257, hidden_size=32, num_layers=2, attention_types=[[['global'], 2]], num_heads=2, intermediate_size=128, max_position_embeddings=128, window_size=128, resid_pdrop=0.0, embed_pdrop=0.0, attention_dropout=0.0)).to(device)
print(f'Kernel params: {sum((p.numel() for p in kernel.parameters())):,}')
print('\nLoading TinyStories data from cache...')
raw = load_dataset('roneneldan/TinyStories', split='train')
texts = raw['text'][:5000]
print(f'Loaded {len(texts)} stories')

class SD(Dataset):

    def __init__(self, texts):
        self.data = []
        for t in texts:
            enc = tok_small(t, truncation=True, max_length=64, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
loader = DataLoader(SD(texts), batch_size=64, shuffle=True)
opt = torch.optim.AdamW(kernel.parameters(), lr=0.0003)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=30, eta_min=1e-05)
best_loss = 9999
best_model = None
best_opt = None
print(f"\n  {'Ep':>3}  {'Loss':>8}  {'Time':>5}  Status")
print(f"  {'─' * 40}")
for ep in range(1, 31):
    kernel.train()
    total = 0
    t0 = time.time()
    for batch in loader:
        batch = batch.to(device)
        opt.zero_grad()
        loss = kernel(batch, labels=batch).loss
        loss.backward()
        nn.utils.clip_grad_norm_(kernel.parameters(), 1.0)
        opt.step()
        total += loss.item()
    sched.step()
    avg = total / len(loader)
    sec = time.time() - t0
    if avg < best_loss:
        best_loss = avg
        best_model = {k: v.clone().cpu() for k, v in kernel.state_dict().items()}
        best_opt = {k: v.clone() if isinstance(v, torch.Tensor) else v for k, v in opt.state_dict().items()}
        tag = f'BEST {best_loss:.4f} ✓'
    else:
        kernel.load_state_dict({k: v.to(device) for k, v in best_model.items()})
        opt.load_state_dict(best_opt)
        tag = f'ROLLED BACK (best={best_loss:.4f})'
    print(f'  {ep:>3}  {avg:>8.4f}  {sec:>4.1f}s  {tag}')
kernel.load_state_dict(best_model)
score_small = score_model(kernel, tok_small, 'TRAINED 1M KERNEL')
print(f"\n{'=' * 60}")
print(f'  FINAL COMPARISON')
print(f"{'=' * 60}")
print(f'  TinyStories-33M (33M params, pretrained) : {score_big:.4f}')
print(f'  Trained 1M Kernel (1M params, from scratch): {score_small:.4f}')
print(f'  Gap : {score_small - score_big:.4f}')
print(f"{'=' * 60}")
_dir = os.path.dirname(os.path.abspath(__file__))
kernel.save_pretrained(os.path.join(_dir, 'tiny1m_trained'))
print('Saved.')
