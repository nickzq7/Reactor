import torch
import torch.nn as nn
import numpy as np
from collections import Counter, defaultdict
from transformers import AutoModelForCausalLM, AutoTokenizer
import math, re
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")

class AtomDiscovery:

    def __init__(self, pmi_threshold=6.0, min_count=4):
        self.pmi_threshold = pmi_threshold
        self.min_count = min_count
        self.atoms = []
        self.atom_map = {}

    def compute_pmi(self, sequences):
        bigram_count = Counter()
        unigram_count = Counter()
        for seq in sequences:
            for i in range(len(seq) - 1):
                bigram_count[seq[i], seq[i + 1]] += 1
                unigram_count[seq[i]] += 1
            if seq:
                unigram_count[seq[-1]] += 1
        total = sum(unigram_count.values())
        pmi_scores = {}
        for (a, b), count in bigram_count.items():
            if count < self.min_count:
                continue
            p_ab = count / total
            p_a = unigram_count[a] / total
            p_b = unigram_count[b] / total
            if p_a > 0 and p_b > 0:
                pmi = math.log2(p_ab / (p_a * p_b))
                pmi_scores[a, b] = (pmi, count)
        return pmi_scores

    def merge_atom(self, sequences, atom_a, atom_b, atom_id):
        new_seqs = []
        for seq in sequences:
            new_seq = []
            i = 0
            while i < len(seq):
                if i < len(seq) - 1 and seq[i] == atom_a and (seq[i + 1] == atom_b):
                    new_seq.append(atom_id)
                    i += 2
                else:
                    new_seq.append(seq[i])
                    i += 1
            new_seqs.append(new_seq)
        return new_seqs

    def discover(self, sequences, tokenizer=None, max_atoms=40):
        working_seqs = [list(s) for s in sequences]
        all_toks = set((t for s in sequences for t in s))
        next_id = max(all_toks) + 1 if all_toks else 1000
        atom_composition = {}
        print(f'\n  Discovering atoms iteratively...')
        print(f'  PMI threshold: {self.pmi_threshold}')
        print(f'  Min count: {self.min_count}\n')
        for iteration in range(max_atoms):
            pmi_scores = self.compute_pmi(working_seqs)
            if not pmi_scores:
                break
            best_pair = max(pmi_scores.items(), key=lambda x: x[1][0])
            (a, b), (pmi, count) = best_pair
            if pmi < self.pmi_threshold:
                break
            atom_id = next_id
            next_id += 1
            name_a = atom_composition.get(a, a)
            name_b = atom_composition.get(b, b)
            if tokenizer:
                try:
                    raw_a = tokenizer.decode([a]) if isinstance(a, int) and a < tokenizer.vocab_size else str(name_a)
                    raw_b = tokenizer.decode([b]) if isinstance(b, int) and b < tokenizer.vocab_size else str(name_b)
                    atom_name = f'{raw_a.strip()}_{raw_b.strip()}'
                except:
                    atom_name = f'atom_{iteration}'
            else:
                atom_name = f'atom_{iteration}'
            atom_composition[atom_id] = atom_name
            self.atoms.append((a, b, pmi, count, atom_name, atom_id))
            self.atom_map[a, b] = atom_id
            working_seqs = self.merge_atom(working_seqs, a, b, atom_id)
            avg_len_before = np.mean([len(s) for s in sequences])
            avg_len_after = np.mean([len(s) for s in working_seqs])
            print(f"  [{iteration + 1:>2}] '{atom_name}'  PMI={pmi:.3f}  count={count}  seq_len: {avg_len_after:.1f}")
        self.working_seqs = working_seqs
        self.atom_composition = atom_composition
        return working_seqs

    def encode(self, sequence):
        seq = list(sequence)
        for a, b, _, _, _, atom_id in self.atoms:
            seq = self.merge_atom([seq], a, b, atom_id)[0]
        return seq

    def compression_ratio(self, original_seqs, compressed_seqs):
        orig_len = np.mean([len(s) for s in original_seqs])
        comp_len = np.mean([len(s) for s in compressed_seqs])
        return orig_len / comp_len
print_sep('PHASE 1 — TINYSTORIES ATOM DISCOVERY')
TS_MODEL = 'roneneldan/TinyStories-1M'
ts_tok = AutoTokenizer.from_pretrained(TS_MODEL)
if ts_tok.pad_token is None:
    ts_tok.pad_token = ts_tok.eos_token
try:
    ts_model = AutoModelForCausalLM.from_pretrained(TS_MODEL, dtype=torch.float32, use_safetensors=True)
except:
    ts_model = AutoModelForCausalLM.from_pretrained(TS_MODEL, torch_dtype=torch.float32)
ts_model = ts_model.to(device)
ts_model.eval()
print(f'  TinyStories-1M loaded: {sum((p.numel() for p in ts_model.parameters())):,} params')

def generate_ts(prompt, max_new=100, temp=0.8):
    inputs = ts_tok(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        out = ts_model.generate(**inputs, max_new_tokens=max_new, temperature=temp, do_sample=True, pad_token_id=ts_tok.eos_token_id)
    return ts_tok.decode(out[0], skip_special_tokens=True)
TS_PROMPTS = ['Once upon a time', 'One day', 'There was a little', 'A small boy named', 'The girl wanted to', 'In the forest', 'Tom went to', 'She looked at', 'The dog ran', 'Once there was', 'A tiny cat', 'The children played', 'He found a', 'She was very', 'The old man', 'One morning', 'They went to', 'A little bird', 'The kind girl', 'Once a bunny'] * 4
print(f'\n  Generating {len(TS_PROMPTS)} TinyStories...')
ts_sentences = []
ts_token_seqs = []
for i, prompt in enumerate(TS_PROMPTS):
    text = generate_ts(prompt, max_new=100)
    sents = [s.strip() for s in re.split('(?<=[.!?])\\s+', text) if 4 < len(s.strip()) < 200]
    for sent in sents:
        toks = ts_tok.encode(sent, add_special_tokens=False)
        if 3 <= len(toks) <= 30:
            ts_sentences.append(sent)
            ts_token_seqs.append(toks)
    if (i + 1) % 20 == 0:
        print(f'  {i + 1}/{len(TS_PROMPTS)} stories... ({len(ts_sentences)} sentences)')
print(f'\n  Total sentences: {len(ts_sentences)}')
print(f'  Avg length: {np.mean([len(s) for s in ts_token_seqs]):.1f} tokens')
ts_discovery = AtomDiscovery(pmi_threshold=6.0, min_count=4)
ts_compressed = ts_discovery.discover(ts_token_seqs, tokenizer=ts_tok, max_atoms=30)
ts_ratio = ts_discovery.compression_ratio(ts_token_seqs, ts_compressed)
print(f'\n  ── TINYSTORIES ATOMS DISCOVERED ──')
print(f'  Original avg length:   {np.mean([len(s) for s in ts_token_seqs]):.1f} tokens')
print(f'  Compressed avg length: {np.mean([len(s) for s in ts_compressed]):.1f} units')
print(f'  Compression ratio:     {ts_ratio:.2f}x')
print(f'  Atoms found:           {len(ts_discovery.atoms)}')
print(f'\n  Top atoms (natural units of TinyStories):')
for a, b, pmi, count, name, atom_id in ts_discovery.atoms[:15]:
    print(f"    '{name}'  PMI={pmi:.2f}  count={count}")
print_sep('PHASE 2 — PYTHON CODE ATOM DISCOVERY')
print(f"\n  Same pipeline. No changes.\n  Different domain: Python code instead of stories.\n  \n  What will the atoms be?\n  We don't know. Data will tell us.\n  \n  Using: microsoft/phi-1 (1.3B, trained on Python)\n  Or fallback: generate Python patterns manually\n")
PY_MODEL_NAME = 'microsoft/phi-1_5'
print(f'  Trying to load Python code model...')
py_model = None
py_tok = None
try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    py_tok = AutoTokenizer.from_pretrained(PY_MODEL_NAME, trust_remote_code=True)
    py_model = AutoModelForCausalLM.from_pretrained(PY_MODEL_NAME, dtype=torch.float32, trust_remote_code=True)
    py_model = py_model.to(device)
    py_model.eval()
    print(f'  Loaded: {sum((p.numel() for p in py_model.parameters())):,} params')
    use_py_model = True
except Exception as e:
    print(f'  Could not load {PY_MODEL_NAME}: {e}')
    print(f'  Using GPT-2 tokenizer on hand-crafted Python corpus instead.')
    use_py_model = False
PYTHON_CORPUS = '\ndef add(a, b):\n    return a + b\n\ndef greet(name):\n    print("Hello", name)\n    return name\n\nfor i in range(10):\n    print(i)\n\nx = 0\nwhile x < 10:\n    x = x + 1\n\ndef factorial(n):\n    if n == 0:\n        return 1\n    return n * factorial(n - 1)\n\nclass Dog:\n    def __init__(self, name):\n        self.name = name\n    def bark(self):\n        print("Woof")\n\nnumbers = [1, 2, 3, 4, 5]\nfor num in numbers:\n    if num > 2:\n        print(num)\n\ndef find_max(lst):\n    max_val = lst[0]\n    for item in lst:\n        if item > max_val:\n            max_val = item\n    return max_val\n\nimport os\nimport sys\nfrom collections import Counter\n\ndef read_file(path):\n    with open(path) as f:\n        return f.read()\n\nresult = []\nfor i in range(100):\n    if i % 2 == 0:\n        result.append(i)\n\ndef is_prime(n):\n    if n < 2:\n        return False\n    for i in range(2, n):\n        if n % i == 0:\n            return False\n    return True\n\ntry:\n    x = int(input())\nexcept ValueError:\n    print("not a number")\n\ndata = {"name": "Alice", "age": 30}\nfor key, value in data.items():\n    print(key, value)\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n):\n        for j in range(n - i - 1):\n            if arr[j] > arr[j + 1]:\n                arr[j], arr[j + 1] = arr[j + 1], arr[j]\n    return arr\n\nlambda x: x * 2\nmap(lambda x: x**2, range(10))\nfilter(lambda x: x > 0, numbers)\n\nassert result is not None\nassert len(result) > 0\n\nprint(f"Result: {result}")\nreturn_value = None\n' * 8
if use_py_model:
    PY_PROMPTS = ['def ', 'for i in ', 'class ', 'import ', 'if ', 'return ', 'while ', 'x = ', 'def add(', 'for item in', 'result = []', 'def find_', 'print(', 'try:\n    '] * 6
    print(f'\n  Generating Python code from model...')
    py_lines = []
    for i, prompt in enumerate(PY_PROMPTS):
        try:
            inputs = py_tok(prompt, return_tensors='pt').to(device)
            with torch.no_grad():
                out = py_model.generate(**inputs, max_new_tokens=60, do_sample=True, temperature=0.7, pad_token_id=py_tok.eos_token_id)
            text = py_tok.decode(out[0], skip_special_tokens=True)
            py_lines.extend(text.split('\n'))
        except Exception as e:
            pass
        if (i + 1) % 20 == 0:
            print(f'  {i + 1}/{len(PY_PROMPTS)} prompts...')
    py_text = '\n'.join(py_lines)
else:
    py_text = PYTHON_CORPUS
from transformers import GPT2Tokenizer
gpt2_tok = GPT2Tokenizer.from_pretrained('gpt2')
py_lines_clean = [line for line in py_text.split('\n') if len(line.strip()) > 2 and len(line.strip()) < 150]
print(f'\n  Python lines: {len(py_lines_clean)}')
print(f'  Sample lines:')
for line in py_lines_clean[:5]:
    print(f'    {repr(line)}')
py_token_seqs = []
py_raw_lines = []
for line in py_lines_clean:
    toks = gpt2_tok.encode(line, add_special_tokens=False)
    if 2 <= len(toks) <= 25:
        py_token_seqs.append(toks)
        py_raw_lines.append(line)
print(f'\n  Tokenized lines: {len(py_token_seqs)}')
print(f'  Avg length: {np.mean([len(s) for s in py_token_seqs]):.1f} tokens')
print(f'\n  Discovering atoms in Python code...')
py_discovery = AtomDiscovery(pmi_threshold=5.0, min_count=3)
py_compressed = py_discovery.discover(py_token_seqs, tokenizer=gpt2_tok, max_atoms=30)
py_ratio = py_discovery.compression_ratio(py_token_seqs, py_compressed)
print(f'\n  ── PYTHON CODE ATOMS DISCOVERED ──')
print(f'  Original avg length:   {np.mean([len(s) for s in py_token_seqs]):.1f} tokens')
print(f'  Compressed avg length: {np.mean([len(s) for s in py_compressed]):.1f} units')
print(f'  Compression ratio:     {py_ratio:.2f}x')
print(f'  Atoms found:           {len(py_discovery.atoms)}')
print(f'\n  Top atoms (natural units of Python code):')
for a, b, pmi, count, name, atom_id in py_discovery.atoms[:20]:
    print(f"    '{name}'  PMI={pmi:.2f}  count={count}")
print_sep('COMPARISON — STORIES vs CODE')
ts_atom_names = [name for _, _, _, _, name, _ in ts_discovery.atoms[:10]]
py_atom_names = [name for _, _, _, _, name, _ in py_discovery.atoms[:10]]
print(f"\n  TINYSTORIES natural atoms:\n    {chr(10).join((f'    {n}' for n in ts_atom_names))}\n  \n  Compression ratio: {ts_ratio:.2f}x\n  \n  PYTHON CODE natural atoms:\n    {chr(10).join((f'    {n}' for n in py_atom_names))}\n  \n  Compression ratio: {py_ratio:.2f}x\n")
print(f'  ── WHAT THIS REVEALS ──\n')
print(f'  Both domains compressed by ~{(ts_ratio + py_ratio) / 2:.1f}x')
print(f'\n  Stories compress: narrative phrases → scene atoms\n  Code compresses:  syntax patterns   → operation atoms\n  \n  Both are the SAME operation:\n    Find what always appears together → compress to one unit\n    \n  Different surface. Same compression principle.\n  \n  This is the W Principle at the token level:\n    natural_feature(tokens) = PMI\n    constant(PMI) = atom\n    atom = compressed unit of meaning\n    \n  Stories: "once_upon" = opening signal\n  Code:    "def_(" = function declaration signal\n  \n  Mind stores signals. Not tokens. Not grammar.\n  Compressed signals.\n  Math = language = code at the compression level.\n  One mind. One engine. One principle.\n')
print_sep('VOCABULARY COMPARISON')
ts_orig_vocab = len(set((t for s in ts_token_seqs for t in s)))
py_orig_vocab = len(set((t for s in py_token_seqs for t in s)))
ts_comp_vocab = len(set((t for s in ts_compressed for t in s)))
py_comp_vocab = len(set((t for s in py_compressed for t in s)))
print(f"\n  TINYSTORIES:\n    Original vocabulary:   {ts_orig_vocab:>6} unique tokens\n    Compressed vocabulary: {ts_comp_vocab:>6} unique units\n    Reduction:             {ts_orig_vocab / ts_comp_vocab:.1f}x smaller vocabulary\n    \n  PYTHON CODE:\n    Original vocabulary:   {py_orig_vocab:>6} unique tokens\n    Compressed vocabulary: {py_comp_vocab:>6} unique units\n    Reduction:             {py_orig_vocab / py_comp_vocab:.1f}x smaller vocabulary\n\n  Neural network trains on original vocabulary.\n  Hybrid mind trains on compressed vocabulary.\n  \n  Smaller vocabulary + compression structure\n  = same information, less confusion, faster learning.\n  \n  This is why child learns grammar faster than LLM:\n  Child's subconscious compresses first.\n  Then learns on compressed units.\n  LLM tries to learn raw tokens directly.\n  Raw tokens = noise from compression perspective.\n")
