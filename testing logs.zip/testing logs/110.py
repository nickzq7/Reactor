import os, json, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D = meta['DA']
H = meta['HA']
NL = meta['NLA']
D_TINY = 8
STEPS_ROUND = 800
LR = 0.003
MAX_ROUNDS = 8

def arith(step, n=60):
    return [i * step % VS for i in range(n)]

def countdown(step, n=60):
    return [(VS - 1 - i * step) % VS for i in range(n)]

def fib(a, b, n=60):
    s = [a % VS, b % VS]
    while len(s) < n:
        s.append((s[-1] + s[-2]) % VS)
    return s

def geo(base, n=60):
    s = [1]
    for _ in range(n - 1):
        s.append(s[-1] * base % VS)
    return s

def poly(fn, n=60):
    return [fn(i) % VS for i in range(n)]

def skip(step, offset, n=60):
    return [(offset + i * step) % VS for i in range(n)]
MODEL_PATTERNS = [[('a1', arith(1)), ('a2', arith(2)), ('a3', arith(3)), ('a4', arith(4)), ('a5', arith(5)), ('a6', arith(6)), ('a7', arith(7)), ('a8', arith(8))], [('a9', arith(9)), ('a10', arith(10)), ('a11', arith(11)), ('a12', arith(12)), ('a13', arith(13)), ('a14', arith(14)), ('a15', arith(15)), ('a16', arith(16))], [('a17', arith(17)), ('a18', arith(18)), ('a19', arith(19)), ('a20', arith(20)), ('a21', arith(21)), ('a22', arith(22)), ('a23', arith(23)), ('a24', arith(24))], [('d1', countdown(1)), ('d2', countdown(2)), ('d3', countdown(3)), ('d4', countdown(4)), ('d5', countdown(5)), ('d6', countdown(6)), ('d7', countdown(7)), ('d8', countdown(8))], [('f1', fib(1, 2)), ('f2', fib(3, 7)), ('f3', fib(5, 11)), ('f4', fib(2, 9)), ('f5', fib(7, 13)), ('f6', fib(4, 15)), ('f7', fib(6, 17)), ('f8', fib(8, 19))], [('g2', geo(2)), ('g3', geo(3)), ('g4', geo(4)), ('g5', geo(5)), ('g6', geo(6)), ('g7', geo(7)), ('g9', geo(9)), ('g11', geo(11))], [('sq0', poly(lambda i: i * i)), ('sq1', poly(lambda i: (i + 1) * (i + 1))), ('sq2', poly(lambda i: (i + 2) * (i + 2))), ('sq3', poly(lambda i: (i + 3) * (i + 3))), ('sq4', poly(lambda i: (i + 4) * (i + 4))), ('sq5', poly(lambda i: (i + 5) * (i + 5))), ('sq6', poly(lambda i: (i + 6) * (i + 6))), ('sq7', poly(lambda i: (i + 7) * (i + 7)))], [('s3o0', skip(3, 0)), ('s3o1', skip(3, 1)), ('s3o2', skip(3, 2)), ('s3o3', skip(3, 3)), ('s5o0', skip(5, 0)), ('s5o1', skip(5, 1)), ('s5o2', skip(5, 2)), ('s5o3', skip(5, 3))]]
ALL_PATTERNS = [p for mp in MODEL_PATTERNS for p in mp]
GROUPS = ['arith1-8', 'arith9-16', 'arith17-24', 'countdown', 'fibonacci', 'geometric', 'polynomial', 'skip+offset']

class Transformer(nn.Module):

    def __init__(self, d):
        super().__init__()
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, H, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, x):
        B, T = x.shape
        h = self.wte(x) + self.wpe(torch.arange(T, device=x.device))
        mask = torch.triu(torch.full((T, T), float('-inf'), device=x.device), diagonal=1)
        for ly in self.layers:
            n = ly['ln1'](h)
            a, _ = ly['attn'](n, n, n, attn_mask=mask, need_weights=False)
            h = h + a
            h = h + ly['ff'](ly['ln2'](h))
        return self.ln_f(h) @ self.wte.weight.T

def build_data(patterns):
    X, Y = ([], [])
    for _, seq in patterns:
        for i in range(len(seq) - K):
            X.append(seq[i:i + K])
            Y.append(seq[i + 1:i + K + 1])
    return (torch.tensor(X, dtype=torch.long), torch.tensor(Y, dtype=torch.long))

def score_all(model):
    model.eval()
    per_group = []
    for patterns_i in MODEL_PATTERNS:
        sc = 0
        for name, seq in patterns_i:
            ctx = torch.tensor([seq[:K]], dtype=torch.long)
            truth = seq[K]
            with torch.no_grad():
                pred = int(model(ctx)[0, -1].argmax())
            sc += pred == truth
        per_group.append(sc)
    return per_group

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]
loss_fn = nn.CrossEntropyLoss()
print('=' * 60)
print('  PHASE 2 — EVOLUTIONARY MUTATION TRANSFER')
print(f'  8 donors → D={D_TINY} child  max {MAX_ROUNDS} rounds')
print('=' * 60)
donors = []
donor_wtes = []
for i in range(8):
    path = os.path.join(_dir, f'donor_{i:02d}.npz')
    data = np.load(path, allow_pickle=True)
    m = Transformer(D)
    m.load_state_dict({k: torch.tensor(data[k]) for k in data.files})
    m.eval()
    donors.append(m)
    donor_wtes.append(m.wte.weight.detach().numpy())
print(f'  Loaded {len(donors)} donors')

def mutate_embedding(target_donor_ids, current_wte=None, k_flip=6):
    selected = [donor_wtes[i] for i in target_donor_ids]
    ref = selected[0]
    proj = [w @ solve(w, ref) for w in selected]
    if len(proj) == 1:
        WTE = proj[0]
    else:
        N = len(proj)
        ags = []
        for i in range(N):
            for j in range(i + 1, N):
                ags.append(np.sum(proj[i] * proj[j], axis=0))
        ags = np.array(ags)
        mean_ag = ags.mean(0)
        tension = ags.std(0)
        combined = mean_ag + tension
        flip_dims = np.argsort(combined)[-k_flip:]
        WTE = np.mean(proj, axis=0).copy()
        WTE[:, flip_dims] *= -1
    if current_wte is not None:
        WTE = 0.5 * WTE + 0.5 * current_wte @ solve(current_wte, WTE)
    U, s, Vt = np.linalg.svd(WTE, full_matrices=False)
    return (U[:, :D_TINY] * s[:D_TINY]).astype(np.float32)
X_all, Y_all = build_data(ALL_PATTERNS)
print('\n  ROUND 0 — Initial mutation from all 8 donors')
wte_init = mutate_embedding(list(range(8)), current_wte=None, k_flip=6)
torch.manual_seed(42)
np.random.seed(42)
child = Transformer(D_TINY)
for nm, p in child.named_parameters():
    if p.dim() > 1:
        nn.init.xavier_uniform_(p)
    else:
        nn.init.zeros_(p)
with torch.no_grad():
    child.wte.weight.copy_(torch.tensor(wte_init))
history = []
best_ever = 0
best_ever_state = None
t0 = time.time()
for rnd in range(MAX_ROUNDS):
    print(f"\n{'=' * 60}")
    print(f'  ROUND {rnd + 1}  ({STEPS_ROUND} steps)')
    print(f"{'=' * 60}")
    opt = torch.optim.Adam(child.parameters(), lr=LR * 0.85 ** rnd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=STEPS_ROUND, eta_min=1e-05)
    best_round = 0
    best_round_state = None
    for step in range(1, STEPS_ROUND + 1):
        child.train()
        opt.zero_grad()
        loss_fn(child(X_all).view(-1, VS), Y_all.view(-1)).backward()
        nn.utils.clip_grad_norm_(child.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 200 == 0:
            per_group = score_all(child)
            total = sum(per_group)
            if total > best_round:
                best_round = total
                best_round_state = {k: v.clone() for k, v in child.state_dict().items()}
            print(f'  step {step:>4}: {total}/64  {per_group}', flush=True)
    if best_round_state:
        child.load_state_dict(best_round_state)
    per_group = score_all(child)
    total = sum(per_group)
    history.append((rnd + 1, total, per_group[:]))
    if total > best_ever:
        best_ever = total
        best_ever_state = {k: v.clone() for k, v in child.state_dict().items()}
    print(f'\n  Round {rnd + 1} best: {total}/64')
    for i, (sc, g) in enumerate(zip(per_group, GROUPS)):
        bar = '█' * sc + '░' * (8 - sc)
        print(f'    {bar}  {sc}/8  {g}')
    if total == 64:
        print('\n  PERFECT SCORE — stopping early')
        break
    if len(history) >= 3 and all((h[1] <= history[-3][1] for h in history[-2:])):
        print('\n  No improvement for 2 rounds — stopping')
        break
    weak_donors = [i for i, sc in enumerate(per_group) if sc < 5]
    if not weak_donors:
        weak_donors = [i for i, sc in enumerate(per_group) if sc == min(per_group)]
    print(f'\n  Weakest groups: {[GROUPS[i] for i in weak_donors]}')
    print(f'  Mutating from donors: {[i + 1 for i in weak_donors]}')
    current_wte = child.wte.weight.detach().numpy()
    new_wte = mutate_embedding(weak_donors, current_wte=current_wte, k_flip=4)
    with torch.no_grad():
        child.wte.weight.copy_(torch.tensor(new_wte))
if best_ever_state:
    child.load_state_dict(best_ever_state)
per_group = score_all(child)
grand_total = sum(per_group)
print('\n' + '=' * 60)
print('  EVOLUTION HISTORY')
print('=' * 60)
for rnd, total, pg in history:
    bar = '█' * total + '░' * (64 - total)
    print(f'  Round {rnd}: {total:>2}/64  {bar[:40]}')
print('\n' + '=' * 60)
print('  FINAL RESULTS')
print('=' * 60)
for i, (sc, g) in enumerate(zip(per_group, GROUPS)):
    bar = '█' * sc + '░' * (8 - sc)
    print(f'  Donor {i + 1}  {bar}  {sc}/8  ({g})')
donor_params = sum((p.numel() for p in donors[0].parameters()))
tiny_params = sum((p.numel() for p in child.parameters()))
print(f'\n  Donor size:  {donor_params} x 8 = {donor_params * 8} total\n  Child size:  {tiny_params}\n  Compression: {donor_params * 8 // tiny_params}x smaller\n\n  Intelligence transferred: {grand_total}/64  ({grand_total / 64 * 100:.0f}%)\n  Rounds used: {len(history)}\n  Time: {time.time() - t0:.1f}s\n')
print('=' * 60)
