import numpy as np, math, time
from collections import Counter
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL v21 — RESIDUAL STREAM + QUADRATIC KERNEL')
print('  Target = WTE[next] (D-dim regression, not one-hot).')
print('  Each layer: W* = pinv(φ(x)) @ Residuals.')
print('  x_new = x + φ(x)@W. logits = x_final @ WTE.T')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
D = 16
L = 3
D_quad = D * (D + 1) // 2
print(f'\n  Vocab={VS} Tokens={N} D={D} L={L}')
print(f'  D_quad={D_quad}  N/D_quad={N // D_quad}x (regression target=D not VS)')
np.random.seed(42)
co = np.zeros((VS, VS))
for i in range(len(toks) - 1):
    co[toks[i], toks[i + 1]] += 1
U_e, S_e, _ = np.linalg.svd(co + 0.1)
WTE_raw = U_e[:, :D] * np.sqrt(S_e[:D])
WTE = (WTE_raw - WTE_raw.mean(0)) / (WTE_raw.std(0) + 1e-05)
print(f'  WTE: {WTE.shape}  (SVD co-occurrence, semantic)')
print(f"  WTE['t']@WTE['h'] = {WTE[c2i['t']] @ WTE[c2i['h']]:.3f}  (should be high)")
print(f"  WTE['t']@WTE['z'] = {WTE[c2i['t']] @ WTE[c2i['z']]:.3f}  (should be lower)")
tri_i, tri_j = np.triu_indices(D)

def phi(x):
    return x[tri_i] * x[tri_j]

def phi_batch(X):
    return X[:, tri_i] * X[:, tri_j]

def pinv_solve(Phi, R):
    U, S, Vt = np.linalg.svd(Phi, full_matrices=False)
    thresh = S[0] * 1e-10
    mask = S > thresh
    S_inv = np.where(mask, 1.0 / np.where(mask, S, 1.0), 0.0)
    return Vt.T @ np.diag(S_inv) @ U.T @ R
W_layers = [np.zeros((D_quad, D)) for _ in range(L)]

def forward_all(W_layers):
    x = WTE[toks].copy()
    xs = [x.copy()]
    for l in range(L):
        Phi = phi_batch(x)
        delta = Phi @ W_layers[l]
        x = x + delta
        xs.append(x.copy())
    return xs

def calc_ppl(x_final):
    nll = 0.0
    ne = 0
    for i in range(N - 1):
        lg = x_final[i] @ WTE.T
        lg -= lg.max()
        lp = lg - np.log(np.sum(np.exp(lg)))
        nll += -lp[toks[i + 1]]
        ne += 1
    return math.exp(min(nll / ne, 500))
print(f'\n  Coordinate descent (solve each layer, multi-round):')
print(f"  {'Round':>6} {'Layer':>6} {'ppl':>10} {'res_before':>12} {'res_after':>11}")
print(f"  {'─' * 50}")
best_ppl = calc_ppl(WTE[toks])
print(f"  {'init':>6} {'—':>6} {best_ppl:>10.2f}  (all W=0, x=WTE[tok])")
best_W = [w.copy() for w in W_layers]
for rnd in range(5):
    improved = False
    for l in range(L):
        xs = forward_all(W_layers)
        x_l = xs[l]
        x_final = xs[-1]
        target_next = WTE[toks[1:]]
        x_in = x_l[:-1]
        R = target_next - x_in
        res_before = np.mean(np.linalg.norm(R, axis=1))
        Phi = phi_batch(x_in)
        W_new = pinv_solve(Phi, R)
        W_try = [w.copy() for w in W_layers]
        W_try[l] = W_new
        xs_new = forward_all(W_try)
        ppl_new = calc_ppl(xs_new[-1])
        delta_new = Phi @ W_new
        res_after = np.mean(np.linalg.norm(R - delta_new, axis=1))
        marker = '★' if ppl_new < best_ppl else ' '
        print(f'  {rnd + 1:>6} {l:>6} {ppl_new:>10.2f}  {res_before:>10.4f}  {res_after:>10.4f}  {marker}')
        if ppl_new < best_ppl:
            best_ppl = ppl_new
            W_layers = W_try
            best_W = [w.copy() for w in W_try]
            improved = True
    if not improved:
        print(f'  Round {rnd + 1}: no improvement. Converged.')
        break
W_layers = best_W
xs_final = forward_all(W_layers)
x_out = xs_final[-1]
print(f'\n  Final ppl={best_ppl:.2f}  vocab={VS}  ratio={best_ppl / VS:.3f}')
print(f'\n  RESIDUAL ANALYSIS (what each layer learned):')
xs = forward_all(W_layers)
for l in range(L):
    x_in = xs[l][:-1]
    x_out_l = xs[l + 1][:-1]
    target = WTE[toks[1:]]
    r_before = np.mean(np.linalg.norm(target - x_in, axis=1))
    r_after = np.mean(np.linalg.norm(target - x_out_l, axis=1))
    print(f'  Layer {l}: residual {r_before:.4f} → {r_after:.4f}  (reduced: {r_before - r_after:.4f})')
print(f'\n  BIGRAM CHECK (single char context):')
for prev in ['t', 'h', 'e', ' ', 'a', 'n']:
    if prev not in c2i:
        continue
    x = WTE[c2i[prev]].copy()
    for l in range(L):
        x = x + phi(x) @ W_layers[l]
    lg = x @ WTE.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{prev}': {top3}")
print(f'\n  TRIGRAM CHECK (2-char context, last token only):')
for bg in ['th', 'he', 'in', 'an']:
    cs = [c2i[c] for c in bg if c in c2i]
    if len(cs) < 2:
        continue
    x = WTE[cs[-1]].copy()
    for l in range(L):
        x = x + phi(x) @ W_layers[l]
    lg = x @ WTE.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2c[i], f'{100 * p[i]:.0f}%') for i in np.argsort(-p)[:3]]
    print(f"  after '{bg}': {top3}")

def forward_one(tok_id):
    x = WTE[tok_id].copy()
    for l in range(L):
        x = x + phi(x) @ W_layers[l]
    return x @ WTE.T

def sample(lg, temp=0.8, top_k=8):
    lg = lg - lg.max()
    lg = lg / temp
    if top_k < len(lg):
        thresh = np.sort(lg)[-top_k]
        lg[lg < thresh] = -10000000000.0
    p = np.exp(lg)
    p /= p.sum()
    return int(np.random.choice(VS, p=p))

def generate(prompt, n=150, temp=0.8, seed=42):
    np.random.seed(seed)
    ids = [c2i[c] for c in prompt if c in c2i]
    for _ in range(n):
        lg = forward_one(ids[-1])
        if not np.all(np.isfinite(lg)):
            break
        ids.append(sample(lg, temp))
    return ''.join((i2c.get(t, '?') for t in ids))
print(f'\n  GENERATION (temp=0.8):')
for p in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    out = generate(p)
    print(f"  '{p}'")
    print(f'    {out[len(p):][:70]}')
gs = generate('the ', n=300, temp=0.85)
sp = 100 * gs[4:].count(' ') / len(gs[4:])
print(f'\n  Space%={sp:.0f}%')
print(f'  Sample: {gs[4:80]}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  ppl={best_ppl:.2f}  ratio={best_ppl / VS:.3f}  vocab={VS}')
print(f'\n  PIPELINE (W Principle, from scratch):')
print(f'    WTE: ({VS},{D}) SVD co-occurrence embeddings')
print(f'    x_0 = WTE[tok]  ← token in semantic space')
print(f'    x_{{l+1}} = x_l + φ(x_l)@W_l  ← residual stream')
print(f'    W_l* = pinv(φ(x_l)) @ (WTE[next]-x_l)  ← W-Kernel solve')
print(f'    logits = x_final @ WTE.T  ← weight tying')
print(f'  Target = WTE[next] in R^{D}. Not one-hot. Not n-gram.')
print('=' * 65 + '\n')
