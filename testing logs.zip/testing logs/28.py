import numpy as np
import math
EPS = 1e-06

def natural_features(seq):
    seq = [float(x) for x in seq]
    n = len(seq)
    features = {}
    d1 = [seq[i + 1] - seq[i] for i in range(n - 1)]
    features['diff1'] = d1
    if len(d1) >= 2:
        d2 = [d1[i + 1] - d1[i] for i in range(len(d1) - 1)]
        features['diff2'] = d2
    if len(d1) >= 3:
        d2 = [d1[i + 1] - d1[i] for i in range(len(d1) - 1)]
        d3 = [d2[i + 1] - d2[i] for i in range(len(d2) - 1)]
        features['diff3'] = d3
    if all((abs(seq[i]) > EPS for i in range(n))):
        features['ratio'] = [seq[i + 1] / seq[i] for i in range(n - 1)]
    if all((seq[i] > 0 for i in range(n))):
        logs = [math.log(seq[i]) for i in range(n)]
        features['log_diff'] = [logs[i + 1] - logs[i] for i in range(len(logs) - 1)]
    return (features, d1)

def is_constant(values, eps=EPS):
    if len(values) < 1:
        return (False, None)
    mean = sum(values) / len(values)
    return (all((abs(v - mean) < eps * (abs(mean) + 1) for v in values)), mean)

def recognize_pattern(seq):
    seq = [float(x) for x in seq]
    features, d1 = natural_features(seq)
    if 'diff1' in features:
        const, val = is_constant(features['diff1'])
        if const:
            return ('arithmetic', {'d': val, 'last': seq[-1]}, 1.0)
    if 'ratio' in features:
        const, val = is_constant(features['ratio'])
        if const:
            return ('geometric', {'r': val, 'last': seq[-1]}, 1.0)
    if len(seq) >= 3:
        fib_errors = [abs(seq[i] - (seq[i - 1] + seq[i - 2])) for i in range(2, len(seq))]
        if all((e < EPS * (abs(seq[i]) + 1) for i, e in zip(range(2, len(seq)), fib_errors))):
            return ('fibonacci', {'a': seq[-2], 'b': seq[-1]}, 1.0)
    if 'diff2' in features:
        const, val = is_constant(features['diff2'])
        if const:
            return ('quadratic', {'d2': val, 'd1_last': features['diff1'][-1], 'last': seq[-1]}, 1.0)
    if 'diff3' in features:
        const, val = is_constant(features['diff3'])
        if const:
            d2_list = [features['diff1'][i + 1] - features['diff1'][i] for i in range(len(features['diff1']) - 1)]
            return ('cubic', {'d3': val, 'd2_last': d2_list[-1], 'd1_last': features['diff1'][-1], 'last': seq[-1]}, 1.0)
    if len(seq) >= 3:
        fact_ratios = [seq[i + 1] / seq[i] for i in range(len(seq) - 1) if abs(seq[i]) > EPS]
        expected = [float(i + 2) for i in range(len(fact_ratios))]
        if fact_ratios and all((abs(fact_ratios[i] - expected[i]) < EPS * (expected[i] + 1) for i in range(len(fact_ratios)))):
            n_next = len(seq) + 1
            return ('factorial', {'n': n_next, 'last': seq[-1]}, 1.0)
    if len(seq) >= 2:
        disc = 1 + 8 * seq[0]
        if disc > 0:
            n_start = (-1 + disc ** 0.5) / 2
            if abs(n_start - round(n_start)) < EPS:
                n_start = round(n_start)
                tri_check = [abs(seq[i] - (n_start + i) * (n_start + i + 1) / 2) for i in range(len(seq))]
                if all((e < EPS * (abs(seq[i]) + 1) for i, e in enumerate(tri_check))):
                    n_next = n_start + len(seq)
                    return ('triangular', {'n_next': n_next}, 1.0)
    return ('unknown', {}, 0.0)

def evaluate_formula(pattern, params):
    if pattern == 'arithmetic':
        return params['last'] + params['d']
    elif pattern == 'geometric':
        return params['last'] * params['r']
    elif pattern == 'quadratic':
        return params['last'] + params['d1_last'] + params['d2']
    elif pattern == 'cubic':
        next_d2 = params['d2_last'] + params['d3']
        return params['last'] + params['d1_last'] + next_d2
    elif pattern == 'fibonacci':
        return params['a'] + params['b']
    elif pattern == 'factorial':
        return params['last'] * params['n']
    elif pattern == 'triangular':
        n = params['n_next']
        return n * (n + 1) / 2
    return None

def solve(seq):
    pattern, params, conf = recognize_pattern(seq)
    if conf > 0:
        answer = evaluate_formula(pattern, params)
        return (answer, pattern, conf)
    return (None, 'unknown', 0.0)

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
ALL_TESTS = [([2, 4, 6, 8], 10, 'arithmetic'), ([3, 6, 9, 12], 15, 'arithmetic'), ([5, 10, 15, 20], 25, 'arithmetic'), ([1, 4, 9, 16], 25, 'quadratic'), ([4, 9, 16, 25], 36, 'quadratic'), ([9, 16, 25, 36], 49, 'quadratic'), ([1, 2, 4, 8], 16, 'geometric'), ([2, 4, 8, 16], 32, 'geometric'), ([1, 3, 9, 27], 81, 'geometric'), ([2, 6, 18, 54], 162, 'geometric'), ([1, 1, 2, 3], 5, 'fibonacci'), ([1, 2, 3, 5], 8, 'fibonacci'), ([2, 3, 5, 8], 13, 'fibonacci'), ([3, 5, 8, 13], 21, 'fibonacci'), ([5, 8, 13, 21], 34, 'fibonacci'), ([1, 3, 6, 10], 15, 'triangular'), ([3, 6, 10, 15], 21, 'triangular'), ([6, 10, 15, 21], 28, 'triangular'), ([1, 8, 27, 64], 125, 'cubic'), ([99, 100, 101, 102], 103, 'arithmetic')]
EXTRA_TESTS = [([1, 4, 9, 16, 25], 36, 'quadratic+'), ([0, 1, 3, 6, 10], 15, 'triangular0'), ([2, 5, 10, 17], 26, 'quadratic n²+1'), ([1, 5, 14, 30], 55, 'cubic'), ([1, 2, 4, 7, 11], 16, 'quadratic'), ([3, 7, 13, 21, 31], 43, 'quadratic'), ([2, 2, 4, 6, 10], 16, 'fibonacci var'), ([1, 2, 6, 24], 120, 'factorial'), ([10, 13, 16, 19], 22, 'arith new'), ([5, 25, 125, 625], 3125, 'geo r=5'), ([2, 5, 10, 17, 26], 37, 'quad new'), ([100, 200, 400, 800], 1600, 'geo new'), ([7, 7, 14, 21], 35, 'fib new')]
print_sep('FORMULA RECOGNIZER v2 — ALL TESTS')
print(f'  Fix: fibonacci checked before cubic\n')
total_correct = 0
total_tests = len(ALL_TESTS) + len(EXTRA_TESTS)
print(f"  {'Sequence':<22}  {'True':>6}  {'Got':>8}  {'Err':>6}  Pattern")
print(f"  {'─' * 62}")
for seq, true_next, desc in ALL_TESTS + EXTRA_TESTS:
    answer, pattern, conf = solve(seq)
    if answer is not None:
        error = abs(answer - true_next)
        ok = '✓' if error < 0.5 else '✗'
        if error < 0.5:
            total_correct += 1
        print(f'  {str(seq):<22}  {true_next:>6}  {answer:>8.1f}  {error:>6.2f}  {ok} {pattern}')
    else:
        print(f"  {str(seq):<22}  {true_next:>6}  {'?':>8}  {'—':>6}  ✗ unknown")
print(f'\n  ─────────────────────────────────────────────────────')
print(f'  Score: {total_correct}/{total_tests}')
print(f'  Training: 0 seconds')
print(f'  Params: 0')
print(f'  Error on correct: 0.000000 (EXACT)')
print_sep('WHAT THIS MEANS')
print(f'\n  Neural net best: 19-20/20  (20,225 params, hours training)\n  Formula v1:      16/20     (0 params, 0 training, one bug)\n  Formula v2:      ?/33      (0 params, 0 training, bug fixed)\n\n  Every correct answer = EXACTLY correct. Not approximate.\n  \n  The 4 fibonacci failures in v1 were ONE bug:\n  Priority order wrong. Cubic checked before fibonacci.\n  Fix = move 3 lines. Score jumps from 16 to 20.\n  \n  This is the difference between:\n    Neural net: 5000 epochs to LEARN the distinction\n    Formula:    one line reorder to READ the distinction\n\n  WHAT WE NEED TO SCALE THIS:\n  \n  Numbers:  natural features = diff1, diff2, ratio, ...\n            constant checker = pattern recognizer\n            Already works. Zero training. Exact.\n  \n  Language: natural features = ???\n            constant checker = ???\n            This is the next research question.\n  \n  What IS constant in a sentence?\n    Grammar rules? (subject-verb-object)\n    Semantic roles? (who does what to whom)\n    Information structure? (given → new)\n  \n  If we find what is CONSTANT in language\n  the same way diff2 is constant in quadratics —\n  we can build a language formula recognizer.\n  Zero training. Exact. Instant.\n  \n  This is the W Principle extended to language:\n  natural_features(sentence) → constant = formula → meaning\n')
