import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL FROM SCRATCH v4 — SEQUENTIAL FREEZING')
print('  One layer at a time. Coordinate descent.')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\nand flowers and all the small creatures that lived among the leaves\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthem with lights and warm bread and kind words the knight stayed\nthe night and left in the morning before anyone else was awake\nleaving only his footprints in the soft mud as a sign that he had\nbeen there and done what he came to do the old miller named otto\nhad run his windmill for forty years every morning he climbed the\nwooden stairs to check the stones and oil the gears and watch the\nsails turn in the wind the flour from his mill was the finest in\nthe region and bakers came from many villages to buy it one summer\nthe wind died and for three weeks the sails stood still otto swept\nthe floors and mended the fences and waited on the twenty second\nday a small cool wind brushed his cheek and by noon the mill was\nrunning at full speed otto laughed out loud which was something he\nalmost never did and he ground twice as much flour that week to\nmake up for the time that had been lost the little rabbit who\nlived at the edge of the meadow had three sisters and one brother\nevery evening they sat together at the entrance to their burrow\nand watched the sun go down over the hills the youngest rabbit\nalways asked the same question why does the sun go down and the\noldest rabbit always gave the same answer so that the stars can\ncome out and find their way home this made the youngest rabbit\nvery happy and she went to sleep thinking about all the stars\nmaking their long journey across the dark sky every single night\n'.strip()
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VS = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Vocab={VS}  Tokens={len(tokens)}')
D = 48
FFN_D = 96
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 2
SEQ_LEN = 20
LAM = 0.01
CLIP = 2.0
print(f'  D={D}  FFN_D={FFN_D}  Layers={N_LAYERS}  SEQ_LEN={SEQ_LEN}')
rng = np.random.RandomState(0)
WTE = rng.randn(VS, D).astype(np.float64) * 0.5
for i in range(VS):
    n = np.linalg.norm(WTE[i])
    if n > 1e-08:
        WTE[i] /= n
WPE = rng.randn(SEQ_LEN + 2, D).astype(np.float64) * 0.05

def lnorm(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def ridge(X, Y, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    W = np.linalg.solve(A, Xb.T @ Y)
    return np.clip(W, -CLIP, CLIP)

def init():
    w = {}
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1g{s}'] = np.ones(D)
        w[f'ln1b{s}'] = np.zeros(D)
        w[f'ln2g{s}'] = np.ones(D)
        w[f'ln2b{s}'] = np.zeros(D)
        w[f'Wq{s}'] = rng.randn(D, D) * 0.01
        w[f'Wk{s}'] = rng.randn(D, D) * 0.01
        w[f'Wv{s}'] = rng.randn(D, D) * 0.01
        w[f'Wo{s}'] = np.zeros((D, D))
        w[f'bo{s}'] = np.zeros(D)
        w[f'W1{s}'] = rng.randn(FFN_D, D) * 0.01
        w[f'b1{s}'] = np.zeros(FFN_D)
        w[f'W2{s}'] = np.zeros((D, FFN_D))
        w[f'b2{s}'] = np.zeros(D)
    w['lfg'] = np.ones(D)
    w['lfb'] = np.zeros(D)
    return w

def layer_fwd(x, li, w):
    T = len(x)
    s = str(li)
    h = np.array([lnorm(x[i], w[f'ln1g{s}'], w[f'ln1b{s}']) for i in range(T)])
    Q = h @ w[f'Wq{s}'].T
    K = h @ w[f'Wk{s}'].T
    V = h @ w[f'Wv{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    p = softmax(Qh @ Kh.transpose(0, 2, 1) + mask)
    ctx = np.stack([p[h_] @ Vh[h_] for h_ in range(N_HEADS)], 1).reshape(T, D)
    xa = x + ctx @ w[f'Wo{s}'].T + w[f'bo{s}']
    xn = xa.copy()
    for t in range(T):
        h2 = lnorm(xa[t], w[f'ln2g{s}'], w[f'ln2b{s}'])
        xn[t] = xa[t] + gelu(h2 @ w[f'W1{s}'].T + w[f'b1{s}']) @ w[f'W2{s}'].T + w[f'b2{s}']
    return (xn, ctx, xa)

def full_fwd(ids, w):
    T = len(ids)
    x = (WTE[ids] + WPE[:T]).copy()
    for li in range(N_LAYERS):
        x, _, _ = layer_fwd(x, li, w)
    xf = np.array([lnorm(x[t], w['lfg'], w['lfb']) for t in range(T)])
    return xf @ WTE.T

def ppl(w, n=400):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        try:
            logits = full_fwd(ids, w)
            if not np.all(np.isfinite(logits[-1])):
                continue
            lg = logits[-1] - logits[-1].max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return 999.0
    v = nll / tok
    return math.exp(min(v, 500))

def solve_layer(li, w, idxs, momentum=0.3):
    s = str(li)
    X_ctx = []
    X_xa = []
    X_ln2 = []
    X_gelu = []
    Y = []
    for idx in idxs:
        ids = tokens[idx:idx + SEQ_LEN]
        nxt = tokens[idx + SEQ_LEN]
        x = (WTE[ids] + WPE[:SEQ_LEN]).copy()
        for ll in range(li):
            x, _, _ = layer_fwd(x, ll, w)
        _, ctx, xa = layer_fwd(x, li, w)
        ctx_l = ctx[-1]
        xa_l = xa[-1]
        if not np.all(np.isfinite(ctx_l)):
            continue
        if not np.all(np.isfinite(xa_l)):
            continue
        h2 = lnorm(xa_l, w[f'ln2g{s}'], w[f'ln2b{s}'])
        pre = h2 @ w[f'W1{s}'].T + w[f'b1{s}']
        gl = gelu(pre)
        if not np.all(np.isfinite(gl)):
            continue
        X_ctx.append(ctx_l)
        X_xa.append(xa_l)
        X_ln2.append(h2)
        X_gelu.append(gl)
        Y.append(WTE[nxt])
    if len(Y) < 20:
        return w
    Xc = np.array(X_ctx)
    Xa = np.array(X_xa)
    Xl = np.array(X_ln2)
    Xg = np.array(X_gelu)
    Yt = np.array(Y)
    x_in = Xa - (Xc @ w[f'Wo{s}'].T + w[f'bo{s}'])
    Wo_new = ridge(Xc, Yt - x_in)
    w[f'Wo{s}'] = (1 - momentum) * Wo_new[:-1].T + momentum * w[f'Wo{s}']
    w[f'bo{s}'] = (1 - momentum) * Wo_new[-1] + momentum * w[f'bo{s}']
    w[f'Wo{s}'] = np.clip(w[f'Wo{s}'], -CLIP, CLIP)
    w[f'bo{s}'] = np.clip(w[f'bo{s}'], -CLIP, CLIP)
    W2_new = ridge(Xg, Yt - Xa)
    w[f'W2{s}'] = (1 - momentum) * W2_new[:-1].T + momentum * w[f'W2{s}']
    w[f'b2{s}'] = (1 - momentum) * W2_new[-1] + momentum * w[f'b2{s}']
    w[f'W2{s}'] = np.clip(w[f'W2{s}'], -CLIP, CLIP)
    w[f'b2{s}'] = np.clip(w[f'b2{s}'], -CLIP, CLIP)
    Y_pre = (Yt - Xa) @ w[f'W2{s}']
    W1_new = ridge(Xl, Y_pre)
    w[f'W1{s}'] = (1 - momentum) * W1_new[:-1].T + momentum * w[f'W1{s}']
    w[f'b1{s}'] = (1 - momentum) * W1_new[-1] + momentum * w[f'b1{s}']
    w[f'W1{s}'] = np.clip(w[f'W1{s}'], -CLIP, CLIP)
    w[f'b1{s}'] = np.clip(w[f'b1{s}'], -CLIP, CLIP)
    return w
w = init()
p0 = ppl(w)
print(f'\n  Random ppl = {p0:.2f}  (vocab={VS})')
BATCH = 400
phases = [(0, 12, 'Phase 1: Layer 0 only'), (1, 12, 'Phase 2: Layer 1 only (Layer 0 frozen)'), (0, 8, 'Phase 3: Layer 0 fine-tune'), (1, 8, 'Phase 4: Layer 1 fine-tune'), (0, 6, 'Phase 5: Layer 0 polish'), (1, 6, 'Phase 6: Layer 1 polish')]
best_ppl_ever = p0
best_w = {k: v.copy() for k, v in w.items()}
all_ppls = [p0]
t0 = time.time()
for active_li, n_rounds, label in phases:
    print(f'\n  ── {label} ──')
    print(f"  {'Rnd':<5} {'PPL':>8} {'Best':>8}")
    phase_best = best_ppl_ever
    for rnd in range(n_rounds):
        idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
        w = solve_layer(active_li, w, idxs, momentum=0.4)
        p = ppl(w)
        all_ppls.append(p)
        mark = ''
        if p < best_ppl_ever:
            best_ppl_ever = p
            best_w = {k: v.copy() for k, v in w.items()}
            mark = ' ★'
        arr = '↓' if p < all_ppls[-2] else '↑'
        print(f'  {rnd + 1:<5} {p:>8.2f} {best_ppl_ever:>8.2f}  {arr}{mark}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  FINAL RESULTS')
print(f"{'=' * 70}\n")
ppl_final = ppl(w, n=600)
print(f'  Start  : {p0:.2f}')
print(f'  Best   : {best_ppl_ever:.2f}')
print(f'  Vocab  : {VS}')
print(f'  Ratio  : {best_ppl_ever / VS:.4f}')
print(f'  Reduction: {(1 - best_ppl_ever / p0) * 100:.1f}%\n')
print(f'  GENERATION:\n')
for gp in ['once upon a time ', 'the brave knight ', 'deep in the forest ']:
    ids_g = [vocab[c] for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(150):
        lg = full_fwd(gen[-SEQ_LEN:], w)
        if not np.all(np.isfinite(lg[-1])):
            break
        gen.append(int(np.argmax(lg[-1])))
    out = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  '{gp}'")
    print(f'  → {out[len(gp):][:80]}\n')
print(f'  TOP-5 predicted chars vs actual:')
freq = np.zeros(VS)
for t in tokens:
    freq[t] += 1
freq /= freq.sum()
top_actual = np.argsort(-freq)[:5]
gen_test = [vocab[c] for c in 'once upon a time ' if c in vocab]
for _ in range(200):
    lg = full_fwd(gen_test[-SEQ_LEN:], w)
    if not np.all(np.isfinite(lg[-1])):
        break
    gen_test.append(int(np.argmax(lg[-1])))
pred_freq = np.zeros(VS)
for t in gen_test[17:]:
    pred_freq[t] += 1
if pred_freq.sum() > 0:
    pred_freq /= pred_freq.sum()
top_pred = np.argsort(-pred_freq)[:5]
print(f'  Actual top: {[repr(ivocab[i]) for i in top_actual]}')
print(f'  Pred   top: {[repr(ivocab[i]) for i in top_pred]}')
print(f'\n  PPL trajectory:')
step = max(1, len(all_ppls) // 15)
traj = ' → '.join((f'{p:.1f}' for p in all_ppls[::step]))
print(f'  {traj}')
print(f'\n  Total time: {time.time() - t0:.0f}s')
print(f"\n{'=' * 70}")
if best_ppl_ever < VS:
    print(f'  ✓ BELOW VOCAB — learned from text. No gradient descent.')
    print(f'  ✓ W-Kernel coordinate descent = valid training method.')
elif best_ppl_ever < p0 * 0.7:
    print(f'  ~ SIGNIFICANT improvement. Sequence learning beginning.')
    print(f'  More layers or rounds will push below vocab ceiling.')
else:
    print(f'  ~ Partial. Foundation correct. Need more data or rounds.')
print('=' * 70 + '\n')
