import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
FFN_D = D * 4
n_heads = model.config.num_heads
print(f'D={D}  Layers={n_layers}  FFN_D={FFN_D}  heads={n_heads}')
texts = ['Once upon a time there was a little girl', 'The farmer woke up early and fed his', 'Deep in the forest a family of bears', 'The brave knight rode his white horse', 'Sophie loved books more than anything', 'The village held a harvest festival every', 'Tommy was afraid of the dark and could', 'Marco sailed across the vast blue ocean', 'The mountains were cold and the children', 'She smiled because today was her birthday', 'Two friends shared every secret since', 'A rabbit lived under the roots of the', 'The grandmother welcomed every lost traveler', 'Sam found a puppy hiding under the bridge', 'The dragon had never spoken before the girl', 'In the ocean a fish dreamed of the world', 'The clock had been silent for twenty years', 'A small seed grew slowly into a mighty tree', 'The painter stared at the blank canvas', 'Every evening the grandfather told his', 'The wind carried the sound of bells from', 'A boy named Jack found a magical stone', 'The old library held secrets no one had', 'She opened the door and saw the garden', 'He could not remember where he had left', 'The stars above the quiet village shone', 'Lily packed her small bag and walked toward', 'The teacher wrote one word on the board', 'When the rain stopped the children ran', 'The captain looked at the map and chose']
W2_col_norms = []
for li in range(n_layers):
    W2 = model.transformer.h[li].mlp.c_proj.weight.detach().float().numpy()
    col_norms = np.linalg.norm(W2, axis=0)
    W2_col_norms.append(col_norms)
print(f'\nCollecting gelu activations + attention weights...')
gelu_store = {li: [] for li in range(n_layers)}
attn_w_store = {li: [] for li in range(n_layers)}
cur = {}
hooks = []
for li in range(n_layers):

    def make_gelu(l):

        def h(m, i, o):
            cur[f'g_{l}'] = o.detach().float().numpy().copy()
        return h
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_gelu(li)))
with torch.no_grad():
    for text in texts:
        cur.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=20, truncation=True)
        L = toks['input_ids'].shape[1]
        out = model(**toks, output_attentions=True)
        for li in range(n_layers):
            if f'g_{li}' in cur:
                g = cur[f'g_{li}'][0]
                for t in range(L):
                    gelu_store[li].append(g[t].copy())
            if out.attentions is not None:
                aw = out.attentions[li][0].detach().float().numpy()
                for t in range(L):
                    attn_w_store[li].append(aw[:, t, :t + 1].flatten().copy())
for h in hooks:
    h.remove()
print(f'  Tokens collected: {len(gelu_store[0])}')
print(f"\n{'=' * 70}")
print(f'  TEST A — gelu_out ACTIVATION MAGNITUDE')
print(f'  Natural space: gelu_out is the selector.')
print(f'  |gelu_out[i]| small → W2[:,i] = silent for this input.')
print(f"{'=' * 70}\n")
epsilons = [0.001, 0.005, 0.01, 0.02, 0.05, 0.1]
print(f'  Fraction of gelu neurons with |gelu_out| < epsilon:')
print(f"  {'Layer':<8} " + '  '.join([f'ε={e}' for e in epsilons]))
print(f"  {'─' * 70}")
for li in range(n_layers):
    G = np.array(gelu_store[li], dtype=np.float64)
    fracs = []
    for eps in epsilons:
        frac = float((np.abs(G) < eps).mean())
        fracs.append(frac)
    print(f'  {li:<8} ' + '  '.join([f'{f * 100:6.1f}%' for f in fracs]))
print(f"\n{'=' * 70}")
print(f'  TEST B — ACTUAL CONTRIBUTION: |gelu[i]| × ||W2[:,i]||')
print(f"  This = the true magnitude of each FFN neuron's output.")
print(f'  Below float16 noise floor (≈1e-3): effectively zero.')
print(f'  These neurons = silent. Their W2 columns = not needed.')
print(f"{'=' * 70}\n")
float16_noise = 0.001
thresholds = [0.0001, 0.001, 0.005, 0.01]
print(f'  Fraction of FFN neurons with contribution < threshold:')
print(f"  {'Layer':<8} " + '  '.join([f't={t:.0e}' for t in thresholds]))
print(f"  {'─' * 60}")
total_silent_contrib = {t: [] for t in thresholds}
for li in range(n_layers):
    G = np.array(gelu_store[li], dtype=np.float64)
    col_norms = W2_col_norms[li]
    contrib = np.abs(G) * col_norms[None, :]
    fracs = []
    for t in thresholds:
        frac = float((contrib < t).mean())
        fracs.append(frac)
        total_silent_contrib[t].append(frac)
    print(f'  {li:<8} ' + '  '.join([f'{f * 100:6.1f}%' for f in fracs]))
print(f'\n  Mean across all layers:')
for t in thresholds:
    mean_frac = np.mean(total_silent_contrib[t])
    print(f'    t={t:.0e}: {mean_frac * 100:.1f}% silent  →  {(1 - mean_frac) * 100:.1f}% active')
print(f"\n{'=' * 70}")
print(f'  TEST C — ATTENTION SILENCE')
print(f'  attention_weight[i,j] × ||V[j]|| < threshold: silent.')
print(f'  Causal mask = exactly 0 (already known).')
print(f'  Additional small weights: how many?')
print(f"{'=' * 70}\n")
attn_thresholds = [0.0001, 0.001, 0.005, 0.01]
print(f'  Fraction of attention weights < threshold (non-causal only):')
print(f"  {'Layer':<8} " + '  '.join([f't={t:.0e}' for t in attn_thresholds]))
print(f"  {'─' * 55}")
total_attn_silent = {t: [] for t in attn_thresholds}
for li in range(n_layers):
    AW = attn_w_store[li]
    if not AW:
        continue
    all_aw = np.concatenate([a for a in AW if len(a) > 0])
    fracs = []
    for t in attn_thresholds:
        frac = float((all_aw < t).mean())
        fracs.append(frac)
        total_attn_silent[t].append(frac)
    print(f'  {li:<8} ' + '  '.join([f'{f * 100:6.1f}%' for f in fracs]))
print(f'\n  Mean across layers:')
for t in attn_thresholds:
    if total_attn_silent[t]:
        mean_frac = np.mean(total_attn_silent[t])
        print(f'    t={t:.0e}: {mean_frac * 100:.1f}% silent')
print(f"\n{'=' * 70}")
print(f'  TEST D — TOTAL COMPUTE SILENCE (FFN + ATTENTION)')
print(f'  Combined: what fraction of all operations are silent?')
print(f"{'=' * 70}\n")
t_ffn = 0.001
t_attn = 0.001
ffn_silent_mean = np.mean(total_silent_contrib[t_ffn])
attn_silent_mean = np.mean(total_attn_silent[t_attn]) if total_attn_silent[t_attn] else 0
ffn_ops_frac = 2 * D * FFN_D / (2 * D * FFN_D + D * D)
attn_ops_frac = D * D / (2 * D * FFN_D + D * D)
total_silence = ffn_ops_frac * ffn_silent_mean + attn_ops_frac * attn_silent_mean
print(f'  FFN silence  (t={t_ffn:.0e}): {ffn_silent_mean * 100:.1f}%')
print(f'  Attn silence (t={t_attn:.0e}): {attn_silent_mean * 100:.1f}%')
print(f'  Total weighted silence:       {total_silence * 100:.1f}%')
print()
print(f'  FOR 70B MODEL:')
print(f'  Full model: 140GB bfloat16')
active_frac = 1 - total_silence
print(f'  Active compute fraction: {active_frac * 100:.1f}%')
print(f'  Memory for active compute: {140 * active_frac:.1f}GB')
print()
laptop_gb = 22
if 140 * active_frac < laptop_gb:
    print(f'  ✓✓ FITS. Active = {140 * active_frac:.1f}GB < {laptop_gb}GB laptop.')
else:
    print(f'  Active = {140 * active_frac:.1f}GB. Threshold needed: {laptop_gb / 140 * 100:.1f}%.')
    required_silence = 1 - laptop_gb / 140
    print(f'  Need {required_silence * 100:.1f}% silence for laptop.')
    print(f'  Current: {total_silence * 100:.1f}%.')
    gap = required_silence - total_silence
    print(f'  Gap: {gap * 100:.1f}% more silence needed.')
print(f"\n{'=' * 70}")
print(f'  TEST E — WHAT IS THE NATURAL SPACE OF gelu SILENCE?')
print(f'  gelu_out[i] small when pre_gelu[i] is negative.')
print(f'  The threshold in PRE_GELU SPACE that gives silence.')
print(f'  pre_gelu < X → gelu < epsilon. Find X.')
print(f"{'=' * 70}\n")
pregelu_store = {li: [] for li in range(n_layers)}
cur2 = {}
hooks2 = []
for li in range(n_layers):

    def make_pg(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            cur2[f'pg_{l}'] = inp.detach().float().numpy().copy()
        return h
    hooks2.append(model.transformer.h[li].mlp.act.register_forward_hook(make_pg(li)))
with torch.no_grad():
    for text in texts[:10]:
        cur2.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=20, truncation=True)
        L = toks['input_ids'].shape[1]
        model(**toks)
        for li in range(n_layers):
            if f'pg_{li}' in cur2:
                pg = cur2[f'pg_{li}'][0]
                for t in range(L):
                    pregelu_store[li].append(pg[t].copy())
for h in hooks2:
    h.remove()
print(f'  In pre_gelu space: what threshold separates')
print(f'  active neurons (gelu contribution > 1e-3) from silent?')
print()
print(f"  {'Layer':<8} {'%pre_gelu<0':<16} {'%contrib<1e-3':<18} {'Natural threshold'}")
print(f"  {'─' * 58}")
for li in range(n_layers):
    if not pregelu_store[li]:
        continue
    PG = np.array(pregelu_store[li], dtype=np.float64)
    G = np.array(gelu_store[li][:len(PG)], dtype=np.float64)
    col_norms = W2_col_norms[li]
    contrib = np.abs(G) * col_norms[None, :]
    pct_neg = float((PG < 0).mean()) * 100
    pct_silent = float((contrib < 0.001).mean()) * 100
    silent_mask = contrib < 0.001
    active_mask = contrib >= 0.001
    mean_pg_silent = float(PG[silent_mask].mean()) if silent_mask.any() else 0
    mean_pg_active = float(PG[active_mask].mean()) if active_mask.any() else 0
    threshold_pg = (mean_pg_silent + mean_pg_active) / 2
    print(f'  {li:<8} {pct_neg:<16.1f} {pct_silent:<18.1f} pre_gelu < {threshold_pg:.3f}')
print(f"\n{'=' * 70}")
print(f'  W LAW — THE NATURAL SPACE OF SELECTIVE RESPONSE')
print(f"{'=' * 70}")
print(f"\n  WRONG: gradient space. Everything connected. All active.\n  \n  RIGHT: forward activation space.\n    gelu_out = the selector.\n    gelu_out[i] × ||W2[:,i]|| = true contribution.\n    Below noise floor = silent. Exactly.\n    \n  WHAT CREATES SILENCE:\n    pre_gelu < threshold → gelu_out ≈ 0 → W2 column silent.\n    pre_gelu threshold = the natural boundary.\n    In this space: silence is visible. Measurable. Exact.\n    \n  This = gelu's natural space applied to SELECTIVITY.\n  Same principle we used to find R²=1.000 for each operation.\n  Applied now to find WHICH OPERATIONS ARE NEEDED.\n  \n  For 70B on laptop:\n    Load model in 4-bit (35GB, still too large, but closer).\n    During forward pass: track which gelu neurons are silent.\n    Skip W2 multiplication for silent neurons.\n    Silent W2 columns = never computed. Never loaded to cache.\n    Only active columns touch the compute unit.\n    \n    Active fraction from this test = ???\n    If < 16%: 70B active compute < 22GB. Fits exactly.\n")
print('=' * 70 + '\n')
