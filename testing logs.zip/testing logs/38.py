import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import math
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
NORM = 1000.0
SEQ_LEN = 4

class SphericalLinear(nn.Module):

    def __init__(self, in_features, out_neurons):
        super().__init__()
        self.linear = nn.Linear(in_features, out_neurons * 2)
        self.out_neurons = out_neurons

    def forward(self, x):
        raw = self.linear(x)
        theta = raw[..., :self.out_neurons]
        phi = raw[..., self.out_neurons:]
        theta = torch.sigmoid(theta) * math.pi
        phi = torch.sigmoid(phi) * 2 * math.pi
        tamas = torch.cos(theta)
        rajas = torch.sin(theta) * torch.cos(phi)
        sattva = torch.sin(theta) * torch.sin(phi)
        sphere_coords = torch.stack([tamas, rajas, sattva], dim=-1)
        return sphere_coords

class SphericalInteraction(nn.Module):

    def __init__(self, n_neurons, n_out):
        super().__init__()
        self.attention = nn.Linear(n_neurons * 3, n_out)
        self.sattva_gate = nn.Linear(n_neurons, n_out)

    def forward(self, sphere_points):
        batch = sphere_points.shape[0]
        flat = sphere_points.view(batch, -1)
        interaction = self.attention(flat)
        sattva = sphere_points[..., 2]
        gate = torch.sigmoid(self.sattva_gate(sattva))
        return interaction * gate

class SphericalResBlock(nn.Module):

    def __init__(self, n_neurons):
        super().__init__()
        self.interact = SphericalInteraction(n_neurons, n_neurons * 2)
        self.project = SphericalLinear(n_neurons * 2, n_neurons)

    def forward(self, x):
        batch = x.shape[0]
        h = self.interact(x)
        h = self.project(h)
        out = x + h
        norm = out.norm(dim=-1, keepdim=True).clamp(min=1e-08)
        return out / norm

class SphericalNet(nn.Module):

    def __init__(self, n_neurons, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.n_neurons = n_neurons
        self.input_to_sphere = SphericalLinear(seq_len, n_neurons)
        self.blocks = nn.ModuleList([SphericalResBlock(n_neurons) for _ in range(n_blocks)])
        self.output = nn.Linear(n_neurons * 3, 1)

    def forward(self, x):
        sphere = self.input_to_sphere(x)
        for blk in self.blocks:
            sphere = blk(sphere)
        flat = sphere.view(x.shape[0], -1)
        return self.output(flat)

class FlatResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class FlatNet(nn.Module):

    def __init__(self, dim, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(seq_len, dim), nn.Tanh())
        self.blocks = nn.ModuleList([FlatResBlock(dim) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

def gen_sequences(seq_len=SEQ_LEN, n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(seq_len + 1)]
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < seq_len + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(seq_len + 1)]
            X.append([v / NORM for v in seq[:seq_len]])
            Y.append(seq[seq_len] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(seq_len + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:seq_len]])
                Y.append(seq[seq_len] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(seq_len + 1)]
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

def train(model, X_tr, Y_tr, X_te, Y_te, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model, X_te)
            print(f'    {label:<20} ep{ep:>5}  loss={best:>12.6f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model, X_te=None):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
print_sep('PHASE 1 — MATH SEQUENCES')
X, Y = gen_sequences()
sp = int(len(X) * 0.8)
X_tr, Y_tr = (X[:sp].to(device), Y[:sp].to(device))
X_te, Y_te = (X[sp:].to(device), Y[sp:].to(device))
print(f'  Sequences: {len(X)}')
EPOCHS = 3000
configs = [('Flat-16 res-10', FlatNet(16, 10).to(device), EPOCHS), ('Flat-16 res-74 (proven best)', FlatNet(16, 74).to(device), EPOCHS), ('Spherical n=8 blocks=10', SphericalNet(8, 10).to(device), EPOCHS), ('Spherical n=16 blocks=10', SphericalNet(16, 10).to(device), EPOCHS), ('Spherical n=8 blocks=74', SphericalNet(8, 74).to(device), EPOCHS), ('Spherical n=16 blocks=74', SphericalNet(16, 74).to(device), EPOCHS)]
math_results = []
for label, model, ep in configs:
    params = sum((p.numel() for p in model.parameters()))
    print(f'\n  ── {label} (params={params:,}) ──')
    np.random.seed(42)
    loss, log = train(model, X_tr, Y_tr, X_te, Y_te, ep, lr=0.001, label=label)
    s = score(model)
    math_results.append((label, params, loss, s))
print_sep('PHASE 1 RESULTS')
math_results.sort(key=lambda x: (-x[3], x[2]))
print(f"\n  {'Model':<35}  {'Params':>10}  {'Score':>7}  {'Loss':>14}")
print(f"  {'─' * 72}")
for label, params, loss, s in math_results:
    tag = ' ← SPHERICAL' if 'Spherical' in label else ''
    print(f'  {label:<35}  {params:>10,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}{tag}')
sphere_wins = any(('Spherical' in r[0] and r[2] < min((x[2] for x in math_results if 'Flat' in x[0])) for r in math_results))
print(f"\n  SPHERICAL SPACE {('WINS' if sphere_wins else 'does not win yet')} on math")
print(f"  → {('Proceed to Phase 2: TinyStories' if sphere_wins else 'Refine spherical architecture first')}")
print_sep('WHAT PHASE 2 WILL TEST')
print(f'\n  If spherical space wins on math →\n  Next script: TinyStories language model\n\n  Same principle:\n    Flat transformer:   12-dim, 2-layer (tiny baseline)\n    Spherical transformer: same params, S² attention\n    \n  Key question:\n    Does natural spherical space give better\n    language modeling than flat space?\n    \n  If YES at both math AND language →\n    We found the natural space of intelligence.\n    Not a trick for one problem.\n    Universal geometry.\n    \n  This is the W Principle final form:\n    Intelligence = reasoning in S² space\n    Collapse only at output\n    Superposition = the computation itself\n    Sattva = the meta-reasoning gate\n')
