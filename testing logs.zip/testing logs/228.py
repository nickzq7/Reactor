import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 66)
print('  W — HYPERNETWORK ENGINE')
print('  H(layer_index) → W_ffn[l]  inside GPU, zero IO')
print('=' * 66)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
cfg = model.config
D = cfg.hidden_size
n_heads = cfg.num_attention_heads
head_dim = D // n_heads
n_layers = cfg.num_layers
act_fn = cfg.activation_function
att_layers = getattr(cfg, 'attention_layers', ['global'] * n_layers)
FFN_D = model.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'\n  D={D}  FFN_D={FFN_D}  Layers={n_layers}')
print(f'  W_ffn shape per layer: ({D}, {FFN_D})  = {D * FFN_D} params')
print(f'  Total FFN params: {n_layers * D * FFN_D:,}')
print(f'\n  Extracting exact W matrices from model...')
W_ffn_true = {}
W_ffn1_true = {}
with torch.no_grad():
    for l in range(n_layers):
        mlp = model.transformer.h[l].mlp
        W_ffn_true[l] = mlp.c_proj.weight.detach().numpy().copy()
        W_ffn1_true[l] = mlp.c_fc.weight.detach().numpy().copy()
        b1 = mlp.c_fc.bias.detach().numpy()
        b2 = mlp.c_proj.bias.detach().numpy()
        print(f'    Layer {l}: W1={W_ffn1_true[l].shape}  W2={W_ffn_true[l].shape}')
print(f"\n{'=' * 66}")
print(f'  HYPERNETWORK ARCHITECTURE')
print(f'  Input:  layer index one-hot ({n_layers},)')
print(f'  Output: W_ffn flattened ({D * FFN_D},)')
print(f"{'=' * 66}\n")

class HyperNet(nn.Module):

    def __init__(self, n_layers, d, ffn_d, hidden=512):
        super().__init__()
        out_dim = d * ffn_d
        self.net = nn.Sequential(nn.Linear(n_layers, hidden), nn.SiLU(), nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, out_dim))
        self.d = d
        self.ffn_d = ffn_d

    def forward(self, layer_onehot):
        flat = self.net(layer_onehot)
        return flat.reshape(self.d, self.ffn_d)

class HyperNetLarge(nn.Module):

    def __init__(self, n_layers, d, ffn_d, hidden=2048):
        super().__init__()
        out_dim = d * ffn_d
        self.net = nn.Sequential(nn.Linear(n_layers, hidden), nn.SiLU(), nn.Linear(hidden, hidden * 2), nn.SiLU(), nn.Linear(hidden * 2, hidden * 2), nn.SiLU(), nn.Linear(hidden * 2, hidden), nn.SiLU(), nn.Linear(hidden, out_dim))
        self.d = d
        self.ffn_d = ffn_d

    def forward(self, layer_onehot):
        flat = self.net(layer_onehot)
        return flat.reshape(self.d, self.ffn_d)
layer_onehots = torch.eye(n_layers)
W_targets = torch.tensor(np.stack([W_ffn_true[l] for l in range(n_layers)]), dtype=torch.float32)

def count_params(m):
    return sum((p.numel() for p in m.parameters()))
h_small = HyperNet(n_layers, D, FFN_D, hidden=512)
h_large = HyperNetLarge(n_layers, D, FFN_D, hidden=2048)
print(f'  Original total FFN params:    {n_layers * D * FFN_D:>10,}')
print(f'  HyperNet small params:        {count_params(h_small):>10,}  ({count_params(h_small) / (n_layers * D * FFN_D) * 100:.1f}%)')
print(f'  HyperNet large params:        {count_params(h_large):>10,}  ({count_params(h_large) / (n_layers * D * FFN_D) * 100:.1f}%)')
print(f"\n{'=' * 66}")
print(f'  TRAINING HYPERNETWORKS')
print(f'  8 samples (one per layer). Fit W_ffn exactly.')
print(f"{'=' * 66}\n")

def train_hyper(model_h, name, epochs=50000, lr=0.001):
    opt = optim.Adam(model_h.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    best_loss = float('inf')
    best_state = None
    t0 = time.time()
    for ep in range(epochs):
        opt.zero_grad()
        preds = torch.stack([model_h(layer_onehots[l]) for l in range(n_layers)])
        loss = nn.functional.mse_loss(preds, W_targets)
        loss.backward()
        opt.step()
        scheduler.step()
        if loss.item() < best_loss:
            best_loss = loss.item()
            best_state = {k: v.clone() for k, v in model_h.state_dict().items()}
        if (ep + 1) % 10000 == 0:
            elapsed = time.time() - t0
            print(f'    [{name}] ep={ep + 1:>6}  loss={loss.item():.6f}  best={best_loss:.6f}  time={elapsed:.1f}s')
    model_h.load_state_dict(best_state)
    return best_loss
print(f'  Training small hypernetwork ({count_params(h_small):,} params)...')
loss_small = train_hyper(h_small, 'small', epochs=50000)
print(f'\n  Training large hypernetwork ({count_params(h_large):,} params)...')
loss_large = train_hyper(h_large, 'large', epochs=50000)
print(f"\n{'=' * 66}")
print(f'  QUALITY EVALUATION')
print(f'  R² per layer: H(l) vs true W_ffn[l]')
print(f"{'=' * 66}\n")

def r2(pred, true):
    ss_res = np.sum((true - pred) ** 2)
    ss_tot = np.sum((true - true.mean()) ** 2)
    return float(1 - ss_res / (ss_tot + 1e-10))
print(f"  {'Layer':<8} {'R² small':<14} {'R² large':<14} {'max_err small':<16} {'max_err large'}")
print(f"  {'─' * 65}")
r2_small_all = []
r2_large_all = []
with torch.no_grad():
    for l in range(n_layers):
        oh = layer_onehots[l]
        W_s = h_small(oh).numpy()
        W_l = h_large(oh).numpy()
        W_t = W_ffn_true[l]
        r2_s = r2(W_s, W_t)
        r2_l = r2(W_l, W_t)
        e_s = float(np.max(np.abs(W_s - W_t)))
        e_l = float(np.max(np.abs(W_l - W_t)))
        r2_small_all.append(r2_s)
        r2_large_all.append(r2_l)
        print(f'  {l:<8} {r2_s:<14.6f} {r2_l:<14.6f} {e_s:<16.4f} {e_l:.4f}')
print(f'\n  Mean R² small: {np.mean(r2_small_all):.6f}')
print(f'  Mean R² large: {np.mean(r2_large_all):.6f}')
print(f"\n{'=' * 66}")
print(f'  ACTIVATION TEST')
print(f'  Does gelu_out @ H(l) ≈ gelu_out @ W_ffn_true[l]?')
print(f'  This is the real quality metric — token prediction.')
print(f"{'=' * 66}\n")
prompts = ['Once upon a time', 'The little girl', 'Deep in the forest', 'A brave knight', 'The old man', 'She smiled and', 'Every morning', 'The dragon flew']
gelu_acts = {l: [] for l in range(n_layers)}
hooks = []
for li in range(n_layers):

    def make_hook(layer_idx):

        def hook(m, inp, out):
            gelu_acts[layer_idx].append(out.detach().numpy().reshape(-1, FFN_D))
        return hook
    hooks.append(model.transformer.h[li].mlp.act.register_forward_hook(make_hook(li)))
with torch.no_grad():
    for p in prompts:
        ids = tokenizer.encode(p, return_tensors='pt')
        model(ids)
for h in hooks:
    h.remove()
gelu_acts = {l: np.vstack(gelu_acts[l]) for l in range(n_layers)}
print(f"  {'Layer':<8} {'R² output small':<20} {'R² output large':<20} {'verdict'}")
print(f"  {'─' * 60}")
with torch.no_grad():
    for l in range(n_layers):
        G = gelu_acts[l]
        W_t = W_ffn_true[l]
        oh = layer_onehots[l]
        W_s = h_small(oh).numpy()
        W_l = h_large(oh).numpy()
        out_true = G @ W_t.T
        out_small = G @ W_s.T
        out_large = G @ W_l.T
        r2_s = r2(out_small, out_true)
        r2_l = r2(out_large, out_true)
        v = '✓ EXACT' if r2_l > 0.999 else '✓ GOOD' if r2_l > 0.99 else '~ USABLE' if r2_l > 0.95 else '✗ POOR'
        print(f'  {l:<8} {r2_s:<20.6f} {r2_l:<20.6f} {v}')
print(f"\n{'=' * 66}")
print(f'  GENERATION TEST')
print(f'  Replace W_ffn with H(l) and generate text.')
print(f'  Compare: PyTorch vs HyperNet engine.')
print(f"{'=' * 66}")

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + np.float32(eps)) * g + b

def gelu_new_np(x):
    x = x.astype(np.float32)
    c = np.float32(math.sqrt(2 / math.pi))
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
lnf_w = model.transformer.ln_f.weight.detach().numpy()
lnf_b = model.transformer.ln_f.bias.detach().numpy()
lm_w = model.lm_head.weight.detach().numpy()
layer_weights = {}
with torch.no_grad():
    for l in range(n_layers):
        blk = model.transformer.h[l]
        att = blk.attn.attention
        layer_weights[l] = {'Wq': att.q_proj.weight.detach().numpy(), 'Wk': att.k_proj.weight.detach().numpy(), 'Wv': att.v_proj.weight.detach().numpy(), 'Wo': att.out_proj.weight.detach().numpy(), 'bo': att.out_proj.bias.detach().numpy(), 'W1': blk.mlp.c_fc.weight.detach().numpy(), 'b1': blk.mlp.c_fc.bias.detach().numpy(), 'W2': blk.mlp.c_proj.weight.detach().numpy(), 'b2': blk.mlp.c_proj.bias.detach().numpy(), 'ln1_w': blk.ln_1.weight.detach().numpy(), 'ln1_b': blk.ln_1.bias.detach().numpy(), 'ln2_w': blk.ln_2.weight.detach().numpy(), 'ln2_b': blk.ln_2.bias.detach().numpy()}
with torch.no_grad():
    H_small_weights = {l: h_small(layer_onehots[l]).numpy() for l in range(n_layers)}
    H_large_weights = {l: h_large(layer_onehots[l]).numpy() for l in range(n_layers)}

def numpy_forward(token_ids, w2_override=None):
    seq_len = len(token_ids)
    x = (wte[token_ids] + wpe[np.arange(seq_len)]).astype(np.float32)
    mask = np.triu(np.full((seq_len, seq_len), float('-inf'), np.float32), 1)
    for l in range(n_layers):
        W = layer_weights[l]
        ln1 = ln_np(x, W['ln1_w'], W['ln1_b'])
        Q = ln1 @ W['Wq'].T
        K = ln1 @ W['Wk'].T
        V = ln1 @ W['Wv'].T
        Qh = Q.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)
        heads = []
        for h in range(n_heads):
            sc = Qh[h] @ Kh[h].T
            heads.append(softmax_np(sc + mask) @ Vh[h])
        concat = np.stack(heads, 1).reshape(seq_len, D)
        att_out = concat @ W['Wo'].T + W['bo']
        x = x + att_out
        ln2 = ln_np(x, W['ln2_w'], W['ln2_b'])
        pre = ln2 @ W['W1'].T + W['b1']
        g = gelu_new_np(pre)
        W2 = w2_override[l] if w2_override else W['W2']
        ffn_out = g @ W2.T + W['b2']
        x = x + ffn_out
    h_f = ln_np(x, lnf_w, lnf_b)
    return (h_f[-1:] @ lm_w.T)[0]
prompt = 'Once upon a time, in a small village, there lived a boy named Jack.'
input_ids_enc = tokenizer.encode(prompt, return_tensors='pt')
N_GEN = 30
pt_ids = input_ids_enc.clone()
with torch.no_grad():
    for _ in range(N_GEN):
        next_id = torch.argmax(model(pt_ids).logits[0, -1, :]).item()
        pt_ids = torch.cat([pt_ids, torch.tensor([[next_id]])], dim=1)
pt_tokens = pt_ids[0].tolist()
pt_text = tokenizer.decode(pt_tokens)
np_ids = input_ids_enc[0].tolist()
for _ in range(N_GEN):
    np_ids.append(int(np.argmax(numpy_forward(np_ids))))
np_text = tokenizer.decode(np_ids)
hs_ids = input_ids_enc[0].tolist()
for _ in range(N_GEN):
    hs_ids.append(int(np.argmax(numpy_forward(hs_ids, H_small_weights))))
hs_text = tokenizer.decode(hs_ids)
hl_ids = input_ids_enc[0].tolist()
for _ in range(N_GEN):
    hl_ids.append(int(np.argmax(numpy_forward(hl_ids, H_large_weights))))
hl_text = tokenizer.decode(hl_ids)
print(f'\n  [ PYTORCH (ground truth) ]:\n  {pt_text}\n')
print(f'  [ NUMPY   (true W)       ]:\n  {np_text}\n')
print(f'  [ HYPER-S (small H)      ]:\n  {hs_text}\n')
print(f'  [ HYPER-L (large H)      ]:\n  {hl_text}\n')
pt_gen = pt_tokens[len(input_ids_enc[0]):]
np_gen = np_ids[len(input_ids_enc[0]):]
hs_gen = hs_ids[len(input_ids_enc[0]):]
hl_gen = hl_ids[len(input_ids_enc[0]):]
np_match = sum((a == b for a, b in zip(pt_gen, np_gen)))
hs_match = sum((a == b for a, b in zip(pt_gen, hs_gen)))
hl_match = sum((a == b for a, b in zip(pt_gen, hl_gen)))
print(f'  Token match vs PyTorch:')
print(f'    Numpy true W:    {np_match}/{N_GEN} = {100 * np_match / N_GEN:.1f}%')
print(f'    HyperNet small:  {hs_match}/{N_GEN} = {100 * hs_match / N_GEN:.1f}%')
print(f'    HyperNet large:  {hl_match}/{N_GEN} = {100 * hl_match / N_GEN:.1f}%')
print(f"\n{'=' * 66}")
print(f'  SPEED TEST')
print(f'  H generation time vs simulated IO time')
print(f"{'=' * 66}\n")
N_BENCH = 1000
with torch.no_grad():
    t0 = time.perf_counter()
    for _ in range(N_BENCH):
        for l in range(n_layers):
            _ = h_large(layer_onehots[l])
    t_hyper = (time.perf_counter() - t0) / N_BENCH * 1000
gelu_sample = gelu_acts[0][:32].astype(np.float32)
t0 = time.perf_counter()
for _ in range(N_BENCH):
    for l in range(n_layers):
        _ = gelu_sample @ W_ffn_true[l].T
t_matmul = (time.perf_counter() - t0) / N_BENCH * 1000
matrix_bytes = D * FFN_D * 4
ssd_speed_mbs = 3000
t_ssd_per_layer_ms = matrix_bytes / (ssd_speed_mbs * 1000000.0) * 1000
t_ssd_total_ms = t_ssd_per_layer_ms * n_layers
ram_speed_mbs = 50000
t_ram_per_layer_ms = matrix_bytes / (ram_speed_mbs * 1000000.0) * 1000
t_ram_total_ms = t_ram_per_layer_ms * n_layers
print(f'  Matrix size per layer: {matrix_bytes / 1024:.1f} KB')
print(f'  Total FFN data:        {matrix_bytes * n_layers / 1024:.1f} KB\n')
print(f"  {'Method':<35} {'time/token':<15} {'speedup'}")
print(f"  {'─' * 55}")
print(f"  {'SSD load (NVMe ~3GB/s)':<35} {t_ssd_total_ms:<15.3f} 1.0x (baseline)")
print(f"  {'RAM load (~50GB/s)':<35} {t_ram_total_ms:<15.3f} {t_ssd_total_ms / t_ram_total_ms:.1f}x")
print(f"  {'H generation (CPU numpy)':<35} {t_hyper:<15.3f} {t_ssd_total_ms / t_hyper:.1f}x")
print(f"  {'FFN matmul only':<35} {t_matmul:<15.3f} {t_ssd_total_ms / t_matmul:.1f}x")
print(f'\n  Note: On real GPU, H generation = ~10-50x faster than CPU.')
print(f'  GPU H generation time ≈ {t_hyper / 20:.4f} ms (estimated)')
print(f'  vs SSD load time      ≈ {t_ssd_total_ms:.4f} ms')
print(f"\n{'=' * 66}")
print(f'  FINAL SUMMARY')
print(f"{'=' * 66}\n")
best_r2 = np.mean(r2_large_all)
print(f'\n  WHAT IS PROVEN:\n  \n  1. W_ffn per layer = exact (R²=1.000000) ← already proven\n  \n  2. HyperNet quality:\n     R² of H(l) vs W_ffn[l]:       {best_r2:.6f}\n     Token match (H large):         {hl_match}/{N_GEN} = {100 * hl_match / N_GEN:.1f}%\n  \n  3. Speed:\n     H generation (CPU):            {t_hyper:.3f} ms\n     SSD load (simulated):          {t_ssd_total_ms:.3f} ms\n     Speedup:                       {t_ssd_total_ms / t_hyper:.1f}x (CPU)\n     Estimated GPU speedup:         {t_ssd_total_ms / (t_hyper / 20):.1f}x\n  \n  WHAT THIS MEANS:\n  \n  If H quality is high (R² > 0.99):\n    Replace disk IO with H generation.\n    H stays permanently in GPU.\n    Zero IO for FFN weights during inference.\n    This is the Sanskrit grammar:\n      Not storing all words (weights on disk).\n      Storing rules (H) that generate words on demand.\n  \n  HONEST LIMITATION:\n    TinyStories = D=64, FFN_D=256. Very small.\n    H can potentially memorize 8 matrices exactly.\n    Real test = 7B model (D=4096, FFN_D=11008, 28 layers).\n    On 7B: same H concept but each matrix = 45MB.\n    H must generalize, not memorize.\n    That is the real open question.\n')
print('=' * 66 + '\n')
