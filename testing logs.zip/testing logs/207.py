import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — MINIMAL FEATURES, MANY SAMPLES')
print('  Only att + ffn corrections.')
print('  5000+ samples. Trustworthy ratio.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
CTX = 8
layer_idx = 0
block = model.transformer.h[layer_idx]

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ R²=1.0' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<50} {mark}')
    return score
starts = ['Once upon a time', 'One day a little', 'There was a small', 'A boy named Tom', 'The princess looked', 'In the forest there', 'A friendly dragon', 'The little rabbit', 'She opened the door', 'He looked up and', 'The old wizard said', 'A kind fairy came', 'The dog ran fast', 'Mom said it was', 'The children went to', 'It was a sunny', 'Deep in the woods', 'The magic stone could', 'Every morning the bird', 'The brave knight rode', 'She found a lost', 'The baby bear found', 'A tiny seed grew', 'The two friends walked', 'A rainbow appeared after', 'The kind queen shared', 'A yellow duck learned', 'The snow fell softly', 'He wished upon a', 'The cat chased the', 'A boat sailed across', 'The children found a', 'She drew a picture', 'The moon shone bright', 'A boy climbed the', 'The woman gave bread', 'He discovered a door', 'An elephant splashed in', 'She sang a song', 'A mouse found cheese', 'A girl named Emma', 'The farmer woke up', 'Three little bears came', 'The frog jumped across', 'A butterfly emerged', 'The children built a', 'An owl sat watching', 'The kitten played with', 'A genie appeared to', 'The turtle and rabbit']
print(f'\n  Generating text from {len(starts)} prompts...')
print(f'  Target: 5000+ windows of {CTX} tokens.')
all_texts = []
with torch.no_grad():
    for i, start in enumerate(starts):
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(i * 100 + int(temp * 10))
            inp = tokenizer.encode(start, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=50, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            text = tokenizer.decode(out[0], skip_special_tokens=True)
            all_texts.append(text)
print(f'  Generated {len(all_texts)} texts.')
print(f'\n  Collecting minimal features...')
print(f'  Features per sample: {CTX * D} (x) + {CTX * D} (att) + {CTX * D} (ffn) = {3 * CTX * D}')
X_list = []
A_list = []
F_list = []
D_list = []
with torch.no_grad():
    for text in all_texts:
        tokens = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < CTX:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for start in range(L - CTX + 1):
            x_t = hs[layer_idx][0, start:start + CTX]
            y_np = hs[layer_idx + 1][0, start:start + CTX].numpy()
            x_np = x_t.numpy()
            delta = y_np - x_np
            ln1 = block.ln_1(x_t)
            att = block.attn(ln1.unsqueeze(0))[0].squeeze(0).numpy()
            x2 = x_t + torch.tensor(att, dtype=torch.float32)
            ln2 = block.ln_2(x2)
            pre = block.mlp.c_fc(ln2).numpy()
            act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
            ffn = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).numpy()
            X_list.append(x_np.flatten())
            A_list.append(att.flatten())
            F_list.append(ffn.flatten())
            D_list.append(delta.flatten())
N = len(X_list)
X_arr = np.array(X_list)
A_arr = np.array(A_list)
F_arr = np.array(F_list)
D_arr = np.array(D_list)
N_tr = int(N * 0.8)
print(f'\n  Total samples     : {N}')
print(f'  Train / Test      : {N_tr} / {N - N_tr}')
print(f'  Ratio x features  : {N_tr / (CTX * D):.1f}x  (need >3x)')
print(f'  Ratio all features: {N_tr / (3 * CTX * D):.1f}x')
print('\n' + '─' * 62)
print('  TARGET: delta (total correction)')
print('  Progressive: which features capture it?')
print('─' * 62)
print()
test(X_arr[:N_tr], D_arr[:N_tr], X_arr[N_tr:], D_arr[N_tr:], 'raw input x → delta')
test(A_arr[:N_tr], D_arr[:N_tr], A_arr[N_tr:], D_arr[N_tr:], 'attention correction → delta')
test(F_arr[:N_tr], D_arr[:N_tr], F_arr[N_tr:], D_arr[N_tr:], 'FFN correction → delta')
AF = np.column_stack([A_arr, F_arr])
test(AF[:N_tr], D_arr[:N_tr], AF[N_tr:], D_arr[N_tr:], 'att + ffn → delta')
XAF = np.column_stack([X_arr, A_arr, F_arr])
test(XAF[:N_tr], D_arr[:N_tr], XAF[N_tr:], D_arr[N_tr:], 'x + att + ffn → delta')
print('\n' + '─' * 62)
print('  SEPARATE TARGETS: att correction and ffn correction')
print('─' * 62)
print()
test(X_arr[:N_tr], A_arr[:N_tr], X_arr[N_tr:], A_arr[N_tr:], 'x → att correction')
test(X_arr[:N_tr], F_arr[:N_tr], X_arr[N_tr:], F_arr[N_tr:], 'x → ffn correction')
test(A_arr[:N_tr], F_arr[:N_tr], A_arr[N_tr:], F_arr[N_tr:], 'att correction → ffn correction')
test(np.column_stack([X_arr, A_arr])[:N_tr], F_arr[:N_tr], np.column_stack([X_arr, A_arr])[N_tr:], F_arr[N_tr:], 'x + att → ffn correction')
print('\n' + '=' * 62)
print('  WHAT IS REVEALED')
print('=' * 62)
print(f'\n  Samples : {N}\n  Ratio   : {N_tr / (3 * CTX * D):.1f}x  (trustworthy above 3x)\n\n  Key questions answered:\n\n  1. Does x alone predict delta well?\n     If yes  → block is approximately linear. Simple.\n     If no   → block has hidden nonlinear structure.\n\n  2. Does att correction predict delta?\n     If R²≈1 → attention dominates the correction.\n     If low  → FFN contributes independently.\n\n  3. Does x predict att correction?\n     If R²=1 → attention is linear in input. (We know rule.)\n     If low  → attention has context structure not in x alone.\n\n  4. Does x+att predict ffn?\n     If R²=1 → FFN depends on attention output.\n               They are not independent.\n               Their interaction IS the hidden law.\n     If low  → FFN is independent of attention.\n\n  The answers to these four questions\n  map the exact hidden structure.\n  No more guessing.\n  Numbers speak.\n')
print('=' * 62 + '\n')
