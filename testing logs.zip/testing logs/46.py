import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq, matrix_rank
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN = 2000
MAX_SEQ = 64
GEN_TOKENS = 40
BATCH_SIZE = 50
TEST_PROMPTS = ['Once upon a time there was a little girl named', 'The dog ran fast and', 'In the forest there lived a', 'Tom and his friend went to the', 'The big red ball']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('\n' + '=' * 65)
print('  LOAD TEACHER + TINYSTORIES DATASET')
print('=' * 65)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD, VOCAB = (H // NH, cfg.vocab_size)
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT_TYPES = cfg.attention_layers
except:
    ATT_TYPES = ['global'] * NL
FFN_D = teacher.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'  NL={NL} H={H} NH={NH} HD={HD} FFN_D={FFN_D}')
print(f'\n  Loading TinyStories dataset...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
sentences = []
for item in ds:
    text = item['text'].strip()
    if 20 < len(text) < 300:
        sentences.append(text)
    if len(sentences) >= N_TRAIN:
        break
print(f'  Loaded {len(sentences)} diverse stories')
print(f'  Sample: "{sentences[0][:60]}"')
print('\n' + '=' * 65)
print(f'  COLLECT CRYSTAL BOUNDARY ACTIVATIONS ({N_TRAIN} stories)')
print('=' * 65)
buffers = {li: {'ln1': [], 'Q': [], 'K': [], 'V': [], 'ctx': [], 'att_out': [], 'ln2': [], 'pre_gelu': [], 'gelu_out': [], 'ffn_out': []} for li in range(NL)}
hooks = []

def add_hooks():
    for li in range(NL):
        bl = teacher.transformer.h[li]
        at = bl.attn.attention

        def make_ln1(l):

            def fn(mod, inp, out):
                buffers[l]['ln1'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_q(l):

            def fn(mod, inp, out):
                buffers[l]['Q'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_k(l):

            def fn(mod, inp, out):
                buffers[l]['K'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_v(l):

            def fn(mod, inp, out):
                buffers[l]['V'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_ctx(l):

            def fn(mod, inp, out):
                buffers[l]['ctx'].append(inp[0].detach().float().cpu().reshape(-1, H).numpy())
                buffers[l]['att_out'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_ln2(l):

            def fn(mod, inp, out):
                buffers[l]['ln2'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn

        def make_fc(l):

            def fn(mod, inp, out):
                buffers[l]['pre_gelu'].append(out.detach().float().cpu().reshape(-1, FFN_D).numpy())
                pre = out.detach().float().cpu()
                g = 0.5 * pre * (1 + torch.tanh(math.sqrt(2 / math.pi) * (pre + 0.044715 * pre ** 3)))
                buffers[l]['gelu_out'].append(g.reshape(-1, FFN_D).numpy())
            return fn

        def make_ffn(l):

            def fn(mod, inp, out):
                buffers[l]['ffn_out'].append(out.detach().float().cpu().reshape(-1, H).numpy())
            return fn
        hooks.append(bl.ln_1.register_forward_hook(make_ln1(li)))
        hooks.append(at.q_proj.register_forward_hook(make_q(li)))
        hooks.append(at.k_proj.register_forward_hook(make_k(li)))
        hooks.append(at.v_proj.register_forward_hook(make_v(li)))
        hooks.append(at.out_proj.register_forward_hook(make_ctx(li)))
        hooks.append(bl.ln_2.register_forward_hook(make_ln2(li)))
        hooks.append(bl.mlp.c_fc.register_forward_hook(make_fc(li)))
        hooks.append(bl.mlp.c_proj.register_forward_hook(make_ffn(li)))
add_hooks()
t_collect = time.perf_counter()
n_tokens = 0
with torch.no_grad():
    for si, sentence in enumerate(sentences):
        ids = tok(sentence, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'].to(device)
        teacher(ids)
        n_tokens += ids.shape[1]
        if (si + 1) % 500 == 0:
            print(f'    {si + 1}/{N_TRAIN}  tokens={n_tokens}')
for h in hooks:
    h.remove()
t_collect = time.perf_counter() - t_collect
print(f'\n  Collected {n_tokens} tokens in {t_collect:.2f}s')
for li in range(NL):
    for k in buffers[li]:
        if buffers[li][k]:
            buffers[li][k] = np.concatenate(buffers[li][k], 0).astype(np.float32)
N = buffers[0]['ln1'].shape[0]
print(f'  Total positions: {N}')
print(f'\n  Activation space coverage (layer 0):')
ln1_sample = buffers[0]['ln1']
rk = matrix_rank(ln1_sample.astype(np.float64))
print(f"    ln1 rank = {rk} / {H}  {('✓ FULL RANK' if rk >= H else f'⚠ RANK DEFICIENT ({rk}<{H})')}")
print('\n' + '=' * 65)
print('  SOLVE W MATRICES (O(1) TRAINING)')
print('=' * 65)
print(f"  {'Layer':<8} {'W_q R²':>8} {'W_k R²':>8} {'W_v R²':>8} {'W_o R²':>8} {'W1 R²':>8} {'W2 R²':>8}  time")
print(f"  {'-' * 72}")

def solve_W(X, Y):
    X = X.astype(np.float64)
    Y = Y.astype(np.float64)
    Xb = np.concatenate([X, np.ones((X.shape[0], 1), np.float64)], 1)
    result, _, _, _ = lstsq(Xb, Y, rcond=None)
    W, b = (result[:-1].T.astype(np.float32), result[-1].astype(np.float32))
    Y_pred = X.astype(np.float32) @ W.T + b
    ss_res = float(((Y.astype(np.float32) - Y_pred) ** 2).sum())
    ss_tot = float(((Y.astype(np.float32) - Y.astype(np.float32).mean(0)) ** 2).sum())
    return (W, b, float(1 - ss_res / (ss_tot + 1e-12)))
R = {}
r2_all = {}
t_solve = time.perf_counter()
for li in range(NL):
    t0 = time.perf_counter()
    b = buffers[li]
    W_q, bq, r2q = solve_W(b['ln1'], b['Q'])
    W_k, bk, r2k = solve_W(b['ln1'], b['K'])
    W_v, bv, r2v = solve_W(b['ln1'], b['V'])
    W_o, bo, r2o = solve_W(b['ctx'], b['att_out'])
    W1, b1, r21 = solve_W(b['ln2'], b['pre_gelu'])
    W2, b2, r22 = solve_W(b['gelu_out'], b['ffn_out'])
    R[li] = {'W_q': W_q, 'b_q': bq, 'W_k': W_k, 'b_k': bk, 'W_v': W_v, 'b_v': bv, 'W_o': W_o, 'b_o': bo, 'W1': W1, 'b1': b1, 'W2': W2, 'b2': b2}
    r2_all[li] = [r2q, r2k, r2v, r2o, r21, r22]
    mark = '✓' if min(r2q, r2k, r2v, r2o, r21, r22) > 0.9999 else '~'
    print(f'  Layer {li:<3}  {r2q:8.6f} {r2k:8.6f} {r2v:8.6f} {r2o:8.6f} {r21:8.6f} {r22:8.6f}  {time.perf_counter() - t0:.2f}s {mark}')
t_solve = time.perf_counter() - t_solve
print(f'\n  Solve time: {t_solve:.3f}s  ZERO gradient steps')
with torch.no_grad():
    for li in range(NL):
        bl = teacher.transformer.h[li]
        R[li].update({'ln1_g': bl.ln_1.weight.detach().float().cpu().numpy(), 'ln1_b': bl.ln_1.bias.detach().float().cpu().numpy(), 'ln2_g': bl.ln_2.weight.detach().float().cpu().numpy(), 'ln2_b': bl.ln_2.bias.detach().float().cpu().numpy(), 'attn_type': ATT_TYPES[li] if li < len(ATT_TYPES) else 'global', 'window': WIN})
Wte = teacher.transformer.wte.weight.detach().float().cpu().numpy()
Wpe = teacher.transformer.wpe.weight.detach().float().cpu().numpy()
lnf_g = teacher.transformer.ln_f.weight.detach().float().cpu().numpy()
lnf_b = teacher.transformer.ln_f.bias.detach().float().cpu().numpy()
Wlm = teacher.lm_head.weight.detach().float().cpu().numpy()
print('\n' + '=' * 65)
print('  W MATRIX DISTANCE: REACTOR vs TEACHER')
print("  (How close are solved W to teacher's actual W?)")
print('=' * 65)

def corr(a, b):
    a, b = (a.ravel().astype(np.float64), b.ravel().astype(np.float64))
    return float(np.corrcoef(a, b)[0, 1])
print(f"\n  {'Layer':<8} {'W_q':>8} {'W_k':>8} {'W_v':>8} {'W_o':>8} {'W1':>8} {'W2':>8}")
print(f"  {'-' * 60}")
with torch.no_grad():
    for li in range(NL):
        bl = teacher.transformer.h[li]
        at = bl.attn.attention
        tw = {'W_q': at.q_proj.weight.detach().float().cpu().numpy(), 'W_k': at.k_proj.weight.detach().float().cpu().numpy(), 'W_v': at.v_proj.weight.detach().float().cpu().numpy(), 'W_o': at.out_proj.weight.detach().float().cpu().numpy(), 'W1': bl.mlp.c_fc.weight.detach().float().cpu().numpy(), 'W2': bl.mlp.c_proj.weight.detach().float().cpu().numpy()}
        cq = corr(R[li]['W_q'], tw['W_q'])
        ck = corr(R[li]['W_k'], tw['W_k'])
        cv = corr(R[li]['W_v'], tw['W_v'])
        co = corr(R[li]['W_o'], tw['W_o'])
        c1 = corr(R[li]['W1'], tw['W1'])
        c2 = corr(R[li]['W2'], tw['W2'])
        print(f'  Layer {li:<3}  {cq:8.5f} {ck:8.5f} {cv:8.5f} {co:8.5f} {c1:8.5f} {c2:8.5f}')
print(f'\n  corr→1.0 = solved W identical to teacher W (full rank data)')
print(f'  corr<1.0 = null space component remains (need more diverse data)')

def ln_np(x, g, b):
    x = x.astype(np.float32)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (g * (x - m) / np.sqrt(v + 1e-05) + b).astype(np.float32)

def gelu_np(x):
    x = x.astype(np.float32)
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)

def softmax_np(x):
    x = x.astype(np.float32)
    e = np.exp(x - x.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)).astype(np.float32)

def reactor_layer(h, li):
    w = R[li]
    sl = h.shape[0]
    ln1 = ln_np(h, w['ln1_g'], w['ln1_b'])
    Q = (ln1 @ w['W_q'].T + w['b_q']).astype(np.float32)
    K = (ln1 @ w['W_k'].T + w['b_k']).astype(np.float32)
    V = (ln1 @ w['W_v'].T + w['b_v']).astype(np.float32)
    Qh = Q.reshape(sl, NH, HD).transpose(1, 0, 2).astype(np.float32)
    Kh = K.reshape(sl, NH, HD).transpose(1, 0, 2).astype(np.float32)
    Vh = V.reshape(sl, NH, HD).transpose(1, 0, 2).astype(np.float32)
    sc = np.matmul(Qh, Kh.transpose(0, 2, 1))
    mk = np.full((sl, sl), -1000000000.0, np.float32)
    for i in range(sl):
        s = max(0, i - w['window'] + 1) if w['attn_type'] == 'local' else 0
        mk[i, s:i + 1] = 0.0
    sc += mk[np.newaxis]
    sc -= sc.max(-1, keepdims=True)
    e = np.exp(sc)
    p = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    ctx = np.matmul(p, Vh).transpose(1, 0, 2).reshape(sl, H).astype(np.float32)
    att = (ctx @ w['W_o'].T + w['b_o']).astype(np.float32)
    hm = (h + att).astype(np.float32)
    ln2 = ln_np(hm, w['ln2_g'], w['ln2_b'])
    pre = (ln2 @ w['W1'].T + w['b1']).astype(np.float32)
    ffn = (gelu_np(pre) @ w['W2'].T + w['b2']).astype(np.float32)
    return (hm + ffn).astype(np.float32)

def reactor_forward(ids):
    ids = np.array(ids, np.int32)
    h = (Wte[ids] + Wpe[np.arange(len(ids))]).astype(np.float32)
    for li in range(NL):
        h = reactor_layer(h, li)
    return (ln_np(h, lnf_g, lnf_b) @ Wlm.T).astype(np.float32)

def gen_teacher(prompt, n):
    ids = tok(prompt, return_tensors='pt')['input_ids'].to(device)
    with torch.no_grad():
        out = teacher.generate(ids, max_new_tokens=n, do_sample=False, use_cache=True)
    return out[0][ids.shape[1]:].cpu().tolist()

def gen_reactor(prompt, n):
    ids = tok(prompt, return_tensors='pt')['input_ids'][0].tolist()
    for _ in range(n):
        ids.append(int(np.argmax(reactor_forward(ids)[-1])))
    return ids[-n:]
print('\n' + '=' * 65)
print('  GENERATION BENCHMARK')
print('=' * 65)
total_match, total_tok = (0, 0)
for prompt in TEST_PROMPTS:
    ids_t = gen_teacher(prompt, GEN_TOKENS)
    ids_r = gen_reactor(prompt, GEN_TOKENS)
    m = sum((a == b for a, b in zip(ids_t, ids_r)))
    total_match += m
    total_tok += GEN_TOKENS
    bar = '█' * (m // 4) + '░' * ((GEN_TOKENS - m) // 4)
    print(f'\n  "{prompt[:45]}"  {m}/{GEN_TOKENS}  {bar}')
    print(f'    Teacher: {repr(tok.decode(ids_t)[:65])}')
    print(f'    REACTOR: {repr(tok.decode(ids_r)[:65])}')
match_pct = 100 * total_match / total_tok
print('\n' + '=' * 65)
print('  SUMMARY')
print('=' * 65)
avg_r2 = np.mean([np.mean(v) for v in r2_all.values()])
min_r2 = np.min([np.min(v) for v in r2_all.values()])
print(f'\n  DATA:\n    Stories:         {N_TRAIN} (diverse TinyStories)\n    Total tokens:    {n_tokens}\n    Activation rank: {rk}/{H} (full rank = unique solution)\n\n  TRAINING (O(1)):\n    Collection:    {t_collect:.2f}s  (one forward pass)\n    Solve time:    {t_solve:.3f}s  (48 lstsq solves)\n    Total:         {t_collect + t_solve:.2f}s\n    Gradient steps: 0\n\n  SOLVE QUALITY:\n    Avg R²: {avg_r2:.8f}\n    Min R²: {min_r2:.8f}\n\n  GENERATION:\n    Token match: {total_match}/{total_tok} = {match_pct:.1f}%\n\n  INTERPRETATION:\n    R²=1.0 + corr(W_solved, W_teacher)→1.0 + match→100%\n      = O(1) training proven, full rank data achieved\n\n    R²=1.0 + corr<1.0 + match<100%\n      = Need more diverse data (null space not collapsed)\n      = N_TRAIN too small OR sentences not diverse enough\n\n    To collapse null space completely:\n      Theoretical minimum: N_unique >> H² = {H ** 2}\n      Practical: {H ** 2 * 4} tokens should suffice\n')
