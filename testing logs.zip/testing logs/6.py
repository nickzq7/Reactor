import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import math
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
NORM = 1000.0
SEQ_LEN = 4

class ComplexLinear(nn.Module):

    def __init__(self, in_features, out_features):
        super().__init__()
        self.W_real = nn.Linear(in_features, out_features, bias=True)
        self.W_imag = nn.Linear(in_features, out_features, bias=False)
        nn.init.normal_(self.W_imag.weight, mean=0, std=0.01)

    def forward(self, x_real, x_imag):
        y_real = self.W_real(x_real) - self.W_imag(x_imag)
        y_imag = self.W_real(x_imag) + self.W_imag(x_real)
        return (y_real, y_imag)

class ComplexActivation(nn.Module):

    def __init__(self, n_features):
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(n_features))

    def forward(self, x_real, x_imag):
        magnitude = torch.sqrt(x_real ** 2 + x_imag ** 2 + 1e-08)
        gate = F.relu(magnitude + self.bias) / magnitude
        return (x_real * gate, x_imag * gate)

class ComplexResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = ComplexLinear(dim, dim)
        self.act = ComplexActivation(dim)

    def forward(self, x_real, x_imag):
        h_real, h_imag = self.linear(x_real, x_imag)
        h_real, h_imag = self.act(h_real, h_imag)
        return (x_real + h_real, x_imag + h_imag)

class ComplexNet(nn.Module):

    def __init__(self, dim, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.dim = dim
        self.input_real = nn.Linear(seq_len, dim)
        self.input_imag = nn.Linear(seq_len, dim)
        nn.init.normal_(self.input_imag.weight, mean=0, std=0.01)
        self.blocks = nn.ModuleList([ComplexResBlock(dim) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x_real = torch.tanh(self.input_real(x))
        x_imag = torch.tanh(self.input_imag(x))
        for blk in self.blocks:
            x_real, x_imag = blk(x_real, x_imag)
        magnitude = torch.sqrt(x_real ** 2 + x_imag ** 2 + 1e-08)
        return self.output(magnitude)

    def sattva_analysis(self, x):
        x_real = torch.tanh(self.input_real(x))
        x_imag = torch.tanh(self.input_imag(x))
        states = []
        for blk in self.blocks:
            x_real, x_imag = blk(x_real, x_imag)
            mag = torch.sqrt(x_real ** 2 + x_imag ** 2 + 1e-08)
            phase = torch.atan2(x_imag, x_real)
            states.append({'tamas_mean': x_real.abs().mean().item(), 'rajas_mean': x_imag.abs().mean().item(), 'sattva_mean': phase.abs().mean().item(), 'magnitude': mag.mean().item()})
        return states

class FlatResBlock(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.linear = nn.Linear(dim, dim)
        self.act = nn.Tanh()

    def forward(self, x):
        return self.act(self.linear(x)) + x

class FlatNet(nn.Module):

    def __init__(self, dim, n_blocks, seq_len=SEQ_LEN):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(seq_len, dim), nn.Tanh())
        self.blocks = nn.ModuleList([FlatResBlock(dim) for _ in range(n_blocks)])
        self.output = nn.Linear(dim, 1)

    def forward(self, x):
        x = self.proj(x)
        for b in self.blocks:
            x = b(x)
        return self.output(x)

def gen_sequences(seq_len=SEQ_LEN, n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(seq_len + 1)]
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < seq_len + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(seq_len + 1)]
            X.append([v / NORM for v in seq[:seq_len]])
            Y.append(seq[seq_len] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(seq_len + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:seq_len]])
                Y.append(seq[seq_len] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(seq_len + 1)]
        X.append([v / NORM for v in seq[:seq_len]])
        Y.append(seq[seq_len] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05
X, Y = gen_sequences()
sp = int(len(X) * 0.8)
X_tr, Y_tr = (X[:sp].to(device), Y[:sp].to(device))
X_te, Y_te = (X[sp:].to(device), Y[sp:].to(device))
print(f'Sequences: {len(X)}')

def train(model, epochs=3000, lr=0.001, label=''):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-07)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    log = []
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            print(f'  NaN ep{ep}')
            break
        opt.zero_grad()
        l.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
        log.append(best)
        if ep % 500 == 0:
            s = score(model)
            print(f'    {label:<24} ep{ep:>5}  loss={best:>12.6f}  score={s}/{len(TESTS)}')
    if best_st:
        model.load_state_dict(best_st)
    return (best, log)

def score(model):
    model.eval()
    c = 0
    with torch.no_grad():
        for seq, tn in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            if abs(model(xt).item() * NORM - tn) / NORM <= TOL:
                c += 1
    return c

def print_sep(t):
    print(f"\n{'=' * 65}\n  {t}\n{'=' * 65}")
EPOCHS = 3000
print_sep('COMPLEX vs FLAT — FAIR COMPARISON')
configs = [('Flat dim=16 blocks=10', FlatNet(16, 10)), ('Flat dim=16 blocks=74', FlatNet(16, 74)), ('Complex dim=8 blocks=10', ComplexNet(8, 10)), ('Complex dim=8 blocks=74', ComplexNet(8, 74)), ('Complex dim=16 blocks=10', ComplexNet(16, 10)), ('Complex dim=16 blocks=74', ComplexNet(16, 74)), ('Complex dim=4 blocks=74', ComplexNet(4, 74))]
results = []
for label, model in configs:
    model = model.to(device)
    params = sum((p.numel() for p in model.parameters()))
    print(f'\n  ── {label} (params={params:,}) ──')
    np.random.seed(42)
    loss, log = train(model, EPOCHS, lr=0.001, label=label[:24])
    s = score(model)
    results.append((label, params, loss, s, model, log))
print_sep('SATTVA ANALYSIS — Three-Guna states inside complex net')
best_complex = min([r for r in results if 'Complex' in r[0]], key=lambda x: x[2])
print(f'\n  Analyzing: {best_complex[0]}')
print(f'  Sampling 5 test sequences...\n')
sample_tests = TESTS[:5]
model_c = best_complex[4]
model_c.eval()
print(f"  {'Layer':>6}  {'Tamas':>10}  {'Rajas':>10}  {'Sattva':>10}  {'Magnitude':>12}  {'Tamas/Rajas':>12}")
print(f"  {'─' * 70}")
with torch.no_grad():
    xt = torch.tensor([[v / NORM for v in sample_tests[0][0]]], dtype=torch.float32).to(device)
    states = model_c.sattva_analysis(xt)
    sample_idx = list(range(0, len(states), max(1, len(states) // 8)))
    for idx in sample_idx:
        st = states[idx]
        ratio = st['tamas_mean'] / (st['rajas_mean'] + 1e-08)
        print(f"  {idx + 1:>6}  {st['tamas_mean']:>10.4f}  {st['rajas_mean']:>10.4f}  {st['sattva_mean']:>10.4f}  {st['magnitude']:>12.4f}  {ratio:>12.4f}")
print_sep('FINAL SCOREBOARD')
results.sort(key=lambda x: (-x[3], x[2]))
print(f"\n  {'Model':<30}  {'Params':>10}  {'Score':>7}  {'Loss':>14}  Type")
print(f"  {'─' * 78}")
for label, params, loss, s, _, _ in results:
    typ = 'COMPLEX' if 'Complex' in label else 'flat'
    mark = ' ← WINNER' if label == results[0][0] else ''
    print(f'  {label:<30}  {params:>10,}  {s:>4}/{len(TESTS)}  {loss:>14.8f}  {typ}{mark}')
print_sep('CONVERGENCE SPEED')
CHECKPTS = [500, 1000, 1500, 2000, 2500, 3000]
short = [(r[0][:18], r[5]) for r in results]
print(f"\n  {'Epoch':>6}", end='')
for label, _ in short:
    print(f'  {label:>18}', end='')
print()
print(f"  {'─' * 130}")
for ep in CHECKPTS:
    print(f'  {ep:>6}', end='')
    for _, log in short:
        v = log[min(ep - 1, len(log) - 1)]
        print(f'  {v:>18.4f}', end='')
    print()
print_sep('WHAT COMPLEX SPACE REVEALS')
best_flat = min([r for r in results if 'Flat' in r[0]], key=lambda x: x[2])
best_complex_r = min([r for r in results if 'Complex' in r[0]], key=lambda x: x[2])
print(f'\n  Best flat:    {best_flat[0]:<30} loss={best_flat[2]:.8f}\n  Best complex: {best_complex_r[0]:<30} loss={best_complex_r[2]:.8f}\n\n  INTERFERENCE (cross terms) analysis:\n    Flat:    y = W @ x          → no cross terms\n    Complex: y_real = Wr@xr - Wi@xi  → cross term: Wi@xi\n             y_imag = Wr@xi + Wi@xr  → cross term: Wi@xr\n    \n    These cross terms = each output holds BOTH inputs simultaneously\n    Real output contains imaginary input influence\n    Imaginary output contains real input influence\n    THIS is genuine multi-state per coordinate.\n\n  Three-Guna balance in trained complex net:\n    Tamas (real)  = ground state\n    Rajas (imag)  = active state\n    Sattva (phase)= relationship = meta-reasoning gate\n\n  If complex wins:\n    The interference = the natural space\n    Real models = forced to be flat\n    Complex models = live in their natural curved space\n    This is the W Principle: natural coordinates → everything linear\n    \n  Next: if complex wins here → test on TinyStories\n  Goal: show small complex model > large flat model on language\n')
