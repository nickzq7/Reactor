import os, time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
_dir = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def banner(text, width=68):
    print(f"\n{'=' * width}")
    print(f'  {text}')
    print(f"{'=' * width}")
D_SMALL = 16
H_SMALL = 2
NL_SMALL = 2
CTX = 64

class TinyModel(nn.Module):

    def __init__(self, vs, d, h, nl, ctx):
        super().__init__()
        self.ctx = ctx
        self.wte = nn.Embedding(vs, d)
        self.wpe = nn.Embedding(ctx, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, h, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(nl)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, ids, labels=None):
        B, K = ids.shape
        pos = torch.arange(K, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        logits = self.ln_f(x) @ self.wte.weight.T
        loss = None
        if labels is not None:
            loss = nn.CrossEntropyLoss()(logits[:, :-1].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
        return type('Out', (), {'logits': logits, 'loss': loss})()

    def generate(self, ids, max_new_tokens=80, repetition_penalty=1.3, **kwargs):
        for _ in range(max_new_tokens):
            inp = ids[:, -self.ctx:]
            out = self(inp)
            logits = out.logits[:, -1, :]
            for token in set(ids[0].tolist()):
                logits[0, token] /= repetition_penalty
            next_tok = logits.argmax(-1, keepdim=True)
            ids = torch.cat([ids, next_tok], dim=1)
            if next_tok.item() == tokenizer.eos_token_id:
                break
        return ids
banner(f'DIRECT COMPRESSION: 8M → 1M   device={device}')
print('  Loading tokenizer + TinyStories-8M (teacher for compression)...')
tokenizer = AutoTokenizer.from_pretrained('roneneldan/TinyStories-8M')
tokenizer.pad_token = tokenizer.eos_token
model_8m = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-8M', use_safetensors=True).to(device).eval()
VS = model_8m.config.vocab_size
model_1m = TinyModel(VS, D_SMALL, H_SMALL, NL_SMALL, CTX).to(device)
p_8m = sum((p.numel() for p in model_8m.parameters()))
p_1m = sum((p.numel() for p in model_1m.parameters()))
print(f'\n  Teacher  8M  : D={model_8m.config.hidden_size}   params={p_8m:>12,}')
print(f'  Student  1M  : D={D_SMALL}    params={p_1m:>12,}')
print(f'  Compression  : {p_8m / p_1m:.1f}x smaller')
print(f'  Vocab size   : {VS:,}')
PROMPTS = ['Once upon a time, there was a little girl named Lily.', 'Tom was a small boy who loved to play with his dog.', 'One day, a bunny found a big carrot in the garden.', 'The sun was shining and the birds were singing.', 'A little bear lived in a cozy cave in the forest.', 'The children ran to the playground and', 'Max saw a butterfly and decided to', 'It was raining outside so Anna decided to', 'The puppy was lost and started to', 'Sam found a shiny coin and', 'Lily was very sad because she', 'Ben was so happy when he', 'The little dragon was scared of', 'Emma felt proud when she', 'Jake was angry because his friend', 'There was a magic tree that could', 'The friendly robot learned how to', 'Deep in the ocean, a fish discovered', 'The baby elephant wanted to learn', 'One night, the stars started to', 'Once there was a kind old man who lived alone. Every day he fed the birds. One morning he woke up and', 'Lucy had a red balloon. She loved it very much. One day the wind blew it away and', 'The three little pigs built their houses. The wolf came and blew them down but']

def generate_hf(model, prompt, max_new=80):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, do_sample=False, repetition_penalty=1.3, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def generate_tiny(model, prompt, max_new=80):
    model.eval()
    ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)
    with torch.no_grad():
        out = model.generate(ids, max_new_tokens=max_new, repetition_penalty=1.3)
    return tokenizer.decode(out[0], skip_special_tokens=True)

def quality(prompt, output):
    gen = output[len(prompt):]
    words = gen.split()
    uniq = len(set((w.lower() for w in words)))
    n = max(len(words), 1)
    score = round(uniq / n * 0.4 + min(n, 80) / 80 * 0.4 + output.rstrip().endswith(('.', '!', '?')) * 0.2, 3)
    return score

def run_all(model, label, gen_fn):
    banner(label)
    total = 0
    results = []
    for i, prompt in enumerate(PROMPTS):
        out = gen_fn(model, prompt)
        q = quality(prompt, out)
        total += q
        results.append((prompt, out, q))
        gen_text = out[len(prompt):].strip().replace('\n', ' ')
        bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
        print(f'  [{i + 1:>2}] {bar} Q={q:.2f}  "{prompt[:42]}..."')
        print(f'       → {gen_text[:100]}')
    avg = total / len(PROMPTS)
    print(f'\n  Average quality: {avg:.3f}/1.0')
    return (results, avg)

def v16_compress(wte_big, d_small, k=3):
    rng = np.random.RandomState(42)
    wte_rand = rng.randn(wte_big.shape[0], d_small) * 0.02
    P = np.linalg.lstsq(wte_big, wte_rand, rcond=None)[0]
    wte_proj = wte_big @ P
    wte_blend = 0.5 * wte_rand + 0.5 * wte_proj
    agree_d = np.sum(wte_rand * wte_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    wte_child = wte_blend.copy()
    wte_child[:, flip_dims] *= -1
    print(f'  Agreement range : {agree_d.min():.2f} → {agree_d.max():.2f}')
    print(f'  Flipped dims    : {flip_dims.tolist()}')
    return wte_child

class StoryDataset(Dataset):

    def __init__(self, texts, tok, maxlen=64):
        self.data = []
        for t in texts:
            enc = tok(t, truncation=True, max_length=maxlen, return_tensors='pt', padding='max_length')
            self.data.append(enc.input_ids[0])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]
results_8m, q_8m = run_all(model_8m, 'TEACHER — TinyStories-8M', generate_hf)
results_before, q_before = run_all(model_1m, 'STUDENT BEFORE — Fresh 1M (random weights)', generate_tiny)
banner('APPLYING V16 COMPRESSION  (8M → 1M)')
WTE_8m = model_8m.transformer.wte.weight.detach().cpu().numpy().astype(np.float64)
print(f'  8M WTE shape : {WTE_8m.shape}')
print(f'  1M WTE shape : ({VS}, {D_SMALL})\n')
WTE_compressed = v16_compress(WTE_8m, D_SMALL, k=3)
with torch.no_grad():
    model_1m.wte.weight.copy_(torch.tensor(WTE_compressed, dtype=torch.float32).to(device))
print('\n  ✓ 8M WTE geometry compressed and injected into 1M model.')
banner('FINE-TUNING 1M MODEL  (8 epochs, WTE frozen)')
print('  WTE frozen. FFN + attention adapt to compressed geometry.\n')
model_1m.wte.weight.requires_grad_(False)
print('  Loading training data...')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
texts = []
for item in ds:
    texts.append(item['text'])
    if len(texts) >= 3000:
        break
print(f'  Loaded {len(texts)} stories.\n')
dataset = StoryDataset(texts, tokenizer, maxlen=CTX)
loader = DataLoader(dataset, batch_size=4, shuffle=True)
opt = torch.optim.AdamW([p for p in model_1m.parameters() if p.requires_grad], lr=0.0003)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=8, eta_min=1e-05)
WATCH = 'Once upon a time, there was a little bear who'
print(f'  Watching: "{WATCH}"\n')
print(f"  {'Epoch':>6}  {'Loss':>8}  {'Q':>6}  Output")
print(f"  {'─' * 65}")
epoch_log = []
for epoch in range(1, 9):
    model_1m.train()
    total = 0
    steps = 0
    for batch in loader:
        batch = batch.to(device)
        out = model_1m(batch, labels=batch)
        opt.zero_grad()
        out.loss.backward()
        nn.utils.clip_grad_norm_(model_1m.parameters(), 1.0)
        opt.step()
        total += out.loss.item()
        steps += 1
    sched.step()
    avg_loss = total / steps
    watch_out = generate_tiny(model_1m, WATCH, max_new=50)
    q = quality(WATCH, watch_out)
    gen_text = watch_out[len(WATCH):].strip().replace('\n', ' ')
    bar = '█' * int(q * 10) + '░' * (10 - int(q * 10))
    print(f'  Epoch {epoch:>2}/8  {avg_loss:>8.4f}  {q:>6.2f}  {bar}')
    print(f'           → {gen_text[:85]}\n')
    epoch_log.append((epoch, avg_loss, q))
print('  ✓ Fine-tuning complete.')
results_after, q_after = run_all(model_1m, 'STUDENT AFTER — 1M (V16 compressed + fine-tuned)', generate_tiny)
banner('FINAL COMPARISON')
print(f"  {'Model':>35}  {'Params':>12}  {'Quality':>8}  {'vs Before':>10}")
print(f"  {'─' * 68}")
print(f"  {'Teacher  8M':>35}  {p_8m:>12,}  {q_8m:>8.3f}  {'(reference)':>10}")
print(f"  {'Student 1M  BEFORE (random)':>35}  {p_1m:>12,}  {q_before:>8.3f}  {'baseline':>10}")
print(f"  {'Student 1M  AFTER  (V16)':>35}  {p_1m:>12,}  {q_after:>8.3f}  {q_after - q_before:>+10.3f}")
print(f'\n  Compression : {p_8m:,} → {p_1m:,} params  ({p_8m / p_1m:.1f}x smaller)')
print(f'  Quality gap : Teacher={q_8m:.3f}  After={q_after:.3f}  diff={q_after - q_8m:+.3f}')
print(f'\n  Learning curve:')
print(f"  {'Epoch':>6}  {'Loss':>8}  {'Q':>6}  Bar")
print(f"  {'─' * 45}")
for ep, loss, q in epoch_log:
    print(f"  {ep:>6}  {loss:>8.4f}  {q:>6.2f}  {'█' * int(q * 20)}")
print(f'\n  SIDE BY SIDE — 5 prompts:')
print(f"  {'─' * 68}")
for i in range(5):
    p = PROMPTS[i]
    t = results_8m[i][1][len(p):].strip().replace('\n', ' ')[:85]
    bef = results_before[i][1][len(p):].strip().replace('\n', ' ')[:85]
    aft = results_after[i][1][len(p):].strip().replace('\n', ' ')[:85]
    print(f'\n  Prompt : {p}')
    print(f'  8M     : {t}')
    print(f'  Before : {bef}')
    print(f'  After  : {aft}')
save_path = os.path.join(_dir, 'tinystories_1m_compressed')
os.makedirs(save_path, exist_ok=True)
torch.save(model_1m.state_dict(), os.path.join(save_path, 'model.pt'))
tokenizer.save_pretrained(save_path)
print(f'\n\n  ✓ Saved to: {save_path}')
banner('DONE')
