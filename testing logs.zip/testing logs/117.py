import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
VS = 31
K = 6
D = 16
H = 2
NL = 2
D_TINY = 8
DONOR_STEPS = 1200
LR_DONOR = 0.005
CHILD_STEPS = 3000
LR_CHILD = 0.003
N_DONORS = 8
torch.manual_seed(42)
np.random.seed(42)
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_primes(n):
    ps = []
    k = 2
    while len(ps) < n:
        if all((k % p != 0 for p in ps)):
            ps.append(k)
        k += 1
    return [p % VS for p in ps]

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s

def make_patterns():
    pats = {}
    for step in range(1, 9):
        pats[f'a{step}'] = ([i * step % VS for i in range(20)], 20 * step % VS)
    for step in range(9, 17):
        pats[f'a{step}'] = ([i * step % VS for i in range(20)], 20 * step % VS)
    for step in range(17, 25):
        pats[f'a{step}'] = ([i * step % VS for i in range(20)], 20 * step % VS)
    for start in range(25, 33):
        seq = [(start - i) % VS for i in range(20)]
        pats[f'd{start}'] = (seq, (start - 20) % VS)
    fib = gen_fib(40)
    for off in range(8):
        s = fib[off:off + 20]
        pats[f'f{off}'] = (s, fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
    for r in [2, 3, 4, 5, 6, 7, 8, 9]:
        seq = [r ** i % VS for i in range(20)]
        pats[f'g{r}'] = (seq, r ** 20 % VS)
    for c in range(8):
        seq = [(i + c) ** 2 % VS for i in range(20)]
        pats[f'sq{c}'] = (seq, (20 + c) ** 2 % VS)
    for step in [3, 5]:
        for off in range(4):
            seq = [(i * step + off) % VS for i in range(20)]
            pats[f's{step}o{off}'] = (seq, (20 * step + off) % VS)
    return pats
ALL_PATS = make_patterns()
pat_names = list(ALL_PATS.keys())
DONOR_PATS = [pat_names[i * 8:(i + 1) * 8] for i in range(N_DONORS)]

def build_tensors_from_pats(pnames):
    Xs = []
    ys = []
    for pn in pnames:
        seq, _ = ALL_PATS[pn]
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            ys.append(seq[i + 1:i + K + 1])
    if not Xs:
        return (None, None)
    return (torch.tensor(Xs, dtype=torch.long, device=device), torch.tensor(ys, dtype=torch.long, device=device))
ALL_X, ALL_Y = build_tensors_from_pats(pat_names)

def eval_pats(model_or_ww, pnames, use_np=False):
    correct = 0
    results = []
    for pn in pnames:
        seq, truth = ALL_PATS[pn]
        inp = seq[-K:]
        if use_np:
            logits = fwd_np(inp, model_or_ww)
            p = int(np.argmax(logits[-1]))
        else:
            model_or_ww.eval()
            ids = torch.tensor([inp], dtype=torch.long, device=device)
            with torch.no_grad():
                p = int(model_or_ww(ids)[0, -1].argmax())
        ok = p == truth
        correct += ok
        results.append(ok)
    return (correct, results)

class SeqT(nn.Module):

    def __init__(self, d=D):
        super().__init__()
        self.d = d
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, H, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def get_wte(model):
    return model.wte.weight.detach().numpy().astype(np.float64)

def set_wte(model, wte_np):
    with torch.no_grad():
        model.wte.weight.copy_(torch.tensor(wte_np, dtype=torch.float32))

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]

def ln_np(x, g, b, eps=1e-05):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_np(x):
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def model_to_npz(model):
    W = {}
    W['WTE'] = get_wte(model)
    W['WPE'] = model.wpe.weight.detach().numpy().astype(np.float64)
    for l in range(NL):
        ip = model.layers[l]['attn'].in_proj_weight.detach().numpy().astype(np.float64)
        d = model.d
        W[f'WQ{l}'] = ip[:d]
        W[f'WK{l}'] = ip[d:2 * d]
        W[f'WV{l}'] = ip[2 * d:]
        W[f'WO{l}'] = model.layers[l]['attn'].out_proj.weight.detach().numpy().astype(np.float64)
        W[f'W1{l}'] = model.layers[l]['ff'][0].weight.detach().numpy().astype(np.float64)
        W[f'b1{l}'] = model.layers[l]['ff'][0].bias.detach().numpy().astype(np.float64)
        W[f'W2{l}'] = model.layers[l]['ff'][2].weight.detach().numpy().astype(np.float64)
        W[f'b2{l}'] = model.layers[l]['ff'][2].bias.detach().numpy().astype(np.float64)
        W[f'LN1g{l}'] = model.layers[l]['ln1'].weight.detach().numpy().astype(np.float64)
        W[f'LN1b{l}'] = model.layers[l]['ln1'].bias.detach().numpy().astype(np.float64)
        W[f'LN2g{l}'] = model.layers[l]['ln2'].weight.detach().numpy().astype(np.float64)
        W[f'LN2b{l}'] = model.layers[l]['ln2'].bias.detach().numpy().astype(np.float64)
    W['LNfg'] = model.ln_f.weight.detach().numpy().astype(np.float64)
    W['LNfb'] = model.ln_f.bias.detach().numpy().astype(np.float64)
    return W

def fwd_np(ids, Ww):
    seq = np.array(ids)
    slen = len(seq)
    d = Ww['WTE'].shape[1]
    x = Ww['WTE'][seq] + Ww['WPE'][np.arange(slen)]
    for l in range(NL):
        mk = np.triu(np.full((slen, slen), -1000000000.0), k=1)
        ln1 = ln_np(x, Ww[f'LN1g{l}'], Ww[f'LN1b{l}'])
        Q = ln1 @ Ww[f'WQ{l}'].T
        Kk = ln1 @ Ww[f'WK{l}'].T
        V = ln1 @ Ww[f'WV{l}'].T
        hd = d // H
        Qh = Q.reshape(slen, H, hd).transpose(1, 0, 2)
        Kh = Kk.reshape(slen, H, hd).transpose(1, 0, 2)
        Vh = V.reshape(slen, H, hd).transpose(1, 0, 2)
        ctx = np.stack([softmax_np(Qh[h] @ Kh[h].T + mk) @ Vh[h] for h in range(H)], 1).reshape(slen, -1)
        att = ctx @ Ww[f'WO{l}'].T
        hm = x + att
        ln2 = ln_np(hm, Ww[f'LN2g{l}'], Ww[f'LN2b{l}'])
        g = gelu_np(ln2 @ Ww[f'W1{l}'].T + Ww[f'b1{l}'])
        x = hm + g @ Ww[f'W2{l}'].T + Ww[f'b2{l}']
    return ln_np(x, Ww['LNfg'], Ww['LNfb']) @ Ww['WTE'].T

def train_model(model, X, Y, steps, lr, label='', print_every=200):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=5e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(X).view(-1, VS), Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, _ = eval_pats(model, pat_names)
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            if label:
                print(f'    {label} step {step:>5}: {sc}/64', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    sc, _ = eval_pats(model, pat_names)
    return sc

def v16_apply(WTE_A, WTE_B, k=6, alpha=0.5):
    if WTE_B.shape[1] != WTE_A.shape[1]:
        P = solve(WTE_B, WTE_A)
        WTE_B_proj = WTE_B @ P
    else:
        P = solve(WTE_B, WTE_A)
        WTE_B_proj = WTE_B @ P
    WTE_h = alpha * WTE_A + (1 - alpha) * WTE_B_proj
    agree_d = np.sum(WTE_A * WTE_B_proj, axis=0)
    flip_dims = np.argsort(agree_d)[-k:]
    WTE_h[:, flip_dims] *= -1
    return (WTE_h, flip_dims, agree_d)
print('=' * 60)
print('  PHASE 1 — TRAINING 8 DONORS')
print('=' * 60)
t0 = time.time()
donors = []
for di in range(N_DONORS):
    torch.manual_seed(di * 100 + 7)
    np.random.seed(di * 100 + 7)
    m = SeqT(D).to(device)
    X, Y = build_tensors_from_pats(DONOR_PATS[di])
    opt = torch.optim.Adam(m.parameters(), lr=LR_DONOR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=DONOR_STEPS, eta_min=0.0001)
    best_s = 0
    best_state = None
    for step in range(1, DONOR_STEPS + 1):
        m.train()
        opt.zero_grad()
        loss = loss_fn(m(X).view(-1, VS), Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        sched.step()
    sc, _ = eval_pats(m, DONOR_PATS[di])
    donors.append(m)
    print(f'  Donor {di + 1}/8  {sc}/8  pats={DONOR_PATS[di][:3]}...', flush=True)
print(f'\n  Phase 1 done in {time.time() - t0:.1f}s')
print('\n' + '=' * 60)
print('  PHASE 2A — ITERATIVE V16 (pairwise, exact formula)')
print('  child ← V16(child, donor_0)')
print('  child ← V16(child, donor_1)')
print('  ... through all 8 donors')
print('  Then train child from scratch on all 64 patterns')
print('=' * 60)
torch.manual_seed(999)
np.random.seed(999)
child = SeqT(D).to(device)
WTE_child = get_wte(child).copy()
print('\n  Applying V16 iteratively...')
print(f"  {'Step':>6}  {'Donor':>8}  {'flip_dims':>25}  agree_range")
all_flip_dims = []
for di, donor in enumerate(donors):
    WTE_donor = get_wte(donor)
    WTE_child, flip_dims, agree_d = v16_apply(WTE_child, WTE_donor, k=6, alpha=0.5)
    all_flip_dims.append(flip_dims.tolist())
    print(f'  {di + 1:>6}  donor_{di + 1:>2}  {flip_dims.tolist()!s:>25}  [{agree_d.min():.2f}, {agree_d.max():.2f}]', flush=True)
print(f'\n  Final child WTE shape: {WTE_child.shape}')
print(f'  Norm: {np.linalg.norm(WTE_child):.3f}')
print('\n  Training child A (iterative V16 init) on all 64 patterns...')
childA = SeqT(D).to(device)
set_wte(childA, WTE_child)
scores_A = []
opt = torch.optim.Adam(childA.parameters(), lr=LR_CHILD)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CHILD_STEPS, eta_min=5e-05)
best_s = 0
best_state = None
for step in range(1, CHILD_STEPS + 1):
    childA.train()
    opt.zero_grad()
    loss = loss_fn(childA(ALL_X).view(-1, VS), ALL_Y.view(-1))
    loss.backward()
    nn.utils.clip_grad_norm_(childA.parameters(), 1.0)
    opt.step()
    sched.step()
    if step % 200 == 0:
        sc, res = eval_pats(childA, pat_names)
        per_donor = [sum(res[i * 8:(i + 1) * 8]) for i in range(N_DONORS)]
        if sc > best_s:
            best_s = sc
            best_state = {k: v.clone() for k, v in childA.state_dict().items()}
        scores_A.append(sc)
        print(f'  step {step:>5}: {sc:>2}/64  {per_donor}', flush=True)
if best_state:
    childA.load_state_dict(best_state)
final_A, res_A = eval_pats(childA, pat_names)
print('\n' + '=' * 60)
print('  PHASE 2B — SINGLE V16 (mean donor WTE as compass)')
print('  WTE_B = mean(all 8 donor WTEs)')
print('  Apply V16 once')
print('=' * 60)
WTE_mean_donor = np.mean([get_wte(d) for d in donors], axis=0)
torch.manual_seed(999)
np.random.seed(999)
WTE_rand = SeqT(D).to(device)
WTE_A_init = get_wte(WTE_rand).copy()
WTE_b_child, flip_dims_b, agree_b = v16_apply(WTE_A_init, WTE_mean_donor, k=6, alpha=0.5)
print(f'\n  flip_dims: {flip_dims_b.tolist()}')
print(f'  agree range: [{agree_b.min():.3f}, {agree_b.max():.3f}]')
print(f'  All positive: {np.all(agree_b > 0)} → collinear parents → flip highest ✓')
print('\n  Training child B (mean-donor V16 init) on all 64 patterns...')
childB = SeqT(D).to(device)
set_wte(childB, WTE_b_child)
opt = torch.optim.Adam(childB.parameters(), lr=LR_CHILD)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CHILD_STEPS, eta_min=5e-05)
best_s = 0
best_state = None
for step in range(1, CHILD_STEPS + 1):
    childB.train()
    opt.zero_grad()
    loss = loss_fn(childB(ALL_X).view(-1, VS), ALL_Y.view(-1))
    loss.backward()
    nn.utils.clip_grad_norm_(childB.parameters(), 1.0)
    opt.step()
    sched.step()
    if step % 200 == 0:
        sc, res = eval_pats(childB, pat_names)
        per_donor = [sum(res[i * 8:(i + 1) * 8]) for i in range(N_DONORS)]
        if sc > best_s:
            best_s = sc
            best_state = {k: v.clone() for k, v in childB.state_dict().items()}
        print(f'  step {step:>5}: {sc:>2}/64  {per_donor}', flush=True)
if best_state:
    childB.load_state_dict(best_state)
final_B, res_B = eval_pats(childB, pat_names)
print('\n' + '=' * 60)
print('  PHASE 2C — BASELINE (random init, no V16)')
print('=' * 60)
torch.manual_seed(999)
np.random.seed(999)
childC = SeqT(D).to(device)
opt = torch.optim.Adam(childC.parameters(), lr=LR_CHILD)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CHILD_STEPS, eta_min=5e-05)
best_s = 0
best_state = None
for step in range(1, CHILD_STEPS + 1):
    childC.train()
    opt.zero_grad()
    loss = loss_fn(childC(ALL_X).view(-1, VS), ALL_Y.view(-1))
    loss.backward()
    nn.utils.clip_grad_norm_(childC.parameters(), 1.0)
    opt.step()
    sched.step()
    if step % 200 == 0:
        sc, res = eval_pats(childC, pat_names)
        per_donor = [sum(res[i * 8:(i + 1) * 8]) for i in range(N_DONORS)]
        if sc > best_s:
            best_s = sc
            best_state = {k: v.clone() for k, v in childC.state_dict().items()}
        print(f'  step {step:>5}: {sc:>2}/64  {per_donor}', flush=True)
if best_state:
    childC.load_state_dict(best_state)
final_C, res_C = eval_pats(childC, pat_names)
print('\n' + '=' * 60)
print('  FINAL RESULTS')
print('=' * 60)
for label, sc, res in [('Child A (iter V16)', final_A, res_A), ('Child B (mean V16)', final_B, res_B), ('Child C (baseline)', final_C, res_C)]:
    print(f'\n  {label}: {sc}/64')
    for di in range(N_DONORS):
        r = res[di * 8:(di + 1) * 8]
        bar = ''.join(('█' if x else '░' for x in r))
        print(f'    Donor {di + 1}  {bar}  {sum(r)}/8')
print(f"\n  V16 FORMULA USED:\n    P       = solve(WTE_B, WTE_A)\n    WTE_h   = 0.5*WTE_A + 0.5*WTE_B@P\n    agree_d = sum(WTE_A * WTE_B@P, axis=0)\n    flip top-6 dims by HIGHEST agree_d\n    train child from scratch on all patterns\n\n  KEY LAW (Finding 39):\n    When parents are collinear (all agree_d > 0):\n    flip HIGHEST agreement dims → maximum orthogonality\n    B = compass only, B's content irrelevant, only flip dims matter\n")
print('=' * 60)
