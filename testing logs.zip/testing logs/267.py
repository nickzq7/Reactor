import numpy as np
import torch
import math
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL v6 — SEQUENTIAL NATURAL SPACES')
print('  ATT and FFN measured separately. Correctly.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
D = model.config.hidden_size
head_dim = D // n_heads

def r2(A, Y):
    A = np.array(A, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    Ab = np.hstack([A, np.ones((len(A), 1))])
    W, _, _, _ = np.linalg.lstsq(Ab, Y, rcond=None)
    Yp = Ab @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0

def fmt(v):
    if v > 0.9999:
        return f'{v:.6f} ✓ EXACT'
    if v > 0.999:
        return f'{v:.6f} ~'
    if v > 0.99:
        return f'{v:.6f} !'
    return f'{v:.6f} ✗'

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_np(x):
    x = x.astype(np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)
PROMPTS = ['Once upon a time a little girl named Lily', 'Deep in the forest there lived a dragon', 'A small dog ran across the green field', 'The brave knight rode into the dark cave', 'She opened the door and smiled at her friend', 'Every morning the birds sang in the tall tree', 'He found a golden key under the old bridge', 'The children played and laughed in the garden', 'Far away there lived a kind old wizard', 'A tiny mouse found some cheese in the barn', 'The princess wore a crown and sat on the throne', 'A rainbow appeared in the sky after the rain', 'The farmer planted seeds in the rich dark soil', 'She read a book about dragons and magic spells', 'The river flowed gently through the green valley', 'A butterfly landed softly on the red flower', 'The ship sailed across the deep blue ocean', 'The moon rose high above the sleeping town', 'A bear found honey in a hollow tree trunk', 'The wind carried the leaves high into the air', 'Once there was a boy who loved to explore', 'The cat sat by the warm fire and purred', 'He climbed the tall mountain and saw the sky', 'She sang a song that made everyone smile', 'A fox ran through the forest looking for food', 'The old man told stories to the young children', 'A baby bird fell from its nest in the oak', 'The cook made a soup that smelled wonderful', 'He drew a picture of his house and garden', 'The queen walked through the market with grace', 'Once a young prince found a magic mirror', 'The stars shone bright above the sleeping child', 'A little fish swam in the clear blue pond', 'The baker made fresh bread every single morning', 'She found a map that led to buried treasure', 'The little rabbit hopped through the meadow', 'Once a young boy found a magic stone', 'The old lighthouse stood by the stormy sea', 'A girl named Emma loved to paint pictures', 'The dragon breathed fire and the village ran', 'A kind witch lived in the old apple orchard', 'The tiny boat sailed far across the great lake', 'He whispered a secret into the old oak tree', 'The clever fox outsmarted the hungry wolf again', 'A magic carpet flew high above the golden city', 'The snow fell softly on the sleeping village', 'She found a door hidden behind the waterfall', 'The little prince asked why the stars were bright', 'A dragon egg hatched under the full blue moon', 'The shepherd counted stars until he fell asleep', 'The old clock ticked slowly in the quiet room', 'A young girl learned to fly on a broomstick', 'The river whispered secrets to the listening stones', 'He opened the treasure chest and found a map', 'The wolf howled at the moon above the hills', 'She planted a seed and a great tree grew', 'The knight bowed before the wise old queen', "A tiny star fell gently into the child's hand", 'The baker smiled and gave the boy fresh bread', 'Deep underground a city of gnomes was hidden', 'The little owl asked who had taken the moon', 'A princess danced alone in the empty tower', 'The giant sat down and the earth shook gently', 'He found a bottle with a message inside it', 'The fairy left a gift under the sleeping child', 'A wolf pup howled for the first time at dawn', 'The wizard opened his eyes and saw the future', 'She whispered to the river and it changed course', 'A golden bird sang and the flowers all bloomed', 'The boy asked the star how far away it was', 'Deep in the cave the treasure chest glowed bright']
SEQ_LEN = 8
N_STEPS = 55
print(f'\n  Collecting data... SEQ_LEN={SEQ_LEN}')
layer_data = {li: {'h_seq': [], 'delta_att': [], 'delta_ffn': [], 'h_ln1': [], 'h_ln2': [], 'context': []} for li in range(n_layers)}
wte = model.transformer.wte.weight.detach().numpy()
wpe = model.transformer.wpe.weight.detach().numpy()
with torch.no_grad():
    for prompt in PROMPTS:
        ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
        while len(ids) < SEQ_LEN:
            out = model(torch.tensor([ids]))
            ids.append(torch.argmax(out.logits[0, -1, :]).item())
        ids = ids[:SEQ_LEN]
        for step in range(N_STEPS):
            ids_use = ids[-SEQ_LEN:]
            T = SEQ_LEN
            x = (wte[ids_use] + wpe[np.arange(T)]).copy()
            for li in range(n_layers):
                blk = model.transformer.h[li]
                ln1_w = blk.ln_1.weight.detach().numpy()
                ln1_b = blk.ln_1.bias.detach().numpy()
                ln2_w = blk.ln_2.weight.detach().numpy()
                ln2_b = blk.ln_2.bias.detach().numpy()
                att = blk.attn.attention
                Wq = att.q_proj.weight.detach().numpy()
                Wk = att.k_proj.weight.detach().numpy()
                Wv = att.v_proj.weight.detach().numpy()
                Wo = att.out_proj.weight.detach().numpy()
                bo = att.out_proj.bias.detach().numpy()
                W1 = blk.mlp.c_fc.weight.detach().numpy()
                b1 = blk.mlp.c_fc.bias.detach().numpy()
                W2 = blk.mlp.c_proj.weight.detach().numpy()
                b2 = blk.mlp.c_proj.bias.detach().numpy()
                h_before_att = x.copy()
                ln1 = np.array([ln_np(x[i:i + 1], ln1_w, ln1_b)[0] for i in range(T)])
                Q = ln1 @ Wq.T
                K = ln1 @ Wk.T
                V = ln1 @ Wv.T
                Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                mask = np.triu(np.full((T, T), float('-inf')), 1)
                probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
                heads = [probs[h] @ Vh[h] for h in range(n_heads)]
                context = np.stack(heads, 1).reshape(T, D)
                att_out = context @ Wo.T + bo
                x_after_att = x + att_out
                delta_att_last = att_out[-1]
                ln2 = ln_np(x_after_att[-1:], ln2_w, ln2_b)[0]
                pre = ln2 @ W1.T + b1
                act = gelu_np(pre)
                ffn_out = act @ W2.T + b2
                x_after_ffn = x_after_att.copy()
                x_after_ffn[-1] = x_after_att[-1] + ffn_out
                delta_ffn_last = ffn_out
                layer_data[li]['h_seq'].append(h_before_att.copy())
                layer_data[li]['delta_att'].append(delta_att_last)
                layer_data[li]['delta_ffn'].append(delta_ffn_last)
                layer_data[li]['h_ln1'].append(ln1.copy())
                layer_data[li]['h_ln2'].append(ln2.copy())
                layer_data[li]['context'].append(context[-1].copy())
                x = x_after_ffn
            out2 = model(torch.tensor([ids_use]))
            ids.append(torch.argmax(out2.logits[0, -1, :]).item())
N = len(layer_data[0]['h_seq'])
print(f'  N={N} sequences\n')
for li in range(n_layers):
    for k in layer_data[li]:
        layer_data[li][k] = np.array(layer_data[li][k], dtype=np.float64)
print(f"{'=' * 70}")
print(f'  TEST 1: ATT DELTA — NATURAL SPACE')
print(f"  What predicts delta_att (attention's contribution)?")
print(f'  Input options: h_last, h_seq, (h_seq, h_seq²), h_ln1_seq')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'h_last':>10} {'h_seq':>10} {'h_ln1_seq':>12} {'(ln1,ln1²)':>12}")
print(f"  {'─' * 56}")
for li in range(n_layers):
    h_last = layer_data[li]['h_seq'][:, -1, :]
    h_seq = layer_data[li]['h_seq'].reshape(N, SEQ_LEN * D)
    h_ln1_seq = layer_data[li]['h_ln1'].reshape(N, SEQ_LEN * D)
    delta_att = layer_data[li]['delta_att']
    r2_hlast = r2(h_last, delta_att)
    r2_hseq = r2(h_seq, delta_att)
    r2_ln1seq = r2(h_ln1_seq, delta_att)
    r2_ln1para = r2(np.hstack([h_ln1_seq, h_ln1_seq ** 2]), delta_att)
    print(f'  L{li:<7} {fmt(r2_hlast):>10} {fmt(r2_hseq):>10} {fmt(r2_ln1seq):>12} {fmt(r2_ln1para):>12}')
print(f"\n{'=' * 70}")
print(f'  TEST 2: FFN DELTA — NATURAL SPACE')
print(f"  What predicts delta_ffn (FFN's contribution)?")
print(f'  FFN acts on single token only. Should be easier.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'h_last':>10} {'(h,h²)':>10} {'ln2':>12} {'(ln2,ln2²)':>12}")
print(f"  {'─' * 56}")
for li in range(n_layers):
    h_last = layer_data[li]['h_seq'][:, -1, :]
    h_ln2 = layer_data[li]['h_ln2']
    delta_ffn = layer_data[li]['delta_ffn']
    r2_hlast = r2(h_last, delta_ffn)
    r2_hpara = r2(np.hstack([h_last, h_last ** 2]), delta_ffn)
    r2_ln2 = r2(h_ln2, delta_ffn)
    r2_ln2para = r2(np.hstack([h_ln2, h_ln2 ** 2]), delta_ffn)
    print(f'  L{li:<7} {fmt(r2_hlast):>10} {fmt(r2_hpara):>10} {fmt(r2_ln2):>12} {fmt(r2_ln2para):>12}')
print(f"\n{'=' * 70}")
print(f'  TEST 3: COMBINED — ATT + FFN SEQUENTIAL')
print(f'  Using best natural space for each:')
print(f'    ATT: (ln1_seq, ln1_seq²)')
print(f'    FFN: (ln2, ln2²)')
print(f'  Predict: delta_att + delta_ffn = full layer contribution')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'att_r2':>10} {'ffn_r2':>10} {'combined_r2':>14} {'verdict'}")
print(f"  {'─' * 56}")
for li in range(n_layers):
    h_ln1_seq = layer_data[li]['h_ln1'].reshape(N, SEQ_LEN * D)
    h_ln2 = layer_data[li]['h_ln2']
    delta_att = layer_data[li]['delta_att']
    delta_ffn = layer_data[li]['delta_ffn']
    delta_tot = delta_att + delta_ffn
    Phi_att = np.hstack([h_ln1_seq, h_ln1_seq ** 2, np.ones((N, 1))])
    W_att, _, _, _ = np.linalg.lstsq(Phi_att, delta_att, rcond=None)
    pred_att = Phi_att @ W_att
    Phi_ffn = np.hstack([h_ln2, h_ln2 ** 2, np.ones((N, 1))])
    W_ffn, _, _, _ = np.linalg.lstsq(Phi_ffn, delta_ffn, rcond=None)
    pred_ffn = Phi_ffn @ W_ffn

    def r2_direct(pred, true):
        ss_res = np.sum((true - pred) ** 2)
        ss_tot = np.sum((true - true.mean(0)) ** 2)
        return float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0
    r2_att = r2_direct(pred_att, delta_att)
    r2_ffn = r2_direct(pred_ffn, delta_ffn)
    pred_tot = pred_att + pred_ffn
    r2_comb = r2_direct(pred_tot, delta_tot)
    v = '✓ EXACT' if r2_comb > 0.9999 else '~' if r2_comb > 0.999 else '!' if r2_comb > 0.99 else '✗'
    print(f'  L{li:<7} {fmt(r2_att):>10} {fmt(r2_ffn):>10} {r2_comb:.6f}         {v}')
print(f"\n{'=' * 70}")
print(f'  TEST 4: WHAT IS GEMINI ACTUALLY MEASURING?')
print(f'  Gemini: out_proj_input → out_proj_output')
print(f'  This = does a linear layer map its own input to output?')
print(f'  Answer: always yes. Trivially. Not a natural space test.')
print(f"{'=' * 70}\n")
li = 0
blk = model.transformer.h[li]
att = blk.attn.attention
Wo = att.out_proj.weight.detach().numpy()
bo = att.out_proj.bias.detach().numpy()
context_in = layer_data[li]['context']
delta_trivial = context_in @ Wo.T + bo
r2_trivial = r2(context_in, delta_trivial)
print(f'  Gemini measurement (layer 0):')
print(f'    context → (context @ Wo.T + bo): R²={fmt(r2_trivial)}')
print(f'    This equals: R²=1.000000 because it IS the weight matrix.')
print(f'    Not a discovery. A tautology.')
print()
r2_real = r2(layer_data[li]['h_seq'][:, -1, :], layer_data[li]['delta_att'])
print(f'  Our measurement (layer 0):')
print(f'    h_last → delta_att: R²={fmt(r2_real)}')
print(f'    This is the REAL question: can input predict contribution?')
print(f"\n{'=' * 70}")
print(f'  FINAL SUMMARY')
print(f"{'=' * 70}\n")
print(f'\n  GEMINI:\n    Measured: linear_layer_input → linear_layer_output\n    R² = 1.000000 always. Trivially. Every linear layer.\n    Not O(1) training. Not natural space discovery.\n    Tautology: W@x = Wx. Always true.\n\n  MANISH PRINCIPLE (our measurement):\n    Measured: h_in → delta_att  (real prediction)\n              h_in → delta_ffn  (real prediction)\n    Best space found:\n      ATT: (ln1_seq, ln1_seq²) → R² above\n      FFN: (ln2, ln2²)         → R² above\n    \n    If R² = 1.000000 for both:\n      W-Kernel = complete.\n      Train any transformer in one step.\n      No gradient descent. Exact weights.\n      \n    This is the real proof.\n    Not a tautology. A discovery.\n')
print('=' * 70 + '\n')
