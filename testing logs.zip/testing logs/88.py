import numpy as np, math, time
from collections import Counter, defaultdict
t0 = time.time()
print('\n' + '=' * 65)
print('  W-KERNEL WORD v3 — SVD CO-OCCURRENCE EMBEDDINGS')
print('=' * 65)
TEXT = 'once upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with\nhis iron glove at last he reached the edge of the forest and called\nout the child answered from behind a large tree where she had been\nhiding the knight lifted her onto his horse and wrapped his cloak\naround her to keep her warm they rode back to the village as the\nfirst stars appeared in the sky and the people came out to greet\nthe old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and\noil the gears and watch the sails turn in the wind the flour from\nhis mill was the finest in the region and bakers came from many\nvillages to buy it one summer the wind died and for three weeks\nthe sails stood still otto swept the floors and mended the fences\nand waited on the twenty second day a small cool wind brushed his\ncheek and by noon the mill was running at full speed otto laughed\na young fox named riku lived at the edge of the meadow with his\nmother and two sisters riku was quick and clever but also curious\nwhich sometimes got him into trouble one spring morning riku went\nexploring while his mother was sleeping he found a path he had\nnever followed before until he reached a farm with a red barn and\na vegetable garden behind a low fence the garden was full of green\nthings and the smell of fresh earth riku squeezed under the fence\nand walked between the rows of vegetables sniffing everything but\nthe farmer saw him from the window and came out shouting riku ran\nas fast as he could back under the fence and all the way home\nthe next day riku went back to the farm but this time he sat\noutside the fence the farmer came out and stood looking at him\nriku sat very still and looked back after a moment the farmer\nwent inside and came back with a piece of bread which he tossed\nover the fence riku ate it carefully and from that day on they\nhad a quiet understanding between them she found a door hidden\nbehind a tall waterfall deep in the hills behind the door was a\nsmall room with a round window and inside the room there was a\nwooden table with a candle and a book the book had no title but\nwhen she opened it the pages were full of maps of places she had\nnever heard of she sat down and read for a long time and when she\nfinally looked up the candle had burned low and the light outside\nhad turned to gold she closed the book and walked back through\nthe door and did not tell anyone what she had found but every\ntime she passed that hill she smiled the small lighthouse on the\neastern cliff had been dark for many years until one autumn a\nyoung woman came to the town and asked if she could tend the\nlight the people were pleased and gave her the keys and she\nclimbed the long stairs to the lamp room and cleaned the great\nlens and filled it with oil that night the light shone out\nacross the water for the first time in years and the ships\nthat had been waiting in the dark found their way safely home\nthe children of the village loved to climb the hill on summer\nevenings and watch the lighthouse beam sweep across the water\nthey made up stories about the ships it had guided home and\nabout the sailors who had seen its light when they thought\nall hope was lost the young woman who tended the lamp never\nknew about these stories but she would have been glad to hear\nthem because she tended the light not for praise but simply\nbecause she believed that if you have the ability to help\nsomeone find their way home then that is what you should do'.strip()
words_raw = TEXT.replace('\n', ' ').split()
word_vocab = sorted(set(words_raw))
w2i = {w: i for i, w in enumerate(word_vocab)}
i2w = {i: w for w, i in w2i.items()}
VS_w = len(word_vocab)
word_toks = [w2i[w] for w in words_raw]
N_w = len(word_toks)
D_svd = 28
WIN = 4
cooc = np.zeros((VS_w, VS_w), dtype=np.float32)
for i, w in enumerate(word_toks):
    for j in range(max(0, i - WIN), min(N_w, i + WIN + 1)):
        if i != j:
            cooc[w, word_toks[j]] += 1.0 / abs(i - j)
total = cooc.sum()
row_s = cooc.sum(1, keepdims=True)
col_s = cooc.sum(0, keepdims=True)
with np.errstate(divide='ignore', invalid='ignore'):
    pmi = np.log2(cooc * total / (row_s * col_s + 1e-10) + 1e-10)
ppmi = np.maximum(pmi, 0)
U, S, Vt = np.linalg.svd(ppmi, full_matrices=False)
WTE_svd = (U[:, :D_svd] * np.sqrt(S[:D_svd])).astype(np.float64)
norms = np.linalg.norm(WTE_svd, axis=1, keepdims=True) + 1e-08
WTE_svd_n = WTE_svd / norms
D = D_svd
print(f'\n  Word vocab={VS_w}  N_w={N_w}  D_svd={D}')
print(f'\n  SVD SEMANTIC SIMILARITY:')
test_pairs = [('the', 'a'), ('the', 'knight'), ('brave', 'knight'), ('she', 'he'), ('she', 'was'), ('in', 'the'), ('forest', 'garden'), ('small', 'big'), ('he', 'his')]
for w1, w2 in test_pairs:
    if w1 in w2i and w2 in w2i:
        v1 = WTE_svd_n[w2i[w1]]
        v2 = WTE_svd_n[w2i[w2]]
        cos = v1 @ v2
        print(f"  cos('{w1}','{w2}')={cos:.3f}")
SCALE = 4.0
WTE_out = WTE_svd_n * SCALE
K = 4
DECAY = 0.5
L = 3
decay_w = np.array([DECAY ** j for j in range(K)], dtype=np.float64)
decay_w /= decay_w.sum()
M_w = N_w - K
y_w = np.array(word_toks[K:])
X0_w = np.zeros((M_w, D), dtype=np.float64)
for i in range(K, N_w):
    for j in range(K):
        X0_w[i - K] += decay_w[j] * WTE_svd_n[word_toks[i - 1 - j]]
T_w = WTE_out[y_w]
tri_i, tri_j = np.triu_indices(D)

def phi_b(X):
    return X[:, tri_i] * X[:, tri_j]

def phi(x):
    return x[tri_i] * x[tri_j]

def pinv_s(Ph, R, lam=1e-06):
    A = Ph.T @ Ph + lam * np.eye(Ph.shape[1])
    return np.linalg.solve(A, Ph.T @ R)

def fwd(X, Wl):
    xs = [X.copy()]
    for W in Wl:
        xs.append(xs[-1] + phi_b(xs[-1]) @ W)
    return xs

def ppl_acc_w(Wl):
    x = fwd(X0_w, Wl)[-1]
    lg = x @ WTE_out.T
    preds = np.argmax(lg, 1)
    acc = 100 * np.mean(preds == y_w)
    step = max(1, M_w // 500)
    nll = 0.0
    ne = 0
    for i in range(0, M_w, step):
        l = lg[i] - lg[i].max()
        l = l - np.log(np.sum(np.exp(l)))
        nll -= l[y_w[i]]
        ne += 1
    return (math.exp(min(nll / ne, 500)), acc)
D_q = D * (D + 1) // 2
print(f'\n  D_quad={D_q}  N/D_quad={M_w / D_q:.2f}x  Scale={SCALE}')
W_w = [np.zeros((D_q, D)) for _ in range(L)]
p0, a0 = ppl_acc_w(W_w)
print(f'  Initial: ppl={p0:.2f}  acc={a0:.1f}%  (random={VS_w})')
print(f"\n  {'Rnd':>4} {'L':>2} {'ppl':>8} {'acc':>7}")
print(f"  {'─' * 35}")
best_p = p0
best_W = [w.copy() for w in W_w]
for rnd in range(10):
    imp = False
    for l in range(L):
        xs = fwd(X0_w, W_w)
        Wn = pinv_s(phi_b(xs[l]), T_w - xs[l])
        Wt = [w.copy() for w in W_w]
        Wt[l] = Wn
        p, a = ppl_acc_w(Wt)
        mk = ' ★' if p < best_p else ''
        print(f'  {rnd + 1:>4} {l:>2} {p:>8.2f} {a:>6.1f}%{mk}')
        if p < best_p:
            best_p = p
            W_w = Wt
            best_W = [w.copy() for w in Wt]
            imp = True
    if not imp:
        print(f'  Converged.')
        break
W_w = best_W
fp, fa = ppl_acc_w(W_w)
xs = fwd(X0_w, W_w)
print(f'\n  RESIDUAL: ', end='')
for l in range(L):
    r = np.mean(np.linalg.norm(T_w - xs[l], axis=1))
    print(f'L{l}:{r:.3f}', end=' → ')
print(f'final:{np.mean(np.linalg.norm(T_w - xs[-1], axis=1)):.3f}')
print(f'\n  WORD PREDICTION:')
for prev_w in ['the', 'and', 'she', 'he', 'in', 'a', 'was', 'had']:
    if prev_w not in w2i:
        continue
    x = decay_w[0] * WTE_svd_n[w2i[prev_w]].copy()
    for W in W_w:
        x = x + phi(x) @ W
    lg = x @ WTE_out.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    top3 = [(i2w[i], f'{100 * p[i]:.1f}%') for i in np.argsort(-p)[:3]]
    print(f"  '{prev_w}' → {top3}")
print(f'\n  BIGRAM PREDICTIONS:')
for ctx, true_w in [(['the', 'brave'], 'knight'), (['she', 'was'], 'so'), (['in', 'the'], 'forest'), (['he', 'had'], 'never'), (['a', 'small'], 'green'), (['and', 'the'], 'birds')]:
    ids = [w2i[w] for w in ctx if w in w2i]
    x = np.zeros(D, dtype=np.float64)
    for j in range(min(K, len(ids))):
        x += decay_w[j] * WTE_svd_n[ids[-1 - j]]
    for W in W_w:
        x = x + phi(x) @ W
    lg = x @ WTE_out.T
    lg -= lg.max()
    p = np.exp(lg)
    p /= p.sum()
    true_p = 100 * p[w2i[true_w]] if true_w in w2i else 0
    top3 = [(i2w[i], f'{100 * p[i]:.1f}%') for i in np.argsort(-p)[:3]]
    print(f"  {ctx}→'{true_w}'({true_p:.1f}%) top3={top3}")

def gen_w(prompt_words, n=20, temp=1.0, seed=42):
    np.random.seed(seed)
    ids = [w2i[w] for w in prompt_words if w in w2i]
    for _ in range(n):
        x = np.zeros(D, dtype=np.float64)
        recent = ids[-K:] if len(ids) >= K else [0] * (K - len(ids)) + ids
        for j in range(K):
            x += decay_w[j] * WTE_svd_n[recent[-1 - j]]
        for W in W_w:
            x = x + phi(x) @ W
        lg = x @ WTE_out.T
        if temp == 0:
            pred = int(np.argmax(lg))
        else:
            lg2 = (lg - lg.max()) / temp
            pr = np.exp(lg2)
            pr /= pr.sum()
            idx = np.argsort(-pr)
            cm = np.cumsum(pr[idx])
            cut = np.searchsorted(cm, 0.9) + 1
            nuc = idx[:max(1, cut)]
            pn = pr[nuc]
            pn /= pn.sum()
            pred = int(np.random.choice(nuc, p=pn))
        ids.append(pred)
    return ' '.join((i2w.get(t, '?') for t in ids))
print(f'\n  GENERATION (greedy):')
for sw in [['once', 'upon', 'a', 'time'], ['the', 'brave', 'knight'], ['deep', 'in', 'the', 'forest']]:
    print(f'  {gen_w(sw, n=15, temp=0)}')
print(f'\n  GENERATION (nucleus):')
for si, sw in enumerate([['once', 'upon', 'a', 'time'], ['the', 'brave', 'knight'], ['deep', 'in', 'the', 'forest']]):
    print(f'  {gen_w(sw, n=15, temp=0.9, seed=si * 7 + 1)}')
print(f'\n  Time:{time.time() - t0:.2f}s')
print(f"\n{'=' * 65}")
print(f'  ppl={fp:.2f}  acc={fa:.1f}%  vocab={VS_w}')
print(f'\n  EMBEDDING COMPARISON:')
print(f'  v2 char-compose: cos(brave,knight)=0.000 (wrong)')
print(f'  v3 SVD co-occur: cos(brave,knight)=? (should be >0)')
print(f'  Natural space for words = distributional context.')
print('=' * 65 + '\n')
