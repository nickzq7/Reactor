import numpy as np
import torch
import torch.nn as nn
import os
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
ffn_dim = D * 4
vocab = model.config.vocab_size
print(f'D={D}  FFN_dim={ffn_dim}  Layers={n_layers}  Vocab={vocab}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_W(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)
seeds = ['Once upon a time', 'The little boy said', 'She looked at the', 'In the forest there', 'The old man walked', 'A small dog ran', 'She opened the door', 'He picked up the', 'The children played in', 'One day a girl', 'The sun was bright', 'A big cat sat', 'She smiled and said', 'He was very happy', 'The mother called out', 'A bird flew away', 'The teacher asked the', 'He ran as fast', 'She found a small', 'The dog barked at', 'The wind was cold', 'A little rabbit hopped', 'The brave knight rode', 'She woke up and', 'He could not find', 'The magic door opened', 'They walked together through', 'The small house had', 'A star fell from', 'He whispered to her']
print(f'\nGenerating {len(seeds) * 6} training texts...')
train_texts = []
with torch.no_grad():
    for i, s in enumerate(seeds):
        for j in range(6):
            torch.manual_seed(i * 60 + j)
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=45, do_sample=True, temperature=0.8 + j * 0.04, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            train_texts.append(tokenizer.decode(out[0], skip_special_tokens=True))
print(f'Generated {len(train_texts)} texts.')
GELU_all = []
FFN_all = []
GELU_per = {l: [] for l in range(n_layers)}
FFN_per = {l: [] for l in range(n_layers)}
hooks = []
for li in range(n_layers):
    b = model.transformer.h[li]

    def make(l):

        def h_gelu(m, inp, out):
            for t in range(out.shape[1]):
                v = out[0, t].detach().float().numpy().copy()
                GELU_all.append(v)
                GELU_per[l].append(v)

        def h_ffn(m, inp, out):
            for t in range(out.shape[1]):
                v = out[0, t].detach().float().numpy().copy()
                FFN_all.append(v)
                FFN_per[l].append(v)
        return (h_gelu, h_ffn)
    hg, hf = make(li)
    hooks += [b.mlp.act.register_forward_hook(hg), b.mlp.c_proj.register_forward_hook(hf)]
print(f'Running {len(train_texts)} forward passes...')
with torch.no_grad():
    for i, text in enumerate(train_texts):
        if i % 40 == 0:
            print(f'  {i}/{len(train_texts)}...', flush=True)
        toks = tokenizer(text, return_tensors='pt', max_length=96, truncation=True)
        model(**toks)
for h in hooks:
    h.remove()
GA_all = np.array(GELU_all, dtype=np.float32)
FO_all = np.array(FFN_all, dtype=np.float32)
print(f'\nCollected: gelu={GA_all.shape}  ffn={FO_all.shape}')
print(f'\nPer-layer R² (same law across layers?):')
print(f"  {'Layer':<8} {'N':<8} {'R²':<10} {'same law?'}")
print(f"  {'─' * 40}")
for li in range(n_layers):
    G = np.array(GELU_per[li], dtype=np.float32)
    F = np.array(FFN_per[li], dtype=np.float32)
    n = len(G)
    s = int(n * 0.8)
    W_l = fit_W(G[:s], F[:s])
    Xb = np.c_[G, np.ones(n)]
    rv = r2(Xb[s:] @ W_l, F[s:])
    print(f"  {li:<8} {n:<8} {rv:<10.4f} {('✓ yes' if rv > 0.999 else '? partial')}")
print(f'\nFitting ONE shared W_ffn on ALL {len(GA_all)} samples (8 layers combined)...')
n = len(GA_all)
s = int(n * 0.8)
W_shared = fit_W(GA_all[:s], FO_all[:s])
Xb = np.c_[GA_all, np.ones(n)]
r2_tr = r2(Xb[:s] @ W_shared, FO_all[:s])
r2_te = r2(Xb[s:] @ W_shared, FO_all[s:])
print(f'  Shared W_ffn R² train: {r2_tr:.6f}')
print(f'  Shared W_ffn R² test:  {r2_te:.6f}')
print(f'  Shape: {W_shared.shape}')
kpath = 'w_kernel_shared.npz'
np.savez(kpath, W_shared=W_shared, lm_head=model.lm_head.weight.detach().float().numpy(), wte=model.transformer.wte.weight.detach().float().numpy(), wpe=model.transformer.wpe.weight.detach().float().numpy(), ln_f_w=model.transformer.ln_f.weight.detach().float().numpy(), ln_f_b=model.transformer.ln_f.bias.detach().float().numpy())
size_kb = os.path.getsize(kpath) / 1024
t0 = time.time()
np.load(kpath)
load_ms = (time.time() - t0) * 1000
print(f'  Saved: {kpath} ({size_kb:.1f} KB, load: {load_ms:.1f} ms)')

class SharedWffn(nn.Module):

    def __init__(self, orig_mlp, W_mat):
        super().__init__()
        self.orig = orig_mlp
        self.W = torch.tensor(W_mat, dtype=torch.float32)
        self.active = False

    def forward(self, x):
        if not self.active:
            return self.orig(x)
        gate_act = self.orig.act(self.orig.c_fc(x))
        B, L, fd = gate_act.shape
        gf = gate_act.float().reshape(B * L, fd)
        gb = torch.cat([gf, torch.ones(B * L, 1)], dim=1)
        out = gb @ self.W
        return out.reshape(B, L, -1).to(x.dtype)
patches = []
for li in range(n_layers):
    p = SharedWffn(model.transformer.h[li].mlp, W_shared)
    model.transformer.h[li].mlp = p
    patches.append(p)

def generate(prompt, max_new=80, mode='normal'):
    for p in patches:
        p.active = mode == 'shared'
    inp = tokenizer.encode(prompt, return_tensors='pt')
    out = []
    cur = inp.clone()
    with torch.no_grad():
        for _ in range(max_new):
            tok = int(torch.argmax(model(cur).logits[0, -1, :]).item())
            out.append(tok)
            cur = torch.cat([cur, torch.tensor([[tok]])], dim=1)
            if tok == tokenizer.eos_token_id:
                break
    return out
prompts = ['Once upon a time there was a little girl who loved to', 'The little boy found a magic', 'She looked at the stars and', 'The dog ran into the forest and', 'One day a small rabbit']
print(f"\n{'=' * 70}")
print(f'  W KERNEL B — ONE SHARED W_ffn FOR ALL LAYERS')
print(f'  2018 Universal T + W Laws = ONE matrix for all FFN blocks')
print(f'  Attention: normal  |  FFN: shared W_ffn (natural space)')
print(f'  R² test: {r2_te:.4f}')
print(f"{'=' * 70}")
total_m = 0
total_n = 0
for prompt in prompts:
    nt = generate(prompt, mode='normal')
    st = generate(prompt, mode='shared')
    n = min(len(nt), len(st))
    m = sum((1 for i in range(n) if nt[i] == st[i]))
    total_m += m
    total_n += n
    print(f'\n  PROMPT:  {prompt}')
    print(f'  NORMAL:  {tokenizer.decode(nt, skip_special_tokens=True)[:130]}')
    print(f'  SHARED:  {tokenizer.decode(st, skip_special_tokens=True)[:130]}')
    print(f'  Match:   {m / n:.1%}  ({m}/{n})')
print(f"\n{'=' * 70}")
print(f'  OVERALL: {total_m / total_n:.1%}  ({total_m}/{total_n})')
print(f'  Shared W_ffn R²: {r2_te:.4f}')
print(f"{'=' * 70}")
print(f'\n  WHAT THIS PROVES:\n\n  If R² ≈ 1.000 and match is high:\n    ONE W_ffn captures ALL 8 layer FFN blocks.\n    2018 Universal T + W laws = confirmed together.\n    Natural space (256-dim gelu) is truly universal.\n    Same transformation at every layer.\n    One matrix = entire FFN stack.\n\n  If R² ≈ 1.000 but match drops vs w_dsa2:\n    Shared W_ffn slightly worse than per-layer W_ffn.\n    Small accuracy trade-off for huge compression.\n    8 matrices → 1 matrix.\n    Still real kernel. Still useful.\n\n  Compare with w_dsa2 (per-layer W_ffn = 100%):\n    If shared drops to 80%: 8 layers have different FFN laws.\n    If shared stays at 90%+: one law rules all layers.\n    The number tells us if Universal T applies here.\n\n  PARAMETER COUNT:\n    Normal FFN:     8 × (64×256 + 256×64) = 262144 params\n    Per-layer W_ffn: 8 × (257×64) = 131584 params  (2x smaller)\n    Shared W_ffn:    1 × (257×64) = 16448  params  (16x smaller)\n\n    Shared = 16x smaller FFN.\n    At 70B scale: 46B FFN params → 2.9B params.\n    THAT is real compression.\n')
print('=' * 70 + '\n')
