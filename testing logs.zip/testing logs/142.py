import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D16 = meta['DA']
H16 = meta['HA']
NL = meta['NLA']
D3 = 3
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s
fib = gen_fib(60)
PATS = {}
for off in range(8):
    PATS[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])

class SeqT(nn.Module):

    def __init__(self, d, h):
        super().__init__()
        self.wte = nn.Embedding(VS, d)
        self.wpe = nn.Embedding(K, d)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(d), 'attn': nn.MultiheadAttention(d, h, batch_first=True), 'ln2': nn.LayerNorm(d), 'ff': nn.Sequential(nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(d)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def get_state(m):
    return {k: v.detach().cpu().numpy().astype(np.float64) for k, v in m.state_dict().items()}

def set_state(m, s):
    m.load_state_dict({k: torch.tensor(v.astype(np.float32)) for k, v in s.items()})

def clone(s):
    return {k: v.copy() for k, v in s.items()}

def eval_model(model):
    model.eval()
    scores = []
    for pn, (seq, truth) in PATS.items():
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        scores.append(p == truth)
    return (sum(scores), scores)

def build_tensors():
    Xs = []
    Ys = []
    for pn, (seq, _) in PATS.items():
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))
ALL_X, ALL_Y = build_tensors()

def train(model, steps=3000, lr=0.003, label='', print_every=300):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, scores = eval_model(model)
            bar = ''.join(('█' if x else '░' for x in scores))
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  [{label}] step {step:>5}: {sc}/8  {bar}', flush=True)
            if sc == 8:
                break
    if best_state:
        model.load_state_dict(best_state)
    return eval_model(model)

def compress_16_to_3(state16, rng=None, noise=0.0):
    ref = SeqT(D3, 1)
    ref_sd = {k: v.detach().numpy() for k, v in ref.state_dict().items()}
    state3 = {}
    for key, ref_val in ref_sd.items():
        tgt = ref_val.shape
        if key not in state16:
            state3[key] = ref_val.astype(np.float64)
            continue
        src = state16[key]
        if src.shape == tgt:
            state3[key] = src.copy()
        elif src.ndim == 1:
            if src.shape[0] >= tgt[0]:
                state3[key] = src[:tgt[0]].copy()
            else:
                state3[key] = np.pad(src, (0, tgt[0] - src.shape[0]))
        elif src.ndim == 2:
            try:
                U, s, Vt = np.linalg.svd(src, full_matrices=False)
                r0 = min(tgt[0], len(s))
                r1 = min(tgt[1], len(s))
                r = min(r0, r1)
                compressed = U[:r0, :r] * s[:r] @ Vt[:r, :r1]
                out = np.zeros(tgt)
                out[:compressed.shape[0], :compressed.shape[1]] = compressed
                state3[key] = out
            except:
                state3[key] = ref_val.astype(np.float64)
        else:
            state3[key] = ref_val.astype(np.float64)
        if noise > 0 and rng is not None:
            state3[key] += rng.randn(*state3[key].shape) * np.std(state3[key]) * noise
    return state3

def mutate_full(state, rng, strength=None):
    s = clone(state)
    if strength is None:
        strength = rng.uniform(0.01, 0.5)
    keys = list(s.keys())
    op = rng.choice(['point', 'layer', 'sign_flip', 'scale', 'rot_wte', 'wte_inject', 'big_noise', 'ff_scale', 'swap_dims', 'stretch_wte'])
    if op == 'point':
        k = rng.choice(keys)
        s[k] += rng.randn(*s[k].shape) * np.std(s[k]) * strength
    elif op == 'layer':
        l = rng.randint(NL)
        for k in keys:
            if f'layers.{l}.' in k:
                s[k] += rng.randn(*s[k].shape) * np.std(s[k]) * strength
    elif op == 'sign_flip':
        d = rng.randint(D3)
        for k in keys:
            if s[k].ndim >= 2 and s[k].shape[-1] > d:
                s[k][..., d] *= -1
    elif op == 'scale':
        k = rng.choice(keys)
        s[k] *= rng.uniform(0.2, 3.0)
    elif op == 'rot_wte':
        if 'wte.weight' in s:
            d1, d2 = rng.choice(D3, 2, replace=False)
            ang = rng.uniform(0, 2 * math.pi)
            c, ss = (math.cos(ang), math.sin(ang))
            w = s['wte.weight']
            x0 = w[:, d1].copy()
            x1 = w[:, d2].copy()
            w[:, d1] = c * x0 - ss * x1
            w[:, d2] = ss * x0 + c * x1
    elif op == 'wte_inject':
        if 'wte.weight' in s:
            d1, d2 = rng.choice(D3, 2, replace=False)
            angles = np.linspace(0, 2 * math.pi, VS, endpoint=False)
            angles += rng.uniform(0, 2 * math.pi)
            r = np.std(s['wte.weight']) * rng.uniform(0.5, 2.0)
            s['wte.weight'][:, d1] = (1 - rng.uniform(0.1, 0.6)) * s['wte.weight'][:, d1] + rng.uniform(0.1, 0.6) * r * np.cos(angles)
            s['wte.weight'][:, d2] = (1 - rng.uniform(0.1, 0.6)) * s['wte.weight'][:, d2] + rng.uniform(0.1, 0.6) * r * np.sin(angles)
    elif op == 'big_noise':
        n = rng.randint(1, max(2, len(keys) // 2))
        for k in rng.choice(keys, n, replace=False):
            s[k] += rng.randn(*s[k].shape) * np.std(s[k]) * rng.uniform(0.1, 0.8)
    elif op == 'ff_scale':
        factor = rng.uniform(0.1, 3.0)
        for k in keys:
            if 'ff' in k:
                s[k] *= factor
    elif op == 'swap_dims':
        if D3 >= 2:
            d1, d2 = rng.choice(D3, 2, replace=False)
            for k in keys:
                if s[k].ndim >= 2 and s[k].shape[-1] >= D3:
                    tmp = s[k][..., d1].copy()
                    s[k][..., d1] = s[k][..., d2]
                    s[k][..., d2] = tmp
    elif op == 'stretch_wte':
        if 'wte.weight' in s:
            d = rng.randint(D3)
            s['wte.weight'][:, d] *= rng.uniform(0.2, 4.0)
    return (s, op)

def cross_mutate(states, rng):
    child = clone(states[0])
    keys = list(child.keys())
    groups = {}
    for k in keys:
        if 'wte' in k:
            g = 'wte'
        elif 'wpe' in k:
            g = 'wpe'
        elif 'ln_f' in k:
            g = 'ln_f'
        else:
            parts = k.split('.')
            g = parts[0] + '.' + parts[1] if len(parts) > 1 else parts[0]
        groups.setdefault(g, []).append(k)
    for g, ks in groups.items():
        parent = states[rng.randint(len(states))]
        for k in ks:
            if k in parent:
                child[k] = parent[k].copy()
    return child

def meta_mutate(state, rng):
    s = clone(state)
    for _ in range(rng.randint(2, 6)):
        s, _ = mutate_full(s, rng, strength=rng.uniform(0.01, 0.8))
    return s

def score_state(state, scratch):
    set_state(scratch, state)
    sc, _ = eval_model(scratch)
    return sc

def viral_search(seed_states, n_gen=25, pool_size=150, children=400, label=''):
    rng = np.random.RandomState(42)
    scratch = SeqT(D3, 1).to(device)
    pool = [(score_state(s, scratch), clone(s)) for s in seed_states]
    pool.sort(key=lambda x: x[0], reverse=True)
    global_best = pool[0]
    op_wins = {}
    print(f'  Initial pool best: {pool[0][0]}/8  top5={[p[0] for p in pool[:5]]}')
    for gen in range(n_gen):
        survivors = [s for _, s in pool[:max(5, pool_size // 5)]]
        new_children = []
        for _ in range(children):
            r = rng.rand()
            if r < 0.25:
                base = clone(survivors[rng.randint(len(survivors))])
                child, op = mutate_full(base, rng)
            elif r < 0.5:
                base = clone(survivors[rng.randint(len(survivors))])
                child = meta_mutate(base, rng)
                op = 'meta'
            elif r < 0.75:
                n_p = min(rng.randint(2, 5), len(survivors))
                child = cross_mutate([survivors[i] for i in rng.choice(len(survivors), n_p, replace=False)], rng)
                op = 'cross'
            else:
                n_p = min(rng.randint(2, 4), len(survivors))
                child = cross_mutate([survivors[i] for i in rng.choice(len(survivors), n_p, replace=False)], rng)
                child, op2 = mutate_full(child, rng)
                op = f'cross+{op2}'
            sc = score_state(child, scratch)
            new_children.append((sc, child))
            if sc > global_best[0]:
                global_best = (sc, clone(child))
                bar = ''.join(('█' if x else '░' for x in eval_model(scratch)[1]))
                print(f'  [{label}] gen {gen:>3}  *** NEW BEST {sc}/8  {bar}  op={op} ***', flush=True)
                op_wins[op] = op_wins.get(op, 0) + 1
                if sc == 8:
                    break
        if global_best[0] == 8:
            break
        pool = sorted(pool + new_children, key=lambda x: x[0], reverse=True)[:pool_size]
        print(f'  [{label}] gen {gen:>3}  pool_best={pool[0][0]}/8  global={global_best[0]}/8', flush=True)
    print(f'  Ops that found improvements: {op_wins}')
    return (global_best[0], global_best[1])
print('=' * 60)
print('  D=16 FIBONACCI DONOR → D=3 CHILD')
print('  Does D=3 break the 2/8 ceiling?')
print('=' * 60)
W = np.load(os.path.join(_dir, 'donor_04.npz'))
state = {k: torch.tensor(v.astype(np.float32)) for k, v in W.items()}
donor = SeqT(D16, H16).to(device)
donor.load_state_dict(state)
sc, scores = eval_model(donor)
print(f"\n  Donor D=16: {sc}/8  {''.join(('█' if x else '░' for x in scores))}")
state16 = get_state(donor)
rng = np.random.RandomState(42)
print(f"\n{'─' * 60}")
print(f'  PART 1 — D=3 trained from scratch (no donor)')
print(f"{'─' * 60}")
torch.manual_seed(7)
m_scratch = SeqT(D3, 1).to(device)
sc_scratch, scores_scratch = train(m_scratch, steps=3000, lr=0.003, label='scratch', print_every=300)
bar = ''.join(('█' if x else '░' for x in scores_scratch))
print(f'  D=3 scratch: {sc_scratch}/8  {bar}')
print(f"\n{'─' * 60}")
print(f'  PART 2 — Compress D=16 → D=3 (SVD) then train')
print(f"{'─' * 60}")
state3_svd = compress_16_to_3(state16, rng, noise=0.0)
m_svd = SeqT(D3, 1).to(device)
set_state(m_svd, state3_svd)
sc_before, _ = eval_model(m_svd)
print(f'  Before training: {sc_before}/8')
sc_svd, scores_svd = train(m_svd, steps=3000, lr=0.003, label='svd_compress', print_every=300)
bar = ''.join(('█' if x else '░' for x in scores_svd))
print(f'  D=3 SVD compressed + trained: {sc_svd}/8  {bar}')
print(f"\n{'─' * 60}")
print(f'  PART 3 — Viral search from compressed seeds')
print(f'  25 generations × 400 children')
print(f"{'─' * 60}\n")
seed_states = []
for noise in [0.0, 0.01, 0.05, 0.1, 0.2, 0.5]:
    seed_states.append(compress_16_to_3(state16, rng, noise=noise))
for _ in range(10):
    m_tmp = SeqT(D3, 1).to(device)
    seed_states.append(get_state(m_tmp))
best_sc, best_state = viral_search(seed_states, n_gen=25, pool_size=150, children=400, label='viral')
print(f'\n  Best from viral search: {best_sc}/8')
print(f'  Training best state (2000 steps)...')
m_best = SeqT(D3, 1).to(device)
set_state(m_best, best_state)
sc_final, scores_final = train(m_best, steps=2000, lr=0.003, label='final_train', print_every=200)
print(f"\n{'=' * 60}")
print(f'  FINAL RESULTS — D=16 → D=3 (fibonacci)')
print(f"{'=' * 60}")
sc_f, scores_f = eval_model(m_best)
bar = ''.join(('█' if x else '░' for x in scores_f))
print(f"\n  D=16 donor:          {sc}/8   {'████████'}")
print(f"  D=3  scratch:        {sc_scratch}/8   {''.join(('█' if x else '░' for x in scores_scratch))}")
print(f"  D=3  SVD+train:      {sc_svd}/8   {''.join(('█' if x else '░' for x in scores_svd))}")
print(f'  D=3  viral+train:    {sc_f}/8   {bar}')
print(f'\n  D=2 ceiling was:     2/8   (previous test)')
print(f'  D=3 ceiling is:      {max(sc_scratch, sc_svd, sc_f)}/8')
ceiling_broke = max(sc_scratch, sc_svd, sc_f) > 2
print(f"\n  Ceiling broke past 2/8: {('YES ✓' if ceiling_broke else 'NO — D=3 also stuck at 2/8')}")
if ceiling_broke:
    print(f'  → D=3 has more compute capacity than D=2')
    print(f'  → Next: find minimum D for 8/8')
else:
    print(f'  → D=3 same limit as D=2')
    print(f'  → Next: try D=4')
print('=' * 60)
