import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 62)
print('  W — REAL MODEL TEST')
print('  TinyStories-1M. Real weights. Same rules.')
print('  R²=1.0 confirms rules are universal.')
print('  R²<1.0 reveals what is still hidden.')
print('=' * 62)
print('\n  Loading model...')
tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125M')
model = AutoModelForCausalLM.from_pretrained('roneneldan/TinyStories-1M')
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
n_heads = model.config.num_attention_heads
head_dim = D // n_heads
print(f'  Loaded. Layers={n_layers} D={D} Heads={n_heads}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return 1 - e / s if s > 0 else 0.0

def test(X_tr, Y_tr, X_te, Y_te, label):
    W = np.linalg.lstsq(X_tr, Y_tr, rcond=None)[0]
    score = r2(X_te @ W, Y_te)
    mark = '✓ R²=1.0' if score > 0.999 else f'  {score:.6f}'
    print(f'    {label:<50} {mark}')
    return (score, W)
sentences = ['Once upon a time there was a little girl named Lily', 'She loved to play outside in the sunshine every day', 'One day she saw a big shiny rock in the sky above', 'The dog ran to the park and saw a big friendly dog', 'A boy named Tom found a magic wand near the old tree', 'The princess looked out the window at the beautiful garden', 'One day a small rabbit decided to hop through the forest', 'He climbed up the tall tree to see what was at the top', 'She picked up the flowers and smiled at her loving mother', 'The children played happily together in the warm sunny yard', 'A kind fairy came to grant three wishes to the poor farmer', 'The brave knight rode his horse into the dark deep forest', 'She opened the door slowly and looked outside at white snow', 'He found a little puppy sleeping near the old red house', 'The sun rose slowly over the distant green rolling hills', 'A small fish swam in the clear blue calm lake all alone', 'The baby bear found golden honey in the hollow oak tree', 'She whispered a secret to her very best friend at school', 'A clever fox tricked the big wolf and quickly ran away', 'The little prince lived alone on a very tiny small planet', 'Once there was a dragon who wanted to make new friends', 'The old wizard taught the young boy how to use magic', 'A tiny seed grew slowly into a tall and beautiful flower', 'The friendly giant woke up and smiled at the whole village', 'She found a lost kitten crying softly in the cold rain', 'The two friends walked together through the enchanted forest', 'A rainbow appeared in the sky after the long heavy rain', 'The queen shared her food with all the hungry poor people', 'A little yellow duck learned to swim in the warm pond', 'The snow fell softly and quietly on the sleeping village', 'He closed his eyes and wished upon the very first star', 'The cat chased the butterfly through the green sunny garden', 'A wooden boat sailed slowly across the wide quiet blue lake', 'The children found a treasure map inside the old dark chest', 'She drew a colorful picture of her happy smiling family', 'The moon shone bright and clear over the quiet little town', 'A young boy climbed the tall mountain to see the whole world', 'The kind old woman gave warm bread to the hungry children', 'He discovered a hidden door behind the dusty old bookshelf', 'The baby elephant splashed happily in the warm muddy water']
print(f'\n  Collecting hidden states from {len(sentences)} sentences...')
layer_idx = 0
inputs_to_block = []
outputs_of_block = []
ln1_outputs = []
att_outputs = []
ln2_outputs = []
ffn_outputs = []
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=32, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < 4:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for pos_start in range(0, L - 3, 2):
            pos_end = min(pos_start + 8, L)
            seg_len = pos_end - pos_start
            h_in = hs[layer_idx][0, pos_start:pos_end].numpy()
            h_out = hs[layer_idx + 1][0, pos_start:pos_end].numpy()
            inputs_to_block.append(h_in)
            outputs_of_block.append(h_out)
N_samples = len(inputs_to_block)
print(f'  Collected {N_samples} sequence segments.')
min_len = min((s.shape[0] for s in inputs_to_block))
CTX = min(8, min_len)
X_segs = np.array([s[:CTX] for s in inputs_to_block])
Y_segs = np.array([s[:CTX] for s in outputs_of_block])
X_flat = X_segs.reshape(N_samples, -1)
Y_flat = Y_segs.reshape(N_samples, -1)
N_tr = int(N_samples * 0.8)
print(f'  Shape: X={X_flat.shape}  Y={Y_flat.shape}')
print(f'  Train: {N_tr}  Test: {N_samples - N_tr}')
print('\n' + '─' * 62)
print(f'  LAYER {layer_idx} — BASELINE (no rules)')
print('─' * 62)
print()
test(X_flat[:N_tr], Y_flat[:N_tr], X_flat[N_tr:], Y_flat[N_tr:], 'raw hidden states')
print('\n' + '─' * 62)
print(f'  LAYER {layer_idx} — RULES APPLIED')
print('  Using real model intermediate states.')
print('─' * 62)
print()
block = model.transformer.h[layer_idx]
all_rule_feats = []
with torch.no_grad():
    for sent in sentences:
        tokens = tokenizer(sent, return_tensors='pt', max_length=32, truncation=True)
        ids = tokens['input_ids']
        L = ids.shape[1]
        if L < 4:
            continue
        out = model(**tokens, output_hidden_states=True)
        hs = out.hidden_states
        for pos_start in range(0, L - 3, 2):
            pos_end = min(pos_start + CTX, L)
            if pos_end - pos_start < CTX:
                continue
            x = hs[layer_idx][0, pos_start:pos_end]
            feats = []
            feats.append(x.numpy().flatten())
            ln1 = block.ln_1(x).numpy()
            feats.append(ln1.flatten())
            attn = block.attn.attention
            c_attn_weight = attn.q_proj if hasattr(attn, 'q_proj') else None
            attn_out_full = block.attn(block.ln_1(x))[0].numpy()
            feats.append(attn_out_full.flatten())
            x_post_attn = x.numpy() + attn_out_full
            feats.append(x_post_attn.flatten())
            x_post_attn_t = torch.tensor(x_post_attn, dtype=torch.float32)
            ln2 = block.ln_2(x_post_attn_t).numpy()
            feats.append(ln2.flatten())
            mlp = block.mlp
            pre_act = mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
            feats.append(pre_act.flatten())
            act_out = mlp.act(torch.tensor(pre_act, dtype=torch.float32)).numpy()
            feats.append(act_out.flatten())
            ind = (pre_act > 0).astype(float)
            feats.append(ind.flatten())
            ffn_out = mlp.c_proj(torch.tensor(act_out, dtype=torch.float32)).numpy()
            feats.append(ffn_out.flatten())
            all_rule_feats.append(np.concatenate(feats))
if len(all_rule_feats) == N_samples:
    X_rules = np.array(all_rule_feats)
    print(f'  Rule feature size: {X_rules.shape[1]}')
    score, W_real = test(X_rules[:N_tr], Y_flat[:N_tr], X_rules[N_tr:], Y_flat[N_tr:], 'all rules — real model internals')
else:
    print(f'  Sample count mismatch. Skipping rule test.')
    score = 0.0
print('\n' + '─' * 62)
print("  PROGRESSIVE — each rule's contribution")
print('─' * 62)
print()
if len(all_rule_feats) == N_samples:
    sizes = []
    with torch.no_grad():
        sent = sentences[0]
        tokens = tokenizer(sent, return_tensors='pt', max_length=32, truncation=True)
        x = model(**tokens, output_hidden_states=True).hidden_states[0][0, :CTX]
        ln1 = block.ln_1(x).numpy()
        att_out = block.attn(block.ln_1(x))[0].numpy()
        x2 = x.numpy() + att_out
        ln2 = block.ln_2(torch.tensor(x2, dtype=torch.float32)).numpy()
        pre = block.mlp.c_fc(torch.tensor(ln2, dtype=torch.float32)).numpy()
        act = block.mlp.act(torch.tensor(pre, dtype=torch.float32)).numpy()
        ffn = block.mlp.c_proj(torch.tensor(act, dtype=torch.float32)).numpy()
        ind = (pre > 0).astype(float)
        group_sizes = [x.numpy().flatten().shape[0], ln1.flatten().shape[0], att_out.flatten().shape[0], x2.flatten().shape[0], ln2.flatten().shape[0], pre.flatten().shape[0], act.flatten().shape[0], ind.flatten().shape[0], ffn.flatten().shape[0]]
    cumulative = np.cumsum([0] + group_sizes)
    group_names = ['raw hidden state', '+ LayerNorm1 rule', '+ Attention output rule', '+ Residual1 rule', '+ LayerNorm2 rule', '+ FFN pre-activation rule', '+ Activation (gelu) rule', '+ Activation indicator rule', '+ FFN output rule']
    for i, name in enumerate(group_names):
        end = cumulative[i + 1]
        Xp = X_rules[:, :end]
        s, _ = test(Xp[:N_tr], Y_flat[:N_tr], Xp[N_tr:], Y_flat[N_tr:], name)
print('\n' + '=' * 62)
print('  WHAT REAL MODEL REVEALS')
print('=' * 62)
print(f"\n  Synthetic weights (previous test):\n    All rules → R²=1.0\n\n  Real trained weights (this test):\n    All rules → R²={score:.6f}\n\n  {('SAME RESULT — rules are universal.' if score > 0.999 else 'DIFFERENCE FOUND — real weights hide something more.')}\n\n  Progressive shows where gap appears.\n  The step where R² stops growing =\n  the hidden operation in real trained weights.\n  That is the next rule to find.\n\n  Real training creates structures\n  that random weights do not have.\n  Sparse activations. Attention patterns.\n  Specific frequency distributions.\n  These may need additional rules.\n\n  W reveals them precisely.\n  Not by guessing.\n  By showing where R² stalls.\n  That stall = the hidden law.\n")
print('=' * 62 + '\n')
