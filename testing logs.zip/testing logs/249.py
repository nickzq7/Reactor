import numpy as np
import math
import time
np.random.seed(42)
print('\n' + '=' * 70)
print('  W-KERNEL FROM SCRATCH v3 — STABLE')
print('  Frozen embeddings. Clipped weights. Normalized targets.')
print('=' * 70)
TEXT = '\nonce upon a time there was a little girl named lily who loved to play\nin the garden near her home every morning she would wake up early and\nrun outside to see the flowers and the birds the garden had red roses\nand yellow daisies and tall green grass that tickled her ankles lily\nhad a small watering can that she used to give the flowers a drink she\nknew that every flower needed water and sunshine to grow one day she\nfound a tiny seed on the ground she picked it up carefully and planted\nit in the soft dark soil near the big oak tree she watered it every\nday and waited patiently after one week a small green shoot appeared\nlily was so happy she clapped her hands and ran to tell her mother her\nmother smiled and said that lily had grown something beautiful together\nthey watched the small plant grow bigger every day until it became a\ntall sunflower with bright yellow petals that reached up toward the sky\nthe birds came to eat the seeds and lily felt proud that she had made\nsomething that helped the animals too her mother told her that taking\ncare of living things was one of the most important things a person\ncould do and lily never forgot those words she grew up to love gardens\nand flowers and all the small creatures that lived among the leaves\ndeep in the forest near the village there lived a small brown rabbit\nwho was very curious about the world one morning the rabbit hopped out\nof his burrow and sniffed the cool morning air the dew was still on the\ngrass and the birds were singing in the tall pine trees the rabbit\ndecided to explore a new part of the forest that he had never visited\nbefore he hopped past the big mossy rock and through the field of tall\nferns until he came to a stream where the water was clear and cold he\nbent his head to drink and saw his own reflection in the water he was\nsurprised and jumped back then slowly came forward again and looked\nmore carefully he thought his reflection looked like a friend and he\nstayed by the stream for a long time watching the water move and the\nfish swim by when the sun was high in the sky he hopped back home to\nhis burrow feeling happy about all the things he had seen that day\nthe brave knight rode across the wide plain toward the distant hills\nthe wind was cold and the sky was gray but the knight did not stop he\nhad promised to find the lost child before nightfall and he kept his\npromise always he rode through a small village where the people stood\nwatching him pass some of the children waved and he waved back with his\niron glove at last he reached the edge of the forest and called out\nthe child answered from behind a large tree where she had been hiding\nthe knight lifted her onto his horse and wrapped his cloak around her\nto keep her warm they rode back to the village as the first stars\nappeared in the sky and the people came out to greet them with lights\nand warm bread and kind words the knight stayed the night and left in\nthe morning before anyone else was awake leaving only his footprints\nin the soft mud as a sign that he had been there and done what he came\nto do the old miller named otto had run his windmill for forty years\nevery morning he climbed the wooden stairs to check the stones and oil\nthe gears and watch the sails turn in the wind the flour from his mill\nwas the finest in the region and bakers came from many villages to buy\nit one summer the wind died and for three weeks the sails stood still\notto swept the floors and mended the fences and waited on the twenty\nsecond day a small cool wind brushed his cheek and by noon the mill\nwas running at full speed and the sound of the stones filled the valley\n'.strip()
chars = sorted(set(TEXT))
vocab = {c: i for i, c in enumerate(chars)}
ivocab = {i: c for c, i in vocab.items()}
VS = len(vocab)
tokens = [vocab[c] for c in TEXT]
print(f'\n  Vocab={VS}  Tokens={len(tokens)}')
D = 32
FFN_D = 64
N_HEADS = 4
HEAD_D = D // N_HEADS
N_LAYERS = 2
SEQ_LEN = 16
CLIP = 3.0
LAM = 0.01
print(f'  D={D}  FFN_D={FFN_D}  Heads={N_HEADS}  Layers={N_LAYERS}')
print(f'  CLIP={CLIP}  LAM={LAM}')
rng = np.random.RandomState(0)
WTE_FIXED = rng.randn(VS, D).astype(np.float64) * 0.3
for i in range(VS):
    n = np.linalg.norm(WTE_FIXED[i])
    if n > 1e-08:
        WTE_FIXED[i] /= n
WTE_FIXED *= 0.5
WPE_FIXED = rng.randn(SEQ_LEN + 1, D).astype(np.float64) * 0.1
print(f'  wte norm range: [{np.linalg.norm(WTE_FIXED, axis=1).min():.3f}, {np.linalg.norm(WTE_FIXED, axis=1).max():.3f}]  FIXED')

def ln_f(x, g, b, eps=1e-05):
    m = x.mean()
    v = ((x - m) ** 2).mean()
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_f(x):
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_f(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def solve_ridge(X, Y, lam=LAM):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    Xb = np.hstack([X, np.ones((len(X), 1))])
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    try:
        W = np.linalg.solve(A, Xb.T @ Y)
    except np.linalg.LinAlgError:
        W, _, _, _ = np.linalg.lstsq(Xb, Y, rcond=None)
    return np.clip(W, -CLIP, CLIP)

def clip_w(w):
    for k, v in w.items():
        if k.startswith('W') or k.startswith('b') or k.startswith('ln'):
            w[k] = np.clip(v, -CLIP, CLIP)
    return w

def init():
    w = {}
    for li in range(N_LAYERS):
        s = str(li)
        w[f'ln1_g{s}'] = np.ones(D, dtype=np.float64)
        w[f'ln1_b{s}'] = np.zeros(D, dtype=np.float64)
        w[f'ln2_g{s}'] = np.ones(D, dtype=np.float64)
        w[f'ln2_b{s}'] = np.zeros(D, dtype=np.float64)
        w[f'Wq{s}'] = rng.randn(D, D).astype(np.float64) * 0.01
        w[f'Wk{s}'] = rng.randn(D, D).astype(np.float64) * 0.01
        w[f'Wv{s}'] = rng.randn(D, D).astype(np.float64) * 0.01
        w[f'Wo{s}'] = np.zeros((D, D), dtype=np.float64)
        w[f'bo{s}'] = np.zeros(D, dtype=np.float64)
        w[f'W1{s}'] = rng.randn(FFN_D, D).astype(np.float64) * 0.01
        w[f'b1{s}'] = np.zeros(FFN_D, dtype=np.float64)
        w[f'W2{s}'] = np.zeros((D, FFN_D), dtype=np.float64)
        w[f'b2{s}'] = np.zeros(D, dtype=np.float64)
    w['lnf_g'] = np.ones(D, dtype=np.float64)
    w['lnf_b'] = np.zeros(D, dtype=np.float64)
    return w

def fwd_layer(x, li, w):
    T = len(x)
    s = str(li)
    ln1 = np.array([ln_f(x[i], w[f'ln1_g{s}'], w[f'ln1_b{s}']) for i in range(T)])
    Q = ln1 @ w[f'Wq{s}'].T
    K = ln1 @ w[f'Wk{s}'].T
    V = ln1 @ w[f'Wv{s}'].T
    Qh = Q.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Kh = K.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    Vh = V.reshape(T, N_HEADS, HEAD_D).transpose(1, 0, 2)
    mask = np.triu(np.full((T, T), float('-inf')), 1)
    probs = softmax_f(Qh @ Kh.transpose(0, 2, 1) + mask)
    ctx = np.stack([probs[h] @ Vh[h] for h in range(N_HEADS)], 1).reshape(T, D)
    att = ctx @ w[f'Wo{s}'].T + w[f'bo{s}']
    xa = x + att
    xn = xa.copy()
    for t in range(T):
        ln2 = ln_f(xa[t], w[f'ln2_g{s}'], w[f'ln2_b{s}'])
        xn[t] = xa[t] + gelu_f(ln2 @ w[f'W1{s}'].T + w[f'b1{s}']) @ w[f'W2{s}'].T + w[f'b2{s}']
    return (xn, ctx, xa)

def fwd_all(ids, w):
    T = len(ids)
    x = (WTE_FIXED[ids] + WPE_FIXED[:T]).copy()
    for li in range(N_LAYERS):
        x, _, _ = fwd_layer(x, li, w)
    xf = np.array([ln_f(x[t], w['lnf_g'], w['lnf_b']) for t in range(T)])
    return (xf @ WTE_FIXED.T, x)

def perplexity(w, n=300):
    nll = 0.0
    tok = 0
    step = max(1, (len(tokens) - SEQ_LEN - 1) // n)
    for s in range(0, len(tokens) - SEQ_LEN - 1, step):
        ids = tokens[s:s + SEQ_LEN]
        tgt = tokens[s + SEQ_LEN]
        try:
            logits, _ = fwd_all(ids, w)
            if not np.all(np.isfinite(logits)):
                continue
            lg = logits[-1] - logits[-1].max()
            lp = lg - np.log(np.sum(np.exp(lg)))
            nll += -lp[tgt]
            tok += 1
        except:
            pass
    if tok == 0:
        return float('inf')
    avg_nll = nll / tok
    if avg_nll > 700:
        return float('inf')
    return math.exp(avg_nll)
w = init()
p0 = perplexity(w)
print(f'\n  Random perplexity: {p0:.2f}  (vocab ceiling={VS})')
print(f"\n{'=' * 70}")
print(f'  TRAINING')
print(f"{'=' * 70}\n")
ROUNDS = 30
BATCH = 300
print(f"  {'Round':<6} {'PPL':>8} {'Best':>8} {'Status'}")
print(f"  {'─' * 40}")
best_ppl = p0
best_w = {k: v.copy() for k, v in w.items()}
hist = [p0]
t0 = time.time()
for rnd in range(ROUNDS):
    idxs = np.random.choice(len(tokens) - SEQ_LEN - 1, BATCH, replace=False)
    for li in range(N_LAYERS):
        s = str(li)
        X_in = []
        X_ctx = []
        X_xatt = []
        X_ln2 = []
        X_gelu = []
        Y_tgt = []
        for idx in idxs:
            ids = tokens[idx:idx + SEQ_LEN]
            nxt = tokens[idx + SEQ_LEN]
            x = (WTE_FIXED[ids] + WPE_FIXED[:SEQ_LEN]).copy()
            for ll in range(li):
                x, _, _ = fwd_layer(x, ll, w)
            x_in_last = x[-1].copy()
            if not np.all(np.isfinite(x_in_last)):
                continue
            _, ctx, xa = fwd_layer(x, li, w)
            ctx_last = ctx[-1].copy()
            xa_last = xa[-1].copy()
            if not np.all(np.isfinite(ctx_last)):
                continue
            if not np.all(np.isfinite(xa_last)):
                continue
            ln2_last = ln_f(xa_last, w[f'ln2_g{s}'], w[f'ln2_b{s}'])
            pre_last = ln2_last @ w[f'W1{s}'].T + w[f'b1{s}']
            gelu_last = gelu_f(pre_last)
            if not np.all(np.isfinite(gelu_last)):
                continue
            target = WTE_FIXED[nxt].copy()
            X_in.append(x_in_last)
            X_ctx.append(ctx_last)
            X_xatt.append(xa_last)
            X_ln2.append(ln2_last)
            X_gelu.append(gelu_last)
            Y_tgt.append(target)
        if len(X_in) < 10:
            continue
        X_in = np.array(X_in, dtype=np.float64)
        X_ctx = np.array(X_ctx, dtype=np.float64)
        X_xatt = np.array(X_xatt, dtype=np.float64)
        X_ln2 = np.array(X_ln2, dtype=np.float64)
        X_gelu = np.array(X_gelu, dtype=np.float64)
        Y = np.array(Y_tgt, dtype=np.float64)
        Y_att = Y - X_in
        Wo_new = solve_ridge(X_ctx, Y_att)
        w[f'Wo{s}'] = Wo_new[:-1].T
        w[f'bo{s}'] = Wo_new[-1]
        Y_ffn = Y - X_xatt
        W2_new = solve_ridge(X_gelu, Y_ffn)
        w[f'W2{s}'] = W2_new[:-1].T
        w[f'b2{s}'] = W2_new[-1]
        Y_pre = Y_ffn @ w[f'W2{s}']
        W1_new = solve_ridge(X_ln2, Y_pre)
        w[f'W1{s}'] = W1_new[:-1].T
        w[f'b1{s}'] = W1_new[-1]
    w = clip_w(w)
    ppl = perplexity(w)
    hist.append(ppl)
    is_best = ''
    if np.isfinite(ppl) and ppl < best_ppl:
        best_ppl = ppl
        best_w = {k: v.copy() for k, v in w.items()}
        is_best = ' ★'
    arrow = '↓' if len(hist) > 1 and ppl < hist[-2] else '↑'
    print(f'  {rnd + 1:<6} {ppl:>8.2f} {best_ppl:>8.2f}  {arrow}{is_best}')
w = best_w
print(f"\n{'=' * 70}")
print(f'  RESULTS')
print(f"{'=' * 70}\n")
print(f'  Start ppl  : {p0:.2f}')
print(f'  Best ppl   : {best_ppl:.2f}')
print(f'  Vocab      : {VS}')
print(f'  Reduction  : {(1 - best_ppl / p0) * 100:.1f}%')
print(f'  Ratio      : {best_ppl / VS:.3f}  (< 1.0 = learned something)\n')
for gp in ['once upon a ', 'the brave ', 'deep in the ']:
    ids_g = [vocab[c] for c in gp if c in vocab]
    gen = list(ids_g)
    for _ in range(120):
        logits, _ = fwd_all(gen[-SEQ_LEN:], w)
        if not np.all(np.isfinite(logits[-1])):
            break
        gen.append(int(np.argmax(logits[-1])))
    out = ''.join((ivocab.get(t, '?') for t in gen))
    print(f"  '{gp}' → {out[len(gp):][:80]}")
print(f'\n  Time: {time.time() - t0:.0f}s')
if best_ppl < VS:
    print(f'\n  ✓ BELOW VOCAB CEILING — learned from text, no gradient descent.')
elif best_ppl < p0:
    print(f'\n  ~ IMPROVED from random — partial learning. More rounds needed.')
else:
    print(f'\n  ! Target formulation needs revision.')
print('=' * 70 + '\n')
