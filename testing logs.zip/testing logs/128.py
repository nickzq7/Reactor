import os, json, time
import numpy as np
import torch
import torch.nn as nn
print('\n' + '=' * 65)
print('  TRAIN MEDIUM MODEL — D=64 on 1000-word TinyStories text')
print('=' * 65)
VOCAB = ['and', 'at', 'back', 'big', 'both', 'cat', 'dog', 'end', 'log', 'looked', 'mat', 'on', 'past', 'ran', 'red', 'sat', 'still', 'the', 'they', 'to', 'together']
w2i = {w: i for i, w in enumerate(VOCAB)}
i2w = {i: w for i, w in enumerate(VOCAB)}
VS = len(VOCAB)
TEXT_1000 = '\nthe cat sat on the mat the dog ran on the log\nthe cat and the dog sat on the big red mat\nthe dog ran past the cat the cat ran back to the mat\nthe dog sat still the cat looked at the dog\nthe dog looked at the cat they both sat on the mat together the end\nthe red cat sat still on the big mat and looked at the log\nthe dog ran back to the mat and sat on it\nthe cat looked at the big red log and ran past it\nboth the cat and the dog looked at the mat together\nthe cat sat at the end and the dog ran back\nthe big dog ran still and the red cat sat on the log\nthey both looked at the mat and ran back to the end\nthe dog and the cat both sat still on the big red mat\nthe cat ran to the log and looked back at the dog\nthe dog looked at the red mat and sat still at the end\nthey ran together to the big mat and both looked at the log\nthe cat sat on the big log and looked at the red mat\nthe dog ran past the mat and back to the end\nboth sat still and looked together at the big red cat\nthe cat and dog ran to the mat and sat at the end\nthe dog sat on the log and the cat ran past the mat\nthey looked at the big red dog and sat still together\nthe cat ran back and the dog looked at the big mat\nboth the dog and the cat sat on the log at the end\nthe big red mat sat still and the cat looked past the log\nthe dog ran to the end and looked back at the cat\nthey both sat on the big red mat and looked together\nthe cat looked at the log and the dog ran past\nthe mat and the log both sat still at the end\nthe red dog sat on the big mat and looked at the cat\nthe cat ran past the log and back to the big mat\nthey both looked at the red mat and sat together at the end\nthe dog sat still on the log and the cat looked at the mat\nthe big cat ran past the dog and back to the red mat\nboth looked at the end and sat still on the big log\nthe cat and the dog ran together past the big red mat\nthey sat on the log and looked at the mat together\nthe red cat ran back to the big mat and sat still\nthe dog looked past the log and ran to the end\nboth the cat and the dog looked at the big red log\nthe mat sat still at the end and they ran back together\nthe cat sat on the big red log and looked at the dog\nthe dog ran past both the mat and the log to the end\nthey both looked at the cat and sat still on the big mat\nthe red mat and the big log both sat at the end together\nthe cat ran back to the log and looked at the still dog\nthe dog sat on the big mat and looked past the red cat\nthey ran together to the end and both sat still on the log\nthe big red dog looked at the cat and sat on the mat\nthe cat looked at the mat and ran back past the log\nboth the dog and the cat sat on the big red end together\nthe mat and the log looked still and the cat ran past\nthe dog ran back to the big red mat and sat at the end\nthey both looked at the log and ran together past the cat\nthe cat sat still on the big mat and looked at the red dog\nthe dog ran past the end and looked back at the big log\nboth sat on the red mat together and looked at the cat\nthe big cat looked at the dog and ran back to the mat\nthey sat still at the end and both looked at the big red log\nthe dog and the cat ran together to the big mat and sat\nthe red log sat still and the cat looked past the big mat\nboth ran back to the end and sat together on the big mat\nthe cat sat on the log and looked at the big red dog\nthe dog ran still and the cat looked at the mat together\nthey both ran past the big red log and sat at the end\nthe mat sat at the end and both the cat and dog looked\nthe big red cat sat still on the log and looked at the dog\nthe dog ran back past the mat and looked at the cat together\nthey sat on the big mat and looked at the red log end\nthe cat ran to the end and sat still on the big log\nboth the dog and the mat sat still and the cat looked\nthe red mat and the big cat both looked at the log together\nthe dog sat past the end and both looked at the big red mat\nthey ran together past the log and sat on the big red mat\nthe cat looked at the end and ran back to the big mat\nthe dog sat still on the red mat and looked at the log\nboth the cat and the dog ran together to the big mat end\nthey looked at the big red mat and sat still together at the end\n'
words = [w for w in TEXT_1000.split() if w in w2i]
toks = [w2i[w] for w in words]
print(f'\n  Vocab size: {VS}')
print(f'  Text length: {len(words)} words')
print(f'  Unique words used: {len(set(words))}')
D = 64
H = 4
NL = 4
K = 8
FFN = D * 4
print(f'\n  Architecture: D={D} H={H} NL={NL} K={K} FFN={FFN}')
print(f'  Context window: {K} tokens (tiny={4})')
cuda_ok = torch.cuda.is_available()
device = torch.device('cuda' if cuda_ok else 'cpu')
print(f'  Device: {device}')
if cuda_ok:
    print(f'  GPU: {torch.cuda.get_device_name(0)}')

class MediumTransformer(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, FFN), nn.GELU(), nn.Linear(FFN, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)
        self._init_weights()

    def _init_weights(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            else:
                nn.init.zeros_(p)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for layer in self.layers:
            xn = layer['ln1'](x)
            a, _ = layer['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + layer['ff'](layer['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T
M = len(toks) - K
X = torch.tensor([toks[i:i + K] for i in range(M)], device=device)
y = torch.tensor([toks[i + 1:i + K + 1] for i in range(M)], device=device)
print(f'\n  Training samples: {M}')
model = MediumTransformer().to(device)
n_params = sum((p.numel() for p in model.parameters()))
print(f'  Parameters: {n_params:,}  (tiny≈{21 * 32 + 4 * 32 + 2 * (32 * 32 * 4 + 128 * 32 + 32 * 128) + 32 * 21:,})')
opt = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=0.001)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=8000, eta_min=0.0001)
loss_fn = nn.CrossEntropyLoss()
print(f"\n  {'Epoch':>7} {'Loss':>8} {'Acc%':>7}  {'LR':>10}")
print(f"  {'─' * 42}")
t0 = time.time()
best_acc = 0.0
best_state = None
for epoch in range(1, 8001):
    model.train()
    opt.zero_grad()
    logits = model(X)
    loss = loss_fn(logits.view(-1, VS), y.view(-1))
    loss.backward()
    opt.step()
    sched.step()
    if epoch % 400 == 0 or loss.item() < 0.005:
        model.eval()
        with torch.no_grad():
            preds = model(X).argmax(-1)
            acc = 100 * (preds == y).float().mean().item()
        lr_now = opt.param_groups[0]['lr']
        print(f'  {epoch:>7} {loss.item():>8.4f} {acc:>6.1f}%  {lr_now:>10.6f}')
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        if loss.item() < 0.005 and acc >= 99:
            print('  ✓ Converged!')
            break
model.load_state_dict(best_state)
model.eval()
with torch.no_grad():
    preds = model(X).argmax(-1)
    final_acc = 100 * (preds == y).float().mean().item()
print(f'\n  FINAL  acc={final_acc:.1f}%  time={time.time() - t0:.1f}s')
Wout = {}
Wout['WTE'] = model.wte.weight.detach().cpu().numpy()
Wout['WPE'] = model.wpe.weight.detach().cpu().numpy()
for l in range(NL):
    layer = model.layers[l]
    ip = layer['attn'].in_proj_weight.detach().cpu().numpy()
    Wout[f'WQ{l}'] = ip[:D, :]
    Wout[f'WK{l}'] = ip[D:2 * D, :]
    Wout[f'WV{l}'] = ip[2 * D:, :]
    Wout[f'WO{l}'] = layer['attn'].out_proj.weight.detach().cpu().numpy()
    Wout[f'W1{l}'] = layer['ff'][0].weight.detach().cpu().numpy()
    Wout[f'b1{l}'] = layer['ff'][0].bias.detach().cpu().numpy()
    Wout[f'W2{l}'] = layer['ff'][2].weight.detach().cpu().numpy()
    Wout[f'b2{l}'] = layer['ff'][2].bias.detach().cpu().numpy()
    Wout[f'LN1g{l}'] = layer['ln1'].weight.detach().cpu().numpy()
    Wout[f'LN1b{l}'] = layer['ln1'].bias.detach().cpu().numpy()
    Wout[f'LN2g{l}'] = layer['ln2'].weight.detach().cpu().numpy()
    Wout[f'LN2b{l}'] = layer['ln2'].bias.detach().cpu().numpy()
Wout['LNfg'] = model.ln_f.weight.detach().cpu().numpy()
Wout['LNfb'] = model.ln_f.bias.detach().cpu().numpy()
_dir = os.path.dirname(os.path.abspath(__file__))
np.savez(os.path.join(_dir, 'medium_weights.npz'), **Wout)
with open(os.path.join(_dir, 'medium_meta.json'), 'w') as f:
    json.dump({'vocab': VOCAB, 'w2i': w2i, 'i2w': {str(k): v for k, v in i2w.items()}, 'VS': VS, 'D': D, 'H': H, 'NL': NL, 'K': K, 'FFN': FFN, 'acc': float(final_acc), 'text_len': len(words)}, f, indent=2)
print(f'\n  Saved: medium_weights.npz')
print(f'  Saved: medium_meta.json')
print(f'  Keys:  {list(Wout.keys())[:8]} ...')
print(f'\n  GENERATION TEST:')

def gen(seed_words, n=10):
    ids = [w2i.get(w, 0) for w in seed_words[-K:]]
    out = list(seed_words)
    model.eval()
    with torch.no_grad():
        for _ in range(n):
            inp = torch.tensor([ids[-K:]], device=device)
            lg = model(inp)[0]
            p = int(lg[-1].argmax())
            out.append(i2w[p])
            ids.append(p)
    return ' '.join(out)
for seed in [['the', 'cat', 'sat', 'on', 'the', 'mat', 'the', 'dog'], ['they', 'both', 'looked', 'at', 'the', 'big', 'red', 'mat'], ['the', 'dog', 'ran', 'past', 'the', 'cat', 'and', 'sat']]:
    print(f'  {gen(seed)}')
print(f'\n  ✓ Done. Now run: surgery_v8_graft.py')
print(f'  Tiny model:  D=32, NL=2, acc=79.4%')
print(f'  Medium model: D=64, NL=4, acc={final_acc:.1f}%\n')
