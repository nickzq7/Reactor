import subprocess, sys

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('torch')
ensure('transformers')
ensure('numpy')
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  TEST 3.1 — CRYSTAL RESONANCE FIX (CONTEXT WINDOW)')
print('  Testing if Cross-Token Context closes the 0.638 gap.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\n  Loading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
n_layers = model.config.num_layers
CTX = 8
print(f'  Layers={n_layers}  Context Window={CTX} tokens')
starts = ['Once upon a time', 'The brave knight', 'In a dark cave', 'A little bird flew', 'The magic wand', 'Deep in the ocean', 'She opened the door', 'He looked up and', 'The old wizard', 'A friendly dragon', 'The little rabbit', 'One sunny day', 'The king and queen', 'A small boy named', 'The magical forest', 'The tiny mouse', 'A wise old owl', 'The giant bear']
print('\n  Generating sequences (Target ~4000 tokens for safe math)...')
all_ids = []
with torch.no_grad():
    for s in starts:
        for temp in [0.7, 0.9, 1.1]:
            torch.manual_seed(hash(s) % 10000 + int(temp * 10))
            inp = tokenizer.encode(s, return_tensors='pt')
            out = model.generate(inp, max_new_tokens=60, do_sample=True, temperature=temp, top_p=0.9, pad_token_id=tokenizer.eos_token_id)
            all_ids.append(out)
store = {l: [] for l in range(n_layers)}

def get_hook(l):

    def hook(m, i, o):
        store[l].append(o.detach().float().numpy())
    return hook
hooks = [model.transformer.h[l].mlp.act.register_forward_hook(get_hook(l)) for l in range(n_layers)]
print('  Hooking GeLU crystals across all generated sequences...')
with torch.no_grad():
    for ids in all_ids:
        model(ids)
for h in hooks:
    h.remove()
X_tok = []
X_ctx = []
Y_tgt = {l: [] for l in range(1, n_layers)}
for b in range(len(store[0])):
    seq_len = store[0][b].shape[1]
    for t in range(CTX - 1, seq_len):
        X_tok.append(store[0][b][0, t, :])
        X_ctx.append(store[0][b][0, t - CTX + 1:t + 1, :].flatten())
        for l in range(1, n_layers):
            Y_tgt[l].append(store[l][b][0, t, :])
X_tok = np.array(X_tok)
X_ctx = np.array(X_ctx)
Y_tgt = {l: np.array(Y_tgt[l]) for l in range(1, n_layers)}
N = len(X_tok)
N_tr = int(N * 0.8)
print(f'  Collected {N} valid window samples.')
print(f'  X_tok (1 token)  features: {X_tok.shape[1]}')
print(f'  X_ctx ({CTX} tokens) features: {X_ctx.shape[1]}')

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 1e-10 else 1.0

def fit_eval(X, Y):
    Xb_tr = np.c_[X[:N_tr], np.ones(N_tr)]
    Xb_te = np.c_[X[N_tr:], np.ones(N - N_tr)]
    W = np.linalg.lstsq(Xb_tr, Y[:N_tr], rcond=None)[0]
    return r2(Xb_te @ W, Y[N_tr:])
print('\n' + '=' * 70)
print('  RESULTS: IS THE FUTURE LOCKED IN AT LAYER 0?')
print('=' * 70)
print(f"  {'Layer':<6} {'gelu_0(1_tok) Baseline':<25} {'gelu_0(8_toks) Window'}")
print(f"  {'-' * 65}")
for l in range(1, n_layers):
    r_tok = fit_eval(X_tok, Y_tgt[l])
    r_ctx = fit_eval(X_ctx, Y_tgt[l])
    diff = r_ctx - r_tok
    mark = f'↑ (+{diff:.3f})' if diff > 0.05 else '~'
    print(f'  {l:<6} R² = {r_tok:<20.4f} R² = {r_ctx:.4f}  {mark}')
print('\n' + '=' * 70)
print('  DIAGNOSIS OF THE GAP:\n  \n  If Context Window jumps to ~0.90+:\n    The crystal resonance is proven. The future IS locked in at Layer 0.\n    But it requires the SEQUENCE of crystals, because Attention \n    rotates the crystal based on its neighbors.\n  \n  If Context Window still drops (e.g. ~0.70):\n    Dynamic Attention (softmax) is irreducible by a flat linear window.\n    The rotation angle is heavily non-linear and depends strictly \n    on the dynamic attention scores. \n    This means we cannot skip middle layers with a simple linear W.\n    We must respect the chain. \n')
print('=' * 70 + '\n')
