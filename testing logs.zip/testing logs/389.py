import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
print(f'D={D}  Layers={n_layers}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss = np.sum((pred - true) ** 2)
    st = np.sum((true - true.mean()) ** 2)
    return float(1 - ss / st) if st > 1e-12 else 1.0

def max_err(a, b):
    return float(np.max(np.abs(np.array(a, dtype=np.float64) - np.array(b, dtype=np.float64))))
texts = ['Once upon a time there was a little girl named', 'The farmer woke up early and fed all his', 'Deep in the forest a family of bears lived', 'The brave knight rode his white horse toward the', 'Sophie loved books more than anything else in', 'The village held a harvest festival every autumn', 'Tommy was afraid of the dark and could not', 'Marco sailed across the vast blue ocean every', 'The mountains were cold and the children learned', 'She smiled because today was her birthday', 'Two friends shared every secret since their', 'A rabbit lived under the roots of the old', 'The grandmother welcomed every lost traveler', 'Sam found a puppy hiding under the old', 'The dragon had never spoken before the', 'In the ocean a fish dreamed of the world', 'The clock had been silent for twenty years before', 'A small seed grew slowly into a mighty', 'The painter stared at the blank canvas before', 'Every evening the grandfather told his grandchildren', 'The wind carried the sound of bells from the', 'A boy named Jack found a magical stone near', 'The old library held secrets no one had read', 'She opened the door and saw the garden full', 'He could not remember where he had left the', 'The stars above the quiet village were very bright', 'Lily packed her small bag and walked toward the', 'The teacher wrote one word on the board that', 'When the rain stopped the children ran outside to', 'The captain looked at the map and chose the', 'A small dragon lived near a warm mountain cave', 'The baker made fresh bread every single morning', 'Two children found a treasure map under the old', 'The princess refused to stay inside the tower', 'An old sailor told stories by the evening fire', 'The forest was quiet until the birds began to', 'She had always wanted to learn how to make', 'The king called all his knights to the great', 'A little boy found a strange door in the', 'The scientist worked late into the night to find', 'The cat sat quietly by the window all day', 'A young girl named Anna loved to paint beautiful', 'The old man walked slowly through the autumn', 'Every morning the children gathered near the big', 'The dog ran fast through the open green', 'In the small town everyone knew each other very', 'The boy opened the box and found something', 'A loud noise woke the whole village that', 'The river flowed gently through the peaceful quiet', 'She took the book from the shelf and began']
MAX_LEN = 12
print(f'\nCollecting per-token hidden states (L={MAX_LEN})...')
HL = {li: [] for li in range(n_layers + 1)}
cur = {}
hooks = []

def emb_h(m, i, o):
    cur[0] = o.detach().float()[0].numpy().copy()
hooks.append(model.transformer.wte.register_forward_hook(emb_h))
for li in range(n_layers):

    def make_h(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur[l + 1] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].register_forward_hook(make_h(li)))
valid = 0
with torch.no_grad():
    for text in texts:
        cur.clear()
        toks = tokenizer(text, return_tensors='pt', max_length=MAX_LEN, truncation=True, padding='max_length')
        L = toks['input_ids'].shape[1]
        if L < MAX_LEN:
            continue
        model(**toks)
        for li in range(n_layers + 1):
            if li in cur:
                for t in range(MAX_LEN):
                    HL[li].append(cur[li][t].copy())
        valid += 1
for h in hooks:
    h.remove()
N_seq = valid
N_tok = valid * MAX_LEN
print(f'  Sequences: {N_seq}  Tokens: {N_tok}')
H = {li: np.array(HL[li], dtype=np.float64) for li in range(n_layers + 1)}
print(f"\n{'=' * 70}")
print(f'  TEST A — RANK-k CORRECTION FIT')
print(f'  delta_l = U_l @ (V_l^T @ h_prev)')
print(f'  Fit via SVD of delta_l prediction matrix.')
print(f'  Find minimum k where R²=1.000 (or plateau).')
print(f"{'=' * 70}\n")
split = int(N_seq * 0.8) * MAX_LEN
layer_results = {}
for li in range(1, n_layers + 1):
    h_prev = H[li - 1]
    h_curr = H[li]
    delta = h_curr - h_prev
    Xtr = H[li - 1][:split]
    Ytr = delta[:split]
    Xte = H[li - 1][split:]
    Yte = delta[split:]
    B_full, _, _, _ = np.linalg.lstsq(Xtr, Ytr, rcond=None)
    U, S, Vt = np.linalg.svd(B_full, full_matrices=False)
    k_vals = [1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24, 32, 48, 64]
    r2_vals = []
    for k in k_vals:
        B_k = U[:, :k] @ np.diag(S[:k]) @ Vt[:k, :]
        pred = Xte @ B_k.T
        rv = r2(pred.flatten(), Yte.flatten())
        r2_vals.append(rv)
    layer_results[li] = (B_full, U, S, Vt, r2_vals)
print(f"  {'Layer':<8} " + '  '.join([f'k={k:<5}' for k in k_vals]))
print(f"  {'─' * 85}")
for li in range(1, n_layers + 1):
    _, _, _, _, r2_vals = layer_results[li]
    row = f'  {li:<8} ' + '  '.join([f'{rv:<7.4f}' for rv in r2_vals])
    print(row)
print(f'\n  Min k for R²>0.99:')
print(f"  {'Layer':<8} {'min_k':<8} {'R²_at_k':<12} {'Full_R²'}")
print(f"  {'─' * 40}")
for li in range(1, n_layers + 1):
    _, _, _, _, r2_vals = layer_results[li]
    min_k = None
    for i, k in enumerate(k_vals):
        if r2_vals[i] > 0.99:
            min_k = k
            min_r = r2_vals[i]
            break
    if min_k is None:
        min_k = k_vals[-1]
        min_r = r2_vals[-1]
    full_r = r2_vals[-1]
    print(f'  {li:<8} {min_k:<8} {min_r:<12.6f} {full_r:.6f}')
print(f"\n{'=' * 70}")
print(f'  TEST B — EXACTNESS OF LOW-RANK FIT')
print(f'  At full rank: delta = h_prev @ B^T: max_err = ?')
print(f'  At k=16: max_err = ?')
print(f'  R²=1.000 + max_err=0 = exact law.')
print(f'  R²<1.000 or max_err>0 = approximation only.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} {'R²_full':<14} {'max_err_full':<18} {'R²_k16':<14} {'max_err_k16'}")
print(f"  {'─' * 65}")
for li in range(1, n_layers + 1):
    B_full, U, S, Vt, r2_vals = layer_results[li]
    Xte = H[li - 1][split:]
    Yte = (H[li] - H[li - 1])[split:]
    pred_full = Xte @ B_full.T
    r2_full = r2(pred_full, Yte)
    me_full = max_err(pred_full, Yte)
    k = min(16, D)
    B_k = U[:, :k] @ np.diag(S[:k]) @ Vt[:k, :]
    pred_k = Xte @ B_k.T
    r2_k = r2(pred_k, Yte)
    me_k = max_err(pred_k, Yte)
    status = '✓✓ EXACT' if r2_full > 0.9999 and me_full < 0.001 else '✓ NEAR' if r2_full > 0.999 else '~ APPROX' if r2_full > 0.95 else '✗'
    print(f'  {li:<8} {r2_full:<14.6f} {me_full:<18.6f} {r2_k:<14.6f} {me_k:.6f}  {status}')
print(f"\n{'=' * 70}")
print(f'  TEST C — COMPOSED TRANSFORM: M @ h_0 = h_final')
print(f'  M = product_l (I + B_l)')
print(f'  If h_final = M @ h_0 exactly: entire model = one matrix.')
print(f"{'=' * 70}\n")
I = np.eye(D, dtype=np.float64)
M = I.copy()
for li in range(1, n_layers + 1):
    B_full = layer_results[li][0]
    M = (I + B_full.T) @ M
pred_final = H[0] @ M.T
rv = r2(pred_final, H[n_layers])
me = max_err(pred_final, H[n_layers])
print(f'  Composed M (full rank per layer):')
print(f'  h_final = M @ h_0: R²={rv:.6f}  max_err={me:.6f}')
print(f"  {('✓✓ EXACT — entire model = one matrix.' if rv > 0.9999 else f'R²={rv:.4f} — partial')}")
M_k = I.copy()
k = 16
for li in range(1, n_layers + 1):
    B_full, U, S, Vt, _ = layer_results[li]
    B_k = U[:, :k] @ np.diag(S[:k]) @ Vt[:k, :]
    M_k = (I + B_k.T) @ M_k
pred_k = H[0] @ M_k.T
rv_k = r2(pred_k, H[n_layers])
me_k = max_err(pred_k, H[n_layers])
print(f'\n  Composed M (rank-{k} per layer):')
print(f'  h_final = M_k @ h_0: R²={rv_k:.6f}  max_err={me_k:.6f}')
print(f"  {('✓✓ EXACT' if rv_k > 0.999 else f'~ PARTIAL R²={rv_k:.4f}')}")
print(f"\n{'=' * 70}")
print(f'  TEST D — SINGULAR VALUE SPECTRUM OF B_l')
print(f'  Hard cutoff = law. Values S[k] ≈ 0 after rank k.')
print(f'  Gradual decay = no hard cutoff = approximation only.')
print(f"{'=' * 70}\n")
print(f"  {'Layer':<8} " + '  '.join([f'σ{i + 1:<5}' for i in range(10)]))
print(f"  {'─' * 75}")
for li in range(1, n_layers + 1):
    _, U, S, Vt, _ = layer_results[li]
    S_norm = S / S[0]
    row = f'  {li:<8} ' + '  '.join([f'{s:<7.4f}' for s in S_norm[:10]])
    print(row)
print(f'\n  Ratio S[k]/S[0] at specific k:')
print(f"  {'Layer':<8} {'S[12]/S[0]':<14} {'S[16]/S[0]':<14} {'S[32]/S[0]'}")
print(f"  {'─' * 45}")
for li in range(1, n_layers + 1):
    S = layer_results[li][2]
    S_norm = S / S[0]
    print(f'  {li:<8} {S_norm[min(11, len(S_norm) - 1)]:<14.4f} {S_norm[min(15, len(S_norm) - 1)]:<14.4f} {S_norm[min(31, len(S_norm) - 1)]:.4f}')
print(f"\n{'=' * 70}")
print(f'  TEST E — ARE U_l, V_l SHARED ACROSS LAYERS?')
print(f'  delta_l = U_l @ (V_l^T @ h)')
print(f'  If U_l = U for all l: output directions = universal.')
print(f'  If V_l = V for all l: input reading = universal.')
print(f"{'=' * 70}\n")
k = 12
U_bases = []
V_bases = []
for li in range(1, n_layers + 1):
    _, U, S, Vt, _ = layer_results[li]
    U_bases.append(U[:, :k])
    V_bases.append(Vt[:k, :].T)
print(f'  U alignment matrix (top-{k} columns):')
print(f"  {'':8} " + ' '.join([f'L{i + 1:<5}' for i in range(n_layers)]))
for i in range(n_layers):
    row = f'  L{i + 1:<7} '
    for j in range(n_layers):
        align = np.linalg.norm(U_bases[i].T @ U_bases[j], 'fro') / k
        row += f'{align:.3f}  '
    print(row)
print(f'\n  Diagonal = 1.000 (self).')
print(f'  Off-diagonal close to 1.000 = shared U basis across layers.')
print(f'  Off-diagonal ≈ 0 = each layer uses different output directions.')
print(f"\n{'=' * 70}")
print(f'  W LAW — LOW-RANK CORRECTION LAW')
print(f"{'=' * 70}")
print(f"\n  WHAT WE FOUND (TEST D previous):\n    Every layer: delta_l is rank 12-16 of D=64. Always.\n    delta_l is LARGE (ratio=1.0-1.2). Not noise. Not passthrough.\n    \n  WHAT THIS MEANS:\n    Each layer = a large correction.\n    That correction lives in only 12-16 dimensions.\n    Other 48-52 dimensions = unchanged by that layer.\n    \n  THE LAW (if TEST B confirms exactness):\n    delta_l = U_l @ (V_l^T @ h_{l - 1})   exactly.\n    U_l: D×k = output directions for layer l.\n    V_l: D×k = what layer l reads from h.\n    k = 12-16.\n    \n  IMPLICATION:\n    Each layer's compute = V_l^T @ h (k dot products, cheap)\n                         + U_l @ result (k-to-D expansion)\n    Cost: O(D×k) not O(D×D). k/D = 0.2. 5x speedup per layer.\n    \n    Full model: compose 8 such transforms.\n    h_final = M @ h_0 where M = product of (I + U_l V_l^T).\n    \n  SCALE TO 70B:\n    If k/D = 0.2 holds: k ≈ 1638 for D=8192.\n    Each layer: 2 × D × k = 2 × 8192 × 1638 ≈ 26.8M params.\n    vs full: D² = 67M per weight matrix, × 4 matrices = 268M per layer.\n    \n    If law holds: 10x compression per layer. Exact.\n    70B → 7B effective. Runs on 28GB. Single GPU.\n")
print('=' * 70 + '\n')
