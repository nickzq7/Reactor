import numpy as np
import torch
import math
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
print('\n' + '=' * 70)
print('  W-KERNEL TRAINER v4 — 500 TOKEN TEXTS')
print('  Full story paragraphs. N >> 21440 target.')
print('=' * 70)
MODEL_NAME = 'roneneldan/TinyStories-1M'
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
model_ref = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model_ref.eval()
n_layers = model_ref.config.num_layers
n_heads = model_ref.config.num_attention_heads
D = model_ref.config.hidden_size
head_dim = D // n_heads
QUAD_DIM = D + D * (D + 1) // 2

def ln_np(x, g, b, eps=1e-05):
    x = x.astype(np.float64)
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * g + b

def gelu_np(x):
    x = x.astype(np.float64)
    return 0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))

def softmax_np(x):
    x = x.astype(np.float64)
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)

def quad_kernel(x):
    x = np.array(x, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(1, -1)
    N, d = x.shape
    i, j = np.triu_indices(d)
    return np.hstack([x, x[:, i] * x[:, j]])

def solve_ridge(Phi, Y, lam=1e-06):
    Phi = np.array(Phi, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    Pb = np.hstack([Phi, np.ones((len(Phi), 1))])
    A = Pb.T @ Pb + lam * np.eye(Pb.shape[1])
    W = np.linalg.solve(A, Pb.T @ Y)
    Yp = Pb @ W
    ss_res = np.sum((Y - Yp) ** 2)
    ss_tot = np.sum((Y - Y.mean(0)) ** 2)
    r2 = float(1 - ss_res / ss_tot) if ss_tot > 1e-15 else 1.0
    return (W, r2)
LONG_STORIES = ['Once upon a time, in a small village near a big forest, there lived a little girl named Lily. Lily loved to explore the woods near her home. One sunny morning, she packed a small bag with some bread and cheese and set off into the trees. The birds were singing and the sunlight came through the leaves in golden beams. Lily followed a little path that wound between the tall oaks and the flowering bushes. Soon she came to a stream where the water was clear and cold. She sat on a mossy stone and ate her lunch while watching the fish swim by. A small frog jumped onto the stone beside her and looked up with its big golden eyes. Lily smiled and said hello to the frog. It croaked once and jumped back into the water with a splash. After lunch Lily kept walking deeper into the forest. The path grew narrower and the trees grew taller. She heard a rustling sound in the bushes and stopped. Out came a small rabbit with long soft ears. The rabbit looked at Lily and then hopped over to sniff her shoes. Lily stood very still so she would not scare it. The rabbit seemed to decide she was friendly and sat down right beside her foot. Lily reached down slowly and gave it a gentle pat on the head. Then the rabbit hopped away into the green shadows. Lily felt very happy. She turned around and walked back home before the sun went down. When she got home her mother was making soup and the whole cottage smelled wonderful. Lily told her mother about the frog and the rabbit and her mother smiled and said the forest was full of magic for those who knew how to look. Lily ate two big bowls of soup and went to bed early dreaming of all the creatures she might meet on her next walk.', 'Deep in the mountains there was a small dragon named Ember. Ember was not like the big fierce dragons in the old stories. He was small enough to sit on your shoulder and he breathed tiny puffs of flame that were just enough to light a candle. Ember lived in a cave on a rocky hillside above a peaceful valley. Every morning he would fly down to the village to say hello to the baker and get a warm bun fresh from the oven. The baker was a round cheerful woman named Rosa who was never afraid of dragons. She would scratch Ember behind his scaly ears and he would purr like a cat. All the children in the village loved Ember. They would run out of their houses when they heard the sound of his wings. He was careful never to breathe fire near the children but sometimes he would light the lanterns in the market square when the evenings grew dark. One autumn a great storm came to the valley. The rain was heavy and the wind bent the trees sideways. A big old oak at the edge of the village split in half and fell across the road blocking the way for the farmers who needed to bring their carts to market. The men of the village tried to move the tree but it was too heavy. Then Ember had an idea. He flew up high above the tree and breathed careful little flames at just the right spots. Slowly the fallen oak caught fire only where Ember aimed and after a long careful hour the tree was reduced to ash and the road was clear again. Everyone cheered and Rosa made Ember a special cake in the shape of a dragon. He ate it in one happy bite.', 'There was once a boy named Sam who lived beside the sea. Every day after school Sam would run down to the beach and look for interesting things the waves had brought in. He had a shelf in his room full of shells and sea glass and smooth stones of every colour. One afternoon Sam found something he had never seen before. It was a small bottle made of green glass sealed with a cork stopper. Inside there was a rolled piece of paper. Sam pulled out the cork and carefully removed the paper. On it was a drawing of a map showing an island with a large X marked in the middle. Around the edges of the map there were drawings of sea creatures and a compass rose with the directions marked in faded ink. Sam showed the map to his grandmother who lived next door. She was very old and knew a great deal about the sea. She looked at the map for a long time with her reading glasses on. Then she smiled and said the island on the map was one she had heard of as a child. It was said to be a place where the fish were so plentiful you could almost walk across the water on their backs. She did not know where it was exactly but she said if the map was real then whoever found that bottle had sailed very far. Sam kept the map in a special wooden box. He spent many evenings looking at it and imagining what the island might look like. He decided that when he was old enough he would build a boat and follow the map and find the island for himself. He would bring his grandmother with him if she was still well enough to travel. She deserved to see it more than anyone.', 'In the town of Millbrook there was a library that everyone loved. It was an old stone building covered in ivy with tall windows that let in the morning light. The librarian was a quiet woman named Miss Wren who wore her hair in a silver bun and always had a pencil tucked behind her ear. Miss Wren knew where every book was kept and she could find exactly the right story for whoever came through her door. Children came every Saturday morning and Miss Wren would read aloud to them in the big armchair by the window. She did all the voices herself and was particularly good at dragons and old witches and brave small animals. One winter a pipe burst in the ceiling of the back room and water poured down onto the oldest books. Many of them were damaged beyond repair. The whole town was very sad. Miss Wren worked day and night to save as many books as she could. She laid them out on tables and spread their pages gently and dried them with a fan. The children came to help and the mayor himself came to see what could be done. In the end most of the books were saved though some had wrinkled pages and faded covers that could never be made right again. The town held a fundraiser and bought new books to replace the ones that were lost. On the day the new books arrived Miss Wren stood at the door of the library and welcomed each box like an old friend. The children helped unpack and put them on the shelves and by the end of the day the library was full again and Miss Wren was smiling her quiet smile.', 'A young fox named Riku lived at the edge of a meadow with his mother and two sisters. Riku was quick and clever but he was also very curious which sometimes got him into trouble. One spring morning Riku went exploring while his mother was sleeping. He found a path he had never followed before and followed it until he reached a farm with a red barn and a vegetable garden behind a low fence. The garden was full of green things and the smell of fresh earth. Riku squeezed under the fence and walked between the rows of vegetables sniffing everything. He did not mean to do any harm. He was just curious. But the farmer saw him from the kitchen window and came out shouting and waving a broom. Riku ran as fast as he could back under the fence and down the path and all the way home where he lay panting under a bush. His mother found him there and asked what had happened. When he told her she was not angry only thoughtful. She said the farmer had worked very hard to grow those vegetables and that Riku should be more careful about going where he was not invited. The next day Riku went back to the farm but this time he sat outside the fence at a safe distance. The farmer came out and stood looking at him. Riku sat very still and looked back. After a moment the farmer went inside and came back with a piece of bread which he tossed over the fence. Riku ate it carefully and then sat down again. The farmer nodded once and went back to his work. After that they had a kind of agreement. Riku never entered the garden again and the farmer always left a small piece of something by the fence post.', "High on a hill there was a windmill that had stood for two hundred years. The old miller who kept it was named Otto and he had run the mill for forty of those years. Every morning he climbed the wooden stairs inside the mill to check the great grinding stones and oil the gears and watch the long wooden sails turn in the wind. The flour from his mill was the finest in the region and bakers from many villages came to buy it. Otto lived alone but he was not lonely. He talked to the mill as if it were a friend and he said the mill talked back in its own language of creaks and groans and the steady whum of the turning sails. One summer the wind died. For three weeks not a breath of air moved in the valley. The sails stood still and the grinding stones were silent. Otto swept the floors and mended the fences and waited. The bakers grew anxious and the villagers worried. On the twenty-second day Otto climbed to the top of the mill at dawn and sat watching the sky. Just as the sun came up a small cool wind brushed his cheek. He closed his eyes and waited. The wind grew stronger. The sails moved once and stopped. Then they turned again and kept turning. By noon the mill was running at full speed and the sound of the stones filled the valley. Otto laughed out loud which was something he almost never did. He ground twice as much flour that week to make up for what had been lost and he never charged the bakers extra for the delay because he said the wind was not anyone's fault.", 'Once there was a little cloud named Wisp who floated above the plains and never stayed in one place for long. All the other clouds were large and grey and full of rain but Wisp was small and white and light as a feather. The big clouds looked down at Wisp and shook their heads. They said a cloud that could not make rain was no use at all. Wisp felt sad about this but kept floating and watching the world below. One very hot summer the sun shone for weeks without rest. The rivers grew shallow and the grass turned yellow and the animals were thirsty. The big clouds had all drifted to the mountains and there was nothing above the plains but blue sky and Wisp. Wisp wanted to help but was too small to make real rain. Then Wisp had an idea. During the hottest part of the day Wisp floated directly in front of the sun and made a small patch of shade below. It was just a little shade but a tired old horse standing in a field walked slowly over and stood in it. Then a dog came and then a child who had been walking a long way. Wisp stayed very still and kept the shade in place for as long as possible each day. After many days the wind shifted and the big clouds returned and the rain came. But by then all the animals and people in the valley had come to know where to find a small cool rest in the worst of the heat. When the big clouds saw what Wisp had done they said nothing but they left a gap in their formation and from then on Wisp always had a place among them.', 'There was a girl named Mara who could hear the rain. Not just the sound of it against the window but what it was saying. When a soft rain fell she heard it whispering old stories. When a heavy rain fell it told her about the mountains it had come from and the rivers it would return to. Mara did not tell anyone about this because she was not sure they would believe her. But she spent a great deal of time sitting near windows on rainy days listening. One autumn a strange drought came to her region. No rain had fallen in two months and the wells were running dry. The farmers worried and the animals were thin. Mara sat at her window and watched the sky but there was nothing to hear. One night she had a dream in which the rain told her there was a spring hidden under a large flat rock at the top of the eastern hill. In the morning she told her father about the dream. He was a practical man but he loved his daughter and agreed to climb the hill with her. They found the flat rock just where the dream had said. Her father called three neighbors and together they moved the rock. Beneath it the earth was dark and wet and after a moment water began to well up from below. It was not a large spring but it was clean and cold and steady. By evening everyone in the village knew about it. They built a small stone channel to carry the water down the hill to a trough where the animals could drink. Mara said nothing about the rain or her dream. She just smiled and looked up at the sky and waited for the next time it would speak to her.', "In a coastal town there was a lighthouse keeper named Finn who had tended the light for twenty years. Every night Finn climbed the spiral stairs to the lamp room and made sure the great lens was turning and the light was burning bright. Ships from many countries had passed safely through the rocky channel because of Finn's light. Finn had a logbook in which he recorded the weather and the ships he saw and anything unusual that happened. Over twenty years the logbook had grown to fill twelve thick volumes. One winter night a fierce storm drove a cargo ship onto the rocks just south of the lighthouse. Finn saw it happen and immediately rang the alarm bell that sent the rescue boat out from the harbor. He kept his light burning at full power to guide the rescuers and the survivors back to shore. All the sailors were saved but the ship was lost and its cargo sank to the bottom of the channel. In the morning when the storm had passed Finn walked down to the rocks and looked at the wreck. Among the debris washed ashore he found a small waterproof case. Inside was a compass and a letter in a language he did not know. He kept the compass on the windowsill of the lamp room and over the following months he asked every sailor who came to the lighthouse if they could read the letter. Finally a ship from the north arrived and the captain read the letter aloud. It was from a sailor to his daughter saying he was on his way home. Finn asked the captain to take the letter and the compass and find the sailor's daughter if he could. The captain agreed and sailed away with them the next morning.", 'There was a baker in the city of Thornwall whose bread was famous throughout the land. Her name was Petra and she had been baking since she was old enough to stand at a table. Her bakery was on a narrow street in the old part of the city and every morning before dawn she lit the oven and began her work. People came from far away to buy her loaves and her rolls and the twisted sweet bread she made on festival days. One year a new bakery opened at the other end of the street. The new baker had a big bright shop with glass windows and a sign in gold letters. He made bread by machine and his loaves were all exactly the same size and shape. Many people went to the new shop because it was modern and the bread was cheaper. Petra kept doing what she had always done. She did not try to compete with the new baker and she did not change her recipes or buy a machine. Her bread still came out of the oven slightly different each time because it was made by hand and that was how she liked it. Over time her regular customers stayed loyal and some of the people who had gone to the new shop came back because they missed the taste of bread made by a person who cared. Petra never said anything against the new baker. She sent him a loaf of her twisted sweet bread on the day his shop opened. He sent back a polite note. They were never friends but they were always civil and the street was better for having both of them on it. Petra baked until she was very old and when she finally retired her daughter took over the bakery and kept all the same recipes.', 'A young elephant named Tulo lived with her herd on the wide plains below a long ridge of hills. Tulo was the youngest and smallest of the herd and she stayed close to her mother and her aunts as they walked the paths they had always walked to water and to the groves of trees they loved to rest under in the heat of the day. One dry season the water hole the herd always used was nearly empty. The older elephants were worried. The matriarch whose name was Nana stood at the edge of the hole and looked at the muddy water for a long time. Then she turned and began walking in a direction Tulo had never gone before. The herd followed without question because they trusted Nana. They walked through the night and by morning they reached a wide river that Tulo had never seen. The water was cool and deep and there was green grass on the banks. Tulo ran into the water up to her belly and blew water over her back and felt the hot dry feeling leave her skin. The herd stayed at the river for three days. Before they left Nana stood on the bank and looked back in the direction they had come as if memorizing the path. Tulo stood beside her and looked too trying to learn what Nana was learning. She did not know then that one day she would be the one the herd looked to when the water holes ran dry. But she was paying attention and that was how it began.', 'On the edge of a small town there was a garden that no one owned. It had been planted long ago by someone no one could remember and over the years it had grown wild and wonderful. There were apple trees and rose bushes and beds of lavender and mint that spread across the paths. In summer bees filled the air and the smell of flowers drifted through the whole neighborhood. Children played in it and old people sat on the stone bench near the apple tree and read their books. One day a man came and put up a sign saying the land had been sold and a building would be constructed there. The neighborhood was very upset. They held a meeting in the community hall and talked for a long time about what to do. One woman suggested they ask the new owner if they could buy the garden back. Another man said they should have a petition signed by everyone in the neighborhood. A young girl who had grown up playing under those apple trees said quietly that maybe the new owner had never seen the garden in summer and if he had he might feel differently. So they invited the owner to come and walk through the garden on a warm July afternoon. He came in his business clothes expecting to see an empty lot. What he found instead was the bees and the lavender and the children playing and the old people on the bench. He stood for a long time without speaking. In the end he agreed to sell the land to the neighborhood at the price he had paid for it. He kept only a small part at the corner where he planted his own roses the following spring.']
TEST_PROMPTS = ['The little fox found a shiny stone by the river', 'Once a kind farmer helped a lost baby deer', 'She climbed the tall tree and saw the whole village', 'A brave boy sailed across the dark stormy sea', 'The old wizard gave the child a glowing lantern', 'A rabbit and a turtle became the best of friends', 'The queen looked out her window at the falling snow', 'He woke up early and saw the first light of dawn', 'A small seed grew into the tallest tree in the land', 'The sleepy bear found a cave and curled up inside']
SEQ_WINDOW = 16
BEST_LAM = 1e-06
wte = model_ref.transformer.wte.weight.detach().numpy()
wpe = model_ref.transformer.wpe.weight.detach().numpy()
print(f'\n  {len(LONG_STORIES)} long stories, window={SEQ_WINDOW}')
print(f'  Each story ≈ 200-250 tokens → ~230 windows per story')
print(f'  Expected N ≈ {len(LONG_STORIES) * 230}')
print(f'  Target N >> {10 * QUAD_DIM} = {10 * QUAD_DIM}')
print(f'\n  Collecting data (this will take a while)...')
t0 = time.time()
data = {li: {'ln2': [], 'delta_ffn': [], 'context': [], 'delta_att': []} for li in range(n_layers)}
total_seqs = 0
with torch.no_grad():
    for story_idx, story in enumerate(LONG_STORIES):
        ids = tokenizer.encode(story)
        if len(ids) < SEQ_WINDOW + 1:
            continue
        for start in range(0, len(ids) - SEQ_WINDOW, 2):
            ids_use = ids[start:start + SEQ_WINDOW]
            T = len(ids_use)
            x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
            for li in range(n_layers):
                blk = model_ref.transformer.h[li]
                ln1w = blk.ln_1.weight.detach().numpy()
                ln1b = blk.ln_1.bias.detach().numpy()
                ln2w = blk.ln_2.weight.detach().numpy()
                ln2b = blk.ln_2.bias.detach().numpy()
                att = blk.attn.attention
                Wq = att.q_proj.weight.detach().numpy()
                Wk = att.k_proj.weight.detach().numpy()
                Wv = att.v_proj.weight.detach().numpy()
                Wo = att.out_proj.weight.detach().numpy()
                bo = att.out_proj.bias.detach().numpy()
                W1 = blk.mlp.c_fc.weight.detach().numpy()
                b1 = blk.mlp.c_fc.bias.detach().numpy()
                W2 = blk.mlp.c_proj.weight.detach().numpy()
                b2 = blk.mlp.c_proj.bias.detach().numpy()
                ln1 = np.array([ln_np(x[i:i + 1], ln1w, ln1b)[0] for i in range(T)])
                Q = ln1 @ Wq.T
                K = ln1 @ Wk.T
                V = ln1 @ Wv.T
                Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
                mask = np.triu(np.full((T, T), float('-inf')), 1)
                probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
                heads = [probs[h] @ Vh[h] for h in range(n_heads)]
                context = np.stack(heads, 1).reshape(T, D)
                att_out = context @ Wo.T + bo
                x_att = x + att_out
                x_new = x_att.copy()
                for t in range(T):
                    ln2t = ln_np(x_att[t:t + 1], ln2w, ln2b)[0]
                    x_new[t] = x_att[t] + gelu_np(ln2t @ W1.T + b1) @ W2.T + b2
                ln2_last = ln_np(x_att[-1:], ln2w, ln2b)[0]
                data[li]['ln2'].append(ln2_last.copy())
                data[li]['delta_ffn'].append((x_new[-1] - x_att[-1]).copy())
                data[li]['context'].append(context[-1].copy())
                data[li]['delta_att'].append(att_out[-1].copy())
                x = x_new
            total_seqs += 1
        if (story_idx + 1) % 4 == 0:
            print(f'    Story {story_idx + 1}/{len(LONG_STORIES)}  seqs_so_far={total_seqs}  elapsed={time.time() - t0:.0f}s')
N = total_seqs
for li in range(n_layers):
    for k in data[li]:
        data[li][k] = np.array(data[li][k], dtype=np.float64)
print(f'\n  N={N} total sequences  ({time.time() - t0:.0f}s)')
print(f"  N/QUAD_DIM = {N}/{QUAD_DIM} = {N / QUAD_DIM:.1f}x  ({('✓ sufficient' if N > 10 * QUAD_DIM else '✗ need more')})")
print(f"\n{'=' * 70}")
print(f'  W-KERNEL SOLVE — λ={BEST_LAM}')
print(f"{'=' * 70}\n")
t_solve = time.time()
solved = {}
print(f"  {'Layer':<8} {'FFN_R²':>12} {'ATT_R²':>12}")
print(f"  {'─' * 36}")
for li in range(n_layers):
    Phi_ffn = quad_kernel(data[li]['ln2'])
    W_ffn, r2_ffn = solve_ridge(Phi_ffn, data[li]['delta_ffn'], lam=BEST_LAM)
    W_att, r2_att = solve_ridge(data[li]['context'], data[li]['delta_att'], lam=1e-08)
    solved[li] = {'W_ffn': W_ffn, 'W_att': W_att}
    vf = '✓' if r2_ffn > 0.9999 else '~'
    va = '✓' if r2_att > 0.9999 else '~'
    print(f'  L{li:<7} {r2_ffn:.6f} {vf}  {r2_att:.6f} {va}')
print(f'  Solve time: {time.time() - t_solve:.1f}s')

def wk_forward(ids_use, wk_ffn=True, wk_att=True):
    T = len(ids_use)
    x = (wte[ids_use] + wpe[np.arange(T)]).copy().astype(np.float64)
    for li in range(n_layers):
        blk = model_ref.transformer.h[li]
        ln1w = blk.ln_1.weight.detach().numpy()
        ln1b = blk.ln_1.bias.detach().numpy()
        ln2w = blk.ln_2.weight.detach().numpy()
        ln2b = blk.ln_2.bias.detach().numpy()
        att = blk.attn.attention
        Wq = att.q_proj.weight.detach().numpy()
        Wk_ = att.k_proj.weight.detach().numpy()
        Wv = att.v_proj.weight.detach().numpy()
        Wo = att.out_proj.weight.detach().numpy()
        bo = att.out_proj.bias.detach().numpy()
        W1 = blk.mlp.c_fc.weight.detach().numpy()
        b1 = blk.mlp.c_fc.bias.detach().numpy()
        W2 = blk.mlp.c_proj.weight.detach().numpy()
        b2 = blk.mlp.c_proj.bias.detach().numpy()
        W_ffn = solved[li]['W_ffn']
        W_att = solved[li]['W_att']
        ln1 = np.array([ln_np(x[i:i + 1], ln1w, ln1b)[0] for i in range(T)])
        Q = ln1 @ Wq.T
        K = ln1 @ Wk_.T
        V = ln1 @ Wv.T
        Qh = Q.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Kh = K.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        Vh = V.reshape(T, n_heads, head_dim).transpose(1, 0, 2)
        mask = np.triu(np.full((T, T), float('-inf')), 1)
        probs = softmax_np(Qh @ Kh.transpose(0, 2, 1) + mask)
        heads = [probs[h] @ Vh[h] for h in range(n_heads)]
        context = np.stack(heads, 1).reshape(T, D)
        att_out = context @ Wo.T + bo
        x_att = x + att_out
        if wk_att:
            ctx_b = np.append(context[-1], 1.0)
            x_att[-1] = x[-1] + ctx_b @ W_att
        x_new = x_att.copy()
        for t in range(T):
            ln2t = ln_np(x_att[t:t + 1], ln2w, ln2b)[0]
            if t == T - 1 and wk_ffn:
                Pb = np.append(quad_kernel(ln2t.reshape(1, -1))[0], 1.0)
                x_new[t] = x_att[t] + Pb @ W_ffn
            else:
                x_new[t] = x_att[t] + gelu_np(ln2t @ W1.T + b1) @ W2.T + b2
        x = x_new
    lnfw = model_ref.transformer.ln_f.weight.detach().numpy()
    lnfb = model_ref.transformer.ln_f.bias.detach().numpy()
    lmw = model_ref.lm_head.weight.detach().numpy()
    return ln_np(x[-1:], lnfw, lnfb)[0] @ lmw.T
print(f"\n{'=' * 70}")
print(f'  EVALUATION')
print(f"{'=' * 70}\n")
SEQ_EVAL = 16

def calc_ppl(prompts, label, mode='ref'):
    nll = 0.0
    tok = 0
    cor = 0
    with torch.no_grad():
        for prompt in prompts:
            ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
            if len(ids) < 3:
                continue
            for i in range(1, min(len(ids), SEQ_EVAL)):
                ctx = ids[:i]
                true_next = ids[i]
                if mode == 'ref':
                    out = model_ref(torch.tensor([ctx]))
                    logits = out.logits[0, -1, :].numpy().astype(np.float64)
                else:
                    logits = wk_forward(ctx, wk_ffn='ffn' in mode or 'both' in mode, wk_att='att' in mode or 'both' in mode)
                lg = logits - logits.max()
                lp = lg - np.log(np.sum(np.exp(lg)))
                nll += -lp[true_next]
                tok += 1
                if int(np.argmax(logits)) == true_next:
                    cor += 1
    ppl = math.exp(nll / tok) if tok > 0 else float('inf')
    acc = cor / tok * 100 if tok > 0 else 0
    print(f'  {label:<35} ppl={ppl:>8.2f}  acc={acc:>5.1f}%')
    return (ppl, acc)
ppl_r, _ = calc_ppl(TEST_PROMPTS, 'Reference (gradient descent)', 'ref')
ppl_f, _ = calc_ppl(TEST_PROMPTS, 'W-Kernel FFN only', 'wk_ffn')
ppl_a, _ = calc_ppl(TEST_PROMPTS, 'W-Kernel ATT only', 'wk_att')
ppl_b, _ = calc_ppl(TEST_PROMPTS, 'W-Kernel FFN+ATT', 'wk_both')
print(f'\n  FFN ratio:  {ppl_f / ppl_r:.6f}   (1.000 = perfect)')
print(f'  ATT ratio:  {ppl_a / ppl_r:.6f}   (1.000 = perfect)')
print(f'  Both ratio: {ppl_b / ppl_r:.6f}   (1.000 = perfect)')
if ppl_b / ppl_r < 1.01:
    verdict = '✓ O(1) TRAINING PROVEN — W-KERNEL = GRADIENT DESCENT'
elif ppl_b / ppl_r < 1.05:
    verdict = '~ VERY CLOSE — minor generalization gap only'
else:
    verdict = '! GAP REMAINS — need more data or longer context'
print(f'\n  VERDICT: {verdict}')
print(f"\n{'=' * 70}")
print(f'  GENERATION COMPARISON (20 tokens)')
print(f"{'=' * 70}\n")
for prompt in ['Once upon a time a little', 'Deep in the forest lived a', 'The brave knight found a big', 'She opened the door and saw']:
    ids = tokenizer.encode(prompt, return_tensors='pt')[0].tolist()
    ir = ids[:]
    iw = ids[:]
    rt = []
    wt = []
    for _ in range(20):
        with torch.no_grad():
            nr = torch.argmax(model_ref(torch.tensor([ir])).logits[0, -1, :]).item()
        ir.append(nr)
        rt.append(nr)
        nw = int(np.argmax(wk_forward(iw, True, True)))
        iw.append(nw)
        wt.append(nw)
    print(f"  '{prompt}'")
    print(f'    REF: {tokenizer.decode(rt)}')
    print(f'    WK:  {tokenizer.decode(wt)}')
    print(f'    match: {sum((a == b for a, b in zip(rt, wt)))}/20\n')
print(f"{'=' * 70}")
print(f'  FINAL — N={N}, N/QUAD_DIM={N / QUAD_DIM:.1f}x, λ={BEST_LAM}')
print(f'  Total time: {time.time() - t0:.0f}s')
print(f"{'=' * 70}\n")
