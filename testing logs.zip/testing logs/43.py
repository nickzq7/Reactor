import torch, numpy as np, math, warnings, time
warnings.filterwarnings('ignore')
from transformers import AutoModelForCausalLM, AutoTokenizer
from numpy.linalg import lstsq
from datasets import load_dataset
MODEL_ID = 'roneneldan/TinyStories-1M'
N_TRAIN = 200
MAX_SEQ = 32
NSUB = 3000
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
print('\n' + '=' * 60)
print('  LOAD')
print('=' * 60)
tok = AutoTokenizer.from_pretrained(MODEL_ID)
teacher = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=torch.float32, use_safetensors=True).to(device).eval()
cfg = teacher.config
NL, H, NH = (cfg.num_layers, cfg.hidden_size, cfg.num_heads)
HD = H // NH
try:
    WIN = cfg.window_size
except:
    WIN = 256
try:
    ATT = cfg.attention_layers
except:
    ATT = ['global'] * NL
FFN_D = teacher.transformer.h[0].mlp.c_fc.weight.shape[0]
print(f'  NL={NL} H={H} NH={NH}')
ds = load_dataset('roneneldan/TinyStories', split='train', streaming=True)
sentences = []
for item in ds:
    t = item['text'].strip()
    if 20 < len(t) < 200:
        sentences.append(t)
    if len(sentences) >= N_TRAIN:
        break
print(f'  Loaded {len(sentences)} stories')
print('\n' + '=' * 60)
print(f'  COLLECT h_0 through h_{NL}  ({N_TRAIN} stories, MAX_SEQ={MAX_SEQ})')
print('=' * 60)
h_streams = {-1: [], **{li: [] for li in range(NL)}}
hooks = []

def make_pre0(streams):

    def fn(mod, inp):
        x = inp[0] if isinstance(inp, (tuple, list)) else inp
        streams[-1].append(x.detach().float().cpu().reshape(-1, H).numpy())
    return fn

def make_block(li, streams):

    def fn(mod, inp, out):
        x = out[0] if isinstance(out, tuple) else out
        streams[li].append(x.detach().float().cpu().reshape(-1, H).numpy())
    return fn
hooks.append(teacher.transformer.h[0].register_forward_pre_hook(make_pre0(h_streams)))
for li in range(NL):
    hooks.append(teacher.transformer.h[li].register_forward_hook(make_block(li, h_streams)))
t0 = time.perf_counter()
n_tok = 0
with torch.no_grad():
    for si, sent in enumerate(sentences):
        ids = tok(sent, return_tensors='pt', max_length=MAX_SEQ, truncation=True)['input_ids'].to(device)
        teacher(ids)
        n_tok += ids.shape[1]
for hk in hooks:
    hk.remove()
for k in h_streams:
    if h_streams[k]:
        h_streams[k] = np.concatenate(h_streams[k], 0).astype(np.float32)
N = h_streams[-1].shape[0]
t_c = time.perf_counter() - t0
print(f'  {n_tok} tokens collected in {t_c:.1f}s  (N={N} positions)')
rng = np.random.RandomState(42)
idx = rng.choice(N, min(NSUB, N), replace=False)
h_final = h_streams[NL - 1]
TARGET = h_final

def r2_fast(feat, tgt=None):
    if tgt is None:
        tgt = TARGET
    X = feat[idx].astype(np.float64)
    Y = tgt[idx].astype(np.float64)
    Xb = np.concatenate([X, np.ones((len(X), 1))], 1)
    W, _, _, _ = lstsq(Xb, Y, rcond=None)
    pred = X @ W[:-1] + W[-1]
    ss_r = float(((Y - pred) ** 2).sum())
    ss_t = float(((Y - Y.mean(0)) ** 2).sum())
    return float(1 - ss_r / (ss_t + 1e-12))

def gelu_np(x):
    return (0.5 * x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))).astype(np.float32)
print('\n' + '=' * 60)
print('  EXP 1: DIRECT FORMULA  h_0 → h_final  (0 layers skipped)')
print('=' * 60)
h0 = h_streams[-1]
tests_direct = [('h_0', h0), ('(h_0, h_0²)', np.concatenate([h0, h0 ** 2], -1)), ('(h_0, gelu(h_0))', np.concatenate([h0, gelu_np(h0)], -1)), ('(h_0,h_0²,h_0³)', np.concatenate([h0, h0 ** 2, h0 ** 3], -1))]
print(f"\n  {'Features':<30} {'dim':>6}  {'R²':>12}  bar")
print(f"  {'-' * 62}")
for name, feat in tests_direct:
    r2 = r2_fast(feat)
    bar = '█' * int(r2 * 30) + '░' * (30 - int(r2 * 30))
    print(f'  {name:<30} {feat.shape[1]:>6}  {r2:12.8f}  {bar}')
print('\n' + '=' * 60)
print('  EXP 2: MINIMUM DEPTH — add h_k until R²=1.0')
print('=' * 60)
print(f"\n  {'Cumulative features':<35} {'dim':>6}  {'R²':>12}  status")
print(f"  {'-' * 70}")
layer_order = [('h_0', h_streams[-1])] + [(f'h_{li}', h_streams[li]) for li in range(NL)]
running = None
prev_r2 = 0.0
min_depth = None
for label, hk in layer_order:
    running = hk if running is None else np.concatenate([running, hk], -1)
    r2 = r2_fast(running)
    delta = r2 - prev_r2
    if r2 > 0.9999 and min_depth is None:
        status = f'✓ SATURATED ← TRUE MINIMUM DEPTH'
        min_depth = label
    elif r2 > 0.999:
        status = f'~ near  Δ+{delta:.4f}'
    else:
        status = f'Δ+{delta:.4f}'
    bar = '█' * int(r2 * 30) + '░' * (30 - int(r2 * 30))
    print(f"  {'up to ' + label:<35} {running.shape[1]:>6}  {r2:12.8f}  {status}")
    print(f"  {'':35}        {'':12}  {bar}")
    prev_r2 = r2
    if r2 > 0.9999:
        break
print('\n' + '=' * 60)
print('  EXP 3: SINGLE LAYER POWER — h_k alone → h_final')
print('=' * 60)
print(f"\n  {'Layer':<10} {'R²':>12}  bar")
print(f"  {'-' * 50}")
single_r2s = []
for label, hk in layer_order:
    r2 = r2_fast(hk)
    bar = '█' * int(r2 * 30) + '░' * (30 - int(r2 * 30))
    print(f'  {label:<10} {r2:12.8f}  {bar}')
    single_r2s.append((r2, label))
best_single = max(single_r2s)
print(f'\n  → Best single layer: {best_single[1]}  R²={best_single[0]:.8f}')
print('\n' + '=' * 60)
print('  EXP 4: BEST LAYER PAIRS')
print('=' * 60)
pairs = []
for i, (li, hi) in enumerate(layer_order):
    for j, (lj, hj) in enumerate(layer_order):
        if j <= i:
            continue
        feat = np.concatenate([hi, hj], -1)
        r2 = r2_fast(feat)
        pairs.append((r2, f'{li}+{lj}'))
pairs.sort(reverse=True)
print(f'\n  Top 5 pairs:')
for r2, name in pairs[:5]:
    bar = '█' * int(r2 * 30) + '░' * (30 - int(r2 * 30))
    print(f'  {name:<20} R²={r2:.8f}  {bar}')
print('\n' + '=' * 60)
print('  SUMMARY')
print('=' * 60)
print(f"\n  Model:  TinyStories-1M  ({NL} layers, H={H})\n  Data:   {N} positions from {N_TRAIN} diverse stories\n\n  DIRECT FORMULA (0 transformer layers):\n    Best R² with only h_0 features: see Exp 1\n\n  MINIMUM DEPTH:\n    R²=1.0 first achieved at: {(min_depth if min_depth else f'>h_{NL - 1} (needs all layers)')}\n    Transformer uses {NL} layers.\n    True minimum depth: {(min_depth if min_depth else 'all layers needed')}.\n\n  SINGLE LAYER POWER:\n    Best layer alone: {best_single[1]}  R²={best_single[0]:.6f}\n    {('Last layer dominates → information accumulates toward output' if 'h_7' in best_single[1] else 'Early layers carry significant signal')}\n\n  REACTOR IMPLICATION:\n    {('REACTOR needs fewer than ' + str(NL) + ' layers — true depth is ' + str(min_depth) if min_depth else 'All ' + str(NL) + ' layers contribute unique information')}\n    {('Build REACTOR with ' + min_depth + ' instead of ' + str(NL) + ' layers' if min_depth else 'REACTOR needs full depth for this model')}\n")
