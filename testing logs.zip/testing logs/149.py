import os, json, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
loss_fn = nn.CrossEntropyLoss()
with open(os.path.join(_dir, 'big_model_meta.json')) as f:
    BM = json.load(f)
with open(os.path.join(_dir, 'small_model_meta.json')) as f:
    SM = json.load(f)
VS = BM['VS']
DB, HB, NLB, KB = (BM['D'], BM['H'], BM['NL'], BM['K'])
DS, HS, NLS, KS = (SM['D'], SM['H'], SM['NL'], SM['K'])
WB = {k: v for k, v in np.load(os.path.join(_dir, 'big_model_weights.npz')).items()}
WS = {k: v for k, v in np.load(os.path.join(_dir, 'small_model_weights.npz')).items()}
TESTS = [(t['name'], t['ctx'], t['truth']) for t in BM['tests']]
N_PAT = len(TESTS)
print(f"Big   model: D={DB} H={HB} NL={NLB}  score={BM['score']}/{N_PAT}")
print(f"Small model: D={DS} H={HS} NL={NLS}  score={SM['score']}/{N_PAT}")
print(f'VS={VS}  K={KS}  Device={device}')

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, (a + b) % VS)
        s.append(b)
    return s

def gen_trib(n):
    a, b, c = (0, 1, 1)
    s = [0, 1, 1]
    while len(s) < n:
        a, b, c = (b, c, (a + b + c) % VS)
        s.append(c)
    return s[:n]

def gen_primes(n):
    P = []
    c = 2
    while len(P) < n:
        if all((c % p for p in P)):
            P.append(c % VS)
        c += 1
    return P

def gen_pow(base, n):
    v = 1
    s = []
    for _ in range(n):
        s.append(v % VS)
        v = v * base % VS
    return s
fib62 = gen_fib(62)
ALL_PATTERNS = [[i % VS for i in range(60)], [i * 2 % VS for i in range(60)], [(i * 2 + 1) % VS for i in range(60)], [i * 3 % VS for i in range(60)], [i * 5 % VS for i in range(60)], [i * 10 % VS for i in range(60)], [i * 7 % VS for i in range(60)], [(100 - i) % VS for i in range(60)], [i * i % VS for i in range(60)], gen_pow(2, 60), gen_pow(3, 60), gen_fib(60), gen_trib(60), gen_primes(60), [abs(fib62[i + 2] - fib62[i]) % VS for i in range(60)]]

def build_tensors(k):
    Xs = []
    Ys = []
    for seq in ALL_PATTERNS:
        for i in range(len(seq) - k):
            Xs.append(seq[i:i + k])
            Ys.append(seq[i + 1:i + k + 1])
    return (torch.tensor(Xs, dtype=torch.long).to(device), torch.tensor(Ys, dtype=torch.long).to(device))
X, Y = build_tensors(KS)

class SmallModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, DS)
        self.wpe = nn.Embedding(KS, DS)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(DS), 'attn': nn.MultiheadAttention(DS, HS, batch_first=True), 'ln2': nn.LayerNorm(DS), 'ff': nn.Sequential(nn.Linear(DS, DS * 4), nn.GELU(), nn.Linear(DS * 4, DS))}) for _ in range(NLS)])
        self.ln_f = nn.LayerNorm(DS)

    def forward(self, ids):
        B, K = ids.shape
        pos = torch.arange(K, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def eval_model(model):
    model.eval()
    c = 0
    bar = []
    for name, ctx, truth in TESTS:
        ids = torch.tensor([ctx[-KS:]], dtype=torch.long).to(device)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        c += p == truth
        bar.append('█' if p == truth else '░')
    return (c, ''.join(bar))

def train_child(init_wte, label, steps=5000):
    torch.manual_seed(42)
    model = SmallModel().to(device)
    for name, param in model.named_parameters():
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.zeros_(param)
    with torch.no_grad():
        model.wte.weight.copy_(torch.tensor(init_wte, dtype=torch.float32).to(device))
    opt = torch.optim.Adam(model.parameters(), lr=0.003)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    best_sc = 0
    best_state = None
    t0 = time.time()
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(X).view(-1, VS), Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 500 == 0:
            sc, bar = eval_model(model)
            if sc > best_sc:
                best_sc = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  [{label}] step {step:>5}: {sc}/{N_PAT}  {bar}  ({time.time() - t0:.0f}s)', flush=True)
            if sc == N_PAT:
                break
    if best_state:
        model.load_state_dict(best_state)
    return eval_model(model)

def solve(X, Y):
    return np.linalg.lstsq(X, Y, rcond=None)[0]
WTE_S = WS['wte.weight']
WTE_B = WB['wte.weight']
P = solve(WTE_B, WTE_S)
WTE_B_proj = WTE_B @ P
WTE_h = 0.5 * WTE_S + 0.5 * WTE_B_proj
agree_d = np.sum(WTE_S * WTE_B_proj, axis=0)
print(f'\n  Agreement per dim: {agree_d.round(2)}')
print(f'  All positive: {np.all(agree_d > 0)}')
print(f"\n{'=' * 60}")
print(f'  BASELINE — random init (no transfer)')
print(f"{'=' * 60}")
rng = np.random.RandomState(0)
WTE_rand = rng.randn(VS, DS).astype(np.float64) * 0.02
sc_rand, bar_rand = train_child(WTE_rand, 'BASELINE')
print(f'  Baseline final: {sc_rand}/{N_PAT}  {bar_rand}')
print(f"\n{'=' * 60}")
print(f'  HALF BLEND — 0.5*S + 0.5*B_proj (no flip)')
print(f"{'=' * 60}")
sc_half, bar_half = train_child(WTE_h, 'HALF')
print(f'  Half blend final: {sc_half}/{N_PAT}  {bar_half}')
results = {}
results['baseline'] = sc_rand
results['half_blend'] = sc_half
for k in [1, 2, 3, 4, 6]:
    flip_dims = np.argsort(agree_d)[-k:]
    WTE_v16 = WTE_h.copy()
    WTE_v16[:, flip_dims] *= -1
    print(f"\n{'=' * 60}")
    print(f'  V16 k={k}  flip dims {flip_dims.tolist()}')
    print(f"{'=' * 60}")
    sc, bar = train_child(WTE_v16, f'V16-k{k}')
    print(f'  V16 k={k} final: {sc}/{N_PAT}  {bar}')
    results[f'v16_k{k}'] = sc
print(f"\n{'=' * 60}")
print(f'  TRANSFER RESULTS SUMMARY')
print(f"{'=' * 60}")
print(f"  Big model (teacher):  {BM['score']}/{N_PAT}")
print(f"  Small model (before): {SM['score']}/{N_PAT}")
print()
for method, sc in results.items():
    bar = '█' * sc + '░' * (N_PAT - sc)
    best = ' ← BEST' if sc == max(results.values()) else ''
    print(f'  {method:>15}: {sc:>2}/{N_PAT}  {bar}{best}')
best_sc = max(results.values())
print(f"\n  Transfer gain: {SM['score']}/15 → {best_sc}/15")
print(f"  Teacher score: {BM['score']}/15")
print('=' * 60)
