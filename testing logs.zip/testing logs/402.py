import subprocess, sys, time

def ensure(p, n=None):
    try:
        __import__(n or p)
    except ImportError:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', p, '-q'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ensure('numpy')
ensure('datasets')
import numpy as np
import math
from datasets import load_dataset
from collections import Counter
print('\n' + '=' * 70)
print('  W — THE DUAL ENGINE (RAM + COMPUTE)')
print('  Learning true semantics from Wikipedia to power the RAM.')
print('=' * 70)
print('\n  [ Phase 1 ] Downloading Raw WikiText...')
ds = load_dataset('wikitext', 'wikitext-2-raw-v1', split='train', streaming=True)
raw_text = []
char_count = 0
TARGET_CHARS = 50000
for item in ds:
    txt = ''.join([c.lower() for c in item['text'] if c.isalpha() or c == ' '])
    txt = ' '.join(txt.split())
    if len(txt) > 20:
        raw_text.append(txt)
        char_count += len(txt)
    if char_count >= TARGET_CHARS:
        break
TEXT = ' '.join(raw_text)[:TARGET_CHARS]
chars = sorted(set(TEXT))
c2i = {c: i for i, c in enumerate(chars)}
i2c = {i: c for c, i in c2i.items()}
VS = len(chars)
toks = [c2i[c] for c in TEXT]
N = len(toks)
print(f'  ✓ Text Secured. Vocab={VS} Tokens={N}')
K = 8
D_emb = 10
D_out = 64
print('\n  [ Phase 2 ] Initializing Neural Spaces...')
np.random.seed(42)
co_occ = np.zeros((VS, VS))
for i in range(len(toks) - 1):
    co_occ[toks[i], toks[i + 1]] += 1
U, S, Vt = np.linalg.svd(co_occ + 0.1)
E = U[:, :D_emb] * np.sqrt(S[:D_emb])
E = (E - E.mean(axis=0)) / (E.std(axis=0) + 1e-05)
P = np.zeros((K, D_emb))
for pos in range(K):
    for i in range(0, D_emb, 2):
        P[pos, i] = math.sin(pos / 10000 ** (i / D_emb))
        if i + 1 < D_emb:
            P[pos, i + 1] = math.cos(pos / 10000 ** (i / D_emb))
W_unembed = np.random.randn(VS, D_out) / math.sqrt(D_out)

def quad_kernel(X):
    N_samples, d = X.shape
    idx_i, idx_j = np.triu_indices(d)
    cross = X[:, idx_i] * X[:, idx_j] / math.sqrt(d)
    return np.hstack([X, cross])
print('\n  [ Phase 3 ] Training the Intelligence Matrices (O(1) Solve)...')
X_dense = []
Y_logits = np.full((N - K, VS), -5.0, dtype=np.float64)
for i in range(K, N):
    ctx = toks[i - K:i]
    emb = E[ctx] + P
    X_dense.append(emb.flatten())
    Y_logits[i - K, toks[i]] = 5.0
X_dense = np.array(X_dense, dtype=np.float64)
Y_h = Y_logits @ np.linalg.pinv(W_unembed.T)
print('  -> Training Quadratic Brain (System 2)...')
Phi = quad_kernel(X_dense)
Phi_b = np.hstack([Phi, np.ones((len(Phi), 1))])
Quad_D = Phi_b.shape[1]
lam_compute = 10.0
W_compute = np.linalg.solve(Phi_b.T @ Phi_b + lam_compute * np.eye(Quad_D), Phi_b.T @ Y_h)
print('  -> Training Linear Warp Reflex (System 1)...')
X_dense_b = np.hstack([X_dense, np.ones((len(X_dense), 1))])
lam_warp = 1.0
W_warp = np.linalg.solve(X_dense_b.T @ X_dense_b + lam_warp * np.eye(X_dense_b.shape[1]), X_dense_b.T @ Y_h)
print('\n  [ Phase 4 ] Building the RAM Bank from Trained Logic...')
H_pred_compute = Phi_b @ W_compute
Compute_Bits = (H_pred_compute > 0).astype(int)
RAM_bank = {}
for i in range(len(Compute_Bits)):
    bits_tuple = tuple(Compute_Bits[i].tolist())
    if bits_tuple not in RAM_bank:
        RAM_bank[bits_tuple] = toks[i + K]
print(f'  ✓ Semantic RAM Bank saturated with {len(RAM_bank)} learned states.')
print('\n' + '─' * 70)
print('  [ Phase 5 ] DUAL ENGINE GENERATION')
print('  GREEN = RAM Reflex (O(0)) | BLUE = Quadratic Compute (O(1))')
print('─' * 70)

def sample(logits, temp=0.5):
    logits = logits / temp
    logits = logits - np.max(logits)
    p_final = np.exp(logits)
    p_final /= p_final.sum()
    return int(np.random.choice(VS, p=p_final))
test_prompt = 'the history of the city is'
print(f"  Prompt: '{test_prompt}'\n  ", end='')
print(test_prompt, end='', flush=True)
gen_ids = [c2i[c] for c in test_prompt if c in c2i]
C_GREEN = '\x1b[92m'
C_BLUE = '\x1b[94m'
C_END = '\x1b[0m'
jumps = 0
computes = 0
start_time = time.time()
for step in range(100):
    ctx = gen_ids[-K:] if len(gen_ids) >= K else [0] * (K - len(gen_ids)) + gen_ids
    emb = E[ctx] + P
    x_in = emb.flatten().reshape(1, -1)
    x_in_b = np.hstack([x_in, [[1.0]]])
    h_warp = x_in_b @ W_warp
    warp_bits = tuple((h_warp[0] > 0).astype(int).tolist())
    if warp_bits in RAM_bank:
        next_id = RAM_bank[warp_bits]
        print(f'{C_GREEN}{i2c[next_id]}{C_END}', end='', flush=True)
        gen_ids.append(next_id)
        jumps += 1
    else:
        phi_in = quad_kernel(x_in)
        phi_in_b = np.hstack([phi_in, [[1.0]]])
        h_compute = phi_in_b @ W_compute
        logits = h_compute @ W_unembed.T
        next_id = sample(logits[0], temp=0.4)
        print(f'{C_BLUE}{i2c[next_id]}{C_END}', end='', flush=True)
        gen_ids.append(next_id)
        computes += 1
duration = time.time() - start_time
print('\n\n' + '=' * 70)
print('  THE DUAL ENGINE VERDICT')
print('=' * 70)
print(f'  Generation Time : {duration:.4f} seconds')
print(f'  RAM Reflexes    : {C_GREEN}{jumps} tokens{C_END} (Fast Known Paths)')
print(f'  Deliberations   : {C_BLUE}{computes} tokens{C_END} (Dynamic Compute)')
print('\n  WHAT THIS PROVES:\n  You cannot use RAM without Compute. We used the trained intelligence \n  to build the RAM. During generation, the model dynamically chooses:\n  If a simple linear projection recognizes the memory, it jumps.\n  If it encounters a novel state, it calculates the quadratic math.\n  \n  This is the true architecture of biological and artificial thought.\n')
print('=' * 70 + '\n')
