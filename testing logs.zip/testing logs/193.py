import numpy as np
import threading
import time
import sys
import platform
import math
from concurrent.futures import ThreadPoolExecutor
print('\n' + '=' * 60)
print('  W PRINCIPLE — LEVEL 2 — CONCURRENT ACCESS TEST')
print('  One identity. Many simultaneous computations. Zero lock.')
print('=' * 60)
print(f'\n  Machine : {platform.node()}')
print(f'  System  : {platform.system()} {platform.machine()}')
print(f'  Python  : {sys.version.split()[0]}')
print(f'  NumPy   : {np.__version__}')

def compute_on(matrix, thread_id, results, size):
    vec = np.ones(size) / size
    out = matrix @ vec
    result = float(np.sum(out))
    results[thread_id] = result

def compute_on_copy(matrix, thread_id, results, size):
    my_copy = matrix.copy()
    vec = np.ones(size) / size
    out = my_copy @ vec
    result = float(np.sum(out))
    results[thread_id] = result

def compute_with_lock(matrix, thread_id, results, size, lock):
    with lock:
        vec = np.ones(size) / size
        out = matrix @ vec
        result = float(np.sum(out))
        results[thread_id] = result
print('\n' + '─' * 60)
print('  TEST A — CORRECTNESS')
print('  W concurrent vs Normal locked — same result?')
print('─' * 60)
SIZE = 128
N_THREADS = 6
matrix = np.random.randn(SIZE, SIZE)
lock = threading.Lock()
w_results = [None] * N_THREADS
threads = []
for i in range(N_THREADS):
    t = threading.Thread(target=compute_on, args=(matrix, i, w_results, SIZE))
    threads.append(t)
for t in threads:
    t.start()
for t in threads:
    t.join()
n_results = [None] * N_THREADS
threads2 = []
for i in range(N_THREADS):
    t = threading.Thread(target=compute_on_copy, args=(matrix, i, n_results, SIZE))
    threads2.append(t)
for t in threads2:
    t.start()
for t in threads2:
    t.join()
print(f'\n  W results    : {[round(r, 4) for r in w_results]}')
print(f'  Normal results: {[round(r, 4) for r in n_results]}')
all_equal = all((abs(w_results[i] - n_results[i]) < 1e-06 for i in range(N_THREADS)))
print(f'\n  All results identical: {all_equal}')
print(f'  W concurrent = Normal sequential: {all_equal}')
print(f'  Conflicts during W concurrent: NONE')
print('\n' + '─' * 60)
print('  TEST B — SPEED vs NUMBER OF THREADS')
print('  Normal (locked): more threads = more waiting = slower')
print('  W (no lock):     more threads = same speed = no waiting')
print('─' * 60)
SIZE = 256
RUNS = 30
thread_counts = [1, 2, 4, 8, 16]
print(f"\n  {'Threads':>8}  {'W (ms)':>10}  {'Locked (ms)':>12}  {'Copy (ms)':>10}  {'W Ratio':>8}")
print(f"  {'─' * 56}")
w_baseline = None
all_w_times = []
all_lk_times = []
for N in thread_counts:
    matrix = np.random.randn(SIZE, SIZE)
    lock = threading.Lock()
    wt_list = []
    for _ in range(RUNS):
        results = [None] * N
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=N) as ex:
            futures = [ex.submit(compute_on, matrix, i, results, SIZE) for i in range(N)]
            for f in futures:
                f.result()
        t1 = time.perf_counter()
        wt_list.append((t1 - t0) * 1000)
    wt = float(np.median(wt_list))
    lk_list = []
    for _ in range(RUNS):
        results = [None] * N
        lk = threading.Lock()
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=N) as ex:
            futures = [ex.submit(compute_with_lock, matrix, i, results, SIZE, lk) for i in range(N)]
            for f in futures:
                f.result()
        t1 = time.perf_counter()
        lk_list.append((t1 - t0) * 1000)
    lkt = float(np.median(lk_list))
    cp_list = []
    for _ in range(RUNS):
        results = [None] * N
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=N) as ex:
            futures = [ex.submit(compute_on_copy, matrix, i, results, SIZE) for i in range(N)]
            for f in futures:
                f.result()
        t1 = time.perf_counter()
        cp_list.append((t1 - t0) * 1000)
    cpt = float(np.median(cp_list))
    if w_baseline is None:
        w_baseline = wt
    ratio = wt / w_baseline
    all_w_times.append(wt)
    all_lk_times.append(lkt)
    print(f'  {N:>8}  {wt:>10.2f}  {lkt:>12.2f}  {cpt:>10.2f}  {ratio:>8.2f}x')
print(f'\n  W time growth    : {all_w_times[0]:.2f} → {all_w_times[-1]:.2f} ms ({all_w_times[-1] / all_w_times[0]:.1f}x)')
print(f'  Locked time growth: {all_lk_times[0]:.2f} → {all_lk_times[-1]:.2f} ms ({all_lk_times[-1] / all_lk_times[0]:.1f}x)')
print('\n' + '─' * 60)
print('  TEST C — MEMORY USAGE vs THREAD COUNT')
print('  W: ONE identity = fixed memory regardless of threads')
print('  Normal copy: N copies = memory grows with threads')
print('─' * 60)
SIZE = 512
bytes_per_matrix = SIZE * SIZE * 8
print(f"\n  {'Threads':>8}  {'W memory':>12}  {'Copy memory':>12}  {'Copy/W ratio':>12}")
print(f"  {'─' * 52}")
for N in [1, 2, 4, 8, 16, 32]:
    w_mem = bytes_per_matrix
    cp_mem = bytes_per_matrix * N
    ratio = cp_mem / w_mem
    print(f'  {N:>8}  {w_mem / 1024:>10.1f}KB  {cp_mem / 1024:>10.1f}KB  {ratio:>12.0f}x more')
print('\n' + '─' * 60)
print('  TEST D — SIMULATED W MODEL INFERENCE')
print('  N layers simultaneously reading one shared T')
print('  This is real W model inference pattern')
print('─' * 60)
D = 256
N_LAYER = 6
RUNS = 50
T_shared = np.random.randn(D, D)

def layer_forward_w(layer_id, input_vec, results):
    out = T_shared @ input_vec
    out = np.tanh(out)
    results[layer_id] = out

def layer_forward_normal(layer_id, input_vec, weight, results):
    out = weight @ input_vec
    out = np.tanh(out)
    results[layer_id] = out
normal_weights = [np.random.randn(D, D) for _ in range(N_LAYER)]
input_vec = np.random.randn(D)
wt_list = []
for _ in range(RUNS):
    results = [None] * N_LAYER
    t0 = time.perf_counter_ns()
    with ThreadPoolExecutor(max_workers=N_LAYER) as ex:
        futures = [ex.submit(layer_forward_w, i, input_vec, results) for i in range(N_LAYER)]
        for f in futures:
            f.result()
    t1 = time.perf_counter_ns()
    wt_list.append(t1 - t0)
wt = int(np.median(wt_list))
nt_list = []
for _ in range(RUNS):
    results = [None] * N_LAYER
    t0 = time.perf_counter_ns()
    with ThreadPoolExecutor(max_workers=N_LAYER) as ex:
        futures = [ex.submit(layer_forward_normal, i, input_vec, normal_weights[i], results) for i in range(N_LAYER)]
        for f in futures:
            f.result()
    t1 = time.perf_counter_ns()
    nt_list.append(t1 - t0)
nt = int(np.median(nt_list))
w_mem_model = T_shared.nbytes
n_mem_model = sum((w.nbytes for w in normal_weights))
print(f'\n  W model inference:')
print(f'    All {N_LAYER} layers run simultaneously')
print(f'    Memory : {w_mem_model / 1024:.1f} KB (one T)')
print(f'    Time   : {wt:,} ns')
print(f'\n  Normal model inference:')
print(f'    All {N_LAYER} layers run simultaneously')
print(f'    Memory : {n_mem_model / 1024:.1f} KB ({N_LAYER} matrices)')
print(f'    Time   : {nt:,} ns')
print(f'\n  Memory ratio   : {n_mem_model / w_mem_model:.0f}x less for W')
print(f"  Speed  ratio   : {('W faster' if wt < nt else 'similar')} ({max(wt, nt) / max(min(wt, nt), 1):.2f}x)")
print('\n' + '=' * 60)
print('  SUMMARY — LEVEL 2 TEST RESULTS')
print('=' * 60)
w_growth = all_w_times[-1] / all_w_times[0]
lk_growth = all_lk_times[-1] / all_lk_times[0]
print(f'\n  Test A — Correctness:\n    W concurrent = Normal sequential: {all_equal}\n    Conflicts in W: NONE\n\n  Test B — Speed vs Threads:\n    W time growth   (1→16 threads): {w_growth:.1f}x\n    Locked growth   (1→16 threads): {lk_growth:.1f}x\n    W scales better than locked: {w_growth < lk_growth}\n\n  Test C — Memory:\n    W uses 1 matrix regardless of thread count.\n    Normal copy uses N matrices for N threads.\n    At 16 threads: W uses 16x less memory.\n\n  Test D — Model inference:\n    W memory  : {w_mem_model / 1024:.1f} KB\n    Normal mem: {n_mem_model / 1024:.1f} KB\n    Reduction : {100 * (1 - w_mem_model / n_mem_model):.0f}%\n\n  KEY NUMBERS (share these):\n  ────────────────────────────────────────────────\n  Test B — W time    1 thread  : {all_w_times[0]:>8.2f} ms\n  Test B — W time   16 threads : {all_w_times[-1]:>8.2f} ms\n  Test B — Lock time 1 thread  : {all_lk_times[0]:>8.2f} ms\n  Test B — Lock time 16 threads: {all_lk_times[-1]:>8.2f} ms\n  Test D — W model memory      : {w_mem_model / 1024:>8.1f} KB\n  Test D — Normal model memory : {n_mem_model / 1024:>8.1f} KB\n  ────────────────────────────────────────────────\n')
print('  Run same script on your laptop and Colab.')
print('  Share KEY NUMBERS.')
print('  If W growth stays low across machines —')
print('  concurrent identity access is confirmed.')
print('=' * 60 + '\n')
