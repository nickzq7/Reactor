import numpy as np
import torch
import torch.nn as nn
import time
import itertools
torch.manual_seed(42)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'device={device}')
BEST_PRIMES = [3, 23, 29, 61, 89, 191, 199, 229, 233, 257, 269, 271, 281, 379, 443, 491]
SEQ_LEN = 4
NORM = 1000.0
DIM = 16

def sieve(n):
    is_p = [True] * (n + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if is_p[i]:
            for j in range(i * i, n + 1, i):
                is_p[j] = False
    return [i for i in range(2, n + 1) if is_p[i]]
ALL_PRIMES = sieve(1000)

def gen_sequences(n_each=300):
    X, Y = ([], [])
    for i in range(2, n_each + 2):
        seq = [(i + j) ** 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        a, b = (i, i + 1)
        seq = [a, b]
        while len(seq) < SEQ_LEN + 1:
            seq.append(seq[-1] + seq[-2])
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
        for d in [1, 2, 3, 5, 7]:
            seq = [i + j * d for j in range(SEQ_LEN + 1)]
            X.append([v / NORM for v in seq[:SEQ_LEN]])
            Y.append(seq[SEQ_LEN] / NORM)
        for r in [2, 3]:
            seq = [i * r ** j for j in range(SEQ_LEN + 1)]
            if seq[-1] < NORM * 10:
                X.append([v / NORM for v in seq[:SEQ_LEN]])
                Y.append(seq[SEQ_LEN] / NORM)
        seq = [(i + j) * (i + j + 1) // 2 for j in range(SEQ_LEN + 1)]
        X.append([v / NORM for v in seq[:SEQ_LEN]])
        Y.append(seq[SEQ_LEN] / NORM)
    arr = list(zip(X, Y))
    np.random.shuffle(arr)
    Xt = torch.tensor([a[0] for a in arr], dtype=torch.float32)
    Yt = torch.tensor([[a[1]] for a in arr], dtype=torch.float32)
    return (Xt, Yt)
X, Y = gen_sequences()
split = int(len(X) * 0.8)
X_tr, Y_tr = (X[:split].to(device), Y[:split].to(device))
X_te, Y_te = (X[split:].to(device), Y[split:].to(device))
print(f'Sequences: {len(X)}')
TESTS = [([1, 4, 9, 16], 25), ([4, 9, 16, 25], 36), ([9, 16, 25, 36], 49), ([2, 4, 6, 8], 10), ([3, 6, 9, 12], 15), ([5, 10, 15, 20], 25), ([1, 2, 4, 8], 16), ([2, 4, 8, 16], 32), ([1, 3, 9, 27], 81), ([2, 6, 18, 54], 162), ([1, 1, 2, 3], 5), ([1, 2, 3, 5], 8), ([2, 3, 5, 8], 13), ([3, 5, 8, 13], 21), ([5, 8, 13, 21], 34), ([1, 3, 6, 10], 15), ([3, 6, 10, 15], 21), ([6, 10, 15, 21], 28), ([1, 8, 27, 64], 125), ([99, 100, 101, 102], 103)]
TOL = 0.05

def score(model):
    model.eval()
    correct = 0
    with torch.no_grad():
        for seq, true_next in TESTS:
            xt = torch.tensor([[v / NORM for v in seq]], dtype=torch.float32).to(device)
            pred = model(xt).item() * NORM
            if abs(pred - true_next) / NORM <= TOL:
                correct += 1
    return correct

def build_W(geo_name, out_dim, in_dim):
    W = np.zeros((out_dim, in_dim), dtype=np.float32)
    if geo_name == 'flat':
        std = np.sqrt(2.0 / (in_dim + out_dim))
        return np.random.randn(out_dim, in_dim).astype(np.float32) * std
    elif geo_name == 'prime':
        arr = np.array(BEST_PRIMES[:out_dim], dtype=np.float32)
        arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
        arr = arr / np.max(np.abs(arr))
    elif geo_name == 'every6th':
        nums = ALL_PRIMES[::6][:out_dim]
        arr = np.array(nums, dtype=np.float32)
        arr = np.tile(arr, int(np.ceil(out_dim / len(arr))))[:out_dim]
        arr = arr / np.max(np.abs(arr))
    elif geo_name == 'fibonacci':
        fibs = [1, 1]
        while len(fibs) < out_dim:
            fibs.append(fibs[-1] + fibs[-2])
        arr = np.array(fibs[:out_dim], dtype=np.float32)
        arr = arr / np.max(np.abs(arr))
    elif geo_name == 'log':
        arr = np.array([np.log(i + 2) for i in range(out_dim)], dtype=np.float32)
        arr = arr / np.max(np.abs(arr))
    elif geo_name == 'sine':
        arr = np.array([np.sin(i * np.pi / out_dim) for i in range(out_dim)], dtype=np.float32)
        arr = arr / (np.max(np.abs(arr)) + 1e-08)
    elif geo_name == 'uniform':
        arr = np.linspace(-1, 1, out_dim).astype(np.float32)
    elif geo_name == 'powers2':
        arr = np.array([2.0 ** i for i in range(out_dim)], dtype=np.float32)
        arr = arr / np.max(np.abs(arr))
    elif geo_name == 'gaps':
        gaps = [ALL_PRIMES[i + 1] - ALL_PRIMES[i] for i in range(out_dim)]
        arr = np.array(gaps, dtype=np.float32)
        arr = arr / np.max(np.abs(arr))
    elif geo_name == 'triangular':
        arr = np.array([i * (i + 1) / 2 for i in range(1, out_dim + 1)], dtype=np.float32)
        arr = arr / np.max(np.abs(arr))
    for col in range(in_dim):
        W[:, col] = arr * (col + 1) / in_dim
    return W

class GeoNet(nn.Module):

    def __init__(self, dim, geo_l1, geo_l2, geo_l3):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(SEQ_LEN, dim), nn.Tanh(), nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, 1))
        np.random.seed(42)
        with torch.no_grad():
            self.net[0].weight.copy_(torch.tensor(build_W(geo_l1, dim, SEQ_LEN)))
            self.net[2].weight.copy_(torch.tensor(build_W(geo_l2, dim, dim)))
            self.net[4].weight.copy_(torch.tensor(build_W(geo_l3, dim, dim)))

    def forward(self, x):
        return self.net(x)

def quick_train(model, epochs=600, lr=0.005):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-05)
    loss_fn = nn.MSELoss()
    best = 9999.0
    best_st = None
    for ep in range(1, epochs + 1):
        model.train()
        l = loss_fn(model(X_tr), Y_tr)
        if torch.isnan(l):
            break
        opt.zero_grad()
        l.backward()
        opt.step()
        sched.step()
        with torch.no_grad():
            v = loss_fn(model(X_te), Y_te).item()
        if not np.isnan(v) and v < best:
            best = v
            best_st = {k: v2.clone() for k, v2 in model.state_dict().items()}
    if best_st:
        model.load_state_dict(best_st)
    return best
GEOMETRIES = ['flat', 'prime', 'every6th', 'fibonacci', 'log', 'sine', 'uniform', 'powers2', 'gaps', 'triangular']
combos = list(itertools.product(GEOMETRIES, repeat=3))
TOTAL = len(combos)
print(f"\n{'=' * 65}")
print(f'  BRUTE FORCE: {TOTAL} layer combinations')
print(f'  Each = (layer1_geo, layer2_geo, layer3_geo)')
print(f"{'=' * 65}\n")
results = []
t0 = time.time()
for i, (g1, g2, g3) in enumerate(combos):
    np.random.seed(42 + i)
    model = GeoNet(DIM, g1, g2, g3).to(device)
    loss = quick_train(model)
    sc = score(model)
    results.append((sc, loss, g1, g2, g3))
    del model
    torch.cuda.empty_cache()
    if (i + 1) % 50 == 0:
        results_sorted = sorted(results, key=lambda x: (-x[0], x[1]))
        best = results_sorted[0]
        elapsed = time.time() - t0
        eta = elapsed / (i + 1) * (TOTAL - i - 1)
        print(f'  [{i + 1:>4}/{TOTAL}]  best={best[0]}/{len(TESTS)} ({best[2]},{best[3]},{best[4]})  eta={eta:.0f}s')
results.sort(key=lambda x: (-x[0], x[1]))
print(f"\n{'=' * 65}")
print(f'  TOP 20 LAYER COMBINATIONS')
print(f"{'=' * 65}")
print(f"  {'#':>3}  {'Score':>7}  {'Loss':>10}  Layer1      Layer2      Layer3")
print(f"  {'─' * 60}")
for rank, (sc, loss, g1, g2, g3) in enumerate(results[:20]):
    print(f'  {rank + 1:>3}  {sc:>4}/{len(TESTS)}  {loss:>10.6f}  {g1:<12}{g2:<12}{g3}')
print(f"\n{'=' * 65}")
print(f'  PER-LAYER GEOMETRY RANKING')
print(f'  (average score when that geometry is used in that layer)')
print(f"{'=' * 65}")
for layer_idx, layer_name in enumerate(['LAYER 1', 'LAYER 2', 'LAYER 3']):
    scores_by_geo = {g: [] for g in GEOMETRIES}
    for sc, loss, g1, g2, g3 in results:
        geo = [g1, g2, g3][layer_idx]
        scores_by_geo[geo].append(sc)
    avg_scores = [(np.mean(v), g) for g, v in scores_by_geo.items()]
    avg_scores.sort(reverse=True)
    print(f'\n  {layer_name}:')
    print(f"  {'Geometry':<14}  {'Avg Score':>10}  {'Max Score':>10}")
    print(f"  {'─' * 38}")
    for avg, g in avg_scores:
        max_s = max(scores_by_geo[g])
        bar = '█' * int(avg / len(TESTS) * 20)
        print(f'  {g:<14}  {avg:>10.2f}  {max_s:>10}  {bar}')
best_sc, best_loss, best_g1, best_g2, best_g3 = results[0]
print(f"\n{'=' * 65}")
print(f'  WINNER: Layer1={best_g1}  Layer2={best_g2}  Layer3={best_g3}')
print(f'  Score: {best_sc}/{len(TESTS)}  Loss: {best_loss:.6f}')
print(f"{'=' * 65}")
print(f'\n  WHAT THIS MEANS:\n\n  Layer 1 ({best_g1}):\n    Input transformation layer\n    {best_g1} geometry best for seeing raw sequences\n\n  Layer 2 ({best_g2}):\n    Internal reasoning layer\n    {best_g2} geometry best for thinking/pattern finding\n\n  Layer 3 ({best_g3}):\n    Decision layer\n    {best_g3} geometry best for committing to answer\n\n  PRINCIPLE:\n    Different layers need different geometries\n    because they do fundamentally different jobs\n    Input seeing ≠ Pattern thinking ≠ Decision making\n    Each job has its own natural geometry\n    Like subconscious:\n      Senses use one structure\n      Memory uses another\n      Decision uses another\n      All work together = intelligence\n')
print(f'  Confirming winner with 1500 epochs...')
np.random.seed(42)
winner = GeoNet(DIM, best_g1, best_g2, best_g3).to(device)
opt = torch.optim.Adam(winner.parameters(), lr=0.005)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=1500, eta_min=1e-05)
loss_fn = nn.MSELoss()
best_l = 9999.0
best_st = None
for ep in range(1, 1501):
    winner.train()
    l = loss_fn(winner(X_tr), Y_tr)
    opt.zero_grad()
    l.backward()
    opt.step()
    sched.step()
    with torch.no_grad():
        v = loss_fn(winner(X_te), Y_te).item()
    if not np.isnan(v) and v < best_l:
        best_l = v
        best_st = {k: v2.clone() for k, v2 in winner.state_dict().items()}
    if ep % 300 == 0:
        print(f'    ep{ep}  best={best_l:.6f}')
winner.load_state_dict(best_st)
final_score = score(winner)
print(f'\n  FINAL CONFIRMED:')
print(f'  Winner combo ({best_g1}, {best_g2}, {best_g3}) : {final_score}/{len(TESTS)}')
print(f'  Total time: {time.time() - t0:.1f}s')
