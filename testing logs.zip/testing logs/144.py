import os, json, math, time, copy
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_dir, 'num_meta.json')) as f:
    meta = json.load(f)
VS = meta['VS']
K = meta['KA']
D16 = meta['DA']
H = meta['HA']
NL = meta['NLA']
D2 = 2
DONOR_IDX = 4
device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss()

def gen_fib(n):
    a, b = (1, 1)
    s = [a % VS, b % VS]
    while len(s) < n:
        a, b = (b, a + b)
        s.append(b % VS)
    return s
fib = gen_fib(60)
ALL_PATS = {}
for off in range(8):
    ALL_PATS[f'f{off}'] = (fib[off:off + 20], fib[off + 20] if off + 20 < len(fib) else fib[(off + 20) % len(fib)])
PAT_NAMES = list(ALL_PATS.keys())

class SeqT2(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D2)
        self.wpe = nn.Embedding(K, D2)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D2), 'attn': nn.MultiheadAttention(D2, 1, batch_first=True), 'ln2': nn.LayerNorm(D2), 'ff': nn.Sequential(nn.Linear(D2, D2 * 4), nn.GELU(), nn.Linear(D2 * 4, D2))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D2)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

class SeqT16(nn.Module):

    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VS, D16)
        self.wpe = nn.Embedding(K, D16)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D16), 'attn': nn.MultiheadAttention(D16, H, batch_first=True), 'ln2': nn.LayerNorm(D16), 'ff': nn.Sequential(nn.Linear(D16, D16 * 4), nn.GELU(), nn.Linear(D16 * 4, D16))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D16)

    def forward(self, ids):
        B, Kk = ids.shape
        pos = torch.arange(Kk, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((Kk, Kk), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def load_donor():
    W = np.load(os.path.join(_dir, f'donor_{DONOR_IDX:02d}.npz'))
    state = {k: torch.tensor(v.astype(np.float32)) for k, v in W.items()}
    m = SeqT16().to(device)
    m.load_state_dict(state, strict=True)
    return m

def get_state(model):
    return {k: v.detach().cpu().numpy().astype(np.float64) for k, v in model.state_dict().items()}

def set_state(model, state_np):
    state_t = {k: torch.tensor(v.astype(np.float32)) for k, v in state_np.items()}
    model.load_state_dict(state_t, strict=True)

def clone(state_np):
    return {k: v.copy() for k, v in state_np.items()}

def compress_state_svd(state16, rng=None, noise=0.0):
    state2 = {}
    ref = SeqT2()
    ref_state = {k: v.detach().numpy() for k, v in ref.state_dict().items()}
    for key, ref_val in ref_state.items():
        if key not in state16:
            state2[key] = ref_val.astype(np.float64)
            continue
        src = state16[key]
        tgt_shape = ref_val.shape
        if src.shape == tgt_shape:
            state2[key] = src.copy()
        elif src.ndim == 1:
            if src.shape[0] >= tgt_shape[0]:
                state2[key] = src[:tgt_shape[0]].copy()
            else:
                state2[key] = np.pad(src, (0, tgt_shape[0] - src.shape[0]))
        elif src.ndim == 2:
            try:
                U, s, Vt = np.linalg.svd(src, full_matrices=False)
                r0 = min(tgt_shape[0], U.shape[0], len(s))
                r1 = min(tgt_shape[1], Vt.shape[1], len(s))
                compressed = U[:r0, :min(r0, r1)] * s[:min(r0, r1)] @ Vt[:min(r0, r1), :r1]
                out = np.zeros(tgt_shape)
                out[:compressed.shape[0], :compressed.shape[1]] = compressed
                state2[key] = out
            except Exception:
                state2[key] = ref_val.astype(np.float64)
        else:
            state2[key] = ref_val.astype(np.float64)
        if noise > 0 and rng is not None:
            std = np.std(state2[key])
            state2[key] += rng.randn(*state2[key].shape) * std * noise
    return state2

def eval_model(model):
    model.eval()
    scores = []
    for pn in PAT_NAMES:
        seq, truth = ALL_PATS[pn]
        ids = torch.tensor([seq[-K:]], dtype=torch.long)
        with torch.no_grad():
            p = int(model(ids)[0, -1].argmax())
        scores.append(p == truth)
    return (sum(scores), scores)
scratch2 = SeqT2().to(device)

def eval_state2(state_np):
    set_state(scratch2, state_np)
    return eval_model(scratch2)

def mutate(state_np, rng, strength=None):
    s = clone(state_np)
    keys = list(s.keys())
    if strength is None:
        strength = rng.uniform(0.01, 0.5)
    op = rng.choice(['point', 'layer', 'sign_flip', 'scale', 'rot_wte', 'swap_dims', 'stretch', 'big_noise', 'wte_inject', 'ff_scale'])
    if op == 'point':
        key = rng.choice(keys)
        s[key] += rng.randn(*s[key].shape) * np.std(s[key]) * strength
    elif op == 'layer':
        l = rng.randint(NL)
        for key in keys:
            if f'layers.{l}.' in key:
                s[key] += rng.randn(*s[key].shape) * np.std(s[key]) * strength
    elif op == 'sign_flip':
        dims_to_flip = rng.choice([0, 1, 2], rng.randint(1, 3), replace=False)
        for key in keys:
            if s[key].ndim >= 2:
                for d in dims_to_flip:
                    if d < s[key].shape[-1]:
                        s[key][..., d] *= -1
    elif op == 'scale':
        key = rng.choice(keys)
        s[key] *= rng.uniform(0.3, 2.5)
    elif op == 'rot_wte':
        key = 'wte.weight'
        if key in s:
            ang = rng.uniform(0, 2 * math.pi)
            c, s_ = (math.cos(ang), math.sin(ang))
            x0 = s[key][:, 0].copy()
            x1 = s[key][:, 1].copy()
            s[key][:, 0] = c * x0 - s_ * x1
            s[key][:, 1] = s_ * x0 + c * x1
    elif op == 'swap_dims':
        d1, d2 = rng.choice(D2, 2, replace=False) if D2 > 1 else (0, 0)
        for key in keys:
            if s[key].ndim >= 2 and s[key].shape[-1] >= 2:
                tmp = s[key][..., d1].copy()
                s[key][..., d1] = s[key][..., d2]
                s[key][..., d2] = tmp
    elif op == 'stretch':
        key = 'wte.weight'
        if key in s:
            ang = rng.uniform(0, math.pi)
            axis = np.array([math.cos(ang), math.sin(ang)])
            proj = (s[key] @ axis)[:, None] * axis[None, :]
            s[key] += (rng.uniform(0.2, 2.0) - 1) * proj
    elif op == 'big_noise':
        n = rng.randint(1, len(keys) // 2 + 1)
        for key in rng.choice(keys, n, replace=False):
            s[key] += rng.randn(*s[key].shape) * np.std(s[key]) * rng.uniform(0.1, 1.0)
    elif op == 'wte_inject':
        key = 'wte.weight'
        if key in s:
            angles = np.linspace(0, 2 * math.pi, VS, endpoint=False)
            angles += rng.uniform(0, 2 * math.pi)
            r = np.std(s[key]) * rng.uniform(0.5, 2.0)
            circle = np.stack([r * np.cos(angles), r * np.sin(angles)], axis=1)
            alpha = rng.uniform(0.05, 0.8)
            s[key] = (1 - alpha) * s[key] + alpha * circle
    elif op == 'ff_scale':
        factor = rng.uniform(0.1, 3.0)
        for key in keys:
            if 'ff' in key:
                s[key] *= factor
    return (s, op)

def cross_mutate(states, rng):
    child = clone(states[0])
    keys = list(child.keys())
    groups = {'wte': [], 'wpe': [], 'ln_f': []}
    for l in range(NL):
        groups[f'layer{l}_attn'] = []
        groups[f'layer{l}_ff'] = []
        groups[f'layer{l}_ln'] = []
    for key in keys:
        if key.startswith('wte'):
            groups['wte'].append(key)
        elif key.startswith('wpe'):
            groups['wpe'].append(key)
        elif key.startswith('ln_f'):
            groups['ln_f'].append(key)
        else:
            placed = False
            for l in range(NL):
                if f'layers.{l}.' in key:
                    if 'attn' in key:
                        groups[f'layer{l}_attn'].append(key)
                    elif 'ff' in key:
                        groups[f'layer{l}_ff'].append(key)
                    elif 'ln' in key:
                        groups[f'layer{l}_ln'].append(key)
                    placed = True
                    break
            if not placed:
                groups['wte'].append(key)
    for gname, gkeys in groups.items():
        parent = states[rng.randint(len(states))]
        for key in gkeys:
            if key in parent:
                child[key] = parent[key].copy()
    return child

def meta_mutate(state_np, rng):
    s = clone(state_np)
    n_ops = rng.randint(2, 6)
    strengths = rng.uniform(0.01, 0.8, n_ops)
    for i in range(n_ops):
        s, _ = mutate(s, rng, strength=strengths[i])
    return s

def build_tensors():
    Xs = []
    Ys = []
    for pn in PAT_NAMES:
        seq, _ = ALL_PATS[pn]
        for i in range(len(seq) - K):
            Xs.append(seq[i:i + K])
            Ys.append(seq[i + 1:i + K + 1])
    return (torch.tensor(Xs, dtype=torch.long), torch.tensor(Ys, dtype=torch.long))
ALL_X, ALL_Y = build_tensors()

def train_from_state(init_state, steps=2000, lr=0.003, print_every=200):
    model = SeqT2().to(device)
    set_state(model, init_state)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-05)
    best_s = 0
    best_state = None
    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(ALL_X).view(-1, VS), ALL_Y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % print_every == 0:
            sc, scores = eval_model(model)
            bar = ''.join(('█' if x else '░' for x in scores))
            if sc > best_s:
                best_s = sc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            print(f'  step {step:>5}: {sc}/8  {bar}', flush=True)
    if best_state:
        model.load_state_dict(best_state)
    return (best_s, model)
print('=' * 60)
print('  VIRAL EVOLUTION: FIBONACCI D=16 → D=2')
print('=' * 60)
donor = load_donor()
sc, scores = eval_model(donor)
print(f"\n  Donor (D=16): {sc}/8  {''.join(('█' if x else '░' for x in scores))}")
donor_state16 = get_state(donor)
rng = np.random.RandomState(42)
print(f'\n  Generating initial population (Gen 0)...')
POOL_SIZE = 200
N_GEN = 30
SURVIVE_TOP = 20
CHILDREN_PER_GEN = 500
pool = []
for noise in [0.0, 0.01, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0]:
    state2 = compress_state_svd(donor_state16, rng, noise=noise)
    sc, _ = eval_state2(state2)
    pool.append((sc, clone(state2)))
for _ in range(POOL_SIZE - len(pool)):
    state2 = compress_state_svd(donor_state16, rng, noise=rng.uniform(0, 1.0))
    n_mut = rng.randint(1, 4)
    for _ in range(n_mut):
        state2, _ = mutate(state2, rng, strength=rng.uniform(0.1, 1.0))
    sc, _ = eval_state2(state2)
    pool.append((sc, clone(state2)))
pool.sort(key=lambda x: x[0], reverse=True)
print(f'  Gen 0 pool: best={pool[0][0]}/8  top5={[p[0] for p in pool[:5]]}')
print(f'\n  Starting evolution: {N_GEN} generations × {CHILDREN_PER_GEN} children')
print(f'  Mutation types: point, layer, sign_flip, scale, rot_wte,')
print(f'                  swap_dims, stretch, big_noise, wte_inject,')
print(f'                  ff_scale, cross_mutate, meta_mutate')
print()
global_best = pool[0]
t0 = time.time()
op_hits = {}
for gen in range(N_GEN):
    survivors = pool[:SURVIVE_TOP]
    survivor_states = [s for _, s in survivors]
    children = []
    for ci in range(CHILDREN_PER_GEN):
        r = rng.rand()
        if r < 0.25:
            base = clone(survivor_states[rng.randint(len(survivor_states))])
            child, op = mutate(base, rng)
        elif r < 0.5:
            base = clone(survivor_states[rng.randint(len(survivor_states))])
            child = meta_mutate(base, rng)
            op = 'meta'
        elif r < 0.75:
            n_parents = min(rng.randint(2, 5), len(survivor_states))
            parents = [survivor_states[i] for i in rng.choice(len(survivor_states), n_parents, replace=False)]
            child = cross_mutate(parents, rng)
            op = 'cross'
        else:
            n_parents = min(rng.randint(2, 4), len(survivor_states))
            parents = [survivor_states[i] for i in rng.choice(len(survivor_states), n_parents, replace=False)]
            child = cross_mutate(parents, rng)
            child, op2 = mutate(child, rng)
            op = f'cross+{op2}'
        sc, _ = eval_state2(child)
        children.append((sc, clone(child), op))
        if sc > global_best[0]:
            global_best = (sc, clone(child))
            bar = ''.join(('█' if x else '░' for x in _))
            print(f'  gen {gen:>3} child {ci:>4}  *** NEW BEST {sc}/8 {bar}  op={op} ***', flush=True)
            op_hits[op] = op_hits.get(op, 0) + 1
            if sc == 8:
                print(f'\n  *** 8/8 ACHIEVED! Generation {gen} ***')
                break
    if global_best[0] == 8:
        break
    all_candidates = pool + [(sc, s) for sc, s, _ in children]
    all_candidates.sort(key=lambda x: x[0], reverse=True)
    pool = all_candidates[:POOL_SIZE]
    top5 = [p[0] for p in pool[:5]]
    print(f'  gen {gen:>3}  best={pool[0][0]}/8  top5={top5}  global={global_best[0]}/8  {time.time() - t0:.0f}s', flush=True)
print(f'\n  Evolution done. Best found: {global_best[0]}/8')
print(f'  Ops that found improvements: {op_hits}')
print(f"\n{'=' * 60}")
print(f'  TRAINING BEST D=2 MODEL  ({global_best[0]}/8 before training)')
print(f'  2000 steps on fibonacci patterns')
print(f"{'=' * 60}\n")
final_sc, final_model = train_from_state(global_best[1], steps=2000, lr=0.003, print_every=200)
sc, scores = eval_model(final_model)
print(f"\n{'=' * 60}")
print(f'  FINAL: {sc}/8')
print(f"{'=' * 60}")
for i, (pn, ok) in enumerate(zip(PAT_NAMES, scores)):
    seq, truth = ALL_PATS[pn]
    ids = torch.tensor([seq[-K:]], dtype=torch.long)
    with torch.no_grad():
        p = int(final_model(ids)[0, -1].argmax())
    print(f"  {pn}  {('✓' if ok else '✗')}  truth={truth}  pred={p}")
wte2 = final_model.wte.weight.detach().numpy()
norms = np.linalg.norm(wte2, axis=1)
print(f'\n  WTE geometry: std(norms)/mean = {norms.std() / norms.mean():.3f}  (0=circle, 1=random)')
print(f'  Total time: {time.time() - t0:.0f}s')
print(f'\n  If {sc}/8 → move to Script 2 (2 donors)')
print(f'  Ops that worked: {op_hits}')
print('=' * 60)
