import numpy as np

def r2(pred, true):
    e = np.mean((pred - true) ** 2)
    s = np.var(true)
    return float(1 - e / s) if s > 0 else 0.0

def fit_linear(X, Y):
    Xb = np.c_[X.astype(np.float64), np.ones(len(X))]
    W = np.linalg.lstsq(Xb, Y.astype(np.float64), rcond=None)[0]
    return W.astype(np.float32)

def gelu(x):
    return x * 0.5 * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))

def relu(x):
    return np.maximum(0, x)

def tanh(x):
    return np.tanh(x)

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def silu(x):
    return x * sigmoid(x)

def square(x):
    return x ** 2
NONLINEARITIES = {'gelu': gelu, 'silu': silu, 'relu': relu, 'tanh': tanh, 'sigmoid': sigmoid, 'square': square}
N = 2000

def gen_linear(n):
    return np.arange(1, n + 1, dtype=np.float32)

def gen_quadratic(n):
    return np.arange(1, n + 1, dtype=np.float32) ** 2

def gen_fibonacci(n):
    f = [1.0, 1.0]
    while len(f) < n:
        f.append(f[-1] + f[-2])
    return np.array(f[:n], dtype=np.float32)

def gen_exponential(n):
    return 2.0 ** np.arange(n, dtype=np.float32)

def gen_prime(n):
    primes = []
    candidate = 2
    while len(primes) < n:
        if all((candidate % p != 0 for p in primes)):
            primes.append(float(candidate))
        candidate += 1
    return np.array(primes, dtype=np.float32)

def gen_sine(n):
    return np.sin(np.arange(n, dtype=np.float32) * 0.3).astype(np.float32)

def gen_random(n):
    np.random.seed(42)
    return np.random.randn(n).astype(np.float32)

def gen_mixed(n):
    t = np.arange(n, dtype=np.float32)
    return (np.sin(t * 0.3) + 0.1 * t + np.cos(t * 0.7)).astype(np.float32)

def gen_triangular(n):
    return (np.arange(1, n + 1) * (np.arange(1, n + 1) + 1) / 2).astype(np.float32)
SEQUENCES = {'linear': gen_linear, 'quadratic': gen_quadratic, 'fibonacci': gen_fibonacci, 'exponential': gen_exponential, 'prime': gen_prime, 'sine': gen_sine, 'random': gen_random, 'mixed': gen_mixed, 'triangular': gen_triangular}
WINDOW = 8

def make_windows(seq, w=WINDOW):
    X = np.array([seq[i:i + w] for i in range(len(seq) - w)], dtype=np.float32)
    Y = seq[w:].reshape(-1, 1).astype(np.float32)
    return (X, Y)

def normalize(seq):
    s = np.std(seq)
    if s < 1e-08:
        return seq
    return (seq - np.mean(seq)) / s
print(f"\n{'=' * 75}")
print(f'  TEST 1 — HYPER LAW ON PURE MATH')
print(f'  Hypothesis: after nonlinear crystallization → linear. R²=1.000')
print(f'  Window={WINDOW}  N={N}')
print(f"{'=' * 75}\n")
all_results = {}
for seq_name, seq_fn in SEQUENCES.items():
    seq = normalize(seq_fn(N))
    X, Y = make_windows(seq, WINDOW)
    n = len(X)
    s = int(n * 0.8)
    W_raw = fit_linear(X[:s], Y[:s])
    Xb = np.c_[X, np.ones(n)]
    r2_raw = r2(Xb[s:] @ W_raw, Y[s:])
    best_r2 = r2_raw
    best_nl = 'raw'
    nl_results = {'raw': r2_raw}
    for nl_name, nl_fn in NONLINEARITIES.items():
        try:
            X_crystal = nl_fn(X).astype(np.float32)
            if not np.all(np.isfinite(X_crystal)):
                nl_results[nl_name] = float('nan')
                continue
            W_nl = fit_linear(X_crystal[:s], Y[:s])
            Xb_nl = np.c_[X_crystal, np.ones(n)]
            r2_nl = r2(Xb_nl[s:] @ W_nl, Y[s:])
            nl_results[nl_name] = r2_nl
            if r2_nl > best_r2:
                best_r2 = r2_nl
                best_nl = nl_name
        except:
            nl_results[nl_name] = float('nan')
    all_results[seq_name] = {'nl_results': nl_results, 'best_r2': best_r2, 'best_nl': best_nl, 'r2_raw': r2_raw, 'lift': best_r2 - r2_raw}
print(f"  {'Sequence':<14} {'Raw R²':<10} {'Best R²':<10} {'Best NL':<12} {'Lift':<10} {'Hyper?'}")
print(f"  {'─' * 70}")
for seq_name, res in all_results.items():
    r_raw = res['r2_raw']
    r_best = res['best_r2']
    b_nl = res['best_nl']
    lift = res['lift']
    hyper = '✓ YES' if r_best > 0.999 else '~ NEAR' if r_best > 0.95 else '✗ NO'
    print(f'  {seq_name:<14} {r_raw:<10.4f} {r_best:<10.4f} {b_nl:<12} {lift:<10.4f} {hyper}')
print(f'\n  DETAIL — R² per nonlinearity:')
print(f"  {'Sequence':<14}", end='')
nls = ['raw'] + list(NONLINEARITIES.keys())
for nl in nls:
    print(f' {nl:<9}', end='')
print()
print(f"  {'─' * 90}")
for seq_name, res in all_results.items():
    print(f'  {seq_name:<14}', end='')
    for nl in nls:
        v = res['nl_results'].get(nl, float('nan'))
        if np.isnan(v):
            print(f" {'nan':<9}", end='')
        else:
            print(f' {v:<9.4f}', end='')
    print()
confirmed = sum((1 for r in all_results.values() if r['best_r2'] > 0.999))
near = sum((1 for r in all_results.values() if 0.95 < r['best_r2'] <= 0.999))
total = len(all_results)
print(f"\n{'=' * 75}")
print(f'  HYPER LAW RESULT:')
print(f'  Confirmed (R²>0.999): {confirmed}/{total} sequences')
print(f'  Near      (R²>0.95):  {near}/{total} sequences')
print(f"{'=' * 75}")
print(f'\n  READING THE RESULT:\n\n  If confirmed >= 6/9:\n    Hyper law holds on pure math.\n    Crystallization reveals linear structure universally.\n    Not transformer specific. Mathematical truth.\n    Law: after nonlinear crystallization → linear. Always.\n\n  If confirmed < 3/9:\n    Hyper law needs refinement.\n    Nonlinearity choice matters.\n    Or: window approach wrong.\n    Or: law needs different formulation.\n\n  Best nonlinearity pattern:\n    If gelu/silu always best:\n      Transformer designers found the right crystallization.\n      Not by accident. By mathematical necessity.\n    If square always best:\n      Law is about variance. Second moment. Statistics.\n    If tanh always best:\n      Law is about bounded spaces. Normalization.\n\n  Lift (best - raw):\n    High lift = crystallization reveals hidden linear structure.\n    Low lift  = structure was already linear. No hiding.\n\n  Random sequence result:\n    If random R² stays low: law is real. Not artifact.\n    If random R² also high: overfitting. Need more data.\n')
print('=' * 75 + '\n')
