import os, json, math, time
import numpy as np
import torch
import torch.nn as nn
_dir = os.path.dirname(os.path.abspath(__file__))
print('=' * 65)
print('  NUMBER SEQUENCE EXPERIMENT')
print('  Small=counting only  Large=all patterns')
print('=' * 65)
MAX_NUM = 30
VS = MAX_NUM + 1
vocab = list(range(VS))

def tok(n):
    return n % VS

def detok(t):
    return t
print(f'\n  Vocabulary: numbers 0 to {MAX_NUM}  (VS={VS})')

def counting(start=0, length=50):
    return [tok(start + i) for i in range(length)]

def evens(start=0, length=30):
    return [tok(start + i * 2) for i in range(length)]

def odds(start=1, length=30):
    return [tok(start + i * 2) for i in range(length)]

def primes(length=20):
    ps = []
    n = 2
    while len(ps) < length:
        if all((n % p != 0 for p in ps)):
            ps.append(n)
        n += 1
    return [tok(p) for p in ps]

def fibonacci(length=20):
    a, b = (1, 1)
    seq = [a, b]
    while len(seq) < length:
        a, b = (b, a + b)
        seq.append(b)
    return [tok(x) for x in seq]

def squares(length=15):
    return [tok(i * i) for i in range(length)]

def threes(start=0, length=20):
    return [tok(start + i * 3) for i in range(length)]

def powers2(length=10):
    return [tok(2 ** i) for i in range(length)]

def make_small_data():
    seqs = []
    for s in range(0, 25, 3):
        seqs.extend(counting(s, 30))
    return seqs

def make_large_data():
    seqs = []
    for s in range(0, 25, 2):
        seqs.extend(counting(s, 25))
    for s in range(0, 10, 2):
        seqs.extend(evens(s, 15))
    for s in range(1, 10, 2):
        seqs.extend(odds(s, 15))
    for _ in range(5):
        seqs.extend(primes(20))
    for _ in range(5):
        seqs.extend(fibonacci(20))
    for _ in range(4):
        seqs.extend(squares(15))
    for s in range(0, 9, 3):
        seqs.extend(threes(s, 15))
    for _ in range(5):
        seqs.extend(powers2(10))
    return seqs
small_data = make_small_data()
large_data = make_large_data()
print(f'\n  Small model data: {len(small_data)} tokens (counting only)')
print(f'  Large model data: {len(large_data)} tokens (all patterns)')

class SeqTransformer(nn.Module):

    def __init__(self, D, H, NL, K):
        super().__init__()
        self.K = K
        self.D = D
        self.H = H
        self.NL = NL
        self.wte = nn.Embedding(VS, D)
        self.wpe = nn.Embedding(K, D)
        self.layers = nn.ModuleList([nn.ModuleDict({'ln1': nn.LayerNorm(D), 'attn': nn.MultiheadAttention(D, H, batch_first=True), 'ln2': nn.LayerNorm(D), 'ff': nn.Sequential(nn.Linear(D, D * 4), nn.GELU(), nn.Linear(D * 4, D))}) for _ in range(NL)])
        self.ln_f = nn.LayerNorm(D)
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            else:
                nn.init.zeros_(p)

    def forward(self, ids):
        B, K = ids.shape
        pos = torch.arange(K, device=ids.device).unsqueeze(0)
        x = self.wte(ids) + self.wpe(pos)
        mask = torch.triu(torch.full((K, K), float('-inf'), device=ids.device), diagonal=1)
        for ly in self.layers:
            xn = ly['ln1'](x)
            a, _ = ly['attn'](xn, xn, xn, attn_mask=mask, need_weights=False)
            x = x + a
            x = x + ly['ff'](ly['ln2'](x))
        return self.ln_f(x) @ self.wte.weight.T

def train_model(data, D, H, NL, K, epochs=6000, lr=0.003, label=''):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    M = len(data) - K
    X = torch.tensor([data[i:i + K] for i in range(M)], device=device)
    y = torch.tensor([data[i + 1:i + K + 1] for i in range(M)], device=device)
    model = SeqTransformer(D, H, NL, K).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.001)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=0.0001)
    loss_fn = nn.CrossEntropyLoss()
    best_acc = 0
    best_state = None
    t0 = time.time()
    print(f'\n  Training {label}: D={D} H={H} NL={NL} K={K} params={sum((p.numel() for p in model.parameters())):,}')
    print(f"  {'Epoch':>7} {'Loss':>8} {'Acc%':>7}")
    print(f"  {'─' * 30}")
    for ep in range(1, epochs + 1):
        model.train()
        opt.zero_grad()
        logits = model(X)
        loss = loss_fn(logits.view(-1, VS), y.view(-1))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if ep % (epochs // 10) == 0 or loss.item() < 0.01:
            model.eval()
            with torch.no_grad():
                acc = 100 * (model(X).argmax(-1) == y).float().mean().item()
            print(f'  {ep:>7} {loss.item():>8.4f} {acc:>6.1f}%')
            if acc > best_acc:
                best_acc = acc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            if loss.item() < 0.005 and acc >= 99:
                print('  ✓ Converged!')
                break
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        final_acc = 100 * (model(X).argmax(-1) == y).float().mean().item()
    print(f'  Final acc={final_acc:.1f}%  time={time.time() - t0:.1f}s')
    return (model, final_acc)
DA = 16
HA = 2
NLA = 2
KA = 6
modelA, accA = train_model(small_data, DA, HA, NLA, KA, epochs=5000, label='SMALL (counting only)')
DB = 64
HB = 4
NLB = 4
KB = 8
modelB, accB = train_model(large_data, DB, HB, NLB, KB, epochs=8000, lr=0.002, label='LARGE (all patterns)')

def extract(model, NL):
    W = {}
    dev = next(model.parameters()).device
    W['WTE'] = model.wte.weight.detach().cpu().numpy().astype(np.float64)
    W['WPE'] = model.wpe.weight.detach().cpu().numpy().astype(np.float64)
    for l in range(NL):
        ly = model.layers[l]
        ip = ly['attn'].in_proj_weight.detach().cpu().numpy().astype(np.float64)
        D_ = W['WTE'].shape[1]
        W[f'WQ{l}'] = ip[:D_]
        W[f'WK{l}'] = ip[D_:2 * D_]
        W[f'WV{l}'] = ip[2 * D_:]
        W[f'WO{l}'] = ly['attn'].out_proj.weight.detach().cpu().numpy().astype(np.float64)
        W[f'W1{l}'] = ly['ff'][0].weight.detach().cpu().numpy().astype(np.float64)
        W[f'b1{l}'] = ly['ff'][0].bias.detach().cpu().numpy().astype(np.float64)
        W[f'W2{l}'] = ly['ff'][2].weight.detach().cpu().numpy().astype(np.float64)
        W[f'b2{l}'] = ly['ff'][2].bias.detach().cpu().numpy().astype(np.float64)
        W[f'LN1g{l}'] = ly['ln1'].weight.detach().cpu().numpy().astype(np.float64)
        W[f'LN1b{l}'] = ly['ln1'].bias.detach().cpu().numpy().astype(np.float64)
        W[f'LN2g{l}'] = ly['ln2'].weight.detach().cpu().numpy().astype(np.float64)
        W[f'LN2b{l}'] = ly['ln2'].bias.detach().cpu().numpy().astype(np.float64)
    W['LNfg'] = model.ln_f.weight.detach().cpu().numpy().astype(np.float64)
    W['LNfb'] = model.ln_f.bias.detach().cpu().numpy().astype(np.float64)
    return W
WA_np = extract(modelA, NLA)
WB_np = extract(modelB, NLB)
print('\n' + '=' * 65)
print('  INTELLIGENCE GAP MEASUREMENT')
print('  Does A know these patterns? Does B?')
print('=' * 65)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
modelA.eval()
modelB.eval()
test_sequences = [('counting', [3, 4, 5, 6, 7, 8], 9, 'next in 3 4 5 6 7 8 = ?'), ('evens', [2, 4, 6, 8, 10, 12], 14, 'next in 2 4 6 8 10 12 = ?'), ('odds', [1, 3, 5, 7, 9, 11], 13, 'next in 1 3 5 7 9 11 = ?'), ('primes', [2, 3, 5, 7, 11, 13], 17, 'next in 2 3 5 7 11 13 = ?'), ('fibonacci', [1, 2, 3, 5, 8, 13], 21, 'next in 1 2 3 5 8 13 = ?'), ('squares', [1, 4, 9, 16, 25, 0], 0, 'next in 1 4 9 16 25 = ? (36 mod 31=5, but 36>30 so test differently)'), ('threes', [0, 3, 6, 9, 12, 15], 18, 'next in 0 3 6 9 12 15 = ?'), ('powers2', [1, 2, 4, 8, 16, 1], 2, 'next in 1 2 4 8 16 = ? (32 mod 31=1, next=2)')]
tests = [('counting', [3, 4, 5, 6, 7, 8], 9, '3 4 5 6 7 8 → ?'), ('evens', [0, 2, 4, 6, 8, 10], 12, '0 2 4 6 8 10 → ?'), ('odds', [1, 3, 5, 7, 9, 11], 13, '1 3 5 7 9 11 → ?'), ('primes', [2, 3, 5, 7, 11, 13], 17, '2 3 5 7 11 13 → ?'), ('fibonacci', [2, 3, 5, 8, 13, 21], 3, '2 3 5 8 13 21 → ? (34 mod 31 = 3)'), ('threes', [0, 3, 6, 9, 12, 15], 18, '0 3 6 9 12 15 → ?'), ('fours', [0, 4, 8, 12, 16, 20], 24, '0 4 8 12 16 20 → ?'), ('countdown', [15, 14, 13, 12, 11, 10], 9, '15 14 13 12 11 10 → ?')]
print(f"\n  {'Pattern':>12} {'Sequence':>25} {'Truth':>6} {'A pred':>8} {'B pred':>8}  {'A✓':>4} {'B✓':>4}")
print(f"  {'─' * 72}")

def predict(model, seq, K):
    ids = torch.tensor([seq[-K:]], device=device)
    with torch.no_grad():
        logits = model(ids)[0]
    return int(logits[-1].argmax())
A_score = 0
B_score = 0
for name, seq, truth, desc in tests:
    pa = predict(modelA, seq, KA)
    pb = predict(modelB, seq, KB)
    a_ok = '✓' if pa == truth else '✗'
    b_ok = '✓' if pb == truth else '✗'
    if pa == truth:
        A_score += 1
    if pb == truth:
        B_score += 1
    seq_str = ' '.join((str(x) for x in seq[-6:]))
    print(f'  {name:>12} {seq_str:>25} {truth:>6} {pa:>8} {pb:>8}  {a_ok:>4} {b_ok:>4}')
print(f'\n  Small model A score: {A_score}/{len(tests)} patterns known')
print(f'  Large model B score: {B_score}/{len(tests)} patterns known')
print(f'\n  Intelligence gap: B knows {B_score - A_score} more patterns than A')
print(f'  SURGERY GOAL: grafted A should know {B_score} patterns, stay size {DA}')
np.savez(os.path.join(_dir, 'num_small_weights.npz'), **WA_np)
np.savez(os.path.join(_dir, 'num_large_weights.npz'), **WB_np)
meta = {'VS': VS, 'MAX_NUM': MAX_NUM, 'DA': DA, 'HA': HA, 'NLA': NLA, 'KA': KA, 'DB': DB, 'HB': HB, 'NLB': NLB, 'KB': KB, 'accA': float(accA), 'accB': float(accB), 'small_data_len': len(small_data), 'large_data_len': len(large_data), 'A_pattern_score': A_score, 'B_pattern_score': B_score, 'test_patterns': [(name, seq, truth) for name, seq, truth, _ in tests]}
with open(os.path.join(_dir, 'num_meta.json'), 'w') as f:
    json.dump(meta, f, indent=2)
print(f'\n  Saved: num_small_weights.npz')
print(f'         num_large_weights.npz')
print(f'         num_meta.json')
print(f'\n  Next: run surgery_v10_number.py')
print(f'        Target: grafted A scores {B_score}/8 while staying D={DA}\n')
