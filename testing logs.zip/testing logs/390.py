import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
MODEL_NAME = 'roneneldan/TinyStories-1M'
print(f'\nLoading {MODEL_NAME}...')
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
model.eval()
D = model.config.hidden_size
n_layers = model.config.num_layers
n_heads = model.config.num_heads
head_dim = D // n_heads
FFN_D = D * 4
print(f'D={D}  Layers={n_layers}  n_heads={n_heads}  head_dim={head_dim}')

def r2(pred, true):
    pred = np.array(pred, dtype=np.float64).flatten()
    true = np.array(true, dtype=np.float64).flatten()
    ss_res = np.sum((pred - true) ** 2)
    ss_tot = np.sum((true - np.mean(true)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 1e-12 else 1.0

def fit_r2(X, Y, split=0.8):
    X = np.array(X, dtype=np.float64)
    Y = np.array(Y, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):
        return (float('nan'), float('nan'))
    n = len(X)
    s = int(n * split)
    if s < 10:
        return (float('nan'), float('nan'))
    Xb = np.c_[X, np.ones(n)]
    try:
        W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    except:
        return (float('nan'), float('nan'))
    return (r2(Xb[:s] @ W, Y[:s]), r2(Xb[s:] @ W, Y[s:]))

def show(name, r2_te, width=60):
    if not np.isfinite(r2_te):
        print(f'  {name:<{width}} NaN')
        return
    marker = '✓✓ EXACT' if r2_te > 0.9999 else '✓  NEAR' if r2_te > 0.999 else '~  STRONG' if r2_te > 0.95 else '·  PARTIAL' if r2_te > 0.5 else '✗  LOW'
    print(f'  {name:<{width}} R²={r2_te:.6f}  {marker}')
print(f'\nCollecting per-sequence activations...')
texts = ['Once upon a time there was a little girl named Lily who loved to play in the garden.', 'The old farmer woke up very early every morning before the sun had risen in the sky.', 'Deep in the forest there was a small house where a family of bears lived together.', 'There was once a brave young knight who lived in a castle near the tall mountains.', 'A small girl named Sophie loved books more than anything else in the whole wide world.', 'The little village sat quietly at the edge of a great forest full of ancient tall trees.', 'Tommy was a small boy who was afraid of the dark and could not sleep at night.', 'The ocean was vast and blue and stretched as far as the eye could possibly see.', 'High up in the mountains there was a small school where children came from far away.', 'She opened her eyes slowly and looked at the bright morning light coming through the window.', 'The two friends had known each other since they were very small children in the same class.', 'Once there was a little rabbit who lived in a burrow under the roots of an old oak tree.', 'The kind old woman lived alone in a small cottage at the edge of the quiet green forest.', 'A young boy named Sam found a small puppy hiding under the bridge near his house one day.', 'The little dragon lived on top of the highest mountain and had never spoken to anyone.', 'In the deep blue ocean there lived a curious fish who wanted to see the world above.', 'The old clock in the corner of the room had not worked for many many long quiet years.', 'A tiny seed fell from the great oak tree and landed softly on the dark rich ground below.', 'The young painter stood in front of the blank white canvas and did not know where to start.', 'Every evening the grandfather would sit in his old chair and tell stories to the children.', 'The little cat sat on the warm windowsill and watched the birds fly past in the morning.', 'A brave explorer set out on a long journey through the jungle to find the ancient temple.', 'The princess looked out from the tower window at the green meadows stretching far below.', 'Three children found a magical door hidden behind the waterfall near the edge of the forest.', 'The wise old owl sat in the oak tree and watched the children playing in the field below.', 'A small boat drifted slowly down the quiet river through the tall reeds and willow trees.', 'The scientist worked late into the night trying to solve the difficult equation on the board.', 'Two rabbits sat together at the edge of the meadow watching the sunset fade over the hills.', 'The mountain was covered in snow and the climbers moved slowly upward toward the rocky peak.', 'A gentle rain began to fall on the small town and the children ran inside from the playground.']
stores_seq = {k: {li: [] for li in range(n_layers)} for k in ['ln1_out', 'softmax_out', 'attn', 'scores_raw']}
cur_seq = {k: {li: None for li in range(n_layers)} for k in stores_seq}
hooks = []
for li in range(n_layers):

    def make_ln1(l):

        def h(m, i, o):
            cur_seq['ln1_out'][l] = o.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].ln_1.register_forward_hook(make_ln1(li)))

    def make_so(l):

        def h(m, i, o):
            inp = i[0] if isinstance(i, tuple) else i
            cur_seq['softmax_out'][l] = inp.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].attn.attention.out_proj.register_forward_hook(make_so(li)))

    def make_a(l):

        def h(m, i, o):
            o2 = o[0] if isinstance(o, tuple) else o
            cur_seq['attn'][l] = o2.detach().float()[0].numpy().copy()
        return h
    hooks.append(model.transformer.h[li].attn.register_forward_hook(make_a(li)))
seq_data = {li: [] for li in range(n_layers)}
with torch.no_grad():
    for text in texts:
        for k in cur_seq:
            for li in range(n_layers):
                cur_seq[k][li] = None
        toks = tokenizer(text, return_tensors='pt', max_length=64, truncation=True)
        L = toks['input_ids'].shape[1]
        out = model(**toks, output_attentions=True)
        for li in range(n_layers):
            entry = {'L': L}
            for k in ['ln1_out', 'softmax_out', 'attn']:
                if cur_seq[k][li] is not None:
                    entry[k] = cur_seq[k][li][:L].copy()
            if out.attentions and li < len(out.attentions):
                aw = out.attentions[li].detach().float()[0].numpy()
                entry['attn_weights'] = aw.copy()
            if 'ln1_out' in entry:
                W_q = model.transformer.h[li].attn.attention.q_proj.weight.detach().float().numpy()
                W_k = model.transformer.h[li].attn.attention.k_proj.weight.detach().float().numpy()
                W_v = model.transformer.h[li].attn.attention.v_proj.weight.detach().float().numpy()
                ln1 = entry['ln1_out'].astype(np.float64)
                Q = ln1 @ W_q.T
                K = ln1 @ W_k.T
                V = ln1 @ W_v.T
                entry['Q'] = Q
                entry['K'] = K
                entry['V'] = V
                scores_heads = []
                for h_idx in range(n_heads):
                    hs = h_idx * head_dim
                    he = hs + head_dim
                    Qh = Q[:, hs:he]
                    Kh = K[:, hs:he]
                    sc = Qh @ Kh.T / np.sqrt(head_dim)
                    scores_heads.append(sc)
                entry['scores'] = np.stack(scores_heads, axis=0)
            seq_data[li].append(entry)
for h in hooks:
    h.remove()
print(f'Sequences: {len(texts)}')
print(f"\n{'=' * 70}")
print(f'  TEST A — Bilinear: [Q[i], K[j]] → score[i,j]')
print(f'  score[i,j] = Q[i]·K[j]/sqrt(d)')
print(f'  Is this linear in [Q[i], K[j]]?')
print(f'  Collect all token pairs. Fit [Q_i, K_j] → score_ij.')
print(f"{'=' * 70}\n")
for li in [0, 3, 7]:
    pairs_X = []
    pairs_Y = []
    for entry in seq_data[li]:
        if 'Q' not in entry:
            continue
        L = entry['L']
        Q = entry['Q'].astype(np.float32)
        K = entry['K'].astype(np.float32)
        for h_idx in range(n_heads):
            hs = h_idx * head_dim
            he = hs + head_dim
            Qh = Q[:, hs:he]
            Kh = K[:, hs:he]
            sc = entry['scores'][h_idx]
            for i in range(L):
                for j in range(L):
                    pairs_X.append(np.concatenate([Qh[i], Kh[j]]))
                    pairs_Y.append(sc[i, j])
    if not pairs_X:
        continue
    X = np.array(pairs_X, dtype=np.float64)
    Y = np.array(pairs_Y, dtype=np.float64).reshape(-1, 1)
    n = len(X)
    s = int(n * 0.8)
    Xb = np.c_[X, np.ones(n)]
    W = np.linalg.lstsq(Xb[:s], Y[:s], rcond=None)[0]
    r2_tr = r2(Xb[:s] @ W, Y[:s])
    r2_te = r2(Xb[s:] @ W, Y[s:])
    show(f'  Layer {li}: [Q_i, K_j] → score_ij (linear?)', r2_te)
    self_X = []
    self_Y = []
    for entry in seq_data[li]:
        if 'Q' not in entry:
            continue
        L = entry['L']
        Q = entry['Q'].astype(np.float32)
        K = entry['K'].astype(np.float32)
        for h_idx in range(n_heads):
            hs = h_idx * head_dim
            he = hs + head_dim
            Qh = Q[:, hs:he]
            Kh = K[:, hs:he]
            for i in range(L):
                self_X.append(Qh[i] * Kh[i])
                self_Y.append(entry['scores'][h_idx][i, i])
    if self_X:
        X2 = np.array(self_X, dtype=np.float64)
        Y2 = np.array(self_Y, dtype=np.float64)
        _, r2_self = fit_r2(X2, Y2)
        show(f'  Layer {li}: Q[i]*K[i] (elem) → self_score[i,i]', r2_self)
print(f"\n{'=' * 70}")
print(f'  TEST B — Exact bilinear: Q@K^T/sqrt(d) = scores exactly?')
print(f'  This must be exact by definition. Verify max_err=0.')
print(f"{'=' * 70}\n")
for li in [0, 3, 7]:
    errs = []
    for entry in seq_data[li]:
        if 'Q' not in entry or 'scores' not in entry:
            continue
        L = entry['L']
        Q = entry['Q'].astype(np.float64)
        K = entry['K'].astype(np.float64)
        for h_idx in range(n_heads):
            hs = h_idx * head_dim
            he = hs + head_dim
            Qh = Q[:, hs:he]
            Kh = K[:, hs:he]
            sc_computed = Qh @ Kh.T / np.sqrt(head_dim)
            sc_stored = entry['scores'][h_idx].astype(np.float64)
            errs.append(float(np.max(np.abs(sc_computed - sc_stored))))
    if errs:
        max_err = float(np.max(errs))
        mean_err = float(np.mean(errs))
        marker = '✓✓ EXACT' if max_err < 0.0001 else '✗ NOT EXACT'
        print(f'  Layer {li}: Q@K^T/sqrt(d) = scores  max_err={max_err:.6f}  {marker}')
print(f"\n{'=' * 70}")
print(f'  TEST C — Softmax natural space: what f(scores_row) → softmax_row?')
print(f'  softmax(x)[i] = exp(x[i]) / sum(exp(x))')
print(f'  Test per-row of score matrix.')
print(f'  Collect (score_row, softmax_row) pairs.')
print(f'  Find f such that f(score_row) → softmax_row is linear.')
print(f"{'=' * 70}\n")

def softmax(x):
    x = x - np.max(x)
    e = np.exp(np.clip(x, -20, 20))
    return e / e.sum()
for li in [0, 3, 7]:
    score_rows = []
    softmax_rows = []
    for entry in seq_data[li]:
        if 'scores' not in entry or 'attn_weights' not in entry:
            continue
        L = entry['L']
        for h_idx in range(n_heads):
            for i in range(L):
                sc_row = entry['scores'][h_idx][i, :L].astype(np.float64)
                sw_row = entry['attn_weights'][h_idx][i, :L].astype(np.float64)
                score_rows.append(sc_row[:L])
                softmax_rows.append(sw_row[:L])
    if not score_rows:
        continue
    max_L = max((r.shape[0] for r in score_rows))
    Xr = np.zeros((len(score_rows), max_L), dtype=np.float64)
    Yr = np.zeros((len(score_rows), max_L), dtype=np.float64)
    for idx, (sr, sw) in enumerate(zip(score_rows, softmax_rows)):
        L_i = len(sr)
        Xr[idx, :L_i] = sr
        Yr[idx, :L_i] = sw
    print(f'  Layer {li}: {len(score_rows)} rows  max_L={max_L}')

    def sm_transform(X, fn):
        result = np.zeros_like(X)
        for idx in range(len(X)):
            try:
                result[idx] = fn(X[idx])
            except:
                result[idx] = X[idx]
        return result
    transforms_sm = {'raw scores': lambda x: x, 'exp(scores)': lambda x: np.exp(np.clip(x - x.max(), -20, 20)), 'scores - max': lambda x: x - x.max(), 'softmax(scores)': lambda x: (lambda e: e / e.sum())(np.exp(np.clip(x - x.max(), -20, 20))), 'log_softmax': lambda x: np.clip(x - x.max(), -20, 0) - np.log(np.sum(np.exp(np.clip(x - x.max(), -20, 0)))), 'scores²': lambda x: x ** 2, 'tanh(scores)': lambda x: np.tanh(np.clip(x, -10, 10)), 'scores/||scores||': lambda x: x / (np.linalg.norm(x) + 1e-08), 'rank(scores)': lambda x: np.argsort(np.argsort(x)).astype(float)}
    results_sm = []
    for tname, tfn in transforms_sm.items():
        try:
            Xt = sm_transform(Xr, tfn)
            if not np.all(np.isfinite(Xt)):
                continue
            _, rv = fit_r2(Xt, Yr)
            results_sm.append((tname, rv))
        except:
            pass
    results_sm.sort(key=lambda x: x[1], reverse=True)
    for tname, rv in results_sm:
        show(f'    {tname:<35}', rv, width=40)
    print(f'\n  Layer {li}: Exact softmax formula check:')
    errs = []
    for entry in seq_data[li]:
        if 'scores' not in entry or 'attn_weights' not in entry:
            continue
        L = entry['L']
        for h_idx in range(n_heads):
            sc = entry['scores'][h_idx].astype(np.float64)
            aw = entry['attn_weights'][h_idx].astype(np.float64)
            sc_stable = sc - sc.max(1, keepdims=True)
            exp_sc = np.exp(np.clip(sc_stable, -20, 20))
            sm_computed = exp_sc / exp_sc.sum(1, keepdims=True)
            err = float(np.max(np.abs(sm_computed[:L, :L] - aw[:L, :L])))
            errs.append(err)
    max_err = float(np.max(errs))
    mean_err = float(np.mean(errs))
    marker = '✓✓ EXACT' if max_err < 0.001 else '~ APPROX' if max_err < 0.01 else '✗ WRONG'
    print(f'  softmax(Q@K^T/sqrt(d)) = attn_weights: max_err={max_err:.6f}  {marker}')
    print()
print(f"\n{'=' * 70}")
print(f'  TEST D — Per-head softmax natural space')
print(f'  GPT-Neo has local (window=64) and global attention.')
print(f'  Different attention types → different natural spaces?')
print(f"{'=' * 70}\n")
for li in range(n_layers):
    att_type = model.transformer.h[li].attn.attention_type
    score_rows_l = []
    sm_rows_l = []
    for entry in seq_data[li]:
        if 'scores' not in entry or 'attn_weights' not in entry:
            continue
        L = entry['L']
        for h_idx in range(n_heads):
            for i in range(L):
                score_rows_l.append(entry['scores'][h_idx][i, :L].astype(np.float64))
                sm_rows_l.append(entry['attn_weights'][h_idx][i, :L].astype(np.float64))
    if not score_rows_l:
        continue
    max_L = max((r.shape[0] for r in score_rows_l))
    Xr = np.zeros((len(score_rows_l), max_L))
    Yr = np.zeros((len(score_rows_l), max_L))
    for idx, (sr, sw) in enumerate(zip(score_rows_l, sm_rows_l)):
        L_i = len(sr)
        Xr[idx, :L_i] = sr
        Yr[idx, :L_i] = sw
    Xt = np.array([np.exp(np.clip(r - r.max(), -20, 20)) for r in Xr])
    _, rv_exp = fit_r2(Xt, Yr)
    _, rv_raw = fit_r2(Xr, Yr)
    print(f'  Layer {li} [{att_type}]: raw_scores→sm={rv_raw:.4f}  exp(scores)→sm={rv_exp:.4f}')
print(f"\n{'=' * 70}")
print(f'  MULTI-NONLINEAR NATURAL SPACES — COMPLETE MAP')
print(f"{'=' * 70}")
print(f'\n  THREE NATURAL SPACE TYPES IN ATTENTION:\n\n  TYPE 1 — Per-token (D-dim):\n    ln1_out → Q, K, V = W_q, W_k, W_v @ ln1_out.\n    Linear. R²=1.000. Already proven.\n    softmax_out (D-dim) → attn = W_o @ softmax_out.\n    Linear. R²=1.000. Already proven.\n\n  TYPE 2 — Per-token-pair (head_dim-dim):\n    Q[i] · K[j] / sqrt(d) = score[i,j].\n    BILINEAR. Product of two linear maps.\n    Cannot be linear in single token.\n    But: [Q[i], K[j]] → score[i,j] = linear? (TEST A)\n    If yes: bilinear space = natural space of scoring.\n    score[i,j] = <Q[i], K[j]> = inner product.\n    This is EXACTLY linear in [Q[i], K[j]] concatenated.\n    The fitting confirms: yes or no.\n\n  TYPE 3 — Per-sequence-row (L-dim):\n    score[i,:] → softmax[i,:].\n    Nonlinear. Cross-position normalization.\n    Natural space: exp(score) → softmax? (TEST C)\n    exp(score[i,j]) = e^{score} = numerator of softmax.\n    softmax[i,j] = exp(score[i,j]) / sum_k exp(score[i,k])\n    = linear in exp(score[i,:]) with constraint sum=1.\n    If exp(score) → softmax linear: TYPE 3 natural space = exp space.\n    \n  COMPLETE CRYSTAL MAP (updated):\n    LN1, LN2, LNF:        Type 1. Natural space = (h-mean)/std. ✓\n    W_q,W_k,W_v,W1,W2,W_o: Type 1. Linear always. ✓\n    residuals:             Exact sum. ✓\n    gelu:                  Type 1. Natural space = gelu_formula(x). ✓\n    scoring (Q@K^T):       Type 2. Natural space = [Q_i, K_j]. ?\n    softmax:               Type 3. Natural space = exp(scores). ?\n    \n  IF TYPE 2 AND TYPE 3 CONFIRMED:\n    LLM = exact machine at EVERY scale:\n    Per-token: all linear. R²=1.000.\n    Per-pair: bilinear = linear in pair space. R²=1.000.\n    Per-row: softmax = linear in exp space. R²=1.000.\n    \n    NO operation is truly nonlinear in its natural space.\n    Only the MAPPING between spaces is nonlinear.\n    All spaces = linear internally.\n    \n    Intelligence = choosing which space to operate in.\n    Computation = reading in the correct space.\n    Crystals = space transitions.\n')
print('=' * 70 + '\n')
